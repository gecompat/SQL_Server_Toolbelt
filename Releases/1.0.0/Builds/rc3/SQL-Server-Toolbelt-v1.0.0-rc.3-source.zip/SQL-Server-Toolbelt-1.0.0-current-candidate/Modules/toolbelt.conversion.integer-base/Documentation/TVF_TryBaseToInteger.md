# toolbelt_conversion.TVF_TryBaseToInteger

**Typ:** Inline Table-valued Function

Decodiert `@EncodedValue varchar(65)` mit `@Alphabet varchar(93)` und liefert
genau eine Zeile mit `DecodedValue bigint`. Ungültige Alphabete, nicht
kanonische Darstellungen, unbekannte Zeichen, `NULL` oder Overflow ergeben
eine Zeile mit `NULL`.

`+` ist eine reguläre Alphabetziffer, wenn es im gewählten Alphabet enthalten
ist. Ein zusätzliches positives Vorzeichen wird nicht interpretiert; mit dem
Dezimalalphabet bleibt `+1` ungültig. Führende Nullzeichen, `-0`, Whitespace,
Präfixe und Gruppierungszeichen werden abgelehnt. Groß- und Kleinschreibung
bleiben durch den binären Vergleich verschieden.

```sql
SELECT source.EncodedValue, decoded.DecodedValue
FROM (VALUES ('FF'), ('-FF'), ('invalid')) AS source(EncodedValue)
OUTER APPLY
    toolbelt_conversion.TVF_TryBaseToInteger
    (
          source.EncodedValue
        , '0123456789ABCDEF'
    ) AS decoded;
```

Die inline TVF ist der kanonische relationale Kern; die SVF bleibt als
Convenience-API verfügbar.

## Aufrufparameter

<!-- API_PARAMETERS:BEGIN -->
| Parameter | SQL-Typ | Default | Richtung | Erklärung / Werte |
|---|---|---|---|---|
| `@EncodedValue` | `varchar(65)` | `kein Default` | Input | Zahlentext aus dem angegebenen Alphabet, höchstens 65 varchar-Bytes; optional genau ein führendes - als Vorzeichen. Keine führenden Nullziffern bei mehrstelligen Werten, kein negatives Null und keine Leerzeichen-Normalisierung. Alle Zeichen müssen Alphabetziffern sein; Betrag muss in bigint passen. Leer, NULL, ungültige Lexik oder Überlauf ergibt NULL. |
| `@Alphabet` | `varchar(93)` | `kein Default` | Input | 2..93 verschiedene einbyteige ASCII-Zeichen aus Codes 33..126, ohne Minuszeichen -. Reihenfolge definiert die Ziffernwerte ab 0; das erste Zeichen ist die Nullziffer. Binärer, case-sensitiver Vergleich; keine Duplikate oder Leerzeichen. NULL/ungültiges Alphabet ergibt NULL. |
<!-- API_PARAMETERS:END -->

## Technischer Lösungsweg

[Grundlage, Verarbeitungsschritte und Designgründe](../../../Documentation/Reference/IMPLEMENTATION_GUIDE.md#zahlensysteme).

## Weiterführende Referenzen

- [Modul, Installation und Testgrenzen](../README.md)
- [SQL-Definition](../Source/TVF_TryBaseToInteger.sql)
- [Objektübersicht](../../../Documentation/Reference/API_CATALOG.md)
