# Testevidenz

## Linux-Repeat mit explizitem Compatibility Level

Der [bestehende Runtimeworkflow](../../../.github/workflows/w6d-execution-cancel-runtime.yml)
prüft den befüllten achtspaltigen Repeat lokal und direkt zentral auf SQL2019
CL150, SQL2022 CL150/160 und SQL2025 CL150/160/170. Der
[Shelltreiber](../../../Tests/CI/run-w6d-execution-cancel-linux.sh) setzt vor
jeder Repeat-Fixture den Level und verlangt den passenden aktuellen
`sys.databases`-Wert. Ein fehlender oder abweichender Wert scheitert mit52748;
unzulässige Engine-/Levelpaare werden vor der SQL-Abfrage abgewiesen.
Image-Defaults gelten nicht als Levelnachweis.

Je vollständigem Workflowlauf sind zwölf Repeatkontexte,24 echte Deploys
und36 isolierte Principalgegenproben erforderlich. Erst nach erfolgreichem
Originalskript erscheint je Kontext `W6D_REPEAT_LEVEL_VERIFIED` mit Version,
Level und Modus. Die drei vorhandenen SQL-Jobs,35-Minuten-Fristen und eigenen
Container-/DB-Cleanupverträge bleiben erhalten. API-/Concurrency-/Security-,
Consumer- und Uninstall-Prüfungen bleiben Bestandteil derselben Jobs.
SQL2022 führt die bestehenden API-/Concurrency-Prüfungen zusätzlich auf CL150 aus.

Die [Offlineprobe](../../../Tests/CI/test_w6d_repeat_levels.py) führt die echten extrahierten
Shellfunktionen mit SQL-/Datei-Stubs aus. Sechs Fälle prüfen alle unterstützten
Paare und Modi, ungültige Auswahl, Level-/Fixturefehler, reale Aufrufstellen
und vollständige Bash-Syntax. Sie läuft im vorhandenen statischen Schritt;
kein Docker, Lab oder SQL. Der vorhandene Cleanup-Selbsttest belegt separat
unveränderte Ownership-/Fehler-/Signalguards. Native Ergebnisse müssen den
exakten tatsächlichen Head-/Main-CI-Jobs zugeordnet werden; Quellcode und
Offlineprobe allein belegen keinen nativen PASS. Die untenstehenden älteren
Windows- und Linux-Zeugen behalten ihre ursprünglichen Grenzen.

Dies ist Erhaltung synthetischer Bestandsdaten, keine neue Rechtevergabe,
Identitätsanlage, Quoten-/CrossDB- oder harte Host-Recoveryqualifikation.
Die Produktquellen und Runtime-Fixtures bleiben unverändert.


## Vollständige achtspaltige Windows-Repeat-Matrix vom 2026-11-06

Die ausdrücklich auf15 Ziel-/Auditaufrufe, sechs eigene Datenbanken und
45 Minuten begrenzte Restwelle bestand den aktuellen achtspaltigen
`RepeatCurrent` in sämtlichen ausgewählten Windows-Kontexten:

| SQL-Version / Patch | Compatibility Levels | Deploymentmodi | Gesamtfälle je CL |
|---|---|---|---|
| Windows2019 / CU32 | 150 | local, central | beide bestanden |
| Windows2022 / CU26 | 150, 160 | local, central | beide bestanden |
| Windows2025 / CU8 | 150, 160, 170 | local, central | beide bestanden |

Zwölf Kontexte bestanden je zwei echte Deploys und drei isolierte
Principalgegenproben: insgesamt24 Wiederholungen und36 Gegenproben.
Sechs vollständige Gesamtkoordinatoren und sechs separate frische Audits
bestätigten Erfolg, Entfernung aller eigenen Datenbanken und unveränderte
fremde Konfiguration, Trusts, Principals, Permissions und CLR-Verbraucher.
Die drei übrigen Aufrufe waren lesende Vorprüfungen der exakt ausgewählten,
schema-validierten Labziele einschließlich tatsächlicher Windows-/SQL-/CU-
Identität. Alle15 Aufrufe und sechs Datenbanken sind verbraucht und geschlossen;
es gab keinen fehlgeschlagenen Versuch und keine Wiederholung in dieser Welle.

Produkt- und Testquellen sind an
[`89f15fe5`](https://github.com/gecompat/SQL_Server_Toolbelt/tree/89f15fe58eb2ec17618a37cf74ce7a20ca1ba5f8)
gebunden. Der private Adapter führt die unveränderten Originalincludes aus,
prüft das tatsächliche CL und verlangt je Kontext die drei geordneten
Gegenprobenzeugen sowie den abschließenden Repeatzeugen. Jeder Audit bindet
das finale Originaljournal und seine Quellpins; alle Bindungen wurden vor
diesem abgeleiteten Dokumentationsnachtrag erneut geprüft. Rohdaten und
Originaljournale bleiben privat.

Damit ist die achtspaltige Windows-Repeat-Lücke über alle unterstützten CLs
lokal und direkt zentral geschlossen. Die früheren fünfspaltigen Ergebnisse
und der damals fehlgeschlagene Windows2019-/local-Fall bleiben unverändert
historisch. Der neue Erfolg ersetzt keine alte Fehlermeldung und wird nicht
als deren nachträglicher PASS ausgelegt.

Dies ist Bestandserhaltung einschließlich synthetischer Principal-ID, SID
und Erzeugungsbytes, keine neue Caller-/Quoten-/CrossDB-Identitätsabnahme.
Functional verwendet erforderliche Verschlüsselung mit dem expliziten
Lab-Trustwert; authentifiziertes TLS ist hier nicht qualifiziert.
SQL-Rechte, Serveroptionen, CLR, Trust und Labressourcen wurden nicht geändert.
Minimalrechte, nichtleere Benutzergrants, historische Migrationen und harte
Unterbrechungen bleiben separat. Das Modul bleibt teilweise validiert und
unveröffentlicht.

## Windows-Repeat vom 2026-11-06: elf abgegrenzte Kontexte

Der unveränderte bisherige `RepeatCurrent` bestand am Produkt-/Fixturestand
`4ed7aad3` auf Windows SQL2019/CU32 zentral bei CL150, SQL2022/CU26 lokal und
zentral bei CL150/160 sowie SQL2025/CU8 lokal und zentral bei CL150/160/170.
Das sind elf erfolgreiche Kontexte mit je zwei echten Deploys, insgesamt
22 Wiederholungen, und fünf erfolgreiche Gesamtkoordinatoren mit separaten
frischen Audits. Alle eigenen Datenbanken sind entfernt; fremde Konfiguration,
Trusts, Principals, Permissions und CLR-Verbraucher blieben unverändert.

Windows2019/CL150 lokal bleibt fehlgeschlagen: Der zusätzliche private
Cleanup-/Transaktionsguard verwarf den ersten Lauf mit54980/3. Die eigene DB
wurde regulär entfernt, der frische Audit bestätigte Abwesenheit und
unveränderte fremde Zustände. Einzelwerte des damaligen kombinierten
Prädikats wurden nicht erfasst; daraus wird keine nachträgliche Rootcause oder
ein bestandener Gesamtfall abgeleitet. Es gab keine Wiederholung dieses Falls.
Die Welle ist mit15 Ziel-/Auditaufrufen und sechs eigenen DBs geschlossen.

Eine lesende Gegenprobe im ohnehin vorgesehenen späteren Vorcheck zeigte
auf SQL2022 und SQL2025 einen abweisenden kombinierten Ausdruck trotz
neutraler Transaktionswerte außerhalb der Tabellenabfrage. Der korrigierte
private Adapter prüft Transaktionszustand und Tabelleninhalt in getrennten
Statements, behält beide verlangten Zustände und sämtliche ursprünglichen
Ownership-/Consumer-Gates bei. Nur zuvor unbegonnene Matrixfälle wurden
innerhalb derselben unveränderten Obergrenzen fortgesetzt; der Erstfehler
bleibt fehlgeschlagen. Originalquellen und Journale bleiben privat erhalten.

Diese Windows-Abnahme prüfte fünf historische Nutzdatenspalten und den
ausgewählten Katalog. Sie belegt nicht die Datenwerte der drei später
ergänzten Principalspalten. Deren neuer Nachweis folgt über den unten
beschriebenen erweiterten Test. Das Modul bleibt `partially validated` und
unveröffentlicht; Minimalrechte, nichtleere Benutzergrants, historische
Migrationen und harte Unterbrechungen bleiben eigenständige Nachweise.

## Aktueller Repeat mit vollständiger Principalbindung

Der aktuelle Test erweitert die Zeilensnapshots um `RequestedByPrincipalId`,
die exakten SIDbytes und die acht gespeicherten `datetime`-Bytes von
`RequestedByPrincipalCreatedAt`. Er umfasst damit alle acht Tabellenspalten.
Die eigene Fixture enthält eine vollständig NULL-belegte historische
Zuordnung und drei synthetische nichtleere Zuordnungen. Dafür werden weder
Principals angelegt noch SQL-Rechte erteilt; dies ist Datenbestandserhaltung,
keine zusätzliche Quoten-/Callerrechteabnahme.

Drei Gegenproben ändern jeweils eines dieser Felder in einer eigenen
Rollbacktransaktion. Das originale Capture-/Assert-Paar muss jeweils exakt
52743/State1 auslösen; ein übersehener Unterschied scheitert mit52747.
Die automatische Rowversionänderung wird ausschließlich im temporären
Gegenprobensnapshot auf den alten Wert kompensiert. Damit kann sie ein
fehlendes Principal-Feld im Snapshot nicht verdecken. Die persistente
Mutation und sämtliche Snapshotanpassungen werden zurückgerollt. Positive
Deployvergleiche verwenden diese Kompensation nicht.

Der vorhandene [Runtimeworkflow](../../../.github/workflows/w6d-execution-cancel-runtime.yml)
führt den erweiterten Test auf seinen ausgewiesenen Linux-Versionen/CLs
lokal und zentral aus. Ein Erfolg muss dem tatsächlich geprüften Head oder
Main-Run zugeordnet werden; die elf Windows-Altfälle werden durch diese
Teständerung nicht zu achtspaltigen oder vollständigen Matrixnachweisen.
Eine weitere native Windows-Ausführung ist in der geschlossenen Welle
nicht enthalten.
Die spätere, separat freigegebene
[vollständige Windows-Restwelle](#vollständige-achtspaltige-windows-repeat-matrix-vom-2026-11-06)
belegt nun die oben beschriebene achtspaltige Matrix; die vorherige Welle
bleibt geschlossen.

Der erste CI-Head der Erweiterung scheiterte auf allen drei Linux-Versionen
mit1934, weil die neue XML-Methode im frischen SQLCMD-Testprozess
`QUOTED_IDENTIFIER ON` benötigt. Der Test setzt diesen Parse-Time-Modus nun
vor einem eigenen Batchtrenner explizit. Alle drei eigenen CI-Zielbereinigungen
bestanden; der Erstlauf bleibt fehlgeschlagen und belegt keine Abnahme.

Die neuen Includes sind über den bestehenden Runtimeeinstieg und die
statische Artefaktprüfung erreichbar; das Modulmanifest, Exportpakete und
Produktversion werden nicht geändert. Ein zusätzlich angestoßener lokaler
Releasevorbereitungs-Vollcheck war nicht erfolgreich:274 Tests meldeten
zwölf Fehler und29 Ausführungsfehler, darunter nicht mehr aktuelle historische
Sourcepins. Diese Prüfung ist keine Releaseabnahme; alte Nachweise oder
Goldenwerte werden dafür nicht auf den heutigen Stand umgeschrieben. Der
Fehler bleibt von den tatsächlich ausgeführten Cancellation-Runtimefällen
und deren begrenztem Erfolg getrennt.

## Historische Funktionsnachweise

Die Runtime-Suite deckt den lokalen Vertrag, Idempotenz, Context-Auflösung,
Transaktionsschutz, Parallelität, Lifecycle und Central Deployment ab. Die
physische SQL_Server_Lab-Matrix ist für SQL Server 2019, 2022 und 2025 unter
Linux und Windows erfolgreich; das Modul ist `validated`.

## Befüllter versionsgleicher Repeat

[RepeatCurrent.Contract.sql](Runtime/RepeatCurrent.Contract.sql) ergänzt die
historische Lifecycle-Suite um zwei echte Deploys des installierten 1.0.0.
Vier synthetische Cancellation-Zeilen enthalten feste UTC-Auditwerte mit
100-ns-Anteilen, synthetische anfordernde Identitäten sowie NULL-, Leerstring-,
Unicode- und Trailing-Space-Gründe. Zwischen Baseline und beiden Deploys
findet keine DML an der persistenten Tabelle statt.

Das gemeinsame [Capture](Runtime/RepeatCurrent.Capture.sql) erfasst alle fünf
Spalten einschließlich der exakten Rowversionbytes. Der
[Assert](Runtime/RepeatCurrent.Assert.sql) vergleicht Zeilen und ausgewählte
Katalogmetadaten in beide Richtungen: vier Modulobjekte und ihre IDs,
Tabellenform, PK, Default, Indizes, vorhandene Constraints/FKs/Trigger,
Schemaowner, Modulmarker, vorhandene Permissions und Tabellen-/Spaltenannotation.
Nichtleere synthetische `MS_Description`-Werte an Tabelle und Reason-Spalte
müssen erhalten bleiben; dieser Installer erneuert sie nicht kanonisch.
Veränderliche DDL-Zeitstempel sind kein Orakel. Vorhandene Permissions werden
nur gelesen; die Fixture erzeugt keine Benutzergrants. Eine leere Grantmenge
ist kein Nachweis für nichtleere Benutzergrants oder tatsächliche Minimalrechte.

Der Aufruf erfolgt in einer eigenen leeren Installationsdatenbank und einer
frischen Session aus `Deployment/`, jeweils mit `DeploymentMode=local` oder
`central`. Nach beiden Repeats werden die Status-TVF und SVF read-only geprüft,
die vier eigenen Zeilen und Annotationen einschließlich eigener Beschreibungen
entfernt und der erfolgreiche
Abschluss mit einem festen Marker bestätigt. Ein Fehler bricht SQLCMD ab;
der aufrufende Adapter muss dann die eigene Testdatenbank beziehungsweise
seinen eigenen flüchtigen Testscope bereinigen. Eine Wiederaufnahme auf
teilweise verbliebener Fixture ist ausgeschlossen.

Der neue Repeat-Scope bestand am Commit
`fac18e590f854a26364e5f498c6a2b5d330a95c2` lokal/zentral auf Linux2019/150,
2022/160 und 2025/170. Historische Windows-/Linux-Evidenz oben ersetzt keine
weitere Repeat-Qualifikation. Neue Windows-, weitere Compatibility-Level-,
nichtleere Benutzergrant-, Minimalrechte- und historische Migrationsprüfungen
bleiben `not executed`; konkrete Evidenz steht nachfolgend getrennt.

## Aktuelle Validierungsevidenz

<!-- BEGIN GENERATED:MODULE_EVIDENCE -->
- Datum: `2026-10-07`
- Nachweis: `https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37690604199`
- Scope: Commit fac18e590f854a26364e5f498c6a2b5d330a95c2: zwei echte befüllte 1.0.0-Repeats lokal/zentral auf SQL Server 2019/150, 2022/160, 2025/170 Linux; alle fünf Spalten mit Rowversionbytes, synthetische Audit-/NULL-/Textwerte, ausgewählter Katalog und eigene typisierte Annotationen inklusive MS_Description erhalten. Vorhandene API-, Concurrency-, Consumer- und Uninstallfälle sowie eigene CI-Bereinigung bestanden. Keine neuen Windows-Repeats, weiteren Repeat-CLs, nichtleeren Benutzergrants, echten Minimalrechte oder historischen Schemaübergänge qualifiziert.
- Ergebnis: `success`
<!-- END GENERATED:MODULE_EVIDENCE -->
