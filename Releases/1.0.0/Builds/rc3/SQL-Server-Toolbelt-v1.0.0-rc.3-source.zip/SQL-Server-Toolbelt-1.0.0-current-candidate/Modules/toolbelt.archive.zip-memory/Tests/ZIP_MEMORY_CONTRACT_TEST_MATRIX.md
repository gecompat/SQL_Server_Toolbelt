# Contract-Testmatrix: ZIP Memory CLR Inspection

## Nachweisabgleich2026-11-06

Die spätere [Entryanzahl-Qualifikation](../../../Releases/1.0.0/ZIP-ENTRY-COUNT-QUALIFICATION.md)
belegt Listing mit10000 Einträgen, die Abweisung von10001 sowie des zu großen
MaxEntries-Parameters auf zwölf Ziel-/CL-Paaren lokal/direkt zentral. Die
nachfolgende alte `not executed`-Zeile für Entry-Count ist deshalb kein heutiger
offener Punkt dieses Listingprofils. Sie bleibt als historischer Eintrag erhalten.
Dies belegt für sich weder Archiv256MiB noch komprimierten Extraktionsinput128MiB.
Die spätere [native Archivbyte-Prüfung](../../../Releases/1.0.0/ZIP-ARCHIVE-BYTE-QUALIFICATION.md)
schließt separat exakt256MiB und ein Byte darüber für öffentliche Listing- und
Extraktionsaufrufe auf Windows2025/CU8 CL170 und Linux2019/latest CL150 jeweils
lokal/direkt zentral: acht positive und acht strikte Fehlerproben, beide
Gesamtläufe und frischen Abschlussaudits bestanden. Die große Füllpayload ist
nicht zur Extraktion ausgewählt; komprimierte Entry- und Ausgabegrenzen sowie
weitere Ziel-/CL-Kombinationen bleiben davon unberührt. Historische Tabellen
werden nicht nachträglich als neue Ausführungen umetikettiert.
Die getrennte [native Entry-Byteprüfung](../../../Releases/1.0.0/ZIP-ENTRY-BYTE-QUALIFICATION.md)
belegt auf denselben zwei Ziel-/CL-Paaren lokal/direkt zentral die tatsächlichen
128-MiB-Komprimat- und64-MiB-Ausgabegrenzen sowie jeweils ein Byte darüber:
acht positive/acht strikte Fehlerproben, zwei Gesamtläufe/zwei frische Audits.
Gültige DEFLATE-/Stored-Inputs und der öffentliche ResultTable-Weg isolieren
die Grenzen; keine Quotenänderung oder Wiederholung der grünen Archiv-/Entryanzahl-
Proben. Weitere Zielkontexte und vollständige Modulabnahme bleiben separat.
Die [Caller-Metadatenpflege](../../../Releases/1.0.0/ZIP-METADATA-UPDATE.md)
bindet außerdem die bereits berichteten Rechteprofile an deren Paketstand;
sie ist keine neue native Ausführung oder vollständige Modulqualifikation.

Der ergänzende Callerrechte-Nachweis umfasst ausschließlich die drei
bestehenden öffentlichen Listing-, Extraktions- und Writer-USPs mit festen
synthetischen ZIPs: [ZIP-Callerprofil](../../../Releases/1.0.0/ZIP-CALLER-PROFILE.md).
Er verändert keine historische Matrix und erweitert keine Produkt- oder
Plattformzusage.

Release 1.4, 2026-10-02: `local: Modules/toolbelt.file.xlsx-memory/Tests/Runtime/Invoke-LabContract.ps1` auf Linux 2019/latest und Windows 2025/CU8 erfolgreich; echte ZIP-1.3-Assemblyhash-Upgradefixture, bestehender Writer-SQL-Vertrag, SAFE local/central und nichtdoomende Lifecycle-Callerablehnung OFF/ON. Kein Ersatznachweis für offene Kapazitäts-/Plattformfälle.

## Writer 1.3.0: Zusatzscope

| Scope | Oracle | Stand |
|---|---|---|
| Stored, Deflate, leere Payloads, Unicode, nachgestellte Leerzeichen, CRC und Header | unabhängiger Framework-ZipArchive plus bitweiser CRC | lokal PASS |
| 32 MiB je Entry, 128 MiB Gesamtpayload, 1024 Entries und 2048 Name-Codeeinheiten | tatsächlich erzeugte und gelesene synthetische ZIPs | lokal PASS |
| Konfiguration: 136 MiB Envelope und 144 MiB Output | unabhängige Budgetcaps, maximaler gültiger Input kleiner | keine exakte Auslastungszusage |
| Vier parallele synthetische Aufrufe | Framework | lokal PASS, keine Serverkapazitätszusage |
| Input, Limits, Help, Append, Transaktionen, Ratio, 16-MiB-Payloads sowie local/central | Writer.Contract.sql | SQL 2019 Linux / 150 und SQL 2025 Windows / 150, 160, 170: PASS |
| Tatsächliche SQLClient-Metadaten und keine zusätzliche SELECT-Ausgabe | Writer.Metadata.ps1 | dieselben lokalen und zentralen Lab-Scopes: PASS |
| Echtes 1.2.0-Binaryupgrade, drei neue Namenskollisionen, historischer Erhalt und Uninstall | Adapter plus Hash-Oracle | dieselben Lab-Scopes: PASS |

Datierte Endstand-Evidence: 2026-10-01. Die vorhandenen encrypted-NULL-Regressionen und unveränderten Readergrenzen bestanden ebenfalls. SQL-Live-Ceilings oberhalb der 16-MiB-Standardpayload, Produktionsarchive und globale Kapazitäts-/Parallelitätszusagen bleiben ausdrücklich offen; `partially validated` bleibt erhalten. Keine privaten Host-, Build-, Ressourcen- oder Runtime-Logs werden gespeichert.

Plattform-Evidenz 2026-09-01: `local: Tests/CI/run-lab-local.ps1` war auf physischen SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und Linux latest erfolgreich; reale Archive, echte Extremgrößen, historische Upgrades und Interoperabilität bleiben offen. Der Modulstatus bleibt `partially validated`. Dieser Nachweis ersetzt frühere offene Windows-Aussagen; datierte ältere Einträge bleiben historische Evidenz.

V0a-Evidenz 2026-08-29: `local: Tests/CI/run-lab-local.ps1` belegt
ausschließlich den im Modulmanifest genannten physischen Linux-Scope; offene
Windows- und modulspezifische Fälle bleiben unberührt.

| Bereich | Pflichtfall | Status |
|---|---|---|
| Build | .NET Framework 4.8; reproduzierbare Release-Artefakte | `success` |
| Dependencies | direkte Assemblyreferenzen nur `System` und `System.Data` | `success` |
| Trust | exakter SHA2-512-Hash; getrenntes administratives Opt-in | `success` |
| Security | `SAFE`; kein Dateisystem, Netzwerk, Prozess, `TRUSTWORTHY`, `EXTERNAL_ACCESS` oder `UNSAFE` | `success` |
| API | öffentliche Procedure behält Parameter, Reihenfolge und Resultset | `success` |
| Listing API | Metadaten-Procedure behält Parameter, Reihenfolge und Resultset | `success` |
| Intern | CLR-Tabellefunktion und Assembly bleiben interne Providerartefakte | `success` |
| Help | vollständiger Help-Vertrag bei `@Hilfe = 1` | `success` |
| Stored | gültiger Method-0-Entry wird extrahiert und CRC-geprüft | `success` |
| Deflate | gültiger Method-8-Entry wird dekomprimiert und CRC-geprüft | `success` |
| Data Descriptor | Method 8 mit Flag 3 und nachgelagertem Descriptor | `success` |
| UTF-8 | Flag 11 dekodiert UTF-8-Namen korrekt | `success` |
| CP437 | Name ohne Flag 11 verwendet CP437 | `success` |
| Namensvergleich | ordinal, case-sensitive, unbekannter Name liefert `51322` | `success` |
| Duplicate Name | doppelter exakter Name liefert `51323` | `success` |
| Verschlüsselt | `@FailIfEncrypted = 1` liefert `51324` | `success` |
| Encrypted Status | `@FailIfEncrypted = 0` liefert `IsEncrypted = 1` ohne Payload | `success` |
| Archivlimit | hartes Limit `268435456` Bytes | `not executed` |
| Entry-Count | hartes Limit `10000` Entries | `not executed` |
| Compressed Limit | hartes Limit `134217728` Bytes | `not executed` |
| Output-Limit | `@MaxEntryBytes` vor und während Dekomprimierung | `success` |
| Ratio-Limit | deklarierte und tatsächliche Compression Ratio | `success` |
| Method | unbekannte Method und Deflate64 liefern `51327` | `success` |
| ZIP64 | Sentinel oder ZIP64-Strukturen liefern `51327` | `success` |
| Multi-Disk | Diskfelder außerhalb Single-Disk liefern `51327` | `success` |
| Header | Local-/Central-Name, Method und relevante Flags müssen übereinstimmen | `success` |
| Größenintegrität | tatsächliche Ausgabe entspricht deklarierter Größe | `success` |
| CRC | CRC32 wird über den tatsächlichen Payload neu berechnet | `success` |
| Leeres ZIP | gültiges leeres ZIP liefert leeres Resultset und Returncode 0 | `success` |
| Listing | Central-Directory-Reihenfolge und deklarierte Metadaten | `success` |
| Listing Status | unbekannte Methode und Verschlüsselung werden markiert, nicht abgelehnt | `success` |
| Listing Names | ordinal/case-sensitive DuplicateCount; UTF-8 und CP437 | `success` |
| Listing Paths | Directory, safe, absolute, drive-qualified, traversal und noncanonical | `success` |
| Listing Time | gültige DOS-Zeit; ungültiger Wert wird NULL | `success` |
| Bounded Read | Deflate darf keine Bytes außerhalb des Entry-Payloads konsumieren | `success` |
| ResultTable | Replace und Append über `@ResultTable`/`@KeepData` | `success` |
| Wiederholung | Deployment derselben Assembly ist idempotent | `success` |
| Upgrade | Upgrade von bekanntem Modulstand `1.1.0` auf `1.2.0` | `partially validated` |
| Central | Aufruf aus Consumer-Datenbank gegen zentrale Toolbelt-Datenbank | `success` |
| Uninstall | Procedure, CLR-TVF und Assembly entfernt; Trust bleibt bestehen | `success` |
| SQL 2019 Linux | physische Engine, Compatibility 150 | `success` |
| SQL 2022 Linux | physische Engine, Compatibility 160 | `success` |
| SQL 2025 Linux | Compatibility 150, 160 und 170 | `success` |
| Windows Build | .NET-Framework-Build und Release-Manifest | `success` |
| Windows Runtime | SQL Server unter Windows | `not executed` |

`not executed` wird erst durch reproduzierbare CI- oder gezielte Release-Evidenz
ersetzt. `partially validated` beim Upgrade bezeichnet den erfolgreichen
synthetischen Versionsmarker-Pfad ohne vollständiges vorheriges 1.1.0-Deployment.
Einzelne offene Fälle verhindern keine wahrheitsgemäße
`partially validated`-Einstufung des Moduls, bleiben aber vor Release sichtbar.

Evidenz: https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/32701896453

## Aktuelle Validierungsevidenz

<!-- BEGIN GENERATED:MODULE_EVIDENCE -->
- Datum: `2026-10-02`
- Nachweis: `local: Modules/toolbelt.file.xlsx-memory/Tests/Runtime/Invoke-LabContract.ps1`
- Scope: Release 1.4.0: finaler identischer Linux-2019-/Windows-2025-CU8-Adapter nach EOF-Pflege; echte ZIP-1.3-Assemblyhash-Upgradefixture, bestehender Writer-SQL-Vertrag, SAFE local/central und nichtdoomende ZIP-Deploy/Uninstall-Callerablehnung OFF/ON. Unabhängige Framework-Writerregression erneut erfolgreich; übrige Kapazitäts-/Plattformmatrix offen.
- Ergebnis: `success`
<!-- END GENERATED:MODULE_EVIDENCE -->
