-- ============================================================================
-- Contract-Tests für Base64/Base64URL
-- Daten: ausschließlich synthetisch
-- SQLCMD-Variable: CompatibilityLevel=150|160|170
-- ============================================================================

SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

DECLARE @CompatibilityLevel int =
    TRY_CONVERT(int, N'$(CompatibilityLevel)');

IF @CompatibilityLevel NOT IN (150, 160, 170)
BEGIN
    THROW 52300, N'CompatibilityLevel muss 150, 160 oder 170 sein.', 1;
END;

DECLARE @SetCompatibilitySql nvarchar(max) =
    N'ALTER DATABASE '
    + QUOTENAME(DB_NAME())
    + N' SET COMPATIBILITY_LEVEL = '
    + CONVERT(nvarchar(3), @CompatibilityLevel)
    + N';';
EXEC sys.sp_executesql @SetCompatibilitySql;

IF OBJECT_ID(N'toolbelt_conversion.TVF_Base64Encode', N'IF') IS NULL
   OR OBJECT_ID(N'toolbelt_conversion.TVF_Base64Decode', N'IF') IS NULL
   OR OBJECT_ID(N'toolbelt_conversion.SVF_Base64Encode', N'FN') IS NULL
   OR OBJECT_ID(N'toolbelt_conversion.SVF_Base64Decode', N'FN') IS NULL
BEGIN
    THROW 52301, N'Die öffentlichen Base64-Funktionen fehlen.', 1;
END;

DECLARE @DdlHelp TABLE
(
      ObjectName sysname NOT NULL
    , RequiredParameter nvarchar(128) NOT NULL
    , RequiredResult nvarchar(128) NOT NULL
);
INSERT @DdlHelp(ObjectName,RequiredParameter,RequiredResult)
VALUES
      (N'TVF_Base64EncodeStatus',N'@UrlSafe',N'Status varchar(16)')
    , (N'TVF_Base64Encode',N'@UrlSafe',N'EncodedValue')
    , (N'TVF_Base64DecodeStatus',N'@Value varchar(max)',N'Status varchar(16)')
    , (N'TVF_Base64Decode',N'@Value varchar(max)',N'DecodedValue')
    , (N'SVF_Base64Encode',N'@UrlSafe',N'Rückgabe: varchar(max)')
    , (N'SVF_Base64Decode',N'@Value varchar(max)',N'Rückgabe: varbinary(max)');

IF EXISTS
(
    SELECT 1
    FROM @DdlHelp AS expected
    CROSS APPLY
    (
        VALUES
        (
            OBJECT_DEFINITION
            (
                OBJECT_ID(N'toolbelt_conversion.' + QUOTENAME(expected.ObjectName))
            )
        )
    ) AS actual(DefinitionText)
    WHERE actual.DefinitionText IS NULL
       OR CHARINDEX(N'DDL-Hilfe:',actual.DefinitionText)=0
       OR CHARINDEX(N'Parameter:',actual.DefinitionText)=0
       OR CHARINDEX(expected.RequiredParameter,actual.DefinitionText)=0
       OR CHARINDEX(expected.RequiredResult,actual.DefinitionText)=0
       OR CHARINDEX(N'Beispiel:',actual.DefinitionText)=0
)
    THROW 52317, N'Eine öffentliche Funktion enthält keine vollständige DDL-interne Hilfe.', 1;

IF NOT EXISTS
   (
       SELECT 1
       FROM sys.parameters
       WHERE object_id =
             OBJECT_ID(N'toolbelt_conversion.SVF_Base64Encode', N'FN')
         AND parameter_id = 0
         AND TYPE_NAME(user_type_id) = N'varchar'
         AND max_length = -1
   )
   OR NOT EXISTS
   (
       SELECT 1
       FROM sys.parameters
       WHERE object_id =
             OBJECT_ID(N'toolbelt_conversion.SVF_Base64Encode', N'FN')
         AND parameter_id = 1
         AND name = N'@Value'
         AND TYPE_NAME(user_type_id) = N'varbinary'
         AND max_length = -1
   )
   OR NOT EXISTS
   (
       SELECT 1
       FROM sys.parameters
       WHERE object_id =
             OBJECT_ID(N'toolbelt_conversion.SVF_Base64Decode', N'FN')
         AND parameter_id = 0
         AND TYPE_NAME(user_type_id) = N'varbinary'
         AND max_length = -1
   )
   OR NOT EXISTS
   (
       SELECT 1
       FROM sys.parameters
       WHERE object_id =
             OBJECT_ID(N'toolbelt_conversion.SVF_Base64Encode', N'FN')
         AND parameter_id = 2
         AND name = N'@UrlSafe'
         AND TYPE_NAME(user_type_id) = N'bit'
   )
   OR NOT EXISTS
   (
       SELECT 1
       FROM sys.parameters
       WHERE object_id =
             OBJECT_ID(N'toolbelt_conversion.SVF_Base64Decode', N'FN')
         AND parameter_id = 1
         AND name = N'@Value'
         AND TYPE_NAME(user_type_id) = N'varchar'
         AND max_length = -1
   )
   OR OBJECT_DEFINITION
      (
          OBJECT_ID(N'toolbelt_conversion.SVF_Base64Encode', N'FN')
      ) NOT LIKE N'%@UrlSafe bit = 0%'
BEGIN
    THROW 52302, N'Die öffentliche Parametersignatur weicht vom Vertrag ab.', 1;
END;

DECLARE @Vectors TABLE
(
      ItemOrdinal    int            NOT NULL PRIMARY KEY
    , BinaryValue    varbinary(max) NOT NULL
    , StandardBase64 varchar(max)   NOT NULL
);

INSERT INTO @Vectors (ItemOrdinal, BinaryValue, StandardBase64)
VALUES
      (1, 0x,             '')
    , (2, 0x66,           'Zg==')
    , (3, 0x666F,         'Zm8=')
    , (4, 0x666F6F,       'Zm9v')
    , (5, 0x666F6F62,     'Zm9vYg==')
    , (6, 0x666F6F6261,   'Zm9vYmE=')
    , (7, 0x666F6F626172, 'Zm9vYmFy');

-- Die festen positiven Werte einmal aufnehmen; NULL ist kein erfolgreicher Vergleich.
DECLARE @ScalarResults TABLE
(
      ItemOrdinal  int            NOT NULL PRIMARY KEY
    , EncodedValue varchar(max)   NULL
    , DecodedValue varbinary(max) NULL
);

INSERT INTO @ScalarResults (ItemOrdinal, EncodedValue, DecodedValue)
SELECT
      vectors.ItemOrdinal
    , toolbelt_conversion.SVF_Base64Encode(vectors.BinaryValue, DEFAULT)
    , toolbelt_conversion.SVF_Base64Decode(vectors.StandardBase64)
FROM @Vectors AS vectors;

IF EXISTS
   (
       SELECT 1
       FROM @Vectors AS vectors
       JOIN @ScalarResults AS scalarResults
         ON scalarResults.ItemOrdinal = vectors.ItemOrdinal
       WHERE scalarResults.EncodedValue IS NULL
          OR scalarResults.DecodedValue IS NULL
          OR scalarResults.EncodedValue <> vectors.StandardBase64
          OR scalarResults.DecodedValue <> vectors.BinaryValue
   )
BEGIN
    THROW 52303, N'Ein RFC-4648-Standardvektor ist fehlgeschlagen.', 1;
END;

IF toolbelt_conversion.SVF_Base64Encode(NULL, 0) IS NOT NULL
   OR toolbelt_conversion.SVF_Base64Decode(NULL) IS NOT NULL
BEGIN
    THROW 52304, N'NULL wird nicht vertragsgemäß weitergegeben.', 1;
END;

-- Getrennte Aufnahmen erhalten die Vektoridentität auch bei fehlenden TVF-Zeilen.
-- Keine Ergebnistabelle begrenzt Mehrfachzeilen vor dem direkten COUNT je Vektor.
DECLARE @EncodeResults TABLE
(
      ItemOrdinal  int          NOT NULL
    , EncodedValue varchar(max) NULL
);
DECLARE @DecodeResults TABLE
(
      ItemOrdinal  int            NOT NULL
    , DecodedValue varbinary(max) NULL
);

INSERT INTO @EncodeResults (ItemOrdinal, EncodedValue)
SELECT vectors.ItemOrdinal, encoded.EncodedValue
FROM @Vectors AS vectors
CROSS APPLY toolbelt_conversion.TVF_Base64Encode
            (
                  vectors.BinaryValue
                , DEFAULT
            ) AS encoded;

INSERT INTO @DecodeResults (ItemOrdinal, DecodedValue)
SELECT encoded.ItemOrdinal, decoded.DecodedValue
FROM @EncodeResults AS encoded
CROSS APPLY toolbelt_conversion.TVF_Base64Decode
            (
                encoded.EncodedValue
            ) AS decoded;

IF EXISTS
   (
       SELECT 1
       FROM @Vectors AS vectors
       WHERE (SELECT COUNT_BIG(*)
              FROM @EncodeResults AS encoded
              WHERE encoded.ItemOrdinal = vectors.ItemOrdinal) <> 1
          OR (SELECT COUNT_BIG(*)
              FROM @DecodeResults AS decoded
              WHERE decoded.ItemOrdinal = vectors.ItemOrdinal) <> 1
   )
   OR EXISTS
      (
          SELECT 1
          FROM @Vectors AS vectors
          JOIN @ScalarResults AS scalarResults
            ON scalarResults.ItemOrdinal = vectors.ItemOrdinal
          JOIN @EncodeResults AS encoded
            ON encoded.ItemOrdinal = vectors.ItemOrdinal
          WHERE encoded.EncodedValue IS NULL
             OR encoded.EncodedValue <> vectors.StandardBase64
             OR encoded.EncodedValue <> scalarResults.EncodedValue
      )
   OR EXISTS
      (
          SELECT 1
          FROM @Vectors AS vectors
          JOIN @ScalarResults AS scalarResults
            ON scalarResults.ItemOrdinal = vectors.ItemOrdinal
          JOIN @DecodeResults AS decoded
            ON decoded.ItemOrdinal = vectors.ItemOrdinal
          WHERE decoded.DecodedValue IS NULL
             OR decoded.DecodedValue <> vectors.BinaryValue
             OR decoded.DecodedValue <> scalarResults.DecodedValue
      )
BEGIN
    THROW 52313, N'Die SVF-/inline-TVF-Parität ist fehlgeschlagen.', 1;
END;

IF (SELECT COUNT(*) FROM toolbelt_conversion.TVF_Base64Encode(NULL, 0)) <> 1
   OR EXISTS
      (
          SELECT 1
          FROM toolbelt_conversion.TVF_Base64Encode(NULL, 0)
          WHERE EncodedValue IS NOT NULL
      )
   OR (SELECT COUNT(*) FROM toolbelt_conversion.TVF_Base64Decode(NULL)) <> 1
   OR EXISTS
      (
          SELECT 1
          FROM toolbelt_conversion.TVF_Base64Decode(NULL)
          WHERE DecodedValue IS NOT NULL
      )
BEGIN
    THROW 52314, N'Der einzeilige NULL-Vertrag der inline TVFs ist fehlgeschlagen.', 1;
END;

DECLARE @ApplyInput TABLE
(
      ItemOrdinal int NOT NULL PRIMARY KEY
    , BinaryValue varbinary(max) NULL
);
INSERT INTO @ApplyInput (ItemOrdinal, BinaryValue)
VALUES (1, 0xCAFECAFE), (2, NULL);

IF (SELECT COUNT(*)
    FROM @ApplyInput AS source
    OUTER APPLY toolbelt_conversion.TVF_Base64Encode
                (
                      source.BinaryValue
                    , 1
                ) AS encoded) <> 2
BEGIN
    THROW 52315, N'OUTER APPLY erhält die äußeren Zeilen nicht vollständig.', 1;
END;

IF toolbelt_conversion.SVF_Base64Encode(0xCAFECAFE, 0) <> 'yv7K/g=='
   OR toolbelt_conversion.SVF_Base64Encode(0xCAFECAFE, 1) <> 'yv7K_g'
   OR toolbelt_conversion.SVF_Base64Decode('yv7K/g==') <> 0xCAFECAFE
   OR toolbelt_conversion.SVF_Base64Decode('yv7K/g') <> 0xCAFECAFE
   OR toolbelt_conversion.SVF_Base64Decode('yv7K_g') <> 0xCAFECAFE
BEGIN
    THROW 52305, N'Alphabet- oder Paddingvertrag ist fehlgeschlagen.', 1;
END;

DECLARE @WhitespaceValue varchar(max) =
    CHAR(32) + 'yv' + CHAR(9) + '7K' + CHAR(13) + '/' + CHAR(10) + 'g==';

IF toolbelt_conversion.SVF_Base64Decode(@WhitespaceValue) <> 0xCAFECAFE
BEGIN
    THROW 52306, N'Der freigegebene Whitespace-Vertrag ist fehlgeschlagen.', 1;
END;

DECLARE @ExpectedErrorObserved bit;

SET @ExpectedErrorObserved = 0;
BEGIN TRY
    DECLARE @InvalidCharacter varbinary(max) =
        toolbelt_conversion.SVF_Base64Decode('qQ!!');
    IF @InvalidCharacter IS NULL
        SET @ExpectedErrorObserved = 0;
END TRY
BEGIN CATCH
    SET @ExpectedErrorObserved = 1;
END CATCH;
IF @ExpectedErrorObserved = 0
BEGIN
    THROW 52307, N'Ein ungültiges Zeichen wurde akzeptiert.', 1;
END;

SET @ExpectedErrorObserved = 0;
BEGIN TRY
    DECLARE @InvalidLength varbinary(max) =
        toolbelt_conversion.SVF_Base64Decode('A');
    IF @InvalidLength IS NULL
        SET @ExpectedErrorObserved = 0;
END TRY
BEGIN CATCH
    SET @ExpectedErrorObserved = 1;
END CATCH;
IF @ExpectedErrorObserved = 0
BEGIN
    THROW 52308, N'Eine ungültige Base64-Länge wurde akzeptiert.', 1;
END;

SET @ExpectedErrorObserved = 0;
BEGIN TRY
    DECLARE @InvalidPadding varbinary(max) =
        toolbelt_conversion.SVF_Base64Decode('qQ===A');
    IF @InvalidPadding IS NULL
        SET @ExpectedErrorObserved = 0;
END TRY
BEGIN CATCH
    SET @ExpectedErrorObserved = 1;
END CATCH;
IF @ExpectedErrorObserved = 0
BEGIN
    THROW 52309, N'Ungültiges Padding wurde akzeptiert.', 1;
END;

SET @ExpectedErrorObserved = 0;
BEGIN TRY
    DECLARE @InvalidWhitespace varbinary(max) =
        toolbelt_conversion.SVF_Base64Decode('q' + CHAR(11) + 'Q==');
    IF @InvalidWhitespace IS NULL
        SET @ExpectedErrorObserved = 0;
END TRY
BEGIN CATCH
    SET @ExpectedErrorObserved = 1;
END CATCH;
IF @ExpectedErrorObserved = 0
BEGIN
    THROW 52310, N'Nicht freigegebener Whitespace wurde akzeptiert.', 1;
END;

SET @ExpectedErrorObserved = 0;
BEGIN TRY
    DECLARE @InvalidTvfResult varbinary(max);

    SELECT @InvalidTvfResult = decoded.DecodedValue
    FROM toolbelt_conversion.TVF_Base64Decode('qQ!!') AS decoded;

    IF @InvalidTvfResult IS NULL
        SET @ExpectedErrorObserved = 0;
END TRY
BEGIN CATCH
    SET @ExpectedErrorObserved = 1;
END CATCH;
IF @ExpectedErrorObserved = 0
BEGIN
    THROW 52316, N'Der inline-TVF-Pfad akzeptierte ein ungültiges Zeichen.', 1;
END;

DECLARE @Sizes TABLE
(
    ByteCount int NOT NULL PRIMARY KEY
);

INSERT INTO @Sizes (ByteCount)
VALUES (6000), (6001), (65536), (1048576);

DECLARE
      @ByteCount    int
    , @Synthetic    varbinary(max)
    , @Encoded      varchar(max)
    , @Decoded      varbinary(max);

DECLARE SizeCursor CURSOR LOCAL FAST_FORWARD
FOR SELECT ByteCount FROM @Sizes ORDER BY ByteCount;

OPEN SizeCursor;
FETCH NEXT FROM SizeCursor INTO @ByteCount;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @Synthetic = CONVERT
    (
          varbinary(max)
        , REPLICATE(CONVERT(varchar(max), 'A'), @ByteCount)
    );
    SELECT @Encoded = encoded.EncodedValue
    FROM toolbelt_conversion.TVF_Base64Encode(@Synthetic, 0) AS encoded;

    SELECT @Decoded = decoded.DecodedValue
    FROM toolbelt_conversion.TVF_Base64Decode(@Encoded) AS decoded;

    IF DATALENGTH(@Synthetic) <> @ByteCount
       OR DATALENGTH(@Decoded) <> @ByteCount
       OR @Decoded <> @Synthetic
       OR
          (
              @ByteCount <= 6001
              AND
              (
                  toolbelt_conversion.SVF_Base64Encode(@Synthetic, 0)
                      <> @Encoded
                  OR toolbelt_conversion.SVF_Base64Decode(@Encoded)
                      <> @Decoded
              )
          )
    BEGIN
        CLOSE SizeCursor;
        DEALLOCATE SizeCursor;
        THROW 52311, N'Ein synthetischer TVF-Größen-Roundtrip oder die SVF-Parität ist fehlgeschlagen.', 1;
    END;

    FETCH NEXT FROM SizeCursor INTO @ByteCount;
END;

CLOSE SizeCursor;
DEALLOCATE SizeCursor;

/*
 * Native SQL-Server-2025-Funktionen werden dynamisch kompiliert, damit der
 * portable Modulcode selbst keine Versionsabhängigkeit erhält.
 */
DECLARE
      @ReferenceValue varbinary(max) = 0xCAFECAFE
    , @NativeStandard varchar(max)
    , @NativeUrlSafe  varchar(max)
    , @NativeDecoded  varbinary(max);

IF TRY_CONVERT(int, SERVERPROPERTY('ProductMajorVersion')) >= 17
BEGIN
    EXEC sys.sp_executesql
          N'SELECT
                  @Standard = BASE64_ENCODE(@Value, 0),
                  @UrlSafe = BASE64_ENCODE(@Value, 1);'
        , N'@Value varbinary(max), @Standard varchar(max) OUTPUT, @UrlSafe varchar(max) OUTPUT'
        , @Value = @ReferenceValue
        , @Standard = @NativeStandard OUTPUT
        , @UrlSafe = @NativeUrlSafe OUTPUT;

    EXEC sys.sp_executesql
          N'SELECT @Decoded = BASE64_DECODE(@Value);'
        , N'@Value varchar(max), @Decoded varbinary(max) OUTPUT'
        , @Value = @NativeUrlSafe
        , @Decoded = @NativeDecoded OUTPUT;

    IF @NativeStandard <>
           toolbelt_conversion.SVF_Base64Encode(@ReferenceValue, 0)
       OR @NativeUrlSafe <>
           toolbelt_conversion.SVF_Base64Encode(@ReferenceValue, 1)
       OR @NativeDecoded <> @ReferenceValue
    BEGIN
        THROW 52312, N'Die semantische Parität zum nativen SQL-Server-2025-Provider ist fehlgeschlagen.', 1;
    END;
END;

PRINT N'Base64 Contract-Tests für Compatibility Level '
    + CONVERT(nvarchar(3), @CompatibilityLevel)
    + N': erfolgreich';
GO
