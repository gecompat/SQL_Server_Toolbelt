## Scope

<!-- Welche Module, Schemas, Objekte oder Standards sind betroffen? -->

## Auftrag und Freigabe

<!-- Arbeitspaket-ID oder ausdrücklicher unmittelbarer Benutzerauftrag -->

## Betroffene Verträge

<!-- Parameter, Resultsets, Help, Fehler, Manifest, Deployment oder andere Verträge -->

## Dokumentation

- [ ] Gekoppelte Dokumentationsdateien aktualisiert.
- [ ] Modulmanifest enthält alle gekoppelten Dokumentationspfade und Contract-Versionen.
- [ ] Generierte Statusabschnitte sind aktuell.
- [ ] Relative Links und Dateipfade geprüft.
- [ ] Objekttypspezifische Vorlage verwendet.
- [ ] Beispiele für neue/geänderte öffentliche SQL-Objekte mit Voraussetzungen und Ergebnisdeutung gemäß [Dokumentationsstandard](https://github.com/gecompat/SQL_Server_Toolbelt/blob/main/Documentation/Standards/CODE_DOCUMENTATION.md#objektreferenz-und-beispiele) geprüft.
- [ ] Bei nicht trivialer Funktionalität Implementierungsweg und Designgründe am aktuellen Code erklärt; bestehende technische Erklärungen bei Algorithmusänderungen mitgepflegt.
- [ ] Jeden einzelnen Parameter auf Eingabeform, Grenzen, Default/NULL und Abhängigkeiten geprüft; sämtliche festen erlaubten Werte taxativ gelistet und einzeln beschrieben.

## Tests und Evidenz

Ausgeführte Prüfungen:

<!-- Je Prüfung: Befehl/Tool/Workflow, Scope, Version/Plattform/Provider, Datum, Ergebnis, Einschränkungen -->

- [ ] Inkrementellen Change-Impact-Validator ausgeführt.
- [ ] Vollaudit ausgeführt oder gemäß Repo-Map nicht erforderlich.

Nicht ausgeführte oder nicht anwendbare Prüfungen:

<!-- Mit Grund und Auswirkung; not applicable nur mit Capability-Begründung -->

- [ ] Keine nicht ausgeführte Prüfung als bestanden oder `validated` dargestellt.

## Datenschutz und Secrets

- [ ] Keine personenbezogenen/sensiblen oder internen/vertraulichen Informationen enthalten.
- [ ] Keine Original-Tabelleninhalte, nicht öffentlichen Infrastrukturangaben, realen Runtime-Ausgaben, Logs, Traces oder Execution Plans übernommen.
- [ ] Keine konkreten Hardware-, Kapazitäts-, Inventar- oder Umgebungswerte von Remote Runnern übernommen.
- [ ] Keine Secrets oder privaten Schlüssel enthalten.
- [ ] Öffentliche Organisations-/Projektnamen und Links sind fachlich relevant; `gecompat` und `Gerhard Pisch` sind ausdrücklich zulässig.
- [ ] Datenschutz-Stop-Gate aus `AGENTS.md` geprüft.

## Lizenz

- [ ] Geschützter Lizenzblock am Anfang der README unverändert.
- [ ] `LICENSE.md` unverändert, sofern keine ausdrückliche Lizenzänderung beauftragt wurde.

## Breaking Changes und Migration

<!-- Nein oder Beschreibung mit Migrationspfad -->

## Backlog, Entscheidungen und Status

- [ ] `.ai/BACKLOG.md`, Roadmap oder Changelog bei Bedarf aktualisiert.
- [ ] Dauerhafte Entscheidungen in `Documentation/Architecture/DECISIONS.md` dokumentiert.
- [ ] Status entspricht der tatsächlich vorhandenen Evidenz.

## Abschluss

- [ ] Vollständigen Branch-Diff geprüft.
- [ ] Keine unabhängigen Änderungen aufgenommen.
- [ ] Arbeitsbranch kann nach dem Merge gelöscht werden.
