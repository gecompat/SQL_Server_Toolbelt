# Öffentlicher Beispielkatalog

## Einzelne SQL-Objekte nachschlagen

Suche im [API-Katalog](API_CATALOG.md) nach dem vollständigen Objektnamen
oder verwende die [durchsuchbare HTML-Ansicht](API_CATALOG.html).
Unter „Vertrag und Quelle“ führt der Markdown-Link mit dem Objektnamen
zur eigenen Beschreibung unter `Modules/<Modul>/Documentation/`.
Dort stehen Verhalten, Aufrufparameter, Voraussetzungen und Beispiele;
gemeinsame Regeln bleiben über die verlinkten Fachverträge erreichbar.
Die SQL-Datei daneben dient der Prüfung der Implementierung.

Bei der Ergebnisdeutung insbesondere SQL-NULL, leere Ergebnismengen und
Statuswerte unterscheiden. Bei Prozeduren erklärt `@Hilfe=1` Parameter,
Ergebnisse und Fehler. Für Installation, Rechte und tatsächlich ausgeführte
Plattformtests der verlinkten Modulbeschreibung und Testmatrix folgen.
Die vollständigen Parametertexte entsprechen den Objektseiten; dafür ist der
[gemeinsame aktuelle Installationsstand](../../INSTALL.md)
erforderlich. Ein älteres installiertes Paket aktualisiert seine Hilfe nicht
durch den Besuch dieser Referenz.
Ein Beispiel mit registrierten Handlern, Claims oder Dateien setzt die dort
beschriebene Vorbereitung voraus.

## Den Implementierungsweg verstehen

Die [technischen Lösungswege](IMPLEMENTATION_GUIDE.md) erläutern ausgewählte
Algorithmen, Zustände und SQL-/CLR-Entscheidungen. Sie beantworten etwa,
warum ein Scanner mehrfach läuft, welche Zustände eine Schleife erhält und
weshalb eine einfachere Alternative den Vertrag verletzen würde. Die
betroffenen Objektseiten führen direkt zum passenden Abschnitt und von
dort zu den zuständigen Quelldateien. Gewöhnliche SQL-Syntax wird dort
nicht erneut als Grundlagenkurs erklärt.

## Beispiele finden

Der [Beispielkatalog](API_CATALOG.md) zeigt alle öffentlichen aufrufbaren
Objekte: Views, Stored Procedures, T-SQL-/CLR-Funktionen und CLR-Aggregate.
Er enthält kurze Erklärungen, Parameter mit SQL-Typ, Default und Richtung,
synthetische Aufrufe, Voraussetzungen und Links zu den bestehenden Verträgen.
Tabellen, Assemblies und interne Helfer sind keine Aufrufoberfläche.

Die Parametertabellen erklären jeden einzelnen Parameter: Datenform,
fachliche Pflicht, Grenzen und Einheiten, Default, explizites NULL und
Abhängigkeiten. Feste Wertemengen werden vollständig mit der Bedeutung jedes
Werts aufgelistet; dynamische Namen haben Auswahl- und Beschaffungsregeln.
Auch Unterschiede zwischen gleich benannten Parametern werden geprüft.
Gefundene Implementierungsgrenzen werden als solche beschrieben, nicht durch
eine Dokumentationsänderung als behoben dargestellt.

Die [HTML-Ansicht](API_CATALOG.html) lässt sich nach dem Entpacken lokal im Browser
durchsuchen. Auf GitHub wird HTML als Quelldatei angezeigt; dort den
[Markdown-Katalog](API_CATALOG.md) verwenden. Die HTML-Seite ist eine Suchhilfe,
kein vollständiger Markdown-Renderer: ihre Objektlinks führen zu den jeweiligen
Markdown-Dateien, die ein geeigneter Viewer oder die GitHub-Dateiansicht darstellt.
Die [SQL-Beispielsammlung](API_EXAMPLES.sql) enthält einzeln auswählbare,
auskommentierte Beispiele. Sie legt keine Zieldatenbank fest. Beispiele mit
Dateien, Handlern, Claims oder Plan-Hashes benötigen ihre beschriebenen
Voraussetzungen und können Zustände verändern. Nicht gesammelt ausführen.

## Quellen und Pflege

- `Modules/*/module.yaml` bestimmt Umfang, Sichtbarkeit, Typ und Modulversion.
- `Modules/*/Source/*.sql` liefert Parameterreihenfolge, SQL-Typen, Defaults
  und OUTPUT. Auch dynamisch deklarierte CLR-Aggregate werden berücksichtigt.
- [api_examples.json](api_examples.json) enthält die redaktionellen
  Kurzbeschreibungen, quellgeprüften Parametererklärungen, synthetischen Beispiele
  und Voraussetzungen je API. Die Parametererklärungen werden auch in die
  markierten `API_PARAMETERS`-Blöcke der Objektseiten geschrieben; diese Blöcke
  nicht separat bearbeiten.
- [usp_help.json](usp_help.json) enthält zusätzliche Required-/Nullable-Metadaten
  und die übrigen Help-Abschnitte der T-SQL-Prozeduren. Parameterbeschreibungen
  werden darin nicht dupliziert. Signaturen und diese Metadaten müssen dieselbe
  Parametermenge besitzen; neue oder entfernte Parameter stoppen den Build.
- [`generate_parameter_help.py`](../../Scripts/Documentation/generate_parameter_help.py)
  schreibt die markierten `API_PARAMETER_HELP`-Blöcke. Der
  [SSIS-Generator](../../Modules/toolbelt.tsql.ssis-debug/Scripts/New-ContractSources.py)
  übernimmt dieselben Texte in API-Projektion, Fassade und interne CLR-Hilfe.
- Modullokale Objektseiten bleiben die verbindlichen fachlichen Verträge,
  insbesondere für zulässige Parameterwerte, Resultsets und Grenzen.

Der Katalog ersetzt keine Objektseite und behauptet keine Runtime-Validierung.
Er wird ausschließlich offline aus Repositoryquellen erzeugt. Zugangsdaten,
installierte SQL-Kataloge und reale Ausgaben werden nicht eingelesen.

Bei einer neuen oder entfernten öffentlichen API muss die Beispielregistry
mitgepflegt werden. Jeder Source-Parameter benötigt eine passende Erklärung;
neue oder entfernte Parameter stoppen die Prüfung bis zur redaktionellen Pflege.
Bei Vertragsänderungen sind Beschreibung, Beispiele und
Voraussetzungen fachlich zu prüfen; der Generator kann diese semantische
Prüfung nicht übernehmen. Die drei Katalogausgabedateien und die markierten
Parametertabellen nicht direkt bearbeiten; übrige Objektabschnitte bleiben manuell.

SQL-Typbindung erfolgt vor der Objektvalidierung. Beispielsweise kann SQL Server
einen numerischen Nichtnullwert beim Binden an `bit` bereits in 1 umwandeln;
eine begrenzte Textparameterlänge ist keine nachträgliche Trunkierungsprüfung
im Objekt. `nvarchar(n)` zählt UTF-16-Einheiten, `varchar(n)` Bytes, nicht
pauschal sichtbare Zeichen. Weiterführend:
[bit-Konvertierung](https://learn.microsoft.com/en-us/sql/t-sql/data-types/bit-transact-sql),
[Unicode-Längen](https://learn.microsoft.com/en-us/sql/t-sql/data-types/nchar-and-nvarchar-transact-sql),
[varchar-Längen](https://learn.microsoft.com/en-us/sql/t-sql/data-types/char-and-varchar-transact-sql).

Vom Repository-Root aus generieren und anschließend prüfen:

```bash
python Scripts/Documentation/generate_parameter_help.py --write
python Modules/toolbelt.tsql.ssis-debug/Scripts/New-ContractSources.py
python Tests/Documentation/generate_api_catalog.py --write
python Tests/Documentation/generate_api_catalog.py
python Tests/Documentation/test_api_catalog.py
python Tests/Documentation/test_parameter_help.py
```

Nach einer Änderung der SSIS-Hilfekonstante muss die DLL neu gebaut werden;
eine reine SQL-Neuerzeugung genügt dort nicht. Der
[Nachweis der ursprünglichen Help-Paketierung](../../Releases/1.0.0/PARAMETER-HELP.md#erzeugung-und-nachweisgrenze)
erklärt Paketkopplung und Nachweisgrenzen. Der Generator castet lange Unicode-
Texte bereits beim ersten Literal auf `nvarchar(max)`: Ein Cast erst nach der
Verkettung würde eine vorherige 4000-Codeeinheiten-Trunkierung nicht rückgängig
machen. Zur Laufzeit werden die statischen Zeilen ausgegeben, keine externen
Dokumentationsdateien gelesen.

Die [Prüfmatrix der vollständigen Parameterhilfe](../../Tests/Release/ParameterHelp.md)
erklärt die tatsächlichen Installations- und Help-Laufzeittests sowie deren
Grenzen. Damit lassen sich Referenztext, Generator, installierter Hilfetext
und zugehöriger Nachweis durchgehend verfolgen.

Die Ausgabe ist deterministisch. Die Read-only-Prüfung erkennt fehlende oder
veraltete API-Einträge, unbekannte öffentliche Typen, mehrdeutige Quellen und
abweichende generierte Dateien. Source-/Vertragsfingerprints erkennen auch
Änderungen ohne sichtbare Signaturänderung. LF und CRLF werden gleich behandelt.
Die bestehende Dokumentations-CI führt Prüfung und Regressionstests über das
Impact-Paket `public_api_catalog` in der Repo-Map aus; ein Vollaudit prüft sie
ebenfalls. Geänderte Quellen und die neu generierten Dateien gemeinsam committen.

Historische Release-Nachweise behalten ihre ursprünglichen Texte und Pins.
Die [begrenzte Parameterprojektion](../../Scripts/Release/HistoricalSources/parameter-contracts-20261030/README.md)
ergänzt dafür den bestehenden historischen Prüfweg. Sie akzeptiert nur die
kanonisch generierte Parametertabelle bei unverändertem übrigen Text.
Quellgeprüfte neue Erklärungen sind dadurch keine neue native Runtimequalifikation.
