:ON ERROR EXIT
-- Nur nach Prüfung aller externen Consumer; Trust bleibt erhalten.
:On Error exit
-- Nichtdoomender Caller-Gate vor SET und sämtlichen Mutationen.
IF @@TRANCOUNT<>0
BEGIN
 RAISERROR(N'TBX_XLSX_LIFECYCLE_CALLER_TRANSACTION: Uninstall benötigt einen eigenen Transaktionsscope.',16,1);
 RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @Confirm bit=TRY_CONVERT(bit,N'1'),@Version nvarchar(max),
 @InstalledMode nvarchar(max),@AssemblyId int,@Installed bit,@Release int,@Phase int=0,@ProtectFuture bit=0;
DECLARE @Slots TABLE(Name sysname COLLATE DATABASE_DEFAULT NOT NULL,Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL,FirstRelease int NOT NULL,Class nvarchar(128) NULL,Method nvarchar(128) NULL);
INSERT @Slots VALUES
 (N'USP_ListXlsxWorksheets','P',10,NULL,NULL),
 (N'USP_ReadXlsxWorksheetCells','P',10,NULL,NULL),
 (N'USP_InternalXlsxRead','P',10,NULL,NULL),
 (N'TVF_InternalXlsxSheets','FT',10,N'Toolbelt.Xlsx.Qualification.XlsxEntryPoints',N'ListSheets'),
 (N'TVF_InternalXlsxCells','FT',10,N'Toolbelt.Xlsx.Qualification.XlsxEntryPoints',N'ReadCells'),
 (N'TVF_InternalInterpretXlsxCell','FT',11,N'Toolbelt.Xlsx.Qualification.XlsxCellType',N'Interpret'),
 (N'TVF_InterpretXlsxCell','IF',11,NULL,NULL),
 (N'TVF_InternalFormatXlsxCell','FT',12,N'Toolbelt.Xlsx.Qualification.XlsxCellDisplayBridge',N'Evaluate'),
 (N'TVF_FormatXlsxCell','IF',12,NULL,NULL);
DECLARE @Own TABLE(Id int NOT NULL PRIMARY KEY);
BEGIN TRY
 WHILE @Phase<2
 BEGIN
  -- Benutzerfreigabe 2026-10-02: vollständige Consumersicht vor Mutation,
  -- im zweiten Durchlauf erneut unter demselben Transaktions-AppLock.
  IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
   OR ISNULL(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
   THROW 51535,N'Vollständige Sicht auf SQL-Abhängigkeiten ist erforderlich.',2;
-- Keine Hashgleichheit ersetzt die bekannte Release-/Slotidentität.
SELECT @Version=NULL,@Installed=0,@InstalledMode=NULL,@AssemblyId=NULL;
SELECT @Version=TRY_CONVERT(nvarchar(max),value),@Installed=1 FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.Version';
SELECT @InstalledMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode';
IF @Installed=1 AND (@Version IS NULL OR CONVERT(varbinary(max),@Version) NOT IN
 (CONVERT(varbinary(max),N'1.0.0'),CONVERT(varbinary(max),N'1.1.0'),CONVERT(varbinary(max),N'1.2.0')))
 THROW 51534,N'Unbekannter oder inkohärenter XLSX-Release.',1;
IF (@Installed=1 AND (@InstalledMode IS NULL OR CONVERT(varbinary(max),@InstalledMode) NOT IN
 (CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))))
 OR (@Installed=0 AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode'))
 THROW 51534,N'Unbekannter oder inkohärenter XLSX-Modus.',1;
SET @Release=CASE CONVERT(varbinary(max),@Version) WHEN CONVERT(varbinary(max),N'1.0.0') THEN 10 WHEN CONVERT(varbinary(max),N'1.1.0') THEN 11 WHEN CONVERT(varbinary(max),N'1.2.0') THEN 12 ELSE 0 END;
SELECT @AssemblyId=assembly_id FROM sys.assemblies WHERE name=N'Toolbelt_File_XlsxMemory';
IF (@Installed=1 AND @AssemblyId IS NULL) OR (@Installed=0 AND @AssemblyId IS NOT NULL)
 OR (@AssemblyId IS NOT NULL AND (NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@AssemblyId AND permission_set=1
  AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_File_XlsxMemory'))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND name=N'Toolbelt.ModuleId'
 AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.file.xlsx-memory'))))
 THROW 51534,N'Fremde oder inkohärente XLSX-Assembly.',1;
IF EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(s.Name))
 WHERE (@Installed=1 AND s.FirstRelease<=@Release AND
  (o.object_id IS NULL OR CONVERT(varbinary(max),o.name)<>CONVERT(varbinary(max),s.Name)
   OR CONVERT(varbinary(max),o.type)<>CONVERT(varbinary(max),s.Kind)
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleId'
      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.file.xlsx-memory'))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleVersion'
      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Version))
   OR (s.Kind='FT' AND NOT EXISTS(SELECT 1 FROM sys.assembly_modules m WHERE m.object_id=o.object_id AND m.assembly_id=@AssemblyId
      AND CONVERT(varbinary(max),m.assembly_class)=CONVERT(varbinary(max),s.Class)
      AND CONVERT(varbinary(max),m.assembly_method)=CONVERT(varbinary(max),s.Method)))))
  OR ((@Installed=0 OR s.FirstRelease>@Release) AND o.object_id IS NOT NULL AND @ProtectFuture=1))
 THROW 51534,N'XLSX-Slot, Typ oder Eigentumsmarker ist nicht der bekannte Release.',1;
DELETE FROM @Own;
INSERT @Own SELECT OBJECT_ID(N'toolbelt_file.'+QUOTENAME(Name)) FROM @Slots WHERE FirstRelease<=@Release;
IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@AssemblyId AND object_id NOT IN(SELECT Id FROM @Own))
 OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@AssemblyId)
 THROW 51535,N'Fremder Assemblyconsumer blockiert XLSX-Lifecycle.',1;

  IF @Installed=0
  BEGIN
   IF @Phase=0 RETURN;
   THROW 51534,N'XLSX-Release änderte sich während des Preflights.',1;
  END;
  IF @Confirm IS NULL OR (@InstalledMode=N'central' AND @Confirm<>1)
   THROW 51536,N'Zentraler Uninstall benötigt ConfirmNoExternalConsumers=1.',1;
  IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies WHERE referenced_id IN(SELECT Id FROM @Own) AND referencing_id NOT IN(SELECT Id FROM @Own))
   THROW 51535,N'Fremder XLSX-Consumer blockiert Uninstall.',1;
  IF @Phase=0
  BEGIN
   BEGIN TRANSACTION;
   DECLARE @Lock int;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.file.xlsx-memory',
    @LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock<0 THROW 51533,N'Paralleler XLSX-Lifecycle aktiv.',1;
  END;
  SET @Phase+=1;
 END;
 IF @Release>=12
 BEGIN
  DROP FUNCTION toolbelt_file.TVF_FormatXlsxCell;
  DROP FUNCTION toolbelt_file.TVF_InternalFormatXlsxCell;
 END;
 IF @Release>=11
 BEGIN
  DROP FUNCTION toolbelt_file.TVF_InterpretXlsxCell;
  DROP FUNCTION toolbelt_file.TVF_InternalInterpretXlsxCell;
 END;
 DROP PROCEDURE toolbelt_file.USP_ListXlsxWorksheets;
 DROP PROCEDURE toolbelt_file.USP_ReadXlsxWorksheetCells;
 DROP PROCEDURE toolbelt_file.USP_InternalXlsxRead;
 DROP FUNCTION toolbelt_file.TVF_InternalXlsxSheets;
 DROP FUNCTION toolbelt_file.TVF_InternalXlsxCells;
 DROP ASSEMBLY Toolbelt_File_XlsxMemory;
 EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.Version';
 EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode';
 IF SCHEMA_ID(N'toolbelt_file') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.objects WHERE schema_id=SCHEMA_ID(N'toolbelt_file'))
  AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=SCHEMA_ID(N'toolbelt_file') AND name=N'Toolbelt.Managed' AND TRY_CONVERT(bit,value)=1)
  EXEC(N'DROP SCHEMA toolbelt_file');
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
-- Kanonische Dependencies und instanzweiter Trust bleiben erhalten.

GO
:On Error exit
-- RAISERROR statt THROW: Caller-Transaktionen bei XACT_ABORT ON nicht beschädigen.
IF @@TRANCOUNT<>0
BEGIN
    RAISERROR(N'TBX_ZIP_LIFECYCLE_CALLER_TRANSACTION: Uninstall benötigt einen eigenen Transaktionsscope.',16,1);
    RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @ConfirmNoExternalConsumers bit =
          TRY_CONVERT(bit, N'1')
    , @VersionProperty sysname =
          N'Toolbelt.Module.toolbelt.archive.zip-memory.Version'
    , @ModeProperty sysname =
          N'Toolbelt.Module.toolbelt.archive.zip-memory.DeploymentMode'
    , @DeploymentMode nvarchar(16)
    , @ExtractPublicObjectId int =
          OBJECT_ID(N'toolbelt_archive.USP_ExtractZipEntryFromBinary')
    , @ListPublicObjectId int =
          OBJECT_ID(N'toolbelt_archive.USP_ListZipEntriesFromBinary')
    , @ExtractInternalObjectId int =
          OBJECT_ID(N'toolbelt_archive.TVF_InternalExtractZipEntryClr')
    , @ListInternalObjectId int =
          OBJECT_ID(N'toolbelt_archive.TVF_InternalListZipEntriesClr')
    , @AssemblyId int =
          (
              SELECT assembly_id
              FROM sys.assemblies
              WHERE name = N'Toolbelt_Archive_ZipMemory'
          );

IF @ConfirmNoExternalConsumers IS NULL
    THROW 51336, N'ConfirmNoExternalConsumers muss 0 oder 1 sein.', 1;

IF NOT EXISTS
   (
       SELECT 1
       FROM sys.extended_properties
       WHERE class = 0
         AND major_id = 0
         AND minor_id = 0
         AND name = @VersionProperty
   )
    RETURN;

SELECT @DeploymentMode = TRY_CONVERT(nvarchar(16), value)
FROM sys.extended_properties
WHERE class = 0
  AND major_id = 0
  AND minor_id = 0
  AND name = @ModeProperty;

IF @DeploymentMode = N'central'
   AND @ConfirmNoExternalConsumers <> 1
    THROW 51336, N'Bei zentraler Installation ist ConfirmNoExternalConsumers=1 erforderlich.', 1;

DECLARE @InstalledVersion nvarchar(64)=(SELECT TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty);
DECLARE @OwnWriter bit=CASE WHEN @InstalledVersion IN(N'1.3.0',N'1.4.0') THEN 1 ELSE 0 END;
DECLARE @WriterPublicId int=CASE WHEN @OwnWriter=1 THEN OBJECT_ID(N'toolbelt_archive.USP_CreateZipFromEntries') END,
 @WriterNameId int=CASE WHEN @OwnWriter=1 THEN OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterName') END,
 @WriterArchiveId int=CASE WHEN @OwnWriter=1 THEN OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterArchive') END;
IF @OwnWriter=1 AND EXISTS(SELECT 1 FROM sys.objects o WHERE o.object_id IN(@WriterPublicId,@WriterNameId,@WriterArchiveId)
 AND NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE e.class=1 AND e.major_id=o.object_id AND e.minor_id=0 AND e.name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(128),e.value)=N'toolbelt.archive.zip-memory'))
 THROW 51338,N'Writerobjekt besitzt keine passende Modulzuordnung.',3;
IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies WHERE referenced_id IN(@WriterPublicId,@WriterNameId,@WriterArchiveId)
 AND referencing_id NOT IN(ISNULL(@WriterPublicId,-1),ISNULL(@WriterNameId,-1),ISNULL(@WriterArchiveId,-1)))
 THROW 51338,N'Der ZIP-Writer wird durch eine same-database Dependency verwendet.',2;

IF EXISTS
   (
       SELECT 1
       FROM sys.sql_expression_dependencies
       WHERE referenced_id IN
             (
                 ISNULL(@ExtractPublicObjectId, -1),
                 ISNULL(@ListPublicObjectId, -1),
                 ISNULL(@ExtractInternalObjectId, -1),
                 ISNULL(@ListInternalObjectId, -1)
             )
         AND referencing_id NOT IN
             (
                 ISNULL(@ExtractPublicObjectId, -1),
                 ISNULL(@ListPublicObjectId, -1),
                 ISNULL(@ExtractInternalObjectId, -1),
                 ISNULL(@ListInternalObjectId, -1)
             )
   )
    THROW 51338, N'Die Deinstallation wird durch eine same-database Dependency blockiert.', 1;

IF @AssemblyId IS NOT NULL
   AND EXISTS
       (
           SELECT 1
           FROM sys.assembly_modules
           WHERE assembly_id = @AssemblyId
             AND object_id NOT IN
                 (
                     ISNULL(@ExtractInternalObjectId, -1),
                     ISNULL(@ListInternalObjectId, -1),
                     ISNULL(@WriterNameId,-1), ISNULL(@WriterArchiveId,-1)
                 )
       )
    THROW 51338, N'Die CLR-ZIP-Assembly wird von einem fremden SQL-Objekt verwendet.', 1;

IF @AssemblyId IS NOT NULL
   AND EXISTS
       (
           SELECT 1
           FROM sys.assembly_references
           WHERE referenced_assembly_id = @AssemblyId
       )
    THROW 51338, N'Die CLR-ZIP-Assembly wird von einer anderen Assembly referenziert.', 1;

BEGIN TRY
    BEGIN TRANSACTION;
    IF @OwnWriter=1 BEGIN
      DROP PROCEDURE IF EXISTS [toolbelt_archive].[USP_CreateZipFromEntries];
      DROP FUNCTION IF EXISTS [toolbelt_archive].[TVF_InternalZipWriterName];
      DROP FUNCTION IF EXISTS [toolbelt_archive].[TVF_InternalZipWriterArchive];
    END;

    DROP PROCEDURE IF EXISTS
        [toolbelt_archive].[USP_ExtractZipEntryFromBinary];

    DROP PROCEDURE IF EXISTS
        [toolbelt_archive].[USP_ListZipEntriesFromBinary];

    DROP FUNCTION IF EXISTS
        [toolbelt_archive].[TVF_InternalExtractZipEntryClr];

    DROP FUNCTION IF EXISTS
        [toolbelt_archive].[TVF_InternalListZipEntriesClr];

    IF EXISTS
       (
           SELECT 1
           FROM sys.assemblies
           WHERE name = N'Toolbelt_Archive_ZipMemory'
       )
        DROP ASSEMBLY [Toolbelt_Archive_ZipMemory];

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0
             AND major_id = 0
             AND minor_id = 0
             AND name = @VersionProperty
       )
        EXEC sys.sp_dropextendedproperty
              @name = @VersionProperty;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0
             AND major_id = 0
             AND minor_id = 0
             AND name = @ModeProperty
       )
        EXEC sys.sp_dropextendedproperty
              @name = @ModeProperty;

    IF SCHEMA_ID(N'toolbelt_archive') IS NOT NULL
       AND NOT EXISTS
           (
               SELECT 1
               FROM sys.objects
               WHERE schema_id = SCHEMA_ID(N'toolbelt_archive')
           )
       AND EXISTS
           (
               SELECT 1
               FROM sys.extended_properties
               WHERE class = 3
                 AND major_id = SCHEMA_ID(N'toolbelt_archive')
                 AND name = N'Toolbelt.Managed'
                 AND TRY_CONVERT(bit, value) = 1
           )
        DROP SCHEMA [toolbelt_archive];

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/*
 * Der serverweite SHA2-512-Trust-Eintrag bleibt absichtlich bestehen. Seine
 * Entfernung ist ein separater administrativer Vorgang, weil derselbe Hash
 * außerhalb dieser Datenbank verwendet werden kann.
 */

GO
:On Error exit

-- ============================================================================
-- Zweck:     Kontrollierte Deinstallation von Result Table Infrastructure
-- Modul:     toolbelt.core.result-table
-- Modus:     SQLCMD
-- Hinweis:   Bei zentraler Installation muss ConfirmNoExternalConsumers=1
--            ausdrücklich bestätigen, dass keine externen Aufrufer verbleiben.
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @ConfirmNoExternalConsumers bit =
          TRY_CONVERT(bit, N'1')
    , @VersionPropertyName sysname =
          N'Toolbelt.Module.toolbelt.core.result-table.Version'
    , @ModePropertyName sysname =
          N'Toolbelt.Module.toolbelt.core.result-table.DeploymentMode'
    , @InstalledVersion nvarchar(64)
    , @DeploymentMode nvarchar(16)
    , @ProcedureId int
    , @ReferencingSchema sysname
    , @ReferencingObject sysname;

IF @ConfirmNoExternalConsumers IS NULL
BEGIN
    THROW 51035, N'Die SQLCMD-Variable ConfirmNoExternalConsumers muss 0 oder 1 sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

SELECT @DeploymentMode = TRY_CONVERT(nvarchar(16), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @ModePropertyName;

IF @InstalledVersion IS NULL
BEGIN
    PRINT N'toolbelt.core.result-table ist nicht als installiert registriert; keine Änderung erforderlich.';
    RETURN;
END;

IF @InstalledVersion COLLATE Latin1_General_100_BIN2 <> N'1.0.0'
BEGIN
    THROW 51033, N'Die installierte Modulversion ist diesem Uninstall-Skript nicht bekannt.', 1;
END;

IF @DeploymentMode NOT IN (N'local', N'central')
BEGIN
    THROW 51033, N'Der registrierte Deployment-Modus fehlt oder ist ungültig.', 1;
END;

IF @DeploymentMode = N'central' AND @ConfirmNoExternalConsumers <> 1
BEGIN
    THROW 51035, N'Bei zentraler Installation ist ConfirmNoExternalConsumers=1 als ausdrückliche Betreiberbestätigung erforderlich.', 1;
END;

SET @ProcedureId = OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable');

/*
 * SQL Server kann nur statische same-database Dependencies zuverlässig
 * ermitteln. Dynamische und externe dreiteilige Aufrufer erklären das
 * zusätzliche Confirm-Gate für zentrale Installationen.
 */
IF @ProcedureId IS NOT NULL
BEGIN
    SELECT TOP (1)
          @ReferencingSchema = OBJECT_SCHEMA_NAME(sed.referencing_id)
        , @ReferencingObject = OBJECT_NAME(sed.referencing_id)
    FROM sys.sql_expression_dependencies AS sed
    WHERE sed.referenced_id = @ProcedureId
      AND sed.referencing_id <> @ProcedureId
    ORDER BY
          OBJECT_SCHEMA_NAME(sed.referencing_id) COLLATE Latin1_General_100_BIN2
        , OBJECT_NAME(sed.referencing_id) COLLATE Latin1_General_100_BIN2;
END;

IF @ReferencingObject IS NOT NULL
BEGIN
    DECLARE @DependencyMessage nvarchar(2048) =
        N'Die Deinstallation wird durch same-database Dependency '
        + COALESCE(QUOTENAME(@ReferencingSchema), N'<ohne Schema>')
        + N'.'
        + COALESCE(QUOTENAME(@ReferencingObject), N'<unbekannt>')
        + N' blockiert.';
    SET @DependencyMessage = REPLACE(@DependencyMessage, N'%', N'%%');
    THROW 51036, @DependencyMessage, 1;
END;

/*
 * Der Preflight ist abgeschlossen. Das Release-Manifest von 1.0.0 enthält
 * genau toolbelt_core.USP_PrepareResultTable. Andere Objekte werden durch
 * dieses Skript nie ausgewählt.
 */
BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE @LockResult int;

    EXEC @LockResult = sys.sp_getapplock
          @Resource    = N'toolbelt.deploy.toolbelt.core.result-table'
        , @LockMode    = N'Exclusive'
        , @LockOwner   = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
    BEGIN
        THROW 51037, N'Ein paralleles Deployment von toolbelt.core.result-table ist bereits aktiv.', 1;
    END;

    DECLARE @CurrentInstalledVersion nvarchar(64);

    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
           <> @InstalledVersion COLLATE Latin1_General_100_BIN2
    BEGIN
        THROW 51037, N'Der installierte Modulstand hat sich seit dem Uninstall-Preflight verändert.', 1;
    END;

    SET @ProcedureId = OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable');

    IF @ProcedureId IS NOT NULL
    BEGIN
        DECLARE @ActualType char(2);

        SELECT @ActualType = o.type
        FROM sys.objects AS o
        WHERE o.object_id = @ProcedureId;

        IF @ActualType IN ('P', 'PC')
        BEGIN
            DROP PROCEDURE [toolbelt_core].[USP_PrepareResultTable];
        END;
        ELSE IF @ActualType = 'V'
        BEGIN
            DROP VIEW [toolbelt_core].[USP_PrepareResultTable];
        END;
        ELSE IF @ActualType IN ('FN', 'FS', 'FT', 'IF', 'TF')
        BEGIN
            DROP FUNCTION [toolbelt_core].[USP_PrepareResultTable];
        END;
        ELSE
        BEGIN
            THROW 51033, N'Das Release-Objekt besitzt einen nicht unterstützten lokal veränderten Objekttyp.', 1;
        END;
    END;

    EXEC sys.sp_dropextendedproperty @name = @VersionPropertyName;
    EXEC sys.sp_dropextendedproperty @name = @ModePropertyName;

    DECLARE
          @SchemaId int = SCHEMA_ID(N'toolbelt_core')
        , @SchemaManaged int
        , @SchemaCategory nvarchar(128);

    IF @SchemaId IS NOT NULL
    BEGIN
        SELECT
              @SchemaManaged = MAX
              (
                  CASE
                      WHEN ep.name = N'Toolbelt.Managed'
                          THEN TRY_CONVERT(int, ep.value)
                  END
              )
            , @SchemaCategory = MAX
              (
                  CASE
                      WHEN ep.name = N'Toolbelt.SchemaCategory'
                          THEN TRY_CONVERT(nvarchar(128), ep.value)
                  END
              )
        FROM sys.extended_properties AS ep
        WHERE ep.class = 3
          AND ep.major_id = @SchemaId
          AND ep.minor_id = 0;

        /*
         * Ein vor der Installation vorhandenes unmarkiertes Schema wird nicht
         * adoptiert und folglich niemals entfernt. Ein vom Toolbelt angelegtes
         * Schema darf nur in vollständig leerem Zustand verschwinden.
         */
        IF ISNULL(@SchemaManaged, 0) = 1
           AND ISNULL(@SchemaCategory, N'') COLLATE Latin1_General_100_BIN2 = N'core'
           AND NOT EXISTS
               (
                   SELECT 1
                   FROM sys.objects AS o
                   WHERE o.schema_id = @SchemaId
               )
           AND NOT EXISTS
               (
                   SELECT 1
                   FROM sys.types AS t
                   WHERE t.schema_id = @SchemaId
                     AND t.is_user_defined = 1
               )
           AND NOT EXISTS
               (
                   SELECT 1
                   FROM sys.xml_schema_collections AS xsc
                   WHERE xsc.schema_id = @SchemaId
                     AND xsc.xml_collection_id > 0
               )
        BEGIN
            DROP SCHEMA [toolbelt_core];
        END;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO

GO
