-- Exakter Assembly-Trust; administrativ bewusst in master ausführen.
:ON ERROR EXIT
USE [master];
GO
IF @@TRANCOUNT<>0 THROW 51593,N'Keine Callertransaktion erlaubt.',1;
IF ISNULL(IS_SRVROLEMEMBER(N'sysadmin'),0)<>1 THROW 51593,N'Vorhandene administrative Rechte erforderlich.',2;
IF NOT EXISTS(SELECT 1 FROM sys.trusted_assemblies WITH (NOLOCK) WHERE hash=0xa3185897b72adbaa81c462cabedc6a770ebedf6b123b1f148d8a659b146130d90c163b76840d59aa8148661b00316cd02d8c5c05174e3394659edc53ff9f1894)
 EXEC sys.sp_add_trusted_assembly @hash=0xa3185897b72adbaa81c462cabedc6a770ebedf6b123b1f148d8a659b146130d90c163b76840d59aa8148661b00316cd02d8c5c05174e3394659edc53ff9f1894,@description=N'Toolbelt 1.0.0 Toolbelt.Archive.ZipMemory.dll';
IF NOT EXISTS(SELECT 1 FROM sys.trusted_assemblies WITH (NOLOCK) WHERE hash=0x5c08fb50e6190890e279a8153b5fed354dc43472d246a6448aa9b60856c4a91357bbd258d4b5420c703929166d1be09b0b38e65787db504c98e3a8396f95f00d)
 EXEC sys.sp_add_trusted_assembly @hash=0x5c08fb50e6190890e279a8153b5fed354dc43472d246a6448aa9b60856c4a91357bbd258d4b5420c703929166d1be09b0b38e65787db504c98e3a8396f95f00d,@description=N'Toolbelt 1.0.0 Toolbelt.File.XlsxMemory.dll';
GO
