-- SQL Server Toolbelt: aus aktuellen Modulskripten erzeugtes Deployment.
-- SQLCMD-Modus und Fehlerabbruch erforderlich (sqlcmd -b -f 65001).
-- In frischer exklusiver Verbindung in der gewählten Zieldatenbank ausführen.
-- Keine Gesamttransaktion; frühere erfolgreiche Module bleiben bei Fehlern installiert.
-- Bestehende Versions-/Dependency-/Trust-/Migrationsgates bleiben wirksam.
-- DeploymentMode: local
:ON ERROR EXIT
GO
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.core.result-table
:On Error exit

-- ============================================================================
-- Zweck:     Erst-, Upgrade- und Wiederholungsdeployment
-- Modul:     toolbelt.core.result-table v1.0.0
-- Schema:    toolbelt_core
-- Erfordert: SQL Server 2019, 2022 oder 2025
-- Modus:     SQLCMD; Ausführung aus diesem Deployment-Verzeichnis
-- Parameter: DeploymentMode=local|central
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'tempdb..#tbx_ResultTableReleaseObjects', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_ResultTableReleaseObjects;
END;

IF OBJECT_ID(N'tempdb..#tbx_ResultTableDeployState', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_ResultTableDeployState;
END;

/*
 * Dieses Manifest enthält jedes bekannte Release. Bei einem neuen Release
 * bleiben die Zeilen der unterstützten Vorgänger erhalten. Dadurch kann das
 * Deployment objektgenau unterscheiden zwischen:
 * - bereits zum Framework gehörenden Objekten,
 * - im Zielrelease neu hinzukommenden Namen,
 * - im Zielrelease weggefallenen Framework-Objekten.
 */
CREATE TABLE #tbx_ResultTableReleaseObjects
(
      ReleaseVersion nvarchar(64) NOT NULL
    , SchemaName     sysname      NOT NULL
    , ObjectName     sysname      NOT NULL
    , ObjectType     char(2)      NOT NULL
    , CONSTRAINT PK_tbx_ResultTableReleaseObjects
          PRIMARY KEY (ReleaseVersion, SchemaName, ObjectName)
);

INSERT INTO #tbx_ResultTableReleaseObjects
(
      ReleaseVersion
    , SchemaName
    , ObjectName
    , ObjectType
)
VALUES
(
      N'1.0.0'
    , N'toolbelt_core'
    , N'USP_PrepareResultTable'
    , 'P'
);

CREATE TABLE #tbx_ResultTableDeployState
(
      TargetVersion    nvarchar(64) NOT NULL
    , InstalledVersion nvarchar(64) NULL
    , DeploymentMode   nvarchar(16) NOT NULL
    , SchemaCreated     bit          NOT NULL
);

DECLARE
      @TargetVersion        nvarchar(64)  = N'1.0.0'
    , @DeploymentMode       nvarchar(16)  = LOWER(N'local')
    , @InstalledVersion     nvarchar(64)
    , @VersionPropertyName  sysname =
          N'Toolbelt.Module.toolbelt.core.result-table.Version'
    , @ProductMajorVersion  int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @SchemaId             int = SCHEMA_ID(N'toolbelt_core')
    , @CollisionSchema      sysname
    , @CollisionObject      sysname
    , @LockResult           int
    , @DropSql              nvarchar(max)
    , @SchemaCreated        bit = 0;

IF @ProductMajorVersion NOT IN (15, 16, 17)
BEGIN
    THROW 51030, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
END;

IF @DeploymentMode NOT IN (N'local', N'central')
BEGIN
    THROW 51031, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

IF @InstalledVersion IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM #tbx_ResultTableReleaseObjects AS ro
           WHERE ro.ReleaseVersion COLLATE Latin1_General_100_BIN2
                     = @InstalledVersion COLLATE Latin1_General_100_BIN2
       )
BEGIN
    THROW 51033, N'Die installierte Modulversion ist diesem Deployment nicht als unterstütztes Vorgängerrelease bekannt.', 1;
END;

-- SQLCMD-Preflightfragment, keine dauerhafte Mutation und kein Batchseparator.
-- Nur dbo sowie explizit vertrauenswürdige DBowner-/Installerrollen dürfen
-- das gemeinsame Schema kontrollieren. Fehlende Metadatensicht ist kein PASS.
IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
    THROW 51032,N'Für die Schematrustprüfung fehlt vollständige Datenbank-Metadatensicht.',2;
IF SCHEMA_ID(N'toolbelt_core') IS NOT NULL
   AND (SELECT principal_id FROM sys.schemas WHERE name=N'toolbelt_core')<>1
    THROW 51032,N'Der Owner von toolbelt_core muss dbo sein; kein automatischer Ownertransfer.',2;

DECLARE @tbx_TrustedSchemaPrincipals TABLE(PrincipalId int PRIMARY KEY);
;WITH Trusted AS
(
    SELECT principal_id FROM sys.database_principals
    WHERE principal_id=1 OR (type='R' AND name IN(N'db_owner',N'toolbelt_core_installer'))
    UNION ALL
    SELECT m.member_principal_id FROM sys.database_role_members m JOIN Trusted t ON t.principal_id=m.role_principal_id
)
INSERT @tbx_TrustedSchemaPrincipals SELECT DISTINCT principal_id FROM Trusted OPTION(MAXRECURSION 32);

-- Eine vertrauenswürdige Rolle darf nicht durch einen untrusted Rollenowner
-- verwaltet werden; Rollenname allein ist keine Autorität.
IF EXISTS(SELECT 1 FROM sys.database_principals r
    JOIN @tbx_TrustedSchemaPrincipals t ON t.PrincipalId=r.principal_id
    WHERE r.type='R' AND NOT EXISTS(SELECT 1 FROM @tbx_TrustedSchemaPrincipals owner
        WHERE owner.PrincipalId=r.owning_principal_id))
    THROW 51032,N'Eine vertrauenswürdige Rolle hat einen nicht freigegebenen Owner.',2;

IF EXISTS
(
    SELECT 1 FROM sys.database_permissions p
    WHERE p.state IN('G','W')
      AND NOT EXISTS(SELECT 1 FROM @tbx_TrustedSchemaPrincipals t WHERE t.PrincipalId=p.grantee_principal_id)
      AND
      (
        (p.class=3 AND p.major_id=SCHEMA_ID(N'toolbelt_core') AND p.permission_name IN(N'ALTER',N'CONTROL',N'TAKE OWNERSHIP'))
        OR (p.class=0 AND p.permission_name IN(N'CONTROL',N'ALTER ANY SCHEMA',N'ALTER ANY ROLE',N'IMPERSONATE ANY USER'))
        OR (p.class=4 AND p.permission_name IN(N'CONTROL',N'IMPERSONATE') AND EXISTS
            (SELECT 1 FROM @tbx_TrustedSchemaPrincipals t WHERE t.PrincipalId=p.major_id))
        OR (p.class=1 AND p.major_id=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable') AND p.permission_name IN(N'ALTER',N'CONTROL',N'TAKE OWNERSHIP'))
      )
)
    THROW 51032,N'Nicht freigegebene Principals besitzen Schema- oder Helperkontrollrechte.',2;

-- Feste Rollenrechte stehen nicht vollständig in sys.database_permissions.
IF EXISTS
(
    SELECT 1 FROM sys.database_role_members m JOIN sys.database_principals r ON r.principal_id=m.role_principal_id
    WHERE r.name IN(N'db_ddladmin',N'db_securityadmin')
      AND NOT EXISTS(SELECT 1 FROM @tbx_TrustedSchemaPrincipals t WHERE t.PrincipalId=m.member_principal_id)
)
    THROW 51032,N'Nicht freigegebene DDL-Administrationsmitgliedschaft verhindert die Schematrustfreigabe.',2;

IF @SchemaId IS NULL
BEGIN
    IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    BEGIN
        THROW 51032, N'Zum Anlegen von toolbelt_core fehlt CREATE SCHEMA in der Installationsdatenbank.', 1;
    END;
END;
ELSE IF HAS_PERMS_BY_NAME(N'toolbelt_core', N'SCHEMA', N'ALTER') <> 1
BEGIN
    THROW 51032, N'Für das vorhandene Schema toolbelt_core fehlt ALTER.', 1;
END;

IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE PROCEDURE') <> 1
BEGIN
    THROW 51032, N'In der Installationsdatenbank fehlt CREATE PROCEDURE.', 1;
END;

/*
 * Ein vorhandener Zielname ist nur dann Framework-Bestand, wenn genau dieser
 * Name im bekannten installierten Release enthalten war. Bei einer
 * Erstinstallation oder einem im Zielrelease neuen Namen wird niemals ein
 * bereits vorhandenes fremdes Objekt überschrieben.
 */
SELECT TOP (1)
      @CollisionSchema = t.SchemaName
    , @CollisionObject = t.ObjectName
FROM #tbx_ResultTableReleaseObjects AS t
INNER JOIN sys.schemas AS s
    ON s.name COLLATE Latin1_General_100_BIN2
          = t.SchemaName COLLATE Latin1_General_100_BIN2
INNER JOIN sys.objects AS o
    ON o.schema_id = s.schema_id
   AND o.name COLLATE Latin1_General_100_BIN2
          = t.ObjectName COLLATE Latin1_General_100_BIN2
WHERE t.ReleaseVersion = @TargetVersion
  AND
  (
      @InstalledVersion IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM #tbx_ResultTableReleaseObjects AS p
             WHERE p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                       = @InstalledVersion COLLATE Latin1_General_100_BIN2
               AND p.SchemaName COLLATE Latin1_General_100_BIN2
                       = t.SchemaName COLLATE Latin1_General_100_BIN2
               AND p.ObjectName COLLATE Latin1_General_100_BIN2
                       = t.ObjectName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY
      t.SchemaName COLLATE Latin1_General_100_BIN2
    , t.ObjectName COLLATE Latin1_General_100_BIN2;

IF @CollisionObject IS NOT NULL
BEGIN
    DECLARE @CollisionMessage nvarchar(2048) =
        N'Das neue Framework-Objekt '
        + QUOTENAME(@CollisionSchema)
        + N'.'
        + QUOTENAME(@CollisionObject)
        + N' ist bereits vorhanden, stammt aber nicht aus dem bekannten installierten Release.';
    SET @CollisionMessage = REPLACE(@CollisionMessage, N'%', N'%%');
    THROW 51034, @CollisionMessage, 1;
END;

INSERT INTO #tbx_ResultTableDeployState
(
      TargetVersion
    , InstalledVersion
    , DeploymentMode
    , SchemaCreated
)
VALUES
(
      @TargetVersion
    , @InstalledVersion
    , @DeploymentMode
    , 0
);

/*
 * Der vollständige Preflight ist abgeschlossen. Erst jetzt beginnt die kurze
 * Mutationstransaktion. Eine Transaction-owned Application Lock serialisiert
 * Deployments dieses Moduls innerhalb der Zieldatenbank.
 */
BEGIN TRY
    BEGIN TRANSACTION;

    EXEC @LockResult = sys.sp_getapplock
          @Resource    = N'toolbelt.deploy.toolbelt.core.result-table'
        , @LockMode    = N'Exclusive'
        , @LockOwner   = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
    BEGIN
        THROW 51037, N'Ein paralleles Deployment von toolbelt.core.result-table ist bereits aktiv.', 1;
    END;

    DECLARE @CurrentInstalledVersion nvarchar(64);

    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
           <> ISNULL(@InstalledVersion, N'') COLLATE Latin1_General_100_BIN2
    BEGIN
        THROW 51037, N'Der installierte Modulstand hat sich seit dem Preflight verändert.', 1;
    END;

    SET @CollisionSchema = NULL;
    SET @CollisionObject = NULL;

    SELECT TOP (1)
          @CollisionSchema = t.SchemaName
        , @CollisionObject = t.ObjectName
    FROM #tbx_ResultTableReleaseObjects AS t
    INNER JOIN sys.schemas AS s
        ON s.name COLLATE Latin1_General_100_BIN2
              = t.SchemaName COLLATE Latin1_General_100_BIN2
    INNER JOIN sys.objects AS o
        ON o.schema_id = s.schema_id
       AND o.name COLLATE Latin1_General_100_BIN2
              = t.ObjectName COLLATE Latin1_General_100_BIN2
    WHERE t.ReleaseVersion = @TargetVersion
      AND
      (
          @InstalledVersion IS NULL
          OR NOT EXISTS
             (
                 SELECT 1
                 FROM #tbx_ResultTableReleaseObjects AS p
                 WHERE p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                           = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND p.SchemaName COLLATE Latin1_General_100_BIN2
                           = t.SchemaName COLLATE Latin1_General_100_BIN2
                   AND p.ObjectName COLLATE Latin1_General_100_BIN2
                           = t.ObjectName COLLATE Latin1_General_100_BIN2
             )
      );

    IF @CollisionObject IS NOT NULL
    BEGIN
        THROW 51037, N'Ein Zielobjekt hat sich seit dem Preflight verändert oder ist neu hinzugekommen.', 1;
    END;

    SET @SchemaId = SCHEMA_ID(N'toolbelt_core');

    IF @SchemaId IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_core] AUTHORIZATION [dbo];';
        SET @SchemaCreated = 1;
        SET @SchemaId = SCHEMA_ID(N'toolbelt_core');

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.Managed'
            , @value      = 1
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_core';

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.SchemaCategory'
            , @value      = N'core'
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_core';
    END;

    UPDATE #tbx_ResultTableDeployState
    SET SchemaCreated = @SchemaCreated;

    /*
     * Ein Objekt verschwindet nur dann, wenn es im bekannten installierten
     * Release enthalten war und im Zielrelease fehlt. Andere Objekte werden
     * durch diesen Block weder ausgewählt noch verändert.
     */
    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN o.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN o.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN o.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(s.name)
                    + N'.'
                    + QUOTENAME(o.name)
                    + N';'
                FROM #tbx_ResultTableReleaseObjects AS p
                INNER JOIN sys.schemas AS s
                    ON s.name COLLATE Latin1_General_100_BIN2
                          = p.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS o
                    ON o.schema_id = s.schema_id
                   AND o.name COLLATE Latin1_General_100_BIN2
                          = p.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                  AND NOT EXISTS
                      (
                          SELECT 1
                          FROM #tbx_ResultTableReleaseObjects AS t
                          WHERE t.ReleaseVersion = @TargetVersion
                            AND t.SchemaName COLLATE Latin1_General_100_BIN2
                                  = p.SchemaName COLLATE Latin1_General_100_BIN2
                            AND t.ObjectName COLLATE Latin1_General_100_BIN2
                                  = p.ObjectName COLLATE Latin1_General_100_BIN2
                      )
                  AND o.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY
                      s.name COLLATE Latin1_General_100_BIN2
                    , o.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;

    /*
     * Wurde ein Framework-Objekt lokal in einen anderen unterstützten
     * Objekttyp umgebaut, bleibt seine Herkunft aus dem Vorgängerrelease
     * maßgeblich. Der falsche Typ wird entfernt, damit die kanonische Source
     * den Zieltyp neu anlegen kann.
     */
    SET @DropSql = NULL;

    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN o.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN o.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN o.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(s.name)
                    + N'.'
                    + QUOTENAME(o.name)
                    + N';'
                FROM #tbx_ResultTableReleaseObjects AS t
                INNER JOIN #tbx_ResultTableReleaseObjects AS p
                    ON p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND p.SchemaName COLLATE Latin1_General_100_BIN2
                          = t.SchemaName COLLATE Latin1_General_100_BIN2
                   AND p.ObjectName COLLATE Latin1_General_100_BIN2
                          = t.ObjectName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.schemas AS s
                    ON s.name COLLATE Latin1_General_100_BIN2
                          = t.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS o
                    ON o.schema_id = s.schema_id
                   AND o.name COLLATE Latin1_General_100_BIN2
                          = t.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE t.ReleaseVersion = @TargetVersion
                  AND o.type COLLATE Latin1_General_100_BIN2
                        <> t.ObjectType COLLATE Latin1_General_100_BIN2
                  AND o.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY
                      s.name COLLATE Latin1_General_100_BIN2
                    , o.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO

/*
 * Die kanonische Source liegt exakt einmal im Repository. CREATE OR ALTER
 * überschreibt bei Erst-, Upgrade- und Wiederholungsdeployment die
 * Framework-Procedure innerhalb der bereits geöffneten Transaktion.
 */
-- ============================================================================
-- Objekt:          toolbelt_core.USP_PrepareResultTable
-- Typ:             Stored Procedure
-- Zweck:           Bereitet eine vorhandene lokale Temp-Tabelle anhand des
--                  Spaltenschemas einer Referenztabelle als ResultTable vor.
-- Vertrag:         Documentation/Architecture/RESULT_TABLE_MODULE_DESIGN.md
-- Parameter:       @ResultTableToAlter sysname = NULL
--                  @LikeTable nvarchar(776) = NULL
--                  @KeepData bit = 0
--                  @Debug tinyint = 0
--                  @Hilfe bit = 0
-- Resultset:       Kein fachliches Resultset; bei @Hilfe = 1 genau ein
--                  standardisiertes Help-Resultset.
-- Dependencies:    Keine weiteren Toolbelt-Module.
-- Rechte:          EXECUTE auf der Procedure und Metadatensichtbarkeit auf
--                  reguläre Referenztabellen. Keine Rechteausweitung.
-- Versionen:       SQL Server 2019, 2022 und 2025.
-- Plattformen:     Windows und Linux; Runtime-Validierung separat auszuweisen.
-- Fehlerverhalten: Vertragsfehler 51020 bis 51029; Engine-Fehler werden nach
--                  transaktionsgerechtem Cleanup unverändert weitergegeben.
-- Performance:     Ein read-only Metadaten-Preflight. DDL nur bei abweichendem
--                  Schema; bei passendem Schema optional TRUNCATE.
-- Einschränkungen: Nur lokale Ziel-Temp-Tabellen und Tabellen als Schemaquelle.
--                  Keine gleichzeitige DDL-Manipulation derselben Zieltable.
-- ============================================================================

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_core].[USP_PrepareResultTable]
(
      @ResultTableToAlter sysname       = NULL
    , @LikeTable          nvarchar(776) = NULL
    , @KeepData           bit           = 0
    , @Debug              tinyint       = 0
    , @Hilfe              bit           = 0
)
AS
BEGIN
    SET NOCOUNT ON;

    -- Explizit übergebenes NULL verwendet denselben technischen Default wie
    -- ein ausgelassener optionaler Steuerparameter.
    SET @KeepData = ISNULL(@KeepData, 0);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    /*
     * Der Help-Pfad steht absichtlich vor jeder fachlichen Validierung. Dadurch
     * bleibt ein reiner Hilfeaufruf ohne Zieltable, Referenztabelle oder Rechte
     * auf fremde Metadaten möglich und garantiert keinerlei Mutation.
     */
    IF @Hilfe = 1
    BEGIN
        -- API_PARAMETER_HELP:BEGIN
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
            CAST(N'toolbelt_core' AS sysname) AS SchemaName,
            CAST(N'USP_PrepareResultTable' AS sysname) AS ObjectName,
            CAST(v.Section AS varchar(32)) AS Section, CAST(v.Ordinal AS int) AS Ordinal,
            CAST(v.ItemName AS sysname) AS ItemName, CAST(v.SqlDataType AS varchar(256)) AS SqlDataType,
            CAST(v.IsRequired AS bit) AS IsRequired, CAST(v.IsNullable AS bit) AS IsNullable,
            CAST(v.DefaultValue AS nvarchar(4000)) AS DefaultValue,
            CAST(v.Description AS nvarchar(max)) AS Description,
            CAST(v.ExampleSql AS nvarchar(max)) AS ExampleSql
        FROM (VALUES
        (N'DESCRIPTION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Bereitet eine vorhandene lokale Temp-Tabelle anhand des Spaltenschemas einer vorhandenen Referenztabelle vor. Die Procedure fügt keine fachlichen Resultzeilen ein.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Diese Infrastruktur-USP besitzt kein fachliches Resultset. Erfolg wird mit RETURN 0, ein Fehler mit THROW signalisiert.' AS nvarchar(max)), NULL),
        (N'ERROR', 1, N'51020', NULL, NULL, NULL, NULL, CAST(N'@ResultTableToAlter fehlt oder ist kein zulässiger lokaler Temp-Tabellenname.' AS nvarchar(max)), NULL),
        (N'ERROR', 2, N'51021', NULL, NULL, NULL, NULL, CAST(N'Die Zieltable ist im aktuellen Session-Scope nicht sichtbar.' AS nvarchar(max)), NULL),
        (N'ERROR', 3, N'51022', NULL, NULL, NULL, NULL, CAST(N'@LikeTable fehlt, ist mehrdeutig, verwendet eine nicht unterstützte Namensform oder bezeichnet dieselbe Temp-Tabelle wie das Ziel.' AS nvarchar(max)), NULL),
        (N'ERROR', 4, N'51023', NULL, NULL, NULL, NULL, CAST(N'Die Referenztabelle ist nicht sichtbar oder kein unterstützter Tabellentyp.' AS nvarchar(max)), NULL),
        (N'ERROR', 5, N'51024', NULL, NULL, NULL, NULL, CAST(N'Das Referenzschema enthält eine nicht unterstützte oder nicht einfügbare Spaltenform.' AS nvarchar(max)), NULL),
        (N'ERROR', 6, N'51025', NULL, NULL, NULL, NULL, CAST(N'@KeepData = 1 verhindert den erforderlichen Schemaumbau.' AS nvarchar(max)), NULL),
        (N'ERROR', 7, N'51026', NULL, NULL, NULL, NULL, CAST(N'Ein Index, Constraint oder anderes abhängiges Objekt verhindert den Schemaumbau.' AS nvarchar(max)), NULL),
        (N'ERROR', 8, N'51027', NULL, NULL, NULL, NULL, CAST(N'Eine Collation oder ein Datentyp kann nicht sicher in DDL überführt werden.' AS nvarchar(max)), NULL),
        (N'ERROR', 9, N'51028', NULL, NULL, NULL, NULL, CAST(N'Der aktuelle Transaktionszustand erlaubt kein kontrolliertes Rollback.' AS nvarchar(max)), NULL),
        (N'ERROR', 10, N'51029', NULL, NULL, NULL, NULL, CAST(N'Intern erzeugtes DDL überschreitet einen unterstützten Grenzwert oder ist unvollständig.' AS nvarchar(max)), NULL),
        (N'PERMISSION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Erforderlich sind EXECUTE auf der Procedure sowie ausreichende Metadatensichtbarkeit auf eine reguläre Referenztabelle. Die Procedure verwendet kein EXECUTE AS und gewährt keine Rechte.' AS nvarchar(max)), NULL),
        (N'LIMITATION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Permanente oder globale Zieltabellen, Tabellenvariablen, identische Ziel- und Referenztabellen, Views, Synonyme, Linked Server, frei geliefertes DDL und parallele DDL-Manipulation derselben Zieltable sind nicht unterstützt.' AS nvarchar(max)), NULL),
        (N'EXAMPLE', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Bereitet eine synthetische lokale ResultTable anhand einer lokalen Helper-Tabelle vor.' AS nvarchar(max)), CAST(N'CREATE TABLE #Result (Dummy int NULL);
CREATE TABLE #ResultShape (ItemOrdinal bigint NOT NULL, ItemValue varchar(100) NULL);

EXEC toolbelt_core.USP_PrepareResultTable
      @ResultTableToAlter = N''#Result''
    , @LikeTable          = N''#ResultShape''
    , @KeepData           = 0;' AS nvarchar(max))),
        (N'PARAMETER', 1, N'@ResultTableToAlter', N'sysname', 1, 0, N'NULL', CAST(N'Fachlich erforderliche, bereits existierende caller-lokale #Temp im selben sichtbaren Session-Scope; logischer Name 2..116 UTF-16-Einheiten, genau ein führendes # und kein reserviertes #tbx_-Präfix. Ein einzelner Identifier, kein DDL und keine Tabellenvariable/permanente/globale Tabelle. NULL ist nur technischer Help-Default. Darf nicht dieselbe Tabelle wie LikeTable sein.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 2, N'@LikeTable', N'nvarchar(776)', 1, 0, N'NULL', CAST(N'Fachlich erforderliche vorhandene Referenztabelle als #LocalTemplate, Schema.Table oder Database.Schema.Table, optional regulär quotierte Namensbestandteile. Keine einteilige permanente Tabelle, Server-/vierteilige Namen, Views, Synonyme oder ##Temps. NULL/leer ungültig. Referenzspalten müssen dem unterstützten einfügbaren Typ-/Metadatenvertrag in RESULT_TABLE_MODULE_DESIGN.md entsprechen; der Helper übernimmt Spaltenshape und keine fachlichen Zeilen.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 3, N'@KeepData', N'bit', 0, 1, N'0', CAST(N'Taxativ im gebundenen bit: 0 ersetzt/leert vorhandene Zielinhalte und baut nötigenfalls das Schema um (Default); 1 erhält vorhandene Zeilen und lehnt einen nötigen Schemaumbau bei nicht leerem Ziel mit 51025 ab. Ein leeres Ziel darf auch bei 1 angepasst werden. NULL wirkt wie 0. Keine Append-Operation des Helpers selbst; fachliche Zeilen fügt der Caller danach ein.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 4, N'@Debug', N'tinyint', 0, 1, N'0', CAST(N'Ganzzahl tinyint 0..255, Default 0; NULL wirkt wie 0. 0 keine Debugmessages, 1 Preflight/Ablauf, 2 zusätzlich zusammengefasste Metadaten/Schemaentscheidung, 3..255 zusätzlich normalisierte Referenzmetadaten und geplantes DDL. Die Schwellwerte gelten kumulativ; 255 besitzt im aktuellen Code keine weitere eigene Stufe. Nur Messages, kein Zusatzresultset.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 5, N'@Hilfe', N'bit', 0, 1, N'0', CAST(N'Taxativ für bit: 1 liefert nur die Standardhilfe vor der Fachvalidierung; 0 (Default) führt den Fachaufruf aus. NULL wird wie 0 behandelt. Syntaktisch erforderliche Argumente ohne technischen Default müssen auch beim Help-Aufruf angegeben werden.' AS nvarchar(max)), NULL)
        ) AS v(Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql)
        ORDER BY CASE v.Section WHEN 'DESCRIPTION' THEN 0 WHEN 'PARAMETER' THEN 1
            WHEN 'RESULT_COLUMN' THEN 2 WHEN 'EXAMPLE' THEN 3 ELSE 4 END, v.Ordinal;
        RETURN 0;
        -- API_PARAMETER_HELP:END
    END;

    DECLARE
          @TargetObjectId          int
        , @TargetQuotedName        nvarchar(258)
        , @SourceObjectId          int
        , @SourceDatabaseName      sysname
        , @SourceDatabaseQuoted    nvarchar(258)
        , @SourceSchemaName        sysname
        , @SourceObjectName        sysname
        , @SourceServerName        sysname
        , @SourceIsLocal           bit = 0
        , @Sql                     nvarchar(max)
        , @ErrorMessage            nvarchar(2048)
        , @DebugMessage            nvarchar(max)
        , @DebugChunk              nvarchar(1800);

    /*
     * Der logische Zielname wird als ein einzelner Identifier behandelt. Ein
     * Punkt oder eine schließende Klammer darf daher Bestandteil des Namens
     * sein; QUOTENAME verhindert, dass daraus ein mehrteiliger Name oder DDL
     * wird. Die physische TempDB-Suffixbildung wird SQL Server überlassen.
     */
    IF @ResultTableToAlter IS NULL
       OR DATALENGTH(@ResultTableToAlter) < 4
       OR DATALENGTH(@ResultTableToAlter) > 232
       OR LEFT(@ResultTableToAlter, 1) COLLATE Latin1_General_100_BIN2 <> N'#'
       OR LEFT(@ResultTableToAlter, 2) COLLATE Latin1_General_100_BIN2 = N'##'
       OR LOWER(LEFT(@ResultTableToAlter, 5) COLLATE Latin1_General_100_BIN2) = N'#tbx_'
       OR QUOTENAME(@ResultTableToAlter) IS NULL
    BEGIN
        THROW 51020, N'@ResultTableToAlter muss eine vorhandene lokale Temp-Tabelle mit genau einem führenden #, höchstens 116 Zeichen und ohne reservierten Präfix #tbx_ bezeichnen.', 1;
    END;

    SET @TargetQuotedName = QUOTENAME(@ResultTableToAlter);
    SET @TargetObjectId = OBJECT_ID(N'tempdb..' + @TargetQuotedName, N'U');

    IF @TargetObjectId IS NULL
    BEGIN
        SET @ErrorMessage = N'Die lokale Zieltable '
            + @TargetQuotedName
            + N' ist im aktuellen Session-Scope nicht sichtbar.';
        SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
        THROW 51021, @ErrorMessage, 1;
    END;

    IF @LikeTable IS NULL OR DATALENGTH(@LikeTable) = 0
    BEGIN
        THROW 51022, N'@LikeTable muss #LocalTemplate, Schema.Table oder Database.Schema.Table bezeichnen.', 1;
    END;

    /*
     * Lokale Referenztabellen werden wie die Zieltable genau einmal aufgelöst.
     * Globale Temp-Tabellen sind eine erkennbare, aber nicht unterstützte
     * Tabellenart und erhalten deshalb den Objektfehler 51023.
     */
    IF (LEFT(@LikeTable, 1) COLLATE Latin1_General_100_BIN2) = N'#'
    BEGIN
        IF (LEFT(@LikeTable, 2) COLLATE Latin1_General_100_BIN2) = N'##'
        BEGIN
            THROW 51023, N'Globale Temp-Tabellen sind als @LikeTable nicht unterstützt.', 1;
        END;

        IF DATALENGTH(@LikeTable) < 4
           OR DATALENGTH(@LikeTable) > 232
           OR QUOTENAME(CONVERT(sysname, @LikeTable)) IS NULL
        BEGIN
            THROW 51022, N'Der lokale Name in @LikeTable ist kein zulässiger Temp-Tabellenname.', 1;
        END;

        SET @SourceIsLocal = 1;
        SET @SourceDatabaseName = N'tempdb';
        SET @SourceDatabaseQuoted = QUOTENAME(@SourceDatabaseName);
        SET @SourceObjectName = CONVERT(sysname, @LikeTable);
        SET @SourceObjectId = OBJECT_ID(
              N'tempdb..' + QUOTENAME(@SourceObjectName)
            , N'U'
        );

        IF @SourceObjectId IS NULL
        BEGIN
            SET @ErrorMessage = N'Die lokale Referenztabelle '
                + QUOTENAME(@SourceObjectName)
                + N' ist im aktuellen Session-Scope nicht sichtbar.';
            SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
            THROW 51023, @ErrorMessage, 1;
        END;
    END;
    ELSE
    BEGIN
        /*
         * PARSENAME zerlegt ausschließlich Objektnamen. Die ermittelten Teile
         * werden nie als Originaltext ausgeführt, sondern als sysname geprüft,
         * mit QUOTENAME neu aufgebaut und Werte in Catalog-Abfragen
         * parametrisiert. Ein Serverteil ist vertraglich ausgeschlossen.
         */
        SET @SourceObjectName = PARSENAME(@LikeTable, 1);
        SET @SourceSchemaName = PARSENAME(@LikeTable, 2);
        SET @SourceDatabaseName = PARSENAME(@LikeTable, 3);
        SET @SourceServerName = PARSENAME(@LikeTable, 4);

        IF @SourceObjectName IS NULL
           OR @SourceSchemaName IS NULL
           OR @SourceServerName IS NOT NULL
           OR QUOTENAME(@SourceObjectName) IS NULL
           OR QUOTENAME(@SourceSchemaName) IS NULL
        BEGIN
            THROW 51022, N'@LikeTable muss als Schema.Table oder Database.Schema.Table ohne Serverteil angegeben werden.', 1;
        END;

        IF @SourceDatabaseName IS NULL
        BEGIN
            SET @SourceDatabaseName = DB_NAME();
        END;

        IF DB_ID(@SourceDatabaseName) IS NULL
           OR QUOTENAME(@SourceDatabaseName) IS NULL
        BEGIN
            THROW 51023, N'Die Datenbank der Referenztabelle ist nicht sichtbar oder nicht vorhanden.', 1;
        END;

        SET @SourceDatabaseQuoted = QUOTENAME(@SourceDatabaseName);
        SET @Sql = N'
SELECT @ResolvedObjectId = t.object_id
FROM ' + @SourceDatabaseQuoted + N'.sys.tables AS t
INNER JOIN ' + @SourceDatabaseQuoted + N'.sys.schemas AS s
    ON s.schema_id = t.schema_id
WHERE s.name COLLATE Latin1_General_100_BIN2
          = @SchemaName COLLATE Latin1_General_100_BIN2
  AND t.name COLLATE Latin1_General_100_BIN2
          = @ObjectName COLLATE Latin1_General_100_BIN2;';

        BEGIN TRY
            EXEC sys.sp_executesql
                  @Sql
                , N'@SchemaName sysname, @ObjectName sysname, @ResolvedObjectId int OUTPUT'
                , @SchemaName      = @SourceSchemaName
                , @ObjectName      = @SourceObjectName
                , @ResolvedObjectId = @SourceObjectId OUTPUT;
        END TRY
        BEGIN CATCH
            /*
             * Ein tatsächlich aufgetretener Engine-Fehler darf nicht als
             * Toolbelt-Validierungsfehler erscheinen. Nur eine erfolgreich
             * ausgeführte Suche ohne unterstütztes Objekt ergibt 51023.
             */
            THROW;
        END CATCH;

        IF @SourceObjectId IS NULL
        BEGIN
            THROW 51023, N'Die reguläre Referenztabelle ist nicht sichtbar, nicht vorhanden oder kein User Table.', 1;
        END;
    END;

    IF @SourceIsLocal = 1 AND @SourceObjectId = @TargetObjectId
    BEGIN
        THROW 51022, N'@ResultTableToAlter und @LikeTable dürfen nicht dieselbe lokale Temp-Tabelle bezeichnen.', 1;
    END;

    IF @Debug >= 1
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: Ziel- und Referenztabelle wurden aufgelöst; read-only Preflight beginnt.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    DECLARE
          @SourceColumnCount       int
        , @TargetColumnCount       int
        , @UnsupportedColumnName   sysname
        , @UnsupportedReason       nvarchar(4000)
        , @InvalidCollationDetected bit
        , @InvalidCollationName    sysname
        , @SchemaMatches           bit
        , @AddColumnsList          nvarchar(max)
        , @AddColumnAfterAnchor     nvarchar(4000)
        , @DropColumnsList         nvarchar(max)
        , @DropColumnBeforeAnchor   nvarchar(258)
        , @SourceMetadataDebug     nvarchar(max);

    /*
     * Die Quelldatenbank ist der einzige dynamische Catalog-Teil. Sie stammt
     * entweder aus DB_NAME/PARSENAME oder ist tempdb und wird mit QUOTENAME
     * begrenzt. Objekt-IDs werden als Werte parametrisiert.
     *
     * Alias Types werden auf den zugrunde liegenden Systemtyp normalisiert.
     * Typisiertes XML und Sparse werden bewusst als untypisiertes XML
     * beziehungsweise normale Spalte abgebildet. Unbekannte neue Typen bleiben
     * durch die Whitelist gesperrt, bis ihr Vertrag versioniert erweitert wird.
     */
    SET @Sql = N'
DECLARE @SourceColumns TABLE
(
      ColumnOrdinal             int            NOT NULL
    , ColumnName                sysname        NOT NULL
    , TypeName                  sysname        NULL
    , MaxLength                 smallint       NOT NULL
    , PrecisionValue            tinyint        NOT NULL
    , ScaleValue                tinyint        NOT NULL
    , IsNullable                bit            NOT NULL
    , CollationName             sysname        NULL
    , IsIdentity                bit            NOT NULL
    , IsComputed                bit            NOT NULL
    , GeneratedAlwaysType       tinyint        NOT NULL
    , IsHidden                  bit            NOT NULL
    , IsColumnSet               bit            NOT NULL
    , IsSparse                  bit            NOT NULL
    , EncryptionType            int            NULL
    , IsAssemblyType            bit            NOT NULL
    , IsUserDefined             bit            NOT NULL
    , XmlCollectionId           int            NOT NULL
    , UnsupportedReason         nvarchar(4000) NULL
    , NormalizedTypeDeclaration nvarchar(4000) NULL
);

;WITH RawSourceColumns AS
(
    SELECT
          ROW_NUMBER() OVER (ORDER BY c.column_id) AS ColumnOrdinal
        , c.name AS ColumnName
        , CASE
              WHEN st.name = N''sysname'' AND c.system_type_id = 231
                  THEN N''nvarchar''
              WHEN st.is_user_defined = 1 AND st.is_assembly_type = 0
                  THEN bt.name
              ELSE st.name
          END AS TypeName
        , c.system_type_id AS SystemTypeId
        , c.max_length AS MaxLength
        , c.precision AS PrecisionValue
        , c.scale AS ScaleValue
        , c.is_nullable AS IsNullable
        , c.collation_name AS CollationName
        , c.is_identity AS IsIdentity
        , c.is_computed AS IsComputed
        , c.generated_always_type AS GeneratedAlwaysType
        , c.is_hidden AS IsHidden
        , c.is_column_set AS IsColumnSet
        , c.is_sparse AS IsSparse
        , c.encryption_type AS EncryptionType
        , ISNULL(st.is_assembly_type, 0) AS IsAssemblyType
        , ISNULL(st.is_user_defined, 0) AS IsUserDefined
        , c.xml_collection_id AS XmlCollectionId
    FROM ' + @SourceDatabaseQuoted + N'.sys.columns AS c
    LEFT JOIN ' + @SourceDatabaseQuoted + N'.sys.types AS st
        ON st.user_type_id = c.user_type_id
    LEFT JOIN ' + @SourceDatabaseQuoted + N'.sys.types AS bt
        ON bt.system_type_id = c.system_type_id
       AND bt.user_type_id = bt.system_type_id
    WHERE c.object_id = @SourceObjectId
)
INSERT INTO @SourceColumns
(
      ColumnOrdinal
    , ColumnName
    , TypeName
    , MaxLength
    , PrecisionValue
    , ScaleValue
    , IsNullable
    , CollationName
    , IsIdentity
    , IsComputed
    , GeneratedAlwaysType
    , IsHidden
    , IsColumnSet
    , IsSparse
    , EncryptionType
    , IsAssemblyType
    , IsUserDefined
    , XmlCollectionId
    , UnsupportedReason
    , NormalizedTypeDeclaration
)
SELECT
      r.ColumnOrdinal
    , r.ColumnName
    , r.TypeName
    , r.MaxLength
    , r.PrecisionValue
    , r.ScaleValue
    , r.IsNullable
    , r.CollationName
    , r.IsIdentity
    , r.IsComputed
    , r.GeneratedAlwaysType
    , r.IsHidden
    , r.IsColumnSet
    , r.IsSparse
    , r.EncryptionType
    , r.IsAssemblyType
    , r.IsUserDefined
    , r.XmlCollectionId
    , CASE
          WHEN r.IsIdentity = 1
              THEN N''Identity-Spalten sind nicht als Resultset-Shape unterstützt.''
          WHEN r.IsComputed = 1
              THEN N''Computed Columns sind nicht als Resultset-Shape unterstützt.''
          WHEN r.GeneratedAlwaysType <> 0
              THEN N''Generated-always-Spalten sind nicht als Resultset-Shape unterstützt.''
          WHEN r.IsHidden = 1
              THEN N''Hidden Columns sind nicht als Resultset-Shape unterstützt.''
          WHEN r.IsColumnSet = 1
              THEN N''XML Column Sets sind nicht als Resultset-Shape unterstützt.''
          WHEN r.EncryptionType IS NOT NULL
              THEN N''Verschlüsselte Spalten sind nicht als Resultset-Shape unterstützt.''
          WHEN r.SystemTypeId = 189
              THEN N''rowversion/timestamp ist nicht explizit einfügbar.''
          WHEN r.TypeName IN (N''text'', N''ntext'', N''image'')
              THEN N''Legacy-LOB-Typen text, ntext und image sind nicht unterstützt.''
          WHEN r.IsAssemblyType = 1
               AND (r.IsUserDefined = 1
                    OR r.TypeName NOT IN (N''hierarchyid'', N''geometry'', N''geography''))
              THEN N''Benutzerdefinierte oder unbekannte CLR Types sind nicht unterstützt.''
          WHEN r.TypeName IS NULL
               OR r.TypeName NOT IN
                  (
                        N''bigint'', N''binary'', N''bit'', N''char''
                      , N''date'', N''datetime'', N''datetime2'', N''datetimeoffset''
                      , N''decimal'', N''float'', N''geography'', N''geometry''
                      , N''hierarchyid'', N''int'', N''money'', N''nchar''
                      , N''numeric'', N''nvarchar'', N''real'', N''smalldatetime''
                      , N''smallint'', N''smallmoney'', N''sql_variant'', N''time''
                      , N''tinyint'', N''uniqueidentifier'', N''varbinary''
                      , N''varchar'', N''xml''
                  )
              THEN N''Der Datentyp ist in Contract-Version 1.0 nicht freigegeben.''
          ELSE NULL
      END AS UnsupportedReason
    , CASE
          WHEN r.TypeName IN (N''char'', N''varchar'', N''binary'', N''varbinary'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CASE
                         WHEN r.MaxLength = -1 THEN N''max''
                         ELSE CONVERT(nvarchar(10), r.MaxLength)
                     END
                   + N'')''
          WHEN r.TypeName IN (N''nchar'', N''nvarchar'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CASE
                         WHEN r.MaxLength = -1 THEN N''max''
                         ELSE CONVERT(nvarchar(10), r.MaxLength / 2)
                     END
                   + N'')''
          WHEN r.TypeName IN (N''decimal'', N''numeric'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CONVERT(nvarchar(10), r.PrecisionValue)
                   + N'',''
                   + CONVERT(nvarchar(10), r.ScaleValue)
                   + N'')''
          WHEN r.TypeName = N''float''
              THEN N''[float](''
                   + CONVERT(nvarchar(10), r.PrecisionValue)
                   + N'')''
          WHEN r.TypeName IN (N''time'', N''datetime2'', N''datetimeoffset'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CONVERT(nvarchar(10), r.ScaleValue)
                   + N'')''
          WHEN r.TypeName IN
               (
                     N''bigint'', N''bit'', N''date'', N''datetime''
                   , N''geography'', N''geometry'', N''hierarchyid'', N''int''
                   , N''money'', N''real'', N''smalldatetime'', N''smallint''
                   , N''smallmoney'', N''sql_variant'', N''tinyint''
                   , N''uniqueidentifier'', N''xml''
               )
              THEN QUOTENAME(r.TypeName)
          ELSE NULL
      END AS NormalizedTypeDeclaration
FROM RawSourceColumns AS r;

DECLARE @TargetColumns TABLE
(
      ColumnOrdinal   int      NOT NULL
    , ColumnName      sysname  NOT NULL
    , TypeName        sysname  NULL
    , MaxLength       smallint NOT NULL
    , PrecisionValue  tinyint  NOT NULL
    , ScaleValue      tinyint  NOT NULL
    , IsNullable      bit      NOT NULL
    , CollationName   sysname  NULL
    , IsInsertable    bit      NOT NULL
);

INSERT INTO @TargetColumns
(
      ColumnOrdinal
    , ColumnName
    , TypeName
    , MaxLength
    , PrecisionValue
    , ScaleValue
    , IsNullable
    , CollationName
    , IsInsertable
)
SELECT
      ROW_NUMBER() OVER (ORDER BY c.column_id)
    , c.name
    , CASE
          WHEN st.name = N''sysname'' AND c.system_type_id = 231
              THEN N''nvarchar''
          WHEN st.is_user_defined = 1 AND st.is_assembly_type = 0
              THEN bt.name
          ELSE st.name
      END
    , c.max_length
    , c.precision
    , c.scale
    , c.is_nullable
    , c.collation_name
    , CONVERT
      (
          bit,
          CASE
              WHEN c.is_identity = 0
               AND c.is_computed = 0
               AND c.generated_always_type = 0
               AND c.is_hidden = 0
               AND c.is_column_set = 0
               AND c.is_sparse = 0
               AND c.encryption_type IS NULL
               AND c.xml_collection_id = 0
               AND c.system_type_id <> 189
               AND NOT
                   (
                       st.is_assembly_type = 1
                       AND (st.is_user_defined = 1
                            OR st.name NOT IN (N''hierarchyid'', N''geometry'', N''geography''))
                   )
                  THEN 1
              ELSE 0
          END
      )
FROM tempdb.sys.columns AS c
LEFT JOIN tempdb.sys.types AS st
    ON st.user_type_id = c.user_type_id
LEFT JOIN tempdb.sys.types AS bt
    ON bt.system_type_id = c.system_type_id
   AND bt.user_type_id = bt.system_type_id
WHERE c.object_id = @TargetObjectId;

SELECT @SourceColumnCount = COUNT(*)
FROM @SourceColumns;

SELECT @TargetColumnCount = COUNT(*)
FROM @TargetColumns;

SELECT TOP (1)
      @UnsupportedColumnName = ColumnName
    , @UnsupportedReason = UnsupportedReason
FROM @SourceColumns
WHERE UnsupportedReason IS NOT NULL
   OR NormalizedTypeDeclaration IS NULL
ORDER BY ColumnOrdinal;

SELECT TOP (1)
      @InvalidCollationDetected = 1
    , @InvalidCollationName = CollationName
FROM @SourceColumns AS c
WHERE c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
  AND
  (
      c.CollationName IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM sys.fn_helpcollations() AS hc
             WHERE hc.name COLLATE Latin1_General_100_BIN2
                       = c.CollationName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY ColumnOrdinal;

SELECT @SchemaMatches =
    CONVERT
    (
        bit,
        CASE
            WHEN EXISTS
                 (
                     SELECT 1
                     FROM @SourceColumns AS s
                     FULL OUTER JOIN @TargetColumns AS t
                         ON t.ColumnOrdinal = s.ColumnOrdinal
                     WHERE s.ColumnOrdinal IS NULL
                        OR t.ColumnOrdinal IS NULL
                        OR s.ColumnName COLLATE Latin1_General_100_BIN2
                               <> t.ColumnName COLLATE Latin1_General_100_BIN2
                        OR ISNULL(s.TypeName, N'''') COLLATE Latin1_General_100_BIN2
                               <> ISNULL(t.TypeName, N'''') COLLATE Latin1_General_100_BIN2
                        OR s.MaxLength <> t.MaxLength
                        OR s.PrecisionValue <> t.PrecisionValue
                        OR s.ScaleValue <> t.ScaleValue
                        OR s.IsNullable <> t.IsNullable
                        OR ISNULL(s.CollationName, N'''') COLLATE Latin1_General_100_BIN2
                               <> ISNULL(t.CollationName, N'''') COLLATE Latin1_General_100_BIN2
                        OR t.IsInsertable <> 1
                 )
                THEN 0
            ELSE 1
        END
    );

SELECT @AddColumnsList =
    STUFF
    (
        (
            SELECT
                  N'', ''
                + QUOTENAME(c.ColumnName)
                + N'' ''
                + c.NormalizedTypeDeclaration
                + CASE
                      WHEN c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
                          THEN N'' COLLATE '' + c.CollationName
                      ELSE N''''
                  END
                + CASE WHEN c.IsNullable = 1 THEN N'' NULL'' ELSE N'' NOT NULL'' END
            FROM @SourceColumns AS c
            WHERE c.ColumnOrdinal < 1024
               OR @SourceColumnCount < 1024
            ORDER BY c.ColumnOrdinal
            FOR XML PATH(N''''), TYPE
        ).value(N''.'', N''nvarchar(max)'')
      , 1
      , 2
      , N''''
    );

SELECT @AddColumnAfterAnchor =
      QUOTENAME(c.ColumnName)
    + N'' ''
    + c.NormalizedTypeDeclaration
    + CASE
          WHEN c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
              THEN N'' COLLATE '' + c.CollationName
          ELSE N''''
      END
    + CASE WHEN c.IsNullable = 1 THEN N'' NULL'' ELSE N'' NOT NULL'' END
FROM @SourceColumns AS c
WHERE @SourceColumnCount = 1024
  AND c.ColumnOrdinal = 1024;

SELECT @DropColumnsList =
    STUFF
    (
        (
            SELECT N'', '' + QUOTENAME(c.ColumnName)
            FROM @TargetColumns AS c
            WHERE c.ColumnOrdinal < 1024
               OR @TargetColumnCount < 1024
            ORDER BY c.ColumnOrdinal
            FOR XML PATH(N''''), TYPE
        ).value(N''.'', N''nvarchar(max)'')
      , 1
      , 2
      , N''''
    );

SELECT @DropColumnBeforeAnchor = QUOTENAME(c.ColumnName)
FROM @TargetColumns AS c
WHERE @TargetColumnCount = 1024
  AND c.ColumnOrdinal = 1024;

SELECT @SourceMetadataDebug =
    STUFF
    (
        (
            SELECT
                  NCHAR(10)
                + CONVERT(nvarchar(10), c.ColumnOrdinal)
                + N'': ''
                + QUOTENAME(c.ColumnName)
                + N'' ''
                + ISNULL(c.NormalizedTypeDeclaration, N''<unsupported>'')
                + CASE
                      WHEN c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
                          THEN N'' COLLATE '' + ISNULL(c.CollationName, N''<NULL>'')
                      ELSE N''''
                  END
                + CASE WHEN c.IsNullable = 1 THEN N'' NULL'' ELSE N'' NOT NULL'' END
            FROM @SourceColumns AS c
            ORDER BY c.ColumnOrdinal
            FOR XML PATH(N''''), TYPE
        ).value(N''.'', N''nvarchar(max)'')
      , 1
      , 1
      , N''''
    );';

    BEGIN TRY
        EXEC sys.sp_executesql
              @Sql
            , N'@SourceObjectId int,
                @TargetObjectId int,
                @SourceColumnCount int OUTPUT,
                @TargetColumnCount int OUTPUT,
                @UnsupportedColumnName sysname OUTPUT,
                @UnsupportedReason nvarchar(4000) OUTPUT,
                @InvalidCollationDetected bit OUTPUT,
                @InvalidCollationName sysname OUTPUT,
                @SchemaMatches bit OUTPUT,
                @AddColumnsList nvarchar(max) OUTPUT,
                @AddColumnAfterAnchor nvarchar(4000) OUTPUT,
                @DropColumnsList nvarchar(max) OUTPUT,
                @DropColumnBeforeAnchor nvarchar(258) OUTPUT,
                @SourceMetadataDebug nvarchar(max) OUTPUT'
            , @SourceObjectId        = @SourceObjectId
            , @TargetObjectId        = @TargetObjectId
            , @SourceColumnCount     = @SourceColumnCount OUTPUT
            , @TargetColumnCount     = @TargetColumnCount OUTPUT
            , @UnsupportedColumnName = @UnsupportedColumnName OUTPUT
            , @UnsupportedReason     = @UnsupportedReason OUTPUT
            , @InvalidCollationDetected = @InvalidCollationDetected OUTPUT
            , @InvalidCollationName  = @InvalidCollationName OUTPUT
            , @SchemaMatches         = @SchemaMatches OUTPUT
            , @AddColumnsList        = @AddColumnsList OUTPUT
            , @AddColumnAfterAnchor  = @AddColumnAfterAnchor OUTPUT
            , @DropColumnsList       = @DropColumnsList OUTPUT
            , @DropColumnBeforeAnchor = @DropColumnBeforeAnchor OUTPUT
            , @SourceMetadataDebug   = @SourceMetadataDebug OUTPUT;
    END TRY
    BEGIN CATCH
        /*
         * Catalog- und Engine-Fehler werden nicht in einen scheinbar
         * erfolgreichen Validierungsstatus übersetzt. Die ursprüngliche
         * Fehlernummer bleibt durch THROW für den Aufrufer erhalten.
         */
        THROW;
    END CATCH;

    IF @SourceColumnCount IS NULL OR @SourceColumnCount = 0
    BEGIN
        THROW 51023, N'Die Referenztabelle besitzt keine sichtbaren Spalten oder ihre Metadaten sind nicht ausreichend sichtbar.', 1;
    END;

    IF @SourceColumnCount > 1024
    BEGIN
        THROW 51029, N'Das Referenzschema überschreitet das unterstützte Limit von 1024 ResultTable-Spalten.', 1;
    END;

    IF @TargetColumnCount > 1024
    BEGIN
        THROW 51029, N'Die Zieltable überschreitet das unterstützte Limit von 1024 ResultTable-Spalten.', 1;
    END;

    IF @UnsupportedColumnName IS NOT NULL
    BEGIN
        SET @ErrorMessage = N'Die Referenzspalte '
            + QUOTENAME(@UnsupportedColumnName)
            + N' ist nicht unterstützt. '
            + ISNULL(@UnsupportedReason, N'Es konnte keine sichere Typdeklaration erzeugt werden.');
        SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
        THROW 51024, @ErrorMessage, 1;
    END;

    IF @InvalidCollationDetected = 1
    BEGIN
        SET @ErrorMessage = N'Die Collation '
            + COALESCE(QUOTENAME(@InvalidCollationName), N'<NULL>')
            + N' kann nicht sicher für die ResultTable verwendet werden.';
        SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
        THROW 51027, @ErrorMessage, 1;
    END;

    IF @AddColumnsList IS NULL
       OR @DropColumnsList IS NULL
       OR (@SourceColumnCount = 1024 AND @AddColumnAfterAnchor IS NULL)
       OR (@TargetColumnCount = 1024 AND @DropColumnBeforeAnchor IS NULL)
       OR DATALENGTH(@AddColumnsList) > 2000000
       OR DATALENGTH(@DropColumnsList) > 2000000
       OR DATALENGTH(ISNULL(@AddColumnAfterAnchor, N'')) > 8000
    BEGIN
        THROW 51029, N'Das intern erzeugte DDL ist unvollständig oder überschreitet 1.000.000 Unicode-Zeichen je Spaltenliste.', 1;
    END;

    DECLARE @TargetHasRows bit;
    SET @Sql = N'SELECT @HasRows = CONVERT(bit, CASE WHEN EXISTS (SELECT 1 FROM '
        + @TargetQuotedName
        + N') THEN 1 ELSE 0 END);';

    EXEC sys.sp_executesql
          @Sql
        , N'@HasRows bit OUTPUT'
        , @HasRows = @TargetHasRows OUTPUT;

    IF @Debug >= 2
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: TargetObjectId='
            + CONVERT(nvarchar(20), @TargetObjectId)
            + N', SourceObjectId='
            + CONVERT(nvarchar(20), @SourceObjectId)
            + N', SourceIsLocal='
            + CONVERT(nvarchar(1), @SourceIsLocal)
            + N', TargetHasRows='
            + CONVERT(nvarchar(1), @TargetHasRows)
            + N', SchemaMatches='
            + CONVERT(nvarchar(1), @SchemaMatches)
            + N'.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    IF @Debug >= 3 AND @SourceMetadataDebug IS NOT NULL
    BEGIN
        SET @DebugMessage = N'USP_PrepareResultTable: normalisierte Referenzmetadaten:'
            + NCHAR(10)
            + @SourceMetadataDebug;

        WHILE DATALENGTH(@DebugMessage) > 0
        BEGIN
            SET @DebugChunk = LEFT(@DebugMessage, 1800);
            RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
            SET @DebugMessage = SUBSTRING(@DebugMessage, 1801, 2147483647);
        END;
    END;

    /*
     * @KeepData = 1 darf bei abweichendem Schema niemals einen Teilumbau
     * auslösen. Der Fehler erfolgt deshalb vor Dependency-Prüfung, Datenlöschung
     * und Transaktionsbeginn und lässt die Zieltable vollständig unverändert.
     */
    IF @SchemaMatches = 0 AND @TargetHasRows = 1 AND @KeepData = 1
    BEGIN
        THROW 51025, N'@KeepData = 1 kann vorhandene Daten bei abweichendem Ziel- und Referenzschema nicht sicher erhalten.', 1;
    END;

    DECLARE
          @BlockerType sysname
        , @BlockerName sysname;

    IF @SchemaMatches = 0
    BEGIN
        /*
         * Der in-place-Algorithmus ersetzt alle alten Spalten. Daher blockiert
         * jedes Objekt, das an einer dieser Spalten hängt. Es wird bewusst
         * nichts automatisch gedroppt oder nachgebaut.
         */
        SELECT TOP (1)
              @BlockerType = d.BlockerType
            , @BlockerName = d.BlockerName
        FROM
        (
            SELECT
                  10 AS PriorityValue
                , CONVERT(sysname, N'INDEX') AS BlockerType
                , i.name AS BlockerName
            FROM tempdb.sys.indexes AS i
            WHERE i.object_id = @TargetObjectId
              AND i.index_id > 0
              AND i.is_hypothetical = 0

            UNION ALL

            SELECT
                  20
                , CONVERT(sysname, N'DEFAULT_CONSTRAINT')
                , dc.name
            FROM tempdb.sys.default_constraints AS dc
            WHERE dc.parent_object_id = @TargetObjectId

            UNION ALL

            SELECT
                  30
                , CONVERT(sysname, N'CHECK_CONSTRAINT')
                , cc.name
            FROM tempdb.sys.check_constraints AS cc
            WHERE cc.parent_object_id = @TargetObjectId

            UNION ALL

            SELECT
                  40
                , CONVERT(sysname, N'FOREIGN_KEY')
                , fk.name
            FROM tempdb.sys.foreign_keys AS fk
            WHERE fk.parent_object_id = @TargetObjectId
               OR fk.referenced_object_id = @TargetObjectId

            UNION ALL

            SELECT
                  50
                , CONVERT(sysname, N'COMPUTED_COLUMN')
                , c.name
            FROM tempdb.sys.columns AS c
            WHERE c.object_id = @TargetObjectId
              AND c.is_computed = 1

            UNION ALL

            SELECT
                  60
                , CONVERT(sysname, N'BOUND_DEFAULT_OR_RULE')
                , c.name
            FROM tempdb.sys.columns AS c
            WHERE c.object_id = @TargetObjectId
              AND (c.default_object_id <> 0 OR c.rule_object_id <> 0)

            UNION ALL

            SELECT
                  70
                , CONVERT(sysname, N'TRIGGER')
                , tr.name
            FROM tempdb.sys.triggers AS tr
            WHERE tr.parent_id = @TargetObjectId

            UNION ALL

            SELECT
                  80
                , CONVERT(sysname, N'USER_STATISTICS')
                , st.name
            FROM tempdb.sys.stats AS st
            WHERE st.object_id = @TargetObjectId
              AND st.user_created = 1
        ) AS d
        ORDER BY
              d.PriorityValue
            , d.BlockerName COLLATE Latin1_General_100_BIN2;

        IF @BlockerType IS NOT NULL
        BEGIN
            SET @ErrorMessage = N'Der Schemaumbau von '
                + @TargetQuotedName
                + N' wird durch '
                + @BlockerType
                + N' '
                + COALESCE(QUOTENAME(@BlockerName), N'<unbenannt>')
                + N' blockiert. Das abhängige Objekt muss der Aufrufer vor dem erneuten Aufruf kontrolliert entfernen.';
            SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
            THROW 51026, @ErrorMessage, 1;
        END;
    END;

    DECLARE @MutationRequired bit =
        CONVERT
        (
            bit,
            CASE
                WHEN @SchemaMatches = 0 THEN 1
                WHEN @TargetHasRows = 1 AND @KeepData = 0 THEN 1
                ELSE 0
            END
        );

    IF @MutationRequired = 0
    BEGIN
        IF @Debug >= 1
        BEGIN
            SET @DebugChunk = N'USP_PrepareResultTable: Schema und Datenzustand erfordern keine Mutation.';
            RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
        END;

        RETURN 0;
    END;

    IF XACT_STATE() = -1
    BEGIN
        THROW 51028, N'Der aktuelle uncommittable Transaktionszustand erlaubt keine kontrollierte ResultTable-Mutation.', 1;
    END;

    DECLARE
          @InvocationToken       varchar(32) = REPLACE(CONVERT(varchar(36), NEWID()), '-', '')
        , @AnchorColumnName      sysname
        , @SavepointName         varchar(32)
        , @StartedTransaction    bit = 0
        , @ClearMethod           varchar(16)
        , @DropBeforeAnchorSql   nvarchar(max)
        , @AddAnchorSql          nvarchar(max)
        , @DropOldColumnsSql     nvarchar(max)
        , @AddNewColumnsSql      nvarchar(max)
        , @DropAnchorSql         nvarchar(max)
        , @AddAfterAnchorSql     nvarchar(max)
        , @TruncateSql           nvarchar(max);

    SET @AnchorColumnName = CONVERT(sysname, N'tbx_anchor_' + @InvocationToken);

    WHILE EXISTS
    (
        SELECT 1
        FROM tempdb.sys.columns AS c
        WHERE c.object_id = @TargetObjectId
          AND c.name COLLATE Latin1_General_100_BIN2
                  = @AnchorColumnName COLLATE Latin1_General_100_BIN2
    )
    BEGIN
        SET @InvocationToken = REPLACE(CONVERT(varchar(36), NEWID()), '-', '');
        SET @AnchorColumnName = CONVERT(sysname, N'tbx_anchor_' + @InvocationToken);
    END;

    SET @SavepointName = CONVERT(varchar(32), 'tbx_rtbl_' + LEFT(@InvocationToken, 23));
    IF @DropColumnBeforeAnchor IS NOT NULL
    BEGIN
        SET @DropBeforeAnchorSql = N'ALTER TABLE '
            + @TargetQuotedName
            + N' DROP COLUMN '
            + @DropColumnBeforeAnchor
            + N';';
    END;

    SET @AddAnchorSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' ADD '
        + QUOTENAME(@AnchorColumnName)
        + N' bit NULL;';
    SET @DropOldColumnsSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' DROP COLUMN '
        + @DropColumnsList
        + N';';
    SET @AddNewColumnsSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' ADD '
        + @AddColumnsList
        + N';';
    SET @DropAnchorSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' DROP COLUMN '
        + QUOTENAME(@AnchorColumnName)
        + N';';
    IF @AddColumnAfterAnchor IS NOT NULL
    BEGIN
        SET @AddAfterAnchorSql = N'ALTER TABLE '
            + @TargetQuotedName
            + N' ADD '
            + @AddColumnAfterAnchor
            + N';';
    END;

    SET @TruncateSql = N'TRUNCATE TABLE ' + @TargetQuotedName + N';';

    IF @Debug >= 3
    BEGIN
        SET @DebugMessage = N'USP_PrepareResultTable: geplantes DDL:'
            + NCHAR(10)
            + CASE
                  WHEN @SchemaMatches = 0
                      THEN COALESCE(@DropBeforeAnchorSql + NCHAR(10), N'')
                           + @AddAnchorSql + NCHAR(10)
                           + @DropOldColumnsSql + NCHAR(10)
                           + @AddNewColumnsSql + NCHAR(10)
                           + @DropAnchorSql
                           + COALESCE(NCHAR(10) + @AddAfterAnchorSql, N'')
                  WHEN @TargetHasRows = 1 AND @KeepData = 0
                      THEN @TruncateSql
                  ELSE N'<keine Mutation>'
              END;

        WHILE DATALENGTH(@DebugMessage) > 0
        BEGIN
            SET @DebugChunk = LEFT(@DebugMessage, 1800);
            RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
            SET @DebugMessage = SUBSTRING(@DebugMessage, 1801, 2147483647);
        END;
    END;

    /*
     * Erst ab hier beginnt die Mutation. Eine vorhandene Caller-Transaktion
     * erhält ausschließlich einen Invocation-spezifischen Savepoint. Die
     * Procedure committed oder rollt niemals die vollständige Caller-
     * Transaktion zurück.
     */
    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @StartedTransaction = 1;
        END;
        ELSE
        BEGIN
            SAVE TRANSACTION @SavepointName;
        END;

        IF @TargetHasRows = 1 AND @KeepData = 0
        BEGIN
            /*
             * Eine lokale ResultTable muss truncatable sein. Verhindert die
             * Engine TRUNCATE dennoch, liegt ein nicht unterstützter Zustand
             * vor. Der Originalfehler wird nach dem Rollback unverändert
             * weitergegeben; ein DELETE-Fallback ist ausdrücklich unzulässig.
             */
            EXEC sys.sp_executesql @TruncateSql;
            SET @ClearMethod = 'TRUNCATE';
        END;

        IF @SchemaMatches = 0
        BEGIN
            /*
             * Bei exakt 1024 Ziel- oder Quellspalten wird der Umbau geteilt:
             * eine alte Spalte weicht vor der Anchor-Spalte beziehungsweise
             * die letzte neue Spalte folgt erst nach deren Entfernung. Dadurch
             * entstehen zu keinem Zeitpunkt mehr als 1024 Spalten.
             */
            IF @DropBeforeAnchorSql IS NOT NULL
            BEGIN
                EXEC sys.sp_executesql @DropBeforeAnchorSql;
            END;

            EXEC sys.sp_executesql @AddAnchorSql;
            EXEC sys.sp_executesql @DropOldColumnsSql;
            EXEC sys.sp_executesql @AddNewColumnsSql;
            EXEC sys.sp_executesql @DropAnchorSql;

            IF @AddAfterAnchorSql IS NOT NULL
            BEGIN
                EXEC sys.sp_executesql @AddAfterAnchorSql;
            END;
        END;

        IF @StartedTransaction = 1
        BEGIN
            COMMIT TRANSACTION;
        END;
    END TRY
    BEGIN CATCH
        DECLARE
              @OriginalErrorNumber  int = ERROR_NUMBER()
            , @OriginalErrorMessage nvarchar(2048) = ERROR_MESSAGE();

        IF @StartedTransaction = 1 AND XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;
        ELSE IF @StartedTransaction = 0 AND XACT_STATE() = 1
        BEGIN
            BEGIN TRY
                ROLLBACK TRANSACTION @SavepointName;
            END TRY
            BEGIN CATCH
                SET @ErrorMessage = N'Der ResultTable-Fehler '
                    + CONVERT(nvarchar(20), @OriginalErrorNumber)
                    + N' konnte wegen Rollback-Fehler '
                    + CONVERT(nvarchar(20), ERROR_NUMBER())
                    + N' nicht kontrolliert zum Savepoint zurückgerollt werden. Ursprüngliche Meldung: '
                    + LEFT(@OriginalErrorMessage, 1200);
                SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
                THROW 51028, @ErrorMessage, 1;
            END CATCH;
        END;

        /*
         * Bei XACT_STATE() = -1 wird kein unzulässiger Savepoint-Rollback
         * versucht. THROW ohne Argumente erhält den ursprünglichen Engine-
         * oder Modulfehler samt Nummer, State und Procedure-Kontext.
         */
        THROW;
    END CATCH;

    IF @Debug >= 2 AND @ClearMethod IS NOT NULL
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: vorhandene Daten wurden mit '
            + @ClearMethod
            + N' entfernt.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    IF @Debug >= 1
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: Vorbereitung erfolgreich abgeschlossen.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    RETURN 0;
END;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    DECLARE
          @ProcedureId          int =
              OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable', N'P')
        , @DeploymentMode       nvarchar(16)
        , @TargetVersion        nvarchar(64)
        , @SourceHash           varchar(64)
        , @VersionPropertyName  sysname =
              N'Toolbelt.Module.toolbelt.core.result-table.Version'
        , @ModePropertyName     sysname =
              N'Toolbelt.Module.toolbelt.core.result-table.DeploymentMode';

    SELECT
          @DeploymentMode = DeploymentMode
        , @TargetVersion = TargetVersion
    FROM #tbx_ResultTableDeployState;

    IF XACT_STATE() <> 1 OR @ProcedureId IS NULL
    BEGIN
        THROW 51038, N'Die Framework-Procedure wurde nicht vollständig innerhalb der Deployment-Transaktion angelegt.', 1;
    END;

    SET @SourceHash = CONVERT
    (
          varchar(64)
        , HASHBYTES
          (
              N'SHA2_256'
            , CONVERT(varbinary(max), OBJECT_DEFINITION(@ProcedureId))
          )
        , 2
    );

    DECLARE @ObjectProperties TABLE
    (
          PropertyOrdinal int IDENTITY(1, 1) NOT NULL
        , PropertyName    sysname            NOT NULL
        , PropertyValue   nvarchar(4000)     NOT NULL
    );

    INSERT INTO @ObjectProperties (PropertyName, PropertyValue)
    VALUES
          (N'Toolbelt.ModuleId', N'toolbelt.core.result-table')
        , (N'Toolbelt.ModuleVersion', @TargetVersion)
        , (N'Toolbelt.ContractVersion', N'1.0')
        , (N'Toolbelt.DeploymentMode', @DeploymentMode)
        , (N'Toolbelt.SourceHash', CONVERT(nvarchar(4000), @SourceHash));

    DECLARE
          @PropertyOrdinal int = 1
        , @PropertyCount   int = (SELECT COUNT(*) FROM @ObjectProperties)
        , @PropertyName    sysname
        , @PropertyValue   nvarchar(4000);

    WHILE @PropertyOrdinal <= @PropertyCount
    BEGIN
        SELECT
              @PropertyName = PropertyName
            , @PropertyValue = PropertyValue
        FROM @ObjectProperties
        WHERE PropertyOrdinal = @PropertyOrdinal;

        IF EXISTS
           (
               SELECT 1
               FROM sys.extended_properties AS ep
               WHERE ep.class = 1
                 AND ep.major_id = @ProcedureId
                 AND ep.minor_id = 0
                 AND ep.name = @PropertyName
           )
        BEGIN
            EXEC sys.sp_updateextendedproperty
                  @name       = @PropertyName
                , @value      = @PropertyValue
                , @level0type = N'SCHEMA'
                , @level0name = N'toolbelt_core'
                , @level1type = N'PROCEDURE'
                , @level1name = N'USP_PrepareResultTable';
        END;
        ELSE
        BEGIN
            EXEC sys.sp_addextendedproperty
                  @name       = @PropertyName
                , @value      = @PropertyValue
                , @level0type = N'SCHEMA'
                , @level0name = N'toolbelt_core'
                , @level1type = N'PROCEDURE'
                , @level1name = N'USP_PrepareResultTable';
        END;

        SET @PropertyOrdinal += 1;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 0
             AND ep.major_id = 0
             AND ep.minor_id = 0
             AND ep.name = @VersionPropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 0
             AND ep.major_id = 0
             AND ep.minor_id = 0
             AND ep.name = @ModePropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.core.result-table
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.archive.zip-memory
:On Error exit
-- RAISERROR statt THROW: Caller-Transaktionen bei XACT_ABORT ON nicht beschädigen.
IF @@TRANCOUNT<>0
BEGIN
    RAISERROR(N'TBX_ZIP_LIFECYCLE_CALLER_TRANSACTION: Deploy benötigt einen eigenen Transaktionsscope.',16,1);
    RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @VersionProperty sysname =
          N'Toolbelt.Module.toolbelt.archive.zip-memory.Version'
    , @ModeProperty sysname =
          N'Toolbelt.Module.toolbelt.archive.zip-memory.DeploymentMode'
    , @DependencyVersionProperty sysname =
          N'Toolbelt.Module.toolbelt.core.result-table.Version'
    , @AssemblyName sysname =
          N'Toolbelt_Archive_ZipMemory'
    , @DeploymentMode nvarchar(16) =
          LOWER(N'local')
    , @InstalledVersion nvarchar(64)
    , @ProductMajorVersion int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @AssemblyBits varbinary(max) =
          0x4d5a90000300000004000000ffff0000b800000000000000400000000000000000000000000000000000000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a2400000000000000504500004c010300c912bb900000000000000000e00022200b013000009600000008000000000000deb400000020000000c00000000000100020000000020000040000000000000006000000000000000000010000020000000000000300608500001000001000000000100000100000000000001000000000000000000000008cb400004f00000000c00000580400000000000000000000000000000000000000e000000c00000070b400001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000080000000000000000000000082000004800000000000000000000002e74657874000000e4940000002000000096000000020000000000000000000000000000200000602e727372630000005804000000c000000006000000980000000000000000000000000000400000402e72656c6f6300000c00000000e0000000020000009e00000000000000000000000000004000004200000000000000000000000000000000c0b40000000000004800000002000500e04e00009065000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001b3005007a00000001000011020304050e0428050000060ade610b076f90000006076f0d00000a286b0000060ade4c262079c800007201000070286b0000060ade39262079c80000727d000070286b0000060ade26262079c8000072f9000070286b0000060ade13262079c800007273010070286b0000060ade00178d07000002251606a22a000001400000000000000e0e001509000002000000000e23001317000001000000000e36001318000001000000000e49001319000001000000000e5c00131a0000011b3004007800000002000011020328060000060bde6c0c086f90000006086f0d00000a288c0000060ade4c262079c8000072e9010070288c0000060ade39262079c80000727d000070288c0000060ade26262079c8000072f9000070288c0000060ade13262079c800007273010070288c0000060ade00178d08000002251606a22a072a01400000000000000a0a001509000002000000000a1f001317000001000000000a32001318000001000000000a45001319000001000000000a5800131a000001133002008e010000030000110274070000020a03066f590000060b1201280e00000a2d077e0f00000a2b13066f590000060b1201281000000a731100000a811b00000104066f5b0000062c0d066f5b000006731200000a2b057e1300000a811300000105066f5d0000062c0d066f5d000006731200000a2b057e1300000a81130000010e04066f5f0000060c1202281400000a2d077e1500000a2b13066f5f0000060c1202281600000a731700000a81140000010e05066f610000060c1202281400000a2d077e1500000a2b13066f610000060c1202281600000a731700000a81140000010e06066f630000060b1201280e00000a2d077e0f00000a2b13066f630000060b1201281000000a731100000a811b0000010e07066f650000060b1201280e00000a2d077e0f00000a2b13066f650000060b1201281000000a731100000a811b0000010e08066f670000060d1203281800000a2d077e1900000a2b13066f670000060d1203281a00000a731b00000a81160000010e09066f690000062c0d066f69000006731c00000a2b057e1d00000a811c0000012a00001330020090020000040000110274080000020a03066f6e0000060b1201280e00000a2d077e0f00000a2b13066f6e0000060b1201281000000a731100000a811b00000104066f700000062c0d066f70000006731200000a2b057e1300000a811300000105066f720000060b1201280e00000a2d077e0f00000a2b13066f720000060b1201281000000a731100000a811b0000010e04066f740000062c0d066f74000006731200000a2b057e1300000a81130000010e05066f760000060c1202281800000a2d077e1900000a2b13066f760000060c1202281a00000a731b00000a81160000010e06066f780000060d1203281400000a2d077e1500000a2b13066f780000060d1203281600000a731700000a81140000010e07066f7a0000060d1203281400000a2d077e1500000a2b13066f7a0000060d1203281600000a731700000a81140000010e08066f7c0000060b1201280e00000a2d077e0f00000a2b13066f7c0000060b1201281000000a731100000a811b0000010e09066f7e0000060b1201280e00000a2d077e0f00000a2b13066f7e0000060b1201281000000a731100000a811b0000010e0a066f800000060c1202281800000a2d077e1900000a2b13066f800000060c1202281a00000a731b00000a81160000010e0b066f820000060c1202281800000a2d077e1900000a2b13066f820000060c1202281a00000a731b00000a81160000010e0c066f840000060b1201280e00000a2d077e0f00000a2b13066f840000060b1201281000000a731100000a811b0000010e0d066f860000060c1202281800000a2d077e1900000a2b13066f860000060c1202281a00000a731b00000a81160000010e0e066f880000062c0d066f88000006731200000a2b057e130000\
0a81130000010e0f066f8a000006810400001b2a1b3007009902000005000011022c10026f1e00000a2d08026f1f00000a2d102078c800007267020070738f0000067a0f01282000000a2d0e0f01282100000a6f2200000a2d102078c8000072e1020070738f0000067a0f01282100000a6f2200000a200004000031102078c80000721d030070738f0000067a0f02282300000a2d1a0f02282400000a166a310f0f02282400000a20000000046a31102078c800007281030070738f0000067a0f03282500000a2d130f03282600000a7e2700000a282800000a2c102078c8000072e9030070738f0000067a0f04282900000a2c102078c800007253040070738f0000067a026f1f00000a20000000106a3110207dc8000072a1040070738f0000067a026f2a00000a0a140b066f2b00000a2d0f06026f1f00000a28070000060b070a06026f1f00000a73200000060c080f01282100000a28080000060d096f4a0000061f415f16fe032c450f04282c00000a2c10207cc80000723c050070738f0000067a096f42000006096f4e000006096f50000006096f48000006096f4c0000061714286c0000061306dd05010000096f480000062c19096f480000061e2e10207fc800007298050070738f0000067a096f500000060f02282400000a3110207dc800007235060070738f0000067a096f4e00000620000000086a3110207dc80000728d060070738f0000067a096f50000006096f4e0000060f03282600000a280e0000060809280c00000608090f02282400000a0f03282600000a14280d000006130411048e6a096f500000062e102080c80000723a070070738f0000067a110414281000000613051105096f4c0000062e102080c8000072ef070070738f0000067a096f42000006096f4e000006096f50000006096f480000061105161104286c0000061306de0a072c06076f2d00000adc11062a000000411c0000020000000c010000800100008c0200000a000000000000001b300f00f401000006000011022c10026f1e00000a2d08026f1f00000a2d102078c800007267020070738f0000067a0f01282e00000a2d180f01282f00000a17320e0f01282f00000a201027000031102078c800007276080070738f0000067a026f1f00000a20000000106a3110207dc8000072a1040070738f0000067a026f2a00000a0a140b066f2b00000a2d0f06026f1f00000a28070000060b070a06026f1f00000a73200000060c0828160000060d096f390000062d0c280100002b1307dd37010000096f390000060f01282f00000a3110207dc8000072d2080070738f0000067a0809142809000006130411046f3100000a2d0c280100002b1307ddf90000001104280a000006130511046f3100000a8d08000002130616130838bc000000110411086f3200000a130911096f4a0000061f415f16fe03130a11096f42000006280b000006130b1106110811096f4000000611096f4200000611096f5800000611096f4e00000611096f5000000611096f4800000611096f4c000006110a11096f480000062c0a11096f480000061e3307110a16fe012b0116110511096f420000066f3300000a2d03172b0e110511096f420000066f3400000a110b723e090070283500000a110b11096f52000006288d000006a2110817581308110811046f3100000a3f36ffffff11061307de0a072c06076f2d00000adc11072a411c0000020000007b0000006c010000e70100000a000000000000001330040084000000070000110320ffffff7f6a3103162b020369733600000a0a20004001008d360000010b166a0c020716078e696f3700000a0d092c2f08096a580c0820000000106a3116066f2d00000a207dc800007248090070738f0000067a060716096f3800000a2bc208032e16066f2d00000a2079c8000072ba090070738f0000067a06166a6f3900000a062a1330030073000000080000110228160000060a02061428090000060b140c160d1613042b3b0711046f3200000a130511056f42000006031a283a00000a2c1b0917580d09173110207bc8000072530a0070738f0000067a11050c1104175813041104076f3100000a32bb082d10207ac8000072d10a0070738f0000067a082a0013300b001f02000009000011036f3b000006036f3d000006580a036f3900000620102700003110207dc8000072330b0070738f0000067a06036f370000062e10207fc8000072c40b0070738f0000067a036f3b0000060b036f39000006733b00000a0c160d389f010000042c06046f3c00000a02071f2e6a6f2600000602076f2400000620504b01022e102079c8000072810c0070738f0000067a02071e6a586f23000006130402071f0a6a586f23000006130502071f106a586f24000006130602071f146a586f24000006130702071f186a586f24000006130802071f1c6a586f23000006130902071f1e6a586f23000006130a02071f206a586f23000006130b02071f226a586f23000006130c02071f2a6a586f24000006130d02071f0c6a586f23000006130e02071f0e6a586f23000006130f1107152e131108152e0e110d152e09110c20ffff00003310207fc8000072fd0c0070738f0000067a110c2c10207fc8000072710d0070738f0000067a1f2e6a11096a58110a6a58110b6a581310020711106f2600000602071f2e6a5811096f25000006131111111104280f000006131211126f2200000a20000400003110207dc8000072d30d0070738f0000067a09175811121111110d6e11051104110611076e11086e110f110e2811000006036f3b000006733f0000061313021113280c0000060811136f\
3d00000a071110580b0917580d09036f390000063f55feffff07062e102079c8000072580e0070738f0000067a082a00133004004a0000000a000011283e00000a733f00000a0a160b2b3002076f3200000a6f420000060c060812036f4000000a2d0a0608176f4100000a2b0a06080917586f4200000a0717580b07026f3100000a32c7062a0000133003006c01000000000000026f2200000a18321f02166f4300000a284400000a2c1102176f4300000a1f3a330672b40e00702a026f2200000a16311c02166f4300000a1f2f2e0b02166f4300000a1f5c330672d40e00702a0272e60e0070283500000a2d720272ec0e00701a6f4500000a162f630272f40e00701a6f4500000a162f540272fc0e00701a6f4500000a162f450272060f00701a6f4500000a162f360272ec0e00701a6f4600000a2d280272f40e00701a6f4600000a2d1a0272100f00706f4700000a2d0d0272180f00706f4700000a2c0672200f00702a026f2200000a39830000000272420f0070283500000a2d760272460f00701a6f4600000a2d6802724c0f00701a6f4800000a2d5a0272520f00701a6f4500000a162f4b0272560f00701a6f4500000a162f3c02725c0f00701a6f4500000a162f2d0272640f00701a6f4500000a162f1e02726c0f00701a6f4500000a162f0f0272720f00701a6f4500000a16320672780f00702a723e0900702a13300500760100000b000011036f460000060a02061f1e6a6f2600000602066f2400000620504b03042e102079c8000072920f0070738f0000067a02061c6a586f2300000602061e6a586f230000060b02061f0e6a586f240000060c02061f126a586f240000060d02061f166a586f24000006130402061f1a6a586f23000006130502061f1c6a586f23000006130625204f0800005f036f4a000006204f0800005f2e102079c800007200100070738f0000067a07036f480000062e102079c8000072a9100070738f0000067a061f1e6a5811056a5811066a58130702061f1e6a5811056a11066a586f26000006021107036f4e0000066f2600000602061f1e6a5811056f25000006036f4400000628130000062d102079c80000724a110070738f0000067a1107036f4e00000658036f5400000631102079c8000072db110070738f0000067a1e5f2d2e08036f4c0000063315096e036f4e000006330b11046e036f500000062e102079c80000724f120070738f0000067a0311076f570000062a00001b300500480100000c00001102036f56000006036f4e0000066f270000060a04176a32120420000000046a3009036f50000006043110207dc8000072f0120070738f0000067a036f50000006b78d360000010b060c140d166a1304036f480000061e330d061617734900000a0d090c2b1e036f4e000006036f500000062e102080c80000725a130070738f0000067a20004001008d360000011305166a13060e042c070e046f3c00000a0811051611058e696f3700000a130711072d02de54110611076a5813061106130411060430071106078e6a3110207dc8000072f7130070738f0000067a1106036f4e00000605280e00000611051607110611076adab71107284a00000a2b96092c06096f2d00000adc066f290000062c102079c800007265140070738f0000067a078e6a11042e102079c8000072d9140070738f0000067a071308de0a062c06066f4b00000adc11082a41340000020000004f000000ae000000fd0000000a000000000000000200000013000000280100003b0100000a00000000000000133002004100000000000000022d012a032d10207ec800007257150070738f0000067a02284c00000a03284c00000a284d00000a04284e00000a2c10207ec8000072f0150070738f0000067a2a860320000800005f2d0c7e15000004026f4f00000a2a7e14000004026f4f00000a2a00133004003b0000000d000011150a160b2b2c032c0f0720ffff00005f2d06036f3c00000a7e16000004060207916120ff0000005f95061e64610a0717580b07028e6932ce06662a001b300600a30000000e000011031f1f5f185a0a031b631f3f5f0b031f0b631f1f5f0c021f1f5f0d021b631f0f5f130420bc070000021f09631f7f5f581305032d0e022d0b1206fe150400001b11062a081f173027071f3b3022061f3b301d110417321811041f0c30120917320e091f1f30091105203b080000310b1206fe150400001b11062a001105110409080706735000000a735100000a1306de0f261207fe150400001b11071306de0011062a000110000000007b001691000f2700000113300300430000000f00001120000100008d3e0000010a160b2b2a070c160d2b1808175f2d050817642b09202083b8ed081764610c0917580d091e32e40607089e0717580b076e068e696a32ce062a00133003002400000010000011028e69038e692e02162a160a2b0e0206910306912e02162a0617580a06028e6932ec172a3202039102031758911e62602a7a02039102031758911e626002031858911f10626002031958911f1862602a133004005e01000011000011026f210000061f166a2f102079c800007254160070738f0000067a026f2100000620150001006a285200000a690a026f21000006066a590b0207066f250000060c088e691f16590d38fa0000000809281500000620504b050640e500000008091f145828140000061304091f1658110458088e6940ca00000007096a58130508091a58281400000608091c582814000006130608091e582814000006130708091f0a582814000006130808091f0c582815000006130908091f10582815000006130a2d0a\
11062d06110711082e10207fc8000072710d0070738f0000067a110720ffff00002e13110820ffff00002e0a1109152e05110a153310207fc8000072fd0c0070738f0000067a110a6e11096e58130b110b1105300a110b026f2100000631102079c8000072d0160070738f0000067a11051108110a6e11096e73360000062a0917590d09163cfffeffff2079c800007234170070738f0000067a0000133002001d0100001200001102390901000002282200000a0b071d3ba5000000071f0c59450600000005000000da0000001c000000da000000330000009300000038d50000000216284300000a0c081f462e45081f492e2e38be0000000216284300000a0c081f442e3d081f522e4738a700000002729e170070283500000a2d6238950000000272c0170070283500000a2d5838830000000272da170070283500000a2d5e2b740272f4170070283500000a2d3f2b65027212180070283500000a2d382b56027230180070283500000a2d392b47027240180070283500000a2d322b382096c800000a2b362098c800000a2b2e2099c800000a2b26209ac800000a2b1e209bc800000a2b16209cc800000a2b0e209ec800000a2b06209fc800000a020673920000062a0000001b3004007700000013000011739300000625285300000a7d470000040a06026f5400000a7d47000004de4d0b06077b440000047d4500000406076f0d00000a7d46000004de322606209bc800007d450000040672641800707d46000004de192606209ec800007d450000040672ce1800707d46000004de00178d0b000002251606a22a0001280000000011000e1f001b0a000002000011000e3a001929000001000011000e530019190000019273a200000625027d5900000425037d5a000004fe06a3000006735500000a28180000062a000000133003005a0000000000000073a400000625027d5b00000425037d5c00000425047d5d00000425057d5e000004250e047d5f000004250e057d60000004250e067d61000004250e077d62000004250e087d63000004fe06a5000006735500000a28180000062a000013300200410000001400001102740b0000020a03067b45000004731100000a811b00000104067b460000042c0d067b46000004731200000a2b057e1300000a811300000105067b47000004512a0000001b30050013010000150000110f00282000000a2d210f01282e00000a2d180f01282f00000a17320e0f01282f00000a2000080000310b72c017007028170000067a0f00282100000a0a066f2200000a2c4c066f2200000a0f01282f00000a303d06166f4300000a1f2f2e3206066f2200000a17596f4300000a1f2f2e20061f5c6f5600000a162f15061f3a6f5600000a162f0a06166f5600000a16320b72c017007028170000067a06178d3a00000125161f2f9d6f5700000a0b160c2b3507089a0d096f2200000a2c1a0972420f0070283500000a2d0d0972e60e0070283500000a2c0b72c017007028170000067a0817580c08078e6932c5001617735800000a066f5900000a735a00000a1304de0c2672c017007028170000067a11042a00011000000000ee001604010c2a0000011b3006001106000016000011026f1e00000a3a2f0100000f01282e00000a3a230100000f01282f00000a2c0d0f01282f00000a1e400d0100000f02282e00000a3a010100000f02282f00000a173ff40000000f02282f00000a20000400003de30000000f03282e00000a3ad70000000f03282f00000a173fca0000000f03282f00000a20000800003db90000000f04282300000a3aad0000000f04282400000a176a3f9f0000000f04282400000a20000000026a3d8d0000000f05282300000a3a810000000f05282400000a176a32760f05282400000a20000000086a30670f06282300000a2d5e0f06282400000a176a32530f06282400000a20000000096a30440f07282300000a2d3b0f07282400000a176a32300f07282400000a20000080086a30210f08282e00000a2d180f08282f00000a17320e0f08282f00000a2060ea0000310b729e17007028170000067a0f08282f00000a73950000060a026f1f00000a0f07282400000a310b721218007028170000067a0f07282400000a0673970000060b026f2a00000a0c086f2b00000a2c0808166a6f3900000a20004001008d360000010d166a13042b12110411056a58130407091611056f3800000a080916098e696f3700000a2513051630dd1104026f1f00000a2e0b724018007028170000067a07166a6f3900000a07285b00000a17735c00000a130611060f02282f00000a0f03282f00000a0f04282400000a0f05282400000a06281e00000613070f06282400000a06739700000613081108285b00000a17735d00000a130911076f5e00000a130c38f1010000120c285f00000a130d066f96000006110d11086f6000000a7d4b000004110920504b03046f6100000a11091f146f6200000a110920000800006f6200000a11090f01282f00000ad16f6200000a1109166f6200000a11091f216f6200000a1109166f6100000a1109166f6100000a1109110d7b4a0000046f6100000a1109110d7b480000048e69d16f6200000a1109166f6200000a1109110d7b480000046f6300000a11086f6000000a130e07110d7b490000046f3900000a15130f110d7b4a00000413100f01282f00000a1e331711102d131108188d360000012516199c16186f3800000a0f01282f00000a1e330411102d03142b0911081617736400000a13112b78066f960000060709161110098e69286500000a6f3700000a1313111316300b724018007028170000067a\
1613142b207e16000004110f091114916120ff0000005f95110f1e6461130f1114175813141114111332da11112c0d1111091611136f3800000a2b0b1108091611136f3800000a111011135913101110163083de0c11112c0711116f2d00000adc066f96000006110d110f667d4c000004110d11086f6000000a110edab87d4d00000411086f6000000a13121108110d7b4b0000041f0e6a586f3900000a1109110d7b4c0000046f6100000a1109110d7b4d0000046f6100000a110811126f3900000a120c286600000a3a03feffffde0e120cfe160b00001b6f4b00000adc11086f6000000a130a11076f5e00000a130c38d9000000120c285f00000a1315066f96000006110920504b01026f6100000a11091f146f6200000a11091f146f6200000a110920000800006f6200000a11090f01282f00000ad16f6200000a1109166f6200000a11091f216f6200000a110911157b4c0000046f6100000a110911157b4d0000046f6100000a110911157b4a0000046f6100000a110911157b480000048e69d16f6200000a1109166f6200000a1109166f6200000a1109166f6200000a1109166f6200000a1109166f6100000a110911157b4b000004b86f6100000a110911157b480000046f6300000a120c286600000a3a1bffffffde0e120cfe160b00001b6f4b00000adc11086f6000000a110adab8130b110920504b05066f6100000a1109166f6200000a1109166f6200000a110911076f6700000ad16f6200000a110911076f6700000ad16f6200000a1109110b6f6100000a1109110ab86f6100000a1109166f6200000a11096f6800000a066f9600000611086f6900000a066f96000006735a00000a1316de2e11092c0711096f4b00000adc11082c0711086f4b00000adc11062c0711066f4b00000adc072c06076f4b00000adc11162a00000041ac0000020000004403000081000000c50300000c00000000000000020000003d02000004020000410400000e000000000000000200000061040000ec0000004d0500000e000000000000000200000034020000ac030000e00500000c000000000000000200000025020000c7030000ec0500000c0000000000000002000000f001000008040000f80500000c00000000000000020000007a0100008a040000040600000a000000000000001b300400e40100001700001173a60000060a060e057d6400000406026f6a00000a7d6500000406fe06a7000006736b00000a0b071f0c6a6f6c00000a026f6d00000a2054425a573309026f6d00000a172e0b724018007028170000067a026f6d00000a0c086e036a310b721218007028170000067a08736e00000a0d283e00000a736f00000a1304161305166a1306161307382a010000071f106a6f6c00000a026f7000000a026f6d00000a1308026f7100000a1309251105300b724018007028170000067a130511082c12110820ffff0000350911086e04195a6a310b72c017007028170000067a110905360b721218007028170000067a1106110985d6130611060e04310b721218007028170000067a0711086e110985d66f6c00000a0211086f7200000a130a1617735800000a110a6f4f00000a130bde0c2672c017007028170000067a110b731200000a04731100000a281c000006261104110b6f7300000a2c0b72f417007028170000067a1104110b176f7400000a09739400000625110a7d4800000425067b650000046f6000000a7d49000004251109697d4a0000046f7500000a067b65000004256f6000000a1109586f3900000a11071758130711076a086e3fccfeffff067b650000046f6000000a067b650000046f7600000a2e0b724018007028170000067a092a0110000000001d01122f010c18000001c21617735800000a801400000420b5010000287700000a287800000a287900000a8015000004281200000680160000042ad602287a00000a036f7b00000a2c08036f2b00000a2d102079c800007240190070738f0000067a02037d17000004020428220000062a1e027b180000042a2202037d180000042a3e02031828250000061628140000062a3e02031a28250000061628150000062a1330050044000000180000110203046a2826000006048d360000010a027b17000004036f3900000a160b2b1e027b1700000406070407596f3700000a0c082d06737c00000a7a0708580b070432de062abe03166a321904166a321403022821000006300b04022821000006035931102079c8000072a8190070738f0000067a2a5a0203042826000006027b17000004030473280000062a8602287d00000a02037d19000004027b19000004046f3900000a02057d1a0000042a1e027b1a0000042a0a172a0a162a0a162a1a737e00000a7a1a737e00000a7a1a737e00000a7a00133004004200000019000011027b1a0000042d02162a056a027b1a000004285200000a690a027b190000040304066f3700000a0b072d06737c00000a7a02027b1a000004076a597d1a000004072a062a1a737e00000a7a1a737e00000a7a1a737e00000a7a220203287f00000a2a9202287a00000a020328380000060204283a0000060205283c000006020e04283e0000062a1e027b1b0000042a2202037d1b0000042a1e027b1c0000042a2202037d1c0000042a1e027b1d0000042a2202037d1d0000042a1e027b1e0000042a2202037d1e0000042a00133002005c0000000000000002287a00000a020328410000060204284300000602052845000006020e042847000006020e052849000006020e06284b000006020e07284d000006020e08284f000006020e092851000006020e0a285300000602\
0e0b28550000062a1e027b1f0000042a2202037d1f0000042a1e027b200000042a2202037d200000042a1e027b210000042a2202037d210000042a1e027b220000042a2202037d220000042a1e027b230000042a2202037d230000042a1e027b240000042a2202037d240000042a1e027b250000042a2202037d250000042a1e027b260000042a2202037d260000042a1e027b270000042a2202037d270000042a1e027b280000042a2202037d280000042a1e027b290000042a2202037d290000042a1e027b2a0000042a2202037d2a0000042a9e02284200000672121a00701a6f4800000a2d1202284200000672520f00701a6f4800000a2a172a1e027b2b0000042a2202037d2b0000042a1e027b2c0000042a2202037d2c0000042a1e027b2d0000042a2202037d2d0000042a1e027b2e0000042a2202037d2e0000042a1e027b2f0000042a2202037d2f0000042a1e027b300000042a2202037d300000042a1e027b310000042a2202037d310000042a1e027b320000042a2202037d320000042a1e027b330000042a2202037d330000042a66736d0000062502738000000a6f5a00000625036f5c0000062a00133003005300000000000000736d00000625026f5e0000062503738100000a6f600000062504738100000a6f620000062505738000000a6f64000006250e04738000000a6f66000006250e05738200000a6f68000006250e066f6a0000062a1e02287a00000a2a1e027b340000042a2202037d340000042a1e027b350000042a2202037d350000042a1e027b360000042a2202037d360000042a1e027b370000042a2202037d370000042a1e027b380000042a2202037d380000042a1e027b390000042a2202037d390000042a1e027b3a0000042a2202037d3a0000042a1e027b3b0000042a2202037d3b0000042a1e027b3c0000042a2202037d3c0000042a1e027b3d0000042a2202037d3d0000042a1e027b3e0000042a2202037d3e0000042a1e027b3f0000042a2202037d3f0000042a1e027b400000042a2202037d400000042a1e027b410000042a2202037d410000042a1e027b420000042a2202037d420000042a66738e0000062502738000000a6f6f00000625036f710000062a133003009c00000000000000738e0000062502738000000a6f7300000625036f750000062504738200000a6f770000062505738100000a6f79000006250e04738100000a6f7b000006250e05738000000a6f7d000006250e06738000000a6f7f000006250e07738200000a6f81000006250e08738200000a6f83000006250e09738000000a6f85000006250e0a738200000a6f87000006250e0b6f89000006250e0c6f8b0000062a1e02287a00000a2a3e0204288300000a020328910000062a1e027b430000042a2202037d430000042a7a0272161a00700372341a0070288400000a288300000a02047d440000042a1e02287a00000a2a1e02287a00000a2a6602288500000a7d4e00000402287a00000a02037d4f0000042a82027b4e0000046f8600000a027b4f0000046a320b723018007028170000067a2a5602288700000a02037d5000000402047d510000042a00000013300600750000001a000011027b510000046f96000006026f6000000a056ad60a06027b50000004310b721218007028170000067a06026f8800000a6a312d02027b500000040620001000006a026f8800000a6a186ad8288900000a288900000a285200000ab76f8a00000a02030405288b00000a027b510000046f960000062a4e02178d360000012516039c16176f3800000a2a1e027b570000042a2202037d570000042a1e027b580000042a2202037d580000042a001b3003000a0200001b00001102287a00000a032c4005176a323b0520000000106a30320e0417322d0e04201027000030240e05176a321e0e0520000000046a30140e06176a320e0e077e2700000a282800000a2c0b72721a0070738c00000a7a04166a32040405310b72b61a0070738d00000a7a020e087d54000004020e057d55000004020e077d560000040228a100000602030473200000067d52000004027b5200000428160000060a066f390000060e04310b72da1a0070738d00000a7a027b52000004060e0828090000060b02283e00000a738e00000a7d5300000402076f3100000a8d33000001289b000006160c38fb0000000228a100000607086f3200000a0d027b53000004096f420000066f8f00000a2c0b72f81a0070738d00000a7a096f4a0000061f415f2d11096f480000062c14096f480000061e2e0b721e1b0070738d00000a7a096f42000006280b000006723e090070289000000a2d08096f580000062c0b72481b0070738d00000a7a096f500000060e05301f096f4e00000620000000086a3011096f500000060e0602289c00000659310b72741b0070738d00000a7a096f50000006096f4e0000060e07280e0000060202289c000006096f5000000658289d000006027b53000004096f42000006096f9100000a02289a00000608096f42000006a20817580c08076f3100000a3ff9feffff0228a1000006de0f130472a01b00701104739200000a7a2a0000411c00000000000006000000f4010000fa0100000f0000000900000236027b53000004036f8f00000a2a00001b300500830000001c0000110228a1000006027b530000040312006f9300000a2d0b72d41b0070738d00000a7a027b5200000406027b55000004027b56000004027b54000004280d0000060b078e6a066f50000006331407027b540000042810000006066f4c0000062e0b72f61b0070738d00000a7a0228a1000006070cde0d\
0d72a01b007009739200000a7a082a0001100000000000007474000d0900000252027b540000042c0b027b540000046f3c00000a2a1e02287a00000a2a4a027b59000004027b5a000004281c0000062a1e02287a00000a2a133009003c00000000000000027b5b000004027b5c000004027b5d000004027b5e000004027b5f000004027b60000004027b61000004027b62000004027b63000004281d0000062a1e02287a00000a2ada027b640000046f9600000603166a321a03027b650000046f7600000a027b650000046f6000000a59310b724018007028170000067a2a0042534a4201000100000000000c00000076342e302e33303331390000000005006c00000004200000237e000070200000c816000023537472696e677300000000383700001c1c00002355530054530000100000002347554944000000645300002c12000023426c6f620000000000000002000001571da209090a000000fa01330016000001000000450000001200000065000000a7000000eb0000009300000016000000970000001c0000000800000033000000600000000e000000010000000300000010000000010000000000f00b0100000000000600d008dc0f06002209dc0f06002908920f0f00fc0f000006005108300d0600b308300d06000909300d0600f008300d06003d08bd0f06008108300d060068085c0a0600b313ab0c06003a0a76150a009e08500f0a00f905500f0a00f305500f0600f3068f120a00c7119e100a00760a9e100a003a019e100a006c0b9e100a00b20c9e100e00680d60010600af0d76150600e10d600106005c0d60010a0019019e100a00c9159e1006009f00ab0c06007407ab0c06008a0c60010600840c60010600d5008d01060022018d010600290dab0c0600d6008d0106006f0bab0c0e00760c090d0600930dab0c06009800ab0c06002d0eab0c0600c80d76150600ec0e600106003a0f600193007a0f00000600aa00ab0c06000e08dc0f0600dc0c60010600350eab0c0e00940a920f0600830aab0c0600ad15ab0c0600b3008d0106005209ab0c06003f0eab0c06002b0fab0c0600c1008d010600920eab0c0e005506090d0600170fab0c0600ff06ab0c06000801ab0c0600a40aab0c06002a0a76150e00df0b090d0600270b76150600170b761506007d0dab0c06001b0eab0c000000005701000000000100010081011000000ff51531000100010003011000de0e0000310017002000030110002e0c00007d0019002800030110001416000031001b003600030110007601000031001f003f0003011000d314000031002b00590003011000f5140000310034006e0003011000f60d0000c50043008f00030110000b0e0000c5004400920003011000621300003100450093000301100070160000310048009400030110003d0b000031004e00950003011000110f000081005000970002011000fa0c0000310052009a00030110001700000031005900a200030110002d00000031005b00a400030110000100000031006400a60051806b11a5045180e510a50451806410a8045180e611a5045180ac12a8045180a607ab045180bb07ab045180d207ab045180080aa80451806212a8045180170aa8045180020aa8045180f909a80451804f12a80451808506ae0451804009ae0451800402ae045180b20bae0451805b0bae043100c613b1043100ba13b1043100ea06b5042100910cb9040100bf03a50421004d06b9040100510aa50401003405a50401001204a80401008e05a50401009903a5040100d703a80401007e03ae0401008f04bd0401006b05a50401002103a8040100d304a8040100a802ab0401004b04a50401006c04a50401001405c10401008e05a50401004c05a5040100f503c90401006003ae0401007e03ae0401004b04d00401006c04d00401002103c9040100a802c9040100dd02d7040100bf02bd040100f503c90401006003ae040100d703c90401007e03ae040100d605d70401004b04d00401006c04d00401002103c9040100a802c9040100dd02d7040100fa02d7040100b605c90401004403d7040100f804ae0401001405c1040100f503a8042300bc0ea8040300ab0ea8040300af06ae040300eb01de0403006007bd0403000414a5040300bf0aa80403001214a5040300a801ab0403001702ab042100490be2042100d113a8042100cd14a5042100490be7042100f90eeb0421007a10ef0421001415f9042100d911a5042100890eb60001003004fe040100af04a5040600650755000600cd144c0006009507de04060046064c0006006f104c000600cb124c0006007c165f000600c60b5f0006009f095f00060089075f000600d1134c000600250fe70406004e06b90450200000000096006016020501001821000000009600d31511050600dc210000000096008b151a050800782300000000960093153a0512001426000000009100ab1370052200d828000000009100581011052700f42a000000009100520c7f052900842b000000009100561688052b00042c0000000091000b1090052d00302e000000009100d812a1053000882e0000000091004513b20531000030000000009100ca0eb70532008431000000009100b801bf0534000c330000000091005d0ecf05390059330000000091004b07d8053c007c33000000009100f100df053e00c4330000000091006a07e80540008434000000009100e506f3054200d434000000009100cf0bf805420004350000000091004301000644001135000000009100040107064600303500000000910010160e0648009c360000000091006b0f15064900c837000000009100e2141b064a007438\
000000009600f61227064b009c380000000096000d1330064d0004390000000096005e134706560054390000000096000b0755065a00843a0000000096008b095e065c00504100000000910046107506650050430000000091188b0f88066b008143000000008618850f8c066b00b743000000008608a90aa8006d00bf43000000008108b40a63006d00c843000000008600430193066e00d843000000008600040198066f00e843000000008600b3109d0670003844000000008600d106a40672006844000000008600400caa0674007f44000000008618850fb1067600a144000000008608430aa8007900a94400000000c608ac0148007900ac4400000000c6084f0b48007900af4400000000c608010848007900b24400000000c608a90aa8007900b94400000000c608420da8007900c04400000000c6084f0d63007900c84400000000c600b30135017a00164500000000c6009e0a06007d00184500000000c600560bb9067d001f4500000000c600dc0a63007f00264500000000c60008083d0180002d4500000000c400f107150083003645000000008618850fc10684005b45000000008608d813a80088006345000000008108e313630088006c450000000086081710ac00890074450000000081082810010089007d450000000086085c14a8008a008545000000008108771463008a008e45000000008608aa09a8008b009645000000008108c30963008b00a045000000008618850fc9068c000846000000008608830bac0097001046000000008108940b0100970019460000000086081c072100980021460000000081082a07100098002a4600000000860836112c03990032460000000081084911720099003b460000000086081e14a8009a004346000000008108341463009a004c460000000086080806ac009b0054460000000081081e0601009b005d460000000086080b12ac009c006546000000008108231201009c006e46000000008608dd005a039d007646000000008108e70012039d007f46000000008608bd10a8009e008746000000008108d11063009e009046000000008608f810a8009f0098460000000081080e1163009f00a1460000000086086f13de06a000a9460000000081088213e706a000b2460000000086085c14a800a100ba4600000000810877146300a100c346000000008608ee13a800a200cb4600000000860800146300a200d4460000000086082a164800a300fc46000000008608970ef106a3000447000000008108a70ef906a3000d470000000086089a062100a4001547000000008108ab061000a4001e470000000086081c072100a50026470000000081082a071000a5002f47000000008608bd100207a6003747000000008108d1100a07a6004047000000008608f8100207a70048470000000081080e110a07a70051470000000086080806f106a80059470000000081081e06f906a8006247000000008608dd00f106a9006a47000000008108e700f906a900734700000000860832021307aa007b4700000000810842021b07aa008447000000008608c4012c03ab008c47000000008108d5017200ab0095470000000096009e072407ac00b047000000009600c3122b07ae000f48000000008618850f0600b5001748000000008608970ef106b5001f48000000008108a70ef906b50028480000000086089a062100b6003048000000008108ab061000b6003948000000008608830bf106b7004148000000008108940bf906b7004a480000000086081c072100b80052480000000081082a071000b8005b480000000086082a161307b90063480000000081083a161b07b9006c48000000008608bd100207ba007448000000008108d1100a07ba007d48000000008608f8100207bb0085480000000081080e110a07bb008e480000000086080806f106bc0096480000000081081e06f906bc009f48000000008608dd00f106bd00a748000000008108e700f906bd00b04800000000860832021307be00b84800000000810842021b07be00c1480000000086085e021307bf00c94800000000810878021b07bf00d2480000000086082915f106c000da480000000081083c15f906c000e34800000000860865061307c100eb4800000000810874061b07c100f44800000000860827132100c200fc4800000000810836131000c20005490000000086086f13de06c3000d490000000081088213e706c30016490000000096009e073807c4003049000000009600c3123f07c600d849000000008618850f0600d300e049000000008618850f5607d300f049000000008608970eac00d500f849000000008108a70e0100d500014a000000008318850f5c07d600204a000000008618850f0600d800284a000000008618850f0600d800304a000000008318850f0100d8004a4a000000008300370b0600d9006b4a000000008318850f6207d900844a00000000c60008083d01db00054b00000000c6004d096907de00194b00000000860882106e07df00214b00000000810890107307df002a4b0000000086088b11a800e000324b000000008108a2116300e0003c4b000000008618850f7907e100704d0000000086008612d601e900804d0000000086006415b002ea00204e000000008100370b0600eb00354e000000008618850f0600eb003d4e0000000083005b008a07eb00504e000000008618850f0600eb00584e00000000830078008a07eb00a04e000000008618850f0600eb00a84e00000000830043006300eb00000001008009000002005b0700000300fd1100000400750e000005002202000001008009000002006f10000001007a09\
02000200b70e02000300bc06020004005b0702000500261102000600241102000700340602000800fe0002000900520202000a00e601000001007a0902000200b70e02000300bc0602000400a50b020005005b07020006004a1602000700261102000800241102000900340602000a00fe0002000b00520202000c00920202000d004f1502000e00830602000f005313020010009513000001008009000002005b0700000300fd1100000400750e000005002202000001008009000002006f10000001004e0600000200cd0a00000100f90e00000200380700000100f90e00000200fb01101003001415000001007a10000001005b0700000100f90e00000200851600000100f90e00000200851600000300fd1100000400750e10100500141500000100241100000200261100000300500e000001007a09000002007912000001007a0910100200141500000100f907000002007d0700000100b01400000200b514000001007a0900000200a914000001007a0900000200a91400000100f90e00000100ec15000001001f0d00000100650700000200cd14000001009507000002004606000003006f1000000400cb12000005007c1600000600c60b000007009f0900000800890700000900d113000001009f1502000200b70e02000300bc0602000400f30100000100650700000200cd14000001009507000002004606000003006f1000000400cb12000005007c1600000600c60b000007009f0900000800890700000900d11300000100f90e000002006f1000000300cb12000004007c1600000500c60b00000600250f00000100920c00000200e60a000001007a0900000100a91400000100a91400000100a914000002005e1500000100a914000002005e1500000100a91400000200e60a000001004e0600000200a91400000300e60a000001007a09000001001e0f00000200a914000003005e1500000100a91400000200e70c000001007a09000001001e0f00000200a914000003005e15000001008a0a00000100a91400000200391000000300921400000400dc09000001007a09000001007a09000001007a09000001007a0900000100a50b000002005b07000003005c11000004004a14000005003406000006003b1200000700fe0000000800261100000900241100000a00951300000b009214000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a0900000100b70e00000200bc06000001005b0700000200261100000300241100000400340600000500fe0000000600520200000700e601000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a0900000100b70e00000200bc0600000100a50b000002005b07000003004a1600000400261100000500241100000600340600000700fe0000000800520200000900920200000a004f1500000b00830600000c00531300000d00951300000100b70e00000200c906000001007a0900000100ec1500000200c30e000001007a0900000100a71500000200250f000001001e0f00000200a914000003005e15000001007a09000001007a09000001007a09000001004e0600000200e60a000003007b1100000400ed1200000500d91100000600b91100000700890e000008001415000001006507000001006507000001005e150900850f01001100850f06001900850f0a002900850f10003100850f10003900850f10004100850f10004900850f15005100850f10005900850f10007100850f06007901850f060089018e0621000c0061094800d9001e0c4c000c0057095000d900850f01009900850f100099001e0c5500140061094800a1001e0c5f00140057095000a100850f63001c0061094800b1001e0c6e001c0057095000b100850f1500e100850f7200e1001e0c78009100180c48009100a90aa8009900180c48009900570921009901a90aac00a100180c4800a1005709a800a900180c4800a9005709b00029018507b6002901cc0cbb00b100180c48009100230cc500f9004f0b4800b10057094800f900f1070600d900180c4800d9005709ac00a101bf16ee002c001f15ac003400990c0a013c00b31518013c00990c1e019901a51625010101850f0100f900b3013501f90008083d01f9004f0d630099017f1257014400850f01001901de060600440000028701c101770b9a013c00850fa0013c006e09ab013c000002b4013c00a20cb4019901a212bc01d101470fc1019901f109c6019901f60ace019901ed0ad6019901ed0ace013101850ff901e101bf150302e901f10706002901bb1410022901ee0c17022901bd0cbb006900800a2302f100850f43022400850f8701f901d80c690291000f0c7c024c00de0650004c00850f89029901f1099e029901c714a3020102850faa026900d011b0029100850f720069004e01ea025901850fef026101850fef025400770f00035c0008155000f900420da8006101080812036101080817036101080872003101850f1c03f901d80c26035c006d15480054001f15ac0061019e0a06000101ab152c035901670cc5006400850f89026400de068701590104015a035400850f01006c00850fa00159010f01ac0059012f0166035901b3106a036c00\
b31518016c000002b401540000028701f900a90aa8001102010b70031902010b76036900370a7c036100850f0600f900ac014800c900850f0600f900850f06002102850f0600f900f10715000c00850f87011400850f87011c00850f87018901850f10009901a4139403910182159b039101a50fa8000101850f060001018b16ac00f901a3156902010198160100010108083d012902850f1000b900850f10007400850fa0017400b31518019901b116250174000002b401b900850fbf0374006e09ab010a000400db030a000800e40308000c00ed030a001000f20308001400fb0309001800000409001c000504090020000a04080024000f0408002800140408002c001904080030001e040800340023040800380028040e003c002d040e00400036040e00440047040e00480066040e004c0087041200bd00a0041200e100a0041200fd00a00420005b00f7082e000b00ce072e001300d7072e001b00f6072e002300ff072e002b002d082e00330073082e003b0081082e0043009a082e004b00a0082e005300ad0840005b00370b030263000f04230263000f04430263000f04010363000f0420035b00f60d40035b00f60d610363000f0480035b009a0f810363000f04a0035b00e210a10363000f04c10363000f04e10363000f04010463000f04200463000f04210463000f04400463000f04410463000f04610463000f04810463000f04a10463000f04c10463000f04e10463000f04010563000f04210563000f04410563000f04610563000f04810563000f04a10563000f04c10563000f04e10563000f04010663000f04210663000f04410663000f04610663000f04810663000f04a10663000f04c10663000f04e00663000f04e10663000f04000763000f04010763000f04200763000f04210763000f04400763000f04410763000f04600763000f04610763000f04800763000f04810763000f04a00763000f04a10763000f04c00763000f04c10763000f04e10763000f04000863000f04010863000f04200863000f04210863000f04400863000f04410863000f04600863000f04610863000f04800863000f04a00863000f04c00863000f04e00863000f04000963000f04200963000f04400963000f04600963000f04800963000f04a00963000f04c00963000f04e00963000f04000a63000f04200a63000f04400a63000f04600a63000f04800a63000f04a00a63000f04c00a63000f04e00a63000f04e10a63000f04010b63000f04200b63000f04400b63000f04600b63000f04800b63000f04a00b63000f04c00b63000f04e00b63000f04000c63000f04200c63000f04400c63000f04600c63000f04800c63000f04a00c63000f04c00c63000f04e00c63000f04000d63000f04200d63000f04400d63000f04c00d63000f04e00d63000f04000e63000f04200e63000f04400e63000f04600e63000f04800e63000f04a00e63000f04c00e63000f04e00e63000f04000f63000f04200f63000f04400f63000f04600f63000f04800f63000f04a00f63000f04c00f63000f04e00f63000f04001063000f04201063000f04401063000f04601063000f04801063000f04a01063000f04c01063000f04e01063000f04001163000f04201163000f04401163000f04601163000f04001263000f04201263000f04401363000f04601363000f04801363000f04a01363000f041a0025002e007c009700ca002b01450160018d01db01e60129022e024d02550259026f0275028f029402b602310388038f03a103a503c70303000100040002000500080006000c000700190008002200090031000f0032000000df0a8f070000470a8f070000b00193070000530b93070000050893070000df0a8f070000530d8f070000a2148f0700002c10970700007b148f070000c7098f070000980b9707000051079b0700004d119f07000038148f070000220697070000271297070000f800a4070000e8108f07000012118f0700008613a80700007b148f07000004148f0700003e1693070000ab0eb1070000af069b07000051079b070000e810b90700001211b90700002206b1070000f800b10700004602c1070000d9019f070000ab0eb1070000af069b070000980bb107000051079b0700003e16c1070000e810b90700001211b90700002206b1070000f800b10700004602c10700007c02c10700004015b10700007806c107000048139b0700008613a8070000ab0e970700009410c9070000a6118f0702002100030001002200030002002900050002002a00070002002b00090002002c000b0002002d000d0002002e000f0001002f000f0002003700110001003800110002003900130001003a00130002003b00150001003c00150002003d00170001003e001700020040001900010041001900020042001b00010043001b00020044001d00010045001d00020046001f00010047001f0002004800210001004900210002004a00230001004b00230002004c00250001004d00250002004e00270001004f002700020050002900010051002900020052002b00010053002b00020054002d00010055002d00020056002f00010057002f0002005800310002005900330001005a00330002005b00350001005c00350002005d00370001005e00370002005f003900010060003900020061003b00010062003b00020063003d00010064003d00020065003f00010066003f0002006700410001006800410002006900430001006a00430002006e00450001006f004500020070004700010071004700020072004900010073004900020074004b00010075004b00020076004d00010077004d00\
020078004f00010079004f0002007a00510001007b00510002007c00530001007d00530002007e00550001007f005500020080005700010081005700020082005900010083005900020084005b00010085005b00020086005d00010087005d00020088005f00010089005f0002008a00610001008b00610002009000630001009100630002009a00650001009b00650002009c00670001009d0067004200590068009000fa00020110017f018102f8020a0353035e03b603048000000100040000000000000000000000f5150000040000000000000000000000d203840100000000040000000000000000000000d2036a0100000000040000000000000000000000d203ab0c00000000030002000400020005000200060002000700020008000200090002000a0002000b0002000c0002000d0002000e0002000f0002001000020011000200120002006100f5000000003c3e635f5f446973706c6179436c61737336335f30003c3e635f5f446973706c6179436c61737335355f30003c3e635f5f446973706c6179436c61737335365f30003c52656164577269746572456e74726965733e625f5f30003c456e636f64655772697465724e616d655374617475733e625f5f30003c437265617465577269746572417263686976655374617475733e625f5f300046756e636031004e756c6c61626c65603100416374696f6e60310049436f6c6c656374696f6e60310049457175616c697479436f6d7061726572603100494c6973746031006765745f4372633332007365745f437263333200436f6d707574654372633332006372633332005265616455496e7433320052656164496e7433320053716c496e7433320044696374696f6e6172796032005265616455496e7436340053716c496e743634005265616455496e743136006765745f55544638003c4d6f64756c653e0053797374656d2e494f0053797374656d2e4461746100456e7472794d65746164617461006d73636f726c69620053797374656d2e436f6c6c656374696f6e732e47656e6572696300437263006765745f43616e5265616400526561645061796c6f6164006765745f456e7472795061796c6f6164007365745f456e7472795061796c6f616400656e7472795061796c6f6164007061796c6f616400656f636400416464005061746844726976655175616c696669656400436f6d70726573736564006661696c4966456e63727970746564006765745f4973456e63727970746564007365745f4973456e63727970746564006973456e63727970746564006765745f497345787472616374696f6e537570706f72746564007365745f497345787472616374696f6e537570706f7274656400697345787472616374696f6e537570706f72746564003c43726333323e6b5f5f4261636b696e674669656c64003c456e7472795061796c6f61643e6b5f5f4261636b696e674669656c64003c4973456e637279707465643e6b5f5f4261636b696e674669656c64003c497345787472616374696f6e537570706f727465643e6b5f5f4261636b696e674669656c64003c436f6d7072657373696f6e4d6574686f643e6b5f5f4261636b696e674669656c64003c497350617468536166653e6b5f5f4261636b696e674669656c64003c4572726f724d6573736167653e6b5f5f4261636b696e674669656c64003c456e7472794e616d653e6b5f5f4261636b696e674669656c64003c43656e7472616c4469726563746f727953697a653e6b5f5f4261636b696e674669656c64003c4c656e6774683e6b5f5f4261636b696e674669656c64003c456e7472794f7264696e616c3e6b5f5f4261636b696e674669656c64003c4572726f724e756d6265723e6b5f5f4261636b696e674669656c64003c546f74616c456e74726965733e6b5f5f4261636b696e674669656c64003c506172744e616d65733e6b5f5f4261636b696e674669656c64003c436f6d7072657373656442797465733e6b5f5f4261636b696e674669656c64003c556e636f6d7072657373656442797465733e6b5f5f4261636b696e674669656c64003c456e7472794e616d6542797465733e6b5f5f4261636b696e674669656c64003c4465636c61726564546f74616c42797465733e6b5f5f4261636b696e674669656c64003c47656e6572616c507572706f7365466c6167733e6b5f5f4261636b696e674669656c64003c506174685374617475733e6b5f5f4261636b696e674669656c64003c4c6173744d6f64696669656441743e6b5f5f4261636b696e674669656c64003c4f66667365743e6b5f5f4261636b696e674669656c64003c5061796c6f61644f66667365743e6b5f5f4261636b696e674669656c64003c4c6f63616c4865616465724f66667365743e6b5f5f4261636b696e674669656c64003c43656e7472616c4469726563746f72794f66667365743e6b5f5f4261636b696e674669656c64003c4475706c6963617465436f756e743e6b5f5f4261636b696e674669656c64003c49734469726563746f72793e6b5f5f4261636b696e674669656c640053797374656d446174614163636573734b696e64006765745f436f6d7072657373696f6e4d6574686f64007365745f436f6d7072657373696f6e4d6574686f6400636f6d7072657373696f6e4d6574686f64006d6574686f64005f736f7572636500436f6d7072657373696f6e4d6f6465006765745f49735061746853616665007365745f497350617468536166650069735061746853616665006765745f4d657373616765006765745f4572726f724d657373616765007365745f45\
72726f724d657373616765006572726f724d657373616765006d657373616765005265717569726552616e676500496e766f6b65004275696c644372635461626c650049456e756d657261626c650049446973706f7361626c6500456e636f64655772697465724e616d65006765745f456e7472794e616d65007365745f456e7472794e616d6500726571756573746564456e7472794e616d65004465636f6465456e7472794e616d6500656e7472794e616d65006e616d6500436f6e76657274446f734461746554696d6500646f7354696d65004f6e65006d6178456e76656c6f706500656e76656c6f7065004661696c757265004c6f63616c4865616465725369676e61747572650043656e7472616c4865616465725369676e617475726500456e644f6643656e7472616c4469726563746f72795369676e617475726500446973706f736500646f7344617465006765745f43616e577269746500436f6d70696c657247656e6572617465644174747269627574650044656275676761626c6541747472696275746500436f6d56697369626c6541747472696275746500417373656d626c795469746c65417474726962757465005461726765744672616d65776f726b41747472696275746500417373656d626c7946696c6556657273696f6e4174747269627574650053716c46756e6374696f6e41747472696275746500417373656d626c794465736372697074696f6e41747472696275746500436f6d70696c6174696f6e52656c61786174696f6e7341747472696275746500417373656d626c7950726f6475637441747472696275746500417373656d626c79436f6d70616e794174747269627574650052756e74696d65436f6d7061746962696c69747941747472696275746500506174684162736f6c75746500577269746542797465006765745f56616c7565006765745f48617356616c75650054727947657456616c75650076616c7565007a6970417263686976650043726561746557726974657241726368697665006d617841726368697665006765745f43656e7472616c4469726563746f727953697a65007365745f43656e7472616c4469726563746f727953697a650063656e7472616c4469726563746f727953697a6500496e6465784f660055746638466c6167005374726f6e67456e6372797074696f6e466c6167004461746144657363726970746f72466c61670055544638456e636f64696e6700476574456e636f64696e67006765745f52656d61696e696e67005f72656d61696e696e670053797374656d2e52756e74696d652e56657273696f6e696e670053716c537472696e6700476574537472696e6700646973706f73696e670053746f70776174636800466c757368004d617468006765745f4c656e677468007365745f4c656e677468005061796c6f61644c656e6774680065787065637465644c656e677468005365744c656e677468006c656e67746800456e6473576974680053746172747357697468006765745f457863657074696f6e46616c6c6261636b004465636f64657246616c6c6261636b00456e636f64657246616c6c6261636b00436865636b00577269746572436c6f636b00636c6f636b006765745f43616e5365656b00506174684e6f6e43616e6f6e6963616c0053716c446563696d616c006765745f4f7264696e616c006765745f456e7472794f7264696e616c007365745f456e7472794f7264696e616c00656e7472794f7264696e616c0050617468506172656e7454726176657273616c006d6178546f74616c0042797465417272617973457175616c00436f6d7072657373696f6e4c6576656c00546f6f6c62656c742e417263686976652e5a69704d656d6f72792e646c6c006765745f4e756c6c006765745f49734e756c6c006765745f53747265616d00426f756e6465645265616453747265616d004f70656e426f756e64656453747265616d00436f7079546f5365656b61626c6553747265616d006765745f4261736553747265616d004465666c61746553747265616d004d656d6f727953747265616d005f73747265616d006765745f4974656d007365745f4974656d0053797374656d0053716c426f6f6c65616e006f705f477265617465725468616e006f705f4c6573735468616e004d696e005365656b4f726967696e006f726967696e006f705f4469766973696f6e004172636869766553657373696f6e0053797374656d2e494f2e436f6d7072657373696f6e006f7065726174696f6e00416374696f6e0053797374656d2e5265666c656374696f6e006765745f506f736974696f6e007365745f506f736974696f6e00494f457863657074696f6e00496e76616c696444617461457863657074696f6e004e6f74537570706f72746564457863657074696f6e00417267756d656e744f75744f6652616e6765457863657074696f6e004465636f64657246616c6c6261636b457863657074696f6e00456e636f64657246616c6c6261636b457863657074696f6e00456e644f6653747265616d457863657074696f6e005a697050726f7669646572457863657074696f6e00577269746572457863657074696f6e00417267756d656e74457863657074696f6e004f766572666c6f77457863657074696f6e00537472696e67436f6d70617269736f6e006d6178696d756d526174696f00456e666f726365436f6d7072657373696f6e526174696f006d6178436f6d7072657373696f6e526174696f006d6178526174696f0043686172006765745f4572726f724e756d626572007365745f4572726f72\
4e756d626572006572726f724e756d626572006e756d6265720056616c69646174654c6f63616c48656164657200417263686976655265616465720042696e61727952656164657200726561646572005a6970456e74727950726f766964657200577269746572427566666572006275666665720074696d657200537472696e67436f6d70617265720042696e6172795772697465720049734c6574746572004d6963726f736f66742e53716c5365727665722e536572766572005772697465724572726f7200476574456e756d657261746f72002e63746f72002e6363746f720053797374656d2e446961676e6f7374696373006765745f456c61707365644d696c6c697365636f6e64730053797374656d2e52756e74696d652e496e7465726f7053657276696365730053797374656d2e52756e74696d652e436f6d70696c6572536572766963657300446562756767696e674d6f6465730052656164456e7472696573006765745f546f74616c456e7472696573007365745f546f74616c456e747269657300746f74616c456e74726965730052656164577269746572456e7472696573004c697374456e7472696573004d6178456e7472696573006d6178456e747269657300656e7472696573006765745f506172744e616d6573007365745f506172744e616d65730053797374656d2e446174612e53716c547970657300526561644279746573006765745f436f6d707265737365644279746573007365745f436f6d707265737365644279746573004d6178436f6d707265737365644279746573006765745f556e636f6d707265737365644279746573007365745f556e636f6d70726573736564427974657300756e636f6d707265737365644279746573006765745f456e7472794e616d654279746573007365745f456e7472794e616d65427974657300656e7472794e616d654279746573004d6178417263686976654279746573006d6178417263686976654279746573006765745f4465636c61726564546f74616c4279746573007365745f4465636c61726564546f74616c4279746573006d6178546f74616c42797465730053716c4279746573004765744279746573006d6178506172744279746573004d6178457874726163746564456e7472794279746573006d6178456e7472794279746573006765745f47656e6572616c507572706f7365466c616773007365745f47656e6572616c507572706f7365466c6167730067656e6572616c507572706f7365466c6167730052656c6576616e744c6f63616c466c61677300436f6d7072657373696f6e4f7074696f6e466c61677300666c61677300457175616c7300436f6e7461696e730053797374656d2e436f6c6c656374696f6e73006765745f4368617273004d6178456e7472794e616d65436861726163746572730053756363657373006d61784e616d65556e697473004275696c644475706c6963617465436f756e7473006d6178506172747300456e636f64655772697465724e616d655374617475730043726561746557726974657241726368697665537461747573006765745f50617468537461747573007365745f50617468537461747573004765745061746853746174757300706174685374617475730046696c6c577269746572537461747573006765745f4c6173744d6f6469666965644174007365745f4c6173744d6f6469666965644174006c6173744d6f646966696564417400436f6e6361740045787472616374004f626a656374004370343337537472696374005574663853747269637400627564676574006765745f4f6666736574007365745f4f6666736574006765745f5061796c6f61644f6666736574007365745f5061796c6f61644f6666736574004c6f63616c4f6666736574006765745f4c6f63616c4865616465724f6666736574007365745f4c6f63616c4865616465724f6666736574006c6f63616c4865616465724f6666736574006765745f43656e7472616c4469726563746f72794f6666736574007365745f43656e7472616c4469726563746f72794f66667365740063656e7472616c4469726563746f72794f6666736574006f6666736574006c656674007269676874006f705f496d706c696369740053706c6974006c696d69740050726f7669646572526573756c7400577269746572537461747573526573756c740050726f76696465724c697374526573756c74006765745f43757272656e7400636865636b706f696e74006765745f436f756e74006765745f4475706c6963617465436f756e74007365745f4475706c6963617465436f756e74006475706c6963617465436f756e7400636f756e74005265616450617274004d6f76654e6578740053797374656d2e546578740053746172744e65770046696c6c526f770046696c6c4c697374526f7700726f77004d6178006d617800546f417272617900436f6e7461696e734b657900426c6f636b436f70790053716c42696e617279004c6973745a6970456e747269657346726f6d42696e6172790063617465676f727900546f6f6c62656c742e417263686976652e5a69704d656d6f72790052656164456e644f6643656e7472616c4469726563746f7279006765745f49734469726563746f7279007365745f49734469726563746f72790069734469726563746f72790046696e64456e74727900457874726163745a6970456e74727900577269746572456e747279006d6178456e74727900656e747279006765745f4361706163697479007365745f4361706163697479006f705f457175616c697479\
006f705f496e657175616c69747900456d70747900000000007b44006500720020006b006f006d007000720069006d006900650072007400650020005a00490050002d005000610079006c006f00610064002000690073007400200075006e006700fc006c0074006900670020006f00640065007200200075006e0076006f006c006c0073007400e4006e006400690067002e00017b450069006e0020005a00490050002d0045006e007400720079002d004e0061006d0065002000760065007200770065006e006400650074002000650069006e006500200075006e006700fc006c00740069006700650020005a00650069006300680065006e006b006f00640069006500720075006e0067002e00017944006500720020005a00490050002d0043006f006e007400610069006e0065007200200065006e00640065007400200069006e006e0065007200680061006c0062002000650069006e00650072002000620065006e00f600740069006700740065006e00200053007400720075006b007400750072002e00017544006500720020005a00490050002d0043006f006e007400610069006e006500720020006b006f006e006e007400650020006e006900630068007400200076006f006c006c0073007400e4006e006400690067002000670065006c006500730065006e002000770065007200640065006e002e00017d44006500720020005a00490050002d0043006f006e007400610069006e00650072002000690073007400200073007400720075006b0074007500720065006c006c00200075006e006700fc006c0074006900670020006f00640065007200200075006e0076006f006c006c0073007400e4006e006400690067002e00017940005a0069007000410072006300680069007600650020006d007500730073002000650069006e0065006e0020006e00690063006800740020006c0065006500720065006e0020005a00490050002d0043006f006e007400610069006e0065007200200065006e007400680061006c00740065006e002e00013b400045006e007400720079004e0061006d00650020006d007500730073002000670065007300650074007a00740020007300650069006e002e000063400045006e007400720079004e0061006d0065002000640061007200660020006800f600630068007300740065006e0073002000310030003200340020005a00650069006300680065006e00200065006e007400680061006c00740065006e002e00016740004d006100780045006e007400720079004200790074006500730020006d0075007300730020007a007700690073006300680065006e0020003100200075006e00640020003600370031003000380038003600340020006c0069006500670065006e002e00006940004d006100780043006f006d007000720065007300730069006f006e0052006100740069006f0020006d00750073007300200067007200f600df006500720020006f00640065007200200067006c0065006900630068002000310020007300650069006e002e00014d40004600610069006c004900660045006e0063007200790070007400650064002000640061007200660020006e00690063006800740020004e0055004c004c0020007300650069006e002e0000809944006500720020005a00490050002d0043006f006e007400610069006e00650072002000fc0062006500720073006300680072006500690074006500740020006400610073002000680061007200740065002000500072006f00760069006400650072006c0069006d0069007400200076006f006e0020003200360038003400330035003400350036002000420079007400650073002e00015b440065007200200061006e006700650066006f0072006400650072007400650020005a00490050002d0045006e00740072007900200069007300740020007600650072007300630068006c00fc007300730065006c0074002e0001809b44006900650020005a0049005000200043006f006d007000720065007300730069006f006e0020004d006500740068006f0064002000770069007200640020006e006900630068007400200075006e0074006500720073007400fc0074007a0074002e0020005a0075006c00e40073007300690067002000730069006e00640020006e007500720020003000200075006e006400200038002e00015744006500720020005a00490050002d0045006e007400720079002000fc00620065007200730063006800720065006900740065007400200040004d006100780045006e00740072007900420079007400650073002e000180ab44006500720020006b006f006d007000720069006d006900650072007400650020005a00490050002d0045006e007400720079002000fc0062006500720073006300680072006500690074006500740020006400610073002000680061007200740065002000500072006f00760069006400650072006c0069006d0069007400200076006f006e0020003100330034003200310037003700320038002000420079007400650073002e000180b344006900650020007400610074007300e400630068006c0069006300680020006100750073006700650067006500620065006e00650020005000610079006c006f00610064002d004c00e4006e006700650020007300740069006d006d00740020006e00690063006800740020006d00690074002000640065006d002000430065006e007400720061006c0020004400690072006500630074006f00720079002000fc006200650072006500\
69006e002e000180854400690065002000430052004300330032002d0050007200fc00660075006e00670020006400650073002000640065006b006f006d007000720069006d00690065007200740065006e0020005000610079006c006f00610064007300200069007300740020006600650068006c00670065007300630068006c006100670065006e002e00015b40004d006100780045006e007400720069006500730020006d0075007300730020007a007700690073006300680065006e0020003100200075006e00640020003100300030003000300020006c0069006500670065006e002e00006b44006100730020005a0049005000200065006e0074006800e4006c00740020006d00650068007200200045006e0074007200690065007300200061006c007300200040004d006100780045006e007400720069006500730020007a0075006c00e4007300730074002e0001097300610066006500007144006500720020005a00490050002d0043006f006e007400610069006e00650072002000fc0062006500720073006300680072006500690074006500740020006400610073002000680061007200740065002000500072006f00760069006400650072006c0069006d00690074002e000180974400690065002000670065006c006500730065006e00650020004100720063006800690076006c00e4006e006700650020007300740069006d006d00740020006e00690063006800740020006d006900740020006400650072002000760061007200620069006e0061007200790028006d006100780029002d004c00e4006e00670065002000fc00620065007200650069006e002e00017d440065007200200061006e006700650066006f00720064006500720074006500200045006e007400720079002d004e0061006d0065002000690073007400200069006d0020005a00490050002d0041007200630068006900760020006e0069006300680074002000650069006e006400650075007400690067002e000161440065007200200061006e006700650066006f0072006400650072007400650020005a00490050002d0045006e0074007200790020007700750072006400650020006e006900630068007400200067006500660075006e00640065006e002e0001808f44006100730020005a00490050002d004100720063006800690076002000fc0062006500720073006300680072006500690074006500740020006400610073002000680061007200740065002000500072006f00760069006400650072006c0069006d0069007400200076006f006e00200031003000300030003000200045006e00740072006900650073002e000180bb5a0075007300e40074007a006c0069006300680065002000430065006e007400720061006c002d004400690072006500630074006f00720079002d0044006100740065006e007300e40074007a0065002000770065007200640065006e00200069006e0020006400690065007300650072002000500072006f00760069006400650072002d00560065007200730069006f006e0020006e006900630068007400200075006e0074006500720073007400fc0074007a0074002e00017b450069006e002000430065006e007400720061006c002d004400690072006500630074006f00720079002d004800650061006400650072002000620065007300690074007a0074002000650069006e006500200075006e006700fc006c00740069006700650020005300690067006e0061007400750072002e0001735a00490050003600340020007700690072006400200076006f006e0020006400690065007300650072002000500072006f00760069006400650072002d00560065007200730069006f006e0020006e006900630068007400200075006e0074006500720073007400fc0074007a0074002e0001614d0075006c00740069002d004400690073006b002d005a00490050002d0041007200630068006900760065002000770065007200640065006e0020006e006900630068007400200075006e0074006500720073007400fc0074007a0074002e00018083450069006e00200045006e007400720079002d004e0061006d0065002000fc00620065007200730063006800720065006900740065007400200064006900650020006d006100780069006d0061006c00650020004c00e4006e0067006500200076006f006e002000310030003200340020005a00650069006300680065006e002e00015b4400690065002000430065006e007400720061006c002d004400690072006500630074006f00720079002d0047007200f600df0065002000690073007400200069006e006b006f006e00730069007300740065006e0074002e00011f640072006900760065002d007100750061006c006900660069006500640001116100620073006f006c0075007400650000052e002e0000072e002e002f0000072e002e005c0000092f002e002e002f0000095c002e002e005c0000072f002e002e0000075c002e002e00002170006100720065006e0074002d00740072006100760065007200730061006c0001032e0000052e002f0000052f002e0000035c0000052f002f0000072f002e002f0000075c002e005c0000052f005c0000055c002f0000196e006f006e00630061006e006f006e006900630061006c00006d44006500720020004c006f00630061006c002000460069006c00650020004800650061006400650072002000620065007300690074007a0074002000650069006e006500200075006e006700fc006c007400690067\
00650020005300690067006e0061007400750072002e000180a7470065006e006500720061006c002d0050007500720070006f00730065002d0046006c00610067007300200076006f006e0020004c006f00630061006c002000480065006100640065007200200075006e0064002000430065006e007400720061006c0020004400690072006500630074006f007200790020007300740069006d006d0065006e0020006e0069006300680074002000fc00620065007200650069006e002e0001809f43006f006d007000720065007300730069006f006e0020004d006500740068006f006400200076006f006e0020004c006f00630061006c002000480065006100640065007200200075006e0064002000430065006e007400720061006c0020004400690072006500630074006f007200790020007300740069006d006d00740020006e0069006300680074002000fc00620065007200650069006e002e0001808f45006e007400720079002d004e0061006d006500200076006f006e0020004c006f00630061006c002000480065006100640065007200200075006e0064002000430065006e007400720061006c0020004400690072006500630074006f007200790020007300740069006d006d00740020006e0069006300680074002000fc00620065007200650069006e002e00017344006500720020006b006f006d007000720069006d006900650072007400650020005000610079006c006f00610064002000fc006200650072006c00610070007000740020006400610073002000430065006e007400720061006c0020004400690072006500630074006f00720079002e0001809f4300520043003300320020006f00640065007200200047007200f600df0065006e00200076006f006e0020004c006f00630061006c002000480065006100640065007200200075006e0064002000430065006e007400720061006c0020004400690072006500630074006f007200790020007300740069006d006d0065006e0020006e0069006300680074002000fc00620065007200650069006e002e0001695a00490050002d0045006e007400720079002000fc0062006500720073006300680072006500690074006500740020006400690065002000660065007300740065002000450078007400720061006b00740069006f006e0073006700720065006e007a0065002e0001809b530074006f007200650064002d0045006e007400720079002000620065007300690074007a007400200075006e007400650072007300630068006900650064006c00690063006800650020006b006f006d007000720069006d0069006500720074006500200075006e006400200075006e006b006f006d007000720069006d0069006500720074006500200047007200f600df0065006e002e00016d44006900650020007400610074007300e400630068006c00690063006800650020005000610079006c006f00610064002000fc00620065007200730063006800720065006900740065007400200040004d006100780045006e00740072007900420079007400650073002e00017344006500720020006b006f006d007000720069006d006900650072007400650020005000610079006c006f0061006400200065006e0074006800e4006c00740020006e00690063006800740020006b006f006e00730075006d00690065007200740065002000420079007400650073002e00017d44006900650020007400610074007300e400630068006c00690063006800650020005a00490050002d0045006e0074007200790067007200f600df0065002000770065006900630068007400200076006f006e0020006400650072002000440065006b006c00610072006100740069006f006e002000610062002e00018097440069006500200043006f006d007000720065007300730069006f006e00200052006100740069006f002000690073007400200077006500670065006e002000650069006e006500720020006b006f006d007000720069006d00690065007200740065006e00200047007200f600df006500200076006f006e0020003000200075006e007a0075006c00e40073007300690067002e00016344006500720020005a00490050002d0045006e007400720079002000fc00620065007200730063006800720065006900740065007400200040004d006100780043006f006d007000720065007300730069006f006e0052006100740069006f002e00017b44006500720020005a00490050002d0043006f006e007400610069006e0065007200200069007300740020007a00750020006b00750072007a0020006600fc0072002000650069006e0065006e0020006700fc006c0074006900670065006e00200045004f00430044002d005200650063006f00720064002e000163430065006e007400720061006c0020004400690072006500630074006f007200790020004f006600660073006500740020006f00640065007200200047007200f600df0065002000690073007400200075006e006700fc006c007400690067002e00016945004f00430044002d005300690067006e006100740075007200200077007500720064006500200069006d0020005a00490050002d0043006f006e007400610069006e006500720020006e006900630068007400200067006500660075006e00640065006e002e00012149004e00560041004c00490044005f0041005200470055004d0045004e005400001949004e00560041004c00490044005f004e0041004d004500001946004f0052004d00410054005f\
004c0049004d0049005400001d4400550050004c00490043004100540045005f004e0041004d004500001d5200450053004f0055005200430045005f004c0049004d0049005400000f540049004d0045004f005500540000235400520041004e00530050004f00520054005f0049004e00560041004c004900440000695400420058005f005a00490050005f00570052004900540045005f0046004f0052004d00410054005f004c0049004d00490054003a0020004e0075006d0065007200690073006300680065007300200046006f0072006d00610074006c0069006d00690074002e0000715400420058005f005a00490050005f00570052004900540045005f005400520041004e00530050004f00520054005f0049004e00560041004c00490044003a00200045006e00760065006c006f0070006500200075006e0076006f006c006c0073007400e4006e006400690067002e00016744006500720020005a00490050002d00450069006e006700610062006500730074007200650061006d00200069007300740020006e00690063006800740020006c0065007300620061007200200075006e00640020007300650065006b006200610072002e000169450069006e00650020005a00490050002d0053007400720075006b00740075007200200076006500720077006500690073007400200061007500df0065007200680061006c0062002000640065007300200043006f006e007400610069006e006500720073002e0001032f00001d5400420058005f005a00490050005f00570052004900540045005f00003d3a0020005a00490050002d005700720069007400650072002d00560065007200740072006100670020007600650072006c00650074007a0074002e00014355006e006700fc006c007400690067006500200074006500630068006e006900730063006800650020005a00490050002d004700720065006e007a0065006e002e0001235a00490050005f0041005200430048004900560045005f004c0049004d0049005400001d5a00490050005f0050004100520054005f004c0049004d004900540000255a00490050005f004400550050004c00490043004100540045005f00500041005200540000295a00490050005f0055004e0053005500500050004f0052005400450044005f005000410052005400002b5a00490050005f004e004f004e00430041004e004f004e004900430041004c005f005000410052005400002b5a00490050005f0050004100520054005f004f0052005f00530055004d005f004c0049004d004900540000335a00490050005f005300540052005500430054005500520045005f004f0052005f005200450053004f00550052004300450000215a00490050005f0050004100520054005f004d0049005300530049004e00470000255a00490050005f0050004100520054005f0049004e0054004500470052004900540059000068771269f192424b85a334f70ba7c98a00042001010803200001052001011111042001010e0420010102060702121c12240320000e080703122012451224130704121c1511750108151175010a1511750102051511750108032000020306116d04200013000306114d05151175010a03061151042001010a05151175010203061159052001011d0503061171130704122015117501081511750102151175010a06151175011179100707127d128081120c12181d0509121c0320000a03200008052000118095040611809509000202118095118095042000127d23070c127d128081120c12141512808501121815128089020e081d12201245081218020e061001001d1e00040a01122007151280d501121807151280850112180520011300080715128089020e0805200102130006200113011300050002020e0e0907041280811d050a08072003081d050808072003011d050808110706121415128085011218121808081218080003020e0e1180dd1e07140a0a15128091011218080808090909080808080908080a1d050e121807151280910112180520010113000c070415128089020e08080e080500001280e10a200101151280e5011300082002021300101301072002011300130104200103080400010203072002080e1180dd072002020e1180dd042001020e0a07080a0809090908080a12070912101d05127d1280990a1d050a081d0509200301127d1180ed020c0005011280d1081280d108080600011180950a0b00021180951180951180950520010e1d050407020908140708080808080808151175011179151175011179092006010808080808080707041d09090908030701080f070c080a1d0508080a08080809090a0500020a0a0a050703080803060702122c1228040000124907151280a1011249052002011c18040701122c0907050e1d0e080e124904200108030620011d0e1d030520020102020520011d050e33071712341238127d1d050a081280ad1512809101123012381280b10a09151180b501123012300a09081280990a080812301249040000123508200301127d1235020715128091011230092000151180b501130007151180b50112300420010109042001010709200301127d118105020500020808080420001d0521070c1248151280b9010a091512809101123015128089020e02080a08090b1d050e06151280b9010a032000090715128089020e020320000b0520011d050805000012810905000012810d0b000312350812810912810d0607031d05080804070208080600030e0e0e0e0500001280c90307010a1007051214151280850112180812181224081512808902\
0e1218072002010e1280c50a070412181d051d05122408b77a5c561934e0890800000010000000000800000008000000000410270000080000000400000000040004000004504b030404504b010204504b050604010000000406000000040800000004400000000400080000044f080000087300610066006500106100620073006f006c007500740065001e640072006900760065002d007100750061006c00690066006900650064002070006100720065006e0074002d00740072006100760065007200730061006c00186e006f006e00630061006e006f006e006900630061006c00040000000002060a02060802060902060e0306123503061d090306127d03061d050706151175011179060615117501080606151175010a060615117501020306124904061280c9030612340306120c090615128089020e1218040612808d03061d0e0e000512451249114d11511155115908000212451249116d1f000a011c10116d10114d10114d10115110115110116d10116d101159101171350010011c10116d10114d10116d10114d10115910115110115110116d10116d10115910115910116d10115910114d101511750111790e0005121c1249114d115111551159080002128081127d0a0700021218120c0e10000315128085011218120c121412808d10000115128089020e08151280850112180400010e0e07000201120c12180f00051d05120c12180a11809512808d080003010a0a1180950600020e1d0508080002091d0512808d0a000215117501117908080400001d09070002021d051d05060002081d0508060002091d05080600011214120c05000112280e0b00011245151280a10112490800021245114d116d16000912451249116d116d116d1151115111511151116d0d0004011c10116d10114d1012490800021249114d116d16000912491249116d116d116d1151115111511151116d120006151280910112301280ad08080a0a12340300000106200201127d0a042001080a042001090a0620021d050a08052002010a0a06200212100a0a07200301127d0a0a0720020a0a1180c1072004010a080a0a14200b01080e1d050a0808090a0a1511750111790a082000151175011179092001011511750111790720001511750108082001011511750108072000151175010a08200101151175010a0720001511750102082001011511750102060002121c080e0c0007121c0e0a0a0808021d050600021220080e16000d1220080e020a0a0808020208020e15117501117905200201080e052002010e08062002010a123404200101050420001d0e052001011d0e10200801127d0a0a080a0a11809512808d04200012490328000a03280002032800080328000e0428001d05032800090828001511750111790728001511750108072800151175010a07280015117501020428001d0e0801000800000000001e01000100540216577261704e6f6e457863657074696f6e5468726f7773010801000200000000002d010028546f6f6c62656c742041726368697665205a4950204d656d6f727920434c522050726f7669646572000045010040534146452053514c20434c522070726f766964657220666f7220626f756e64656420696e2d6d656d6f7279205a495020656e7472792065787472616374696f6e00000d0100086765636f6d70617400001801001353514c2053657276657220546f6f6c62656c7400000501000000000c010007312e342e302e3000004901001a2e4e45544672616d65776f726b2c56657273696f6e3d76342e380100540e144672616d65776f726b446973706c61794e616d65122e4e4554204672616d65776f726b20342e38823e010006005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630154020949735072656369736501540e1146696c6c526f774d6574686f644e616d650746696c6c526f77540e0f5461626c65446566696e6974696f6e80c84572726f724e756d62657220696e742c204572726f724d657373616765206e766172636861722834303030292c20456e7472794e616d65206e766172636861722831303234292c20436f6d70726573736564427974657320626967696e742c20556e636f6d70726573736564427974657320626967696e742c20436f6d7072657373696f6e4d6574686f6420696e742c20437263333220696e742c204973456e63727970746564206269742c20456e7472795061796c6f61642076617262696e617279286d61782982bd010006005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a4461\
74614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630154020949735072656369736501540e1146696c6c526f774d6574686f644e616d650b46696c6c4c697374526f77540e0f5461626c65446566696e6974696f6e81434572726f724e756d62657220696e742c204572726f724d657373616765206e766172636861722834303030292c20456e7472794f7264696e616c20696e742c20456e7472794e616d65206e766172636861722831303234292c2049734469726563746f7279206269742c20436f6d70726573736564427974657320626967696e742c20556e636f6d70726573736564427974657320626967696e742c20436f6d7072657373696f6e4d6574686f6420696e742c20437263333220696e742c204973456e63727970746564206269742c20497345787472616374696f6e537570706f72746564206269742c204475706c6963617465436f756e7420696e742c2049735061746853616665206269742c2050617468537461747573206e76617263686172283332292c204c6173744d6f6469666965644174206461746574696d653228302981a2010004005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d4461746141636365737300000000540e1146696c6c526f774d6574686f644e616d651046696c6c577269746572537461747573540e0f5461626c65446566696e6974696f6e444572726f724e756d62657220696e742c204572726f724d657373616765206e766172636861722834303030292c205061796c6f61642076617262696e617279286d6178298146010004005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e697374696301540209497350726563697365018146010004005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630054020949735072656369736501000000000000000000000000000010000000000000000000000000000000b4b400000000000000000000ceb40000002000000000000000000000000000000000000000000000c0b40000000000000000000000005f436f72446c6c4d61696e006d73636f7265652e646c6c0000000000ff25002000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000\
00000000000000000000000000000100100000001800008000000000000000000000000000000100010000003000008000000000000000000000000000000100000000004800000058c00000fc0300000000000000000000fc0334000000560053005f00560045005200530049004f004e005f0049004e0046004f0000000000bd04effe00000100040001000000000004000100000000003f000000000000000400000002000000000000000000000000000000440000000100560061007200460069006c00650049006e0066006f00000000002400040000005400720061006e0073006c006100740069006f006e00000000000000b0045c030000010053007400720069006e006700460069006c00650049006e0066006f0000003803000001003000300030003000300034006200300000009a004100010043006f006d006d0065006e0074007300000053004100460045002000530051004c00200043004c0052002000700072006f0076006900640065007200200066006f007200200062006f0075006e00640065006400200069006e002d006d0065006d006f007200790020005a0049005000200065006e007400720079002000650078007400720061006300740069006f006e000000000032000900010043006f006d00700061006e0079004e0061006d006500000000006700650063006f006d00700061007400000000007a0029000100460069006c0065004400650073006300720069007000740069006f006e000000000054006f006f006c00620065006c0074002000410072006300680069007600650020005a004900500020004d0065006d006f0072007900200043004c0052002000500072006f007600690064006500720000000000300008000100460069006c006500560065007200730069006f006e000000000031002e0034002e0030002e00300000005e001f00010049006e007400650072006e0061006c004e0061006d006500000054006f006f006c00620065006c0074002e0041007200630068006900760065002e005a00690070004d0065006d006f00720079002e0064006c006c00000000002800020001004c006500670061006c0043006f00700079007200690067006800740000002000000066001f0001004f0072006900670069006e0061006c00460069006c0065006e0061006d006500000054006f006f006c00620065006c0074002e0041007200630068006900760065002e005a00690070004d0065006d006f00720079002e0064006c006c0000000000480014000100500072006f0064007500630074004e0061006d00650000000000530051004c002000530065007200760065007200200054006f006f006c00620065006c0074000000340008000100500072006f006400750063007400560065007200730069006f006e00000031002e0034002e0030002e003000000038000800010041007300730065006d0062006c0079002000560065007200730069006f006e00000031002e0034002e0030002e0030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b000000c000000e03400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
    , @AssemblyHash varbinary(64)
    , @InstalledAssemblyHash varbinary(64);

IF @ProductMajorVersion NOT IN (15, 16, 17)
    THROW 51330, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 51331, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;

IF OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable', N'P') IS NULL
    THROW 51332, N'Die Dependency toolbelt_core.USP_PrepareResultTable fehlt.', 1;
IF NOT EXISTS
   (
       SELECT 1
       FROM sys.extended_properties
       WHERE class = 0
         AND major_id = 0
         AND minor_id = 0
         AND name = @DependencyVersionProperty
   )
    THROW 51332, N'Die Dependency toolbelt.core.result-table ist nicht als Modul registriert.', 1;

DECLARE @DependencyVersion nvarchar(64)=(SELECT TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@DependencyVersionProperty);
IF @DependencyVersion IS NULL OR PARSENAME(@DependencyVersion,4) IS NOT NULL
 OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)) IS NULL OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,3))<1
 OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)) IS NULL OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,2))<0
 OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,1)) IS NULL OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,1))<0
 OR CONVERT(varbinary(128),@DependencyVersion)<>CONVERT(varbinary(128),CONCAT(TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)),N'.',TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)),N'.',TRY_CONVERT(int,PARSENAME(@DependencyVersion,1))))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(128),value))=CONVERT(varbinary(max),N'toolbelt.core.result-table'))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable') AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@DependencyVersion))
 THROW 51332,N'Die ResultTable-Dependency >=1.0.0 besitzt keinen kanonischen übereinstimmenden Vertrag.',2;

IF NOT EXISTS
   (
       SELECT 1
       FROM sys.configurations
       WHERE name = N'clr enabled'
         AND value_in_use = 1
   )
    THROW 51340, N'CLR ist auf dieser Instanz nicht aktiviert. Das Modul ändert keine Instanzoption.', 1;

IF NOT EXISTS
   (
       SELECT 1
       FROM sys.configurations
       WHERE name = N'clr strict security'
         AND value_in_use = 1
   )
    THROW 51342, N'clr strict security muss aktiviert bleiben.', 1;

IF @AssemblyBits IS NULL OR DATALENGTH(@AssemblyBits) < 1024
    THROW 51343, N'AssemblyBits enthält kein plausibles CLR-Release-Binary.', 1;

SET @AssemblyHash = HASHBYTES(N'SHA2_512', @AssemblyBits);

IF @AssemblyHash IS NULL
   OR NOT EXISTS
      (
          SELECT 1
          FROM sys.trusted_assemblies
          WHERE hash = @AssemblyHash
      )
    THROW 51345, N'Der exakte SHA2-512-Hash der CLR-ZIP-Assembly ist auf dieser Instanz nicht freigegeben.', 1;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), value)
FROM sys.extended_properties
WHERE class = 0
  AND major_id = 0
  AND minor_id = 0
  AND name = @VersionProperty;

SELECT @InstalledAssemblyHash = HASHBYTES(N'SHA2_512', af.content)
FROM sys.assemblies AS a
INNER JOIN sys.assembly_files AS af
  ON af.assembly_id = a.assembly_id
 AND af.file_id = 1
WHERE a.name = @AssemblyName;

IF @InstalledVersion IS NOT NULL
   AND @InstalledVersion NOT IN (N'1.0.0', N'1.1.0', N'1.2.0', N'1.3.0', N'1.4.0')
    THROW 51333, N'Die installierte Modulversion ist diesem Deployment nicht bekannt.', 1;

IF @InstalledVersion IS NULL
   AND
   (
       OBJECT_ID(N'toolbelt_archive.USP_ExtractZipEntryFromBinary') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.USP_ListZipEntriesFromBinary') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.TVF_InternalExtractZipEntryClr') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.TVF_InternalListZipEntriesClr') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.USP_CreateZipFromEntries') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterName') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterArchive') IS NOT NULL
       OR EXISTS
          (
              SELECT 1
              FROM sys.assemblies
              WHERE name = @AssemblyName
          )
   )
    THROW 51334, N'Ein Zielobjekt oder die Assembly stammt nicht aus einem bekannten Toolbelt-Release.', 1;

IF EXISTS(SELECT 1 FROM sys.objects o WHERE o.schema_id=SCHEMA_ID(N'toolbelt_archive')
 AND o.name IN(N'USP_CreateZipFromEntries',N'TVF_InternalZipWriterName',N'TVF_InternalZipWriterArchive')
 AND (@InstalledVersion NOT IN(N'1.3.0',N'1.4.0') OR @InstalledVersion IS NULL OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE e.class=1 AND e.major_id=o.object_id AND e.minor_id=0
 AND e.name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(128),e.value)=N'toolbelt.archive.zip-memory')))
 THROW 51334,N'Ein Writerziel ist nicht als Toolbelt-ZIP-Objekt markiert.',2;

IF SCHEMA_ID(N'toolbelt_archive') IS NULL
   AND HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    THROW 51335, N'In der Installationsdatenbank fehlt CREATE SCHEMA.', 1;
IF SCHEMA_ID(N'toolbelt_archive') IS NOT NULL
   AND HAS_PERMS_BY_NAME(N'toolbelt_archive', N'SCHEMA', N'ALTER') <> 1
    THROW 51335, N'Für toolbelt_archive fehlt ALTER.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE PROCEDURE') <> 1
    THROW 51335, N'In der Installationsdatenbank fehlt CREATE PROCEDURE.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
    THROW 51335, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;

IF EXISTS
   (
       SELECT 1
       FROM sys.assemblies
       WHERE name = @AssemblyName
   )
BEGIN
    IF ISNULL(@InstalledAssemblyHash, 0x) <> @AssemblyHash
       AND HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'ALTER ANY ASSEMBLY') <> 1
        THROW 51335, N'Für die vorhandene CLR-ZIP-Assembly fehlt ALTER ANY ASSEMBLY.', 1;
END
ELSE IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE ASSEMBLY') <> 1
    THROW 51335, N'In der Installationsdatenbank fehlt CREATE ASSEMBLY.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE @LockResult int;
    EXEC @LockResult = sys.sp_getapplock
          @Resource = N'toolbelt.deploy.toolbelt.archive.zip-memory'
        , @LockMode = N'Exclusive'
        , @LockOwner = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
        THROW 51337, N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.', 1;

    IF EXISTS(SELECT 1 FROM sys.objects o WHERE o.schema_id=SCHEMA_ID(N'toolbelt_archive')
     AND o.name IN(N'USP_CreateZipFromEntries',N'TVF_InternalZipWriterName',N'TVF_InternalZipWriterArchive')
     AND (@InstalledVersion NOT IN(N'1.3.0',N'1.4.0') OR @InstalledVersion IS NULL OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE e.class=1 AND e.major_id=o.object_id AND e.minor_id=0
     AND e.name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(128),e.value)=N'toolbelt.archive.zip-memory')))
     THROW 51334,N'Writerziel kollidiert nach Deploymentlock.',3;

    IF SCHEMA_ID(N'toolbelt_archive') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_archive];';

        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.Managed'
            , @value = 1
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_archive';

        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.SchemaCategory'
            , @value = N'archive'
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_archive';
    END;

    DROP FUNCTION IF EXISTS
        [toolbelt_archive].[TVF_InternalExtractZipEntryClr];

    DROP FUNCTION IF EXISTS
        [toolbelt_archive].[TVF_InternalListZipEntriesClr];
    DROP FUNCTION IF EXISTS [toolbelt_archive].[TVF_InternalZipWriterName];
    DROP FUNCTION IF EXISTS [toolbelt_archive].[TVF_InternalZipWriterArchive];

    IF @InstalledAssemblyHash IS NULL
       OR @InstalledAssemblyHash <> @AssemblyHash
    BEGIN
        DECLARE @AssemblyDdl nvarchar(max) =
            CASE
                WHEN EXISTS
                     (
                         SELECT 1
                         FROM sys.assemblies
                         WHERE name = @AssemblyName
                     )
                    THEN N'ALTER ASSEMBLY [Toolbelt_Archive_ZipMemory]'
                ELSE N'CREATE ASSEMBLY [Toolbelt_Archive_ZipMemory]'
            END
            + N' FROM '
            + CONVERT(nvarchar(max), @AssemblyBits, 1)
            + N' WITH PERMISSION_SET = SAFE;';

        EXEC sys.sp_executesql @AssemblyDdl;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/*
 * Interner Providervertrag. Öffentliche Aufrufer verwenden ausschließlich
 * toolbelt_archive.USP_ExtractZipEntryFromBinary.
 */
IF OBJECT_ID(N'toolbelt_archive.TVF_InternalExtractZipEntryClr', N'FT') IS NOT NULL
    DROP FUNCTION [toolbelt_archive].[TVF_InternalExtractZipEntryClr];
GO

CREATE FUNCTION [toolbelt_archive].[TVF_InternalExtractZipEntryClr]
(
      @ZipArchive          varbinary(max)
    , @EntryName           nvarchar(1024)
    , @MaxEntryBytes       bigint
    , @MaxCompressionRatio decimal(9,2)
    , @FailIfEncrypted     bit
)
RETURNS TABLE
(
      ErrorNumber          int
    , ErrorMessage         nvarchar(4000)
    , EntryName            nvarchar(1024)
    , CompressedBytes      bigint
    , UncompressedBytes    bigint
    , CompressionMethod    int
    , Crc32                int
    , IsEncrypted          bit
    , EntryPayload         varbinary(max)
)
AS EXTERNAL NAME
    [Toolbelt_Archive_ZipMemory]
    .[Toolbelt.Archive.ZipMemory.ZipEntryProvider]
    .[ExtractZipEntry];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE FUNCTION [toolbelt_archive].[TVF_InternalListZipEntriesClr]
(
      @ZipArchive varbinary(max)
    , @MaxEntries int
)
RETURNS TABLE
(
      ErrorNumber          int            NULL
    , ErrorMessage         nvarchar(4000) NULL
    , EntryOrdinal         int            NULL
    , EntryName            nvarchar(1024) NULL
    , IsDirectory          bit            NULL
    , CompressedBytes      bigint         NULL
    , UncompressedBytes    bigint         NULL
    , CompressionMethod    int            NULL
    , Crc32                int            NULL
    , IsEncrypted          bit            NULL
    , IsExtractionSupported bit           NULL
    , DuplicateCount       int            NULL
    , IsPathSafe           bit            NULL
    , PathStatus           nvarchar(32)   NULL
    , LastModifiedAt       datetime2(0)   NULL
)
AS EXTERNAL NAME
    [Toolbelt_Archive_ZipMemory]
    .[Toolbelt.Archive.ZipMemory.ZipEntryProvider]
    .[ListZipEntriesFromBinary];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_archive].[USP_ExtractZipEntryFromBinary]
(
      @ZipArchive          varbinary(max) = NULL
    , @EntryName           nvarchar(1024) = NULL
    , @MaxEntryBytes       bigint         = 16777216
    , @MaxCompressionRatio decimal(9,2)   = 200.00
    , @FailIfEncrypted     bit            = 1
    , @ResultTable         sysname        = NULL
    , @KeepData            bit            = 0
    , @Debug               tinyint        = 0
    , @Hilfe               bit            = 0
)
AS
BEGIN
    SET NOCOUNT ON;

    SET @FailIfEncrypted = ISNULL(@FailIfEncrypted, 1);
    SET @KeepData = ISNULL(@KeepData, 0);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    IF @Hilfe = 1
    BEGIN
        -- API_PARAMETER_HELP:BEGIN
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
            CAST(N'toolbelt_archive' AS sysname) AS SchemaName,
            CAST(N'USP_ExtractZipEntryFromBinary' AS sysname) AS ObjectName,
            CAST(v.Section AS varchar(32)) AS Section, CAST(v.Ordinal AS int) AS Ordinal,
            CAST(v.ItemName AS sysname) AS ItemName, CAST(v.SqlDataType AS varchar(256)) AS SqlDataType,
            CAST(v.IsRequired AS bit) AS IsRequired, CAST(v.IsNullable AS bit) AS IsNullable,
            CAST(v.DefaultValue AS nvarchar(4000)) AS DefaultValue,
            CAST(v.Description AS nvarchar(max)) AS Description,
            CAST(v.ExampleSql AS nvarchar(max)) AS ExampleSql
        FROM (VALUES
        (N'DESCRIPTION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Extrahiert einen einzelnen benannten ZIP-Entry aus einem varbinary(max)-Archiv im Speicher. Der interne SAFE-CLR-Provider unterstützt ZIP Methods 0 und 8 und prüft die CRC32 des tatsächlichen Payloads.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 1, N'EntryName', N'nvarchar(1024)', 1, 0, NULL, CAST(N'Exakter Entry-Name aus dem Central Directory.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 2, N'CompressedBytes', N'bigint', 1, 0, NULL, CAST(N'Komprimierte Entry-Größe laut Central Directory.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 3, N'UncompressedBytes', N'bigint', 1, 0, NULL, CAST(N'Unkomprimierte Entry-Größe, nach erfolgreicher Extraktion gegen die tatsächliche Ausgabe geprüft.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 4, N'CompressionMethod', N'int', 1, 0, NULL, CAST(N'ZIP Compression Method. Unterstützt werden 0 (Stored) und 8 (Deflate).' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 5, N'Crc32', N'int', 0, 1, NULL, CAST(N'CRC32 des tatsächlichen Payloads als SQL-int-Bitmuster. Bei verschlüsseltem Status stammt der Wert aus dem Central Directory.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 6, N'IsEncrypted', N'bit', 1, 0, NULL, CAST(N'1 kennzeichnet einen als verschlüsselt markierten Entry.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 7, N'EntryPayload', N'varbinary(max)', 0, 1, NULL, CAST(N'Dekomprimierter Payload. Bei @FailIfEncrypted=0 und verschlüsseltem Entry ist der Wert NULL.' AS nvarchar(max)), NULL),
        (N'ERROR', 1, N'51320-51329', NULL, NULL, NULL, NULL, CAST(N'Parameter-, ZIP-Struktur-, Limit-, Feature-, Integritäts- und Providerfehlerbereich.' AS nvarchar(max)), NULL),
        (N'PERMISSION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Erforderlich sind EXECUTE auf diesem Objekt und bei @ResultTable zusätzlich EXECUTE auf toolbelt_core.USP_PrepareResultTable.' AS nvarchar(max)), NULL),
        (N'LIMITATION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Nicht unterstützt: ZIP64, Multi-Disk, Verschlüsselungsentschlüsselung, Deflate64, unbekannte Methods und zusätzliche Central-Directory-Datensätze.' AS nvarchar(max)), NULL),
        (N'LIMITATION', 2, NULL, NULL, NULL, NULL, NULL, CAST(N'Harte Providerlimits: 268435456 Archivbytes, 134217728 komprimierte Entry-Bytes und 10000 Entries.' AS nvarchar(max)), NULL),
        (N'EXAMPLE', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Extrahiert deflated.txt aus einem synthetischen ZIP-BLOB.' AS nvarchar(max)), CAST(N'DECLARE @ZipArchive varbinary(max) = 0x...;
EXEC toolbelt_archive.USP_ExtractZipEntryFromBinary
      @ZipArchive = @ZipArchive
    , @EntryName = N''deflated.txt'';' AS nvarchar(max))),
        (N'PARAMETER', 1, N'@ZipArchive', N'varbinary(max)', 1, 0, N'NULL', CAST(N'Vollständiger nicht leerer ZIP-Bytepuffer varbinary(max), kein Pfad/Base64text. NULL (technischer Help-Default)/0x ungültig. Harte Readergrenze 268435456 Archivbytes, höchstens 10000 Entries, Namen höchstens 1024 UTF-16-Einheiten; keine ZIP64-/Multi-Disk-Unterstützung. Namen werden nach Flag11 als UTF-8, sonst CP437 decodiert. Metadatenlisting ist keine CRC-/Payloadvalidierung aller Einträge.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 2, N'@EntryName', N'nvarchar(1024)', 1, 0, N'NULL', CAST(N'Exakter nicht leerer Entryname aus dem Central Directory, nvarchar(1024), ordinal/case- und längensensitiv einschließlich trailing Spaces. Keine Wildcards, Normalisierung oder automatische Pfad-/Casekorrektur. NULL ungültig, kein Treffer 51322, mehrfach gleicher gesuchter Name 51323. Das Binary-API extrahiert Bytes und benutzt diesen Namen nicht als Dateisystemziel; ToFile verwendet ausschließlich RelativePath.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 3, N'@MaxEntryBytes', N'bigint', 0, 1, N'16777216', CAST(N'Ganzzahl 1..67108864 unkomprimierte Bytes des ausgewählten Entries, Default 16777216. NULL/0/negativ/höher ungültig. Prüfung der Deklaration und tatsächlichen Dekompression; unabhängig davon harte Grenze 134217728 komprimierte Bytes. Readergrenze unterscheidet sich von der Writer-Entrygrenze.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 4, N'@MaxCompressionRatio', N'decimal(9,2)', 0, 1, N'200.00', CAST(N'decimal(9,2) im Bereich 1.00..9999999.99, Default 200.00; unkomprimierte/komprimierte Bytes als Faktor, kein Prozentwert. NULL/<1 ungültig. Deklarierte und tatsächliche Expansionsprüfung; nicht leere Ausgabe aus 0 komprimierten Bytes ist ungültig. Gilt für tatsächliche Extraktion, nicht den erlaubten verschlüsselten Metadatenpfad.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 5, N'@FailIfEncrypted', N'bit', 0, 1, N'1', CAST(N'Taxativ im gebundenen bit: 1 lehnt einen verschlüsselten ausgewählten Entry mit 51324 ab (Default); 0 liefert ausschließlich dessen Metadaten mit IsEncrypted=1 und EntryPayload=NULL, keine Entschlüsselung/Passwortübergabe. NULL wird wie 1 normalisiert. Der erlaubte Metadatenpfad passiert vor Method-/Payloadgrößen-/Ratio-/CRC-Extraktionsprüfungen; er qualifiziert keine lesbare Payload.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 6, N'@ResultTable', N'sysname', 0, 1, N'NULL', CAST(N'NULL (Default) liefert den fachlichen SELECT-Resultset. Sonst ein einzelner sysname mit 2..116 UTF-16-Einheiten einschließlich führendem # als Name einer bereits im Caller-Scope angelegten lokalen #Temp-Tabelle, z.B. N''#Result''; keine globale ##Temp, persistente oder mehrteilige Tabelle. Der ResultTable-Helper muss verfügbar sein; die Ausgabeform wird anhand des konkreten Objektresultsets vorbereitet.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 7, N'@KeepData', N'bit', 0, 1, N'0', CAST(N'Taxativ für bit: 0 ersetzt Ergebnisdaten (Default), 1 hängt bei kompatibler ResultTable an; NULL entspricht 0. Nur bei nicht-NULL ResultTable relevant; Schema- und Datenbehandlung folgen dem kanonischen ResultTable-Vertrag.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 8, N'@Debug', N'tinyint', 0, 1, N'0', CAST(N'tinyint 0..255, Default 0; NULL wirkt wie 0. Keine eigene zusätzliche Readerdiagnose; im ResultTable-Pfad an den kanonischen Helper weitergereicht.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 9, N'@Hilfe', N'bit', 0, 1, N'0', CAST(N'Taxativ für bit: 1 liefert nur die Standardhilfe vor der Fachvalidierung; 0 (Default) führt den Fachaufruf aus. NULL wird wie 0 behandelt. Syntaktisch erforderliche Argumente ohne technischen Default müssen auch beim Help-Aufruf angegeben werden.' AS nvarchar(max)), NULL)
        ) AS v(Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql)
        ORDER BY CASE v.Section WHEN 'DESCRIPTION' THEN 0 WHEN 'PARAMETER' THEN 1
            WHEN 'RESULT_COLUMN' THEN 2 WHEN 'EXAMPLE' THEN 3 ELSE 4 END, v.Ordinal;
        RETURN 0;
        -- API_PARAMETER_HELP:END
    END;

    IF @ZipArchive IS NULL OR DATALENGTH(@ZipArchive) = 0
        THROW 51320, N'@ZipArchive muss einen nicht leeren ZIP-Container enthalten.', 1;
    IF @EntryName IS NULL OR LEN(@EntryName) = 0
        THROW 51320, N'@EntryName muss gesetzt sein.', 1;
    IF @MaxEntryBytes IS NULL
       OR @MaxEntryBytes <= 0
       OR @MaxEntryBytes > 67108864
        THROW 51320, N'@MaxEntryBytes muss zwischen 1 und 67108864 liegen.', 1;
    IF @MaxCompressionRatio IS NULL OR @MaxCompressionRatio < 1
        THROW 51320, N'@MaxCompressionRatio muss größer oder gleich 1 sein.', 1;

    IF OBJECT_ID(N'toolbelt_archive.TVF_InternalExtractZipEntryClr', N'FT') IS NULL
        THROW 51329, N'Der interne CLR-ZIP-Provider ist nicht installiert.', 1;

    DECLARE @ProviderResult TABLE
    (
          ErrorNumber       int            NULL
        , ErrorMessage      nvarchar(4000) NULL
        , EntryName         nvarchar(1024) NULL
        , CompressedBytes   bigint         NULL
        , UncompressedBytes bigint         NULL
        , CompressionMethod int            NULL
        , Crc32             int            NULL
        , IsEncrypted       bit            NULL
        , EntryPayload      varbinary(max) NULL
    );

    INSERT INTO @ProviderResult
    (
          ErrorNumber
        , ErrorMessage
        , EntryName
        , CompressedBytes
        , UncompressedBytes
        , CompressionMethod
        , Crc32
        , IsEncrypted
        , EntryPayload
    )
    SELECT
          ErrorNumber
        , ErrorMessage
        , EntryName
        , CompressedBytes
        , UncompressedBytes
        , CompressionMethod
        , Crc32
        , IsEncrypted
        , EntryPayload
    FROM toolbelt_archive.TVF_InternalExtractZipEntryClr
    (
          @ZipArchive
        , @EntryName
        , @MaxEntryBytes
        , @MaxCompressionRatio
        , @FailIfEncrypted
    );

    IF (SELECT COUNT_BIG(*) FROM @ProviderResult) <> 1
        THROW 51329, N'Der interne CLR-ZIP-Provider lieferte keinen eindeutigen Status.', 1;

    DECLARE
          @ProviderErrorNumber int
        , @ProviderErrorMessage nvarchar(2048);

    SELECT
          @ProviderErrorNumber = ErrorNumber
        , @ProviderErrorMessage =
              CONVERT(nvarchar(2048), LEFT(ErrorMessage, 2048))
    FROM @ProviderResult;

    IF @ProviderErrorNumber IS NOT NULL
    BEGIN
        IF @ProviderErrorNumber NOT BETWEEN 51320 AND 51329
            THROW 51329, N'Der interne CLR-ZIP-Provider lieferte einen ungültigen Fehlercode.', 1;

        SET @ProviderErrorMessage =
            COALESCE(NULLIF(@ProviderErrorMessage, N''), N'Der CLR-ZIP-Provider hat den Vorgang abgebrochen.');

        THROW @ProviderErrorNumber, @ProviderErrorMessage, 1;
    END;

    CREATE TABLE #tbx_ZipMemory_ResultSource
    (
          EntryName         nvarchar(1024) NOT NULL
        , CompressedBytes   bigint         NOT NULL
        , UncompressedBytes bigint         NOT NULL
        , CompressionMethod int            NOT NULL
        , Crc32             int            NULL
        , IsEncrypted       bit            NOT NULL
        , EntryPayload      varbinary(max) NULL
    );

    INSERT INTO #tbx_ZipMemory_ResultSource
    (
          EntryName
        , CompressedBytes
        , UncompressedBytes
        , CompressionMethod
        , Crc32
        , IsEncrypted
        , EntryPayload
    )
    SELECT
          EntryName
        , CompressedBytes
        , UncompressedBytes
        , CompressionMethod
        , Crc32
        , IsEncrypted
        , EntryPayload
    FROM @ProviderResult;

    IF @ResultTable IS NULL
    BEGIN
        SELECT
              EntryName
            , CompressedBytes
            , UncompressedBytes
            , CompressionMethod
            , Crc32
            , IsEncrypted
            , EntryPayload
        FROM #tbx_ZipMemory_ResultSource;

        RETURN 0;
    END;

    IF OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable', N'P') IS NULL
        THROW 51329, N'Die ResultTable-Dependency toolbelt_core.USP_PrepareResultTable ist nicht installiert.', 1;

    CREATE TABLE #tbx_ZipMemory_ResultShape
    (
          EntryName         nvarchar(1024) NOT NULL
        , CompressedBytes   bigint         NOT NULL
        , UncompressedBytes bigint         NOT NULL
        , CompressionMethod int            NOT NULL
        , Crc32             int            NULL
        , IsEncrypted       bit            NOT NULL
        , EntryPayload      varbinary(max) NULL
    );

    EXEC toolbelt_core.USP_PrepareResultTable
          @ResultTableToAlter = @ResultTable
        , @LikeTable          = N'#tbx_ZipMemory_ResultShape'
        , @KeepData           = @KeepData
        , @Debug              = @Debug;

    DECLARE @InsertSql nvarchar(max) =
        N'INSERT INTO ' + QUOTENAME(@ResultTable) + N'
        (
              EntryName
            , CompressedBytes
            , UncompressedBytes
            , CompressionMethod
            , Crc32
            , IsEncrypted
            , EntryPayload
        )
        SELECT
              EntryName
            , CompressedBytes
            , UncompressedBytes
            , CompressionMethod
            , Crc32
            , IsEncrypted
            , EntryPayload
        FROM #tbx_ZipMemory_ResultSource;';

    EXEC sys.sp_executesql @InsertSql;

    RETURN 0;
END;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_archive].[USP_ListZipEntriesFromBinary]
(
      @ZipArchive  varbinary(max) = NULL
    , @MaxEntries  int            = 10000
    , @ResultTable sysname        = NULL
    , @KeepData    bit            = 0
    , @Debug       tinyint        = 0
    , @Hilfe       bit            = 0
)
AS
BEGIN
    SET NOCOUNT ON;

    SET @KeepData = ISNULL(@KeepData, 0);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    IF @Hilfe = 1
    BEGIN
        -- API_PARAMETER_HELP:BEGIN
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
            CAST(N'toolbelt_archive' AS sysname) AS SchemaName,
            CAST(N'USP_ListZipEntriesFromBinary' AS sysname) AS ObjectName,
            CAST(v.Section AS varchar(32)) AS Section, CAST(v.Ordinal AS int) AS Ordinal,
            CAST(v.ItemName AS sysname) AS ItemName, CAST(v.SqlDataType AS varchar(256)) AS SqlDataType,
            CAST(v.IsRequired AS bit) AS IsRequired, CAST(v.IsNullable AS bit) AS IsNullable,
            CAST(v.DefaultValue AS nvarchar(4000)) AS DefaultValue,
            CAST(v.Description AS nvarchar(max)) AS Description,
            CAST(v.ExampleSql AS nvarchar(max)) AS ExampleSql
        FROM (VALUES
        (N'DESCRIPTION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Listet deklarierte Metadaten aller Central-Directory-Entries eines klassischen Single-Disk-ZIP aus varbinary(max), ohne Payloads zu lesen oder zu dekomprimieren.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 1, N'EntryOrdinal', N'int', 1, 0, NULL, CAST(N'Einsbasierte Position im Central Directory.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 2, N'EntryName', N'nvarchar(1024)', 1, 0, NULL, CAST(N'Exakt dekodierter, nicht normalisierter Entry-Name.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 3, N'IsDirectory', N'bit', 1, 0, NULL, CAST(N'Aus einem abschließenden Schrägstrich abgeleitete Directory-Markierung.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 4, N'CompressedBytes', N'bigint', 1, 0, NULL, CAST(N'Deklarierte komprimierte Größe.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 5, N'UncompressedBytes', N'bigint', 1, 0, NULL, CAST(N'Deklarierte unkomprimierte Größe.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 6, N'CompressionMethod', N'int', 1, 0, NULL, CAST(N'Numerischer ZIP-Methodenwert.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 7, N'Crc32', N'int', 1, 0, NULL, CAST(N'Deklarierte und beim Listing nicht neu berechnete CRC32.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 8, N'IsEncrypted', N'bit', 1, 0, NULL, CAST(N'Verschlüsselungsstatus aus den General-Purpose-Flags.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 9, N'IsExtractionSupported', N'bit', 1, 0, NULL, CAST(N'1 nur für unverschlüsselte Methods 0 und 8.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 10, N'DuplicateCount', N'int', 1, 0, NULL, CAST(N'Ordinal und case-sensitive gezählte Namensduplikate.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 11, N'IsPathSafe', N'bit', 1, 0, NULL, CAST(N'1 nur für einen kanonischen relativen Pfad.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 12, N'PathStatus', N'varchar(32)', 1, 0, NULL, CAST(N'safe, absolute, drive-qualified, parent-traversal oder noncanonical.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 13, N'LastModifiedAt', N'datetime2(0)', 0, 1, NULL, CAST(N'DOS-Zeit ohne Zeitzonenbehauptung; bei ungültigem Wert NULL.' AS nvarchar(max)), NULL),
        (N'ERROR', 1, N'51320-51329', NULL, NULL, NULL, NULL, CAST(N'Parameter-, Struktur-, Limit-, Feature- und Providerfehlerbereich.' AS nvarchar(max)), NULL),
        (N'LIMITATION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'ZIP64 und Multi-Disk werden abgelehnt. Metadaten sind keine Integritätsbestätigung des Payloads.' AS nvarchar(max)), NULL),
        (N'EXAMPLE', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Listet alle Entries eines ZIP-BLOBs.' AS nvarchar(max)), CAST(N'EXEC toolbelt_archive.USP_ListZipEntriesFromBinary @ZipArchive = 0x...;' AS nvarchar(max))),
        (N'PARAMETER', 1, N'@ZipArchive', N'varbinary(max)', 1, 0, N'NULL', CAST(N'Vollständiger nicht leerer ZIP-Bytepuffer varbinary(max), kein Pfad/Base64text. NULL (technischer Help-Default)/0x ungültig. Harte Readergrenze 268435456 Archivbytes, höchstens 10000 Entries, Namen höchstens 1024 UTF-16-Einheiten; keine ZIP64-/Multi-Disk-Unterstützung. Namen werden nach Flag11 als UTF-8, sonst CP437 decodiert. Metadatenlisting ist keine CRC-/Payloadvalidierung aller Einträge.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 2, N'@MaxEntries', N'int', 0, 0, N'10000', CAST(N'Ganzzahl 1..10000 Central-Directory-Entries, Default 10000. NULL/0/negativ/höher ungültig. Überschreitung verwirft den gesamten Aufruf, kein gültiges TOP-Präfix; keine Payloadextraktion durch dieses Limit.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 3, N'@ResultTable', N'sysname', 0, 1, N'NULL', CAST(N'NULL (Default) liefert den fachlichen SELECT-Resultset. Sonst ein einzelner sysname mit 2..116 UTF-16-Einheiten einschließlich führendem # als Name einer bereits im Caller-Scope angelegten lokalen #Temp-Tabelle, z.B. N''#Result''; keine globale ##Temp, persistente oder mehrteilige Tabelle. Der ResultTable-Helper muss verfügbar sein; die Ausgabeform wird anhand des konkreten Objektresultsets vorbereitet.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 4, N'@KeepData', N'bit', 0, 1, N'0', CAST(N'Taxativ für bit: 0 ersetzt Ergebnisdaten (Default), 1 hängt bei kompatibler ResultTable an; NULL entspricht 0. Nur bei nicht-NULL ResultTable relevant; Schema- und Datenbehandlung folgen dem kanonischen ResultTable-Vertrag.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 5, N'@Debug', N'tinyint', 0, 1, N'0', CAST(N'tinyint 0..255, Default 0; NULL wirkt wie 0. Keine eigene zusätzliche Readerdiagnose; im ResultTable-Pfad an den kanonischen Helper weitergereicht.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 6, N'@Hilfe', N'bit', 0, 1, N'0', CAST(N'Taxativ für bit: 1 liefert nur die Standardhilfe vor der Fachvalidierung; 0 (Default) führt den Fachaufruf aus. NULL wird wie 0 behandelt. Syntaktisch erforderliche Argumente ohne technischen Default müssen auch beim Help-Aufruf angegeben werden.' AS nvarchar(max)), NULL)
        ) AS v(Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql)
        ORDER BY CASE v.Section WHEN 'DESCRIPTION' THEN 0 WHEN 'PARAMETER' THEN 1
            WHEN 'RESULT_COLUMN' THEN 2 WHEN 'EXAMPLE' THEN 3 ELSE 4 END, v.Ordinal;
        RETURN 0;
        -- API_PARAMETER_HELP:END
    END;

    IF @ZipArchive IS NULL OR DATALENGTH(@ZipArchive) = 0
        THROW 51320, N'@ZipArchive muss einen nicht leeren ZIP-Container enthalten.', 1;
    IF @MaxEntries IS NULL OR @MaxEntries < 1 OR @MaxEntries > 10000
        THROW 51320, N'@MaxEntries muss zwischen 1 und 10000 liegen.', 1;
    IF OBJECT_ID(N'toolbelt_archive.TVF_InternalListZipEntriesClr', N'FT') IS NULL
        THROW 51329, N'Der interne CLR-ZIP-Metadatenprovider ist nicht installiert.', 1;

    DECLARE @ProviderResult TABLE
    (
          ErrorNumber           int            NULL
        , ErrorMessage          nvarchar(4000) NULL
        , EntryOrdinal          int            NULL
        , EntryName             nvarchar(1024) NULL
        , IsDirectory           bit            NULL
        , CompressedBytes       bigint         NULL
        , UncompressedBytes     bigint         NULL
        , CompressionMethod     int            NULL
        , Crc32                 int            NULL
        , IsEncrypted           bit            NULL
        , IsExtractionSupported bit            NULL
        , DuplicateCount        int            NULL
        , IsPathSafe            bit            NULL
        , PathStatus            nvarchar(32)   NULL
        , LastModifiedAt        datetime2(0)   NULL
    );

    INSERT INTO @ProviderResult
    (
          ErrorNumber, ErrorMessage, EntryOrdinal, EntryName, IsDirectory
        , CompressedBytes, UncompressedBytes, CompressionMethod, Crc32
        , IsEncrypted, IsExtractionSupported, DuplicateCount, IsPathSafe
        , PathStatus, LastModifiedAt
    )
    SELECT
          ErrorNumber, ErrorMessage, EntryOrdinal, EntryName, IsDirectory
        , CompressedBytes, UncompressedBytes, CompressionMethod, Crc32
        , IsEncrypted, IsExtractionSupported, DuplicateCount, IsPathSafe
        , PathStatus, LastModifiedAt
    FROM toolbelt_archive.TVF_InternalListZipEntriesClr(@ZipArchive, @MaxEntries);

    IF EXISTS (SELECT 1 FROM @ProviderResult WHERE ErrorNumber IS NOT NULL)
    BEGIN
        IF (SELECT COUNT_BIG(*) FROM @ProviderResult) <> 1
            THROW 51329, N'Der interne CLR-ZIP-Metadatenprovider lieferte einen inkonsistenten Fehlerstatus.', 1;

        DECLARE
              @ProviderErrorNumber int
            , @ProviderErrorMessage nvarchar(2048);

        SELECT
              @ProviderErrorNumber = ErrorNumber
            , @ProviderErrorMessage = CONVERT(nvarchar(2048), LEFT(ErrorMessage, 2048))
        FROM @ProviderResult;

        IF @ProviderErrorNumber NOT BETWEEN 51320 AND 51329
            THROW 51329, N'Der interne CLR-ZIP-Metadatenprovider lieferte einen ungültigen Fehlercode.', 1;

        SET @ProviderErrorMessage = COALESCE(NULLIF(@ProviderErrorMessage, N''), N'Der CLR-ZIP-Metadatenprovider hat den Vorgang abgebrochen.');
        THROW @ProviderErrorNumber, @ProviderErrorMessage, 1;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM @ProviderResult
           WHERE EntryOrdinal IS NULL
              OR EntryName IS NULL
              OR IsDirectory IS NULL
              OR CompressedBytes IS NULL
              OR UncompressedBytes IS NULL
              OR CompressionMethod IS NULL
              OR Crc32 IS NULL
              OR IsEncrypted IS NULL
              OR IsExtractionSupported IS NULL
              OR DuplicateCount IS NULL
              OR IsPathSafe IS NULL
              OR PathStatus IS NULL
       )
        THROW 51329, N'Der interne CLR-ZIP-Metadatenprovider lieferte eine unvollständige Datenzeile.', 1;

    CREATE TABLE #tbx_ZipList_ResultSource
    (
          EntryOrdinal          int            NOT NULL
        , EntryName             nvarchar(1024) NOT NULL
        , IsDirectory           bit            NOT NULL
        , CompressedBytes       bigint         NOT NULL
        , UncompressedBytes     bigint         NOT NULL
        , CompressionMethod     int            NOT NULL
        , Crc32                 int            NOT NULL
        , IsEncrypted           bit            NOT NULL
        , IsExtractionSupported bit            NOT NULL
        , DuplicateCount        int            NOT NULL
        , IsPathSafe            bit            NOT NULL
        , PathStatus            varchar(32)    NOT NULL
        , LastModifiedAt        datetime2(0)   NULL
    );

    INSERT INTO #tbx_ZipList_ResultSource
    SELECT
          EntryOrdinal, EntryName, IsDirectory, CompressedBytes
        , UncompressedBytes, CompressionMethod, Crc32, IsEncrypted
        , IsExtractionSupported, DuplicateCount, IsPathSafe
        , CONVERT(varchar(32), PathStatus), LastModifiedAt
    FROM @ProviderResult;

    IF @ResultTable IS NULL
    BEGIN
        SELECT
              EntryOrdinal, EntryName, IsDirectory, CompressedBytes
            , UncompressedBytes, CompressionMethod, Crc32, IsEncrypted
            , IsExtractionSupported, DuplicateCount, IsPathSafe, PathStatus
            , LastModifiedAt
        FROM #tbx_ZipList_ResultSource
        ORDER BY EntryOrdinal;
        RETURN 0;
    END;

    IF OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable', N'P') IS NULL
        THROW 51329, N'Die ResultTable-Dependency toolbelt_core.USP_PrepareResultTable ist nicht installiert.', 1;

    CREATE TABLE #tbx_ZipList_ResultShape
    (
          EntryOrdinal          int            NOT NULL
        , EntryName             nvarchar(1024) NOT NULL
        , IsDirectory           bit            NOT NULL
        , CompressedBytes       bigint         NOT NULL
        , UncompressedBytes     bigint         NOT NULL
        , CompressionMethod     int            NOT NULL
        , Crc32                 int            NOT NULL
        , IsEncrypted           bit            NOT NULL
        , IsExtractionSupported bit            NOT NULL
        , DuplicateCount        int            NOT NULL
        , IsPathSafe            bit            NOT NULL
        , PathStatus            varchar(32)    NOT NULL
        , LastModifiedAt        datetime2(0)   NULL
    );

    EXEC toolbelt_core.USP_PrepareResultTable
          @ResultTableToAlter = @ResultTable
        , @LikeTable          = N'#tbx_ZipList_ResultShape'
        , @KeepData           = @KeepData
        , @Debug              = @Debug;

    DECLARE @InsertSql nvarchar(max) =
        N'INSERT INTO ' + QUOTENAME(@ResultTable) + N'
        SELECT
              EntryOrdinal, EntryName, IsDirectory, CompressedBytes
            , UncompressedBytes, CompressionMethod, Crc32, IsEncrypted
            , IsExtractionSupported, DuplicateCount, IsPathSafe, PathStatus
            , LastModifiedAt
        FROM #tbx_ZipList_ResultSource;';

    EXEC sys.sp_executesql @InsertSql;
    RETURN 0;
END;
GO
SET ANSI_NULLS ON;
-- Interne CLR-Status-TVFs, Modul1.3.0; keine öffentliche Fach-API.
-- Zweck: validierter UTF8-Namenstransport und bounded Binary-Envelope→ZIP.
-- DataAccess/SystemDataAccess None; keine Datenabfrage/Datei-I/O/Rechteausweitung.
-- Eine Statuszeile ErrorNumber/ErrorMessage/Payload; USP setzt TSQL-THROW um.
-- Erwartete Fehler51350–51359, unerwartete Enginefehler bleiben Originalfehler.
-- Dependency: Toolbelt_Archive_ZipMemory, Assemblyrelease 1.3.0 (SAFE).
SET QUOTED_IDENTIFIER ON;
GO
-- Name-Binding: strenges UTF-16-Validieren vor UTF-8-Encoding; eine Statuszeile.
CREATE FUNCTION toolbelt_archive.TVF_InternalZipWriterName(@Name nvarchar(max), @MaxUnits int)
RETURNS TABLE(ErrorNumber int, ErrorMessage nvarchar(4000), Payload varbinary(max))
AS EXTERNAL NAME [Toolbelt_Archive_ZipMemory].[Toolbelt.Archive.ZipMemory.ZipEntryProvider].[EncodeWriterNameStatus];
GO
-- Archive-Binding: TBZW-Version-1-Envelope ohne ContextConnection/Dateifallback;
-- vollständiges Stored-/Deflate-ZIP oder erwarteter Statusfehler, nie Teiloutput.
CREATE FUNCTION toolbelt_archive.TVF_InternalZipWriterArchive
(@Envelope varbinary(max), @Method int, @MaxEntries int, @MaxNameUnits int,
 @MaxEntry bigint, @MaxTotal bigint, @MaxArchive bigint, @MaxEnvelope bigint, @Budget int)
RETURNS TABLE(ErrorNumber int, ErrorMessage nvarchar(4000), Payload varbinary(max))
AS EXTERNAL NAME [Toolbelt_Archive_ZipMemory].[Toolbelt.Archive.ZipMemory.ZipEntryProvider].[CreateWriterArchiveStatus];
GO
-- ============================================================================
-- Objekt: toolbelt_archive.USP_CreateZipFromEntries; Typ: Stored Procedure
-- Zweck: Begrenztes In-memory-ZIP aus caller-lokaler Entrytabelle erzeugen.
-- Vertrag: Documentation/USP_CreateZipFromEntries.md; USP_CONTRACT 1.0.
-- Parameter: EntryTable, Stored/Deflate, positive Ressourcenlimits; Standard-
-- Defaults 256 Entries/16 MiB Entry/64 MiB Summe/68 MiB Output und Envelope.
-- Resultset: ArchivePayload, ArchiveBytes, EntryCount, TotalPayloadBytes,
-- CompressionMethod; Dependencies: SAFE-ZIP-CLR, ResultTable >=1.0.0.
-- Rechte: EXECUTE, eigene lokale Temps; keine Rechte-/Trustausweitung.
-- Versionen: SQL Server 2019/2022/2025; Plattformen: Windows/Linux.
-- Fehler: 51350–51359; keine Teilarchive, callerfreundliche Savepoints.
-- Performance: Snapshot/Envelope/Output materialisiert, LOB-.WRITE statt
-- wachsender Variablenkonkatenation; CLR-Budget kooperativ, kein SQL-Timeout.
-- Einschränkungen: kein Datei-I/O/ZIP64/TVP/Encryption; Readerlimits bleiben.
-- ============================================================================
CREATE OR ALTER PROCEDURE toolbelt_archive.USP_CreateZipFromEntries
      @EntryTable sysname = NULL
    , @CompressionMethod varchar(max) = 'Stored'
    , @MaxEntries int = 256
    , @MaxEntryNameCodeUnits int = 1024
    , @MaxEntryBytes bigint = 16777216
    , @MaxTotalPayloadBytes bigint = 67108864
    , @MaxArchiveBytes bigint = 71303168
    , @MaxEnvelopeBytes bigint = 71303168
    , @WriterBudgetMilliseconds int = 30000
    , @ResultTable sysname = NULL
    , @KeepData bit = 0
    , @Debug tinyint = 0
    , @Hilfe bit = 0
AS
BEGIN
    SET NOCOUNT ON;
    SELECT @KeepData=ISNULL(@KeepData,0), @Debug=ISNULL(@Debug,0), @Hilfe=ISNULL(@Hilfe,0);
    IF @Hilfe = 1
    BEGIN
        -- API_PARAMETER_HELP:BEGIN
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
            CAST(N'toolbelt_archive' AS sysname) AS SchemaName,
            CAST(N'USP_CreateZipFromEntries' AS sysname) AS ObjectName,
            CAST(v.Section AS varchar(32)) AS Section, CAST(v.Ordinal AS int) AS Ordinal,
            CAST(v.ItemName AS sysname) AS ItemName, CAST(v.SqlDataType AS varchar(256)) AS SqlDataType,
            CAST(v.IsRequired AS bit) AS IsRequired, CAST(v.IsNullable AS bit) AS IsNullable,
            CAST(v.DefaultValue AS nvarchar(4000)) AS DefaultValue,
            CAST(v.Description AS nvarchar(max)) AS Description,
            CAST(v.ExampleSql AS nvarchar(max)) AS ExampleSql
        FROM (VALUES
        (N'DESCRIPTION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Erzeugt ein begrenztes ZIP aus Ordinal int, EntryName nvarchar(max), Payload varbinary(max) einer vorhandenen caller-lokalen Temp-Tabelle.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 1, N'ArchivePayload', N'varbinary(max)', NULL, 0, NULL, CAST(N'Vollständig finalisiertes ZIP-Binary.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 2, N'ArchiveBytes', N'bigint', NULL, 0, NULL, CAST(N'Tatsächliche Archivgröße in Bytes.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 3, N'EntryCount', N'int', NULL, 0, NULL, CAST(N'Anzahl vorhandener Dateien, leere Liste erlaubt.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 4, N'TotalPayloadBytes', N'bigint', NULL, 0, NULL, CAST(N'Summe unkomprimierter Payloadbytes.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 5, N'CompressionMethod', N'int', NULL, 0, NULL, CAST(N'ZIP-Methode 0 Stored oder 8 Deflate.' AS nvarchar(max)), NULL),
        (N'EXAMPLE', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Synthetischer In-memory-Aufruf.' AS nvarchar(max)), CAST(N'CREATE TABLE #ZipInput(Ordinal int, EntryName nvarchar(max), Payload varbinary(max)); INSERT #ZipInput VALUES(1,N''hello.txt'',0x4869); EXEC toolbelt_archive.USP_CreateZipFromEntries @EntryTable=N''#ZipInput'';' AS nvarchar(max))),
        (N'ERROR', 1, N'51350-51359', NULL, NULL, NULL, NULL, CAST(N'TBX_ZIP_WRITE_*; kein Teiloutput; Original-Enginefehler und Callertransaktionszustand erhalten.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 1, N'@EntryTable', N'sysname', 1, 0, N'NULL', CAST(N'Vorhandene sichtbare caller-lokale #Temp, Name ohne Punkt/## und höchstens 116 Zeichen, nicht dieselbe tatsächliche Tabelle wie ResultTable. Benötigt Ordinal int, EntryName nvarchar(max), Payload varbinary(max), nicht computed/verschlüsselt; Zusatzspalten und nullable Metadaten erlaubt, tatsächliche Werte alle nicht NULL. Ordinal positiv und eindeutig, Lücken erlaubt; Ausgabe nach Ordinal. EntryName 1..MaxEntryNameCodeUnits wohlgeformte UTF-16-Einheiten, binär/case-/längensensitiv eindeutig; relative /-Dateinamen ohne NUL, Backslash, Doppelpunkt, führenden/abschließenden /, leere Segmente sowie Segmente mit exakt einem oder zwei Punkten. Payload darf 0x sein. Leere Tabelle erzeugt ein gültiges 22-Byte-EOCD-ZIP. NULL ist fachlich ungültig; keine Parallelmutation.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 2, N'@CompressionMethod', N'varchar(max)', 0, 0, N'''Stored''', CAST(N'Taxativ, exakt ASCII einschließlich Länge/Case: Stored (Default) = Method0, unkomprimierte Payload; Deflate = Method8, Deflate-Kompression. Gilt für alle Entries. NULL/leer/andere Schreibweisen/angehängte Spaces ungültig; keine freie Kompressionsstufe/Methodnummer.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 3, N'@MaxEntries', N'int', 0, 0, N'256', CAST(N'Ganzzahl 1..1024, Default 256: Entries über die gesamte Tabelle. Innerhalb dieses Bereichs absenkbar oder erhöhbar; NULL/0/negativ/höher ungültig. Keine unbegrenzte Einstellung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 4, N'@MaxEntryNameCodeUnits', N'int', 0, 0, N'1024', CAST(N'Ganzzahl 1..2048, Default 1024: UTF-16-Einheiten je Entryname; Reader bleibt unabhängig bei 1024. Innerhalb dieses Bereichs absenkbar oder erhöhbar; NULL/0/negativ/höher ungültig. Keine unbegrenzte Einstellung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 5, N'@MaxEntryBytes', N'bigint', 0, 0, N'16777216', CAST(N'Ganzzahl 1..33554432, Default 16777216: unkomprimierte Payloadbytes je Entry. Innerhalb dieses Bereichs absenkbar oder erhöhbar; NULL/0/negativ/höher ungültig. Keine unbegrenzte Einstellung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 6, N'@MaxTotalPayloadBytes', N'bigint', 0, 0, N'67108864', CAST(N'Ganzzahl 1..134217728, Default 67108864: Summe unkomprimierter Payloadbytes aller Entries. Innerhalb dieses Bereichs absenkbar oder erhöhbar; NULL/0/negativ/höher ungültig. Keine unbegrenzte Einstellung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 7, N'@MaxArchiveBytes', N'bigint', 0, 0, N'71303168', CAST(N'Ganzzahl 1..150994944, Default 71303168: Bytes des vollständigen finalisierten ZIP einschließlich Header, Namen und Directory. Innerhalb dieses Bereichs absenkbar oder erhöhbar; NULL/0/negativ/höher ungültig. Keine unbegrenzte Einstellung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 8, N'@MaxEnvelopeBytes', N'bigint', 0, 0, N'71303168', CAST(N'Ganzzahl 1..142606336, Default 71303168: Bytes des internen Übergabe-Envelopes einschließlich Framing und Namen, nicht nur Payload. Innerhalb dieses Bereichs absenkbar oder erhöhbar; NULL/0/negativ/höher ungültig. Keine unbegrenzte Einstellung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 9, N'@WriterBudgetMilliseconds', N'int', 0, 0, N'30000', CAST(N'Ganzzahl 1..60000, Default 30000: Millisekunden kooperatives Writerbudget; keine harte Gesamtwallclock-/SQL-Marshallingfrist. Innerhalb dieses Bereichs absenkbar oder erhöhbar; NULL/0/negativ/höher ungültig. Keine unbegrenzte Einstellung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 10, N'@ResultTable', N'sysname', 0, 1, N'NULL', CAST(N'NULL (Default) liefert den fachlichen SELECT-Resultset. Sonst ein einzelner sysname mit 2..116 UTF-16-Einheiten einschließlich führendem # als Name einer bereits im Caller-Scope angelegten lokalen #Temp-Tabelle, z.B. N''#Result''; keine globale ##Temp, persistente oder mehrteilige Tabelle. Der ResultTable-Helper muss verfügbar sein; die Ausgabeform wird anhand des konkreten Objektresultsets vorbereitet. Darf nicht die EntryTable sein; beim In-memory-Writer kein Punkt im Namen und kein reservierter #tbx_ZipWriter_-Name.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 11, N'@KeepData', N'bit', 0, 1, N'0', CAST(N'Taxativ für bit: 0 ersetzt Ergebnisdaten (Default), 1 hängt bei kompatibler ResultTable an; NULL entspricht 0. Nur bei nicht-NULL ResultTable relevant; Schema- und Datenbehandlung folgen dem kanonischen ResultTable-Vertrag.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 12, N'@Debug', N'tinyint', 0, 1, N'0', CAST(N'tinyint 0..255, Default 0; NULL wirkt wie 0. 0 keine eigenen Messages, 1..255 kurze Abschlussmessage ohne Entrynamen/Payloads/Pfade; bei ResultTable zusätzlich Helperdiagnose.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 13, N'@Hilfe', N'bit', 0, 1, N'0', CAST(N'Taxativ für bit: 1 liefert nur die Standardhilfe vor der Fachvalidierung; 0 (Default) führt den Fachaufruf aus. NULL wird wie 0 behandelt. Syntaktisch erforderliche Argumente ohne technischen Default müssen auch beim Help-Aufruf angegeben werden.' AS nvarchar(max)), NULL)
        ) AS v(Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql)
        ORDER BY CASE v.Section WHEN 'DESCRIPTION' THEN 0 WHEN 'PARAMETER' THEN 1
            WHEN 'RESULT_COLUMN' THEN 2 WHEN 'EXAMPLE' THEN 3 ELSE 4 END, v.Ordinal;
        RETURN 0;
        -- API_PARAMETER_HELP:END
    END;

    IF @CompressionMethod IS NULL OR
       NOT ((@CompressionMethod COLLATE Latin1_General_100_BIN2 = 'Stored' AND DATALENGTH(@CompressionMethod)=6)
         OR (@CompressionMethod COLLATE Latin1_General_100_BIN2 = 'Deflate' AND DATALENGTH(@CompressionMethod)=7))
       OR @MaxEntries IS NULL OR @MaxEntries NOT BETWEEN 1 AND 1024
       OR @MaxEntryNameCodeUnits IS NULL OR @MaxEntryNameCodeUnits NOT BETWEEN 1 AND 2048
       OR @MaxEntryBytes IS NULL OR @MaxEntryBytes NOT BETWEEN 1 AND 33554432
       OR @MaxTotalPayloadBytes IS NULL OR @MaxTotalPayloadBytes NOT BETWEEN 1 AND 134217728
       OR @MaxArchiveBytes IS NULL OR @MaxArchiveBytes NOT BETWEEN 1 AND 150994944
       OR @MaxEnvelopeBytes IS NULL OR @MaxEnvelopeBytes NOT BETWEEN 1 AND 142606336
       OR @WriterBudgetMilliseconds IS NULL OR @WriterBudgetMilliseconds NOT BETWEEN 1 AND 60000
        THROW 51350,N'TBX_ZIP_WRITE_INVALID_ARGUMENT: Parameter oder Ressourcenlimit ungültig.',1;
    DECLARE @DependencyVersion nvarchar(64)=(SELECT TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version');
    IF OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterName',N'FT') IS NULL
       OR OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterArchive',N'FT') IS NULL
       OR OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P') IS NULL
       OR @DependencyVersion IS NULL
       OR PARSENAME(@DependencyVersion,4) IS NOT NULL
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)) IS NULL
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)) IS NULL
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,1)) IS NULL
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)) < 1
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)) < 0
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,1)) < 0
       OR CONVERT(varbinary(128),@DependencyVersion) <> CONVERT(varbinary(128),CONCAT(TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)),N'.',TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)),N'.',TRY_CONVERT(int,PARSENAME(@DependencyVersion,1))))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(128),value))=CONVERT(varbinary(max),N'toolbelt.core.result-table'))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable') AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@DependencyVersion))
        THROW 51357,N'TBX_ZIP_WRITE_DEPENDENCY: ZIP-Writer oder ResultTable >=1.0.0 fehlt.',1;
    IF @EntryTable IS NULL OR LEFT(@EntryTable,1)<>N'#' OR LEFT(@EntryTable,2)=N'##'
       OR LEN(@EntryTable)>116 OR CHARINDEX(N'.',@EntryTable)>0
       OR (@ResultTable IS NOT NULL AND (LEFT(@ResultTable,1)<>N'#' OR LEFT(@ResultTable,2)=N'##' OR LEN(@ResultTable)>116 OR CHARINDEX(N'.',@ResultTable)>0))
        THROW 51351,N'TBX_ZIP_WRITE_INPUT_SCHEMA: Nur vorhandene caller-lokale Temps sind zulässig.',1;
    DECLARE @InputId int=OBJECT_ID(N'tempdb..'+QUOTENAME(@EntryTable),N'U'),
            @OutputId int=CASE WHEN @ResultTable IS NOT NULL THEN OBJECT_ID(N'tempdb..'+QUOTENAME(@ResultTable),N'U') END;
    IF @InputId IS NULL OR (@ResultTable IS NOT NULL AND @OutputId IS NULL) OR @InputId=@OutputId
        THROW 51351,N'TBX_ZIP_WRITE_INPUT_SCHEMA: Temp fehlt oder Input und Output sind identisch.',2;
    IF (SELECT COUNT(*) FROM tempdb.sys.columns WHERE object_id=@InputId AND
          ((name COLLATE Latin1_General_100_BIN2=N'Ordinal' AND system_type_id=56 AND max_length=4)
          OR (name COLLATE Latin1_General_100_BIN2=N'EntryName' AND system_type_id=231 AND max_length=-1)
          OR (name COLLATE Latin1_General_100_BIN2=N'Payload' AND system_type_id=165 AND max_length=-1))
          AND is_computed=0 AND encryption_type IS NULL) <> 3
        THROW 51351,N'TBX_ZIP_WRITE_INPUT_SCHEMA: Erwartet Ordinal int, EntryName nvarchar(max), Payload varbinary(max).',3;
    IF XACT_STATE()=-1 THROW 51350,N'TBX_ZIP_WRITE_INVALID_ARGUMENT: Callertransaktion nicht committable.',2;
    IF LEFT(@EntryTable,15)=N'#tbx_ZipWriter_' OR LEFT(@ResultTable,15)=N'#tbx_ZipWriter_'
        THROW 51351,N'TBX_ZIP_WRITE_INPUT_SCHEMA: Interne Helpernamen sind reserviert.',4;

    -- Keine MARS-/Parallelmutation derselben Caller-Temps während des
    -- synchronen Aufrufs. Eine Lese-Transaktion stabilisiert Preflight/Snapshot.
    DECLARE @OwnTransaction bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,
            @SavepointSet bit=0,
            @Savepoint varchar(32)='tbxZW'+REPLACE(CONVERT(varchar(36),NEWID()),'-',''),
            @Sql nvarchar(max), @Count bigint, @Total bigint, @Invalid bigint,
            @TooLarge bigint, @Duplicate bigint, @Envelope varbinary(max),
            @Archive varbinary(max), @Method int=CASE WHEN @CompressionMethod='Stored' THEN 0 ELSE 8 END;
    BEGIN TRY
        IF @OwnTransaction=1 BEGIN TRANSACTION;
        ELSE BEGIN SAVE TRANSACTION @Savepoint; SET @SavepointSet=1; END;
        SET @Sql=N'SELECT @Count=COUNT_BIG(*), @Total=COALESCE(SUM(CONVERT(bigint,DATALENGTH(Payload))),0),
          @Invalid=COALESCE(SUM(CONVERT(bigint,CASE WHEN Ordinal IS NULL OR Ordinal<1 OR EntryName IS NULL OR Payload IS NULL THEN 1 ELSE 0 END)),0),
          @TooLarge=COALESCE(SUM(CONVERT(bigint,CASE WHEN DATALENGTH(Payload)>@EntryMax OR DATALENGTH(EntryName)>CONVERT(bigint,@NameMax)*2 THEN 1 ELSE 0 END)),0)
          FROM '+QUOTENAME(@EntryTable)+N' WITH(HOLDLOCK);
          SELECT @Duplicate=COUNT_BIG(*) FROM(SELECT Ordinal FROM '+QUOTENAME(@EntryTable)+N' GROUP BY Ordinal HAVING COUNT_BIG(*)>1)d;';
        EXEC sys.sp_executesql @Sql,N'@Count bigint OUTPUT,@Total bigint OUTPUT,@Invalid bigint OUTPUT,@TooLarge bigint OUTPUT,@Duplicate bigint OUTPUT,@EntryMax bigint,@NameMax int',
            @Count OUTPUT,@Total OUTPUT,@Invalid OUTPUT,@TooLarge OUTPUT,@Duplicate OUTPUT,@MaxEntryBytes,@MaxEntryNameCodeUnits;
        IF @Invalid>0 OR @Duplicate>0 THROW 51350,N'TBX_ZIP_WRITE_INVALID_ARGUMENT: NULL, ungültige oder doppelte Ordinals.',3;
        IF @Count>@MaxEntries OR @Total>@MaxTotalPayloadBytes OR @TooLarge>0
            THROW 51354,N'TBX_ZIP_WRITE_RESOURCE_LIMIT: Input überschreitet die Ressourcenlimits.',1;
        CREATE TABLE #tbx_ZipWriter_Snapshot(Ordinal int NOT NULL PRIMARY KEY, EntryName nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL, Payload varbinary(max) NOT NULL, NameBytes varbinary(max) NULL, NameError int NULL);
        SET @Sql=N'INSERT #tbx_ZipWriter_Snapshot(Ordinal,EntryName,Payload) SELECT Ordinal,EntryName,Payload FROM '+QUOTENAME(@EntryTable)+N' WITH(HOLDLOCK);';
        EXEC sys.sp_executesql @Sql;
        -- Encoding wird vor verlustbehafteter UTF8-Konvertierung durch CLR mit
        -- Exceptionfallback validiert; Namensduplikate inklusive Länge/Bytes.
        UPDATE s SET NameBytes=p.Payload,NameError=p.ErrorNumber
        FROM #tbx_ZipWriter_Snapshot s CROSS APPLY toolbelt_archive.TVF_InternalZipWriterName(EntryName COLLATE DATABASE_DEFAULT,@MaxEntryNameCodeUnits) p;
        IF EXISTS(SELECT 1 FROM #tbx_ZipWriter_Snapshot WHERE NameError IS NULL OR NameError<>0 OR NameBytes IS NULL)
            THROW 51352,N'TBX_ZIP_WRITE_INVALID_NAME: Name oder UTF-16 ungültig.',1;
        IF EXISTS(SELECT 1 FROM #tbx_ZipWriter_Snapshot a JOIN #tbx_ZipWriter_Snapshot b ON a.Ordinal<b.Ordinal
            AND DATALENGTH(a.NameBytes)=DATALENGTH(b.NameBytes) AND a.NameBytes=b.NameBytes)
            THROW 51353,N'TBX_ZIP_WRITE_DUPLICATE_NAME: Binär identische Namen.',1;
        DECLARE @EnvelopeSize bigint=12+@Total+@Count*16+(SELECT COALESCE(SUM(CONVERT(bigint,DATALENGTH(NameBytes))),0) FROM #tbx_ZipWriter_Snapshot);
        IF @EnvelopeSize>@MaxEnvelopeBytes THROW 51354,N'TBX_ZIP_WRITE_RESOURCE_LIMIT: Envelope inklusive Namen/Framing zu groß.',2;
        CREATE TABLE #tbx_ZipWriter_Envelope(Value varbinary(max) NOT NULL);
        DECLARE @CountBinary binary(4)=CONVERT(binary(4),CONVERT(int,@Count));
        INSERT #tbx_ZipWriter_Envelope VALUES(0x54425A5701000000+SUBSTRING(@CountBinary,4,1)+SUBSTRING(@CountBinary,3,1)+SUBSTRING(@CountBinary,2,1)+SUBSTRING(@CountBinary,1,1));
        DECLARE @Ordinal int,@Name varbinary(max),@Payload varbinary(max),@Chunk varbinary(max);
        DECLARE EntryCursor CURSOR LOCAL FAST_FORWARD FOR SELECT Ordinal,NameBytes,Payload FROM #tbx_ZipWriter_Snapshot ORDER BY Ordinal;
        OPEN EntryCursor;
        FETCH NEXT FROM EntryCursor INTO @Ordinal,@Name,@Payload;
        WHILE @@FETCH_STATUS=0
        BEGIN
            -- REVERSE(binary) liefert varchar und ist deshalb kein sicherer
            -- Binarytransport. Byteweise SUBSTRING bleibt varbinary.
            DECLARE @OrdinalBinary binary(4)=CONVERT(binary(4),@Ordinal),@NameBinary binary(4)=CONVERT(binary(4),DATALENGTH(@Name)),@PayloadBinary binary(8)=CONVERT(binary(8),CONVERT(bigint,DATALENGTH(@Payload)));
            SET @Chunk=SUBSTRING(@OrdinalBinary,4,1)+SUBSTRING(@OrdinalBinary,3,1)+SUBSTRING(@OrdinalBinary,2,1)+SUBSTRING(@OrdinalBinary,1,1)
              +SUBSTRING(@NameBinary,4,1)+SUBSTRING(@NameBinary,3,1)+SUBSTRING(@NameBinary,2,1)+SUBSTRING(@NameBinary,1,1)
              +SUBSTRING(@PayloadBinary,8,1)+SUBSTRING(@PayloadBinary,7,1)+SUBSTRING(@PayloadBinary,6,1)+SUBSTRING(@PayloadBinary,5,1)
              +SUBSTRING(@PayloadBinary,4,1)+SUBSTRING(@PayloadBinary,3,1)+SUBSTRING(@PayloadBinary,2,1)+SUBSTRING(@PayloadBinary,1,1)+@Name;
            -- .WRITE fügt LOB-Teile an; kein @Envelope=@Envelope+Payload mit
            -- quadratischen Komplettkopien bei vielen Entries.
            UPDATE #tbx_ZipWriter_Envelope SET Value.WRITE(@Chunk,NULL,0);
            UPDATE #tbx_ZipWriter_Envelope SET Value.WRITE(@Payload,NULL,0);
            FETCH NEXT FROM EntryCursor INTO @Ordinal,@Name,@Payload;
        END;
        CLOSE EntryCursor; DEALLOCATE EntryCursor;
        SELECT @Envelope=Value FROM #tbx_ZipWriter_Envelope;
        IF DATALENGTH(@Envelope)<>@EnvelopeSize THROW 51358,N'TBX_ZIP_WRITE_TRANSPORT_INVALID: Envelope-Länge widersprüchlich.',1;
        DECLARE @Provider TABLE(ErrorNumber int,ErrorMessage nvarchar(4000),Payload varbinary(max));
        INSERT @Provider SELECT ErrorNumber,ErrorMessage,Payload
        FROM toolbelt_archive.TVF_InternalZipWriterArchive(@Envelope,@Method,@MaxEntries,@MaxEntryNameCodeUnits,@MaxEntryBytes,@MaxTotalPayloadBytes,@MaxArchiveBytes,@MaxEnvelopeBytes,@WriterBudgetMilliseconds);
        IF (SELECT COUNT(*) FROM @Provider)<>1 THROW 51359,N'TBX_ZIP_WRITE_PROVIDER_FAILURE: Statusrow fehlt oder mehrdeutig.',1;
        DECLARE @ProviderError int,@ProviderMessage nvarchar(4000);
        SELECT @ProviderError=ErrorNumber,@ProviderMessage=ErrorMessage,@Archive=Payload FROM @Provider;
        IF @ProviderError IS NULL OR @ProviderError NOT BETWEEN 0 AND 51359 OR (@ProviderError<>0 AND @ProviderError<51350)
            THROW 51359,N'TBX_ZIP_WRITE_PROVIDER_FAILURE: Fehlerstatus ungültig.',2;
        IF @ProviderError<>0 THROW @ProviderError,@ProviderMessage,1;
        IF @Archive IS NULL THROW 51359,N'TBX_ZIP_WRITE_PROVIDER_FAILURE: Archiv fehlt.',1;
        CREATE TABLE #tbx_ZipWriter_Result(ArchivePayload varbinary(max) NOT NULL,ArchiveBytes bigint NOT NULL,EntryCount int NOT NULL,TotalPayloadBytes bigint NOT NULL,CompressionMethod int NOT NULL);
        INSERT #tbx_ZipWriter_Result VALUES(@Archive,DATALENGTH(@Archive),CONVERT(int,@Count),@Total,@Method);
        IF @ResultTable IS NOT NULL
        BEGIN
            EXEC toolbelt_core.USP_PrepareResultTable @ResultTableToAlter=@ResultTable,@LikeTable=N'#tbx_ZipWriter_Result',@KeepData=@KeepData,@Debug=@Debug;
            SET @Sql=N'INSERT '+QUOTENAME(@ResultTable)+N'(ArchivePayload,ArchiveBytes,EntryCount,TotalPayloadBytes,CompressionMethod) SELECT ArchivePayload,ArchiveBytes,EntryCount,TotalPayloadBytes,CompressionMethod FROM #tbx_ZipWriter_Result;';
            EXEC sys.sp_executesql @Sql;
        END;
        IF @OwnTransaction=1 COMMIT TRANSACTION;
        IF @Debug>0 PRINT N'ZIP-Writer: vollständiges Archiv erfolgreich erzeugt; Inhalte werden nicht ausgegeben.';
        IF @ResultTable IS NULL SELECT ArchivePayload,ArchiveBytes,EntryCount,TotalPayloadBytes,CompressionMethod FROM #tbx_ZipWriter_Result;
        DROP TABLE #tbx_ZipWriter_Result,#tbx_ZipWriter_Envelope,#tbx_ZipWriter_Snapshot;
        RETURN 0;
    END TRY
    BEGIN CATCH
        IF @OwnTransaction=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
        ELSE IF @OwnTransaction=0 AND @SavepointSet=1 AND XACT_STATE()=1 ROLLBACK TRANSACTION @Savepoint;
        -- Lokale statische Temps werden bei Scopeende auch dann entfernt,
        -- wenn ein Caller-Doom-Zustand kein weiteres DDL erlaubt.
        THROW;
    END CATCH;
END;
GO

SET NOCOUNT ON;

BEGIN TRY
    IF @@TRANCOUNT = 0
        THROW 51339, N'Die Deployment-Transaktion ist vorzeitig beendet worden.', 1;

    DECLARE
          @VersionProperty sysname =
              N'Toolbelt.Module.toolbelt.archive.zip-memory.Version'
        , @ModeProperty sysname =
              N'Toolbelt.Module.toolbelt.archive.zip-memory.DeploymentMode';

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0
             AND major_id = 0
             AND minor_id = 0
             AND name = @VersionProperty
       )
        EXEC sys.sp_updateextendedproperty
              @name = @VersionProperty
            , @value = N'1.4.0';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = @VersionProperty
            , @value = N'1.4.0';

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0
             AND major_id = 0
             AND minor_id = 0
             AND name = @ModeProperty
       )
        EXEC sys.sp_updateextendedproperty
              @name = @ModeProperty
            , @value = N'local';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = @ModeProperty
            , @value = N'local';

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           INNER JOIN sys.assemblies AS a
             ON a.assembly_id = ep.major_id
           WHERE ep.class = 5
             AND ep.name = N'Toolbelt.Managed'
             AND a.name = N'Toolbelt_Archive_ZipMemory'
       )
        EXEC sys.sp_updateextendedproperty
              @name = N'Toolbelt.Managed'
            , @value = 1
            , @level0type = N'ASSEMBLY'
            , @level0name = N'Toolbelt_Archive_ZipMemory';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.Managed'
            , @value = 1
            , @level0type = N'ASSEMBLY'
            , @level0name = N'Toolbelt_Archive_ZipMemory';

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           INNER JOIN sys.assemblies AS a
             ON a.assembly_id = ep.major_id
           WHERE ep.class = 5
             AND ep.name = N'Toolbelt.ModuleId'
             AND a.name = N'Toolbelt_Archive_ZipMemory'
       )
        EXEC sys.sp_updateextendedproperty
              @name = N'Toolbelt.ModuleId'
            , @value = N'toolbelt.archive.zip-memory'
            , @level0type = N'ASSEMBLY'
            , @level0name = N'Toolbelt_Archive_ZipMemory';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.ModuleId'
            , @value = N'toolbelt.archive.zip-memory'
            , @level0type = N'ASSEMBLY'
            , @level0name = N'Toolbelt_Archive_ZipMemory';

    DECLARE @ObjectName sysname,@ObjectType varchar(16),@Property sysname,@PropertyValue nvarchar(128);
    DECLARE WriterMarkers CURSOR LOCAL FAST_FORWARD FOR
    SELECT o.name,CASE WHEN o.type='P' THEN 'PROCEDURE' ELSE 'FUNCTION' END,p.Name,p.Value
    FROM sys.objects o CROSS APPLY(VALUES(N'Toolbelt.ModuleId',N'toolbelt.archive.zip-memory'),(N'Toolbelt.ModuleVersion',N'1.4.0'),(N'Toolbelt.Visibility',CASE WHEN o.type='P' THEN N'public' ELSE N'internal' END))p(Name,Value)
    WHERE o.schema_id=SCHEMA_ID(N'toolbelt_archive') AND o.name IN(N'USP_CreateZipFromEntries',N'TVF_InternalZipWriterName',N'TVF_InternalZipWriterArchive');
    OPEN WriterMarkers; FETCH NEXT FROM WriterMarkers INTO @ObjectName,@ObjectType,@Property,@PropertyValue;
    WHILE @@FETCH_STATUS=0 BEGIN
      IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_archive.'+QUOTENAME(@ObjectName)) AND minor_id=0 AND name=@Property)
       EXEC sys.sp_updateextendedproperty @name=@Property,@value=@PropertyValue,@level0type=N'SCHEMA',@level0name=N'toolbelt_archive',@level1type=@ObjectType,@level1name=@ObjectName;
      ELSE EXEC sys.sp_addextendedproperty @name=@Property,@value=@PropertyValue,@level0type=N'SCHEMA',@level0name=N'toolbelt_archive',@level1type=@ObjectType,@level1name=@ObjectName;
      FETCH NEXT FROM WriterMarkers INTO @ObjectName,@ObjectType,@Property,@PropertyValue;
    END; CLOSE WriterMarkers; DEALLOCATE WriterMarkers;
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.archive.zip-memory
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.file.xlsx-memory
:On Error exit
-- Nichtdoomender Caller-Gate vor SET, eigener Transaktionsscope erforderlich.
IF @@TRANCOUNT<>0
BEGIN
 RAISERROR(N'TBX_XLSX_LIFECYCLE_CALLER_TRANSACTION: Deploy benötigt einen eigenen Transaktionsscope.',16,1);
 RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @Mode nvarchar(max)=N'local',@Bits varbinary(max)=0x4d5a90000300000004000000ffff0000b800000000000000400000000000000000000000000000000000000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a2400000000000000504500004c010300b9090fd00000000000000000e00022200b013000008a00000008000000000000c2a800000020000000c000000000001000200000000200000400000000000000040000000000000000000100000200000000000003004085000010000010000000001000001000000000000010000000000000000000000070a800004f00000000c00000240400000000000000000000000000000000000000e000000c00000054a800001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000080000000000000000000000082000004800000000000000000000002e74657874000000c888000000200000008a000000020000000000000000000000000000200000602e727372630000002404000000c0000000060000008c0000000000000000000000000000400000402e72656c6f6300000c00000000e0000000020000009200000000000000000000000000004000004200000000000000000000000000000000a4a80000000000004800000002000500505e0000044a000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001e027b0f0000042a2202037d0f0000042a0000001b300a00b60100000100001102280c00000a7d0500000402280d00000a7d0600000402280e00000a730f00000a7d0700000402280e00000a731000000a7d0800000402731100000a7d0900000402281200000a0204252d0626734c0000067d0a000004027b0a0000046f4b000006032d0a7201000070281900000602038e6a2813000006020316731300000a038e6a027b0a0000047b12000004027b0a0000047b15000004027b0a0000047b13000004027b0a0000047b14000004027b0a0000047b1d00000402fe0617000006731400000a731500000a7d04000004027b040000046f1600000a0b160c2b2a07089a0d09281e0000060972290000701a6f1700000a2c0e0209092821000006280b000006260817580c08078e6932d0027235000070724d000070280b000006140a6f1800000a13042b321204281900000a13051205281a00000a724f0000701a6f1700000a2c15062c0a726f00007028190000061205281b00000a0a1204281c00000a2dc5de0e1204fe160400001b6f1d00000adc062d0a72a7000070281900000602067d0d00000402280c000006020672db000070280d000006020206282000000606280b0000067d0e00000402280a0000062a000001100000020029013f68010e000000001e027b100000042a1e0228180000062a1b3003007500000002000011022817000006027b090000046f1e00000a0a2b201200281f00000a0b02077b1f000004281200000602077b2000000428120000061200282000000a2dd7de0e1200fe160600001b6f1d00000adc02027b090000046f2100000a6a1f106a5a2813000006022818000006027b090000046f2200000a2a00000001100000020012002d3f000e000000001b300400af020000030000110317320e03027b090000046f2100000a310a72f100007028190000060228090000060a732300000a0b732400000a0c02027b090000040317596f2500000a7b21000004280e0000060d16130416130516130616130702027b090000040317596f2500000a7b21000004720d010070280d00000638ca010000096f2600000a1f0f3327096f2700000a7221010070282800000a2c15096f2900000a7229010070282800000a2c03161307096f2600000a1f0f3330096f2700000a729d010070282800000a2c1e096f2900000a7229010070282800000a2c0c096f2a00000a173303161305096f2600000a17405301000011042d1309720d0100707229010070281a000006171304096f2900000a7229010070282b00000a3a27010000096f2700000a729d010070282800000a2c29096f2a00000a17fe0116fe011106602c0a72b10100702819000006171306096f2c00000a16fe011305096f2700000a7221010070282800000a2c3e096f2a00000a18330411052d0a72e7010070281900000609720f0200706f2d00000a20000010007213020070281c0000061307096f2c00000a2c03161307096f2700000a722f020070282b00000a3a87000000096f2a00000a19330411072d0a72330200702819000006076f2e00000a027b0a0000047b17000004320a725d020070281900000602091107062808000006130811087b230000046a1f206211087b240000046e6013090811096f2f00000a2c0a72730200702819000006081109176f3000000a0711086f3100000a0220800000006a28130000060209280f0000063a2afeffff11042c0411062d0a72910200702819000006de0a092c06096f1d00000adc077e30000004252d17267e2f000004fe0651000006733200000a2580300000046f3300000a02076f2e00000a6a1f106a5a2813000006022818000006076f3400000a2a00411c0000020000004900000019020000620200000a0000000000000013300400170400000400001103720f0200706f2d00000a12011200281d00000604072e0a72b102007028190000060372d50200706f2d00000a252d062672d90200700c0872d9020070282b00\
000a2c580872dd020070282b00000a2c4b0872e1020070282b00000a2c3e0872f5020070282b00000a2c310872fd020070282b00000a2c24087201030070282b00000a2c17087205030070282b00000a2c0a72090300702819000006734e00000625047d2300000425067d2400000425087d250000040d036f2a00000a1304036f2c00000a3af401000038cc010000036f2600000a1740c0010000036f2900000a7229010070282b00000a2c0a72350300702819000006036f2700000a7267030070282800000a2c37036f2a00000a11041758332b097b2b0000042c0a726b030070281900000609177d2b00000409020328100000067d26000004385b010000036f2700000a728b030070282800000a39f0000000036f2a00000a1104175840e1000000097b2c0000042c0a728f030070281900000609177d2c000004090372d50200706f2d00000a252d062672b30300707d29000004097b2900000472b3030070282b00000a2c40097b2900000472c1030070282b00000a2c2e097b2900000472cf030070282b00000a2c1c097b2900000472db030070282b00000a2c0a72ef03007028190000060372210400706f2d00000a130511052c1c09110520ffffff7f7227040070281b000006733500000a7d2e000004097b2900000472c1030070282800000a2c0e11052d0a7227040070281900000609020328100000067d280000042b56036f2700000a7251040070282800000a2c3a036f2a00000a11041758332e097b270000042d0d0872e1020070282b00000a2c0a7257040070281900000609020328110000067d270000042b0a723503007028190000060203280f0000062c1a036f2600000a1f0f401efeffff036f2a00000a11044011feffff0872dd020070282800000a2c4d097b2b0000042d0a72830400702819000006097b2600000420ffffff7f7283040070281b00000613061106056f3600000a320a72830400702819000006090511066f3700000a7d270000042b210872f5020070282800000a2c14097b2b0000042c0c09097b260000047d270000040872e1020070282800000a2c12097b2b0000042c0a725704007028190000060872fd020070282800000a2c48097b2b0000042c40097b26000004724d000070282b00000a2c2e097b2600000472b3040070282b00000a2c1c097b2600000472b7040070282b00000a2c0a72bb0400702819000006097b2c0000042c1809097b2b0000047d2d00000409097b260000047d2a00000402097b25000004281200000602097b26000004281200000602097b27000004281200000602097b28000004281200000602097b29000004281200000602097b2a0000042812000006092a001b3004007301000005000011140a027b0e0000046f1800000a0c2b311202281900000a0d1203281a00000a72e70400701a6f1700000a2c15062c0a720505007028190000061203281b00000a0a1202281c00000a2dc6de0e1202fe160400001b6f1d00000adc733800000a0b062d02072a02067237050070280d0000060206280e000006130416130538c600000011046f2600000a1740b900000011052d14110472530500707229010070281a00000617130511046f2700000a7221040070282800000a398b00000011046f2900000a7229010070282800000a2c7811046f2a00000a172e0a725b0500702819000006076f3600000a027b0a0000047b18000004320a729705007028190000060211042811000006130602027b0c00000411066f3900000a6a186a5a587d0c000004027b0c000004027b0a0000047b1a000004310a72cb05007028190000060711066f3a00000a021104280f0000063a2dffffff11052d0a72fd0500702819000006de0c11042c0711046f1d00000adc072a00011c000002000e003e4c000e0000000002007a00eb65010c000000001b3005002c03000006000011280e00000a733b00000a0a02027b0d000004280e0000060b160c160d1613041613053894020000076f2600000a1f0f332f076f2700000a7227060070282800000a2c1d076f2900000a7229010070282800000a2c0b076f2a00000a173302160d076f2600000a17404f020000082d120772350600707229010070281a000006170c076f2900000a7229010070282b00000a3a25020000076f2700000a7227060070282800000a2c28076f2a00000a17fe0116fe011104602c0a72470600702819000006171304076f2c00000a16fe010d076f2700000a7275060070282800000a3994000000076f2a00000a17fe0116fe011105602c0a728b06007028190000061713050772c30600706f2d00000a130a110a2c42110a72b3040070282b00000a2c34110a72b7040070282b00000a2c26110a72d5060070282b00000a2c18110a72e1060070282b00000a2c0a72eb060070281900000602110a72b7040070282800000a2d0e110a72e1060070282800000a2b01172802000006076f2700000a720d070070282b00000a3a2d010000076f2a00000a183303092d0a72190700702819000006027b090000046f2100000a027b0a0000047b16000004320a7245070070281900000607725d0700706f2d00000a1306077267070070726d0700706f3c00000a13070772f60700706f2d00000a252d0626720208007013081106283d00000a2d0a0611066f3e00000a2c0a7212080070281900000611087202080070282b00000a2c2611087238080070282b00000a2c1811087246080070282b00000a2c0a725c080070281900000611072c1b027b0e0000041107728e080070283f00000a12096f4000000a2d0c72a408007028190000062b3b027b09000004734d00\
000625027b090000046f2100000a17587d1e0000042511067d1f0000042511087d200000042511097d210000046f4100000a061106176f4200000a0207280f0000063a60fdffff082c1111042c0d027b090000046f2100000a2d0a72d20800702819000006de0a072c06076f1d00000adc027b090000046f1e00000a130b2b12120b281f00000a0228010000067d22000004120b282000000a2de5de0e120bfe160600001b6f1d00000adc2a413400000200000018000000cf020000e70200000a0000000000000002000000fe0200001f0000001d0300000e000000000000001b300400d801000007000011280e00000a731000000a0a280e00000a733b00000a0b0203280e0000060c160d388c010000086f2600000a174080010000092d120872f0080070720c090070281a000006170d086f2700000a7286090070282b00000a3a56010000086f2900000a720c090070282b00000a3a41010000086f2a00000a1740350100000872a00900706f2d00000a13040872b60900706f2d00000a13050872bc0900706f2d00000a13060872c60900706f2d00000a130711042c18110472d4090070282b00000a2c0a72e609007028190000061105283d00000a2d120711056f3e00000a2d0811062c0411072d0a72220a00702819000006071105176f4200000a110672440a00701a6f4300000a2d0a72cf0a007028190000061106726d070070283900000a17586f4400000a1308110872030b0070282800000a2d38110872190b0070282800000a2d2a110872330b0070282800000a2d1c1108724b0b0070282800000a2d0e1108725b0b0070282800000a2c0a72cf0a00702819000006041107281f0000061309027b0400000411096f4500000a2d0a726f0b00702819000006061105729f0b00701108284600000a11096f4700000a0208280f0000063a68feffff092d0a72a30b00702819000006de0a082c06086f1d00000adc062a411c0000020000001e000000ae010000cc0100000a000000000000001b3003007301000008000011160a0272c10b0070280e0000060b383a010000076f2600000a17402e010000062d120772e90b007072f50b0070281a000006170a076f2900000a72f50b0070282b00000a3a04010000076f2a00000a1740f800000007726f0c00706f2d00000a0c082d0a72870c00702819000006076f2700000a72b10c0070282800000a2c5c0772c30c00706f2d00000a0d092c0e0972d50c00701a6f4300000a2d0a72870c0070281900000609176f4400000a0d09281e000006027b08000004096f4800000a2c0a72d90c00702819000006027b0800000409086f4700000a2b1c076f2700000a72070d0070282b00000a2c0a72170d007028190000060872490d00701b6f4900000a162f3c0872550d00701b6f4900000a162f2d08725d0d00701b6f4900000a162f1e0872190b00701b6f4900000a162f0f0872330b00701b6f4900000a16320a72170d007028190000060207280f0000063abafeffffde0a072c06076f1d00000adc062d0a726d0d007028190000062a00411c0000020000000e0000004d0100005b0100000a00000000000000133004003300000009000011027b080000040312006f4000000a2c180672a10d007004721b0e0070284600000a282b00000a2c0a72250e007028190000062a0013300300c00000000a000011022817000006027b070000040312006f4a00000a2d5a027b04000004036f4b00000a0a02027b0b000004068e6a587d0b000004027b0b000004027b0a0000047b14000004310a72510e0070281900000602068e6a1a6a5a20004001006a582813000006027b0700000403066f4c00000a734d00000a25166f4e00000a25146f4f00000a25027b0a0000047b130000046f5000000a25176a6f5100000a25176f5200000a25176f5300000a25176f5400000a0b0616731300000a07285500000a2ace022817000006036f5600000a022817000006252c1d036f2a00000a027b0a0000047b19000004310a726f0e007028190000062a133003009b0000000b000011036f2a00000a0a036f2c00000a2c06724d0000702a735700000a0b2b5b036f2600000a17330a728f0e00702819000006036f2600000a192e1d036f2600000a1a2e14036f2600000a1f0e2e0a036f2600000a1f0d332202036f5800000a6f3900000a6a1a6a5a281300000607036f5800000a6f5900000a260203280f0000062c13036f2600000a1f0f3392036f2a00000a063389076f5a00000a2a0013300300d20000000c000011036f2a00000a0a036f2c00000a2c06724d0000702a735700000a0b150c3887000000036f2600000a1f0f330b036f2a00000a083302150c036f2600000a173369036f2900000a7229010070282b00000a2d57036f2700000a72b90e0070282800000a2c0f036f2c00000a2d07036f2a00000a0c036f2700000a72d5020070282800000a2c2408162f20020328100000060d02096f3900000a6a1a6a5a281300000607096f5900000a260203280f0000062c19036f2600000a1f0f4063ffffff036f2a00000a064057ffffff076f5a00000a2a52032c1002036f3900000a6a1a6ad828130000062ace03166a321503027b0a0000047b1b000004027b1000000459310a72c10e0070281900000602027b1000000403587d100000042a4a021f20310b03021f2059fe0516fe012a172a120302592a2602036afe0416fe012a00000013300200390000000d000011027b0a0000047b1c0000040a061f2030070228180000062a027b06000004280d00000a28150000060b060728140000062c060228180000062aa2027b050000046f5b0000\
0a027b0a0000047b1c00000428160000062c0a72f30e007028190000062a4672130f007002283f00000a735c00000a7abe026f2a00000a2d1c026f2700000a03282b00000a2d0e026f2900000a04282b00000a2c0a72270f007028190000062a13300200590000000e00001102283d00000a2c08042819000006162a166a0a020b160c2b3407086f5d00000a0d091f303205091f393106042819000006061f0a6a5a096e581f306a590a06036a31060428190000060817580c08076f3900000a32c306692a4a020304281b000006252d060428190000062a13300600950000000f00001104165403165402283d00000a2c0a72510f00702819000006160a2b2b04044a1f1a5a02062517580a6f5d00000a581f4159175854044a2000400000310a72510f0070281900000606026f3900000a2f1602066f5d00000a1f41320b02066f5d00000a1f5a31b6062c0906026f3900000a330a72510f007028190000060302066f4400000a200000100072510f0070281c000006542a00000013300500aa0000001000001102283d00000a2d4202166f5d00000a1f2f2e37021f5c6f5e00000a162f2c021f3a6f5e00000a162f21021f256f5e00000a162f16021f3f6f5e00000a162f0b021f236f5e00000a16320a726f0f0070281900000602178d3800000125161f2f9d6f5f00000a0a160b2b3906079a0c08724d000070282800000a2d1a08729b0f0070282800000a2d0d08729f0f0070282800000a2c0a726f0f007028190000060717580b07068e6932c12a0000133006002d0100001100001103283d00000a2d37031f3a6f5e00000a162f2c031f5c6f5e00000a162f21031f256f5e00000a162f16031f3f6f5e00000a162f0b031f236f5e00000a16320a72a50f00702819000006733800000a0a0372d50c00701a6f4300000a2d30021f2f6f6000000a163225060216021f2f6f6000000a6f6100000a178d3800000125161f2f9d6f5f00000a6f6200000a03178d3800000125161f2f9d6f6300000a178d3800000125161f2f9d6f5f00000a0b160c2b6207089a0d09729f0f0070282800000a2c22066f3600000a2d0a72dd0f0070281900000606066f3600000a17596f6400000a2b2b09729b0f0070282b00000a2c1e09724d000070282800000a2c0a72a50f0070281900000606096f3a00000a0817580c08078e69329872d50c007006286500000a25281e0000062a00000013300500370000000f000011021f2f6f6000000a0a0616320c02160617586f6100000a2b05724d000070720b100070020617586f4400000a7229000070286600000a2a0013300500970000000f000011027235000070282800000a2c06724d0000702a0272191000701a6f6700000a0a06162f2d02720b1000701a6f4300000a2c1f0272290000701a6f1700000a2c11021c026f3900000a1f0b596f6100000a2a0616320e0272290000701a6f1700000a2d1072291000702819000006724d0000702a02160617586f6100000a02061d58026f3900000a06591f0c596f6100000a283f00000a2a001330030009010000000000000f00286800000a2d5a0f01286800000a2d510f02286800000a2d480f03286900000a2d3f0f04286900000a2d360f05286900000a2d2d0f06286900000a2d240f07286800000a2d1b0f08286900000a2d120f09286a00000a2d090f0a286900000a2c0b724f100070735c00000a7a734c000006250f00286b00000a7d12000004250f01286b00000a7d13000004250f02286b00000a7d14000004250f03286c00000a7d15000004250f04286c00000a7d16000004250f05286c00000a7d17000004250f06286c00000a7d18000004250f07286b00000a7d1a000004250f08286c00000a7d19000004250f09286d00000a7d1d000004250f0a286c00000a7d1c000004256f4b0000062a0000001b300b003b01000012000011736e00000a0a050e040e050e060e070e080e090e0a0e0b0e0c0e0d28220000060b042c1e0f01286900000a2d0a0f01286c00000a172f0b727b100070735c00000a7a026f6f00000a2c07060ddde8000000026f7000000a077b12000004310b72a9100070735c00000a7a026f7100000a0773030000060c042c44080f01286c00000a6f0700000613041613052b26110411059a1306086f050000060673520000062511067d340000046f7200000a110517581305110511048e6932d22b3b086f0600000613071613052b26110711059a1308086f050000060673520000062511087d330000046f7200000a110517581305110511078e6932d2086f05000006060dde362672d710007028250000060dde2826720111007028250000060dde1a6f7300000a28240000060dde0d6f7300000a28240000060dde00092a000134000000000600fd03010e2000000100000600fd11010e2100000100000600fd1f010d2200000100000600fd2c010d230000019a0272130f00701a6f4300000a2c0a026f3900000a1f603107723511007010000228250000062a9a178d0b00000225167352000006252040c90000733500000a7d3100000425027d32000004a22a000013300e002000000000000000027e7400000a160304050e040e050e060e070e080e090e0a0e0b28230000062a13300e001d0000000000000002031704050e040e050e060e070e080e090e0a0e0b0e0c28230000062a42022c0702737500000a2a7e7600000a2a000013300200b10000001300001102740b0000020a03067c31000004287700000a2d077e7400000a2b10067c31000004287800000a737900000a811c00000104067b3200000428280000068127000001067b330000040b05072c0d077b1e\
000004737900000a2b057e7400000a811c0000010e04072c08077b1f0000042b0114282800000681270000010e05072c08077b200000042b0114282800000681270000010e06072c0d077b22000004737a00000a2b057e7b00000a81280000012a00000013300200930100001400001102740b0000020a03067c31000004287700000a2d077e7400000a2b10067c31000004287800000a737900000a811c00000104067b3200000428280000068127000001067b340000040b05072c0d077b23000004737900000a2b057e7400000a811c0000010e04072c0d077b24000004737900000a2b057e7400000a811c0000010e05072c08077b250000042b0114282800000681270000010e06072c0d077b2b000004737a00000a2b057e7b00000a81280000010e07072c08077b260000042b0114282800000681270000010e08072c08077b270000042b0114282800000681270000010e09072c0d077b2c000004737a00000a2b057e7b00000a81280000010e0a072c08077b280000042b0114282800000681270000010e0b072c08077b290000042b0114282800000681270000010e0c072c1f077c2e000004287700000a2c12077c2e000004287800000a737900000a2b057e7400000a811c0000010e0d072c0d077b2d000004737a00000a2b057e7b00000a81280000010e0e072c08077b2a0000042b0114282800000681270000012a32022c07026f3900000a2a162a52735300000625027d3c00000425167d3b0000042a00000013300400af0000000000000002037d3c000004032c4e027e7c00000a7d3d000004027c3e000004fe150e00001b027c3f000004fe150f00001b027c40000004fe150f00001b027c41000004fe151000001b027c42000004fe151100001b02147d3900000420000100006a1a6a027b35000004282b000006027b36000004282b00000658027b37000004282b00000658027b38000004282b00000658027b39000004282b000006586a5a5820000004006a3002022a19282c0000062a0013300200530000000f000011022d02172a160a2b3f02066f5d00000a287d00000a2c1d061758250a026f3900000a2e0e02066f5d00000a287e00000a2d12162a02066f5d00000a287e00000a2c02162a0617580a06026f3900000a32b8172a00133002005c0000000000000002726b110070282800000a2d4d027279110070282800000a2d40027289110070282800000a2d33027293110070282800000a2d2602729d110070282800000a2d190272af110070282800000a2d0c0272b9110070282800000a2a172a13300200390100001500001102393101000002283900000a0a061759450a0000000d0000008b000000fa000000460000009a000000fa000000fa0000002a000000c7000000a9000000061f133bb000000038ed0000000216285d00000a0b071f303bb9000000071f403bcf00000038d00000000216285d00000a0b071f232e24071f302e31071f682e3b38b40000000272cb110070282800000a3a80000000389f0000000272d5110070282800000a2d6e388d0000000272e7110070282800000a2d5c2b7e0272f9110070282800000a2d5f2b6f02720b120070282800000a2d3e2b60027211120070282800000a2d2f2b5102721d120070282800000a2d262b42027233120070282800000a2d1d2b3302725b120070282800000a2d1a2b24726b1100702a72931100702a729d1100702a72af1100702a72b91100702a72891100702a142a42021f303209021f39fe0216fe012a162a000013300200fc00000016000011160a160b026f3900000a2d02162a02066f5d00000a1f2b2e0b02066f5d00000a1f2d330e0617580a2b080617580a0717580b06026f3900000a2f0e02066f5d00000a28310000062de106026f3900000a2f3002066f5d00000a1f2e33250617580a2b080617580a0717580b06026f3900000a2f0e02066f5d00000a28310000062de1072d02162a06026f3900000a2f6202066f5d00000a1f652e0b02066f5d00000a1f45334c0617580a06026f3900000a2f1a02066f5d00000a1f2b2e0b02066f5d00000a1f2d33040617580a060c2b040617580a06026f3900000a2f0e02066f5d00000a28310000062de506083302162a06026f3900000afe012a13300200b00000000f000011022c38032d26026f3900000a1f132e19026f3900000a1f15320c026f3900000a1f1bfe022b13172b10162b0d026f3900000a1f0afe0116fe012c02162a160a2b64061a2e04061d330d02066f5d00000a1f2d2e4d162a061f0a330d02066f5d00000a1f542e3b162a061f0d2e05061f10330d02066f5d00000a1f3a2e24162a061f13330d02066f5d00000a1f2e2e12162a02066f5d00000a28310000062d02162a0617580a06026f3900000a3293172a13300500910400001700001102282b0000061f2030330e04282b0000061f2030280e05282b0000062080000000301a04282b0000062000000100300d05282b0000062000000100310719282c0000062a735300000625027d3500000425037d3a00000425047d3600000425057d370000040a02282e0000062c2204282e0000062c1a05282e0000062c120e04282e0000062c090e05282e0000062d08061a282d0000062a022c090f01287f00000a2d080617282d0000062a0272e1020070282800000a2c1f0f01288000000a2d03042c080618282d0000062a052d220617282d0000062a0f01288000000a2d1106042d03052c03182b0117282d0000062a0272dd020070282800000a2c13042c260416288100000a1201288200000a2c160272f5020070282800000a2c110405282b00000a2c080618282d\
0000062a0272d9020070282b00000a2c560272fd020070282b00000a2c490272dd020070282b00000a2c3c0272f5020070282b00000a2c2f0272e1020070282b00000a2c22027205030070282b00000a2c15027201030070282b00000a2c08061c282d0000062a0e042c110e04282f0000062d080618282d0000062a0e052c090e0528300000062b01140c0e052c0b082d08061c282d0000062a0e042c15082c120e0408282b00000a2c080618282d0000062a060e04252d472608252d42260272d9020070282800000a2d2f0272fd020070282800000a2d1b027205030070282800000a2d0772891100702b13729d1100702b0c72791100702b05726b1100707d38000004027201030070282800000a2c09061f0a282d0000062a067b380000047289110070282800000a2c44060272dd020070282800000a2d1d0272f5020070282800000a2d100272e1020070282800000a2d03042b01057d3900000406067b390000042c03162b0118282d0000062a067b380000047279110070282800000a2c550272fd020070282b00000a2c080618282d0000062a0472b3040070282b00000a2c150472b7040070282b00000a2c08061a282d0000062a060472b7040070282800000a738300000a7d3e0000040616282d0000062a027205030070282800000a39ca000000067b380000047293110070282b00000a2c1a067b38000004729d110070282b00000a2c080618282d0000062a04067b380000047293110070282800000a28330000062c4804067b380000047293110070282800000a2d18188d320000012516726f120070a22517729b120070a22b0e178d32000001251672d7120070a2288100000a161205288400000a2d08061a282d0000062a067b380000047293110070282800000a2c0f061105738500000a7d3f0000042b0d061105738500000a7d400000040616282d0000062a0272d9020070282b00000a2d03042d080618282d0000062a046f3900000a2080000000310719282c0000062a067b380000047293110070282800000a2d12067b38000004729d110070282800000a2c110f06287f00000a2d080618282d0000062a0412032835000006130411042c09061104282d0000062a067b38000004726b110070282800000a2c1406097b460000047d3d0000040616282d0000062a0609060f06288600000a2838000006282d0000062a000000133007002e020000180000110314510228320000062d021a2a02166f5d00000a1f2dfe010a02166f5d00000a1f2d2e0b02166f5d00000a1f2b330902176f4400000a100002188d3800000125161f659d25171f459d6f8700000a0b160c0716322e020717586f4400000a1a288100000a1202288200000a2c0a081fc03205081f4031021b2a0216076f6100000a1000021f2e6f5e00000a0d0916320c026f3900000a095917592b01160859130402729b0f0070724d0000706f8800000a178d3800000125161f309d6f6300000a130511056f3900000a2d390373540000062572b30400707d430000042516738900000a7d4600000451162a11051611056f3900000a17596f6100000a1305110417591304110416310f110572b30400701a6f1700000a2dd31104162f2611056f3900000a1104591f2631021b2a11051f30110465738a00000a283f00000a130516130411056f3900000a1f26300611041f2631021b2a1a8d400000011306110513081613092b50110811096f5d00000a1f30596e130a16130b2b241106110b956e1f0a6a5a110a58130c1106110b110c6d9e110c1f2064130a110b1758130b110b11068e6932d4110a2c06738b00000a7a110917581309110911086f3900000a32a51a8d3c000001130716130d2b101107110d1106110d959e110d1758130d110d1a32eb0373540000062511057d430000042511047d4400000425067d45000004251711056f3900000a1104288c00000a288c00000ad21104d20616fe011107738d00000a7d4600000451162a0000133005008600000019000011166a0a026f3900000a1f0e588d380000010b078e690c026f3900000a17590d2b3602096f5d00000a1f30596a2100c0692ac90000005a0658130407081759250c1f306a11041f0a6a5d58d19d11041f0a6a5b0a0917590d09162fc62b1707081759250c1f306a061f0a6a5d58d19d061f0a6a5b0a06166a30e40708078e690859738e00000a2a0000133004007b000000090000110228360000060a066f3900000a0330181f30031758066f3900000a59738a00000a06283f00000a0a032c110616066f3900000a03596f6100000a2b010616288100000a04288f00000a2d02162a0316312806066f3900000a03596f5d00000a1f353216044c21ffffffffffffff7f3302162a04044c176a5855172a00133005002a0200001a000011027b450000042c14037b3800000472b9110070282b00000a2c021e2a027b430000040a066f3900000a027b44000004301d1f30027b440000041758066f3900000a59738a00000a06283f00000a0a027b440000042c160616066f3900000a027b44000004596f6100000a2b0106027b440000042c1506066f3900000a027b44000004596f4400000a2b0572b30400700b16288100000a1202288f00000a2d021e2a037b3800000472b9110070282800000a2c31027b43000004027b44000004120328370000062d021e2a03027b450000042d03092b020965739000000a7d42000004162a037b3800000472af110070282800000a2c39082d21027b43000004027b44000004120328370000062c0c092100c0692ac900000032021e2a0309739100000a739200000a7d41000004162a042d08081f\
3c6a33021d2a042d0508176a32090820dab937006a31021e2a037b380000047293110070282800000a2c1b07178d3800000125161f309d6f9300000a6f3900000a2c031f092a07027b44000004120328370000062d021e2a042d0b08081f3c6afe026a592b01081304042d10206b0700001f0c1f1f739400000a2b0c20700700001717739400000a13061206289500000a11042100c0692ac90000005a58095813051105166a321211057e9600000a13061206289500000a31021e2a037b380000047293110070282800000a2c14031105739700000a738500000a7d3f0000042b12031105739700000a738500000a7d40000004162a000013300a00c10000001b00001102283a0000061f206a30370e04283a0000061f206a302b0e05283a00000620800000006a301c04283a00000620000001006a300e05283a00000620000001006a3110178d0c000002251619282c000006a22a178d0c000002251602283b0000060f01289800000a2d0e0f01289900000a738300000a2b091200fe150e00001b0604283b00000605283b0000060e04283b0000060e05283b0000060f06289800000a2d0e0f06289900000a738300000a2b091200fe150e00001b062834000006a22a56022c0f026f9a00000a2d07026f9b00000a2a166a2a66022c14026f9a00000a2d0c026f9c00000a739d00000a2a142a42022c0702737500000a2a7e7600000a2a000013300200490100001c00001102740c0000020a03067b35000004283c000006812700000104067c3a000004287f00000a2d077e7b00000a2b10067c3a000004288000000a737a00000a812800000105067b36000004283c00000681270000010e04067b37000004283c00000681270000010e05067b3b000004737a00000a81280000010e06067b38000004283c00000681270000010e07067c3d000004286a00000a2d0d067b3d0000048c1d0000012b0114510e08067c3e000004287f00000a2d077e7b00000a2b10067c3e000004288000000a737a00000a81280000010e09067b3f000004810f00001b0e0a067b40000004810f00001b0e0b067b41000004811000001b0e0c067c42000004289e00000a2d077e9f00000a2b10067c4200000428a000000a73a100000a811b0000010e0d067b39000004283c00000681270000010e0e067b3c000004737900000a811c0000012a36735500000625027d480000042a32022c07026f3900000a2a162a13300200530000000f000011022d02172a160a2b3f02066f5d00000a287d00000a2c1d061758250a026f3900000a2f0e02066f5d00000a287e00000a2d12162a02066f5d00000a287e00000a2c02162a0617580a06026f3900000a32b8172a0013300700fa0300001d00001102283f0000061f20303e0e04283f0000061f2030330e05283f0000062080000000302504283f0000062000000100301805283f0000062000000100300b0e07283f0000061f20310719283e0000062a0228400000062c2b0428400000062c230528400000062c1b0e0428400000062c120e0528400000062c090e0728400000062d071a283e0000062a020304050e040e050e0628340000060a067b3c0000042c0c067b3c000004283e0000062a0e0772ed120070282b00000a2c230e0772f9120070282b00000a2c150e077205130070282b00000a2c0718283e0000062a0e052d0718283e0000062a0e0539cf0200000e05283900000a130511051759450a0000000e000000a20000009502000050000000b500000095020000950200002f00000095020000c800000011051f133bd200000038870200000e0516285d00000a130611061f303bd000000011061f403bf100000038660200000e0516285d00000a130611061f232e2711061f302e3411061f682e4138450200000e0572cb110070282800000a3a90000000382f0200000e0572d5110070282800000a2d7d381c0200000e0572e7110070282800000a2d6a38090200000e0572f9110070282800000a3a3901000038f30100000e05720b120070282800000a2d4138e00100000e057211120070282800000a2d2e38cd0100000e05721d120070282800000a2d6138ba0100000e057233120070282800000a3a8400000038a4010000067c3d000004286a00000a2c081f0b283e0000062a067b3d0000040e050e0728460000060b3881010000067b390000042d081f0b283e0000062a067b390000040b3865010000067c3f00000428a200000a2d081f0b283e0000062a067c3f00000428a300000a1307120772d7120070288100000a28a400000a0b382c010000067c4000000428a200000a2d081f0b283e0000062a067c4000000428a300000a13071207289500000a7e9600000a13071207289500000a120228420000062d071e283e0000062a08739700000a130712077211130070288100000a28a400000a0b38c6000000067c4100000428a500000a2d081f0b283e0000062a067c4100000428a600000a1308120828a700000a21ffbf692ac9000000120328420000062d071e283e0000062a120409289100000a1b8d320000012516120428a800000a130512057239130070288100000a28a900000aa22517723f130070a22518120428aa00000a130512057239130070288100000a28a900000aa22519723f130070a2251a120428ab00000a130512057239130070288100000a28a900000aa228ac00000a0b2b071c283e0000062a20000100006a1a6a076f3900000a6a5a5820000004006a310719283e0000062a735500000625077d4700000425167d480000042a0000133003003b0000001e0000110220809698006a5b0a0220809698006a5d20404b\
4c006a320506176a580a060320809698006a5b310604166a55162a040620809698006a5a55172a0013300400960000001f0000110f0028ad00000a0a1a8d400000010b1613042b0e071104061104949e11041758130411041a32ed1f278d380000010c088e690d166a13051913062b2611051f2062071106956e60130707110611071f0a6a5c6d9e11071f0a6a5e13051106175913061106162fd508091759250d1f306a110558d19d0716952db90717952db40718952daf0719952daa0809088e690959738e00000a2a0000133003004800000020000011026fae00000a0a068e6917590b2b240607931f392e1406078f3800000125491758d15306739d00000a2a06071f309d0717590b07162fd872b704007006739d00000a283f00000a2a13300300530000002100001103163010021f300365738a00000a283f00000a2a03026f3900000a310672b30400702a026f3900000a03590a062c0a0216066f6100000a2b0572b30400700b02066f5d00000a1f352f02072a0728440000062a0013300600b0020000220000110228430000060a0472ed120070282800000a2d0772431300702b05729b0f00700b0472ed120070282800000a2d07729b0f00702b0572431300700c0372e7110070282800000a39da0000000672b3040070282800000a2d12066f3900000a0f0028af00000a5917592b0116130806066f3900000a19592845000006130911096f3900000a19310d724713007013091108175813080f0028b000000a2d0d0672b3040070282b00000a2d07724d0000702b05724f130070130a1d8d320000012516110aa225171109166f5d00000a130b120b28b100000aa2251807a225191109176f4400000aa2251a7253130070a2251b110816320772571300702b05724f130070a2251c110828b200000a130c120c7239130070288100000a28a900000aa228ac00000a2a03720b120070282800000a2d0d037211120070282800000a2b01170d0372b3040070282800000a2d1003720b120070282800000a2d03182b01161304060f0028af00000a092d03162b011859110459284500000613051105178d3800000125161f309d6f9300000a6f3900000a16fe01130611056f3900000a1104301c1f301104175811056f3900000a59738a00000a1105283f00000a130511042c1411051611056f3900000a1104596f6100000a2b02110513071107178d3800000125161f309d6f6300000a130711076f3900000a2d0772b304007013070372d5110070282800000a2c53735700000a130d16130e2b33110e16311711076f3900000a110e59195d2d09110d086f5900000a26110d1107110e6f5d00000a6fb300000a26110e1758130e110e11076f3900000a32c2110d6f5a00000a13070f0028b000000a2d0411062c07724d0000702b05724f130070110711042c1907110511056f3900000a1104596f4400000a283f00000a2b05724d000070092d07724d0000702b05725b130070286600000a2a56022c0f026f9a00000a2d07026f9b00000a2a166a2a66022c14026f9a00000a2d0c026f9c00000a739d00000a2a142a13300b00da0000001b0000110228470000061f206a30430e0428470000061f206a30370e05284700000620800000006a302804284700000620000001006a301a05284700000620000001006a300c0e0728470000061f206a3116178d0e0000022516735500000625197d48000004a22a178d0e00000225160228480000060f01289800000a2d0e0f01289900000a738300000a2b091200fe150e00001b060428480000060528480000060e0428480000060e0528480000060f06289800000a2d0e0f06289900000a738300000a2b091200fe150e00001b060e0728480000062841000006a22a0000133002006b0000002300001102750e0000020a062c23067b4800000416321a067b480000041f0b3010067b480000042c13067b470000042c0b725f13007073b400000a7a03067b470000042c12067b470000046fae00000a73b500000a2b0528b600000a5104067b48000004737900000a811c0000012a00133002005401000000000000027b12000004176a3f3c010000027b1200000420000000016a3d2b010000027b13000004176a3f1e010000027b1300000420000000016a3d0d010000027b14000004176a3f00010000027b1400000420000000046a3def000000027b15000004173fe3000000027b1500000420000100003dd3000000027b16000004173fc7000000027b160000041f203dba000000027b17000004173fae000000027b1700000420a08601003d9e000000027b18000004173f92000000027b180000042050c300003d82000000027b19000004173279027b190000041f40306f027b1a000004176a3265027b1a00000420000080006a3057027b1b000004176a324d027b1b00000420000000086a303f027b1c000004173236027b1c00000420881300003029027b1d0000047eb700000a28b800000a2d17027b1d00000420c800000073b900000a28ba00000a2c0a729113007028190000062a133002008f000000000000000220000000016a7d120000040220000000016a7d130000040220000000046a7d140000040220000100007d15000004021f207d160000040220a08601007d17000004022050c300007d18000004021f407d190000040220000080006a7d1a0000040220000000086a7d1b0000040220881300007d1c0000040220c800000073b900000a7d1d00000402281200000a2a1e02281200000a2a1e02281200000a2a2e7350000006802f0000042a1e02281200000a2aca037b23000004047b230000042e12037c23000004\
047b2300000428bb00000a2a037c24000004047b2400000428bb00000a2a1e02281200000a2a6602177d3b000004027e7c00000a7d3d00000402281200000a2a1e02281200000a2a1e02281200000a2a42534a4201000100000000000c00000076342e302e33303331390000000005006c000000e8130000237e000054140000800f000023537472696e677300000000d4230000ac1300002355530080370000100000002347554944000000903700007412000023426c6f620000000000000002000001571da2090902000000fa01330016000001000000440000000e0000004800000055000000cc000000bb000000040000001100000023000000010000000200000003000000110000000100000005000000080000000000f60501000000000006000404780906006304780906007603a7080f009809000006009e032d070600e7032d0706004a042d07060024042d0706008a0359090600b5032d070600530c63060a0023080b0f3300d40600000e004905a70806007e000f01060058000f0106005b0378093f008b08000006006f000f0143008b0800001200020835061200bd0a350606003408200e0600aa05630606001e0063060600370063061600ae00ef0916006600ef091600a705ef0906003602440b1600750aef0912007907350606006007200e0e004b07db0006003f07db001600d20361081600ad0161081600a701610816001a05ef0916008a06ef090600610263061600980bef090600b80663060600db0c6306060042086306060044000f0106004806db0006002607630606004e06db000600260563060600b207630606004202630612009402350612003b0535061200550835060600ef076306060029000f010600a80763060600cd0711070600690063060600d40911070600130863060600c509110706005f0063060600a007630606005a0563060600b100630606008607630600000000c1000000000001000100010110009e05e3062d000100010081011000fd0be3062d001100220081011000a002e3062d0011002b0080011000990ee3062d0012003e0081011000f401e3062d001200470002011000d60b00002d0012004b00020110005a0c00002d001e004d0002011000170600002d0023004e00032110000b0100002d002f004f00030110006f0e00002d003100520005011000ab0c00002d0035005300030110000d0c00002d004300540005011000ab0c00002d00470055005680600cc20551803a0bc2055180220bc2052100d104c50521009405c9052100900dcd0521001a0cd0052100190ad9052100c10be1052100dd0be90501003f0aed050100320aed052100c20dc2052100320bd90501007a01f00501003b01ed055180d90aed050600510aed050600990aed0506006a0aed050600140ccd050600ba0bcd050600ff0acd050600ad0acd0506008205cd0506005e0aed050600890aed0506003309cd050600e3072b040600ce05cd0506005702c2050600590fc2050600e90dc20506009c00f00506006f0ecd050600c606cd0506007c02c2050600b904c2050600af04c20506002c0ec20506009b01c20506008b04c2050600470df00506000f0df00506002d0df00506007f0ef3053600bd00fa0516000100fe0506007c08f3050600e401c20506005a0c0606060017060a0603005a01c20503005a0ec2050300500ec20503006801c2050300380ec20503004c0d0e060300d907f0050300200ccd050300f407da0203008d060e0603001303150603006102150603006e021e060300ff0627060300c80bc20503002a02cd050300d904f0050300c504da020300a10ec2050300200ccd0550200000000086088b00b70001005820000000008108980015000100642000000000861896082e06020038220000000086087e0a3602040040220000000086005c0d060004004822000000008600b60b36060400dc22000000008600e80a3c060400b425000000008100130643060500d829000000008100a90a50060800742b0000000081009a0506000800e02e000000008100140b58060800e030000000008100040a06000a007c32000000008100ad0263060a00bc32000000008100400669060c0088330000000081002a016f060d00bc33000000008100500e75060e0064340000000081004c0e75060f004235000000008100130210001000573500000000810019020e0211008b35000000009300ef027b0612009e35000000009300eb0881061400a3350000000093004a0187061600b0350000000081008e0506001800f535000000008100f502060018001e36000000009100f1058d0618003036000000009100b40d920619006036000000009100e2049a061c00c536000000009100f4049a061f00d8360000000091004703a10622007c37000000009100cf0d8d0625003438000000009100fd04a70126007039000000009100dd0daa062800b439000000009100780baa062900583a000000009100d60baf062a00703b0000000091002a01ca063500ec3c000000009100c502ea064300133d000000009100ca02ea0644003c3d000000009600b60bf0064500683d000000009600e80a0d075100913d000000009100500e2c075e00a43d000000009600ab0b33075f00643e000000009600f20a4e0766000340000000009100e40b870775001040000000009100c1018c0776002840000000009100530592077700e440000000009100b700a20179004441000000009100730ca2017a00ac41000000009100d90eaa067b00f1420000000091008d0cfa027c0004430000000091007706a2017d000c440000000091006f069a077e00c844000000009300\
5203a007800068490000000091000d03b4078700a44b000000009100e20eaa068900384c0000000091000505bc078a00c04c000000009100de05c4078d00f84e000000009600830ccd079000c54f0000000091006305e7079700db4f0000000091002605ee079800f54f000000009100500e2c07990008500000000096001c06f5079a005d510000000091007c083a08a9006b51000000009100e40b8707aa007851000000009100b700a201ab00d85100000000930052034008ac00e055000000009100c6085508b4002856000000009300b20c5d08b700cc56000000009100d10caa06b800205700000000910005056308b9008057000000009300f4076908bb003c5a0000000091006305e707be00525a000000009100f60eee07bf006c5a00000000960052037108c000545b0000000096006b0e8e08c800cc5b00000000860018030600cb002c5d00000000861896080600cb00c75d00000000861896080600cb00cf5d00000000861896080600cb00d75d0000000091189c089a08cb00e35d00000000861896080600cb00eb5d0000000083000b009e08cb001e5e00000000861896080600cd00265e00000000861896080600cd00405e00000000861896080600cd00485e00000000861896080600cd0000000100cb0400000100fb0e00000200dd0b00000100be05000001000c0800000200730e00000300b50a00000100ee0d00000200d90100000100ee0d00000200920e00000100ee0d000001000c08000001000c08000001000c0800000100cb0400000100a30a00000100460900000200050900000100a50d000002007f0d000001001f0900000200460900000100020f00000100a108000002005c0200000300750b00000100550e000002007b0e00000300820800000100550e000002007b0e00000300820800000100550e02000200730e02000300cd06000001005c0200000100d901000002007c0c00000100d90100000100ed0500000100d10400000200ee0d00000300e705000004001a0c00000500c10b00000600050b00000700b50a00000800550e00000900880500000a00e90700000b006c0c00000100110e00000200d60500000300050b00000400d10400000500ee0d00000600e705000007001a0c00000800c10b00000900fc0a00000a00b50a00000b00550e00000c00880500000d00e90700000e006c0c00000100020f00000100020f00000100110e00000200d10400000300ee0d00000400e705000005001a0c00000600c10b00000700050b00000800b50a00000900550e00000a00880500000b00e90700000c006c0c00000100110e00000200d60500000300d10400000400ee0d00000500e705000006001a0c00000700c10b00000800050b00000900b50a00000a00550e00000b00880500000c00e90700000d006c0c00000100cb0400000100cb0402000200820802000300ec0102000400d605020005005c0202000600640f02000700a50000000100cb0402000200820802000300ec0102000400cb0502000500cd0602000600c00202000700540d020008005e0e02000900550e02000a001e0d02000b00e50002000c00bc0102000d00430102000e003a0d02000f00200200000100cb0400000100270c00000100730e00000200270c00000100cb0400000100cb0400000100cb0400000100cb0400000100cb0400000100cb04000002001c0300000100610100000200540d000003005e0e00000400550e000005007c0c000006003e0c00000700a500000001005e0e02000200fb0700000100cf0b00000100cf0b00000200300202000300e20a00000100fb0700000200730e00000300a50000000100610100000200540d000003005e0e00000400550e000005007c0c000006003e0c00000700a50000000100cb0400000100cb0400000100cb0400000100cb0402000200610102000300540d020004005e0e02000500550e02000600de0702000700710102000800fb0702000900950602000a001c0302000b006a0202000c00730202000d00080702000e00420e02000f00270c00000100270c00000100550e00000100550e00000100610100000200540d000003005e0e00000400550e000005007c0c000006003e0c00000700a50000000800e70200000100e20a00000200820602000300330100000100cb0400000100cb0400000100cf0b00000200c90100000100cb04000002003e0c00000300e70200000100cb0400000100cb0400000100610100000200540d000003005e0e00000400550e000005007c0c000006003e0c00000700a50000000800e702000001005e0602000200a90e02000300270c000001000001000002000901090096080100110096080600190096080a002900960810003100960810003900960810004100960810004900960815005100960810008900960806002101960806007100620e2e006101710d33006901b20537000c00960845001400960845001c0096080600590096080600790196085e00810196086500690096086b006900e1097c0091016a0581001400880889002400030d9b002c00c50ead002c008104b2002400170eb700a101020306001c008808c6003400030dad003400170eb7001c00670dd6001c00b10eda003c00960806004400960806001c0055060b01a90087021101a9004e02170191013f0f1b01a900ca001701a9007e05d60091014b0f1b01a900be0cb700a9003d0421013c00670dd6004400cd0e260144002f012c013c002f0134014c00960865003c00fd0d41013c00b10eda005400960834015c00670dd6005c0055060b015c009608060091015f05d6005c002f013401640096084500a900\
3d049c0191016f0fa2016400cd0e26019101370ca7011400a304ad011c002f01340164002f012c0191017305810091012d05ce0169000b0bd3019101370cd80114002f012c011400cd0e260191011205e7010c00a304ad016900b90dfa010c002f012c01b10096080600b10037050002b10051080702b100e70c0e02b100a7090e02b100ea0b1500b100570b1500b100020e1500a90021031302a9002a01b700b90096080600a90081041701b900940123025900240517017100d308360211019608100091018e0b41029101120551029101930c560291010e05510291012d0569025c000a026f029101f30d7a025c002e0c01009101c10680029101370c8b0291010e05e701d9002a06b700e1002a06b700e9002a06b700d90081043602e1008104d600e900810493026c0096080600f9002a06b700f9005f053602f9008104b9026c002f013401d101e0011701e1003006be0239019608100039013006c20254009604b70054008104ad00e1009608010041019608150041013006ce02e9003006da02c1012803fa02c1013803fa0274009604b70074008104ad00d901d2021703e1010a031d037400960834014901450c2a037c00960834017400990cad009101eb0e4e039101d1019c01e900960801009101960854030902960806001102770e5a03e9009608600391019608720319020a037a038c0096083401590196080e0284009608340191016a067a024901960893034901cf0a36024901c2049a03490196080e0241012a06b70041018104b70051012a06b70051015f05360251018104a70391019608ac038c009604b700d9003006b7038c008104ad00d90096080e027c009604b7007c008104ad0049012405ce0384009604b70084008104ad005901cf0a36025901a10bd600e1012405ce035901260ad6005901ba08d6009101370cd603e900f900ee039101b90ea703e90026021104e900ee04b700c101240517011102a3081504b90094011a0421029608100051019608ac03510121062504c10078022b04c100ac062f04c10096080100c1009d062f04e101c30737040e00040045040e000800b8040e000c0031050a004400b9052000530079092e000b00ae082e001300b7082e001b00d6082e002300df082e002b0000092e0033003f092e003b004d092e00430066092e004b006c09400053007909430153007909e10153007909c0045b007e09e0045b00760b20075b00280e20095b00d3101a00bb00e0004b0162017b01b601df01ef01f3011d02290231023a0246024a025d029802c702d302ff0204030a033b03690387039f03b203bb03dc03e003f303f903fe0320040200010000009c00a6080000820aaa080200010003000100020003000200040005003d00500057009400a600cf00fd0004013a0156015c019501b202de02e402ec02f402048000000100020000000000000000000000260f00000400000000000000000000003c0402010000000001000400000000000000000000000b0f000000000400000000000000000000003c046306000000000400000000000000000000003c043506000000000400000000000000000000003c04ed00000000000700020008000200090002000a0002000b0003000c0004000d0004000e00050000000000003c3e395f5f32365f30003c5265616443656c6c733e625f5f32365f30004e756c6c61626c6560310049456e756d657261626c65603100436f6d70617269736f6e60310049457175616c697479436f6d70617265726031004c69737460310055496e7433320053716c496e743332004b657956616c75655061697260320044696374696f6e6172796032006765745f4461746531393034007365745f44617465313930340064617465313930340053716c496e743634005574663136003c3e39003c4d6f64756c653e006765745f4e616d6573706163655552490053797374656d2e494f00666f726d756c610053797374656d2e44617461006765745f44617461006d73636f726c6962003c3e630053797374656d2e436f6c6c656374696f6e732e47656e6572696300526561640041646400726f756e646564006368617267656400736861726564004973427564676574457870697265640053746f7265640073746f726564005265736f6c766564007265736f6c766564003c44617465313930343e6b5f5f4261636b696e674669656c6400417070656e6400466f726d756c614b696e640053797374656d446174614163636573734b696e64006b696e6400446973636172640064697363617264005265706c61636500736f75726365006765745f4d657373616765006d65737361676500586c737843656c6c446973706c61794272696467650041646452616e6765004f7574707574436861726765006361636865006765745f5363616c65007363616c650049456e756d657261626c650049446973706f7361626c65006765745f4c6f63616c4e616d65006e616d65004461746554696d65006461746554696d650074696d65004f6e650053746f72656454797065006765745f4e6f64655479706500586d6c4e6f64655479706500586c737843656c6c547970650052657175697265436f6e74656e7454797065007479706500496e7075744661696c757265006765745f496e76617269616e7443756c747572650063756c747572650053686f756c64436865636b5072656369736500446973706f736500547279506172736500446174650056616c69646174650043726561746500497348696768537572726f676174650049734c6f77537572726f6761746500436f6f7264696e617465004576616c756174650043\
6f6d70696c657247656e6572617465644174747269627574650044656275676761626c6541747472696275746500436f6d56697369626c6541747472696275746500417373656d626c795469746c6541747472696275746500417373656d626c7946696c6556657273696f6e4174747269627574650053716c46756e6374696f6e41747472696275746500417373656d626c794465736372697074696f6e41747472696275746500436f6d70696c6174696f6e52656c61786174696f6e7341747472696275746500417373656d626c7950726f647563744174747269627574650047657441747472696275746500417373656d626c79436f6d70616e794174747269627574650052756e74696d65436f6d7061746962696c697479417474726962757465006765745f56616c756500436163686556616c7565006765745f48617356616c75650054727947657456616c7565005465787456616c75650052617756616c7565004d617856616c75650076616c75650061726368697665004e65676174697665004e6f6e6e65676174697665006765745f4973506f736974697665005265736f6c7665005175616e74697a65004c617374496e6465784f660053716c537472696e6700546f537472696e6700537562737472696e67007365745f44746450726f63657373696e670053746f7077617463680046696e697368004d617468006765745f4c656e67746800456e6473576974680053746172747357697468006765745f446570746800646570746800436865636b00636c6f636b0052656164576f726b626f6f6b0053716c446563696d616c006765745f4f7264696e616c0073686565744f7264696e616c00726f774f7264696e616c006f7264696e616c0054656d706f72616c00746f74616c0072656c004661696c00546f6f6c62656c742e46696c652e586c73784d656d6f72792e646c6c005265616443656c6c0046696c6c006765745f4e756c6c006765745f49734e756c6c0053797374656d2e586d6c004f70656e586d6c004d656d6f727953747265616d006765745f4974656d006974656d0053797374656d005472696d0049736f466f726d004e756d626572466f726d006d6178696d756d0053716c426f6f6c65616e00626f6f6c65616e006f705f477265617465725468616e006f705f4c6573735468616e0054696d655370616e004a6f696e00436f6c756d6e00636f6c756d6e004172636869766553657373696f6e00546f6f6c62656c742e586c73782e5175616c696669636174696f6e004475726174696f6e006475726174696f6e0053797374656d2e476c6f62616c697a6174696f6e00416374696f6e0053797374656d2e5265666c656374696f6e00494f457863657074696f6e00496e76616c696444617461457863657074696f6e004465636f64657246616c6c6261636b457863657074696f6e00586d6c457863657074696f6e00496e76616c69644f7065726174696f6e457863657074696f6e004f766572666c6f77457863657074696f6e00537472696e67436f6d70617269736f6e00436f6d70617265546f0043756c74757265496e666f004563686f006563686f00526174696f00726174696f0043686172004e756d626572006e756d62657200586d6c526561646572007265616465720049466f726d617450726f7669646572005a6970456e74727950726f766964657200537472696e674275696c64657200537472696e67436f6d7061726572007365745f586d6c5265736f6c766572004d6963726f736f66742e53716c5365727665722e536572766572004572726f72006572726f7200476574456e756d657261746f72002e63746f72002e6363746f72004162730053797374656d2e446961676e6f7374696373006765745f5365636f6e647300526f756e645365636f6e6473006765745f456c61707365644d696c6c697365636f6e647300436f61727365456c61707365644d696c6c697365636f6e647300636f61727365456c61707365644d696c6c697365636f6e647300656c61707365644d696c6c697365636f6e6473004275646765744d696c6c697365636f6e6473006275646765744d696c6c697365636f6e64730053797374656d2e52756e74696d652e496e7465726f7053657276696365730053797374656d2e52756e74696d652e436f6d70696c6572536572766963657300446562756767696e674d6f646573007365745f4d61784368617261637465727346726f6d456e746974696573004461746554696d655374796c6573004e756d6265725374796c6573006765745f506172744e616d65730053797374656d2e446174612e53716c54797065730056616c6964617465436f6e74656e74547970657300636f6e74656e745479706573006765745f4d696e75746573006465636f6465644279746573006d6174657269616c697a656442797465730041726368697665427974657300537472696e67427974657300546f74616c42797465730053716c4279746573006765745f436f756e746564416c6c6f636174696f6e4279746573005061727442797465730062797465730052656164537472696e677300737472696e677300586d6c52656164657253657474696e6773006765745f5469636b73004461795469636b73007469636b73005265616443656c6c730046696c6c43656c6c73006d617843656c6c730063656c6c7300436f6e7461696e73005265616452656c6174696f6e73004f666669636552656c6174696f6e7300776f726b626f6f6b52656c6174696f6e730053797374656d2e436f6c6c656374696f6e73007365745f49\
676e6f726550726f63657373696e67496e737472756374696f6e7300536f757263654f6652656c6174696f6e7368697073006765745f43686172730053716c4368617273006765745f486f7572730046696c6c536865657473004c697374536865657473007368656574730044696769747300646967697473004c696d697473006c696d69747300556e697473007365745f49676e6f7265436f6d6d656e747300586c7378456e747279506f696e747300446563696d616c506172747300706172747300537461747573007374617475730052656d6f7665417400436f6e63617400666f726d61740054727950617273654578616374004f626a656374005368656574005370726561647368656574006275646765740049735461726765740074617267657400496e746572707265740044696769740053706c69740047657456616c75654f7244656661756c7400526573756c7400436f656666696369656e74006765745f4973456d707479456c656d656e7400496e6372656d656e7400456e7669726f6e6d656e74007365745f4d617843686172616374657273496e446f63756d656e74006765745f43757272656e7400466f726d756c6150726573656e7400666f726d756c6150726573656e7400436163686550726573656e7400636163686550726573656e740056616c756550726573656e740070726573656e7400436865636b706f696e74006765745f436f756e74006765745f5469636b436f756e740063757272656e745469636b436f756e7400636f6172736553746172745469636b436f756e740073746172745469636b436f756e7400526f6f7400526561645061727400776f726b626f6f6b506172740043616e6f6e6963616c506172740052656c6174696f6e73686970506172740070617274005472696d537461727400536f7274007365745f436c6f7365496e70757400696e707574004d6f76654e6578740053797374656d2e5465787400466f726d756c61546578740054797065645465787400747970656454657874005269636854657874007465787400526177007261770053746172744e65770046696c6c526f7700726f77004d6178006d617800536861726564466f726d756c61496e6465780073756666697800586c737843656c6c446973706c617900646973706c617900546f417272617900546f436861724172726179006765745f4b657900436f6e7461696e734b657900436c617373696679004d756c7469706c7900496e6465784f66416e7900436f70790062696e6172790063617465676f727900546f6f6c62656c742e417263686976652e5a69704d656d6f727900546f6f6c62656c742e46696c652e586c73784d656d6f7279006f705f457175616c697479006f705f496e657175616c697479005669736962696c697479007669736962696c6974790049734e756c6c4f72456d70747900000000002749004e005000550054005f004e0055004c004c005f0049004e005400450052004e0041004c00000b2e00720065006c00730000175f00720065006c0073002f002e00720065006c0073000001001f01006f006600660069006300650044006f00630075006d0065006e007400013757004f0052004b0042004f004f004b005f00520045004c004100540049004f004e005f004400550050004c0049004300410054004500003357004f0052004b0042004f004f004b005f00520045004c004100540049004f004e005f004d0049005300530049004e0047000015730068006500650074002e006d00610069006e00001b530048004500450054005f004f005200440049004e0041004c00001377006f0072006b0073006800650065007400000772006f007700007368007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f00730070007200650061006400730068006500650074006d006c002f0032003000300036002f006d00610069006e0000137300680065006500740044006100740061000035530048004500450054005f0044004100540041005f004e0045005300540049004e0047005f0049004e00560041004c0049004400002752004f0057005f004e0045005300540049004e0047005f0049004e00560041004c004900440000037200001b52004f0057005f005200450046004500520045004e0043004500000363000029430045004c004c005f004e0045005300540049004e0047005f0049004e00560041004c00490044000015430045004c004c005f004c0049004d0049005400001d430045004c004c005f004400550050004c0049004300410054004500001f57004f0052004b00530048004500450054005f0045004d005000540059000023430045004c004c005f0052004f0057005f004d00490053004d0041005400430048000003740000036e0000037300001369006e006c0069006e0065005300740072000007730074007200000362000003650000036400002b430045004c004c005f0054005900500045005f0055004e0053005500500050004f0052005400450044000031430045004c004c005f0043004f004e00540045004e0054005f0055004e0053005500500050004f00520054004500440000037600001f560041004c00550045005f004400550050004c004900430041005400450000036600002346004f0052004d0055004c0041005f004400550050004c0049004300410054004500000d6e006f0072006d0061006c00000d730068006100720065006400000b610072007200610079000013\
64006100740061005400610062006c006500003146004f0052004d0055004c0041005f004b0049004e0044005f0055004e0053005500500050004f005200540045004400000573006900002946004f0052004d0055004c0041005f005300480041005200450044005f0049004e00440045005800000569007300002b49004e004c0049004e0045005f0053005400520049004e0047005f0049004e00560041004c0049004400002f5300480041005200450044005f0053005400520049004e0047005f005200450046004500520045004e00430045000003300000033100002b42004f004f004c00450041004e005f00560041004c00550045005f0049004e00560041004c0049004400001d010073006800610072006500640053007400720069006e006700730001315300480041005200450044005f0053005400520049004e00470053005f004400550050004c0049004300410054004500001b73006800610072006500640053007400720069006e00670073000007730073007400003b5300480041005200450044005f0053005400520049004e0047005f004e0045005300540049004e0047005f0049004e00560041004c004900440000335300480041005200450044005f0053005400520049004e0047005f0043004f0055004e0054005f004c0049004d004900540000315300480041005200450044005f0053005400520049004e0047005f0054004500580054005f004c0049004d004900540000295300480041005200450044005f0053005400520049004e00470053005f0045004d00500054005900000d730068006500650074007300001177006f0072006b0062006f006f006b00002d5300480045004500540053005f004e0045005300540049004e0047005f0049004e00560041004c0049004400001577006f0072006b0062006f006f006b0050007200003757004f0052004b0042004f004f004b005f00500052004f0050004500520054004900450053005f0049004e00560041004c0049004400001164006100740065003100390030003400000b660061006c0073006500000974007200750065000021440041005400450031003900300034005f0049004e00560041004c0049004400000b73006800650065007400002b530048004500450054005f004e0045005300540049004e0047005f0049004e00560041004c00490044000017530048004500450054005f004c0049004d004900540000096e0061006d00650000056900640000808768007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f006f006600660069006300650044006f00630075006d0065006e0074002f0032003000300036002f00720065006c006100740069006f006e0073006800690070007300000b73007400610074006500000f760069007300690062006c0065000025530048004500450054005f004e0041004d0045005f0049004e00560041004c0049004400000d680069006400640065006e0000157600650072007900480069006400640065006e000031530048004500450054005f005600490053004900420049004c004900540059005f0049004e00560041004c00490044000015010077006f0072006b0073006800650065007400012d530048004500450054005f00520045004c004100540049004f004e005f004d0049005300530049004e004700001d57004f0052004b0042004f004f004b005f0045004d00500054005900001b520065006c006100740069006f006e0073006800690070007300007968007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f007000610063006b006100670065002f0032003000300036002f00720065006c006100740069006f006e00730068006900700073000019520065006c006100740069006f006e00730068006900700000155400610072006700650074004d006f006400650000054900640000095400790070006500000d540061007200670065007400001149006e007400650072006e0061006c00003b450058005400450052004e0041004c005f00520045004c004100540049004f004e005f0055004e0053005500500050004f0052005400450044000021520045004c004100540049004f004e005f0049004e00560041004c004900440000808968007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f006f006600660069006300650044006f00630075006d0065006e0074002f0032003000300036002f00720065006c006100740069006f006e00730068006900700073002f000033520045004c004100540049004f004e005f0054005900500045005f0055004e0053005500500050004f0052005400450044000015760062006100500072006f006a006500630074000019650078007400650072006e0061006c004c0069006e006b00001763006f006e006e0065006300740069006f006e007300000f63006f006e00740072006f006c0000136f006c0065004f0062006a00650063007400002f520045004c004100540049004f004e005f005400410052004700450054005f004d0049005300530049004e00470000030100011d520045004c004100540049004f004e005f0045004d0050005400590000275b0043006f006e00740065006e0074005f005400790070006500\
73005d002e0078006d006c00000b54007900700065007300007968007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f007000610063006b006100670065002f0032003000300036002f0063006f006e00740065006e0074002d0074007900700065007300011743006f006e00740065006e0074005400790070006500002943004f004e00540045004e0054005f0054005900500045005f0049004e00560041004c004900440000114f007600650072007200690064006500001150006100720074004e0061006d00650000032f00002d43004f004e00540045004e0054005f0054005900500045005f004400550050004c0049004300410054004500000f440065006600610075006c007400003143004f004e00540045004e0054005f0054005900500045005f0055004e0053005500500050004f005200540045004400000b6d006100630072006f000007760062006100000f6100630074006900760065005800003358004c00530058005f0043004f004e00540045004e0054005f0054005900500045005f004d0049005300530049004e00470000796100700070006c00690063006100740069006f006e002f0076006e0064002e006f00700065006e0078006d006c0066006f0072006d006100740073002d006f006600660069006300650064006f00630075006d0065006e0074002e00730070007200650061006400730068006500650074006d006c002e0001092b0078006d006c00002b43004f004e00540045004e0054005f0054005900500045005f004d00490053004d004100540043004800001d50004100520054005f00530055004d005f004c0049004d0049005400001f58004d004c005f00440045005000540048005f004c0049004d0049005400002954004500580054005f004e0045005300540049004e0047005f0049004e00560041004c00490044000007720050006800003143004f0055004e005400450044005f0041004c004c004f0043004100540049004f004e005f004c0049004d0049005400001f4200550044004700450054005f004500580043004500450044004500440000135400420058005f0058004c00530058005f00002958004d004c005f0052004f004f0054005f0055004e0053005500500050004f005200540045004400001d430045004c004c005f005200450046004500520045004e0043004500002b50004100520054005f004e0041004d0045005f0055004e0053005500500050004f00520054004500440000032e0000052e002e000037520045004c004100540049004f004e005f005400410052004700450054005f0055004e0053005500500050004f005200540045004400002d520045004c004100540049004f004e005f005400410052004700450054005f00450053004300410050004500000d5f00720065006c0073002f00000f2f005f00720065006c0073002f000025520045004c004100540049004f004e005f0050004100520054005f004e0041004d004500002b5400420058005f0058004c00530058005f004c0049004d00490054005f0043004f004e00460049004700002d5400420058005f0058004c00530058005f00530048004500450054005f004f005200440049004e0041004c00002d5400420058005f0058004c00530058005f0041005200430048004900560045005f004c0049004d004900540000295400420058005f0058004c00530058005f0058004d004c005f0049004e00560041004c004900440000335400420058005f0058004c00530058005f0045004e0043004f00440049004e0047005f0049004e00560041004c004900440000355400420058005f0058004c00530058005f0043004f004e005400410049004e00450052005f0049004e00560041004c0049004400000d6e0075006d00620065007200000f62006f006f006c00650061006e00000974006500780074000009640061007400650000116400610074006500740069006d0065000009740069006d00650000116400750072006100740069006f006e00000930002e0030003000001123002c002300230030002e0030003000001130002e003000300045002b00300030000011680068003a006d006d003a0073007300000530002500000b30002e00300030002500001579007900790079002d006d006d002d0064006400012779007900790079002d006d006d002d00640064002000680068003a006d006d003a007300730001135b0068005d003a006d006d003a0073007300002b79007900790079002d004d004d002d0064006400270054002700480048003a006d006d003a0073007300013b79007900790079002d004d004d002d0064006400270054002700480048003a006d006d003a00730073002e004600460046004600460046004600011579007900790079002d004d004d002d0064006400010b65006e002d0055005300010b640065002d0044004500010b740072002d0054005200012779007900790079002d004d004d002d00640064002000480048003a006d006d003a007300730001054400320000033a0000032c00000731003000300000032d000103450000032b000003250000315400420058005f0058004c00530058005f0044004900530050004c00410059005f00420049004e00440049004e00470000194c0049004d00490054005f0043004f004e00460049004700000034f5dbb761836f40b3906d5531f6966000042001010803200001052001011111042001010e04200101021307060e1d0e\
080e151149020e0e15114d020e0e0400001239030000080500001280b50715123d020e1d050a200101151280b90113000615123d020e0e06151241011220062002011d0502052002011c18102008011280c50a0a080a0a11611280c10420001d0e072002020e1180cd0a2000151149021300130106151149020e0e0a200015114d02130013010615114d020e0e04200013000420001301032000020a0702151151011220122008200015115101130006151151011220032000080520001d13001c070a151241010e15124101122415123d020a0212550202020812240a061512410112240615123d020a020520011300080520001180d50320000e050002020e0e0420010e0e052001021300072002011300130105200101130006151269011224092001011512690113000a070708080e1224080e0805151165010805151241010e1807070e151241010e151149020e0e15114d020e0e1255020e19070c15123d020e021255020202020e0e0e0e0e1511510112200615123d020e020520020e0e0e040001020e0500020e0e0e08200202130010130117070a15123d020e0e15123d020e021255020e0e0e0e0e0e0420010e08042001020e0600030e0e0e0e0707040212550e0e072002080e1180cd0307010e0607021d0512590520011d050e062001011180d9062001011280dd042001010a09000212551280c5125905070208125d052001125d0e07070408125d080e04070208090320000a0607040a0e08030420010308030701080607031d0e080e04200108030620011d0e1d030b0704151241010e1d0e080e0520020e08080a200101151280e50113000520010e1d030a00020e0e151280e5010e0700040e0e0e0e0e042000116119070915124101122c121c120812791d12240812241d122012200615124101122c0420001d0503061171040611809d060702122c122004061180a1060702122c12240306117505151165010207151165011180a507151165011180ad05151165010a040001020304070208030507030808080c07061230080e1234081180a50500001280ed0c0004020e1180f51280f91008100005020e1d0e1280f91180fd101180a512070e02080808080e1d091d080e080b080b08052001081d03052002010308050002080808082004010505021d080807050a1d0308080a072003011d0308080c0004020e1180f51280f9100a0b07070e0e0a0a0a0a1180a50620030108080804061180a507070115116501020420001d03052001011d0304070112300306116d12070912300e0a0a1180ad08031180a51180ad0720020e0e1280f90500010e1d0e0307010a0d07081d081d091d0308080b080b0420001d080507021d0308040702080e12070f0e0e0e02080e020e080e0e0308125d08032000050400010808052001125d0304070112380500001280a9030611610700020211611161042001080808b77a5c561934e0897268007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f00730070007200650061006400730068006500650074006d006c002f0032003000300036002f006d00610069006e007868007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f007000610063006b006100670065002f0032003000300036002f00720065006c006100740069006f006e0073006800690070007300808668007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f006f006600660069006300650044006f00630075006d0065006e0074002f0032003000300036002f00720065006c006100740069006f006e00730068006900700073000800c0692ac900000002060e0306123503061239020608080615123d020e1d05070615123d020e0e07061512410112200306121c02060a020602060615116501080306122807061512690112240306122003061224060615116501020806151165011180a50806151165011180ad0606151165010a072002011d05121c0520001d12200620011d1224080c20031224125508151241010e072000151241010e0a200215123d020e0e0e0e052002010e0e05200112550e0520010212550520010e1255050002020809050002090808050002020a08040001010e0700030112550e0e060003080e080e080003010e100810080400010e0e1a000b121c116d116d116d1171117111711171116d1171117511711f000e1279127d117102116d116d116d1171117111711171116d11711175117105000112790e1c000c1279127d116d116d116d1171117111711171116d1171117511711e000d1279127d1171116d116d116d1171117111711171116d11711175117106000111809d0e1a0007011c1011711011809d1011711011809d1011809d101180a138000f011c1011711011809d1011711011711011809d101180a11011809d1011809d101180a11011809d1011809d101171101180a11011809d040001080e0500011230080700021230123008050002020e0213000712300e15116501020e0e0e0e1511650102070002080e101234070003020e08100a08000308123412300219000712791280a91180a11280a91280a91280a91280a91180a10600010a1280a90600010e1280a944000f011c1011809d101180a11011809d1011809d101180a11011809d101c101180a110151165011180a5\
10151165011180a510151165011180ad10116d1011809d10117105000112380814000812380e15116501020e0e0e0e15116501020e070003020a0a100a0500010e11750500020e0e080700030e11750e0e1c000812791280a91180a11280a91280a91280a91280a91180a11280a90b0003011c101280a9101171030000010720020812241224032800020328000a0801000800000000001e01000100540216577261704e6f6e457863657074696f6e5468726f7773010801000200000000002001001b546f6f6c62656c7420584c5358204d656d6f72792052656164657200003e010039426f756e64656420534146452062696e61727920584c535820776f726b736865657420616e64207370617273652063656c6c2072656164657200000d0100086765636f6d70617400001801001353514c2053657276657220546f6f6c62656c7400000501000000000c010007312e322e302e300000040100000081f601000600540e1146696c6c526f774d6574686f644e616d650a46696c6c5368656574735455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630054020949735072656369736501540e0f5461626c65446566696e6974696f6e7e4572726f724e756d62657220696e742c204572726f724d657373616765206e766172636861722834303030292c2053686565744f7264696e616c20696e742c2053686565744e616d65206e76617263686172286d6178292c205669736962696c697479206e76617263686172283136292c2044617465313930342062697482b001000600540e1146696c6c526f774d6574686f644e616d650946696c6c43656c6c735455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630054020949735072656369736501540e0f5461626c65446566696e6974696f6e81384572726f724e756d62657220696e742c204572726f724d657373616765206e766172636861722834303030292c20526f774f7264696e616c20696e742c20436f6c756d6e4f7264696e616c20696e742c2053746f72656454797065206e76617263686172283136292c2056616c756550726573656e74206269742c2052617756616c7565206e76617263686172286d6178292c205465787456616c7565206e76617263686172286d6178292c20466f726d756c6150726573656e74206269742c20466f726d756c6154657874206e76617263686172286d6178292c20466f726d756c614b696e64206e76617263686172283136292c20536861726564466f726d756c61496e64657820696e742c20436163686550726573656e74206269742c20436163686556616c7565206e76617263686172286d61782982a901000600540e1146696c6c526f774d6574686f644e616d650446696c6c5455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630154020949735072656369736501540e0f5461626c65446566696e6974696f6e813653746f72656454797065206e76617263686172283332292c2056616c756550726573656e74206269742c2052617756616c7565206e76617263686172286d6178292c205465787456616c7565206e76617263686172286d6178292c204563686f507265736572766564206269742c205265736f6c76656454797065206e766172636861\
72283136292c204e756d62657256616c75652073716c5f76617269616e742c20426f6f6c65616e56616c7565206269742c204461746556616c756520646174652c204461746554696d6556616c7565206461746574696d65322837292c2054696d6556616c75652074696d652837292c204475726174696f6e5469636b7320626967696e742c2054797065645465787456616c7565206e76617263686172286d6178292c20537461747573436f646520696e74819e01000600540e1146696c6c526f774d6574686f644e616d650746696c6c526f77540e0f5461626c65446566696e6974696f6e29446973706c617954657874206e76617263686172286d6178292c20537461747573436f646520696e745455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630154020949735072656369736501000000000000000000000000001000000000000000000000000000000098a800000000000000000000b2a80000002000000000000000000000000000000000000000000000a4a80000000000000000000000005f436f72446c6c4d61696e006d73636f7265652e646c6c0000000000ff250020001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100100000001800008000000000000000000000000000000100010000003000008000000000000000000000000000000100000000004800000058c00000c80300000000000000000000c80334000000560053005f00560045005200530049004f004e005f0049004e0046004f0000000000bd04effe00000100020001000000000002000100000000003f000000000000000400000002000000000000000000000000000000440000000100560061007200460069006c00650049006e0066006f00000000002400040000005400720061006e0073006c006100740069006f006e00000000000000b00428030000010053007400720069006e006700460069006c00650049006e0066006f0000000403000001003000300030003000300034006200300000008c003a00010043006f006d006d0065006e0074007300000042006f0075006e00640065006400200053004100460045002000620069006e00610072007900200058004c0053005800200077006f0072006b0073006800650065007400200061006e00640020007300700061007200730065002000630065006c006c002000720065006100640065007200000032000900010043006f006d00700061006e0079004e0061006d006500000000006700650063006f006d007000610074000000000060001c000100460069006c0065004400650073006300720069007000740069006f006e000000000054006f006f006c00620065006c007400200058004c005300580020004d0065006d006f007200790020005200650061006400650072000000300008000100460069006c006500560065007200730069006f006e000000000031002e0032002e0030002e00300000005a001d00010049006e007400650072006e0061006c004e0061006d006500000054006f006f006c00620065006c0074002e00460069006c0065002e0058006c00730078004d0065006d006f00720079002e0064006c006c00000000002800020001004c006500670061006c0043006f00700079007200690067006800740000002000000062001d0001004f0072006900670069006e0061006c00460069006c0065006e0061006d006500000054006f006f006c00620065006c0074002e00460069006c0065002e0058006c00730078004d0065006d006f00720079002e0064006c006c0000000000480014000100500072006f0064007500630074004e0061006d00650000000000530051004c002000530065007200760065007200200054006f006f006c00620065006c0074000000340008000100500072006f006400750063007400560065007200730069006f006e00000031002e0032002e0030002e003000000038000800010041007300730065006d0062006c0079002000\
560065007200730069006f006e00000031002e0032002e0030002e003000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a000000c000000c43800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000,
 @Version nvarchar(max),@Hash varbinary(64),@AssemblyId int,@InstalledMode nvarchar(max),
 @Installed bit,@Release int,@Phase int=0,@ProtectFuture bit=1;
IF ISNULL(TRY_CONVERT(int,SERVERPROPERTY('ProductMajorVersion')),0) NOT IN(15,16,17)
 THROW 51530,N'Unterstützt werden SQL Server 2019, 2022 und 2025.',1;
IF CONVERT(varbinary(max),@Mode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))
 THROW 51530,N'DeploymentMode muss exakt local oder central sein.',1;
IF @Bits IS NULL OR DATALENGTH(@Bits)<1024 THROW 51531,N'Plausibles Releasebinary fehlt.',1;
SET @Hash=HASHBYTES('SHA2_512',@Bits);
DECLARE @Dependency TABLE(Id nvarchar(128) NOT NULL,MinimumMinor int NOT NULL,ObjectId int NULL,Version nvarchar(64) NULL);
DECLARE @Slots TABLE(Name sysname COLLATE DATABASE_DEFAULT NOT NULL,Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL,FirstRelease int NOT NULL,Class nvarchar(128) NULL,Method nvarchar(128) NULL);
INSERT @Slots VALUES
 (N'USP_ListXlsxWorksheets','P',10,NULL,NULL),
 (N'USP_ReadXlsxWorksheetCells','P',10,NULL,NULL),
 (N'USP_InternalXlsxRead','P',10,NULL,NULL),
 (N'TVF_InternalXlsxSheets','FT',10,N'Toolbelt.Xlsx.Qualification.XlsxEntryPoints',N'ListSheets'),
 (N'TVF_InternalXlsxCells','FT',10,N'Toolbelt.Xlsx.Qualification.XlsxEntryPoints',N'ReadCells'),
 (N'TVF_InternalInterpretXlsxCell','FT',11,N'Toolbelt.Xlsx.Qualification.XlsxCellType',N'Interpret'),
 (N'TVF_InterpretXlsxCell','IF',11,NULL,NULL),
 (N'TVF_InternalFormatXlsxCell','FT',12,N'Toolbelt.Xlsx.Qualification.XlsxCellDisplayBridge',N'Evaluate'),
 (N'TVF_FormatXlsxCell','IF',12,NULL,NULL);
DECLARE @Own TABLE(Id int NOT NULL PRIMARY KEY);
BEGIN TRY
 WHILE @Phase<2
 BEGIN
  -- Benutzerfreigabe 2026-10-02: vollständige Consumersicht vor Mutation,
  -- im zweiten Durchlauf erneut unter demselben Transaktions-AppLock.
  IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
   OR ISNULL(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
   THROW 51535,N'Vollständige Sicht auf SQL-Abhängigkeiten ist erforderlich.',2;
  IF NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr enabled' AND value_in_use=1)
   OR NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr strict security' AND value_in_use=1)
   OR NOT EXISTS(SELECT 1 FROM sys.trusted_assemblies WHERE hash=@Hash)
   THROW 51531,N'CLR/strict security und exakter Releasehashtrust sind erforderlich.',1;
-- Beide Dependencies werden vor jeder Mutation kanonisch geprüft.
DELETE FROM @Dependency;
INSERT @Dependency SELECT N'toolbelt.core.result-table',0,OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P'),
 TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
INSERT @Dependency SELECT N'toolbelt.archive.zip-memory',4,NULL,TRY_CONVERT(nvarchar(64),value)
 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.archive.zip-memory.Version';
IF (SELECT COUNT(*) FROM @Dependency)<>2 OR EXISTS
 (SELECT 1 FROM @Dependency d
  CROSS APPLY(SELECT TRY_CONVERT(int,PARSENAME(d.Version,3)) Major,
    TRY_CONVERT(int,PARSENAME(d.Version,2)) Minor,TRY_CONVERT(int,PARSENAME(d.Version,1)) Patch) p
  WHERE p.Major IS NULL OR p.Major<>1 OR p.Minor IS NULL OR p.Minor<d.MinimumMinor OR p.Patch IS NULL OR p.Patch<0
    OR CONVERT(varbinary(max),d.Version)<>CONVERT(varbinary(max),CONCAT(p.Major,N'.',p.Minor,N'.',p.Patch))
    OR (d.Id=N'toolbelt.core.result-table' AND (d.ObjectId IS NULL
        OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE e.class=1 AND e.major_id=d.ObjectId AND e.minor_id=0
             AND e.name=N'Toolbelt.ModuleId' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(128),e.value))=CONVERT(varbinary(max),d.Id))
        OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE e.class=1 AND e.major_id=d.ObjectId AND e.minor_id=0
             AND e.name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),e.value))=CONVERT(varbinary(max),d.Version)))))
 THROW 51532,N'Die registrierten ResultTable- und ZIP-Dependencies sind ungeeignet.',1;
IF NOT EXISTS(SELECT 1 FROM sys.assemblies a JOIN sys.extended_properties e ON e.class=5 AND e.major_id=a.assembly_id
 WHERE a.name=N'Toolbelt_Archive_ZipMemory' AND a.permission_set=1 AND e.name=N'Toolbelt.ModuleId'
 AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(128),e.value))=CONVERT(varbinary(max),N'toolbelt.archive.zip-memory'))
 THROW 51532,N'Die kanonische SAFE-ZIP-Assembly fehlt.',1;

-- Keine Hashgleichheit ersetzt die bekannte Release-/Slotidentität.
SELECT @Version=NULL,@Installed=0,@InstalledMode=NULL,@AssemblyId=NULL;
SELECT @Version=TRY_CONVERT(nvarchar(max),value),@Installed=1 FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.Version';
SELECT @InstalledMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode';
IF @Installed=1 AND (@Version IS NULL OR CONVERT(varbinary(max),@Version) NOT IN
 (CONVERT(varbinary(max),N'1.0.0'),CONVERT(varbinary(max),N'1.1.0'),CONVERT(varbinary(max),N'1.2.0')))
 THROW 51534,N'Unbekannter oder inkohärenter XLSX-Release.',1;
IF (@Installed=1 AND (@InstalledMode IS NULL OR CONVERT(varbinary(max),@InstalledMode) NOT IN
 (CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))))
 OR (@Installed=0 AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode'))
 THROW 51534,N'Unbekannter oder inkohärenter XLSX-Modus.',1;
SET @Release=CASE CONVERT(varbinary(max),@Version) WHEN CONVERT(varbinary(max),N'1.0.0') THEN 10 WHEN CONVERT(varbinary(max),N'1.1.0') THEN 11 WHEN CONVERT(varbinary(max),N'1.2.0') THEN 12 ELSE 0 END;
SELECT @AssemblyId=assembly_id FROM sys.assemblies WHERE name=N'Toolbelt_File_XlsxMemory';
IF (@Installed=1 AND @AssemblyId IS NULL) OR (@Installed=0 AND @AssemblyId IS NOT NULL)
 OR (@AssemblyId IS NOT NULL AND (NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@AssemblyId AND permission_set=1
  AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_File_XlsxMemory'))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND name=N'Toolbelt.ModuleId'
 AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.file.xlsx-memory'))))
 THROW 51534,N'Fremde oder inkohärente XLSX-Assembly.',1;
IF EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(s.Name))
 WHERE (@Installed=1 AND s.FirstRelease<=@Release AND
  (o.object_id IS NULL OR CONVERT(varbinary(max),o.name)<>CONVERT(varbinary(max),s.Name)
   OR CONVERT(varbinary(max),o.type)<>CONVERT(varbinary(max),s.Kind)
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleId'
      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.file.xlsx-memory'))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleVersion'
      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Version))
   OR (s.Kind='FT' AND NOT EXISTS(SELECT 1 FROM sys.assembly_modules m WHERE m.object_id=o.object_id AND m.assembly_id=@AssemblyId
      AND CONVERT(varbinary(max),m.assembly_class)=CONVERT(varbinary(max),s.Class)
      AND CONVERT(varbinary(max),m.assembly_method)=CONVERT(varbinary(max),s.Method)))))
  OR ((@Installed=0 OR s.FirstRelease>@Release) AND o.object_id IS NOT NULL AND @ProtectFuture=1))
 THROW 51534,N'XLSX-Slot, Typ oder Eigentumsmarker ist nicht der bekannte Release.',1;
DELETE FROM @Own;
INSERT @Own SELECT OBJECT_ID(N'toolbelt_file.'+QUOTENAME(Name)) FROM @Slots WHERE FirstRelease<=@Release;
IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@AssemblyId AND object_id NOT IN(SELECT Id FROM @Own))
 OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@AssemblyId)
 THROW 51535,N'Fremder Assemblyconsumer blockiert XLSX-Lifecycle.',1;
IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d WHERE d.referenced_id IN
 (SELECT o.Id FROM @Own o JOIN sys.objects a ON a.object_id=o.Id WHERE a.type IN('FT','IF'))
 AND d.referencing_id NOT IN(SELECT Id FROM @Own))
 THROW 51535,N'Fremder Consumer verwendet ein XLSX-Binding.',1;
  IF @Phase=0
  BEGIN
   BEGIN TRANSACTION;
   DECLARE @Lock int;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.file.xlsx-memory',
    @LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock<0 THROW 51533,N'Paralleles XLSX-Deployment aktiv.',1;
  END;
  SET @Phase+=1;
 END;
 IF SCHEMA_ID(N'toolbelt_file') IS NULL
 BEGIN
   EXEC(N'CREATE SCHEMA toolbelt_file');
   EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_file';
   EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'file',@level0type=N'SCHEMA',@level0name=N'toolbelt_file';
 END;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_FormatXlsxCell;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_InternalFormatXlsxCell;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_InterpretXlsxCell;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_InternalInterpretXlsxCell;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_InternalXlsxSheets;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_InternalXlsxCells;
 DECLARE @InstalledHash varbinary(64)=(SELECT HASHBYTES('SHA2_512',content) FROM sys.assembly_files WHERE assembly_id=@AssemblyId AND file_id=1);
 IF @InstalledHash IS NULL OR @InstalledHash<>@Hash
 BEGIN
   DECLARE @Ddl nvarchar(max)=CASE WHEN @AssemblyId IS NULL THEN N'CREATE' ELSE N'ALTER' END
      +N' ASSEMBLY [Toolbelt_File_XlsxMemory] FROM '+CONVERT(nvarchar(max),@Bits,1)+N' WITH PERMISSION_SET=SAFE;';
   EXEC sys.sp_executesql @Ddl;
 END;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
/*
-- Objekt: toolbelt_file.TVF_InternalFormatXlsxCell (interne CLR-FT).
-- Zweck: Reiner Einzelzell-Anzeigetransport auf unverändertem Typkern.
-- Parameter: Acht Zell-/Ziel-/Kulturparameter, keine Workbook-/Styleauswertung.
-- Resultset: Genau eine nullable Zeile DisplayText nvarchar(max), StatusCode int.
-- Fehler: Erwartete Zellfehler als Status; unerwartete CLR-Fehler original.
-- Performance: Feste Input-/Ausgabequoten, kein externer Datenzugriff.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE FUNCTION toolbelt_file.TVF_InternalFormatXlsxCell
(
 @StoredType nvarchar(max), @ValuePresent bit, @RawValue nvarchar(max),
 @TextValue nvarchar(max), @TargetType nvarchar(max), @FormatCode nvarchar(max),
 @Date1904 bit, @CultureName nvarchar(max)
)
RETURNS TABLE(DisplayText nvarchar(max) NULL, StatusCode int NULL)
AS EXTERNAL NAME [Toolbelt_File_XlsxMemory].[Toolbelt.Xlsx.Qualification.XlsxCellDisplayBridge].[Evaluate];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER FUNCTION toolbelt_file.TVF_FormatXlsxCell
(
 @StoredType nvarchar(max)=NULL, @ValuePresent bit=NULL, @RawValue nvarchar(max)=NULL,
 @TextValue nvarchar(max)=NULL, @TargetType nvarchar(max)=NULL, @FormatCode nvarchar(max)=NULL,
 @Date1904 bit=NULL, @CultureName nvarchar(max)=NULL
)
/*
-- Objekt: toolbelt_file.TVF_FormatXlsxCell.
-- Zweck: Bereits gelesene XLSX-Einzelzelle mit endlichen Formaten anzeigen.
-- Parameter: @StoredType/@RawValue/@TextValue/@TargetType/@FormatCode nvarchar(max),
-- @ValuePresent/@Date1904 bit, @CultureName nvarchar(max), alle Default NULL.
-- Kultur: ausschließlich en-US, de-DE oder tr-TR, ohne Betriebssysteminferenz.
-- Resultset: DisplayText nvarchar(max) nullable und StatusCode int immer gesetzt.
-- NULL: Keine Null-on-null-Abkürzung; genau eine Statuszeile auch bei NULL-Input.
-- Fehler: 0OK/1Absent/2Argument/3Limit/4LexikUTF16/5NumberRange/6Unsupported/
-- 7Serial60/8TemporalRange/9Precision/10ExcelError/11NullBinding; Fehlertext NULL.
-- Rechte: vorhandenes SELECT/Ownershipchain, keine Rechteerteilung.
-- Performance: Typkernbudgets unverändert; Kultur höchstens32 UTF16-Einheiten.
-- Grenzen: Kein Workbook-/SST-/Stylezugriff, keine Formelberechnung oder Daueranzeige.
-- Dependencies: Interne FT in vorhandener SAFE-XLSX-Assembly, Typkern unverändert.
-- Beispiel: SELECT * FROM toolbelt_file.TVF_FormatXlsxCell(N'n',1,N'1.235',NULL,N'number',N'0.00',NULL,N'en-US');
-- Vertrag: Documentation/Architecture/XLSX_CELL_DISPLAY_CONTRACT.md.
*/
RETURNS TABLE AS RETURN
 SELECT CASE WHEN r.StatusCode IS NOT NULL THEN r.DisplayText END DisplayText,
        ISNULL(r.StatusCode,11) StatusCode
 FROM toolbelt_file.TVF_InternalFormatXlsxCell
 (@StoredType,@ValuePresent,@RawValue,@TextValue,@TargetType,@FormatCode,@Date1904,@CultureName) r;
GO
/*
-- Objekt: toolbelt_file.TVF_InternalInterpretXlsxCell (interne CLR-FT)
-- Parameter: Sieben Zell-/Zielparameter; keine Workbook- oder Styleauswertung.
-- Resultset: Genau eine nullable Statuszeile mit 14 Spalten.
-- Fehlerverhalten: Erwartete Zellfehler als Status; unerwartete CLR-Fehler original.
-- Performance: Feste Input-/Ausgabequoten, datenzugriffsfreie Einzelzellinterpretation.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE FUNCTION toolbelt_file.TVF_InternalInterpretXlsxCell
(
 @StoredType nvarchar(max), @ValuePresent bit, @RawValue nvarchar(max),
 @TextValue nvarchar(max), @TargetType nvarchar(max), @FormatCode nvarchar(max), @Date1904 bit
)
RETURNS TABLE
(
 StoredType nvarchar(32) NULL, ValuePresent bit NULL, RawValue nvarchar(max) NULL,
 TextValue nvarchar(max) NULL, EchoPreserved bit NULL, ResolvedType nvarchar(16) NULL,
 NumberValue sql_variant NULL, BooleanValue bit NULL, DateValue date NULL,
 DateTimeValue datetime2(7) NULL, TimeValue time(7) NULL, DurationTicks bigint NULL,
 TypedTextValue nvarchar(max) NULL, StatusCode int NULL
)
AS EXTERNAL NAME [Toolbelt_File_XlsxMemory].[Toolbelt.Xlsx.Qualification.XlsxCellType].[Interpret];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER FUNCTION toolbelt_file.TVF_InterpretXlsxCell
(
 @StoredType nvarchar(max) = NULL, @ValuePresent bit = NULL, @RawValue nvarchar(max) = NULL,
 @TextValue nvarchar(max) = NULL, @TargetType nvarchar(max) = NULL,
 @FormatCode nvarchar(max) = NULL, @Date1904 bit = NULL
)
/*
-- Objekt: toolbelt_file.TVF_InterpretXlsxCell
-- Zweck: Bereits gelesene XLSX-Einzelzelle invariant typisieren, ohne Anzeigeformatierung.
-- Parameter: @StoredType nvarchar(max)=NULL (n/b/s/str/inlineStr/d/e),
-- @ValuePresent bit=NULL (XML-v-Presence), @RawValue nvarchar(max)=NULL,
-- @TextValue nvarchar(max)=NULL (bereits aufgelöster Text), @TargetType nvarchar(max)=NULL
-- (number/boolean/text/date/datetime/time/duration), @FormatCode nvarchar(max)=NULL
-- (endliche Zielklassifikation), @Date1904 bit=NULL (n-Date/Datetime benötigt Datumssystem).
-- Resultset: Genau eine Zeile mit StoredType nvarchar(32), ValuePresent bit,
-- RawValue nvarchar(max), TextValue nvarchar(max), EchoPreserved bit,
-- ResolvedType nvarchar(16), NumberValue sql_variant (exaktes SqlDecimal p<=38),
-- BooleanValue bit, DateValue date, DateTimeValue datetime2(7), TimeValue time(7),
-- DurationTicks bigint, TypedTextValue nvarchar(max), StatusCode int.
-- NULL: Echo-/Typedwerte nullable; EchoPreserved/StatusCode logisch immer gesetzt.
-- Ausschließlich NULL-Input liefert eine Statuszeile, keine Null-on-null-Abkürzung.
-- Fehlerverhalten: 0OK/1Absent/2Argument/3Limit/4LexikUTF16/5NumberRange/6Unsupported/
-- 7Serial60/8TemporalRange/9Precision/10ExcelError/11NullBinding. Alle Typedwerte
-- bei Fehler NULL; Status3/11 verwirft Echos atomar. Andere Enginefehler original.
-- Dependencies: Interne FT derselben vorhandenen SAFE-XLSX-Assembly; Moduldependencies
-- ZIP>=1.4.0/ResultTable>=1.0.0 bleiben. Caller benötigt bestehendes SELECT auf der TVF;
-- Deployment erstellt keine Berechtigungen. SQL2019/2022/2025 Windows/Linux Zielmatrix.
-- Performance: Input32/32/128/65536/65536 UTF16; Number-/Serialparser128; Ausgabecharge
-- 262144=256+4*Stringunits, keine gesamte Heap-/SQL-Memorygrant-/Laufzeitgarantie.
-- Grenzen: Keine Workbook-/SST-/Style-Neulesung, Cultureinferenz oder Formelberechnung.
-- Beispiel: SELECT * FROM toolbelt_file.TVF_InterpretXlsxCell(N'n',1,N'1',NULL,NULL,NULL,NULL);
*/
RETURNS TABLE
AS
RETURN
 SELECT
  CASE WHEN r.StatusCode IS NOT NULL THEN r.StoredType END AS StoredType,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.ValuePresent END AS ValuePresent,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.RawValue END AS RawValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.TextValue END AS TextValue,
  ISNULL(CASE WHEN r.StatusCode IS NOT NULL THEN r.EchoPreserved END,CONVERT(bit,0)) AS EchoPreserved,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.ResolvedType END AS ResolvedType,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.NumberValue END AS NumberValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.BooleanValue END AS BooleanValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.DateValue END AS DateValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.DateTimeValue END AS DateTimeValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.TimeValue END AS TimeValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.DurationTicks END AS DurationTicks,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.TypedTextValue END AS TypedTextValue,
  ISNULL(r.StatusCode,11) AS StatusCode
 FROM toolbelt_file.TVF_InternalInterpretXlsxCell
  (@StoredType,@ValuePresent,@RawValue,@TextValue,@TargetType,@FormatCode,@Date1904) AS r;
GO
/*
Interner Statusrow-Provider für USP_ListXlsxWorksheets; keine öffentliche Neben-API.
Dependency Toolbelt_File_XlsxMemory 1.0.0 und Toolbelt_Archive_ZipMemory 1.4.0.
SAFE, DataAccess/SystemDataAccess None. Vollständige Materialisierung vor Rows.
Erwartete Inputfehler: eine ErrorNumber/ErrorMessage-Zeile; unerwartete CLR-Fehler
bleiben Originalfehler. Keine Dateisystem- oder Netzwerkzugriffe.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE FUNCTION toolbelt_file.TVF_InternalXlsxSheets
(
    @XlsxBinary varbinary(max),
    @MaxArchiveBytes bigint,
    @MaxPartBytes bigint,
    @MaxTotalUncompressedBytes bigint,
    @MaxParts int,
    @MaxSheets int,
    @MaxCells int,
    @MaxSharedStrings int,
    @MaxSharedStringBytes bigint,
    @MaxXmlDepth int,
    @MaxCompressionRatio decimal(18,4),
    @BudgetMilliseconds int
)
RETURNS TABLE
(
    ErrorNumber int NULL, ErrorMessage nvarchar(4000) NULL,
    SheetOrdinal int NULL,
    SheetName nvarchar(max) NULL,
    Visibility nvarchar(16) NULL,
    Date1904 bit NULL
)
AS EXTERNAL NAME [Toolbelt_File_XlsxMemory].[Toolbelt.Xlsx.Qualification.XlsxEntryPoints].[ListSheets];
GO
/*
Interner Statusrow-Provider für USP_ReadXlsxWorksheetCells; keine öffentliche Neben-API.
Dependency Toolbelt_File_XlsxMemory 1.0.0 und Toolbelt_Archive_ZipMemory 1.4.0.
SAFE, DataAccess/SystemDataAccess None. Vollständige Materialisierung vor Rows.
Erwartete Inputfehler: eine ErrorNumber/ErrorMessage-Zeile; unerwartete CLR-Fehler
bleiben Originalfehler. Keine Dateisystem- oder Netzwerkzugriffe.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE FUNCTION toolbelt_file.TVF_InternalXlsxCells
(
    @XlsxBinary varbinary(max),
    @SheetOrdinal int,
    @MaxArchiveBytes bigint,
    @MaxPartBytes bigint,
    @MaxTotalUncompressedBytes bigint,
    @MaxParts int,
    @MaxSheets int,
    @MaxCells int,
    @MaxSharedStrings int,
    @MaxSharedStringBytes bigint,
    @MaxXmlDepth int,
    @MaxCompressionRatio decimal(18,4),
    @BudgetMilliseconds int
)
RETURNS TABLE
(
    ErrorNumber int NULL, ErrorMessage nvarchar(4000) NULL,
    RowOrdinal int NULL,
    ColumnOrdinal int NULL,
    StoredType nvarchar(16) NULL,
    ValuePresent bit NULL,
    RawValue nvarchar(max) NULL,
    TextValue nvarchar(max) NULL,
    FormulaPresent bit NULL,
    FormulaText nvarchar(max) NULL,
    FormulaKind nvarchar(16) NULL,
    SharedFormulaIndex int NULL,
    CachePresent bit NULL,
    CacheValue nvarchar(max) NULL
)
AS EXTERNAL NAME [Toolbelt_File_XlsxMemory].[Toolbelt.Xlsx.Qualification.XlsxEntryPoints].[ReadCells];
GO
/*
Interne Compiler-/Routinggrenze der beiden öffentlichen XLSX-USPs.
Kein zusätzlicher öffentlicher Funktionsvertrag. Dependency: SAFE Status-TVFs
und ResultTable-Helper. Reservierte Tempnamen prüft der öffentliche Wrapper
vor EXEC; hier erfolgt die erste Kompilierung der fachlichen Tempstatements.
Erwartete Inputfehler vor Mutation; eigene Transaktion oder Caller-Savepoint.
Direkter Aufruf ist intern, keine Grant-Zusage.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE toolbelt_file.USP_InternalXlsxRead
(
    @ReadCells bit = NULL,
    @XlsxBinary varbinary(max) = NULL,
    @SheetOrdinal int = NULL,
    @MaxArchiveBytes bigint = 16777216,
    @MaxPartBytes bigint = 16777216,
    @MaxTotalUncompressedBytes bigint = 67108864,
    @MaxParts int = 256,
    @MaxSheets int = 32,
    @MaxCells int = 100000,
    @MaxSharedStrings int = 50000,
    @MaxSharedStringBytes bigint = 8388608,
    @MaxXmlDepth int = 64,
    @MaxCompressionRatio decimal(18,4) = 200,
    @BudgetMilliseconds int = 5000,
    @ResultTable sysname = NULL,
    @KeepData bit = 0,
    @Debug tinyint = 0,
    @Hilfe bit = 0
)
AS
BEGIN
    SET NOCOUNT ON;
    IF @Hilfe=1
    BEGIN
        DECLARE @Help TABLE
        (HelpContractVersion varchar(16) NOT NULL DEFAULT '1.0',
         SchemaName sysname NOT NULL DEFAULT N'toolbelt_file',
         ObjectName sysname NOT NULL DEFAULT N'USP_InternalXlsxRead',
         Section varchar(32) NOT NULL, Ordinal int NOT NULL, ItemName sysname NULL,
         SqlDataType varchar(256) NULL, IsRequired bit NULL, IsNullable bit NULL,
         DefaultValue nvarchar(4000) NULL, Description nvarchar(max) NOT NULL, ExampleSql nvarchar(max) NULL);
        INSERT @Help (Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql) VALUES
        ('PARAMETER',1,N'@ReadCells','bit',1,0,N'NULL',N'Interner Modus: 0 Sheetliste, 1 Zellliste; öffentliche USPs bevorzugen.',NULL),
        ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'Begrenzter SAFE Binary-XLSX-Reader; atomarer gewählter Snapshot, keine Datei-/Netzwerkzugriffe, Formelberechnung oder Typinferenz.',NULL),
        ('PARAMETER',2,N'@XlsxBinary','varbinary(max)',0,1,N'NULL',N'NULL liefert keine Zeilen und verändert kein ResultTable.',NULL),
        ('PARAMETER',3,N'@SheetOrdinal','int',1,0,N'NULL',N'Positive Worksheetposition aus ListXlsxWorksheets.',NULL),
        ('PARAMETER',4,N'@MaxArchiveBytes','bigint',0,0,N'16777216',N'Containerbytes, höchstens 16 MiB.',NULL),
        ('PARAMETER',5,N'@MaxPartBytes','bigint',0,0,N'16777216',N'Unkomprimierte Bytes je Part, höchstens 16 MiB.',NULL),
        ('PARAMETER',6,N'@MaxTotalUncompressedBytes','bigint',0,0,N'67108864',N'Deklarierte Gesamtbytes, höchstens 64 MiB.',NULL),
        ('PARAMETER',7,N'@MaxParts','int',0,0,N'256',N'ZIP-Parts, höchstens 256.',NULL),
        ('PARAMETER',8,N'@MaxSheets','int',0,0,N'32',N'Worksheets, höchstens 32.',NULL),
        ('PARAMETER',9,N'@MaxCells','int',0,0,N'100000',N'Vorhandene Zellen im gewählten Sheet, höchstens 100000.',NULL),
        ('PARAMETER',10,N'@MaxSharedStrings','int',0,0,N'50000',N'Shared Strings, höchstens 50000.',NULL),
        ('PARAMETER',11,N'@MaxSharedStringBytes','bigint',0,0,N'8388608',N'Dekodierter Shared-String-UTF16-Text, höchstens 8 MiB.',NULL),
        ('PARAMETER',12,N'@MaxXmlDepth','int',0,0,N'64',N'XML-Tiefe, höchstens 64.',NULL),
        ('PARAMETER',13,N'@MaxCompressionRatio','decimal(18,4)',0,0,N'200',N'Maximales deklarierter Ratio, höchstens 200.',NULL),
        ('PARAMETER',14,N'@BudgetMilliseconds','int',0,0,N'5000',N'Kooperatives Gesamtbudget, höchstens 5000 ms; keine harte Wallclockzusage.',NULL),
        ('PARAMETER',15,N'@ResultTable','sysname',0,1,N'NULL',N'Vorhandene caller-lokale Temp-Tabelle, sonst SELECT.',NULL),
        ('PARAMETER',16,N'@KeepData','bit',0,1,N'0',N'Replace 0 oder Append 1; NULL entspricht 0.',NULL),
        ('PARAMETER',17,N'@Debug','tinyint',0,1,N'0',N'Nur Messages ohne Workbookinhalte.',NULL),
        ('PARAMETER',18,N'@Hilfe','bit',0,1,N'0',N'Ausschließlich standardisierte Hilfe.',NULL),
        ('RESULT_COLUMN',1,N'RowOrdinal','int',1,0,NULL,N'Einsbasierte Zeile.',NULL),
        ('RESULT_COLUMN',2,N'ColumnOrdinal','int',1,0,NULL,N'Einsbasierte Spalte.',NULL),
        ('RESULT_COLUMN',3,N'StoredType','nvarchar(16)',1,0,NULL,N'Gespeicherter Zelltyp, keine Typinferenz.',NULL),
        ('RESULT_COLUMN',4,N'ValuePresent','bit',1,0,NULL,N'Gespeichertes v-Element vorhanden, auch wenn leer.',NULL),
        ('RESULT_COLUMN',5,N'RawValue','nvarchar(max)',1,1,NULL,N'Rohtext aus v, NULL bei fehlendem v.',NULL),
        ('RESULT_COLUMN',6,N'TextValue','nvarchar(max)',1,1,NULL,N'Shared-/Inline-/str-Text, kein Excel-Anzeigeformat.',NULL),
        ('RESULT_COLUMN',7,N'FormulaPresent','bit',1,0,NULL,N'f-Element vorhanden.',NULL),
        ('RESULT_COLUMN',8,N'FormulaText','nvarchar(max)',1,1,NULL,N'Unveränderter Formeltext, keine Berechnung.',NULL),
        ('RESULT_COLUMN',9,N'FormulaKind','nvarchar(16)',1,1,NULL,N'normal, shared, array oder dataTable.',NULL),
        ('RESULT_COLUMN',10,N'SharedFormulaIndex','int',1,1,NULL,N'Gespeichertes si, keine Formelrekonstruktion.',NULL),
        ('RESULT_COLUMN',11,N'CachePresent','bit',1,0,NULL,N'Formel und v-Element vorhanden.',NULL),
        ('RESULT_COLUMN',12,N'CacheValue','nvarchar(max)',1,1,NULL,N'Gespeicherter Formelcache-Rohtext.',NULL),
        ('ERROR',1,N'51520',NULL,NULL,NULL,NULL,N'Begrenzte Kategorie eines erwarteten Input-/Container-/XML-/Feature-/Ressourcenfehlers; keine Teilausgabe.',NULL),
        ('ERROR',2,N'51529',NULL,NULL,NULL,NULL,N'Fehlende oder inkonsistente registrierte Dependency bzw. interner Providervertrag.',NULL),
        ('PERMISSION',1,NULL,NULL,NULL,NULL,NULL,N'EXECUTE auf USP; ResultTable zusätzlich Helper-EXECUTE und Sichtbarkeit der caller-lokalen Tabelle. Keine Rechteausweitung.',NULL),
        ('LIMITATION',1,NULL,NULL,NULL,NULL,NULL,N'Transitional XLSX, klassische Stored-/Deflate-ZIPs. Kein ZIP64, externe Beziehungen, Makros oder Strict Open XML. Unicode bleibt unverändert, Tabellen brauchen explizite Ordinals zum Sortieren.',NULL),
        ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Hilfe ohne fachliche Eingaben.',N'EXEC toolbelt_file.USP_ReadXlsxWorksheetCells @Hilfe=1;');
        -- Technische Hilfe benennt die tatsächliche Modus-0-Resultshape;
        -- ohne expliziten Modus bleibt die dokumentierte Zellshape sichtbar.
        IF @ReadCells=0
        BEGIN
            DELETE FROM @Help WHERE Section='RESULT_COLUMN';
            UPDATE @Help SET IsRequired=0,IsNullable=1,
                Description=N'Für den Sheetlistenmodus nicht verwendet.'
                WHERE Section='PARAMETER' AND ItemName=N'@SheetOrdinal';
            INSERT @Help (Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql) VALUES
            ('RESULT_COLUMN',1,N'SheetOrdinal','int',1,0,NULL,N'Einsbasierte Worksheetposition.',NULL),
            ('RESULT_COLUMN',2,N'SheetName','nvarchar(max)',1,0,NULL,N'Unveränderter Worksheetname.',NULL),
            ('RESULT_COLUMN',3,N'Visibility','nvarchar(16)',1,0,NULL,N'visible, hidden oder veryHidden.',NULL),
            ('RESULT_COLUMN',4,N'Date1904','bit',1,0,NULL,N'Gespeichertes Workbook-Datumssystem.',NULL);
        END;
        SELECT HelpContractVersion,SchemaName,ObjectName,
               Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql
        FROM @Help ORDER BY CASE Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2
           WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 WHEN 'PERMISSION' THEN 5
           WHEN 'LIMITATION' THEN 6 ELSE 7 END,Ordinal;
        RETURN 0;
    END;
    SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0);
    IF @ReadCells IS NULL THROW 51529,N'Interner XLSX-Routingmodus fehlt.',1;
    IF @ReadCells=0
    BEGIN
    CREATE TABLE #tbx_ListXlsxWorksheets_ResultSource
    (
        [SheetOrdinal] int NOT NULL,
        [SheetName] nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL,
        [Visibility] nvarchar(16) COLLATE Latin1_General_100_BIN2 NOT NULL,
        [Date1904] bit NOT NULL
    );
    IF @XlsxBinary IS NULL
    BEGIN
        IF @ResultTable IS NULL SELECT [SheetOrdinal],[SheetName],[Visibility],[Date1904] FROM #tbx_ListXlsxWorksheets_ResultSource;
        RETURN 0;
    END;
    IF OBJECT_ID(N'toolbelt_file.TVF_InternalXlsxSheets',N'FT') IS NULL
        THROW 51529,N'Der interne XLSX-Provider fehlt.',1;
    DECLARE @SheetsSnapshot TABLE
    (ErrorNumber int NULL, ErrorMessage nvarchar(4000) NULL,
        [SheetOrdinal] int NULL,
        [SheetName] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [Visibility] nvarchar(16) COLLATE Latin1_General_100_BIN2 NULL,
        [Date1904] bit NULL
    );
    INSERT @SheetsSnapshot SELECT ErrorNumber,ErrorMessage,[SheetOrdinal],[SheetName],[Visibility],[Date1904]
    FROM toolbelt_file.TVF_InternalXlsxSheets(@XlsxBinary,@MaxArchiveBytes,@MaxPartBytes,@MaxTotalUncompressedBytes,@MaxParts,@MaxSheets,@MaxCells,@MaxSharedStrings,@MaxSharedStringBytes,@MaxXmlDepth,@MaxCompressionRatio,@BudgetMilliseconds);
    IF EXISTS(SELECT 1 FROM @SheetsSnapshot WHERE ErrorNumber IS NOT NULL)
    BEGIN
        IF (SELECT COUNT_BIG(*) FROM @SheetsSnapshot)<>1
            THROW 51529,N'Inkonsistenter XLSX-Statusvertrag.',1;
        DECLARE @SheetsError int,@SheetsMessage nvarchar(2048);
        SELECT @SheetsError=ErrorNumber,@SheetsMessage=CONVERT(nvarchar(2048),ErrorMessage) FROM @SheetsSnapshot;
        IF @SheetsError<>51520 OR @SheetsMessage IS NULL
            THROW 51529,N'Ungültiger XLSX-Statusvertrag.',1;
        THROW @SheetsError,@SheetsMessage,1;
    END;
    IF EXISTS(SELECT 1 FROM @SheetsSnapshot WHERE [SheetOrdinal] IS NULL OR [SheetName] IS NULL OR [Visibility] IS NULL OR [Date1904] IS NULL)
        THROW 51529,N'Unvollständige XLSX-Datenzeile.',1;
    INSERT #tbx_ListXlsxWorksheets_ResultSource([SheetOrdinal],[SheetName],[Visibility],[Date1904]) SELECT [SheetOrdinal],[SheetName],[Visibility],[Date1904] FROM @SheetsSnapshot;
    IF @Debug>0 RAISERROR(N'XLSX: validierter Ergebnissnapshot bereit.',10,1) WITH NOWAIT;
    IF @ResultTable IS NULL
    BEGIN
        SELECT [SheetOrdinal],[SheetName],[Visibility],[Date1904] FROM #tbx_ListXlsxWorksheets_ResultSource ORDER BY SheetOrdinal;
        RETURN 0;
    END;
    DECLARE @SheetsDependencyVersion nvarchar(64),@SheetsDependencyId int=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P');
    SELECT @SheetsDependencyVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties
    WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
    DECLARE @SheetsMajor int=TRY_CONVERT(int,PARSENAME(@SheetsDependencyVersion,3)),
            @SheetsMinor int=TRY_CONVERT(int,PARSENAME(@SheetsDependencyVersion,2)),
            @SheetsPatch int=TRY_CONVERT(int,PARSENAME(@SheetsDependencyVersion,1));
    IF @SheetsDependencyId IS NULL OR @SheetsMajor IS NULL OR @SheetsMajor<1 OR @SheetsMinor IS NULL OR @SheetsMinor<0 OR @SheetsPatch IS NULL OR @SheetsPatch<0
       OR CONVERT(varbinary(max),@SheetsDependencyVersion)<>CONVERT(varbinary(max),CONCAT(@SheetsMajor,N'.',@SheetsMinor,N'.',@SheetsPatch))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@SheetsDependencyId AND minor_id=0
           AND name=N'Toolbelt.ModuleId' AND TRY_CONVERT(nvarchar(128),value)=N'toolbelt.core.result-table')
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@SheetsDependencyId AND minor_id=0
           AND name=N'Toolbelt.ModuleVersion'
           AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@SheetsDependencyVersion))
        THROW 51529,N'ResultTable-Dependency >= 1.0.0 fehlt oder ist ungeeignet.',1;
    DECLARE @SheetsOwnTransaction bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,
            @SheetsSavepoint varchar(32)=REPLACE(CONVERT(varchar(36),NEWID()),'-',''),@SheetsSavepointSet bit=0;
    BEGIN TRY
        IF @SheetsOwnTransaction=1 BEGIN TRANSACTION;
        ELSE BEGIN SAVE TRANSACTION @SheetsSavepoint; SET @SheetsSavepointSet=1; END;
        EXEC toolbelt_core.USP_PrepareResultTable
             @ResultTableToAlter=@ResultTable,@LikeTable=N'#tbx_ListXlsxWorksheets_ResultSource',
             @KeepData=@KeepData,@Debug=@Debug;
        DECLARE @SheetsSql nvarchar(max)=N'INSERT INTO '+QUOTENAME(@ResultTable)
           +N' ([SheetOrdinal],[SheetName],[Visibility],[Date1904]) SELECT [SheetOrdinal],[SheetName],[Visibility],[Date1904] FROM #tbx_ListXlsxWorksheets_ResultSource;';
        EXEC sys.sp_executesql @SheetsSql;
        IF @SheetsOwnTransaction=1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @SheetsOwnTransaction=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
        ELSE IF @SheetsSavepointSet=1 AND XACT_STATE()=1 ROLLBACK TRANSACTION @SheetsSavepoint;
        THROW;
    END CATCH;
    RETURN 0;

    END
    ELSE
    BEGIN
    CREATE TABLE #tbx_ReadXlsxWorksheetCells_ResultSource
    (
        [RowOrdinal] int NOT NULL,
        [ColumnOrdinal] int NOT NULL,
        [StoredType] nvarchar(16) COLLATE Latin1_General_100_BIN2 NOT NULL,
        [ValuePresent] bit NOT NULL,
        [RawValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [TextValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [FormulaPresent] bit NOT NULL,
        [FormulaText] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [FormulaKind] nvarchar(16) COLLATE Latin1_General_100_BIN2 NULL,
        [SharedFormulaIndex] int NULL,
        [CachePresent] bit NOT NULL,
        [CacheValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL
    );
    IF @XlsxBinary IS NULL
    BEGIN
        IF @ResultTable IS NULL SELECT [RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue] FROM #tbx_ReadXlsxWorksheetCells_ResultSource;
        RETURN 0;
    END;
    IF OBJECT_ID(N'toolbelt_file.TVF_InternalXlsxCells',N'FT') IS NULL
        THROW 51529,N'Der interne XLSX-Provider fehlt.',1;
    DECLARE @CellsSnapshot TABLE
    (ErrorNumber int NULL, ErrorMessage nvarchar(4000) NULL,
        [RowOrdinal] int NULL,
        [ColumnOrdinal] int NULL,
        [StoredType] nvarchar(16) COLLATE Latin1_General_100_BIN2 NULL,
        [ValuePresent] bit NULL,
        [RawValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [TextValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [FormulaPresent] bit NULL,
        [FormulaText] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [FormulaKind] nvarchar(16) COLLATE Latin1_General_100_BIN2 NULL,
        [SharedFormulaIndex] int NULL,
        [CachePresent] bit NULL,
        [CacheValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL
    );
    INSERT @CellsSnapshot SELECT ErrorNumber,ErrorMessage,[RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue]
    FROM toolbelt_file.TVF_InternalXlsxCells(@XlsxBinary,@SheetOrdinal,@MaxArchiveBytes,@MaxPartBytes,@MaxTotalUncompressedBytes,@MaxParts,@MaxSheets,@MaxCells,@MaxSharedStrings,@MaxSharedStringBytes,@MaxXmlDepth,@MaxCompressionRatio,@BudgetMilliseconds);
    IF EXISTS(SELECT 1 FROM @CellsSnapshot WHERE ErrorNumber IS NOT NULL)
    BEGIN
        IF (SELECT COUNT_BIG(*) FROM @CellsSnapshot)<>1
            THROW 51529,N'Inkonsistenter XLSX-Statusvertrag.',1;
        DECLARE @CellsError int,@CellsMessage nvarchar(2048);
        SELECT @CellsError=ErrorNumber,@CellsMessage=CONVERT(nvarchar(2048),ErrorMessage) FROM @CellsSnapshot;
        IF @CellsError<>51520 OR @CellsMessage IS NULL
            THROW 51529,N'Ungültiger XLSX-Statusvertrag.',1;
        THROW @CellsError,@CellsMessage,1;
    END;
    IF EXISTS(SELECT 1 FROM @CellsSnapshot WHERE [RowOrdinal] IS NULL OR [ColumnOrdinal] IS NULL OR [StoredType] IS NULL OR [ValuePresent] IS NULL OR [FormulaPresent] IS NULL OR [CachePresent] IS NULL)
        THROW 51529,N'Unvollständige XLSX-Datenzeile.',1;
    INSERT #tbx_ReadXlsxWorksheetCells_ResultSource([RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue]) SELECT [RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue] FROM @CellsSnapshot;
    IF @Debug>0 RAISERROR(N'XLSX: validierter Ergebnissnapshot bereit.',10,1) WITH NOWAIT;
    IF @ResultTable IS NULL
    BEGIN
        SELECT [RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue] FROM #tbx_ReadXlsxWorksheetCells_ResultSource ORDER BY RowOrdinal,ColumnOrdinal;
        RETURN 0;
    END;
    DECLARE @CellsDependencyVersion nvarchar(64),@CellsDependencyId int=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P');
    SELECT @CellsDependencyVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties
    WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
    DECLARE @CellsMajor int=TRY_CONVERT(int,PARSENAME(@CellsDependencyVersion,3)),
            @CellsMinor int=TRY_CONVERT(int,PARSENAME(@CellsDependencyVersion,2)),
            @CellsPatch int=TRY_CONVERT(int,PARSENAME(@CellsDependencyVersion,1));
    IF @CellsDependencyId IS NULL OR @CellsMajor IS NULL OR @CellsMajor<1 OR @CellsMinor IS NULL OR @CellsMinor<0 OR @CellsPatch IS NULL OR @CellsPatch<0
       OR CONVERT(varbinary(max),@CellsDependencyVersion)<>CONVERT(varbinary(max),CONCAT(@CellsMajor,N'.',@CellsMinor,N'.',@CellsPatch))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@CellsDependencyId AND minor_id=0
           AND name=N'Toolbelt.ModuleId' AND TRY_CONVERT(nvarchar(128),value)=N'toolbelt.core.result-table')
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@CellsDependencyId AND minor_id=0
           AND name=N'Toolbelt.ModuleVersion'
           AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@CellsDependencyVersion))
        THROW 51529,N'ResultTable-Dependency >= 1.0.0 fehlt oder ist ungeeignet.',1;
    DECLARE @CellsOwnTransaction bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,
            @CellsSavepoint varchar(32)=REPLACE(CONVERT(varchar(36),NEWID()),'-',''),@CellsSavepointSet bit=0;
    BEGIN TRY
        IF @CellsOwnTransaction=1 BEGIN TRANSACTION;
        ELSE BEGIN SAVE TRANSACTION @CellsSavepoint; SET @CellsSavepointSet=1; END;
        EXEC toolbelt_core.USP_PrepareResultTable
             @ResultTableToAlter=@ResultTable,@LikeTable=N'#tbx_ReadXlsxWorksheetCells_ResultSource',
             @KeepData=@KeepData,@Debug=@Debug;
        DECLARE @CellsSql nvarchar(max)=N'INSERT INTO '+QUOTENAME(@ResultTable)
           +N' ([RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue]) SELECT [RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue] FROM #tbx_ReadXlsxWorksheetCells_ResultSource;';
        EXEC sys.sp_executesql @CellsSql;
        IF @CellsOwnTransaction=1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @CellsOwnTransaction=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
        ELSE IF @CellsSavepointSet=1 AND XACT_STATE()=1 ROLLBACK TRANSACTION @CellsSavepoint;
        THROW;
    END CATCH;
    RETURN 0;

    END;
END;
GO
-- ============================================================================
-- Objekt: toolbelt_file.USP_ListXlsxWorksheets
-- Typ: Stored Procedure
-- Zweck: Worksheetliste mit Workbook-Reihenfolge, Visibility und Date1904.
-- Vertrag: USP_CONTRACT 1.0; Documentation/USP_ListXlsxWorksheets.md
-- Parameter: @XlsxBinary varbinary(max)=NULL;
--   @MaxArchiveBytes bigint=16777216; @MaxPartBytes bigint=16777216;
--   @MaxTotalUncompressedBytes bigint=67108864; @MaxParts int=256;
--   @MaxSheets int=32; @MaxCells int=100000; @MaxSharedStrings int=50000;
--   @MaxSharedStringBytes bigint=8388608; @MaxXmlDepth int=64;
--   @MaxCompressionRatio decimal(18,4)=200; @BudgetMilliseconds int=5000;
--   @ResultTable sysname=NULL; @KeepData bit=0; @Debug tinyint=0; @Hilfe bit=0.
-- Resultset: SheetOrdinal int, SheetName nvarchar(max), Visibility nvarchar(16), Date1904 bit;
--   alle Spalten NOT NULL.
-- Dependencies: toolbelt.file.xlsx-memory 1.0.0 / SAFE CLR;
--   toolbelt.archive.zip-memory >=1.4.0; ResultTable-Helper >=1.0.0.
-- Rechte: EXECUTE auf USP; bei ResultTable zusätzlich Helper-EXECUTE.
-- Versionen: SQL Server 2019, 2022, 2025. Plattformen: Windows/Linux, SAFE CLR.
-- Fehlerverhalten: 51520 erwarteter Parser-/Input-/Limitfehler, 51529 Provider-/Dependencyfehler.
--   Keine Teilausgabe; Mutationsscope eigene Transaktion oder Caller-Savepoint.
--   Uncommittable Caller wird nicht zurückgerollt; ursprüngliche Enginefehler bleiben erhalten.
-- Performance: Input/Parts/gewählter Output werden materialisiert, keine Streaming- oder
--   SQL-Memory-Grant-Zusage. Reduzierbare Limits, kooperatives Budget, keine harte Wallclock.
-- Einschränkungen: Transitional XLSX, keine externen Beziehungen/ZIP64/Makros/Dateizugriffe,
--   Styles-/Datums-/Cultureinferenz oder Formelberechnung. NULL-Binary ist früher No-op.
-- ============================================================================
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE toolbelt_file.USP_ListXlsxWorksheets
(
    @XlsxBinary varbinary(max) = NULL,
    @MaxArchiveBytes bigint = 16777216,
    @MaxPartBytes bigint = 16777216,
    @MaxTotalUncompressedBytes bigint = 67108864,
    @MaxParts int = 256,
    @MaxSheets int = 32,
    @MaxCells int = 100000,
    @MaxSharedStrings int = 50000,
    @MaxSharedStringBytes bigint = 8388608,
    @MaxXmlDepth int = 64,
    @MaxCompressionRatio decimal(18,4) = 200,
    @BudgetMilliseconds int = 5000,
    @ResultTable sysname = NULL,
    @KeepData bit = 0,
    @Debug tinyint = 0,
    @Hilfe bit = 0
)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0),@Hilfe=COALESCE(@Hilfe,0);
    IF @Hilfe=1
    BEGIN
        -- API_PARAMETER_HELP:BEGIN
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
            CAST(N'toolbelt_file' AS sysname) AS SchemaName,
            CAST(N'USP_ListXlsxWorksheets' AS sysname) AS ObjectName,
            CAST(v.Section AS varchar(32)) AS Section, CAST(v.Ordinal AS int) AS Ordinal,
            CAST(v.ItemName AS sysname) AS ItemName, CAST(v.SqlDataType AS varchar(256)) AS SqlDataType,
            CAST(v.IsRequired AS bit) AS IsRequired, CAST(v.IsNullable AS bit) AS IsNullable,
            CAST(v.DefaultValue AS nvarchar(4000)) AS DefaultValue,
            CAST(v.Description AS nvarchar(max)) AS Description,
            CAST(v.ExampleSql AS nvarchar(max)) AS ExampleSql
        FROM (VALUES
        (N'DESCRIPTION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Begrenzter SAFE Binary-XLSX-Reader; atomarer gewählter Snapshot, keine Datei-/Netzwerkzugriffe, Formelberechnung oder Typinferenz.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 1, N'SheetOrdinal', N'int', 1, 0, NULL, CAST(N'Einsbasierte Workbook-Reihenfolge.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 2, N'SheetName', N'nvarchar(max)', 1, 0, NULL, CAST(N'Unveränderter Worksheetname.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 3, N'Visibility', N'nvarchar(16)', 1, 0, NULL, CAST(N'visible, hidden oder veryHidden.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 4, N'Date1904', N'bit', 1, 0, NULL, CAST(N'Workbook-Datumsmodus; keine Datumsumrechnung.' AS nvarchar(max)), NULL),
        (N'ERROR', 1, N'51520', NULL, NULL, NULL, NULL, CAST(N'Begrenzte Kategorie eines erwarteten Input-/Container-/XML-/Feature-/Ressourcenfehlers; keine Teilausgabe.' AS nvarchar(max)), NULL),
        (N'ERROR', 2, N'51529', NULL, NULL, NULL, NULL, CAST(N'Fehlende oder inkonsistente registrierte Dependency bzw. interner Providervertrag.' AS nvarchar(max)), NULL),
        (N'PERMISSION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'EXECUTE auf USP; ResultTable zusätzlich Helper-EXECUTE und Sichtbarkeit der caller-lokalen Tabelle. Keine Rechteausweitung.' AS nvarchar(max)), NULL),
        (N'LIMITATION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Transitional XLSX, klassische Stored-/Deflate-ZIPs. Kein ZIP64, externe Beziehungen, Makros oder Strict Open XML. Unicode bleibt unverändert, Tabellen brauchen explizite Ordinals zum Sortieren.' AS nvarchar(max)), NULL),
        (N'EXAMPLE', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Listet die Sheets eines vom Caller bereitgestellten synthetischen XLSX-Binarys.' AS nvarchar(max)), CAST(N'EXEC toolbelt_file.USP_ListXlsxWorksheets @XlsxBinary=@SyntheticWorkbook;' AS nvarchar(max))),
        (N'PARAMETER', 1, N'@XlsxBinary', N'varbinary(max)', 0, 1, N'NULL', CAST(N'Vollständiger XLSX-Bytepuffer varbinary(max), kein Pfad/Base64text. Unterstützt Transitional-XLSX mit kanonischen Stored-/Deflate-ZIP-Parts, sicheren lokalen Relationships und XML ohne DTD/externe Auflösung; keine XLS/XLSB-/verschlüsselten Workbooks oder Makroausführung. Leer ist ungültig. NULL (Default) liefert keine Zeilen vor Sheet-/Limit-/Dependency-/Zielprüfung und lässt ResultTable unverändert.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 2, N'@MaxArchiveBytes', N'bigint', 0, 0, N'16777216', CAST(N'Ganzzahl 1..16777216, Default 16777216: komprimierte Bytes des vollständigen XLSX-Inputs. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 3, N'@MaxPartBytes', N'bigint', 0, 0, N'16777216', CAST(N'Ganzzahl 1..16777216, Default 16777216: unkomprimierte Bytes je ZIP-/XML-Part. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 4, N'@MaxTotalUncompressedBytes', N'bigint', 0, 0, N'67108864', CAST(N'Ganzzahl 1..67108864, Default 67108864: globale unkomprimierte ZIP-/Partbytes; zusätzliche gezählte XML-Materialisierung bleibt begrenzt. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 5, N'@MaxParts', N'int', 0, 0, N'256', CAST(N'Ganzzahl 1..256, Default 256: ZIP-Parts einschließlich nicht als Zelloutput gewählter Einträge. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 6, N'@MaxSheets', N'int', 0, 0, N'32', CAST(N'Ganzzahl 1..32, Default 32: Worksheet-Metadaten im Workbook, nicht nur der ausgewählte Sheet. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 7, N'@MaxCells', N'int', 0, 0, N'100000', CAST(N'Ganzzahl 1..100000, Default 100000: vorhandene sparse Zellen des gelesenen Worksheets; keine aufgefüllten Rechteckzellen. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 8, N'@MaxSharedStrings', N'int', 0, 0, N'50000', CAST(N'Ganzzahl 1..50000, Default 50000: Einträge der Shared-String-Tabelle. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 9, N'@MaxSharedStringBytes', N'bigint', 0, 0, N'8388608', CAST(N'Ganzzahl 1..8388608, Default 8388608: decodierte UTF-16-Bytes der Shared-String-Texte, nicht komprimierte XML-Bytes. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 10, N'@MaxXmlDepth', N'int', 0, 0, N'64', CAST(N'Ganzzahl 1..64, Default 64: XmlReader-Tiefe; XML-Root hat Depth 0. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 11, N'@MaxCompressionRatio', N'decimal(18,4)', 0, 0, N'200', CAST(N'decimal(18,4) im inklusiven Bereich 1..200, Default 200. Deklarierte Uncompressed-/Compressed-Byte-Ratio der ZIP-Einträge; Bruchteile sind zulässig. NULL/<1/>200 ungültig bei nicht-NULL-Binary. Kein Prozentsatz und keine globale Heapgarantie.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 12, N'@BudgetMilliseconds', N'int', 0, 0, N'5000', CAST(N'Ganzzahl 1..5000, Default 5000: Millisekunden kooperatives Verarbeitungsbudget; keine harte SQL-Marshalling-/Gesamtwallclock-Garantie. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 13, N'@ResultTable', N'sysname', 0, 1, N'NULL', CAST(N'NULL (Default) liefert den fachlichen SELECT-Resultset. Sonst ein einzelner sysname mit 2..116 UTF-16-Einheiten einschließlich führendem # als Name einer bereits im Caller-Scope angelegten lokalen #Temp-Tabelle, z.B. N''#Result''; keine globale ##Temp, persistente oder mehrteilige Tabelle. Der ResultTable-Helper muss verfügbar sein; die Ausgabeform wird anhand des konkreten Objektresultsets vorbereitet. Kein #tbx_-Präfix. XlsxBinary=NULL lässt das Ziel vollständig unverändert und prüft es nicht.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 14, N'@KeepData', N'bit', 0, 1, N'0', CAST(N'Taxativ für bit: 0 ersetzt Ergebnisdaten (Default), 1 hängt bei kompatibler ResultTable an; NULL entspricht 0. Nur bei nicht-NULL ResultTable relevant; Schema- und Datenbehandlung folgen dem kanonischen ResultTable-Vertrag.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 15, N'@Debug', N'tinyint', 0, 1, N'0', CAST(N'tinyint 0..255: 0 (Default) oder NULL ohne Diagnose; 1..255 aktiviert die im Objekt beschriebenen abstrakten Diagnose-Messages, ohne zusätzlichen fachlichen Resultset. Keine Workbookinhalte; im Zielpfad zusätzlich Helperdiagnose.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 16, N'@Hilfe', N'bit', 0, 1, N'0', CAST(N'Taxativ für bit: 1 liefert nur die Standardhilfe vor der Fachvalidierung; 0 (Default) führt den Fachaufruf aus. NULL wird wie 0 behandelt. Syntaktisch erforderliche Argumente ohne technischen Default müssen auch beim Help-Aufruf angegeben werden.' AS nvarchar(max)), NULL)
        ) AS v(Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql)
        ORDER BY CASE v.Section WHEN 'DESCRIPTION' THEN 0 WHEN 'PARAMETER' THEN 1
            WHEN 'RESULT_COLUMN' THEN 2 WHEN 'EXAMPLE' THEN 3 ELSE 4 END, v.Ordinal;
        RETURN 0;
        -- API_PARAMETER_HELP:END
    END;
    -- NULL und Namespaceprüfung liegen vor der separaten Compilergrenze.
    IF @XlsxBinary IS NULL
    BEGIN
        -- Tablevariable hält auch bei null Zeilen die genaue Result-Nullability;
        -- keine private Temptabelle oder fachliche Core-Kompilierung entsteht.
        DECLARE @Empty TABLE ([SheetOrdinal] int NOT NULL,[SheetName] nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL,[Visibility] nvarchar(16) COLLATE Latin1_General_100_BIN2 NOT NULL,[Date1904] bit NOT NULL);
        IF @ResultTable IS NULL SELECT [SheetOrdinal],[SheetName],[Visibility],[Date1904] FROM @Empty;
        RETURN 0;
    END;
    IF (@ResultTable IS NOT NULL AND LOWER(LEFT(@ResultTable COLLATE Latin1_General_100_BIN2,5))=N'#tbx_')
       OR OBJECT_ID(N'tempdb..#tbx_ListXlsxWorksheets_ResultSource') IS NOT NULL
       OR OBJECT_ID(N'tempdb..#tbx_ReadXlsxWorksheetCells_ResultSource') IS NOT NULL
        THROW 51520,N'Reservierter interner XLSX-Tempnamensbereich.',1;
    -- Fachliche Tempstatements werden erst hinter dieser EXEC-Grenze kompiliert.
    EXEC toolbelt_file.USP_InternalXlsxRead @ReadCells=0,
         @XlsxBinary=@XlsxBinary,
         @MaxArchiveBytes=@MaxArchiveBytes,
         @MaxPartBytes=@MaxPartBytes,
         @MaxTotalUncompressedBytes=@MaxTotalUncompressedBytes,
         @MaxParts=@MaxParts,
         @MaxSheets=@MaxSheets,
         @MaxCells=@MaxCells,
         @MaxSharedStrings=@MaxSharedStrings,
         @MaxSharedStringBytes=@MaxSharedStringBytes,
         @MaxXmlDepth=@MaxXmlDepth,
         @MaxCompressionRatio=@MaxCompressionRatio,
         @BudgetMilliseconds=@BudgetMilliseconds,
         @ResultTable=@ResultTable,
         @KeepData=@KeepData,
         @Debug=@Debug,@SheetOrdinal=NULL;
    RETURN 0;
END;
GO
-- ============================================================================
-- Objekt: toolbelt_file.USP_ReadXlsxWorksheetCells
-- Typ: Stored Procedure
-- Zweck: Sparse vorhandene Zellen mit Rohtext, aufgelöstem Stringtext, Formel und Cache.
-- Vertrag: USP_CONTRACT 1.0; Documentation/USP_ReadXlsxWorksheetCells.md
-- Parameter: @XlsxBinary varbinary(max)=NULL, @SheetOrdinal int=NULL;
--   @MaxArchiveBytes bigint=16777216; @MaxPartBytes bigint=16777216;
--   @MaxTotalUncompressedBytes bigint=67108864; @MaxParts int=256;
--   @MaxSheets int=32; @MaxCells int=100000; @MaxSharedStrings int=50000;
--   @MaxSharedStringBytes bigint=8388608; @MaxXmlDepth int=64;
--   @MaxCompressionRatio decimal(18,4)=200; @BudgetMilliseconds int=5000;
--   @ResultTable sysname=NULL; @KeepData bit=0; @Debug tinyint=0; @Hilfe bit=0.
-- Resultset: RowOrdinal int, ColumnOrdinal int, StoredType nvarchar(16), ValuePresent bit,
--   RawValue/TextValue nvarchar(max) NULL, FormulaPresent bit, FormulaText nvarchar(max) NULL,
--   FormulaKind nvarchar(16) NULL, SharedFormulaIndex int NULL, CachePresent bit,
--   CacheValue nvarchar(max) NULL; übrige Spalten NOT NULL.
-- Dependencies: toolbelt.file.xlsx-memory 1.0.0 / SAFE CLR;
--   toolbelt.archive.zip-memory >=1.4.0; ResultTable-Helper >=1.0.0.
-- Rechte: EXECUTE auf USP; bei ResultTable zusätzlich Helper-EXECUTE.
-- Versionen: SQL Server 2019, 2022, 2025. Plattformen: Windows/Linux, SAFE CLR.
-- Fehlerverhalten: 51520 erwarteter Parser-/Input-/Limitfehler, 51529 Provider-/Dependencyfehler.
--   Keine Teilausgabe; Mutationsscope eigene Transaktion oder Caller-Savepoint.
--   Uncommittable Caller wird nicht zurückgerollt; ursprüngliche Enginefehler bleiben erhalten.
-- Performance: Input/Parts/gewählter Output werden materialisiert, keine Streaming- oder
--   SQL-Memory-Grant-Zusage. Reduzierbare Limits, kooperatives Budget, keine harte Wallclock.
-- Einschränkungen: Transitional XLSX, keine externen Beziehungen/ZIP64/Makros/Dateizugriffe,
--   Styles-/Datums-/Cultureinferenz oder Formelberechnung. NULL-Binary ist früher No-op.
-- ============================================================================
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE toolbelt_file.USP_ReadXlsxWorksheetCells
(
    @XlsxBinary varbinary(max) = NULL,
    @SheetOrdinal int = NULL,
    @MaxArchiveBytes bigint = 16777216,
    @MaxPartBytes bigint = 16777216,
    @MaxTotalUncompressedBytes bigint = 67108864,
    @MaxParts int = 256,
    @MaxSheets int = 32,
    @MaxCells int = 100000,
    @MaxSharedStrings int = 50000,
    @MaxSharedStringBytes bigint = 8388608,
    @MaxXmlDepth int = 64,
    @MaxCompressionRatio decimal(18,4) = 200,
    @BudgetMilliseconds int = 5000,
    @ResultTable sysname = NULL,
    @KeepData bit = 0,
    @Debug tinyint = 0,
    @Hilfe bit = 0
)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0),@Hilfe=COALESCE(@Hilfe,0);
    IF @Hilfe=1
    BEGIN
        -- API_PARAMETER_HELP:BEGIN
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
            CAST(N'toolbelt_file' AS sysname) AS SchemaName,
            CAST(N'USP_ReadXlsxWorksheetCells' AS sysname) AS ObjectName,
            CAST(v.Section AS varchar(32)) AS Section, CAST(v.Ordinal AS int) AS Ordinal,
            CAST(v.ItemName AS sysname) AS ItemName, CAST(v.SqlDataType AS varchar(256)) AS SqlDataType,
            CAST(v.IsRequired AS bit) AS IsRequired, CAST(v.IsNullable AS bit) AS IsNullable,
            CAST(v.DefaultValue AS nvarchar(4000)) AS DefaultValue,
            CAST(v.Description AS nvarchar(max)) AS Description,
            CAST(v.ExampleSql AS nvarchar(max)) AS ExampleSql
        FROM (VALUES
        (N'DESCRIPTION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Begrenzter SAFE Binary-XLSX-Reader; atomarer gewählter Snapshot, keine Datei-/Netzwerkzugriffe, Formelberechnung oder Typinferenz.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 1, N'RowOrdinal', N'int', 1, 0, NULL, CAST(N'Einsbasierte Zeile.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 2, N'ColumnOrdinal', N'int', 1, 0, NULL, CAST(N'Einsbasierte Spalte.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 3, N'StoredType', N'nvarchar(16)', 1, 0, NULL, CAST(N'Gespeicherter Zelltyp, keine Typinferenz.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 4, N'ValuePresent', N'bit', 1, 0, NULL, CAST(N'Gespeichertes v-Element vorhanden, auch wenn leer.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 5, N'RawValue', N'nvarchar(max)', 1, 1, NULL, CAST(N'Rohtext aus v, NULL bei fehlendem v.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 6, N'TextValue', N'nvarchar(max)', 1, 1, NULL, CAST(N'Shared-/Inline-/str-Text, kein Excel-Anzeigeformat.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 7, N'FormulaPresent', N'bit', 1, 0, NULL, CAST(N'f-Element vorhanden.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 8, N'FormulaText', N'nvarchar(max)', 1, 1, NULL, CAST(N'Unveränderter Formeltext, keine Berechnung.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 9, N'FormulaKind', N'nvarchar(16)', 1, 1, NULL, CAST(N'normal, shared, array oder dataTable.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 10, N'SharedFormulaIndex', N'int', 1, 1, NULL, CAST(N'Gespeichertes si, keine Formelrekonstruktion.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 11, N'CachePresent', N'bit', 1, 0, NULL, CAST(N'Formel und v-Element vorhanden.' AS nvarchar(max)), NULL),
        (N'RESULT_COLUMN', 12, N'CacheValue', N'nvarchar(max)', 1, 1, NULL, CAST(N'Gespeicherter Formelcache-Rohtext.' AS nvarchar(max)), NULL),
        (N'ERROR', 1, N'51520', NULL, NULL, NULL, NULL, CAST(N'Begrenzte Kategorie eines erwarteten Input-/Container-/XML-/Feature-/Ressourcenfehlers; keine Teilausgabe.' AS nvarchar(max)), NULL),
        (N'ERROR', 2, N'51529', NULL, NULL, NULL, NULL, CAST(N'Fehlende oder inkonsistente registrierte Dependency bzw. interner Providervertrag.' AS nvarchar(max)), NULL),
        (N'PERMISSION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'EXECUTE auf USP; ResultTable zusätzlich Helper-EXECUTE und Sichtbarkeit der caller-lokalen Tabelle. Keine Rechteausweitung.' AS nvarchar(max)), NULL),
        (N'LIMITATION', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Transitional XLSX, klassische Stored-/Deflate-ZIPs. Kein ZIP64, externe Beziehungen, Makros oder Strict Open XML. Unicode bleibt unverändert, Tabellen brauchen explizite Ordinals zum Sortieren.' AS nvarchar(max)), NULL),
        (N'EXAMPLE', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'Liest sparse Zellen aus Sheet 1 eines vom Caller bereitgestellten synthetischen XLSX-Binarys.' AS nvarchar(max)), CAST(N'EXEC toolbelt_file.USP_ReadXlsxWorksheetCells @XlsxBinary=@SyntheticWorkbook,@SheetOrdinal=1;' AS nvarchar(max))),
        (N'PARAMETER', 1, N'@XlsxBinary', N'varbinary(max)', 0, 1, N'NULL', CAST(N'Vollständiger XLSX-Bytepuffer varbinary(max), kein Pfad/Base64text. Unterstützt Transitional-XLSX mit kanonischen Stored-/Deflate-ZIP-Parts, sicheren lokalen Relationships und XML ohne DTD/externe Auflösung; keine XLS/XLSB-/verschlüsselten Workbooks oder Makroausführung. Leer ist ungültig. NULL (Default) liefert keine Zeilen vor Sheet-/Limit-/Dependency-/Zielprüfung und lässt ResultTable unverändert.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 2, N'@SheetOrdinal', N'int', 1, 0, N'NULL', CAST(N'Fachlich erforderliche positive int-Worksheetnummer aus USP_ListXlsxWorksheets, 1-basiert in Workbookreihenfolge; keine SheetId, kein Name und keine nullbasierte Position. Muss tatsächlich existieren. NULL (technischer Default)/0/negativ ungültig bei nicht-NULL-XlsxBinary; bei NULL-Binary ignoriert.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 3, N'@MaxArchiveBytes', N'bigint', 0, 0, N'16777216', CAST(N'Ganzzahl 1..16777216, Default 16777216: komprimierte Bytes des vollständigen XLSX-Inputs. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 4, N'@MaxPartBytes', N'bigint', 0, 0, N'16777216', CAST(N'Ganzzahl 1..16777216, Default 16777216: unkomprimierte Bytes je ZIP-/XML-Part. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 5, N'@MaxTotalUncompressedBytes', N'bigint', 0, 0, N'67108864', CAST(N'Ganzzahl 1..67108864, Default 67108864: globale unkomprimierte ZIP-/Partbytes; zusätzliche gezählte XML-Materialisierung bleibt begrenzt. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 6, N'@MaxParts', N'int', 0, 0, N'256', CAST(N'Ganzzahl 1..256, Default 256: ZIP-Parts einschließlich nicht als Zelloutput gewählter Einträge. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 7, N'@MaxSheets', N'int', 0, 0, N'32', CAST(N'Ganzzahl 1..32, Default 32: Worksheet-Metadaten im Workbook, nicht nur der ausgewählte Sheet. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 8, N'@MaxCells', N'int', 0, 0, N'100000', CAST(N'Ganzzahl 1..100000, Default 100000: vorhandene sparse Zellen des gelesenen Worksheets; keine aufgefüllten Rechteckzellen. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 9, N'@MaxSharedStrings', N'int', 0, 0, N'50000', CAST(N'Ganzzahl 1..50000, Default 50000: Einträge der Shared-String-Tabelle. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 10, N'@MaxSharedStringBytes', N'bigint', 0, 0, N'8388608', CAST(N'Ganzzahl 1..8388608, Default 8388608: decodierte UTF-16-Bytes der Shared-String-Texte, nicht komprimierte XML-Bytes. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 11, N'@MaxXmlDepth', N'int', 0, 0, N'64', CAST(N'Ganzzahl 1..64, Default 64: XmlReader-Tiefe; XML-Root hat Depth 0. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 12, N'@MaxCompressionRatio', N'decimal(18,4)', 0, 0, N'200', CAST(N'decimal(18,4) im inklusiven Bereich 1..200, Default 200. Deklarierte Uncompressed-/Compressed-Byte-Ratio der ZIP-Einträge; Bruchteile sind zulässig. NULL/<1/>200 ungültig bei nicht-NULL-Binary. Kein Prozentsatz und keine globale Heapgarantie.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 13, N'@BudgetMilliseconds', N'int', 0, 0, N'5000', CAST(N'Ganzzahl 1..5000, Default 5000: Millisekunden kooperatives Verarbeitungsbudget; keine harte SQL-Marshalling-/Gesamtwallclock-Garantie. Explizites NULL/0/negativ/höher ungültig bei nicht-NULL-XlsxBinary. Nur absenkbar; ein früher NULL-Binary-Pfad überspringt die Prüfung.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 14, N'@ResultTable', N'sysname', 0, 1, N'NULL', CAST(N'NULL (Default) liefert den fachlichen SELECT-Resultset. Sonst ein einzelner sysname mit 2..116 UTF-16-Einheiten einschließlich führendem # als Name einer bereits im Caller-Scope angelegten lokalen #Temp-Tabelle, z.B. N''#Result''; keine globale ##Temp, persistente oder mehrteilige Tabelle. Der ResultTable-Helper muss verfügbar sein; die Ausgabeform wird anhand des konkreten Objektresultsets vorbereitet. Kein #tbx_-Präfix. XlsxBinary=NULL lässt das Ziel vollständig unverändert und prüft es nicht.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 15, N'@KeepData', N'bit', 0, 1, N'0', CAST(N'Taxativ für bit: 0 ersetzt Ergebnisdaten (Default), 1 hängt bei kompatibler ResultTable an; NULL entspricht 0. Nur bei nicht-NULL ResultTable relevant; Schema- und Datenbehandlung folgen dem kanonischen ResultTable-Vertrag.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 16, N'@Debug', N'tinyint', 0, 1, N'0', CAST(N'tinyint 0..255: 0 (Default) oder NULL ohne Diagnose; 1..255 aktiviert die im Objekt beschriebenen abstrakten Diagnose-Messages, ohne zusätzlichen fachlichen Resultset. Keine Workbookinhalte; im Zielpfad zusätzlich Helperdiagnose.' AS nvarchar(max)), NULL),
        (N'PARAMETER', 17, N'@Hilfe', N'bit', 0, 1, N'0', CAST(N'Taxativ für bit: 1 liefert nur die Standardhilfe vor der Fachvalidierung; 0 (Default) führt den Fachaufruf aus. NULL wird wie 0 behandelt. Syntaktisch erforderliche Argumente ohne technischen Default müssen auch beim Help-Aufruf angegeben werden.' AS nvarchar(max)), NULL)
        ) AS v(Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql)
        ORDER BY CASE v.Section WHEN 'DESCRIPTION' THEN 0 WHEN 'PARAMETER' THEN 1
            WHEN 'RESULT_COLUMN' THEN 2 WHEN 'EXAMPLE' THEN 3 ELSE 4 END, v.Ordinal;
        RETURN 0;
        -- API_PARAMETER_HELP:END
    END;
    -- NULL und Namespaceprüfung liegen vor der separaten Compilergrenze.
    IF @XlsxBinary IS NULL
    BEGIN
        -- Tablevariable hält auch bei null Zeilen die genaue Result-Nullability;
        -- keine private Temptabelle oder fachliche Core-Kompilierung entsteht.
        DECLARE @Empty TABLE ([RowOrdinal] int NOT NULL,[ColumnOrdinal] int NOT NULL,[StoredType] nvarchar(16) COLLATE Latin1_General_100_BIN2 NOT NULL,[ValuePresent] bit NOT NULL,[RawValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,[TextValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,[FormulaPresent] bit NOT NULL,[FormulaText] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,[FormulaKind] nvarchar(16) COLLATE Latin1_General_100_BIN2 NULL,[SharedFormulaIndex] int NULL,[CachePresent] bit NOT NULL,[CacheValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL);
        IF @ResultTable IS NULL SELECT [RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue] FROM @Empty;
        RETURN 0;
    END;
    IF (@ResultTable IS NOT NULL AND LOWER(LEFT(@ResultTable COLLATE Latin1_General_100_BIN2,5))=N'#tbx_')
       OR OBJECT_ID(N'tempdb..#tbx_ListXlsxWorksheets_ResultSource') IS NOT NULL
       OR OBJECT_ID(N'tempdb..#tbx_ReadXlsxWorksheetCells_ResultSource') IS NOT NULL
        THROW 51520,N'Reservierter interner XLSX-Tempnamensbereich.',1;
    -- Fachliche Tempstatements werden erst hinter dieser EXEC-Grenze kompiliert.
    EXEC toolbelt_file.USP_InternalXlsxRead @ReadCells=1,
         @XlsxBinary=@XlsxBinary,
         @SheetOrdinal=@SheetOrdinal,
         @MaxArchiveBytes=@MaxArchiveBytes,
         @MaxPartBytes=@MaxPartBytes,
         @MaxTotalUncompressedBytes=@MaxTotalUncompressedBytes,
         @MaxParts=@MaxParts,
         @MaxSheets=@MaxSheets,
         @MaxCells=@MaxCells,
         @MaxSharedStrings=@MaxSharedStrings,
         @MaxSharedStringBytes=@MaxSharedStringBytes,
         @MaxXmlDepth=@MaxXmlDepth,
         @MaxCompressionRatio=@MaxCompressionRatio,
         @BudgetMilliseconds=@BudgetMilliseconds,
         @ResultTable=@ResultTable,
         @KeepData=@KeepData,
         @Debug=@Debug;
    RETURN 0;
END;
GO
SET NOCOUNT ON;
BEGIN TRY
 IF @@TRANCOUNT<>1 THROW 51539,N'Deploymenttransaktion fehlt.',1;
 DECLARE @Property sysname,@Value nvarchar(128);
 DECLARE ModuleMarkers CURSOR LOCAL FAST_FORWARD FOR SELECT Name,Value FROM
  (VALUES(N'Toolbelt.Module.toolbelt.file.xlsx-memory.Version',N'1.2.0'),
         (N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode',N'local'))p(Name,Value);
 OPEN ModuleMarkers; FETCH NEXT FROM ModuleMarkers INTO @Property,@Value;
 WHILE @@FETCH_STATUS=0
 BEGIN
  IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=@Property)
   EXEC sys.sp_updateextendedproperty @name=@Property,@value=@Value;
  ELSE EXEC sys.sp_addextendedproperty @name=@Property,@value=@Value;
  FETCH NEXT FROM ModuleMarkers INTO @Property,@Value;
 END;
 CLOSE ModuleMarkers; DEALLOCATE ModuleMarkers;
 DECLARE @Object sysname,@Type varchar(16);
 DECLARE ObjectMarkers CURSOR LOCAL FAST_FORWARD FOR
  SELECT o.name,CASE WHEN o.type=N'P' THEN 'PROCEDURE' ELSE 'FUNCTION' END,p.Name,p.Value
  FROM sys.objects o CROSS APPLY(VALUES(N'Toolbelt.ModuleId',N'toolbelt.file.xlsx-memory'),
     (N'Toolbelt.ModuleVersion',N'1.2.0'),
     (N'Toolbelt.Visibility',CASE WHEN o.name IN(N'USP_ListXlsxWorksheets',N'USP_ReadXlsxWorksheetCells',N'TVF_InterpretXlsxCell',N'TVF_FormatXlsxCell') THEN N'public' ELSE N'internal' END))p(Name,Value)
  WHERE o.schema_id=SCHEMA_ID(N'toolbelt_file') AND o.name IN(N'USP_ListXlsxWorksheets',N'USP_ReadXlsxWorksheetCells',N'USP_InternalXlsxRead',N'TVF_InternalXlsxSheets',N'TVF_InternalXlsxCells',N'TVF_InternalInterpretXlsxCell',N'TVF_InterpretXlsxCell',N'TVF_InternalFormatXlsxCell',N'TVF_FormatXlsxCell');
 OPEN ObjectMarkers; FETCH NEXT FROM ObjectMarkers INTO @Object,@Type,@Property,@Value;
 WHILE @@FETCH_STATUS=0
 BEGIN
  IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(@Object)) AND minor_id=0 AND name=@Property)
   EXEC sys.sp_updateextendedproperty @name=@Property,@value=@Value,@level0type=N'SCHEMA',@level0name=N'toolbelt_file',@level1type=@Type,@level1name=@Object;
  ELSE EXEC sys.sp_addextendedproperty @name=@Property,@value=@Value,@level0type=N'SCHEMA',@level0name=N'toolbelt_file',@level1type=@Type,@level1name=@Object;
  FETCH NEXT FROM ObjectMarkers INTO @Object,@Type,@Property,@Value;
 END;
 CLOSE ObjectMarkers; DEALLOCATE ObjectMarkers;
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=(SELECT assembly_id FROM sys.assemblies WHERE name=N'Toolbelt_File_XlsxMemory') AND name=N'Toolbelt.ModuleId')
  EXEC sys.sp_updateextendedproperty @name=N'Toolbelt.ModuleId',@value=N'toolbelt.file.xlsx-memory',@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_File_XlsxMemory';
 ELSE EXEC sys.sp_addextendedproperty @name=N'Toolbelt.ModuleId',@value=N'toolbelt.file.xlsx-memory',@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_File_XlsxMemory';
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.file.xlsx-memory
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
