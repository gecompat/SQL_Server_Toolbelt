# XLSX installieren

Dieses unveröffentlichte Paket umfasst ausschließlich ResultTable 1.0, ZIP Memory 1.4 und XLSX Memory 1.2. Andere Module des historischen CLR-Gesamtpakets sind nicht enthalten.

1. ZIP-SHA256 gegen die benachbarte .sha256-Datei prüfen und in einen eigenen neuen Ordner entpacken.
2. PowerShell 7 und vorhandenes sqlcmd verwenden. Zuerst `./Install-ClrPackage.ps1 -ValidateOnly`.
3. Vorhandene Installationsrechte und verschlüsseltes SQL-Ziel wählen; `clr strict security` bleibt aktiv. CLR-Aktivierung und administrativer exakter Trust sind getrennte Vorbereitungen, keine automatische Rechtevergabe.
4. `./Install-ClrPackage.ps1 -Profile Windows-local -ServerInstance localhost -Database Contoso -Action Install` mit bestehender Anmeldung ausführen. Windows-central sowie Portable-local/central wählen den gleichwertigen Modus; Portable gilt für unterstützte Linux- und Windows-Engines. SQL-Anmeldung erfolgt nur über explizites PSCredential.
5. Repeat verwendet den exakten vorhandenen Assemblyhash. Uninstall/UninstallAbsent verlangen zusätzlich `-ConfirmNoExternalConsumers`; Trust und Dependencies anderer Verbraucher bleiben erhalten. `-RegisterExactTrust` ist ein ausdrückliches administratives Opt-in. Encrypt bleibt Mandatory; `-TrustServerCertificate` ist nur ein bewusster funktionaler Testweg und kein Serveridentitätsnachweis.

Fehlende Rechte, Hashdrift oder unbekannte Verbraucher blockieren; kein Provider-/Trustfallback. Das Paket startet oder repariert keine Labressourcen. Quellen unter Sources sind die Installations-/CLR-Quellclosure, kein vollständiger Entwicklercheckout.

Ergebnis und Grenzen der konkreten Paketbytes stehen im externen [Qualifikationsbericht](https://github.com/gecompat/SQL_Server_Toolbelt/blob/main/Releases/1.0.0/XLSX-NATIVE-PACKAGE-QUALIFICATION.md). Ein vorbereitetes Paket allein ist kein bestandener Test und keine Veröffentlichungsfreigabe.
