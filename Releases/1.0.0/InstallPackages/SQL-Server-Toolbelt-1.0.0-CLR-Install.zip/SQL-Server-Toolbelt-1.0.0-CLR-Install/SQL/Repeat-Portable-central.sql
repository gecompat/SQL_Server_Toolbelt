-- SQL Server Toolbelt: aus aktuellen Modulskripten erzeugtes Deployment.
-- SQLCMD-Modus und Fehlerabbruch erforderlich (sqlcmd -b -f 65001).
-- In frischer exklusiver Verbindung in der gewählten Zieldatenbank ausführen.
-- Keine Gesamttransaktion; frühere erfolgreiche Module bleiben bei Fehlern installiert.
-- Bestehende Versions-/Dependency-/Trust-/Migrationsgates bleiben wirksam.
-- DeploymentMode: central
:ON ERROR EXIT
GO
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.core.result-table
:On Error exit

-- ============================================================================
-- Zweck:     Erst-, Upgrade- und Wiederholungsdeployment
-- Modul:     toolbelt.core.result-table v1.0.0
-- Schema:    toolbelt_core
-- Erfordert: SQL Server 2019, 2022 oder 2025
-- Modus:     SQLCMD; Ausführung aus diesem Deployment-Verzeichnis
-- Parameter: DeploymentMode=local|central
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'tempdb..#tbx_ResultTableReleaseObjects', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_ResultTableReleaseObjects;
END;

IF OBJECT_ID(N'tempdb..#tbx_ResultTableDeployState', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_ResultTableDeployState;
END;

/*
 * Dieses Manifest enthält jedes bekannte Release. Bei einem neuen Release
 * bleiben die Zeilen der unterstützten Vorgänger erhalten. Dadurch kann das
 * Deployment objektgenau unterscheiden zwischen:
 * - bereits zum Framework gehörenden Objekten,
 * - im Zielrelease neu hinzukommenden Namen,
 * - im Zielrelease weggefallenen Framework-Objekten.
 */
CREATE TABLE #tbx_ResultTableReleaseObjects
(
      ReleaseVersion nvarchar(64) NOT NULL
    , SchemaName     sysname      NOT NULL
    , ObjectName     sysname      NOT NULL
    , ObjectType     char(2)      NOT NULL
    , CONSTRAINT PK_tbx_ResultTableReleaseObjects
          PRIMARY KEY (ReleaseVersion, SchemaName, ObjectName)
);

INSERT INTO #tbx_ResultTableReleaseObjects
(
      ReleaseVersion
    , SchemaName
    , ObjectName
    , ObjectType
)
VALUES
(
      N'1.0.0'
    , N'toolbelt_core'
    , N'USP_PrepareResultTable'
    , 'P'
);

CREATE TABLE #tbx_ResultTableDeployState
(
      TargetVersion    nvarchar(64) NOT NULL
    , InstalledVersion nvarchar(64) NULL
    , DeploymentMode   nvarchar(16) NOT NULL
    , SchemaCreated     bit          NOT NULL
);

DECLARE
      @TargetVersion        nvarchar(64)  = N'1.0.0'
    , @DeploymentMode       nvarchar(16)  = LOWER(N'central')
    , @InstalledVersion     nvarchar(64)
    , @VersionPropertyName  sysname =
          N'Toolbelt.Module.toolbelt.core.result-table.Version'
    , @ProductMajorVersion  int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @SchemaId             int = SCHEMA_ID(N'toolbelt_core')
    , @CollisionSchema      sysname
    , @CollisionObject      sysname
    , @LockResult           int
    , @DropSql              nvarchar(max)
    , @SchemaCreated        bit = 0;

IF @ProductMajorVersion NOT IN (15, 16, 17)
BEGIN
    THROW 51030, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
END;

IF @DeploymentMode NOT IN (N'local', N'central')
BEGIN
    THROW 51031, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

IF @InstalledVersion IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM #tbx_ResultTableReleaseObjects AS ro
           WHERE ro.ReleaseVersion COLLATE Latin1_General_100_BIN2
                     = @InstalledVersion COLLATE Latin1_General_100_BIN2
       )
BEGIN
    THROW 51033, N'Die installierte Modulversion ist diesem Deployment nicht als unterstütztes Vorgängerrelease bekannt.', 1;
END;

-- SQLCMD-Preflightfragment, keine dauerhafte Mutation und kein Batchseparator.
-- Nur dbo sowie explizit vertrauenswürdige DBowner-/Installerrollen dürfen
-- das gemeinsame Schema kontrollieren. Fehlende Metadatensicht ist kein PASS.
IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
    THROW 51032,N'Für die Schematrustprüfung fehlt vollständige Datenbank-Metadatensicht.',2;
IF SCHEMA_ID(N'toolbelt_core') IS NOT NULL
   AND (SELECT principal_id FROM sys.schemas WHERE name=N'toolbelt_core')<>1
    THROW 51032,N'Der Owner von toolbelt_core muss dbo sein; kein automatischer Ownertransfer.',2;

DECLARE @tbx_TrustedSchemaPrincipals TABLE(PrincipalId int PRIMARY KEY);
;WITH Trusted AS
(
    SELECT principal_id FROM sys.database_principals
    WHERE principal_id=1 OR (type='R' AND name IN(N'db_owner',N'toolbelt_core_installer'))
    UNION ALL
    SELECT m.member_principal_id FROM sys.database_role_members m JOIN Trusted t ON t.principal_id=m.role_principal_id
)
INSERT @tbx_TrustedSchemaPrincipals SELECT DISTINCT principal_id FROM Trusted OPTION(MAXRECURSION 32);

-- Eine vertrauenswürdige Rolle darf nicht durch einen untrusted Rollenowner
-- verwaltet werden; Rollenname allein ist keine Autorität.
IF EXISTS(SELECT 1 FROM sys.database_principals r
    JOIN @tbx_TrustedSchemaPrincipals t ON t.PrincipalId=r.principal_id
    WHERE r.type='R' AND NOT EXISTS(SELECT 1 FROM @tbx_TrustedSchemaPrincipals owner
        WHERE owner.PrincipalId=r.owning_principal_id))
    THROW 51032,N'Eine vertrauenswürdige Rolle hat einen nicht freigegebenen Owner.',2;

IF EXISTS
(
    SELECT 1 FROM sys.database_permissions p
    WHERE p.state IN('G','W')
      AND NOT EXISTS(SELECT 1 FROM @tbx_TrustedSchemaPrincipals t WHERE t.PrincipalId=p.grantee_principal_id)
      AND
      (
        (p.class=3 AND p.major_id=SCHEMA_ID(N'toolbelt_core') AND p.permission_name IN(N'ALTER',N'CONTROL',N'TAKE OWNERSHIP'))
        OR (p.class=0 AND p.permission_name IN(N'CONTROL',N'ALTER ANY SCHEMA',N'ALTER ANY ROLE',N'IMPERSONATE ANY USER'))
        OR (p.class=4 AND p.permission_name IN(N'CONTROL',N'IMPERSONATE') AND EXISTS
            (SELECT 1 FROM @tbx_TrustedSchemaPrincipals t WHERE t.PrincipalId=p.major_id))
        OR (p.class=1 AND p.major_id=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable') AND p.permission_name IN(N'ALTER',N'CONTROL',N'TAKE OWNERSHIP'))
      )
)
    THROW 51032,N'Nicht freigegebene Principals besitzen Schema- oder Helperkontrollrechte.',2;

-- Feste Rollenrechte stehen nicht vollständig in sys.database_permissions.
IF EXISTS
(
    SELECT 1 FROM sys.database_role_members m JOIN sys.database_principals r ON r.principal_id=m.role_principal_id
    WHERE r.name IN(N'db_ddladmin',N'db_securityadmin')
      AND NOT EXISTS(SELECT 1 FROM @tbx_TrustedSchemaPrincipals t WHERE t.PrincipalId=m.member_principal_id)
)
    THROW 51032,N'Nicht freigegebene DDL-Administrationsmitgliedschaft verhindert die Schematrustfreigabe.',2;

IF @SchemaId IS NULL
BEGIN
    IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    BEGIN
        THROW 51032, N'Zum Anlegen von toolbelt_core fehlt CREATE SCHEMA in der Installationsdatenbank.', 1;
    END;
END;
ELSE IF HAS_PERMS_BY_NAME(N'toolbelt_core', N'SCHEMA', N'ALTER') <> 1
BEGIN
    THROW 51032, N'Für das vorhandene Schema toolbelt_core fehlt ALTER.', 1;
END;

IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE PROCEDURE') <> 1
BEGIN
    THROW 51032, N'In der Installationsdatenbank fehlt CREATE PROCEDURE.', 1;
END;

/*
 * Ein vorhandener Zielname ist nur dann Framework-Bestand, wenn genau dieser
 * Name im bekannten installierten Release enthalten war. Bei einer
 * Erstinstallation oder einem im Zielrelease neuen Namen wird niemals ein
 * bereits vorhandenes fremdes Objekt überschrieben.
 */
SELECT TOP (1)
      @CollisionSchema = t.SchemaName
    , @CollisionObject = t.ObjectName
FROM #tbx_ResultTableReleaseObjects AS t
INNER JOIN sys.schemas AS s
    ON s.name COLLATE Latin1_General_100_BIN2
          = t.SchemaName COLLATE Latin1_General_100_BIN2
INNER JOIN sys.objects AS o
    ON o.schema_id = s.schema_id
   AND o.name COLLATE Latin1_General_100_BIN2
          = t.ObjectName COLLATE Latin1_General_100_BIN2
WHERE t.ReleaseVersion = @TargetVersion
  AND
  (
      @InstalledVersion IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM #tbx_ResultTableReleaseObjects AS p
             WHERE p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                       = @InstalledVersion COLLATE Latin1_General_100_BIN2
               AND p.SchemaName COLLATE Latin1_General_100_BIN2
                       = t.SchemaName COLLATE Latin1_General_100_BIN2
               AND p.ObjectName COLLATE Latin1_General_100_BIN2
                       = t.ObjectName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY
      t.SchemaName COLLATE Latin1_General_100_BIN2
    , t.ObjectName COLLATE Latin1_General_100_BIN2;

IF @CollisionObject IS NOT NULL
BEGIN
    DECLARE @CollisionMessage nvarchar(2048) =
        N'Das neue Framework-Objekt '
        + QUOTENAME(@CollisionSchema)
        + N'.'
        + QUOTENAME(@CollisionObject)
        + N' ist bereits vorhanden, stammt aber nicht aus dem bekannten installierten Release.';
    SET @CollisionMessage = REPLACE(@CollisionMessage, N'%', N'%%');
    THROW 51034, @CollisionMessage, 1;
END;

INSERT INTO #tbx_ResultTableDeployState
(
      TargetVersion
    , InstalledVersion
    , DeploymentMode
    , SchemaCreated
)
VALUES
(
      @TargetVersion
    , @InstalledVersion
    , @DeploymentMode
    , 0
);

/*
 * Der vollständige Preflight ist abgeschlossen. Erst jetzt beginnt die kurze
 * Mutationstransaktion. Eine Transaction-owned Application Lock serialisiert
 * Deployments dieses Moduls innerhalb der Zieldatenbank.
 */
BEGIN TRY
    BEGIN TRANSACTION;

    EXEC @LockResult = sys.sp_getapplock
          @Resource    = N'toolbelt.deploy.toolbelt.core.result-table'
        , @LockMode    = N'Exclusive'
        , @LockOwner   = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
    BEGIN
        THROW 51037, N'Ein paralleles Deployment von toolbelt.core.result-table ist bereits aktiv.', 1;
    END;

    DECLARE @CurrentInstalledVersion nvarchar(64);

    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
           <> ISNULL(@InstalledVersion, N'') COLLATE Latin1_General_100_BIN2
    BEGIN
        THROW 51037, N'Der installierte Modulstand hat sich seit dem Preflight verändert.', 1;
    END;

    SET @CollisionSchema = NULL;
    SET @CollisionObject = NULL;

    SELECT TOP (1)
          @CollisionSchema = t.SchemaName
        , @CollisionObject = t.ObjectName
    FROM #tbx_ResultTableReleaseObjects AS t
    INNER JOIN sys.schemas AS s
        ON s.name COLLATE Latin1_General_100_BIN2
              = t.SchemaName COLLATE Latin1_General_100_BIN2
    INNER JOIN sys.objects AS o
        ON o.schema_id = s.schema_id
       AND o.name COLLATE Latin1_General_100_BIN2
              = t.ObjectName COLLATE Latin1_General_100_BIN2
    WHERE t.ReleaseVersion = @TargetVersion
      AND
      (
          @InstalledVersion IS NULL
          OR NOT EXISTS
             (
                 SELECT 1
                 FROM #tbx_ResultTableReleaseObjects AS p
                 WHERE p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                           = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND p.SchemaName COLLATE Latin1_General_100_BIN2
                           = t.SchemaName COLLATE Latin1_General_100_BIN2
                   AND p.ObjectName COLLATE Latin1_General_100_BIN2
                           = t.ObjectName COLLATE Latin1_General_100_BIN2
             )
      );

    IF @CollisionObject IS NOT NULL
    BEGIN
        THROW 51037, N'Ein Zielobjekt hat sich seit dem Preflight verändert oder ist neu hinzugekommen.', 1;
    END;

    SET @SchemaId = SCHEMA_ID(N'toolbelt_core');

    IF @SchemaId IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_core] AUTHORIZATION [dbo];';
        SET @SchemaCreated = 1;
        SET @SchemaId = SCHEMA_ID(N'toolbelt_core');

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.Managed'
            , @value      = 1
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_core';

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.SchemaCategory'
            , @value      = N'core'
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_core';
    END;

    UPDATE #tbx_ResultTableDeployState
    SET SchemaCreated = @SchemaCreated;

    /*
     * Ein Objekt verschwindet nur dann, wenn es im bekannten installierten
     * Release enthalten war und im Zielrelease fehlt. Andere Objekte werden
     * durch diesen Block weder ausgewählt noch verändert.
     */
    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN o.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN o.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN o.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(s.name)
                    + N'.'
                    + QUOTENAME(o.name)
                    + N';'
                FROM #tbx_ResultTableReleaseObjects AS p
                INNER JOIN sys.schemas AS s
                    ON s.name COLLATE Latin1_General_100_BIN2
                          = p.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS o
                    ON o.schema_id = s.schema_id
                   AND o.name COLLATE Latin1_General_100_BIN2
                          = p.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                  AND NOT EXISTS
                      (
                          SELECT 1
                          FROM #tbx_ResultTableReleaseObjects AS t
                          WHERE t.ReleaseVersion = @TargetVersion
                            AND t.SchemaName COLLATE Latin1_General_100_BIN2
                                  = p.SchemaName COLLATE Latin1_General_100_BIN2
                            AND t.ObjectName COLLATE Latin1_General_100_BIN2
                                  = p.ObjectName COLLATE Latin1_General_100_BIN2
                      )
                  AND o.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY
                      s.name COLLATE Latin1_General_100_BIN2
                    , o.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;

    /*
     * Wurde ein Framework-Objekt lokal in einen anderen unterstützten
     * Objekttyp umgebaut, bleibt seine Herkunft aus dem Vorgängerrelease
     * maßgeblich. Der falsche Typ wird entfernt, damit die kanonische Source
     * den Zieltyp neu anlegen kann.
     */
    SET @DropSql = NULL;

    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN o.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN o.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN o.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(s.name)
                    + N'.'
                    + QUOTENAME(o.name)
                    + N';'
                FROM #tbx_ResultTableReleaseObjects AS t
                INNER JOIN #tbx_ResultTableReleaseObjects AS p
                    ON p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND p.SchemaName COLLATE Latin1_General_100_BIN2
                          = t.SchemaName COLLATE Latin1_General_100_BIN2
                   AND p.ObjectName COLLATE Latin1_General_100_BIN2
                          = t.ObjectName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.schemas AS s
                    ON s.name COLLATE Latin1_General_100_BIN2
                          = t.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS o
                    ON o.schema_id = s.schema_id
                   AND o.name COLLATE Latin1_General_100_BIN2
                          = t.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE t.ReleaseVersion = @TargetVersion
                  AND o.type COLLATE Latin1_General_100_BIN2
                        <> t.ObjectType COLLATE Latin1_General_100_BIN2
                  AND o.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY
                      s.name COLLATE Latin1_General_100_BIN2
                    , o.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO

/*
 * Die kanonische Source liegt exakt einmal im Repository. CREATE OR ALTER
 * überschreibt bei Erst-, Upgrade- und Wiederholungsdeployment die
 * Framework-Procedure innerhalb der bereits geöffneten Transaktion.
 */
-- ============================================================================
-- Objekt:          toolbelt_core.USP_PrepareResultTable
-- Typ:             Stored Procedure
-- Zweck:           Bereitet eine vorhandene lokale Temp-Tabelle anhand des
--                  Spaltenschemas einer Referenztabelle als ResultTable vor.
-- Vertrag:         Documentation/Architecture/RESULT_TABLE_MODULE_DESIGN.md
-- Parameter:       @ResultTableToAlter sysname = NULL
--                  @LikeTable nvarchar(776) = NULL
--                  @KeepData bit = 0
--                  @Debug tinyint = 0
--                  @Hilfe bit = 0
-- Resultset:       Kein fachliches Resultset; bei @Hilfe = 1 genau ein
--                  standardisiertes Help-Resultset.
-- Dependencies:    Keine weiteren Toolbelt-Module.
-- Rechte:          EXECUTE auf der Procedure und Metadatensichtbarkeit auf
--                  reguläre Referenztabellen. Keine Rechteausweitung.
-- Versionen:       SQL Server 2019, 2022 und 2025.
-- Plattformen:     Windows und Linux; Runtime-Validierung separat auszuweisen.
-- Fehlerverhalten: Vertragsfehler 51020 bis 51029; Engine-Fehler werden nach
--                  transaktionsgerechtem Cleanup unverändert weitergegeben.
-- Performance:     Ein read-only Metadaten-Preflight. DDL nur bei abweichendem
--                  Schema; bei passendem Schema optional TRUNCATE.
-- Einschränkungen: Nur lokale Ziel-Temp-Tabellen und Tabellen als Schemaquelle.
--                  Keine gleichzeitige DDL-Manipulation derselben Zieltable.
-- ============================================================================

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_core].[USP_PrepareResultTable]
(
      @ResultTableToAlter sysname       = NULL
    , @LikeTable          nvarchar(776) = NULL
    , @KeepData           bit           = 0
    , @Debug              tinyint       = 0
    , @Hilfe              bit           = 0
)
AS
BEGIN
    SET NOCOUNT ON;

    -- Explizit übergebenes NULL verwendet denselben technischen Default wie
    -- ein ausgelassener optionaler Steuerparameter.
    SET @KeepData = ISNULL(@KeepData, 0);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    /*
     * Der Help-Pfad steht absichtlich vor jeder fachlichen Validierung. Dadurch
     * bleibt ein reiner Hilfeaufruf ohne Zieltable, Referenztabelle oder Rechte
     * auf fremde Metadaten möglich und garantiert keinerlei Mutation.
     */
    IF @Hilfe = 1
    BEGIN
        DECLARE @Help TABLE
        (
              HelpContractVersion varchar(16)    NOT NULL
            , SchemaName          sysname        NOT NULL
            , ObjectName          sysname        NOT NULL
            , Section             varchar(32)    NOT NULL
            , Ordinal             int            NOT NULL
            , ItemName            sysname        NULL
            , SqlDataType         varchar(256)   NULL
            , IsRequired          bit            NULL
            , IsNullable          bit            NULL
            , DefaultValue        nvarchar(4000) NULL
            , Description         nvarchar(max)  NOT NULL
            , ExampleSql          nvarchar(max)  NULL
        );

        INSERT INTO @Help
        (
              HelpContractVersion
            , SchemaName
            , ObjectName
            , Section
            , Ordinal
            , ItemName
            , SqlDataType
            , IsRequired
            , IsNullable
            , DefaultValue
            , Description
            , ExampleSql
        )
        VALUES
          ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'DESCRIPTION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Bereitet eine vorhandene lokale Temp-Tabelle anhand des Spaltenschemas einer vorhandenen Referenztabelle vor. Die Procedure fügt keine fachlichen Resultzeilen ein.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PARAMETER', 1
          , N'@ResultTableToAlter', 'sysname', 1, 0, N'NULL'
          , N'Vorhandene lokale Ziel-Temp-Tabelle. Der Name beginnt mit genau einem #, ist höchstens 116 Zeichen lang und verwendet nicht den reservierten Präfix #tbx_.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PARAMETER', 2
          , N'@LikeTable', 'nvarchar(776)', 1, 0, N'NULL'
          , N'Referenztabelle in der Form #LocalTemplate, Schema.Table oder Database.Schema.Table. Ziel- und Referenztabelle dürfen nicht identisch sein. Views, Synonyme, globale Temp-Tabellen und vierteilige Namen sind nicht unterstützt.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PARAMETER', 3
          , N'@KeepData', 'bit', 0, 1, N'0'
          , N'0 verwendet Replace-Semantik. 1 erhält vorhandene Daten nur bei bereits passendem Schema; andernfalls wird vor jeder Mutation mit Fehler 51025 abgebrochen.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PARAMETER', 4
          , N'@Debug', 'tinyint', 0, 1, N'0'
          , N'Steuert Debug-Messages. Die Stufen 1 bis 3 liefern zunehmend Details; 255 ist der maximale interne Trace. Debug erzeugt kein Resultset.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PARAMETER', 5
          , N'@Hilfe', 'bit', 0, 1, N'0'
          , N'1 gibt ausschließlich dieses Help-Resultset aus und ignoriert alle anderen Parameter.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'RESULT_COLUMN', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Diese Infrastruktur-USP besitzt kein fachliches Resultset. Erfolg wird mit RETURN 0, ein Fehler mit THROW signalisiert.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 1
          , N'51020', NULL, NULL, NULL, NULL
          , N'@ResultTableToAlter fehlt oder ist kein zulässiger lokaler Temp-Tabellenname.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 2
          , N'51021', NULL, NULL, NULL, NULL
          , N'Die Zieltable ist im aktuellen Session-Scope nicht sichtbar.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 3
          , N'51022', NULL, NULL, NULL, NULL
          , N'@LikeTable fehlt, ist mehrdeutig, verwendet eine nicht unterstützte Namensform oder bezeichnet dieselbe Temp-Tabelle wie das Ziel.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 4
          , N'51023', NULL, NULL, NULL, NULL
          , N'Die Referenztabelle ist nicht sichtbar oder kein unterstützter Tabellentyp.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 5
          , N'51024', NULL, NULL, NULL, NULL
          , N'Das Referenzschema enthält eine nicht unterstützte oder nicht einfügbare Spaltenform.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 6
          , N'51025', NULL, NULL, NULL, NULL
          , N'@KeepData = 1 verhindert den erforderlichen Schemaumbau.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 7
          , N'51026', NULL, NULL, NULL, NULL
          , N'Ein Index, Constraint oder anderes abhängiges Objekt verhindert den Schemaumbau.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 8
          , N'51027', NULL, NULL, NULL, NULL
          , N'Eine Collation oder ein Datentyp kann nicht sicher in DDL überführt werden.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 9
          , N'51028', NULL, NULL, NULL, NULL
          , N'Der aktuelle Transaktionszustand erlaubt kein kontrolliertes Rollback.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 10
          , N'51029', NULL, NULL, NULL, NULL
          , N'Intern erzeugtes DDL überschreitet einen unterstützten Grenzwert oder ist unvollständig.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PERMISSION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Erforderlich sind EXECUTE auf der Procedure sowie ausreichende Metadatensichtbarkeit auf eine reguläre Referenztabelle. Die Procedure verwendet kein EXECUTE AS und gewährt keine Rechte.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'LIMITATION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Permanente oder globale Zieltabellen, Tabellenvariablen, identische Ziel- und Referenztabellen, Views, Synonyme, Linked Server, frei geliefertes DDL und parallele DDL-Manipulation derselben Zieltable sind nicht unterstützt.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'EXAMPLE', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Bereitet eine synthetische lokale ResultTable anhand einer lokalen Helper-Tabelle vor.'
          , N'CREATE TABLE #Result (Dummy int NULL);
CREATE TABLE #ResultShape (ItemOrdinal bigint NOT NULL, ItemValue varchar(100) NULL);

EXEC toolbelt_core.USP_PrepareResultTable
      @ResultTableToAlter = N''#Result''
    , @LikeTable          = N''#ResultShape''
    , @KeepData           = 0;' );

        SELECT
              HelpContractVersion
            , SchemaName
            , ObjectName
            , Section
            , Ordinal
            , ItemName
            , SqlDataType
            , IsRequired
            , IsNullable
            , DefaultValue
            , Description
            , ExampleSql
        FROM @Help
        ORDER BY
              CASE Section
                  WHEN 'DESCRIPTION'   THEN 1
                  WHEN 'PARAMETER'     THEN 2
                  WHEN 'RESULT_COLUMN' THEN 3
                  WHEN 'ERROR'         THEN 4
                  WHEN 'PERMISSION'    THEN 5
                  WHEN 'LIMITATION'    THEN 6
                  WHEN 'EXAMPLE'       THEN 7
                  ELSE 8
              END
            , Ordinal;

        RETURN 0;
    END;

    DECLARE
          @TargetObjectId          int
        , @TargetQuotedName        nvarchar(258)
        , @SourceObjectId          int
        , @SourceDatabaseName      sysname
        , @SourceDatabaseQuoted    nvarchar(258)
        , @SourceSchemaName        sysname
        , @SourceObjectName        sysname
        , @SourceServerName        sysname
        , @SourceIsLocal           bit = 0
        , @Sql                     nvarchar(max)
        , @ErrorMessage            nvarchar(2048)
        , @DebugMessage            nvarchar(max)
        , @DebugChunk              nvarchar(1800);

    /*
     * Der logische Zielname wird als ein einzelner Identifier behandelt. Ein
     * Punkt oder eine schließende Klammer darf daher Bestandteil des Namens
     * sein; QUOTENAME verhindert, dass daraus ein mehrteiliger Name oder DDL
     * wird. Die physische TempDB-Suffixbildung wird SQL Server überlassen.
     */
    IF @ResultTableToAlter IS NULL
       OR DATALENGTH(@ResultTableToAlter) < 4
       OR DATALENGTH(@ResultTableToAlter) > 232
       OR LEFT(@ResultTableToAlter, 1) COLLATE Latin1_General_100_BIN2 <> N'#'
       OR LEFT(@ResultTableToAlter, 2) COLLATE Latin1_General_100_BIN2 = N'##'
       OR LOWER(LEFT(@ResultTableToAlter, 5) COLLATE Latin1_General_100_BIN2) = N'#tbx_'
       OR QUOTENAME(@ResultTableToAlter) IS NULL
    BEGIN
        THROW 51020, N'@ResultTableToAlter muss eine vorhandene lokale Temp-Tabelle mit genau einem führenden #, höchstens 116 Zeichen und ohne reservierten Präfix #tbx_ bezeichnen.', 1;
    END;

    SET @TargetQuotedName = QUOTENAME(@ResultTableToAlter);
    SET @TargetObjectId = OBJECT_ID(N'tempdb..' + @TargetQuotedName, N'U');

    IF @TargetObjectId IS NULL
    BEGIN
        SET @ErrorMessage = N'Die lokale Zieltable '
            + @TargetQuotedName
            + N' ist im aktuellen Session-Scope nicht sichtbar.';
        SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
        THROW 51021, @ErrorMessage, 1;
    END;

    IF @LikeTable IS NULL OR DATALENGTH(@LikeTable) = 0
    BEGIN
        THROW 51022, N'@LikeTable muss #LocalTemplate, Schema.Table oder Database.Schema.Table bezeichnen.', 1;
    END;

    /*
     * Lokale Referenztabellen werden wie die Zieltable genau einmal aufgelöst.
     * Globale Temp-Tabellen sind eine erkennbare, aber nicht unterstützte
     * Tabellenart und erhalten deshalb den Objektfehler 51023.
     */
    IF (LEFT(@LikeTable, 1) COLLATE Latin1_General_100_BIN2) = N'#'
    BEGIN
        IF (LEFT(@LikeTable, 2) COLLATE Latin1_General_100_BIN2) = N'##'
        BEGIN
            THROW 51023, N'Globale Temp-Tabellen sind als @LikeTable nicht unterstützt.', 1;
        END;

        IF DATALENGTH(@LikeTable) < 4
           OR DATALENGTH(@LikeTable) > 232
           OR QUOTENAME(CONVERT(sysname, @LikeTable)) IS NULL
        BEGIN
            THROW 51022, N'Der lokale Name in @LikeTable ist kein zulässiger Temp-Tabellenname.', 1;
        END;

        SET @SourceIsLocal = 1;
        SET @SourceDatabaseName = N'tempdb';
        SET @SourceDatabaseQuoted = QUOTENAME(@SourceDatabaseName);
        SET @SourceObjectName = CONVERT(sysname, @LikeTable);
        SET @SourceObjectId = OBJECT_ID(
              N'tempdb..' + QUOTENAME(@SourceObjectName)
            , N'U'
        );

        IF @SourceObjectId IS NULL
        BEGIN
            SET @ErrorMessage = N'Die lokale Referenztabelle '
                + QUOTENAME(@SourceObjectName)
                + N' ist im aktuellen Session-Scope nicht sichtbar.';
            SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
            THROW 51023, @ErrorMessage, 1;
        END;
    END;
    ELSE
    BEGIN
        /*
         * PARSENAME zerlegt ausschließlich Objektnamen. Die ermittelten Teile
         * werden nie als Originaltext ausgeführt, sondern als sysname geprüft,
         * mit QUOTENAME neu aufgebaut und Werte in Catalog-Abfragen
         * parametrisiert. Ein Serverteil ist vertraglich ausgeschlossen.
         */
        SET @SourceObjectName = PARSENAME(@LikeTable, 1);
        SET @SourceSchemaName = PARSENAME(@LikeTable, 2);
        SET @SourceDatabaseName = PARSENAME(@LikeTable, 3);
        SET @SourceServerName = PARSENAME(@LikeTable, 4);

        IF @SourceObjectName IS NULL
           OR @SourceSchemaName IS NULL
           OR @SourceServerName IS NOT NULL
           OR QUOTENAME(@SourceObjectName) IS NULL
           OR QUOTENAME(@SourceSchemaName) IS NULL
        BEGIN
            THROW 51022, N'@LikeTable muss als Schema.Table oder Database.Schema.Table ohne Serverteil angegeben werden.', 1;
        END;

        IF @SourceDatabaseName IS NULL
        BEGIN
            SET @SourceDatabaseName = DB_NAME();
        END;

        IF DB_ID(@SourceDatabaseName) IS NULL
           OR QUOTENAME(@SourceDatabaseName) IS NULL
        BEGIN
            THROW 51023, N'Die Datenbank der Referenztabelle ist nicht sichtbar oder nicht vorhanden.', 1;
        END;

        SET @SourceDatabaseQuoted = QUOTENAME(@SourceDatabaseName);
        SET @Sql = N'
SELECT @ResolvedObjectId = t.object_id
FROM ' + @SourceDatabaseQuoted + N'.sys.tables AS t
INNER JOIN ' + @SourceDatabaseQuoted + N'.sys.schemas AS s
    ON s.schema_id = t.schema_id
WHERE s.name COLLATE Latin1_General_100_BIN2
          = @SchemaName COLLATE Latin1_General_100_BIN2
  AND t.name COLLATE Latin1_General_100_BIN2
          = @ObjectName COLLATE Latin1_General_100_BIN2;';

        BEGIN TRY
            EXEC sys.sp_executesql
                  @Sql
                , N'@SchemaName sysname, @ObjectName sysname, @ResolvedObjectId int OUTPUT'
                , @SchemaName      = @SourceSchemaName
                , @ObjectName      = @SourceObjectName
                , @ResolvedObjectId = @SourceObjectId OUTPUT;
        END TRY
        BEGIN CATCH
            /*
             * Ein tatsächlich aufgetretener Engine-Fehler darf nicht als
             * Toolbelt-Validierungsfehler erscheinen. Nur eine erfolgreich
             * ausgeführte Suche ohne unterstütztes Objekt ergibt 51023.
             */
            THROW;
        END CATCH;

        IF @SourceObjectId IS NULL
        BEGIN
            THROW 51023, N'Die reguläre Referenztabelle ist nicht sichtbar, nicht vorhanden oder kein User Table.', 1;
        END;
    END;

    IF @SourceIsLocal = 1 AND @SourceObjectId = @TargetObjectId
    BEGIN
        THROW 51022, N'@ResultTableToAlter und @LikeTable dürfen nicht dieselbe lokale Temp-Tabelle bezeichnen.', 1;
    END;

    IF @Debug >= 1
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: Ziel- und Referenztabelle wurden aufgelöst; read-only Preflight beginnt.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    DECLARE
          @SourceColumnCount       int
        , @TargetColumnCount       int
        , @UnsupportedColumnName   sysname
        , @UnsupportedReason       nvarchar(4000)
        , @InvalidCollationDetected bit
        , @InvalidCollationName    sysname
        , @SchemaMatches           bit
        , @AddColumnsList          nvarchar(max)
        , @AddColumnAfterAnchor     nvarchar(4000)
        , @DropColumnsList         nvarchar(max)
        , @DropColumnBeforeAnchor   nvarchar(258)
        , @SourceMetadataDebug     nvarchar(max);

    /*
     * Die Quelldatenbank ist der einzige dynamische Catalog-Teil. Sie stammt
     * entweder aus DB_NAME/PARSENAME oder ist tempdb und wird mit QUOTENAME
     * begrenzt. Objekt-IDs werden als Werte parametrisiert.
     *
     * Alias Types werden auf den zugrunde liegenden Systemtyp normalisiert.
     * Typisiertes XML und Sparse werden bewusst als untypisiertes XML
     * beziehungsweise normale Spalte abgebildet. Unbekannte neue Typen bleiben
     * durch die Whitelist gesperrt, bis ihr Vertrag versioniert erweitert wird.
     */
    SET @Sql = N'
DECLARE @SourceColumns TABLE
(
      ColumnOrdinal             int            NOT NULL
    , ColumnName                sysname        NOT NULL
    , TypeName                  sysname        NULL
    , MaxLength                 smallint       NOT NULL
    , PrecisionValue            tinyint        NOT NULL
    , ScaleValue                tinyint        NOT NULL
    , IsNullable                bit            NOT NULL
    , CollationName             sysname        NULL
    , IsIdentity                bit            NOT NULL
    , IsComputed                bit            NOT NULL
    , GeneratedAlwaysType       tinyint        NOT NULL
    , IsHidden                  bit            NOT NULL
    , IsColumnSet               bit            NOT NULL
    , IsSparse                  bit            NOT NULL
    , EncryptionType            int            NULL
    , IsAssemblyType            bit            NOT NULL
    , IsUserDefined             bit            NOT NULL
    , XmlCollectionId           int            NOT NULL
    , UnsupportedReason         nvarchar(4000) NULL
    , NormalizedTypeDeclaration nvarchar(4000) NULL
);

;WITH RawSourceColumns AS
(
    SELECT
          ROW_NUMBER() OVER (ORDER BY c.column_id) AS ColumnOrdinal
        , c.name AS ColumnName
        , CASE
              WHEN st.name = N''sysname'' AND c.system_type_id = 231
                  THEN N''nvarchar''
              WHEN st.is_user_defined = 1 AND st.is_assembly_type = 0
                  THEN bt.name
              ELSE st.name
          END AS TypeName
        , c.system_type_id AS SystemTypeId
        , c.max_length AS MaxLength
        , c.precision AS PrecisionValue
        , c.scale AS ScaleValue
        , c.is_nullable AS IsNullable
        , c.collation_name AS CollationName
        , c.is_identity AS IsIdentity
        , c.is_computed AS IsComputed
        , c.generated_always_type AS GeneratedAlwaysType
        , c.is_hidden AS IsHidden
        , c.is_column_set AS IsColumnSet
        , c.is_sparse AS IsSparse
        , c.encryption_type AS EncryptionType
        , ISNULL(st.is_assembly_type, 0) AS IsAssemblyType
        , ISNULL(st.is_user_defined, 0) AS IsUserDefined
        , c.xml_collection_id AS XmlCollectionId
    FROM ' + @SourceDatabaseQuoted + N'.sys.columns AS c
    LEFT JOIN ' + @SourceDatabaseQuoted + N'.sys.types AS st
        ON st.user_type_id = c.user_type_id
    LEFT JOIN ' + @SourceDatabaseQuoted + N'.sys.types AS bt
        ON bt.system_type_id = c.system_type_id
       AND bt.user_type_id = bt.system_type_id
    WHERE c.object_id = @SourceObjectId
)
INSERT INTO @SourceColumns
(
      ColumnOrdinal
    , ColumnName
    , TypeName
    , MaxLength
    , PrecisionValue
    , ScaleValue
    , IsNullable
    , CollationName
    , IsIdentity
    , IsComputed
    , GeneratedAlwaysType
    , IsHidden
    , IsColumnSet
    , IsSparse
    , EncryptionType
    , IsAssemblyType
    , IsUserDefined
    , XmlCollectionId
    , UnsupportedReason
    , NormalizedTypeDeclaration
)
SELECT
      r.ColumnOrdinal
    , r.ColumnName
    , r.TypeName
    , r.MaxLength
    , r.PrecisionValue
    , r.ScaleValue
    , r.IsNullable
    , r.CollationName
    , r.IsIdentity
    , r.IsComputed
    , r.GeneratedAlwaysType
    , r.IsHidden
    , r.IsColumnSet
    , r.IsSparse
    , r.EncryptionType
    , r.IsAssemblyType
    , r.IsUserDefined
    , r.XmlCollectionId
    , CASE
          WHEN r.IsIdentity = 1
              THEN N''Identity-Spalten sind nicht als Resultset-Shape unterstützt.''
          WHEN r.IsComputed = 1
              THEN N''Computed Columns sind nicht als Resultset-Shape unterstützt.''
          WHEN r.GeneratedAlwaysType <> 0
              THEN N''Generated-always-Spalten sind nicht als Resultset-Shape unterstützt.''
          WHEN r.IsHidden = 1
              THEN N''Hidden Columns sind nicht als Resultset-Shape unterstützt.''
          WHEN r.IsColumnSet = 1
              THEN N''XML Column Sets sind nicht als Resultset-Shape unterstützt.''
          WHEN r.EncryptionType IS NOT NULL
              THEN N''Verschlüsselte Spalten sind nicht als Resultset-Shape unterstützt.''
          WHEN r.SystemTypeId = 189
              THEN N''rowversion/timestamp ist nicht explizit einfügbar.''
          WHEN r.TypeName IN (N''text'', N''ntext'', N''image'')
              THEN N''Legacy-LOB-Typen text, ntext und image sind nicht unterstützt.''
          WHEN r.IsAssemblyType = 1
               AND (r.IsUserDefined = 1
                    OR r.TypeName NOT IN (N''hierarchyid'', N''geometry'', N''geography''))
              THEN N''Benutzerdefinierte oder unbekannte CLR Types sind nicht unterstützt.''
          WHEN r.TypeName IS NULL
               OR r.TypeName NOT IN
                  (
                        N''bigint'', N''binary'', N''bit'', N''char''
                      , N''date'', N''datetime'', N''datetime2'', N''datetimeoffset''
                      , N''decimal'', N''float'', N''geography'', N''geometry''
                      , N''hierarchyid'', N''int'', N''money'', N''nchar''
                      , N''numeric'', N''nvarchar'', N''real'', N''smalldatetime''
                      , N''smallint'', N''smallmoney'', N''sql_variant'', N''time''
                      , N''tinyint'', N''uniqueidentifier'', N''varbinary''
                      , N''varchar'', N''xml''
                  )
              THEN N''Der Datentyp ist in Contract-Version 1.0 nicht freigegeben.''
          ELSE NULL
      END AS UnsupportedReason
    , CASE
          WHEN r.TypeName IN (N''char'', N''varchar'', N''binary'', N''varbinary'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CASE
                         WHEN r.MaxLength = -1 THEN N''max''
                         ELSE CONVERT(nvarchar(10), r.MaxLength)
                     END
                   + N'')''
          WHEN r.TypeName IN (N''nchar'', N''nvarchar'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CASE
                         WHEN r.MaxLength = -1 THEN N''max''
                         ELSE CONVERT(nvarchar(10), r.MaxLength / 2)
                     END
                   + N'')''
          WHEN r.TypeName IN (N''decimal'', N''numeric'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CONVERT(nvarchar(10), r.PrecisionValue)
                   + N'',''
                   + CONVERT(nvarchar(10), r.ScaleValue)
                   + N'')''
          WHEN r.TypeName = N''float''
              THEN N''[float](''
                   + CONVERT(nvarchar(10), r.PrecisionValue)
                   + N'')''
          WHEN r.TypeName IN (N''time'', N''datetime2'', N''datetimeoffset'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CONVERT(nvarchar(10), r.ScaleValue)
                   + N'')''
          WHEN r.TypeName IN
               (
                     N''bigint'', N''bit'', N''date'', N''datetime''
                   , N''geography'', N''geometry'', N''hierarchyid'', N''int''
                   , N''money'', N''real'', N''smalldatetime'', N''smallint''
                   , N''smallmoney'', N''sql_variant'', N''tinyint''
                   , N''uniqueidentifier'', N''xml''
               )
              THEN QUOTENAME(r.TypeName)
          ELSE NULL
      END AS NormalizedTypeDeclaration
FROM RawSourceColumns AS r;

DECLARE @TargetColumns TABLE
(
      ColumnOrdinal   int      NOT NULL
    , ColumnName      sysname  NOT NULL
    , TypeName        sysname  NULL
    , MaxLength       smallint NOT NULL
    , PrecisionValue  tinyint  NOT NULL
    , ScaleValue      tinyint  NOT NULL
    , IsNullable      bit      NOT NULL
    , CollationName   sysname  NULL
    , IsInsertable    bit      NOT NULL
);

INSERT INTO @TargetColumns
(
      ColumnOrdinal
    , ColumnName
    , TypeName
    , MaxLength
    , PrecisionValue
    , ScaleValue
    , IsNullable
    , CollationName
    , IsInsertable
)
SELECT
      ROW_NUMBER() OVER (ORDER BY c.column_id)
    , c.name
    , CASE
          WHEN st.name = N''sysname'' AND c.system_type_id = 231
              THEN N''nvarchar''
          WHEN st.is_user_defined = 1 AND st.is_assembly_type = 0
              THEN bt.name
          ELSE st.name
      END
    , c.max_length
    , c.precision
    , c.scale
    , c.is_nullable
    , c.collation_name
    , CONVERT
      (
          bit,
          CASE
              WHEN c.is_identity = 0
               AND c.is_computed = 0
               AND c.generated_always_type = 0
               AND c.is_hidden = 0
               AND c.is_column_set = 0
               AND c.is_sparse = 0
               AND c.encryption_type IS NULL
               AND c.xml_collection_id = 0
               AND c.system_type_id <> 189
               AND NOT
                   (
                       st.is_assembly_type = 1
                       AND (st.is_user_defined = 1
                            OR st.name NOT IN (N''hierarchyid'', N''geometry'', N''geography''))
                   )
                  THEN 1
              ELSE 0
          END
      )
FROM tempdb.sys.columns AS c
LEFT JOIN tempdb.sys.types AS st
    ON st.user_type_id = c.user_type_id
LEFT JOIN tempdb.sys.types AS bt
    ON bt.system_type_id = c.system_type_id
   AND bt.user_type_id = bt.system_type_id
WHERE c.object_id = @TargetObjectId;

SELECT @SourceColumnCount = COUNT(*)
FROM @SourceColumns;

SELECT @TargetColumnCount = COUNT(*)
FROM @TargetColumns;

SELECT TOP (1)
      @UnsupportedColumnName = ColumnName
    , @UnsupportedReason = UnsupportedReason
FROM @SourceColumns
WHERE UnsupportedReason IS NOT NULL
   OR NormalizedTypeDeclaration IS NULL
ORDER BY ColumnOrdinal;

SELECT TOP (1)
      @InvalidCollationDetected = 1
    , @InvalidCollationName = CollationName
FROM @SourceColumns AS c
WHERE c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
  AND
  (
      c.CollationName IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM sys.fn_helpcollations() AS hc
             WHERE hc.name COLLATE Latin1_General_100_BIN2
                       = c.CollationName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY ColumnOrdinal;

SELECT @SchemaMatches =
    CONVERT
    (
        bit,
        CASE
            WHEN EXISTS
                 (
                     SELECT 1
                     FROM @SourceColumns AS s
                     FULL OUTER JOIN @TargetColumns AS t
                         ON t.ColumnOrdinal = s.ColumnOrdinal
                     WHERE s.ColumnOrdinal IS NULL
                        OR t.ColumnOrdinal IS NULL
                        OR s.ColumnName COLLATE Latin1_General_100_BIN2
                               <> t.ColumnName COLLATE Latin1_General_100_BIN2
                        OR ISNULL(s.TypeName, N'''') COLLATE Latin1_General_100_BIN2
                               <> ISNULL(t.TypeName, N'''') COLLATE Latin1_General_100_BIN2
                        OR s.MaxLength <> t.MaxLength
                        OR s.PrecisionValue <> t.PrecisionValue
                        OR s.ScaleValue <> t.ScaleValue
                        OR s.IsNullable <> t.IsNullable
                        OR ISNULL(s.CollationName, N'''') COLLATE Latin1_General_100_BIN2
                               <> ISNULL(t.CollationName, N'''') COLLATE Latin1_General_100_BIN2
                        OR t.IsInsertable <> 1
                 )
                THEN 0
            ELSE 1
        END
    );

SELECT @AddColumnsList =
    STUFF
    (
        (
            SELECT
                  N'', ''
                + QUOTENAME(c.ColumnName)
                + N'' ''
                + c.NormalizedTypeDeclaration
                + CASE
                      WHEN c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
                          THEN N'' COLLATE '' + c.CollationName
                      ELSE N''''
                  END
                + CASE WHEN c.IsNullable = 1 THEN N'' NULL'' ELSE N'' NOT NULL'' END
            FROM @SourceColumns AS c
            WHERE c.ColumnOrdinal < 1024
               OR @SourceColumnCount < 1024
            ORDER BY c.ColumnOrdinal
            FOR XML PATH(N''''), TYPE
        ).value(N''.'', N''nvarchar(max)'')
      , 1
      , 2
      , N''''
    );

SELECT @AddColumnAfterAnchor =
      QUOTENAME(c.ColumnName)
    + N'' ''
    + c.NormalizedTypeDeclaration
    + CASE
          WHEN c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
              THEN N'' COLLATE '' + c.CollationName
          ELSE N''''
      END
    + CASE WHEN c.IsNullable = 1 THEN N'' NULL'' ELSE N'' NOT NULL'' END
FROM @SourceColumns AS c
WHERE @SourceColumnCount = 1024
  AND c.ColumnOrdinal = 1024;

SELECT @DropColumnsList =
    STUFF
    (
        (
            SELECT N'', '' + QUOTENAME(c.ColumnName)
            FROM @TargetColumns AS c
            WHERE c.ColumnOrdinal < 1024
               OR @TargetColumnCount < 1024
            ORDER BY c.ColumnOrdinal
            FOR XML PATH(N''''), TYPE
        ).value(N''.'', N''nvarchar(max)'')
      , 1
      , 2
      , N''''
    );

SELECT @DropColumnBeforeAnchor = QUOTENAME(c.ColumnName)
FROM @TargetColumns AS c
WHERE @TargetColumnCount = 1024
  AND c.ColumnOrdinal = 1024;

SELECT @SourceMetadataDebug =
    STUFF
    (
        (
            SELECT
                  NCHAR(10)
                + CONVERT(nvarchar(10), c.ColumnOrdinal)
                + N'': ''
                + QUOTENAME(c.ColumnName)
                + N'' ''
                + ISNULL(c.NormalizedTypeDeclaration, N''<unsupported>'')
                + CASE
                      WHEN c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
                          THEN N'' COLLATE '' + ISNULL(c.CollationName, N''<NULL>'')
                      ELSE N''''
                  END
                + CASE WHEN c.IsNullable = 1 THEN N'' NULL'' ELSE N'' NOT NULL'' END
            FROM @SourceColumns AS c
            ORDER BY c.ColumnOrdinal
            FOR XML PATH(N''''), TYPE
        ).value(N''.'', N''nvarchar(max)'')
      , 1
      , 1
      , N''''
    );';

    BEGIN TRY
        EXEC sys.sp_executesql
              @Sql
            , N'@SourceObjectId int,
                @TargetObjectId int,
                @SourceColumnCount int OUTPUT,
                @TargetColumnCount int OUTPUT,
                @UnsupportedColumnName sysname OUTPUT,
                @UnsupportedReason nvarchar(4000) OUTPUT,
                @InvalidCollationDetected bit OUTPUT,
                @InvalidCollationName sysname OUTPUT,
                @SchemaMatches bit OUTPUT,
                @AddColumnsList nvarchar(max) OUTPUT,
                @AddColumnAfterAnchor nvarchar(4000) OUTPUT,
                @DropColumnsList nvarchar(max) OUTPUT,
                @DropColumnBeforeAnchor nvarchar(258) OUTPUT,
                @SourceMetadataDebug nvarchar(max) OUTPUT'
            , @SourceObjectId        = @SourceObjectId
            , @TargetObjectId        = @TargetObjectId
            , @SourceColumnCount     = @SourceColumnCount OUTPUT
            , @TargetColumnCount     = @TargetColumnCount OUTPUT
            , @UnsupportedColumnName = @UnsupportedColumnName OUTPUT
            , @UnsupportedReason     = @UnsupportedReason OUTPUT
            , @InvalidCollationDetected = @InvalidCollationDetected OUTPUT
            , @InvalidCollationName  = @InvalidCollationName OUTPUT
            , @SchemaMatches         = @SchemaMatches OUTPUT
            , @AddColumnsList        = @AddColumnsList OUTPUT
            , @AddColumnAfterAnchor  = @AddColumnAfterAnchor OUTPUT
            , @DropColumnsList       = @DropColumnsList OUTPUT
            , @DropColumnBeforeAnchor = @DropColumnBeforeAnchor OUTPUT
            , @SourceMetadataDebug   = @SourceMetadataDebug OUTPUT;
    END TRY
    BEGIN CATCH
        /*
         * Catalog- und Engine-Fehler werden nicht in einen scheinbar
         * erfolgreichen Validierungsstatus übersetzt. Die ursprüngliche
         * Fehlernummer bleibt durch THROW für den Aufrufer erhalten.
         */
        THROW;
    END CATCH;

    IF @SourceColumnCount IS NULL OR @SourceColumnCount = 0
    BEGIN
        THROW 51023, N'Die Referenztabelle besitzt keine sichtbaren Spalten oder ihre Metadaten sind nicht ausreichend sichtbar.', 1;
    END;

    IF @SourceColumnCount > 1024
    BEGIN
        THROW 51029, N'Das Referenzschema überschreitet das unterstützte Limit von 1024 ResultTable-Spalten.', 1;
    END;

    IF @TargetColumnCount > 1024
    BEGIN
        THROW 51029, N'Die Zieltable überschreitet das unterstützte Limit von 1024 ResultTable-Spalten.', 1;
    END;

    IF @UnsupportedColumnName IS NOT NULL
    BEGIN
        SET @ErrorMessage = N'Die Referenzspalte '
            + QUOTENAME(@UnsupportedColumnName)
            + N' ist nicht unterstützt. '
            + ISNULL(@UnsupportedReason, N'Es konnte keine sichere Typdeklaration erzeugt werden.');
        SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
        THROW 51024, @ErrorMessage, 1;
    END;

    IF @InvalidCollationDetected = 1
    BEGIN
        SET @ErrorMessage = N'Die Collation '
            + COALESCE(QUOTENAME(@InvalidCollationName), N'<NULL>')
            + N' kann nicht sicher für die ResultTable verwendet werden.';
        SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
        THROW 51027, @ErrorMessage, 1;
    END;

    IF @AddColumnsList IS NULL
       OR @DropColumnsList IS NULL
       OR (@SourceColumnCount = 1024 AND @AddColumnAfterAnchor IS NULL)
       OR (@TargetColumnCount = 1024 AND @DropColumnBeforeAnchor IS NULL)
       OR DATALENGTH(@AddColumnsList) > 2000000
       OR DATALENGTH(@DropColumnsList) > 2000000
       OR DATALENGTH(ISNULL(@AddColumnAfterAnchor, N'')) > 8000
    BEGIN
        THROW 51029, N'Das intern erzeugte DDL ist unvollständig oder überschreitet 1.000.000 Unicode-Zeichen je Spaltenliste.', 1;
    END;

    DECLARE @TargetHasRows bit;
    SET @Sql = N'SELECT @HasRows = CONVERT(bit, CASE WHEN EXISTS (SELECT 1 FROM '
        + @TargetQuotedName
        + N') THEN 1 ELSE 0 END);';

    EXEC sys.sp_executesql
          @Sql
        , N'@HasRows bit OUTPUT'
        , @HasRows = @TargetHasRows OUTPUT;

    IF @Debug >= 2
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: TargetObjectId='
            + CONVERT(nvarchar(20), @TargetObjectId)
            + N', SourceObjectId='
            + CONVERT(nvarchar(20), @SourceObjectId)
            + N', SourceIsLocal='
            + CONVERT(nvarchar(1), @SourceIsLocal)
            + N', TargetHasRows='
            + CONVERT(nvarchar(1), @TargetHasRows)
            + N', SchemaMatches='
            + CONVERT(nvarchar(1), @SchemaMatches)
            + N'.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    IF @Debug >= 3 AND @SourceMetadataDebug IS NOT NULL
    BEGIN
        SET @DebugMessage = N'USP_PrepareResultTable: normalisierte Referenzmetadaten:'
            + NCHAR(10)
            + @SourceMetadataDebug;

        WHILE DATALENGTH(@DebugMessage) > 0
        BEGIN
            SET @DebugChunk = LEFT(@DebugMessage, 1800);
            RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
            SET @DebugMessage = SUBSTRING(@DebugMessage, 1801, 2147483647);
        END;
    END;

    /*
     * @KeepData = 1 darf bei abweichendem Schema niemals einen Teilumbau
     * auslösen. Der Fehler erfolgt deshalb vor Dependency-Prüfung, Datenlöschung
     * und Transaktionsbeginn und lässt die Zieltable vollständig unverändert.
     */
    IF @SchemaMatches = 0 AND @TargetHasRows = 1 AND @KeepData = 1
    BEGIN
        THROW 51025, N'@KeepData = 1 kann vorhandene Daten bei abweichendem Ziel- und Referenzschema nicht sicher erhalten.', 1;
    END;

    DECLARE
          @BlockerType sysname
        , @BlockerName sysname;

    IF @SchemaMatches = 0
    BEGIN
        /*
         * Der in-place-Algorithmus ersetzt alle alten Spalten. Daher blockiert
         * jedes Objekt, das an einer dieser Spalten hängt. Es wird bewusst
         * nichts automatisch gedroppt oder nachgebaut.
         */
        SELECT TOP (1)
              @BlockerType = d.BlockerType
            , @BlockerName = d.BlockerName
        FROM
        (
            SELECT
                  10 AS PriorityValue
                , CONVERT(sysname, N'INDEX') AS BlockerType
                , i.name AS BlockerName
            FROM tempdb.sys.indexes AS i
            WHERE i.object_id = @TargetObjectId
              AND i.index_id > 0
              AND i.is_hypothetical = 0

            UNION ALL

            SELECT
                  20
                , CONVERT(sysname, N'DEFAULT_CONSTRAINT')
                , dc.name
            FROM tempdb.sys.default_constraints AS dc
            WHERE dc.parent_object_id = @TargetObjectId

            UNION ALL

            SELECT
                  30
                , CONVERT(sysname, N'CHECK_CONSTRAINT')
                , cc.name
            FROM tempdb.sys.check_constraints AS cc
            WHERE cc.parent_object_id = @TargetObjectId

            UNION ALL

            SELECT
                  40
                , CONVERT(sysname, N'FOREIGN_KEY')
                , fk.name
            FROM tempdb.sys.foreign_keys AS fk
            WHERE fk.parent_object_id = @TargetObjectId
               OR fk.referenced_object_id = @TargetObjectId

            UNION ALL

            SELECT
                  50
                , CONVERT(sysname, N'COMPUTED_COLUMN')
                , c.name
            FROM tempdb.sys.columns AS c
            WHERE c.object_id = @TargetObjectId
              AND c.is_computed = 1

            UNION ALL

            SELECT
                  60
                , CONVERT(sysname, N'BOUND_DEFAULT_OR_RULE')
                , c.name
            FROM tempdb.sys.columns AS c
            WHERE c.object_id = @TargetObjectId
              AND (c.default_object_id <> 0 OR c.rule_object_id <> 0)

            UNION ALL

            SELECT
                  70
                , CONVERT(sysname, N'TRIGGER')
                , tr.name
            FROM tempdb.sys.triggers AS tr
            WHERE tr.parent_id = @TargetObjectId

            UNION ALL

            SELECT
                  80
                , CONVERT(sysname, N'USER_STATISTICS')
                , st.name
            FROM tempdb.sys.stats AS st
            WHERE st.object_id = @TargetObjectId
              AND st.user_created = 1
        ) AS d
        ORDER BY
              d.PriorityValue
            , d.BlockerName COLLATE Latin1_General_100_BIN2;

        IF @BlockerType IS NOT NULL
        BEGIN
            SET @ErrorMessage = N'Der Schemaumbau von '
                + @TargetQuotedName
                + N' wird durch '
                + @BlockerType
                + N' '
                + COALESCE(QUOTENAME(@BlockerName), N'<unbenannt>')
                + N' blockiert. Das abhängige Objekt muss der Aufrufer vor dem erneuten Aufruf kontrolliert entfernen.';
            SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
            THROW 51026, @ErrorMessage, 1;
        END;
    END;

    DECLARE @MutationRequired bit =
        CONVERT
        (
            bit,
            CASE
                WHEN @SchemaMatches = 0 THEN 1
                WHEN @TargetHasRows = 1 AND @KeepData = 0 THEN 1
                ELSE 0
            END
        );

    IF @MutationRequired = 0
    BEGIN
        IF @Debug >= 1
        BEGIN
            SET @DebugChunk = N'USP_PrepareResultTable: Schema und Datenzustand erfordern keine Mutation.';
            RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
        END;

        RETURN 0;
    END;

    IF XACT_STATE() = -1
    BEGIN
        THROW 51028, N'Der aktuelle uncommittable Transaktionszustand erlaubt keine kontrollierte ResultTable-Mutation.', 1;
    END;

    DECLARE
          @InvocationToken       varchar(32) = REPLACE(CONVERT(varchar(36), NEWID()), '-', '')
        , @AnchorColumnName      sysname
        , @SavepointName         varchar(32)
        , @StartedTransaction    bit = 0
        , @ClearMethod           varchar(16)
        , @DropBeforeAnchorSql   nvarchar(max)
        , @AddAnchorSql          nvarchar(max)
        , @DropOldColumnsSql     nvarchar(max)
        , @AddNewColumnsSql      nvarchar(max)
        , @DropAnchorSql         nvarchar(max)
        , @AddAfterAnchorSql     nvarchar(max)
        , @TruncateSql           nvarchar(max);

    SET @AnchorColumnName = CONVERT(sysname, N'tbx_anchor_' + @InvocationToken);

    WHILE EXISTS
    (
        SELECT 1
        FROM tempdb.sys.columns AS c
        WHERE c.object_id = @TargetObjectId
          AND c.name COLLATE Latin1_General_100_BIN2
                  = @AnchorColumnName COLLATE Latin1_General_100_BIN2
    )
    BEGIN
        SET @InvocationToken = REPLACE(CONVERT(varchar(36), NEWID()), '-', '');
        SET @AnchorColumnName = CONVERT(sysname, N'tbx_anchor_' + @InvocationToken);
    END;

    SET @SavepointName = CONVERT(varchar(32), 'tbx_rtbl_' + LEFT(@InvocationToken, 23));
    IF @DropColumnBeforeAnchor IS NOT NULL
    BEGIN
        SET @DropBeforeAnchorSql = N'ALTER TABLE '
            + @TargetQuotedName
            + N' DROP COLUMN '
            + @DropColumnBeforeAnchor
            + N';';
    END;

    SET @AddAnchorSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' ADD '
        + QUOTENAME(@AnchorColumnName)
        + N' bit NULL;';
    SET @DropOldColumnsSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' DROP COLUMN '
        + @DropColumnsList
        + N';';
    SET @AddNewColumnsSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' ADD '
        + @AddColumnsList
        + N';';
    SET @DropAnchorSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' DROP COLUMN '
        + QUOTENAME(@AnchorColumnName)
        + N';';
    IF @AddColumnAfterAnchor IS NOT NULL
    BEGIN
        SET @AddAfterAnchorSql = N'ALTER TABLE '
            + @TargetQuotedName
            + N' ADD '
            + @AddColumnAfterAnchor
            + N';';
    END;

    SET @TruncateSql = N'TRUNCATE TABLE ' + @TargetQuotedName + N';';

    IF @Debug >= 3
    BEGIN
        SET @DebugMessage = N'USP_PrepareResultTable: geplantes DDL:'
            + NCHAR(10)
            + CASE
                  WHEN @SchemaMatches = 0
                      THEN COALESCE(@DropBeforeAnchorSql + NCHAR(10), N'')
                           + @AddAnchorSql + NCHAR(10)
                           + @DropOldColumnsSql + NCHAR(10)
                           + @AddNewColumnsSql + NCHAR(10)
                           + @DropAnchorSql
                           + COALESCE(NCHAR(10) + @AddAfterAnchorSql, N'')
                  WHEN @TargetHasRows = 1 AND @KeepData = 0
                      THEN @TruncateSql
                  ELSE N'<keine Mutation>'
              END;

        WHILE DATALENGTH(@DebugMessage) > 0
        BEGIN
            SET @DebugChunk = LEFT(@DebugMessage, 1800);
            RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
            SET @DebugMessage = SUBSTRING(@DebugMessage, 1801, 2147483647);
        END;
    END;

    /*
     * Erst ab hier beginnt die Mutation. Eine vorhandene Caller-Transaktion
     * erhält ausschließlich einen Invocation-spezifischen Savepoint. Die
     * Procedure committed oder rollt niemals die vollständige Caller-
     * Transaktion zurück.
     */
    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @StartedTransaction = 1;
        END;
        ELSE
        BEGIN
            SAVE TRANSACTION @SavepointName;
        END;

        IF @TargetHasRows = 1 AND @KeepData = 0
        BEGIN
            /*
             * Eine lokale ResultTable muss truncatable sein. Verhindert die
             * Engine TRUNCATE dennoch, liegt ein nicht unterstützter Zustand
             * vor. Der Originalfehler wird nach dem Rollback unverändert
             * weitergegeben; ein DELETE-Fallback ist ausdrücklich unzulässig.
             */
            EXEC sys.sp_executesql @TruncateSql;
            SET @ClearMethod = 'TRUNCATE';
        END;

        IF @SchemaMatches = 0
        BEGIN
            /*
             * Bei exakt 1024 Ziel- oder Quellspalten wird der Umbau geteilt:
             * eine alte Spalte weicht vor der Anchor-Spalte beziehungsweise
             * die letzte neue Spalte folgt erst nach deren Entfernung. Dadurch
             * entstehen zu keinem Zeitpunkt mehr als 1024 Spalten.
             */
            IF @DropBeforeAnchorSql IS NOT NULL
            BEGIN
                EXEC sys.sp_executesql @DropBeforeAnchorSql;
            END;

            EXEC sys.sp_executesql @AddAnchorSql;
            EXEC sys.sp_executesql @DropOldColumnsSql;
            EXEC sys.sp_executesql @AddNewColumnsSql;
            EXEC sys.sp_executesql @DropAnchorSql;

            IF @AddAfterAnchorSql IS NOT NULL
            BEGIN
                EXEC sys.sp_executesql @AddAfterAnchorSql;
            END;
        END;

        IF @StartedTransaction = 1
        BEGIN
            COMMIT TRANSACTION;
        END;
    END TRY
    BEGIN CATCH
        DECLARE
              @OriginalErrorNumber  int = ERROR_NUMBER()
            , @OriginalErrorMessage nvarchar(2048) = ERROR_MESSAGE();

        IF @StartedTransaction = 1 AND XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;
        ELSE IF @StartedTransaction = 0 AND XACT_STATE() = 1
        BEGIN
            BEGIN TRY
                ROLLBACK TRANSACTION @SavepointName;
            END TRY
            BEGIN CATCH
                SET @ErrorMessage = N'Der ResultTable-Fehler '
                    + CONVERT(nvarchar(20), @OriginalErrorNumber)
                    + N' konnte wegen Rollback-Fehler '
                    + CONVERT(nvarchar(20), ERROR_NUMBER())
                    + N' nicht kontrolliert zum Savepoint zurückgerollt werden. Ursprüngliche Meldung: '
                    + LEFT(@OriginalErrorMessage, 1200);
                SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
                THROW 51028, @ErrorMessage, 1;
            END CATCH;
        END;

        /*
         * Bei XACT_STATE() = -1 wird kein unzulässiger Savepoint-Rollback
         * versucht. THROW ohne Argumente erhält den ursprünglichen Engine-
         * oder Modulfehler samt Nummer, State und Procedure-Kontext.
         */
        THROW;
    END CATCH;

    IF @Debug >= 2 AND @ClearMethod IS NOT NULL
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: vorhandene Daten wurden mit '
            + @ClearMethod
            + N' entfernt.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    IF @Debug >= 1
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: Vorbereitung erfolgreich abgeschlossen.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    RETURN 0;
END;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    DECLARE
          @ProcedureId          int =
              OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable', N'P')
        , @DeploymentMode       nvarchar(16)
        , @TargetVersion        nvarchar(64)
        , @SourceHash           varchar(64)
        , @VersionPropertyName  sysname =
              N'Toolbelt.Module.toolbelt.core.result-table.Version'
        , @ModePropertyName     sysname =
              N'Toolbelt.Module.toolbelt.core.result-table.DeploymentMode';

    SELECT
          @DeploymentMode = DeploymentMode
        , @TargetVersion = TargetVersion
    FROM #tbx_ResultTableDeployState;

    IF XACT_STATE() <> 1 OR @ProcedureId IS NULL
    BEGIN
        THROW 51038, N'Die Framework-Procedure wurde nicht vollständig innerhalb der Deployment-Transaktion angelegt.', 1;
    END;

    SET @SourceHash = CONVERT
    (
          varchar(64)
        , HASHBYTES
          (
              N'SHA2_256'
            , CONVERT(varbinary(max), OBJECT_DEFINITION(@ProcedureId))
          )
        , 2
    );

    DECLARE @ObjectProperties TABLE
    (
          PropertyOrdinal int IDENTITY(1, 1) NOT NULL
        , PropertyName    sysname            NOT NULL
        , PropertyValue   nvarchar(4000)     NOT NULL
    );

    INSERT INTO @ObjectProperties (PropertyName, PropertyValue)
    VALUES
          (N'Toolbelt.ModuleId', N'toolbelt.core.result-table')
        , (N'Toolbelt.ModuleVersion', @TargetVersion)
        , (N'Toolbelt.ContractVersion', N'1.0')
        , (N'Toolbelt.DeploymentMode', @DeploymentMode)
        , (N'Toolbelt.SourceHash', CONVERT(nvarchar(4000), @SourceHash));

    DECLARE
          @PropertyOrdinal int = 1
        , @PropertyCount   int = (SELECT COUNT(*) FROM @ObjectProperties)
        , @PropertyName    sysname
        , @PropertyValue   nvarchar(4000);

    WHILE @PropertyOrdinal <= @PropertyCount
    BEGIN
        SELECT
              @PropertyName = PropertyName
            , @PropertyValue = PropertyValue
        FROM @ObjectProperties
        WHERE PropertyOrdinal = @PropertyOrdinal;

        IF EXISTS
           (
               SELECT 1
               FROM sys.extended_properties AS ep
               WHERE ep.class = 1
                 AND ep.major_id = @ProcedureId
                 AND ep.minor_id = 0
                 AND ep.name = @PropertyName
           )
        BEGIN
            EXEC sys.sp_updateextendedproperty
                  @name       = @PropertyName
                , @value      = @PropertyValue
                , @level0type = N'SCHEMA'
                , @level0name = N'toolbelt_core'
                , @level1type = N'PROCEDURE'
                , @level1name = N'USP_PrepareResultTable';
        END;
        ELSE
        BEGIN
            EXEC sys.sp_addextendedproperty
                  @name       = @PropertyName
                , @value      = @PropertyValue
                , @level0type = N'SCHEMA'
                , @level0name = N'toolbelt_core'
                , @level1type = N'PROCEDURE'
                , @level1name = N'USP_PrepareResultTable';
        END;

        SET @PropertyOrdinal += 1;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 0
             AND ep.major_id = 0
             AND ep.minor_id = 0
             AND ep.name = @VersionPropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 0
             AND ep.major_id = 0
             AND ep.minor_id = 0
             AND ep.name = @ModePropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.core.result-table
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.json.core
:On Error exit
-- Technischer Core1.0: separat, known-exact, keine Dependency-/Trustbeschaffung.
IF @@TRANCOUNT>0
BEGIN
 RAISERROR(N'JSON_CORE_CALLER_TRANSACTION: aktive Callertransaktion ausgeschlossen.',16,1);
 RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @Mode nvarchar(max)=N'central',@Bits varbinary(max)=0x4d5a90000300000004000000ffff0000b800000000000000400000000000000000000000000000000000000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a2400000000000000504500004c010300f4344e920000000000000000e00022200b0130000036000000060000000000002a54000000200000006000000000001000200000000200000400000000000000040000000000000000a000000002000000000000030040850000100000100000000010000010000000000000100000000000000000000000d85300004f000000006000007003000000000000000000000000000000000000008000000c000000bc5300001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000080000000000000000000000082000004800000000000000000000002e7465787400000030340000002000000036000000020000000000000000000000000000200000602e7273726300000070030000006000000004000000380000000000000000000000000000400000402e72656c6f6300000c0000000080000000020000003c000000000000000000000000000040000042000000000000000000000000000000000c540000000000004800000002000500d4380000e81a0000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000013300400270000000100001102280900000a03166a300b7201000070730a00000a7a020203250a7d02000004067d010000042a1e027b020000042a3a027b01000004027b02000004da2aba03166a2f0b7211000070730a00000a7a03027b02000004310673050000067a02027b0200000403da7d020000042a3202721b000070280b00000a2a1e027b0a0000042a2202037d0a0000042a1e027b0b0000042a2202037d0b0000042a1e027b0c0000042a2202037d0c0000042a1e027b0d0000042a2202037d0d0000042a1e027b0e0000042a2202037d0e0000042a1e027b0f0000042a2202037d0f0000042a1e027b100000042a2202037d100000042a1e027b110000042a2202037d110000042a1e027b120000042a2202037d120000042a5602157d1300000402157d1400000402280900000a2a1e027b1a0000042a2202037d1a0000042a32027b160000046f0c00000a2a8202730d00000a7d1600000402280900000a02037d1700000402047d180000042a6a027b18000004176a6f04000006027b16000004036f0e00000a2a36027b16000004036f0e00000a2a000000133003000a01000002000011027b160000046f0c00000a027b160000046f0f00000a3344027b160000046f0f00000a2c0f027b160000046f0f00000a18d82b011a0c027b18000004086a027b160000046f0c00000a6ad66f04000006027b16000004086f1000000a027b18000004176a6f04000006731800000625036f0700000625046f0900000625056f0d00000625156f0f00000625156f11000006250e047d14000004250e057d150000040a027b160000046f0c00000a0b027b16000004066f1100000a0516324a027b18000004176a6f04000006027b16000004056f0e00000a0d097b13000004162f0909076f0f0000062b17027b16000004097b130000046f0e00000a076f1100000609077d13000004072a00001330030032000000030000110203281d0000060a027b18000004066f0a0000066a6f04000006027b17000004066f08000006066f0a0000066f1200000a2a000013300500a2000000040000110228190000062c0d0228190000067b2b0000042c0b723d000070731300000a7a160a2b670206281d0000060b077b1400000416322102077b14000004077b150000041203120228230000062d02162a07096f13000006076f0600000619332802076f08000006076f0a0000061203120228230000062d02162a07096f1500000607086f170000060617d60a06027b160000046f0c00000a328b02177d19000004172a000013300300f100000005000011027b190000042d0b7257000070731300000a7a031554160a38c10000000206281d0000060b076f060000061a40a9000000160c076f0e00000613042b25027b18000004176a6f040000060817d60c027b1600000411046f0e00000a6f1000000613041104162fd6027b18000004086a186ad66f0400000608027b180000047324000006731400000a0d076f0e00000613052b42021105281d00000613060911066f120000066f1500000a2c0603110554162a0911066f1200000611056f1600000a027b1600000411056f0e00000a6f1000000613051105162fb90617d60a06027b160000046f0c00000a3f2effffff172a0000001330040063010000060000110418da0a027b18000004186a066ad8176ad66f0400000606731700000a0b0e041654160c0304d617da0d0317d613043803010000027b1700000411046f1800000a130511051f5c409c000000027b17000004110417d62513046f1800000a130611061f7533391613071613082b2511071f10d8027b17000004110417d62513046f1800000a2839000006d61307110817d6130811081a32d61107b613052b4911061f66350e11061f622e1c11061f662e1b2b3111061f6e2e1911061f722e1911061f742e192b1d1e13052b1c1f0c13052b161f0a13052b101f0d13052b0a1f0913052b0411061305082c1a1105281900000a2d05051451162a160c0e040e044a17d6542b231105281a00000a2c04170c2b161105281900000a2c05051451162a0e040e044a17d6540711056f1b00000a26110417d613041104093ff5feffff082c05051451162a027b18000004076f1c00000a6a6f0400000605076f1d00000a51172a7202280900000a032d0b7273000070731e00000a7a02037d1b0000042a133003007500000007000011032c03042d0b727d000070731e00000a7a036f1f00000a046f1f00000a282000000a0a160b2b35027b1b000004176a6f0400000603076f1800000a04076f1800000a2e1403076f1800000a04076f1800000a3202172a152a0717d60b070632c7036f1f00000a0c1202046f1f00000a282100000a2ab6032c03042d0b727d000070731e00000a7a036f1f00000a046f1f00000a330c020304282500000616fe012a162a00133003004400000008000011032d0b727d000070731e00000a7a20c59d1c810a160b2b21027b1b000004176a6f040000060603076f1800000a6120930100015a0a0717d60b07036f1f00000a32d6062ade02732f0000067d2100000402280900000a02037d1c00000402047d1d00000402057d1e000004020e047d1f000004020e057d200000042a92027b1e0000042c0d027b1e000004176a6f0400000602027b2200000417d67d220000042a62027b1c000004027c22000004027b1e00000428380000062a000013300500530300000900001102282a000006027b22000004027b1c0000046f1f00000a2e32027b1f0000042d37027b1c000004027b220000046f1800000a1f5b2e22027b1c000004027b220000046f1800000a1f7b2e0d02027b22000004282d0000062a027b1f0000042d1c027b1d000004172e0f027b1c0000046f1f00000a17d62b1a1f7f2b16027b20000004027b1c0000046f1f00000a282000000a0a027b1e0000042c13027b1e0000041a6a066ad8176ad66f0400000602068d180000017d24000004027b1f0000042c2402068d180000017d2500000402068d180000017d2600000402068d180000017d2700000402151516282e0000063a10020000027b210000042a02282a000006027b22000004027b1c0000046f1f00000a330d02027b22000004282d0000062a027b2300000417da0b027b2400000407940c027b1c000004027b220000046f1800000a0d082c0408173344082d11091f5d330c0207282c00000638a4010000027b2400000407189e02027b1f0000042c0a027b2500000407942b01151516282e0000063a7b010000027b210000042a08183337091f5d330c0207282c000006385f010000091f2c3314022829000006027b2400000407179e384601000002027b22000004282d0000062a08192e04081a337208193311091f7d330c0207282c000006381c010000027b220000041304027b1c000004027c220000041205027b1e000004283a0000062d09021105282d0000062a027b1f0000042c1b027b260000040711049e027b2700000407027b220000041104da9e027b24000004071b9e38bf000000081b3326091f3a2e0d02027b22000004282d0000062a022829000006027b24000004071c9e3895000000081c3351027b24000004071d9e02027b1f0000042c0a027b2500000407942b0115027b1f0000042c0a027b2600000407942b0115027b1f0000042c0a027b2700000407942b0116282e0000062d47027b210000042a081d3331091f7d33090207282c0000062b2e091f2c3311022829000006027b24000004071a9e2b1802027b22000004282d0000062a7289000070731300000a7a027b23000004163debfdffff02282a000006027b22000004027b1c0000046f1f00000a2e0d02027b22000004282d0000062a027b21000004027b210000047b2d0000047d2f000004027b210000042a00133003004400000003000011022829000006027b1f0000042c27027b1f000004027b2500000403946f1e0000060a06027b22000004066f08000006da6f0b00000602027b2300000417da7d230000042aea027b210000047b2b0000042d0c027b21000004177d2b000004027b210000047b2c000004162f0c027b21000004037d2c000004027b210000042a0013300800600200000a000011027b22000004027b1c0000046f1f00000a330f02027b22000004282d00000626162a027b220000040a027b220000040b027b1c000004027b220000046f1800000a0c081f5b2e08081f7b40ef000000027b21000004027b210000047b2d000004027b2300000417d6282200000a7d2d000004027b1f0000042c0e027b23000004027b200000042e1b027b1f0000042d32027b1d000004173329027b230000041f7f331f027b21000004187d2b000004027b21000004027b220000047d2c000004162a081f5b2e031a2b011b0d027b24000004027b23000004081f5b2e03192b01169e027b1f0000042c1d027b25000004027b23000004027b1f00000409060304056f1f0000069e02027b2300000417d67d23000004027b21000004027b210000047b2e000004027b23000004282200000a7d2e000004022829000006172a081f223322190d027b1c000004027c220000041201027b1e000004283a000006130438b7000000081f743327170d027b1c000004027c2200000472950000701201027b1e000004283b0000061304388b000000081f663324170d027b1c000004027c22000004729f0000701201027b1e000004283b00000613042b62081f6e3324160d027b1c000004027c2200000472ab0000701201027b1e000004283b00000613042b39081f2d2e080828330000062c27180d027b1c000004027c22000004027b1e000004283500000616fe011304027b220000040b2b05160d16130411042d0a0207282d00000626162a027b1f0000042c2c027b1f00000409060304056f1f0000061305027b1f00000411056f1e000006027b2200000406da6f0b000006172a5602157d2c00000402157d2f00000402280900000a2a1e02280900000a2a4202037d3100000402047d32000004022a0013300300550000000b000011022d02172a160a2b4102066f1800000a0b07281a00000a2c230617d6026f1f00000a2e10020617d66f1800000a281900000a2d02162a0617d60a2b0a07281900000a2c02162a0617d60a06026f1f00000a32b6172a42021f303209021f39fe0216fe012a162a4a032c0803176a6f0400000602024a17d6542a00000013300200540100000c000011034a026f1f00000a2f1302034a6f1800000a1f2d330703042834000006034a026f1f00000a2f1502034a6f1800000a1f303309030428340000062b4f034a026f1f00000a2f4302034a6f1800000a1f31323702034a6f1800000a1f39302b030428340000062b0703042834000006034a026f1f00000a2f1302034a6f1800000a28330000062de02b02192a034a026f1f00000a2f3f02034a6f1800000a1f2e333303042834000006034a0a2b0703042834000006034a026f1f00000a2f0f02034a6f1800000a28330000062de0034a0633021a2a034a026f1f00000a2f7402034a6f1800000a1f652e0c02034a6f1800000a1f45335c03042834000006034a026f1f00000a2f1f02034a6f1800000a1f2b2e0c02034a6f1800000a1f2d330703042834000006034a0b2b0703042834000006034a026f1f00000a2f0f02034a6f1800000a28330000062de0034a0733021b2a162a133003001e0000000c000011160a0212001428350000060b072d0d06026f1f00000a2e021c2a162a072a5e021f202e10021f092e0b021f0d2e06021f0afe012a172a8e2b0703042834000006034a026f1f00000a2f0f02034a6f1800000a28370000062de02ad6021f303205021f393126021f613205021f663114021f413205021f463102152a021f41da1f0ad62a021f61da1f0ad62a021f30da2a13300200fb0000000d00001104034a54034a026f1f00000a2f0c02034a6f1800000a1f222e02162a0305283400000638c0000000034a0a02034a6f1800000a0b03052834000006071f223302172a071f202f05040654162a071f5c4094000000034a026f1f00000a330604034a54162a034a0c02034a6f1800000a0d03052834000006091f75333f1613042b33034a026f1f00000a330604034a54162a02034a6f1800000a2839000006162f0604034a54162a03052834000006110417d6130411041a32c82b2d091f222e28091f5c2e23091f2f2e1e091f622e19091f662e14091f6e2e0f091f722e0a091f742e05040854162a034a026f1f00000a3f33ffffff04034a54162a00133003005d0000000e000011160a2b40034a06d6026f1f00000a320805034a06d654162a0e042c090e04176a6f0400000602034a06d66f1800000a04066f1800000a2e0805034a06d654162a0617d60a06046f1f00000a32b703034a046f1f00000ad654051554172ac203172e0e032c0b72b5000070732300000a7a022d0b72c3000070731e00000a7a02031414167328000006282b0000062a0000133006005a0000000f000011022d0b72c3000070731e00000a7a042d0b7273000070731e00000a7a03173208032080000000310b72c7000070730a00000a7a041a6a6f040000060204731c0000060a0602160406037328000006282b0000066f1a000006062a000013300400ed000000100000110272e10000701a6f2400000a162f02162a160a160b160c38c300000002086f1800000a0d062d12091f223304170a160b0817d60c38a6000000091f223310072c02182a160a0817d60c3891000000091f5c3349020817d66f1800000a130411041f75332f160d1613052b1d091f10d8020818d61105d66f1800000a2839000006d60d110517d6130511051a32de081cd60c2b0d11040d0818d60c2b040817d60c072c16092000dc000032080920ffdf00003102192a160b2b26092000d80000320c0920ffdb00003004170b2b12092000dc0000320a0920ffdf000030021a2a08026f1f00000a3f31ffffff162ad2021f222e0a021f5c2e05021f2f3302182a021e2e14021f0c2e0f021f0a2e0a021f0d2e05021f093302182a021f203202172a1c2a0000133002002a00000011000011166a0a020b160c2b1607086f1800000a0d0609283f0000066ad60a0817580c08076f1f00000a32e1062a0000133004001501000012000011732500000a0a020b160c38f300000007086f1800000a0d091f22352a091e594506000000460000007e000000620000008c0000005400000070000000091f222e113882000000091f2f2e29091f5c2e132b760672e70000706f2600000a26389b0000000672ed0000706f2600000a26388a0000000672f30000706f2600000a262b7c0672f90000706f2600000a262b6e0672ff0000706f2600000a262b600672050100706f2600000a262b5206720b0100706f2600000a262b440672110100706f2600000a262b36091f202f290672e10000706f2600000a260609130412047217010070282700000a282800000a6f2600000a262b0806096f1b00000a260817580c08076f1f00000a3f01ffffff066f1d00000a2a00000013300400690100001300001173300000060a06052c0c186a056f1f00000a6ad82b02166a7d3400000406022c03032d04166a2b0a186a036f1f00000a6ad87d35000004022c25032c15036f1f00000a2c0d036f1f00000a2000040000310d062063d100001728310000062a042c09046f1f00000a1d310d062065d100001828310000062a04721d010070282900000a2c410472ab000070282900000a2c3404722b010070282900000a2c2704723b010070282900000a2c1a047249010070282900000a2c0d062065d100001728310000062a0472ab000070282a00000a0514fe012e0d062066d100001728310000062a060472ab000070282a00000a2d08067b340000042b021e6a04721d010070282a00000a2d03162b011a6ad6022d04166a2b09067b350000041c6ad6d67d3600000406177d3a000004022c1c0328320000062d1406177d39000004062067d100001728310000062a0528320000062d1406187d39000004062067d100001728310000062a062a00000013300500ae010000140000110203040528420000060a067b310000042c02062a047249010070282a00000a2c5a06050e04283c0000067d30000004067b300000047b2b00000418330d0620900300001728310000062a067b300000047b2b0000042c0d062068d100001828310000062a05283e0000060d092c0d062067d100000928310000062a04722b010070282a00000a2c27057295000070282900000a2c1a05729f000070282900000a2c0d062068d100001728310000062a04723b010070282a00000a2c1a052836000006130411042c0e062068d10000110428310000062a04721d010070282a00000a2d190472ab000070282a00000a2d08056f1f00000a2b011a6a2b09052840000006186ad6022d04166a2b09032840000006196ad6d60b06186a07d87d370000040e052d02062a04721d010070282a00000a2d170472ab000070282a00000a2d03052b1c72ab0000702b1572530100700528410000067253010070282b00000a0c06022d03082b167253010070032841000006725701007008282c00000a7d3300000406177d38000004067b37000004186a067b330000046f1f00000a6ad82e0b725d010070731300000a7a062a000042534a4201000100000000000c00000076342e302e33303331390000000005006c0000003c0c0000237e0000a80c00008809000023537472696e67730000000030160000680100002355530098170000100000002347554944000000a81700004003000023426c6f620000000000000002000001571fa2090900000000fa013300160000010000001c0000000c0000003a0000004300000057000000020000002c0000000c0000002500000014000000030000000d000000170000000400000001000000010000000000d40401000000000006007303c20606009303c2060600fa0289060f00e206000006002203500506005603500506003903500506000e03a3060600dc07f8040600d605f80406000c05f8040600df02c206060021005b0006002e005b0006004906d20806000d005b00060001005b0006006b05f80406002404f80406009d05f80406002906f80406008705f80406003504f80406002800f8040600ce05f8040600fc05f80406001b063b0506003906f804000000004100000000000100010001011000e707620225000100010001011000b705620229000300050001010000070262022d0003000600010110002d05620225000a0006000101100054086202250016001900010110006906620225001b002400000110005706620225001c0028000101000015097e072d0028002f00010110001e087e0725002b002f00010110002d087e072500300030008101100050027e0725003b0031002100cc046f0101000d046f0106064a0072015680ea0475015680160575015680320675015680240475015680dc07750156800f0975010100d80075010100790172010100460172010100610172010100bc00720101000b0172010100ab0179010100ee0079010100280172010300c00172010300b5087201030083047201210065077c012100270279012100c704840101007a008801010093018b012100c70484012100e6087901210020098f012100c70484012100660893012100a9047201210039088b010100620572010100b60472010100070797010100f10697010100b107970101004807970106064a0072015680f1058f015680e0058f010600bb0772010600f607720106009b0072010600f706720106009e047201060011058b010600350272010600ca02720106004b087901060028076f01060031076f0106000e076f0106001a076f0106008b0072010600890272010600b0008801502000000000861883069b0101008320000000008608ff03a00102008b200000000086088200a00102009a20000000008600e8019b010200c920000000008618830606000300d620000000008608f501a4010300de20000000008308fe01a9010300e7200000000086089b0831000400ef20000000008308a80801000400f820000000008608670431000500002100000000830875040100050009210000000086086f083100060011210000000083087a08010006001a21000000008608ca01310007002221000000008308d901010007002b21000000008608df03310008003321000000008308ef03010008003c210000000086082709ab00090044210000000083082f09100009004d21000000008608b103ab000a005521000000008308c10310000a005e21000000008608450431000b006621000000008308560401000b006f21000000008618830606000c008521000000008608ef08af010c008d21000000008308fa08b4010c0096210000000086088c0831000d00a3210000000083188306ba010d00c421000000008600e307c1010f00df21000000008300c204c1011000f0210000000083007600c70111000823000000008600de08d101160048230000000086003a07d6011700f823000000008600c207da011700f8240000000081003a02e001180067260000000086188306ea011c00842600000000e6014802f0011d00052700000000e6015307f6011f00342700000000e6012e02fc0121008427000000008318830601022200bc270000000081001f0206002700e1270000000081009c0606002700fc270000000083000d06af0127005c2b000000008100920201002700ac2b000000008100fe080d022800e82b000000008100cb0313022900542e000000008618830606002c006a2e000000008618830606002c00722e0000000091007d061a022c00842e0000000091003b0023022f00e52e0000000093001208a0003000f62e0000000093001f02280231000c2f0000000093002e06300233006c30000000009100c402390236009630000000009100d902a0003700ae300000000093009c063e023800d230000000009300050947023b00083100000000930017044c023c001032000000009300ff04570240007932000000009600e80563024500ac320000000096005a076b0247001433000000009100b70239024a000d34000000009100a50747024b004434000000009100980774024c007c34000000009100410279024d00a03500000000960047097e024e001837000000009600d0028702520000000100040500000100cd0800000100d10300000100d10300000100d10300000100d10300000100d10300000100d10300000100d10300000100d10300000100d10300000100d10300000100270200000200c70400000100090900000100090900000100150200000200c70800000300850800000400be08000005008d04000001000909020001001e0500000100c70800000200970402000300390802000400760700000100c704000001000708000002000c08000001000708000002000c0800000100d10300000100e60800000200200900000300c70400000400660800000500a90400000100960800000100180800000100850800000200be08000003008d0400000100870600000200740000000300d307000001000d0900000100740000000100270600000200c704000001000d0900000200bc0410100300c704000001000d09000001007400000001000d0900000200270610100300c704000001007400000001000d0900000200270602000300180810100400c704000001000d09000002002706000003001a0202000400180810100500c704000001000d09000002002009000001000d0900000200a90400000300c704000001000d09000001007400000001000d09000001000d0900000100be0400000200430900000300150200000400d10300000100be0400000200430900000300150200000400d1030000050020090000060040080700060007000a00090083060100110083060600190083060a002900830610003100830610003900830610004100830615006100830606004900830606009100830610005100830610001c008c0831001c00830606001c00ef0435001c00540931001c00610901001c007600440099002b044f00a1008306100024008306750024003709800024007600860079008306010099006c079b00a900a802a000a9009802a0007900ee01a50079003a04310049002204ab00b1008306100099003a043100b9003705b500c1001106bb00b900eb08b500c900830610009900d703fc007900830606007900ee011301d90074021901c10022041e0199007a092a0199006e092a019900d50739019900d5074001080010005101080014005601080018005b0108001c006001080020006501080024006a010800a40051010800a80056011200d50051011200e90051011200fd0051011200110151012e000b00a9022e001300b2022e001b00d1022e002300da022e002b00f1022e0033002d032e003b003a03c00043005601e00043005601000143005601200143005601400143005601410143005601600143005601610143005601800143005601810143005601a00143005601a10143005601c00143005601c10143005601e00143005601e10143005601000243005601010243005601200243005601210243005601400243005601410243005601600243005601800243005601a00243005601c00243005601e0024300560120034300560140034300560141034300560126003b004a0055005d008e00af00c000c500ce00d800dd00e200ea00ee00f30003010a0125013001020001000500030006000c000000030493020000860093020000100297020000ac089c02000079049c0200007e089c020000dd019c020000f3039c0200003f09a0020000c503a00200005a049c020000fe08a402000090089c0202000200030002000300050002000600070001000700070002000800090001000900090002000a000b0001000b000b0002000c000d0001000d000d0002000e000f0001000f000f0002001000110001001100110002001200130001001300130002001400150001001500150002001600170001001700170002001900190001001a00190002001b001b001a0020002a006e0004800000010000000000000000000000000062020000040000000000000000000000480152000000000000000049436f6d706172657260310049457175616c697479436f6d70617265726031004c697374603100496e7433320044696374696f6e6172796032005574663136003c4d6f64756c653e0076616c75655f5f006d73636f726c69620053797374656d2e436f6c6c656374696f6e732e47656e6572696300416464006465636f646564006765745f55736564004f7574707574416c6c6f6361746564004d61784f70656e44657074684f62736572766564005374726f6e6756616c6964003c46697273744368696c643e6b5f5f4261636b696e674669656c64003c4b696e643e6b5f5f4261636b696e674669656c64003c537472696e6756616c75653e6b5f5f4261636b696e674669656c64003c4e6578745369626c696e673e6b5f5f4261636b696e674669656c64003c5363616c61724c656e6774683e6b5f5f4261636b696e674669656c64003c5261774c656e6774683e6b5f5f4261636b696e674669656c64003c506172656e743e6b5f5f4261636b696e674669656c64003c52617753746172743e6b5f5f4261636b696e674669656c64003c53796e7461783e6b5f5f4261636b696e674669656c64003c4b65793e6b5f5f4261636b696e674669656c64004c6173744368696c64006765745f46697273744368696c64007365745f46697273744368696c64005370656e6400417070656e64006765745f4b696e64007365745f4b696e64004a736f6e56616c75654b696e64006b696e6400776f726400416476616e636500736f757263650047657448617368436f6465004465636f64650045736361706500436f6d70617265004a736f6e43616e6f6e6963616c436f726500546f6f6c62656c742e4a736f6e436f7265006765745f496e76617269616e7443756c7475726500526177506861736500436c6f736500497348696768537572726f676174650049734c6f77537572726f67617465004465636f6465645374617465004e756d6265725374617465004576616c7561746500576869746500436f6d70696c657247656e6572617465644174747269627574650044656275676761626c6541747472696275746500436f6d56697369626c6541747472696275746500417373656d626c795469746c6541747472696275746500417373656d626c7946696c6556657273696f6e41747472696275746500417373656d626c794465736372697074696f6e41747472696275746500436f6d70696c6174696f6e52656c61786174696f6e734174747269627574650052756e74696d65436f6d7061746962696c697479417474726962757465006765745f537472696e6756616c7565007365745f537472696e6756616c75650076616c756500496e6465784f66006765745f4e6578745369626c696e67007365745f4e6578745369626c696e67006765745f52656d61696e696e670072656d61696e696e67004a736f6e537472696e6700546f537472696e6700537562737472696e67004d617468006765745f4c656e677468006765745f5363616c61724c656e677468007365745f5363616c61724c656e677468006765745f5261774c656e677468007365745f5261774c656e677468004b65794c656e677468006b65794c656e677468006c656e6774680056616c69644465707468006d6178696d756d44657074680064657074680069006f626a005065656b00776f726b00696e697469616c00546f6f6c62656c742e4a736f6e436f72652e646c6c004e756c6c006765745f4974656d0053797374656d0041746f6d006d6178696d756d00456e756d005363616e00426f6f6c65616e006475706c6963617465546f6b656e004a736f6e546f6b656e004d696e0053797374656d2e476c6f62616c697a6174696f6e0053797374656d2e5265666c656374696f6e00706f736974696f6e00417267756d656e744f75744f6652616e6765457863657074696f6e00417267756d656e744e756c6c457863657074696f6e00496e76616c69644f7065726174696f6e457863657074696f6e004a736f6e576f726b4c696d6974457863657074696f6e00417267756d656e74457863657074696f6e004167664a736f6e005363616e4a736f6e004c65676163794a736f6e00537472696e67436f6d70617269736f6e0052756e00436f6d70617265546f0043756c74757265496e666f0070004368617200526561644e756d6265720049466f726d617450726f766964657200537472696e674275696c646572004a736f6e53796e7461785363616e6e6572004a736f6e4f7264696e616c436f6d7061726572004572726f72002e63746f720053797374656d2e446961676e6f7374696373005370616365730053797374656d2e52756e74696d652e496e7465726f7053657276696365730053797374656d2e52756e74696d652e436f6d70696c6572536572766963657300446562756767696e674d6f646573006e6f646573004d617853746f7265644672616d6573006672616d6573005374726f6e67427974657300467261676d656e744279746573005261774279746573004b65794279746573004465636f6465537472696e6773006b65794c656e6774687300457175616c73005363616e546f6b656e7300746f6b656e73006765745f4368617273007363616c61727300546f6f6c62656c742e4a736f6e436f6e7374727563746f72730045736361706564556e69747300457363617065556e697473006b65795374617274730053746174757300436865636b4475706c69636174654b65797300436f6e636174004f626a65637400476574004a736f6e576f726b4275646765740046697273744661756c744f6666736574006c656674007269676874004469676974006661756c74004a736f6e5363616e526573756c7400456e747279526573756c7400726573756c74006d6174657269616c697a65467261676d656e74004a736f6e546f6b656e446f63756d656e7400646f63756d656e74006765745f506172656e74007365745f506172656e7400706172656e74006765745f436f756e7400736c6f74006765745f5261775374617274007365745f5261775374617274004b65795374617274006b6579537461727400737461727400636f73740053797374656d2e5465787400526177546578740074657874004d6178006765745f53796e746178007365745f53796e7461780048657800696e646578004172726179004a736f6e506f6c69637900706f6c696379006765745f4b6579007365745f4b657900436f6e7461696e734b6579006b6579005261774f6e6c79456e747279006765745f4361706163697479007365745f4361706163697479006f705f457175616c697479006f705f496e657175616c69747900000f6d006100780069006d0075006d00000963006f007300740000214500560041004c0055004100540049004f004e005f004c0049004d0049005400001954004f004b0045004e005f00530059004e00540041005800001b54004f004b0045004e005f0055004e00490043004f0044004500000977006f0072006b00000b760061006c0075006500000b4600520041004d00450000097400720075006500000b660061006c007300650000096e0075006c006c00000d50004f004c004900430059000003780000196d006100780069006d0075006d004400650070007400680000055c00750000055c00220000055c005c0000055c002f0000055c00620000055c00660000055c006e0000055c00720000055c007400000578003400000d73007400720069006e006700000f62006f006f006c00650061006e00000d6e0075006d0062006500720000096a0073006f006e0000032200000522003a00000943004f00530054000000d02ce87dbe9a2c4f8cdfa14da448aa4a00042001010803200001052001011111042001010e042001010205151241010e05151245010e0307010a061512350112140320000805200113000808070412140808121405200101130004070112140520020e0808070704081214080e10070708121408151239020e080808121406151239020e080a2002010815124101130005200102130007200201130013010c070908123d0208080303080804200103080400010203052001123d030320000e0507030808080500020808080420010808040702090808070608080803080809070608080311100208040702080304070208080707050803080308030701080407011218080706020208080808062002080e11690607040a0e0803080705123d0e080308052001123d0e040000126d0620020e0e1271040701122c050002020e0e080705122c0a0e08080600030e0e0e0e0700040e0e0e0e0e08b77a5c561934e08904000000000401000000040200000004030000000404000000040500000002060a0206080306111002060e07061512350112140306120802060203061228030611240306121803061d08042001010a0320000a04200011100520010111100420001228052001011228062002010e1208052001121408092005081110080808080420010e0803200002052001021008092004020808100e1008052001011208052002080e0e052002020e0e042001080e0b2005010e1124120812180805200112280806200302080808080003122c122c0808040001020e0700020110081208080003080e10081208040001080e080003010e1008120804000108030a0004020e1008100812080b0005020e10080e1008120807000212280e112408000312180e0812080400010a0e0400010e0e080004122c020e0e0e0b0006122c020e0e0e1124020328000a0428001110032800080328000e04280012280801000800000000001e01000100540216577261704e6f6e457863657074696f6e5468726f77730108010002000000000016010011546f6f6c62656c742e4a736f6e436f726500003b0100364b616e6f6e69736368657220746563686e697363686572204a534f4e2d4b65726e206f686e652053514c2d456e747279706f696e747300000c010007312e302e302e300000050100000000000000000000000000000000100000000000000000000000000000000054000000000000000000001a5400000020000000000000000000000000000000000000000000000c540000000000000000000000005f436f72446c6c4d61696e006d73636f7265652e646c6c0000000000ff2500200010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100100000001800008000000000000000000000000000000100010000003000008000000000000000000000000000000100000000004800000058600000140300000000000000000000140334000000560053005f00560045005200530049004f004e005f0049004e0046004f0000000000bd04effe00000100000001000000000000000100000000003f000000000000000400000002000000000000000000000000000000440000000100560061007200460069006c00650049006e0066006f00000000002400040000005400720061006e0073006c006100740069006f006e00000000000000b00474020000010053007400720069006e006700460069006c00650049006e0066006f00000050020000010030003000300030003000340062003000000086003700010043006f006d006d0065006e007400730000004b0061006e006f006e00690073006300680065007200200074006500630068006e0069007300630068006500720020004a0053004f004e002d004b00650072006e0020006f0068006e0065002000530051004c002d0045006e0074007200790070006f0069006e0074007300000000004c0012000100460069006c0065004400650073006300720069007000740069006f006e000000000054006f006f006c00620065006c0074002e004a0073006f006e0043006f00720065000000300008000100460069006c006500560065007200730069006f006e000000000031002e0030002e0030002e00300000004c001600010049006e007400650072006e0061006c004e0061006d006500000054006f006f006c00620065006c0074002e004a0073006f006e0043006f00720065002e0064006c006c0000002800020001004c006500670061006c0043006f0070007900720069006700680074000000200000005400160001004f0072006900670069006e0061006c00460069006c0065006e0061006d006500000054006f006f006c00620065006c0074002e004a0073006f006e0043006f00720065002e0064006c006c000000340008000100500072006f006400750063007400560065007200730069006f006e00000031002e0030002e0030002e003000000038000800010041007300730065006d0062006c0079002000560065007200730069006f006e00000031002e0030002e0030002e003000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005000000c0000002c3400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000,
 @Pass int=0,@Lock int,@InitialId int,@InitialOwner int,@InitialTargetOwner int,@Owner int,@OwnerName sysname,@Sql nvarchar(max),@Marker sysname,@Value sql_variant,@ModeValue nvarchar(16);
-- Qualifizierte Offline-Corezeile; keine Trustfreigabe und keine Runtimeableitung.
DECLARE @JsonCoreKnownHash varbinary(64)=0x4680e9d34a0870924b5ca003cc5983882fc8ffb653e702bcc549e5f65dde11934c55ba7b356b519503ac5ce1e2478fe64876fea0295176ff13b5b4a6ab61b894,
 @JsonCoreArtifactId varchar(64)='975d4a84bb86e80b6e5844d6e86785ae0e98b13ee44c0f66c021507a23e0f888',
 @JsonCoreId int,@JsonCoreOwner int,@JsonCoreHash varbinary(64),
 @JsonCoreVersion nvarchar(max),@JsonCoreStoredMode nvarchar(max),
 @JsonCoreExpectedMode nvarchar(max),@JsonCoreRequired bit=1,@JsonCoreRemoving bit=0;
DECLARE @JsonCoreMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);
IF CONVERT(varbinary(max),@Mode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))
 THROW 55621,N'JSON Core: ungültiger Deploymentmodus.',1;
IF @Bits IS NULL OR HASHBYTES(N'SHA2_512',@Bits)<>@JsonCoreKnownHash
 THROW 55623,N'JSON Core: Targetbinary ist kein bekanntes qualifiziertes Artefakt.',1;
SELECT @JsonCoreExpectedMode=@Mode,@JsonCoreRequired=0;
SET @ModeValue=CONVERT(nvarchar(16),@Mode);
BEGIN TRY
 WHILE @Pass<2
 BEGIN
  IF COALESCE(TRY_CONVERT(int,SERVERPROPERTY(N'ProductMajorVersion')),0) NOT IN(15,16,17)
   OR COALESCE((SELECT compatibility_level FROM sys.databases WHERE database_id=DB_ID()),0)<150
   THROW 55620,N'JSON Core: SQL-Version oder Compatibility Level nicht unterstützt.',1;
-- Pure SQLCMD-Include: keine Helper-USP, Mutation, Trust- oder Ownerreparatur.
-- KnownArtifact.sql deklariert den Scope. Aufruf vor/unter der gemeinsamen Lock.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 THROW 55622,N'JSON Core: vollständige Assemblymetadatensicht fehlt.',1;
SELECT @JsonCoreId=NULL,@JsonCoreOwner=NULL,@JsonCoreHash=NULL,@JsonCoreVersion=NULL,@JsonCoreStoredMode=NULL;
SELECT @JsonCoreVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.Version';
SELECT @JsonCoreStoredMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode';
SELECT @JsonCoreId=a.assembly_id,@JsonCoreOwner=a.principal_id,@JsonCoreHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonCore';
IF @JsonCoreId IS NULL
BEGIN
 IF @JsonCoreRequired=1 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0
  AND name IN(N'Toolbelt.Module.toolbelt.json.core.Version',N'Toolbelt.Module.toolbelt.json.core.DeploymentMode'))
  THROW 55623,N'JSON Core: erforderliche bekannte Dependency fehlt oder ist inkohärent.',1;
END
ELSE
BEGIN
 IF @JsonCoreVersion IS NULL OR CONVERT(varbinary(max),@JsonCoreVersion)<>CONVERT(varbinary(max),N'1.0.0')
  OR @JsonCoreStoredMode IS NULL OR CONVERT(varbinary(max),@JsonCoreStoredMode)<>CONVERT(varbinary(max),@JsonCoreExpectedMode)
  OR @JsonCoreHash IS NULL OR @JsonCoreHash<>@JsonCoreKnownHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@JsonCoreId AND is_user_defined=1 AND permission_set=1 AND is_visible=0
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonCore'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@JsonCoreId)<>1
  THROW 55623,N'JSON Core: keine kohärente bekannte technische SAFE-Assembly.',1;
 DELETE FROM @JsonCoreMarkers;
 INSERT @JsonCoreMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.core'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.0.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@JsonCoreExpectedMode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@JsonCoreKnownHash)),
 (N'Toolbelt.ArtifactId',CONVERT(sql_variant,@JsonCoreArtifactId));
 IF EXISTS(SELECT 1 FROM @JsonCoreMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@JsonCoreId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value)
   AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55623,N'JSON Core: typisiertes bekanntes Markertuple ist inkohärent.',1;
 -- Die technische Dependency stellt keine eigenen oder fremden SQL-Slots bereit.
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: direkter SQL-Verbraucher blockiert den technischen Corevertrag.',1;
 IF @JsonCoreRemoving=1 AND EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: verbleibende Assemblyverbraucher blockieren den Abbau.',1;
END;
  IF @Pass=1 AND (COALESCE(@JsonCoreId,-1)<>COALESCE(@InitialId,-1) OR COALESCE(@JsonCoreOwner,-1)<>COALESCE(@InitialOwner,-1))
   THROW 55627,N'JSON Core: Assemblyidentität hat sich unter Lock verändert.',1;
  IF @JsonCoreId IS NULL
  BEGIN
   IF NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr enabled' AND value_in_use=1)
    OR NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr strict security' AND value_in_use=1)
    OR COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE ASSEMBLY'),0)<>1
    THROW 55622,N'JSON Core: CLR-Konfiguration oder vorhandenes CREATE-ASSEMBLY-Recht fehlt.',1;
   SELECT @Owner=COALESCE((SELECT principal_id FROM sys.schemas WHERE name=N'toolbelt_json'),USER_ID());
   IF @Owner IS NULL THROW 55622,N'JSON Core: vorhandener Zielowner ist nicht sichtbar.',1;
   IF @Pass=1 AND @Owner<>@InitialTargetOwner THROW 55627,N'JSON Core: Zielowner hat sich unter Lock verändert.',1;
  END;
  IF @Pass=0
  BEGIN
   SELECT @InitialId=@JsonCoreId,@InitialOwner=@JsonCoreOwner,@InitialTargetOwner=@Owner;
   BEGIN TRANSACTION;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.json.shared-core',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock IS NULL OR @Lock<0 THROW 55627,N'JSON Core: gemeinsame AppLock nicht verfügbar.',1;
  END;
  SET @Pass+=1;
 END;
 IF @JsonCoreId IS NULL
 BEGIN
  SET @OwnerName=USER_NAME(@Owner);
  IF @OwnerName IS NULL THROW 55622,N'JSON Core: vorhandener Zielowner ist nicht sichtbar.',1;
  SET @Sql=N'CREATE ASSEMBLY [Toolbelt_JsonCore] AUTHORIZATION '+QUOTENAME(@OwnerName)+N' FROM '+CONVERT(nvarchar(max),@Bits,1)+N' WITH PERMISSION_SET=SAFE;';
  EXEC sys.sp_executesql @Sql;
  ALTER ASSEMBLY [Toolbelt_JsonCore] WITH VISIBILITY=OFF;
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Module.toolbelt.json.core.Version',@value=N'1.0.0';
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode',@value=@ModeValue;
  INSERT @JsonCoreMarkers VALUES
  (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
  (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.core'))),
  (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.0.0'))),
  (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@Mode))),
  (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@JsonCoreKnownHash)),
  (N'Toolbelt.ArtifactId',CONVERT(sql_variant,@JsonCoreArtifactId));
  WHILE EXISTS(SELECT 1 FROM @JsonCoreMarkers)
  BEGIN
   SELECT TOP(1) @Marker=Name,@Value=Value FROM @JsonCoreMarkers ORDER BY Name;
   EXEC sys.sp_addextendedproperty @name=@Marker,@value=@Value,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_JsonCore';
   DELETE FROM @JsonCoreMarkers WHERE Name=@Marker;
  END;
 END;
 SELECT @JsonCoreRequired=1;
-- Pure SQLCMD-Include: keine Helper-USP, Mutation, Trust- oder Ownerreparatur.
-- KnownArtifact.sql deklariert den Scope. Aufruf vor/unter der gemeinsamen Lock.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 THROW 55622,N'JSON Core: vollständige Assemblymetadatensicht fehlt.',1;
SELECT @JsonCoreId=NULL,@JsonCoreOwner=NULL,@JsonCoreHash=NULL,@JsonCoreVersion=NULL,@JsonCoreStoredMode=NULL;
SELECT @JsonCoreVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.Version';
SELECT @JsonCoreStoredMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode';
SELECT @JsonCoreId=a.assembly_id,@JsonCoreOwner=a.principal_id,@JsonCoreHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonCore';
IF @JsonCoreId IS NULL
BEGIN
 IF @JsonCoreRequired=1 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0
  AND name IN(N'Toolbelt.Module.toolbelt.json.core.Version',N'Toolbelt.Module.toolbelt.json.core.DeploymentMode'))
  THROW 55623,N'JSON Core: erforderliche bekannte Dependency fehlt oder ist inkohärent.',1;
END
ELSE
BEGIN
 IF @JsonCoreVersion IS NULL OR CONVERT(varbinary(max),@JsonCoreVersion)<>CONVERT(varbinary(max),N'1.0.0')
  OR @JsonCoreStoredMode IS NULL OR CONVERT(varbinary(max),@JsonCoreStoredMode)<>CONVERT(varbinary(max),@JsonCoreExpectedMode)
  OR @JsonCoreHash IS NULL OR @JsonCoreHash<>@JsonCoreKnownHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@JsonCoreId AND is_user_defined=1 AND permission_set=1 AND is_visible=0
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonCore'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@JsonCoreId)<>1
  THROW 55623,N'JSON Core: keine kohärente bekannte technische SAFE-Assembly.',1;
 DELETE FROM @JsonCoreMarkers;
 INSERT @JsonCoreMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.core'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.0.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@JsonCoreExpectedMode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@JsonCoreKnownHash)),
 (N'Toolbelt.ArtifactId',CONVERT(sql_variant,@JsonCoreArtifactId));
 IF EXISTS(SELECT 1 FROM @JsonCoreMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@JsonCoreId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value)
   AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55623,N'JSON Core: typisiertes bekanntes Markertuple ist inkohärent.',1;
 -- Die technische Dependency stellt keine eigenen oder fremden SQL-Slots bereit.
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: direkter SQL-Verbraucher blockiert den technischen Corevertrag.',1;
 IF @JsonCoreRemoving=1 AND EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: verbleibende Assemblyverbraucher blockieren den Abbau.',1;
END;
 COMMIT;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.json.core
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.string.edit-distance
:On Error exit
-- RETURN beendet den gesamten ersten Batch; SQLCMD stoppt vor weiteren Batches.
IF @@TRANCOUNT <> 0
BEGIN
    RAISERROR(N'Der Editierdistanz-Lifecycle akzeptiert keine Caller-Transaktion.', 16, 1);
    RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @VersionProperty sysname = N'Toolbelt.Module.toolbelt.string.edit-distance.Version',
        @ModeProperty sysname = N'Toolbelt.Module.toolbelt.string.edit-distance.DeploymentMode',
        @InstalledVersion nvarchar(max), @InstalledMode nvarchar(max),
        @Release int, @AssemblyId int, @InstalledAssemblyHash varbinary(64),
        @Pass int = 1, @OwnTransaction bit = 0;
DECLARE @Slots TABLE (Name sysname COLLATE DATABASE_DEFAULT PRIMARY KEY, SinceRelease int NOT NULL,
                      Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL, ObjectId int NULL);
INSERT @Slots(Name, SinceRelease, Kind) VALUES
    (N'TVF_LevenshteinDistance', 10, 'IF'),
    (N'TVF_OsaDistance', 10, 'IF'),
    (N'TVF_LevenshteinDistanceCore', 10, 'FT'),
    (N'TVF_OsaDistanceCore', 10, 'FT'),
    (N'TVF_JaroWinklerSimilarity', 11, 'IF'),
    (N'TVF_JaroWinklerSimilarityCore', 11, 'FT');
DECLARE @DeploymentMode nvarchar(16) = N'central',
        @AssemblyBits varbinary(max) = 0x4d5a90000300000004000000ffff0000b800000000000000400000000000000000000000000000000000000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a2400000000000000504500004c0103008ca3d2ff0000000000000000e00022200b013000002000000006000000000000b23e0000002000000040000000000010002000000002000004000000000000000600000000000000008000000002000000000000030060850000100000100000000010000010000000000000100000000000000000000000603e00004f00000000400000b803000000000000000000000000000000000000006000000c000000443e00001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000080000000000000000000000082000004800000000000000000000002e74657874000000b81e0000002000000020000000020000000000000000000000000000200000602e72737263000000b8030000004000000004000000220000000000000000000000000000400000402e72656c6f6300000c0000000060000000020000002600000000000000000000000000004000004200000000000000000000000000000000943e0000000000004800000002000500fc2c00004811000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001330060053000000010000110f02280a00000a2d06026a036ad82a0f02280b00000a0203280c00000a280d00000a0a166a0b170c2b230716030806d6280d00000a170806da280c00000ada17d6280c00000a6ad60b0817d60c080231d9072a001b300700dd03000002000011730f0000060a022c03032d02062a057201000070280e00000a2c16057213000070280e00000a2c0906177d03000004062a0f02280a00000a2c130f02280b00000a162f0906187d03000004062a057213000070280f00000a252d0720000800002b0520000001000b252d0720000400002b0520008000000c2d0820000010006a2b0620000000016a0d026f1000000a073009036f1000000a07310906197d03000004062a0002280d000006130403280d0000061305de1026061a7d0300000406130ddd1303000011040830051105083109061b7d03000004062a0f02280a00000a2c2111041105da281100000a0f02280b00000a310e0617731200000a7d02000004062a06110411050428010000067d05000004067b05000004093109061c7d03000004062a11042c0411052d220611041105280c00000a731300000a7d010000040616731200000a7d02000004062a021104280e0000061306031105280e00000613070f02280a00000a2d0b11041105280c00000a2b150f02280b00000a11041105280c00000a280d00000a130811041105280c00000a17d61309110517d68d17000001130a110517d68d17000001130b0e042d03142b09110517d68d17000001130c061a6a11041105d66a0e042d04186a2b02196a110517d66ad8d6d87d0600000416130e2b3f110a110e110e1108310411092b02110e9e110b110e11099e0e042c07110c110e11099e06257b070000040e042d03182b01196ad67d07000004110e17d6130e110e110531bb17130f383f01000017110f1108da280c00000a13101105110f1108d6280d00000a1311110b16110f1108310411092b02110f9e06257b08000004176ad67d080000041110173118110b111017da11099e06257b08000004176ad67d08000004111111052f18110b111117d611099e06257b08000004176ad67d0800000411101312389a000000110a11129417d6110b111217da9417d6110a111217da941106110f17da941107111217da94fe0116fe01d6280d00000a280d00000a13130e042c3c110f17313711121731321106110f17da941107111218da9433221106110f18da941107111217da9433121113110c111218da9417d6280d00000a1313110b111211091113280d00000a9e06257b04000004176ad67d04000004111217d61312111211113e5dffffff0e042d04110a2b02110c0e042c04110a130c110b130a130b110f17d6130f110f11043eb8feffff067b04000004067b050000042e0b721f000070731400000a7a0f02280a00000a2c1c110a1105940f02280b00000a310e0617731200000a7d020000042b1c06110a110594731300000a7d010000040616731200000a7d02000004062a110d2a000000011000000000a50012b700100c000001133006004800000001000011020331060203100010011603185b17da280c00000a0a166a0b160c2b2507160317da0806d6280d00000a160806da280c00000ada17d6280c00000a6ad60b0817d60c080232d7072a1b3005006a0300000300001173100000060a022c03032d02062a047201000070280e00000a2c16047213000070280e00000a2c0906177d0a000004062a047213000070280f00000a0b026f1000000a072d0720000800002b0520000001003017036f1000000a072d0720000800002b052000000100310906197d0a000004062a0002280d0000060c03280d0000060dde1026061a7d0a000004061311ddd202000008072d0720000400002b052000800000301209072d0720000400002b0520008000003109061b7d0a000004062a06080928030000067d0b000004067b0b000004072d0820000010006a2b0620000000016a3109061c7d0a000004062a082c03092d250608092e0b2300000000000000002b0923000000000000f03f731500000a7d09000004062a0208280e00000613040309280e00000613050809fe0213060809332c1613122b22110411129411051112942e1011041112941105111294fe0213062b0b111217d6131211120832d911062c0c110411051304130508090c0d1609185b17da280c00000a1307088d170000011308098d1900000113091613132b0c11081113159e111317d6131311130832ef16130a1613142b671611141107da280c00000a13150917da11141107d6280d00000a13162b3d06257b0c000004176ad67d0c00000411091115912d211104111494110511159433151108111411159e11091115179c110a17d6130a2b0c111517d613151115111631bd111417d613141114083294067b0c000004067b0b000004310b7255000070731400000a7a06110a7d0d000004110a2d1606230000000000000000731500000a7d09000004062a16130b16130c1613172b351108111794162f082b25110c17d6130c1109110c912cf311041117941105110c942e06110b17d6130b110c17d6130c111717d6131711170832c616130d2b06110d17d6130d110d1a08280d00000a2f0c1104110d941105110d942ee306110b7d0e00000406110d7d0f000004110a6c086c5b110a6c096c5b58110a6c110b6c2300000000000000405b59110a6c5b582300000000000008405b130e186a110a6ad8110a6ad80809d66ad8186a110a6ad8110b6ada086ad8096ad8d6130f1c6a110a6ad8086ad8096ad81310061f0a6a110fd81d6a1110d83004110e2b1d110e110d6c2300000000000024405b23000000000000f03f110e595a58731500000a7d09000004062a11112a00000110000000007500108500100c00000113300600ce0000000400001173100000060a026f1600000a2d08036f1600000a2c0b178d08000002251606a22a140b046f1600000a2d1b046f1700000a1e6a2e0a046f1700000a1b6a33070428060000060b077201000070280e00000a2c1f077213000070280e00000a2c1206177d0a000004178d08000002251606a22a077213000070280f00000a2d0720000800002b0520000001000c026f1700000a086a300a036f1700000a086a311206197d0a000004178d08000002251606a22a178d080000022516022806000006032806000006072804000006a22a0000133006004a00000005000011026f1700000ab70a068d1a0000010b166a0c2b2a02080708b70608b7da6f1800000a0d09166a310709066a08da310b7271000070731400000a7a0809d60c08066a32d107731900000a2a00001330020051000000060000110275080000020a062d0b7271000070731400000a7a03067c09000004281a00000a2d077e1b00000a2b10067c09000004281c00000a731d00000a811200000104067b0a000004731e00000a81130000012a2e0203040516280a0000062a2e0203040517280a0000062a000000133005001701000007000011730f0000060a026f1600000a2d08036f1600000a2c0b178d07000002251606a22a140b056f1600000a2d1b056f1700000a1e6a2e0a056f1700000a1b6a330705280b0000060b077201000070280e00000a2c1f077213000070280e00000a2c1206177d03000004178d07000002251606a22a0f02281f00000a2d1c0f02282000000a162f1206187d03000004178d07000002251606a22a077213000070280f00000a2d0720000800002b0520000001000c026f1700000a086a300a036f1700000a086a311206197d03000004178d07000002251606a22a02280b00000603280b0000060f02281f00000a2d0e0f02282000000a731300000a2b091203fe150100001b09070e0428020000060a178d07000002251606a22a00133006004300000005000011026f1700000ab70a068d1a0000010b166a0c2b2302080708b70608b7da6f1800000a0d09166a300b7297000070731400000a7a0809d60c08066a32d807731900000a2a00133002007b000000080000110275070000020a062d0b7297000070731400000a7a03067c01000004280a00000a2d077e2100000a2b10067c01000004280b00000a731e00000a811300000104067c02000004282200000a2d077e2300000a2b10067c02000004282400000a732500000a811400000105067b03000004731e00000a81130000012a00133003006800000009000011160a160b2b5702076f2600000a0c08282700000a2c2c0717d6026f1000000a2e10020717d66f2600000a282800000a2d0b72c5000070732900000a7a0717d60b2b1308282800000a2c0b72c5000070732900000a7a0717d60b0617d60a07026f1000000a32a0062a133004003c0000000a000011038d170000010a160b160c2b2406072517d60b0208282a00000a9e02086f2600000a282700000a2c040817d60c0817d60c08026f1000000a32d3062a1e02282b00000a2a1e02282b00000a2a42534a4201000100000000000c00000076342e302e33303331390000000005006c00000038050000237e0000a4050000fc04000023537472696e677300000000a00a0000d400000023555300740b0000100000002347554944000000840b0000c405000023426c6f620000000000000002000001571502080902000000fa013300160000010000001a000000080000000f00000010000000290000002b0000000b0000000a0000000300000001000000020000000200000000008a020100000000000600ba01bb030600da01bb030600130179030f00db03000006003b01d80206009d01d80206006b01d802060027019c0306005201150206008704b60206000100b60206000403b6020a00880147030a006f0047030a00690047030600cd0061040a007e04fd030a00d900fd030a001b00fd030a00bd02fd0306003602b60206002f02b60206001e00b6020600ea02b6020600c002b60206001603b60200000000240000000000010001008001100070020000290001000100800110007f027e00290001000300810110003a037e002900010005008101100029037e00290001000800800110001b03ae00290001000d000201100062030000290001000f00020110006203000029000900100006009200040106008c030b0106006903120106005b0415010600520415010600360415010600120415010600270415010600e60418010600690312010600460215010600520215010600ea0312010600f20312010600c0041201502000000000960045041f010100b0200000000096000a012a010400ac240000000096005e023801090000250000000096000a013e010b0088280000000096000a0146010e006429000000009100c70451011100bc29000000009600b00457011200192a000000009600cc0262011500252a0000000096002d0062011900342a000000009100c6006f011d00582b000000009100c70451012200a82b000000009600b0047d012300302c0000000096008e048b012700a42c0000000096004f0090012800ec2c0000000086186f0306002a00f42c0000000086186f0306002a0000000100140300000200bb02000003005f00000001009a04000002009f04000003005f0000000400e30000000500310000000100140300000200bb02000001009a04000002009f0400000300e300000001009a04000002009f0400000300e300000001000f0200000100b80402000200f10402000300a400000001009a04000002009f04000003005f0000000400e300000001009a04000002009f04000003005f0000000400e300000001009a04000002009f04000003005f0000000400e300000005003100000001000f0200000100b804020002009b0002000300940302000400a40000000100ab0400000100ab0400000200a50409006f03010011006f03060019006f030a0029006f03100031006f03100039006f03100041006f03150049006f03100069006f0306000c00020226000c00f8012a00a900bc042f00a900c8022f00b100d8045300b100cc045300b1003b025900a90075035d0014006f0368000c006f036800c1006f0310001c006f0368008900ab02260089003b029c0089004a00a800b1006f03b1001c00020226009100b102bc001c00f8012a0091006f03c00099006f0301009900ab0226009900f80159009900b102d600140002022600a100b102da001400f8012a00a1006f031500b1007404e400d100eb00e900d100fb00e90061006f031000d1000c00f50051006f0306002e000b0097012e001300a0012e001b00bf012e002300c8012e002b00ea012e00330026022e003b0033022e0043003902a0004b00830200014b00190420014b0019041a0035006e009500a000b700c500d100de00ee00200062008f000480000001000100000000000000000000007e000000040000000000000000000000fb00410000000000040000000000000000000000fb0035000000000007000200080003000000004e756c6c61626c65603100436f6e76657274546f55746633320053716c496e743332003c4d6f64756c653e004f7361006f73610053797374656d2e44617461006d73636f726c69620052656164004465636f646556616c696461746564007468726573686f6c640053797374656d446174614163636573734b696e6400546f6f6c62656c742e537472696e672e4564697444697374616e63650064697374616e6365006572726f72436f646500546f6f6c62656c742e537472696e672e556e69636f646500496e766f6b650049456e756d657261626c650053716c446f75626c650070726f66696c6500497348696768537572726f676174650049734c6f77537572726f67617465004576616c756174650044656275676761626c6541747472696275746500436f6d56697369626c6541747472696275746500417373656d626c795469746c65417474726962757465005461726765744672616d65776f726b41747472696275746500417373656d626c7946696c6556657273696f6e4174747269627574650053716c46756e6374696f6e41747472696275746500417373656d626c794465736372697074696f6e41747472696275746500436f6d70696c6174696f6e52656c61786174696f6e734174747269627574650052756e74696d65436f6d7061746962696c697479417474726962757465006765745f56616c7565006765745f48617356616c75650076616c75650053797374656d2e52756e74696d652e56657273696f6e696e6700537472696e67004d617468006765745f4c656e67746800506c616e6e6564576f726b0056697369746564576f726b00506c616e6e656457696e646f77576f726b0044697374616e63654b65726e656c004a61726f4b65726e656c00546f6f6c62656c742e537472696e672e4564697444697374616e63652e646c6c006765745f49734e756c6c0053797374656d0053716c426f6f6c65616e004d696e004c6576656e73687465696e0053797374656d2e5265666c656374696f6e00496e76616c69644f7065726174696f6e457863657074696f6e00417267756d656e74457863657074696f6e004368617200556e69636f64655363616c61720044697374616e636550726f7669646572004a61726f50726f7669646572004d6963726f736f66742e53716c5365727665722e53657276657200416e73776572004572726f72002e63746f72004162730053797374656d2e446961676e6f7374696373004578636565647300657863656564730053797374656d2e52756e74696d652e496e7465726f7053657276696365730053797374656d2e52756e74696d652e436f6d70696c6572536572766963657300446562756767696e674d6f646573004d617463686573004d69736d6174636865730053797374656d2e446174612e53716c547970657300496e697469616c697a6174696f6e57726974657300426f756e6461727957726974657300496e74427566666572427974657300506c616e6e656443656c6c730050726564696374656443656c6c730053797374656d2e436f6c6c656374696f6e73006765745f43686172730053716c4368617273004f626a65637400436f756e74537472696374006c65667400726967687400636f756e7400746578740046696c6c526f7700726f77004d61780050726566697800436f7079006f705f457175616c697479006f705f496e657175616c6974790053696d696c61726974790073696d696c61726974790000117300740061006e006400610072006400000b6c00610072006700650000355400420058005f00440049005300540041004e00430045005f0057004f0052004b005f004d00490053004d004100540043004800001b5400420058005f004a00410052004f005f0057004f0052004b0000255400420058005f004a00410052004f005f005400520041004e00530050004f0052005400002d5400420058005f00440049005300540041004e00430045005f005400520041004e00530050004f0052005400000b55005400460031003600000000009eb7a62a1154874594beefe2806682bd00042001010803200001052001011111042001010e0420010102050703080a080515112d01080320000204200013000500020808081d0714121c08080a08081d081d0808081d081d081d08121c080808080808050002020e0e0320000804000108080515112d010205200101130020071812200208081d081d0802081d081d02080808080d0a0a12200808080808080515112d010d06070312200e080320000a070704081d030a0a0820040a0a1d030808052001011d03040701122003061149042001010d0b0704121c0e0815112d0108040701121c0306114d03061151050703080803042001030804000102030607031d080808050002080e0808b77a5c561934e089060615112d0108060615112d010202060802060a060615112d010d0a00030a080815112d01080d0005121c0e0e15112d01080e020500020a080807000312200e0e0e0a000312411245124512450500010e12450a0003011c10114910114d0c0004124112451245114d12450d0005124112451245114d1245020d0004011c10114d10115110114d040001080e0600021d080e080801000800000000001e01000100540216577261704e6f6e457863657074696f6e5468726f7773010801000200000000002101001c546f6f6c62656c742e537472696e672e4564697444697374616e636500003b010036506f727461626c652053414645205363616c6172204c6576656e73687465696e2c204f534120756e64204a61726f2d57696e6b6c657200000c010007312e312e302e3000000501000000004901001a2e4e45544672616d65776f726b2c56657273696f6e3d76342e380100540e144672616d65776f726b446973706c61794e616d65122e4e4554204672616d65776f726b20342e3881940100060054020f497344657465726d696e697374696301540209497350726563697365005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d4461746141636365737300000000540e1146696c6c526f774d6574686f644e616d650746696c6c526f77540e0f5461626c65446566696e6974696f6e1f53696d696c617269747920666c6f61742c204572726f72436f646520696e7481a80100060054020f497344657465726d696e697374696301540209497350726563697365015455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d4461746141636365737300000000540e1146696c6c526f774d6574686f644e616d650746696c6c526f77540e0f5461626c65446566696e6974696f6e3344697374616e636520696e742c20457863656564734d617844697374616e6365206269742c204572726f72436f646520696e740000000000000000000000000010000000000000000000000000000000883e00000000000000000000a23e0000002000000000000000000000000000000000000000000000943e0000000000000000000000005f436f72446c6c4d61696e006d73636f7265652e646c6c0000000000ff250020001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001001000000018000080000000000000000000000000000001000100000030000080000000000000000000000000000001000000000048000000584000005c03000000000000000000005c0334000000560053005f00560045005200530049004f004e005f0049004e0046004f0000000000bd04effe00000100010001000000000001000100000000003f000000000000000400000002000000000000000000000000000000440000000100560061007200460069006c00650049006e0066006f00000000002400040000005400720061006e0073006c006100740069006f006e00000000000000b004bc020000010053007400720069006e006700460069006c00650049006e0066006f00000098020000010030003000300030003000340062003000000086003700010043006f006d006d0065006e0074007300000050006f0072007400610062006c0065002000530041004600450020005300630061006c006100720020004c006500760065006e00730068007400650069006e002c0020004f0053004100200075006e00640020004a00610072006f002d00570069006e006b006c00650072000000000062001d000100460069006c0065004400650073006300720069007000740069006f006e000000000054006f006f006c00620065006c0074002e0053007400720069006e0067002e004500640069007400440069007300740061006e006300650000000000300008000100460069006c006500560065007200730069006f006e000000000031002e0031002e0030002e003000000062002100010049006e007400650072006e0061006c004e0061006d006500000054006f006f006c00620065006c0074002e0053007400720069006e0067002e004500640069007400440069007300740061006e00630065002e0064006c006c00000000002800020001004c006500670061006c0043006f0070007900720069006700680074000000200000006a00210001004f0072006900670069006e0061006c00460069006c0065006e0061006d006500000054006f006f006c00620065006c0074002e0053007400720069006e0067002e004500640069007400440069007300740061006e00630065002e0064006c006c0000000000340008000100500072006f006400750063007400560065007200730069006f006e00000031002e0031002e0030002e003000000038000800010041007300730065006d0062006c0079002000560065007200730069006f006e00000031002e0031002e0030002e003000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003000000c000000b43e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000, @AssemblyHash varbinary(64);
IF TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion')) NOT IN (15, 16, 17)
    THROW 55030, N'Dieses Modul unterstützt SQL Server 2019, 2022 und 2025.', 1;
IF CONVERT(varbinary(max), @DeploymentMode) NOT IN (CONVERT(varbinary(max), N'local'), CONVERT(varbinary(max), N'central')) OR DATALENGTH(N'central') NOT IN (10,14)
    THROW 55031, N'DeploymentMode muss local oder central sein.', 1;
IF @AssemblyBits IS NULL OR DATALENGTH(@AssemblyBits) < 1024
    THROW 55043, N'AssemblyBits enthält kein plausibles Release-Binary.', 1;
SET @AssemblyHash = HASHBYTES(N'SHA2_512', @AssemblyBits);
-- Explizite Offline-Erwartung; niemals aus dem aktuellen Katalog ableiten.
DECLARE @ExpectedInstalledAssemblyHashText nvarchar(max) = N'0xc81e7a841dc0670b850f46d932337f55b6225d2a834d4480ae3d514875b84bf56261ff580df56155a59c0f8a56b6fe54e798d046329f4122e7228467cca90404',
        @ExpectedInstalledAssemblyHash varbinary(64), @ExpectedAbsence bit = 0;
IF CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText) = CONVERT(varbinary(max), N'0x')
    SET @ExpectedAbsence = 1;
ELSE
BEGIN
    IF @ExpectedInstalledAssemblyHashText IS NULL
       OR DATALENGTH(@ExpectedInstalledAssemblyHashText) <> 260
       OR CONVERT(varbinary(max), LEFT(@ExpectedInstalledAssemblyHashText, 2)) <> CONVERT(varbinary(max), N'0x')
       OR SUBSTRING(@ExpectedInstalledAssemblyHashText, 3, 128) COLLATE Latin1_General_100_BIN2 LIKE N'%[^0-9A-Fa-f]%'
       OR TRY_CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText, 1) IS NULL
       OR DATALENGTH(TRY_CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText, 1)) <> 64
        THROW 55046, N'ExpectedInstalledAssemblyHash muss 0x oder exakt 128 Hexzeichen nach 0x enthalten.', 1;
    SET @ExpectedInstalledAssemblyHash = TRY_CONVERT(varbinary(64), @ExpectedInstalledAssemblyHashText, 1);
END;
BEGIN TRY
    WHILE @Pass <= 2
    BEGIN
        -- Vollständige Metadatensicht wird auch unter dem AppLock neu geprüft.
        IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'VIEW DEFINITION'), 0) <> 1
         OR ISNULL(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies', N'OBJECT', N'SELECT'), 0) <> 1
            THROW 55034, N'Vollständige Dependency-Metadatensicht fehlt; keine Rechtevergabe.', 6;
        -- Beide Durchläufe lesen den aktuellen Katalog; der zweite läuft unter AppLock.
        SET @InstalledVersion = NULL;
        SET @InstalledMode = NULL;
        SET @AssemblyId = NULL;
        SET @InstalledAssemblyHash = NULL;
        SELECT @InstalledVersion = TRY_CONVERT(nvarchar(max), value)
        FROM sys.extended_properties
        WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @VersionProperty;
        SELECT @InstalledMode = TRY_CONVERT(nvarchar(max), value)
        FROM sys.extended_properties
        WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @ModeProperty;
        SET @Release = CASE CONVERT(varbinary(max), @InstalledVersion)
            WHEN CONVERT(varbinary(max), N'1.0.0') THEN 10
            WHEN CONVERT(varbinary(max), N'1.1.0') THEN 11 ELSE 0 END;
        IF @Release = 0 AND EXISTS (SELECT 1 FROM sys.extended_properties
            WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @VersionProperty)
            THROW 55032, N'Die installierte Modulversion ist nicht bekannt.', 1;
        SELECT @AssemblyId = a.assembly_id,
               @InstalledAssemblyHash = HASHBYTES(N'SHA2_512', f.content)
        FROM sys.assemblies a LEFT JOIN sys.assembly_files f
          ON f.assembly_id = a.assembly_id AND f.file_id = 1
        WHERE a.name = N'Toolbelt_String_EditDistance';
        UPDATE s SET ObjectId = o.object_id FROM @Slots s
        LEFT JOIN sys.objects o ON o.schema_id = SCHEMA_ID(N'toolbelt_string') AND o.name COLLATE DATABASE_DEFAULT = s.Name COLLATE DATABASE_DEFAULT;

        IF @Release = 0 AND (@AssemblyId IS NOT NULL OR EXISTS (SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@ModeProperty)
            OR EXISTS (SELECT 1 FROM @Slots WHERE ObjectId IS NOT NULL))
            THROW 55033, N'Zielobjekte ohne bekannten Versionsmarker sind fremd belegt.', 7;
        IF @Release > 0 AND (@InstalledMode IS NULL OR
            CONVERT(varbinary(max), @InstalledMode) NOT IN
            (CONVERT(varbinary(max), N'local'), CONVERT(varbinary(max), N'central')))
            THROW 55033, N'Der installierte DeploymentMode ist nicht kohärent.', 1;
        IF SCHEMA_ID(N'toolbelt_string') IS NOT NULL AND
          (NOT EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 3
            AND major_id = SCHEMA_ID(N'toolbelt_string') AND minor_id = 0
            AND name = N'Toolbelt.Managed' AND TRY_CONVERT(int, value) = 1)
           OR NOT EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 3
            AND major_id = SCHEMA_ID(N'toolbelt_string') AND minor_id = 0
            AND name = N'Toolbelt.SchemaCategory'
            AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), value)) = CONVERT(varbinary(max), N'string')))
            THROW 55033, N'Das vorhandene Schema hat keine eigene Toolbelt-Zuordnung.', 2;
        IF @Release > 0 AND EXISTS
          (SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id = s.ObjectId
           WHERE s.SinceRelease <= @Release AND
           (o.object_id IS NULL OR CONVERT(varbinary(max),o.name)<>CONVERT(varbinary(max),s.Name)
            OR o.type COLLATE DATABASE_DEFAULT <> s.Kind COLLATE DATABASE_DEFAULT
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.Managed'
              AND TRY_CONVERT(int, e.value) = 1)
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleId'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), N'toolbelt.string.edit-distance'))
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleVersion'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), @InstalledVersion))
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class=1
              AND e.major_id=o.object_id AND e.minor_id=0 AND e.name=N'Toolbelt.Visibility'
              AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),e.value))=
                  CONVERT(varbinary(max),CASE WHEN s.Kind='FT' THEN N'internal' ELSE N'public' END))))
            THROW 55033, N'Das installierte Release-Objektmanifest ist nicht kohärent.', 3;
        -- Historische Releasebytes werden explizit gebunden, nicht aus clr_name erschlossen.
        IF @Release = 0 AND @ExpectedAbsence = 0
           OR @Release > 0 AND @ExpectedAbsence = 1
            THROW 55046, N'Die erwartete Assembly-Anwesenheit passt nicht zum geprüften Modulzustand.', 2;
        IF @Release > 0 AND (@InstalledAssemblyHash IS NULL
            OR @InstalledAssemblyHash <> @ExpectedInstalledAssemblyHash)
            THROW 55047, N'Der installierte Assemblyhash entspricht nicht der expliziten Offline-Erwartung.', 1;
        IF @Release > 0 AND EXISTS
          (SELECT 1 FROM @Slots s JOIN sys.assembly_modules m ON m.object_id=s.ObjectId
           WHERE s.SinceRelease<=@Release AND s.Kind='FT' AND (CONVERT(varbinary(max),m.assembly_class) <> CONVERT(varbinary(max),CASE WHEN s.Name=N'TVF_JaroWinklerSimilarityCore' THEN N'Toolbelt.String.EditDistance.JaroProvider' ELSE N'Toolbelt.String.EditDistance.DistanceProvider' END)
             OR CONVERT(varbinary(max),m.assembly_method) <> CONVERT(varbinary(max),CASE s.Name
                WHEN N'TVF_LevenshteinDistanceCore' THEN N'Levenshtein' WHEN N'TVF_JaroWinklerSimilarityCore' THEN N'Evaluate' ELSE N'Osa' END)
             OR m.null_on_null_input<>0))
            THROW 55033, N'Der CLR-Kern besitzt eine falsche EntryPoint- oder NULL-Bindung.', 8;
        IF @Release > 0 AND EXISTS
          (SELECT 1 FROM @Slots s WHERE s.SinceRelease<=@Release AND
            ((SELECT COUNT(*) FROM sys.parameters p WHERE p.object_id=s.ObjectId AND p.parameter_id>0)
                 <>CASE WHEN s.SinceRelease=11 THEN 3 ELSE 4 END
            OR (SELECT COUNT(*) FROM sys.columns c WHERE c.object_id=s.ObjectId)
                 <>CASE WHEN s.SinceRelease=11 THEN 2 ELSE 3 END
            OR EXISTS(SELECT 1 FROM sys.parameters p WHERE p.object_id=s.ObjectId AND
              (p.user_type_id<>p.system_type_id
               OR (p.parameter_id=1 AND(CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),N'@LeftText') OR TYPE_NAME(p.system_type_id)<>N'nvarchar' OR p.max_length<>-1))
               OR (p.parameter_id=2 AND(CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),N'@RightText') OR TYPE_NAME(p.system_type_id)<>N'nvarchar' OR p.max_length<>-1))
               OR (s.SinceRelease=10 AND p.parameter_id=3 AND(CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),N'@MaxDistance') OR TYPE_NAME(p.system_type_id)<>N'int' OR p.max_length<>4))
               OR (s.SinceRelease=10 AND p.parameter_id=4 AND(CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),N'@Profile') OR TYPE_NAME(p.system_type_id)<>N'nvarchar' OR p.max_length<>-1))
               OR (s.SinceRelease=11 AND p.parameter_id=3 AND(CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),N'@Profile') OR TYPE_NAME(p.system_type_id)<>N'nvarchar' OR p.max_length<>-1))))
            OR EXISTS(SELECT 1 FROM sys.columns c WHERE c.object_id=s.ObjectId AND
              (c.user_type_id<>c.system_type_id
               OR (s.SinceRelease=10 AND ((c.column_id=1 AND(CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'Distance') OR TYPE_NAME(c.system_type_id)<>N'int' OR c.max_length<>4))
                 OR(c.column_id=2 AND(CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'ExceedsMaxDistance') OR TYPE_NAME(c.system_type_id)<>N'bit' OR c.max_length<>1))
                 OR(c.column_id=3 AND(CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'ErrorCode') OR TYPE_NAME(c.system_type_id)<>N'int' OR c.max_length<>4))))
               OR (s.SinceRelease=11 AND ((c.column_id=1 AND(CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'Similarity') OR TYPE_NAME(c.system_type_id)<>N'float' OR c.max_length<>8 OR c.precision<>53))
                 OR(c.column_id=2 AND(CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'ErrorCode') OR TYPE_NAME(c.system_type_id)<>N'int' OR c.max_length<>4))))))))
            THROW 55033, N'Die Parameter-/Resultset-Metadaten des installierten Releases sind nicht kohärent.', 9;
        IF @Release > 0 AND (@AssemblyId IS NULL OR @InstalledAssemblyHash IS NULL
          OR NOT EXISTS (SELECT 1 FROM sys.assemblies a WHERE a.assembly_id = @AssemblyId
              AND a.permission_set_desc = N'SAFE_ACCESS' AND a.is_user_defined = 1)
          OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.Managed' AND TRY_CONVERT(int, e.value) = 1)
          OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleId'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), N'toolbelt.string.edit-distance'))
          OR (@Release IN (10,11) AND NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleVersion'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), @InstalledVersion))))
            THROW 55033, N'Die installierte Assembly-Zuordnung ist nicht kohärent.', 4;
        IF EXISTS (SELECT 1 FROM sys.sql_expression_dependencies d
              JOIN @Slots s ON s.ObjectId = d.referenced_id AND s.SinceRelease <= @Release
              WHERE NOT EXISTS (SELECT 1 FROM @Slots own WHERE own.ObjectId = d.referencing_id AND own.SinceRelease <= @Release)
                -- Der bekannte Text-Pairs-Consumer bleibt bei einem exakt
                -- hashgebundenen 1.1.0-Repeat erhalten. Upgrade, Binary- und
                -- Moduswechsel sowie unbekannte Consumer bleiben gesperrt.
                AND NOT EXISTS (SELECT 1 WHERE @Release = 11 AND @ExpectedAbsence = 0
                  AND @ExpectedInstalledAssemblyHash = @AssemblyHash
                  AND @InstalledAssemblyHash = @AssemblyHash
                  AND CONVERT(varbinary(max), @InstalledMode) = CONVERT(varbinary(max), @DeploymentMode)
                  AND d.referencing_id = OBJECT_ID(N'toolbelt_string.USP_CompareTextPairs', N'P')
                  AND EXISTS (SELECT 1 FROM sys.extended_properties e WITH (NOLOCK)
                    WHERE e.class=0 AND e.major_id=0 AND e.minor_id=0
                      AND e.name=N'Toolbelt.Module.toolbelt.string.text-pairs.Version'
                      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),e.value))=CONVERT(varbinary(max),N'1.0.0'))
                  AND EXISTS (SELECT 1 FROM sys.extended_properties e WITH (NOLOCK)
                    WHERE e.class=0 AND e.major_id=0 AND e.minor_id=0
                      AND e.name=N'Toolbelt.Module.toolbelt.string.text-pairs.DeploymentMode'
                      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),e.value))=CONVERT(varbinary(max),@InstalledMode))
                  AND EXISTS (SELECT 1 FROM sys.extended_properties e WITH (NOLOCK)
                    WHERE e.class=1 AND e.major_id=d.referencing_id AND e.minor_id=0
                      AND e.name=N'Toolbelt.ModuleId'
                      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),e.value))=CONVERT(varbinary(max),N'toolbelt.string.text-pairs'))
                  AND EXISTS (SELECT 1 FROM sys.extended_properties e WITH (NOLOCK)
                    WHERE e.class=1 AND e.major_id=d.referencing_id AND e.minor_id=0
                      AND e.name=N'Toolbelt.ModuleVersion'
                      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),e.value))=CONVERT(varbinary(max),N'1.0.0'))
                  AND EXISTS (SELECT 1 FROM sys.extended_properties e WITH (NOLOCK)
                    WHERE e.class=1 AND e.major_id=d.referencing_id AND e.minor_id=0
                      AND e.name=N'Toolbelt.DeploymentMode'
                      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),e.value))=CONVERT(varbinary(max),@InstalledMode))))
            THROW 55038, N'Eine fremde same-database Dependency blockiert den Lifecycle.', 1;
        IF EXISTS (SELECT 1 FROM sys.assembly_modules m WHERE m.assembly_id = @AssemblyId
              AND NOT EXISTS (SELECT 1 FROM @Slots s WHERE s.ObjectId = m.object_id AND s.SinceRelease <= @Release AND s.Kind IN ('FS', 'FT')))
           OR EXISTS (SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id = @AssemblyId)
            THROW 55038, N'Ein fremder Assembly-Verbraucher blockiert den Lifecycle.', 2;
        IF EXISTS (SELECT 1 FROM @Slots s JOIN sys.assembly_modules m ON m.object_id = s.ObjectId
              WHERE s.SinceRelease <= @Release AND s.Kind IN ('FS', 'FT') AND m.assembly_id <> @AssemblyId)
            THROW 55033, N'Ein CLR-Kern verweist auf eine andere Assembly.', 5;
        IF NOT EXISTS (SELECT 1 FROM sys.configurations WHERE name = N'clr enabled' AND value_in_use = 1)
            THROW 55040, N'CLR ist nicht aktiviert; der Lifecycle ändert keine Instanzoption.', 1;
        IF NOT EXISTS (SELECT 1 FROM sys.configurations WHERE name = N'clr strict security' AND value_in_use = 1)
            THROW 55042, N'clr strict security muss aktiviert bleiben.', 1;
        IF @AssemblyHash IS NULL OR NOT EXISTS (SELECT 1 FROM sys.trusted_assemblies WHERE hash = @AssemblyHash)
            THROW 55045, N'Der exakte Release-Hash ist nicht freigegeben.', 1;
        -- Neue Slots gehören keinem Vorgängerrelease, auch mit imitierten Markern.
        IF EXISTS (SELECT 1 FROM @Slots WHERE SinceRelease > @Release AND ObjectId IS NOT NULL)
            OR (@Release = 0 AND (@AssemblyId IS NOT NULL OR EXISTS (SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@ModeProperty)))
            THROW 55033, N'Ein Zielslot oder die Assembly ist fremd belegt.', 6;
        IF SCHEMA_ID(N'toolbelt_string') IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA'), 0) <> 1
            THROW 55034, N'CREATE SCHEMA fehlt.', 1;
        IF SCHEMA_ID(N'toolbelt_string') IS NOT NULL AND ISNULL(HAS_PERMS_BY_NAME(N'toolbelt_string', N'SCHEMA', N'ALTER'), 0) <> 1
            THROW 55034, N'ALTER auf toolbelt_string fehlt.', 2;
        IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION'), 0) <> 1
            THROW 55034, N'CREATE FUNCTION fehlt.', 3;
        IF @AssemblyId IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE ASSEMBLY'), 0) <> 1
            THROW 55034, N'CREATE ASSEMBLY fehlt.', 4;
        IF @AssemblyId IS NOT NULL AND @InstalledAssemblyHash <> @AssemblyHash
           AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'ALTER ANY ASSEMBLY'), 0) <> 1
            THROW 55034, N'ALTER ANY ASSEMBLY fehlt.', 5;
        IF @Pass = 1
        BEGIN
            BEGIN TRANSACTION;
            SET @OwnTransaction = 1;
            DECLARE @LockResult int;
            EXEC @LockResult = sys.sp_getapplock
                  @Resource = N'toolbelt.deploy.toolbelt.string.edit-distance',
                  @LockMode = N'Exclusive', @LockOwner = N'Transaction',
                  @LockTimeout = 0, @DbPrincipal = N'public';
            IF @LockResult < 0
                THROW 55035, N'Ein paralleler Editierdistanz-Lifecycle ist bereits aktiv.', 1;
        END;
        SET @Pass += 1;
    END;
    IF SCHEMA_ID(N'toolbelt_string') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_string];';
        EXEC sys.sp_addextendedproperty @name = N'Toolbelt.Managed', @value = 1,
             @level0type = N'SCHEMA', @level0name = N'toolbelt_string';
        EXEC sys.sp_addextendedproperty @name = N'Toolbelt.SchemaCategory', @value = N'string',
             @level0type = N'SCHEMA', @level0name = N'toolbelt_string';
    END;
    IF @Release IN (10,11)
    BEGIN
        IF @Release=11
        BEGIN
            DROP FUNCTION [toolbelt_string].[TVF_JaroWinklerSimilarity];
            DROP FUNCTION [toolbelt_string].[TVF_JaroWinklerSimilarityCore];
        END;
        DROP FUNCTION [toolbelt_string].[TVF_LevenshteinDistance];
        DROP FUNCTION [toolbelt_string].[TVF_OsaDistance];
        DROP FUNCTION [toolbelt_string].[TVF_LevenshteinDistanceCore];
        DROP FUNCTION [toolbelt_string].[TVF_OsaDistanceCore];
    END;
    IF @InstalledAssemblyHash IS NULL OR @InstalledAssemblyHash <> @AssemblyHash
    BEGIN
        DECLARE @AssemblyDdl nvarchar(max) =
            CASE WHEN @AssemblyId IS NULL THEN N'CREATE' ELSE N'ALTER' END
            + N' ASSEMBLY [Toolbelt_String_EditDistance] FROM ' + CONVERT(nvarchar(max), @AssemblyBits, 1)
            + N' WITH PERMISSION_SET = SAFE;';
        EXEC sys.sp_executesql @AssemblyDdl;
    END;
END TRY
BEGIN CATCH
    IF @OwnTransaction = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO
-- Interner SAFE-CLR-Transport; gemeinsame Scalar-/DP-Implementierung.
CREATE FUNCTION toolbelt_string.TVF_LevenshteinDistanceCore
(@LeftText nvarchar(max), @RightText nvarchar(max), @MaxDistance int, @Profile nvarchar(max))
RETURNS TABLE (Distance int, ExceedsMaxDistance bit, ErrorCode int)
AS EXTERNAL NAME [Toolbelt_String_EditDistance].[Toolbelt.String.EditDistance.DistanceProvider].[Levenshtein];
GO
-- ============================================================================
-- Objekt: toolbelt_string.TVF_LevenshteinDistance; Typ: inline TVF.
-- Zweck: begrenzte exakte Unicode-Scalar-Editierdistanz oder Thresholdnachweis.
-- Parameter: LeftText/RightText nvarchar(max), MaxDistance int=NULL,
-- Profile nvarchar(max)=standard; large ausdrücklich auswählen, kein Abschneiden.
-- Ergebnis: genau eine Zeile Distance int NULL, ExceedsMaxDistance bit NULL,
-- ErrorCode int logisch nicht NULL; native Metadaten nullable zulässig.
-- NULL: irgendein Text NULL => NULL/NULL/0 vor übrigen Prüfungen.
-- Fehler: Profile1, negative Grenze2, Raw3, UTF164, Scalars5, DP-Budget6.
-- Dependencies: eigener SAFE-CLR-Provider; Rechte: SELECT auf dieser Funktion.
-- Versionen: SQL Server 2019/2022/2025, Windows/Linux; native Gates noch offen.
-- Performance: bandierte zwei/drei DP-Zeilen, endliche Profilbudgets;
-- keine relationale Inlining-/Heap-/Parallelitätszusage. Keine Datenzugriffe.
-- Besonderheiten: ordinal, keine Normalisierung, NUL/trailing spaces erhalten.
-- Vertrag: Documentation/Architecture/EDIT_DISTANCE_CONTRACT.md.
-- ============================================================================
CREATE FUNCTION toolbelt_string.TVF_LevenshteinDistance
(@LeftText nvarchar(max), @RightText nvarchar(max), @MaxDistance int = NULL,
 @Profile nvarchar(max) = N'standard')
RETURNS TABLE
AS RETURN
    SELECT Distance, ExceedsMaxDistance, ErrorCode
    FROM toolbelt_string.TVF_LevenshteinDistanceCore(@LeftText, @RightText, @MaxDistance, @Profile);
GO
-- Interner SAFE-CLR-Transport; gemeinsame Scalar-/DP-Implementierung.
CREATE FUNCTION toolbelt_string.TVF_OsaDistanceCore
(@LeftText nvarchar(max), @RightText nvarchar(max), @MaxDistance int, @Profile nvarchar(max))
RETURNS TABLE (Distance int, ExceedsMaxDistance bit, ErrorCode int)
AS EXTERNAL NAME [Toolbelt_String_EditDistance].[Toolbelt.String.EditDistance.DistanceProvider].[Osa];
GO
-- ============================================================================
-- Objekt: toolbelt_string.TVF_OsaDistance; Typ: inline TVF.
-- Zweck: begrenzte exakte Unicode-Scalar-Editierdistanz oder Thresholdnachweis.
-- Parameter: LeftText/RightText nvarchar(max), MaxDistance int=NULL,
-- Profile nvarchar(max)=standard; large ausdrücklich auswählen, kein Abschneiden.
-- Ergebnis: genau eine Zeile Distance int NULL, ExceedsMaxDistance bit NULL,
-- ErrorCode int logisch nicht NULL; native Metadaten nullable zulässig.
-- NULL: irgendein Text NULL => NULL/NULL/0 vor übrigen Prüfungen.
-- Fehler: Profile1, negative Grenze2, Raw3, UTF164, Scalars5, DP-Budget6.
-- Dependencies: eigener SAFE-CLR-Provider; Rechte: SELECT auf dieser Funktion.
-- Versionen: SQL Server 2019/2022/2025, Windows/Linux; native Gates noch offen.
-- Performance: bandierte zwei/drei DP-Zeilen, endliche Profilbudgets;
-- keine relationale Inlining-/Heap-/Parallelitätszusage. Keine Datenzugriffe.
-- Besonderheiten: ordinal, keine Normalisierung, NUL/trailing spaces erhalten.
-- Vertrag: Documentation/Architecture/EDIT_DISTANCE_CONTRACT.md.
-- ============================================================================
CREATE FUNCTION toolbelt_string.TVF_OsaDistance
(@LeftText nvarchar(max), @RightText nvarchar(max), @MaxDistance int = NULL,
 @Profile nvarchar(max) = N'standard')
RETURNS TABLE
AS RETURN
    SELECT Distance, ExceedsMaxDistance, ErrorCode
    FROM toolbelt_string.TVF_OsaDistanceCore(@LeftText, @RightText, @MaxDistance, @Profile);
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO
-- Interner SAFE-Transport; gemeinsamer Scalar-Helfer ohne Culture-/Datenzugriffe.
CREATE FUNCTION toolbelt_string.TVF_JaroWinklerSimilarityCore
(@LeftText nvarchar(max),@RightText nvarchar(max),@Profile nvarchar(max))
RETURNS TABLE (Similarity float(53),ErrorCode int)
AS EXTERNAL NAME [Toolbelt_String_EditDistance].[Toolbelt.String.EditDistance.JaroProvider].[Evaluate];
GO
-- ============================================================================
-- Objekt: toolbelt_string.TVF_JaroWinklerSimilarity; Typ: inline TVF.
-- Zweck: begrenzte vollständige symmetrische Scalar-Ähnlichkeit von 0 bis 1.
-- Parameter: LeftText/RightText nvarchar(max), Profile nvarchar(max)=N'standard'.
-- Resultset: genau eine Zeile Similarity float(53) NULL, ErrorCode int logisch NOT NULL;
-- physische SQL-/Clientnullability nullable zulässig, kein Erfolgsfallback.
-- NULL: irgendein Text NULL ergibt NULL/ErrorCode 0 vor anderen Argumenten.
-- Fehler: Profil 1, Raw 3, UTF-16 4, Scalar 5, geplante Fensterarbeit 6.
-- Dependencies: eigener SAFE-Provider 1.1 und UnicodeScalar; SELECT auf öffentliche IF.
-- Versionen/Plattformen: Ziel SQL Server 2019/2022/2025 Windows/Linux; Runtime offen.
-- Performance: endliche Raw/Scalar-/Workprofile, lineare Matchpuffer;
-- keine SARGability-/Inlining-/Parallelitäts-/Heap-/Hardwallzusage.
-- Besonderheiten: h/2 reell, strikt J>0.7, Präfixbonus 0.1/maximal 4; keine Normalisierung.
-- Vertrag: Documentation/Architecture/JARO_WINKLER_CONTRACT.md.
-- ============================================================================
CREATE FUNCTION toolbelt_string.TVF_JaroWinklerSimilarity
(@LeftText nvarchar(max),@RightText nvarchar(max),@Profile nvarchar(max)=N'standard')
RETURNS TABLE
AS RETURN
    SELECT Similarity,ErrorCode
    FROM toolbelt_string.TVF_JaroWinklerSimilarityCore(@LeftText,@RightText,@Profile);
GO

SET NOCOUNT ON;
BEGIN TRY
    IF @@TRANCOUNT <> 1
        THROW 55039, N'Die Deployment-Transaktion ist vorzeitig beendet worden.', 1;

    DECLARE
          @VersionProperty sysname =
              N'Toolbelt.Module.toolbelt.string.edit-distance.Version'
        , @ModeProperty sysname =
              N'Toolbelt.Module.toolbelt.string.edit-distance.DeploymentMode'
        , @DeploymentMode nvarchar(16) = N'central';

    IF EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 0 AND name = @VersionProperty)
        EXEC sys.sp_updateextendedproperty @name = @VersionProperty, @value = N'1.1.0';
    ELSE
        EXEC sys.sp_addextendedproperty @name = @VersionProperty, @value = N'1.1.0';

    IF EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 0 AND name = @ModeProperty)
        EXEC sys.sp_updateextendedproperty @name = @ModeProperty, @value = @DeploymentMode;
    ELSE
        EXEC sys.sp_addextendedproperty @name = @ModeProperty, @value = @DeploymentMode;

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties AS ep
           INNER JOIN sys.assemblies AS a ON a.assembly_id = ep.major_id
           WHERE ep.class = 5 AND ep.name = N'Toolbelt.Managed'
             AND a.name = N'Toolbelt_String_EditDistance'
       )
        EXEC sys.sp_updateextendedproperty
              @name = N'Toolbelt.Managed', @value = 1
            , @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_EditDistance';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.Managed', @value = 1
            , @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_EditDistance';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties AS ep
           INNER JOIN sys.assemblies AS a ON a.assembly_id = ep.major_id
           WHERE ep.class = 5 AND ep.name = N'Toolbelt.ModuleId'
             AND a.name = N'Toolbelt_String_EditDistance'
       )
        EXEC sys.sp_updateextendedproperty
              @name = N'Toolbelt.ModuleId', @value = N'toolbelt.string.edit-distance'
            , @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_EditDistance';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.ModuleId', @value = N'toolbelt.string.edit-distance'
            , @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_EditDistance';

    IF EXISTS (SELECT 1 FROM sys.extended_properties e JOIN sys.assemblies a ON a.assembly_id = e.major_id
               WHERE e.class = 5 AND e.name = N'Toolbelt.ModuleVersion' AND a.name = N'Toolbelt_String_EditDistance')
        EXEC sys.sp_updateextendedproperty @name = N'Toolbelt.ModuleVersion', @value = N'1.1.0',
             @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_EditDistance';
    ELSE
        EXEC sys.sp_addextendedproperty @name = N'Toolbelt.ModuleVersion', @value = N'1.1.0',
             @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_EditDistance';

    DECLARE @FunctionName sysname;
    DECLARE FunctionCursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT name
        FROM sys.objects
        WHERE schema_id = SCHEMA_ID(N'toolbelt_string')
          AND name IN (N'TVF_LevenshteinDistance', N'TVF_OsaDistance', N'TVF_LevenshteinDistanceCore', N'TVF_OsaDistanceCore', N'TVF_JaroWinklerSimilarity', N'TVF_JaroWinklerSimilarityCore');
    OPEN FunctionCursor;
    FETCH NEXT FROM FunctionCursor INTO @FunctionName;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.Managed', @value = 1
            , @level0type = N'SCHEMA', @level0name = N'toolbelt_string'
            , @level1type = N'FUNCTION', @level1name = @FunctionName;
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.ModuleId', @value = N'toolbelt.string.edit-distance'
            , @level0type = N'SCHEMA', @level0name = N'toolbelt_string'
            , @level1type = N'FUNCTION', @level1name = @FunctionName;
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.ModuleVersion', @value = N'1.1.0'
            , @level0type = N'SCHEMA', @level0name = N'toolbelt_string'
            , @level1type = N'FUNCTION', @level1name = @FunctionName;
        DECLARE @Visibility nvarchar(16) = CASE WHEN @FunctionName IN (N'TVF_LevenshteinDistanceCore', N'TVF_OsaDistanceCore', N'TVF_JaroWinklerSimilarityCore') THEN N'internal' ELSE N'public' END;
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.Visibility', @value = @Visibility
            , @level0type = N'SCHEMA', @level0name = N'toolbelt_string'
            , @level1type = N'FUNCTION', @level1name = @FunctionName;
        FETCH NEXT FROM FunctionCursor INTO @FunctionName;
    END;
    CLOSE FunctionCursor;
    DEALLOCATE FunctionCursor;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF CURSOR_STATUS(N'local', N'FunctionCursor') >= 0 CLOSE FunctionCursor;
    IF CURSOR_STATUS(N'local', N'FunctionCursor') > -3 DEALLOCATE FunctionCursor;
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.string.edit-distance
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.string.phonetic
:On Error exit
-- SQLCMD-Parameter: vollständige AssemblyBits, explizite installierte
-- SHA2-512-Erwartung (0x nur für Abwesenheit), DeploymentMode local/central.
DECLARE @Install bit=1,@AssemblyBits varbinary(max)=0x4d5a90000300000004000000ffff0000b800000000000000400000000000000000000000000000000000000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a2400000000000000504500004c010300aefca0fd0000000000000000e00022200b0130000042000000080000000000007a60000000200000008000000000001000200000000200000400000000000000060000000000000000c000000002000000000000030060850000100000100000000010000010000000000000100000000000000000000000286000004f00000000800000440400000000000000000000000000000000000000a000000c0000000c6000001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000080000000000000000000000082000004800000000000000000000002e7465787400000080400000002000000042000000020000000000000000000000000000200000602e7273726300000044040000008000000006000000440000000000000000000000000000400000402e72656c6f6300000c00000000a0000000020000004a000000000000000000000000000040000042000000000000000000000000000000005c60000000000000480000000200050084430000881c0000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000032027201000070280c00000a2a000000133006006602000001000011041451026f0d00000a2c02162a026f0e00000a0a0620001000006a3102182a06166a2f0b721f000070730f00000a7a06b78d170000010b166a0c2b2d02080708b70608dab76f1000000a13061106166a310711060608da310b724b000070730f00000a7a081106d60c080632cf1613072b3e07110793281100000a2c20110717d6078e692f0d07110717d693281200000a2d02172a110717d613072b0d07110793281200000a2c02172a110717d613071107078e6932bb07130816130938880000001108110993130a110a1f7f3170032d29110a20c70000002e1d110a20e70000002e14110a20d10000002e0b110a20f1000000fe012b48172b45110a20c40000002e38110a20d60000002e2f110a20dc0000002e26110a20e40000002e1d110a20f60000002e14110a20fc0000002e0b110a20df000000fe012b04172b01172d02192a110917581309110911088e693f6dffffff160d078e691304032d292b040917d60d0911042f0f0709931f2031f02b06110417da1304110409310a07110417da931f2031eb731300000a130509130b38bb00000007110b93130c032c20110c20df000000331711051f53280300000611051f532803000006388c000000110c1f613210110c1f7a300a110c1f20dab6130c2b6d032c48110c20c40000002e09110c20e400000033061f41130c2b52110c20d60000002e09110c20f600000033061f4f130c2b3a110c20dc0000002e09110c20fc00000033281f55130c2b22110c20e7000000330920c7000000130c2b10110c20f1000000330720d1000000130c1105110c2803000006110b17d6130b110b11043f3cffffff0411056f1400000a51162a7a026f1500000a17d62000200000310673010000067a02036f1600000a262a000000133002004500000002000011022c0d026f1700000a2000400000310b7273000070730f00000a7a020a160b2b1a06076f1800000a1f7f310b729b000070730f00000a7a0717580b07066f1700000a32dd2a000000133003001302000003000011731300000a0a1f2f0b1f2d0c160d38ed01000002096f1800000a13040917d6026f1700000a32041f2d2b09020917d66f1800000a130511041f413fbd01000011041f5a3db401000072c90000701104281900000a16320f061f3012012806000006389301000011041f422e0c11041f50331511051f482e0f061f3112012806000006387201000011041f442e0611041f54331e72d90000701105281900000a162f0f061f3212012806000006384801000072e10000701104281900000a16320f061f3312012806000006382a01000072eb0000701104281900000a16320f061f3412012806000006380c01000011041f58332772f300007008281900000a162f19061f3412012806000006061f381201280600000638df00000011041f532e0611041f5a330f061f381201280600000638c400000011041f433357066f1500000a2d220672fb0000701105281900000a162f041f382b021f3412012806000006389400000006720f01007008281900000a162f1372150100701105281900000a1632041f342b021f38120128060000062b6772250100701104281900000a16320c061f38120128060000062b4c11041f52330c061f37120128060000062b3a11041f4c330c061f35120128060000062b2811041f4d2e0611041f4e330c061f36120128060000062b1011041f48330a061f2d1201280600000611040c0917d60d09026f1700000a3f07feffff066f1400000a2ae2031f2d2e2f0449032e2a031f303308026f1500000a2d1d026f1500000a17d62000400000310673010000067a02036f1600000a260403532a1330050042000000040000110316320f0416320b03026f1700000a04da3102162a050a160b2b1f06079a0c086f1700000a04330e0203081604281a00000a2d02172a0717580b07068e6932db162ade0216181b8d180000012516722d010070a225177233010070a225187239010070a22519723f010070a2251a7245010070a228070000062aea021f576f1900000a162f2d021f4b6f1900000a162f2202724b0100701a6f1b00000a162f130272510100701a6f1b00000a16fe0416fe012a172a4a725b01007002281900000a16fe0416fe012a1330040084020000050000110228090000060a02280800000616fe030b73350000060c385802000002076f1800000a0d091f4159451a00000018000000250000005900000067000000180000007500000098000000a700000018000000b5000000c4000000e7000000f50000001401000018000000480100005601000076010000820100008e0100001800000099010000b9010000c401000018000000cf0100000920c70000002e400920d10000003b2401000038c3010000080728110000060b38ba010000081f506f2d000006020717d628230000061f422e050717d62b030718d60b3897010000081f536f2d0000060717d60b388601000002080728120000060b387801000002080728150000060b386a010000081f466f2d000006020717d628230000061f462e050717d62b030718d60b38470100000208070628160000060b383801000002080728180000060b382a0100000208070628190000060b381b010000081f4b6f2d000006020717d628230000061f4b2e050717d62b030718d60b38f8000000020807281a0000060b38ea000000081f4d6f2d000006020728100000062d050717d62b030718d60b38cb000000081f4e6f2d000006020717d628230000061f4e2e050717d62b030718d60b38a8000000081f4e6f2d0000060717d60b3897000000020807281b0000060b3889000000081f4b6f2d000006020717d628230000061f512e050717d62b030718d60b2b6902080706281c0000060b2b5d02080706281d0000060b2b51020807281f0000060b2b46081f466f2d000006020717d628230000061f562e050717d62b030718d60b2b2602080728200000060b2b1b02080728210000060b2b100208070628220000060b2b040717d60b07026f1700000a17da3e9afdffff082a13300700850000000600001102031a178d1800000125167269010070a228070000062c02172a03173002162a020318da2823000006280a0000062c02162a020317da19178d1800000125167273010070a228070000062d02162a020318d628230000060a061f492e05061f453321020318da1c188d180000012516727b010070a225177289010070a228070000062a172a000000133007007500000000000000032c02162a020317d61b188d1800000125167297010070a2251772a3010070a228070000062d34020317d6191a8d18000001251672af010070a2251772b7010070a2251872bf010070a2251972c7010070a228070000062d02162a02161b178d18000001251672cf010070a2280700000616fe012a000000133007003d0100000000000002161a188d18000001251672db010070a2251772e5010070a228070000063a18010000021619178d18000001251672ef010070a228070000063afd000000020318da1c198d18000001251672f7010070a225177205020070a225187213020070a228070000063ad0000000020318d617188d1800000125167221020070a225177225020070a228070000063aab000000020317da171a8d1800000125167229020070a22517722d020070a225187231020070a225197235020070a228070000062d03032d74020318d6171f0a8d1800000125167239020070a22517723d020070a225187241020070a225197245020070a2251a7249020070a2251b724d020070a2251c7251020070a2251d7255020070a2251e7259020070a2251f09725d020070a228070000062d0e0317d6026f1700000a17dafe012a172a162a172a00000013300700a00000000000000003026f1700000a19da332c020317da1a198d1800000125167261020070a22517726b020070a225187275020070a228070000062c02172a02026f1700000a18da18188d180000012516727f020070a225177285020070a228070000062d2702026f1700000a17da17188d1800000125167229020070a22517722d020070a228070000062c19020317da1a178d1800000125167275020070a228070000062a162a133007005300000000000000020317d628230000061f4d3302172a020317da19178d180000012516728b020070a228070000062c280317d6026f1700000a17da2e19020318d618178d1800000125167293020070a228070000062a172a162a3e032d08021f416f2d0000060317d62a00133007004c020000000000000204280c0000062c12031f4b6f2d0000060418d61002382f020000042d2a02041c178d1800000125167299020070a228070000062c12031f536f2d0000060418d610023802020000020418178d18000001251672a7020070a228070000062c0f0203042814000006100238db010000020418178d180000012516724b010070a228070000062c2e020418da1a178d18000001251672ad020070a228070000062d14031f531f586f2e0000060418d610023895010000020417d619178d18000001251672b7020070a228070000062c12031f586f2d0000060419d610023869010000020418178d18000001251672bf020070a228070000062c180417330b021628230000061f4d2e0902030428130000062a020418198d18000001251672c5020070a2251772cb020070a2251872d1020070a228070000062c12031f4b6f2d0000060418d6100238ff000000020418198d18000001251672d7020070a2251772dd020070a2251872e3020070a228070000062c46020419198d18000001251672e9020070a2251772f1020070a2251872b7020070a228070000062c0c031f531f586f2e0000062b08031f536f2d0000060418d610023891000000031f4b6f2d000006020417d618198d18000001251672f9020070a2251772ff020070a225187205030070a228070000062c070419d610022b58020417d617198d180000012516720b030070a22517720f030070a225187213030070a228070000062c29020417d618188d18000001251672dd020070a2251772d7020070a228070000062d070418d610022b050417d61002042a13300700a200000000000000020418d617198d1800000125167217030070a225177235020070a22518724d020070a228070000062c69020418d618178d180000012516721b030070a228070000062d4f0417330d020417da28230000061f412e22020417da1b188d1800000125167221030070a22517722d030070a228070000062c0d0372390300706f2f0000062b08031f586f2d0000060419d610022b0d031f4b6f2d0000060418d61002042a00001330070092000000000000000416312602041a178d180000012516723f030070a228070000062c0e031f4b1f586f2e0000060418d62a0204280d0000062c0c031f4b6f2d0000060418d62a0204280e0000062c0c031f4b6f2d0000060418d62a0416312e021618178d1800000125167249030070a228070000062c0a031f4b6f2d0000062b14031f581f4b6f2e0000062b08031f586f2d0000060418d62a000013300700a100000000000000020418178d180000012516724f030070a228070000062c4b020418d617198d1800000125167217030070a225177235020070a225187255030070a228070000062c0f031f4a6f2d0000060419d610022b4e0372590300706f2f0000060418d610022b3c020418188d180000012516725f030070a225177265030070a228070000062c0f031f546f2d0000060418d610022b0d031f546f2d0000060417d61002042a000000133007001903000000000000020417d628230000061f48330f0203042817000006100238fb020000020417d628230000061f4e33780417332302162823000006280a0000062c15052d1203723301007072410200706f300000062b47020418d618178d180000012516726b030070a228070000062d22020417d628230000061f592e15052d1203724102007072330100706f300000062b0b0372330100706f2f0000060418d610023876020000020417d618178d1800000125167271030070a228070000062c1d052d1a03727703007072390200706f300000060418d61002383f020000043a8e000000020417d628230000061f592e6d020417d6181f0b8d180000012516727d030070a225177283030070a225187289030070a22519728f030070a2251a726b030070a2251b7295030070a2251c729b030070a2251d72a1030070a2251e72a7030070a2251f0972ad030070a2251f0a7293020070a228070000062c14031f4b1f4a6f2e0000060418d6100238ab010000020417d618178d1800000125167293020070a228070000062d10020417d628230000061f59408000000002161c198d18000001251672b3030070a2251772c1030070a2251872cf030070a228070000062d58020417da17188d1800000125167235020070a225177217030070a228070000062d36020417da19188d18000001251672dd030070a2251772e5030070a228070000062d14031f4b1f4a6f2e0000060418d610023801010000020417d617198d1800000125167235020070a225177217030070a225187255030070a228070000062d25020417da1a188d18000001251672ed030070a2251772f7030070a22807000006399100000002161a188d18000001251672db010070a2251772e5010070a228070000062d32021619178d18000001251672ef010070a228070000062d1a020417d618178d1800000125167201040070a228070000062c0a031f4b6f2d0000062b2e020417d619178d1800000125167207040070a228070000062c0a031f4a6f2d0000062b0a031f4a1f4b6f2e0000060418d610022b21020417d628230000061f4733070418d610022b050417d61002031f4b6f2d000006042a00000013300700500100000000000004163122020417da2823000006280a0000062d12031f4b6f2d0000060418d610023828010000042d29020418d628230000061f49330a031f4a6f2d0000062b08031f4b6f2d0000060418d6100238fc0000000417312a020418da17198d1800000125167249020070a22517724d020070a22518720f040070a228070000062d540418312a020419da17198d1800000125167249020070a22517724d020070a22518720f040070a228070000062d260419312902041ada17188d1800000125167249020070a22517724d020070a228070000062c070418d610022b7304183151020417da28230000061f553344020419da171b8d180000012516720b030070a225177213040070a225187239020070a22519723d020070a2251a7221020070a228070000062c0a031f466f2d0000062b1904163115020417da28230000061f492e08031f4b6f2d0000060418d61002042ae6042c10020417da2823000006280a0000062c1f020417d62823000006280a0000062c0f031f486f2d0000060418d610022b050417d61002042a0000133007009e0100000000000002041a178d1800000125167217040070a228070000062d1802161a178d1800000125167221040070a228070000062c4f042d0d02041ad628230000061f202e21026f1700000a1a2e1802161a178d1800000125167221040070a228070000062c0a031f486f2d0000062b0a031f4a1f486f2e0000060417d61002381d010000042d2702041a178d1800000125167217040070a228070000062d0f031f4a1f416f2e00000638da000000020417da2823000006280a0000062c2c052d29020417d628230000061f412e0d020417d628230000061f4f330f031f4a1f486f2e000006389e00000004026f1700000a17da330f031f4a1f206f2e0000063884000000020417d6171e8d1800000125167239020070a225177221020070a22518720f030070a225197225020070a2251a7241020070a2251b7245020070a2251c7249020070a2251d722b040070a228070000062d32020417da17198d1800000125167225020070a22517720f030070a225187239020070a228070000062d08031f4a6f2d000006020417d628230000061f4a33070418d610022b050417d61002042afa020417d628230000061f4c33220204280f0000062c0a031f4c6f310000062b08031f4c6f2d0000060418d610022b0d0417d61002031f4c6f2d000006042a000000133007005200000000000000020417d628230000061f48330f031f466f2d0000060418d610022b34031f506f2d000006020417d617188d180000012516722f040070a225177249020070a228070000062d050417d62b030418d61002042a000013300700710000000000000004026f1700000a17da3349052d46020418da18178d18000001251672a7030070a228070000062c2c02041ada18188d1800000125167233040070a225177239040070a228070000062d0a031f526f320000062b08031f526f2d000006020417d628230000061f522e040417d62a0418d62a000000133007002d02000000000000020417da19188d180000012516723f040070a225177247040070a228070000062c0a0417d6100238ff010000042d2c02041b178d180000012516724f040070a228070000062c14031f581f536f2e0000060417d6100238d0010000020418178d180000012516725b040070a228070000062c4e020417d61a1a8d1800000125167261040070a22517726b040070a225187275040070a22519727f040070a228070000062c0a031f536f2d0000062b08031f586f2d0000060418d61002386a010000020419188d1800000125167289040070a225177291040070a228070000062d1802041a178d1800000125167299040070a228070000062c21052c0a031f536f2d0000062b0a031f531f586f2e0000060419d610023811010000042d32020417d6171a8d1800000125167245020070a225177241020070a225187239020070a225197259020070a228070000062d1a020417d617178d180000012516722b040070a228070000062c33031f531f586f2e000006020417d617178d180000012516722b040070a228070000062d050417d62b030418d61002388f000000020418178d18000001251672a3040070a228070000062c0c020304281e00000610022b6b04026f1700000a17da332c020418da18188d18000001251672a9040070a2251772af040070a228070000062c0a031f536f320000062b08031f536f2d000006020417d617188d1800000125167225020070a22517722b040070a228070000062d050417d62b030418d61002042a000000133007000801000000000000020418d628230000061f4840b5000000020419d6181c8d18000001251672b5040070a225177293020070a2251872bb040070a2251972c1040070a2251a72c7040070a2251b72cd040070a228070000062c41020419d618188d1800000125167293020070a2251772bb040070a228070000062c120372d304007072d70400706f300000062b7e0372d70400706f2f0000062b71042d2502192823000006280a0000062d17021928230000061f572e0c031f581f536f2e0000062b49031f586f2d0000062b3f020418d617198d1800000125167217030070a225177235020070a225187255030070a228070000062c0a031f536f2d0000062b0b0372d70400706f2f0000060419d62a13300700250100000000000002041a178d18000001251672dd040070a228070000062d20020419188d18000001251672e7040070a2251772ef040070a228070000062c12031f586f2d0000060419d6100238d9000000020418178d18000001251672f7040070a228070000062d18020419178d18000001251672fd040070a228070000062c75020418d618188d1800000125167205050070a22517720b050070a228070000062d3802161a188d18000001251672db010070a2251772e5010070a228070000062d18021619178d18000001251672ef010070a228070000062c0a031f546f2d0000062b0a031f301f546f2e0000060418d610022b34031f546f2d000006020417d617188d1800000125167221020070a22517720f040070a228070000062d050417d62b030418d61002042a000000133007003501000000000000020418178d180000012516723f010070a228070000062c12031f526f2d0000060418d610023809010000042d56020417d62823000006280a0000062d18020418178d1800000125167211050070a228070000062c2e020417d62823000006280a0000062c0c031f411f466f2e0000062b08031f416f2d0000060417d6100238b000000004026f1700000a17da3310020417da2823000006280a0000062d4a020417da1b1a8d1800000125167217050070a225177223050070a22518722f050070a22519723b050070a228070000062d18021619178d18000001251672ef010070a228070000062c0f031f466f320000060417d610022b3c02041a188d18000001251672ad020070a225177251010070a228070000062c17037247050070724d0500706f30000006041ad610022b050417d61002042a000000133007009d00000000000000042d12031f536f2d0000060417d61002388600000004026f1700000a17da3344020419da19188d1800000125167253050070a22517725b050070a228070000062d2d020418da18188d1800000125167263050070a225177269050070a228070000062d0b0372390300706f2f000006020417d617188d180000012516720b030070a2251772d3040070a228070000062d050417d62b030418d61002042a000000133007008d00000000000000020417d628230000061f48330f031f4a6f2d0000060418d610022b6f020417d618198d180000012516726f050070a225177275050070a22518727b050070a228070000062d14052c230416311f020417da28230000061f542e1203722502007072470500706f300000062b08031f536f2d000006020417d628230000061f5a2e050417d62b030418d61002042a5e0316320903026f1700000a3202162a02036f1800000a2a0000001b3004004400000007000011026f0d00000a0a140d0217120228020000060b072d0a062d070828050000060dde0526180bde000907067336000006130411042828000006178d0800000225161104a22a011000000000090019220005020000021b3004007600000008000011026f0d00000a0a140d1413040216120228020000060b072d32062d2f08280b000006256f2a0000060d6f2b0000061304096f1700000a11046f1700000ad62000800000310673010000067ade0a26180b140d141304de0009110407067337000006130511052829000006178d0900000225161105a22a00000110000000000c00414d000a02000002133002004d000000090000110275080000020a062d0b7281050070730f00000a7a06282800000603067b070000042c0d067b07000004731c00000a2b057e1d00000a811400000104067b08000004731e00000a81150000012a000000133002006d0000000a0000110275090000020a062d0b72b5050070730f00000a7a06282900000603067b0a0000042c0d067b0a000004731c00000a2b057e1d00000a811400000104067b0b0000042c0d067b0b000004731c00000a2b057e1d00000a811400000105067b0c000004731e00000a81150000012a000000133003005d00000000000000027b08000004163235027b0800000419302c027b090000042c08027b080000042d1c027b080000042d08027b090000042b0117027b0700000414fe012e0b72e7050070730f00000a7a027b070000042c0b027b0700000428040000062a000000133003009a0000000b000011027b0c0000042d08027b0d0000042b01170a027b0c000004163231027b0c000004193028027b0d0000042c08027b0c0000042d1806027b0a00000414fe01330c06027b0b00000414fe012e0b721d060070730f00000a7a062d3f027b0a0000042804000006027b0b0000042804000006027b0a0000046f1700000a027b0b0000046f1700000ad62000800000310b7251060070730f00000a7a2a32027b050000046f1400000a2a32027b060000046f1400000a2a8e026f1500000a036f1700000ad62000400000310673010000067a02036f1f00000a262a26020303282e0000062a3e02032831000006020428320000062a2602030328300000062a3e02032833000006020428340000062a4e027b050000040f01282000000a282c0000062a4e027b060000040f01282000000a282c0000062a36027b0500000403282c0000062a36027b0600000403282c0000062a7602731300000a7d0500000402731300000a7d0600000402282100000a2a7202282100000a02037d0700000402047d0800000402057d090000042a9202282100000a02037d0a00000402047d0b00000402057d0c000004020e047d0d0000042a42534a4201000100000000000c00000076342e302e33303331390000000005006c00000030090000237e00009c0900007006000023537472696e6773000000000c100000840600002355530090160000100000002347554944000000a0160000e805000023426c6f620000000000000002000001571da2010902000000fa0133001600000100000019000000090000000d000000370000007600000021000000040000000c0000000b0000000100000002000000020000000100000002000000030000000000040401000000000006001203090506007803090506008402d7040f00290500000600ac0233040600f502330406005f03330406003203330406009802ea040600c302330406006c042c04060083052c040a007305380506008c04000606004b032c040a00e0029a040a0078019a040a0072019a040600f00156050a00a40338050a003f00380506005c042c04060087042c040600b0032c04060076042c04000000004800000000000100010000011000450426012d000100010080011000d105260131000100020080011000d803260131000500050080011000e603260131000500070081011000e1012601310005002400050110009c050000310005002a00030110001f060000310007003600030110001106000031000a0037005380f305d50053804801d5005380af01d5005380b504d50021006506d80021007a02d8002300d501dc002300c504d5002300df05df0023005d06dc0023007002dc002300c504d5002300df05df005020000000008318d1040600010060200000000093002c02e2000100d2220000000091006401eb000400f4220000000093009401f20006004823000000009300da01f70007006725000000009100cd05fc000800a0250000000091004d0505010b00ee25000000009100b9050e010f00262600000000910008010e0110006126000000009100fc033e0011007426000000009300da0113011200042900000000910001001901130098290000000091000d00190115001c2a000000009100320019011700682b0000000091001a0019011900142c000000009100260019011b00732c000000009100d5001f011d00842c000000009100630026011f00dc2e0000000091005100260122008c2f0000000091007b00260125002c300000000091006b0026012800dc3000000000910073002e012b000434000000009100840026012f0060350000000091008d00260132009c3500000000910095002e01350046370000000091009d00260139008837000000009100a50026013c00e837000000009100ad002e013f006838000000009100b5002e014300a43a0000000091005a0026014700b83b000000009100bd0026014a00ec3c000000009100c50026014d00303e000000009100cd0026015000dc3e000000009100e2002e015300753f0000000091007c0537015700903f000000009600fc013d015900f03f00000000960014023d015a0084400000000096001b0644015b00e0400000000096002a064f015e005c4100000000910034025d016200c8410000000091003402630163006e420000000083084b06430064007b420000000083085c02430064008842000000009100440169016400ac420000000083006b0170016600b6420000000083006b0175016700c6420000000083006b0110006900d0420000000083006b017b016a00e042000000008300570670016c00f4420000000083006a0270016d000843000000008300570610006e0016430000000083006a0210006f002443000000008618d104060070004243000000008318d104810170005f43000000008318d10488017300000001000c06000002000c02020003005b0100000100b20500000200960300000100dc01000001000c0600000100b20500000200dc0100000300c50100000100960300000200c70500000300c20300000400ea0000000100960300000100960300000100960300000100960300000100960300000200450600000100960300000200450600000100960300000200450600000100960300000200450600000100960300000200450600000100b20500000200450600000100960300000200b20500000300450600000100960300000200b20500000300450600000100960300000200b20500000300450600000100960300000200b20500000300450600000100960300000200b20500000300450600000400180100000100960300000200b20500000300450600000100960300000200b20500000300450600000100960300000200b20500000300450600000400180100000100960300000200b20500000300450600000100960300000200b20500000300450600000100960300000200b20500000300450600000400180100000100960300000200b20500000300450600000400180100000100960300000200b20500000300450600000100960300000200b20500000300450600000100960300000200b20500000300450600000100960300000200b20500000300450600000100960300000200b205000003004506000004001801000001009603000002004506000001000c06000001000c0600000100960302000200870102000300bb0100000100960302000200ce0102000300a10102000400bb01000001004106000001004106000001008a0500000200960300000100960300000100910500000200960500000100960300000100910500000200960500000100960300000100960300000100960300000100960300000100dc0100000200cb0400000300e905000001006506000002007a0200000300cb0400000400e9050900d10401001100d10406001900d1040a002900d10410003100d10410003900d10410004100d10410004900d10415005100d10410007900d10406008100d10406005900d1041000690021042d006900b7033100b100d104100069003f013500b9003d023e00b9004d023e007100d10406006100ae0343007100b7034700710064014b00c100b7034700c10069055600c1009c036500c100c9037100c1009c037a00a100d1041000a1002704a500a900d104010071006401b200b900ae0343006100d104060008000400c10008000800c60008000c00cb0008001000d0002e000b0094012e0013009d012e001b00bc012e002300c5012e002b00e3012e00330035022e003b0043022e0043005c022e004b006202c4015300e10580045b006f02a0045b0016041a0051005b006a00810089008d009600a000a900ae000700010000005d06900100007002900102002a00030002002b00050004800000010000000000000000000000000026010000040000000000000000000000b800ff0000000000040000000000000000000000b800f300000000000700050008000600090006000000000000636f6e646974696f6e433000636f6e646974696f6e43483000636f6e646974696f6e4c3000636f6e646974696f6e4d3000636f6e646974696f6e4348310053716c496e743332003c4d6f64756c653e0068616e646c6543430068616e646c6553430068616e646c65430068616e646c65440068616e646c65470068616e646c6543480068616e646c6547480068616e646c65480068616e646c654a0068616e646c654c0068616e646c65500068616e646c65520068616e646c65530068616e646c65540068616e646c65570068616e646c65580068616e646c654145494f55590068616e646c655a0063726974657269610053797374656d2e44617461006d73636f726c6962006973536c61766f4765726d616e696300736c61766f4765726d616e696300546f6f6c62656c742e537472696e672e50686f6e65746963005265616400416464004d6178696d756d5472616e73666f726d656400707265706172656400417070656e6400617070656e640053797374656d446174614163636573734b696e640070686f6e65746963436f64650056616c6964617465436f646500616c7465726e617465436f6465004d6178696d756d436f6465006572726f72436f6465006c617374436f6465007072696d617279436f646500456e636f64650050686f6e657469634272696467650049456e756d657261626c65004576616c75617465436f6c6f676e6500636f6c6f676e65004576616c75617465446f75626c654d65746170686f6e6500507265706172650056616c696461746500497348696768537572726f676174650049734c6f77537572726f67617465006765745f416c7465726e61746500617070656e64416c7465726e61746500616c7465726e6174650044656275676761626c6541747472696275746500436f6d56697369626c6541747472696275746500417373656d626c795469746c6541747472696275746500417373656d626c7946696c6556657273696f6e4174747269627574650053716c46756e6374696f6e41747472696275746500417373656d626c794465736372697074696f6e41747472696275746500436f6d70696c6174696f6e52656c61786174696f6e7341747472696275746500417373656d626c7950726f6475637441747472696275746500506172616d417272617941747472696275746500417373656d626c79436f6d70616e794174747269627574650052756e74696d65436f6d7061746962696c6974794174747269627574650076616c756500496e6465784f660053716c537472696e6700546f537472696e67006765745f4c656e677468006c656e67746800436f6d706172654f7264696e616c00436f6c6f676e654b65726e656c00446f75626c654d65746170686f6e654b65726e656c006973566f77656c00546f6f6c62656c742e537472696e672e50686f6e657469632e646c6c006765745f49734e756c6c0053797374656d0053797374656d2e5265666c656374696f6e0050686f6e6574696351756f7461457863657074696f6e00496e76616c69644f7065726174696f6e457863657074696f6e00537472696e67436f6d70617269736f6e004368617200537472696e674275696c646572004d6963726f736f66742e53716c5365727665722e536572766572004d6178696d756d436f646550616972004572726f72006572726f72002e63746f720053797374656d2e446961676e6f73746963730053797374656d2e52756e74696d652e496e7465726f7053657276696365730053797374656d2e52756e74696d652e436f6d70696c6572536572766963657300446562756767696e674d6f6465730053797374656d2e446174612e53716c547970657300636f6e7461696e730053797374656d2e436f6c6c656374696f6e73006765745f43686172730053716c436861727300636861724174004f626a65637400746172676574006c65667400726967687400446f75626c654d65746170686f6e65526573756c7400726573756c7400697353696c656e745374617274007374617274005075740050686f6e65746963496e707574004e756c6c496e707574006e756c6c496e707574004d6178696d756d496e7075740053797374656d2e54657874007465787400446f75626c65526f770046696c6c436f6c6f676e65526f770046696c6c446f75626c654d65746170686f6e65526f7700726f7700696e646578006765745f5072696d61727900617070656e645072696d617279007072696d61727900000000001d500048004f004e0045005400490043005f00510055004f0054004100002b500048004f004e0045005400490043005f0049004e005000550054005f004c0045004e004700540048000027500048004f004e0045005400490043005f0049004e005000550054005f0052004500410044000027500048004f004e0045005400490043005f0043004f00440045005f0053004800410050004500002d500048004f004e0045005400490043005f0043004f00440045005f0041004c00500048004100420045005400000f4100450049004a004f00550059000007430053005a0000094600500056005700000747004b005100000743004b0051000013410048004b004c004f005100520055005800000553005a00000f410048004b004f005100550058000007440054005800000547004e0000054b004e00000550004e00000557005200000550005300000543005a0000095700490054005a00000d4100450049004f0055005900000943004800490041000007410043004800000d420041004300480045005200000d4d0041004300480045005200000b48004100520041004300000b48004100520049005300000748004f0052000007480059004d0000074800490041000007480045004d00000b430048004f00520045000009560041004e002000000956004f004e0020000007530043004800000d4f0052004300480045005300000d410052004300480049005400000d4f005200430048004900440000035400000353000003410000034f00000355000003450000034c000003520000034e0000034d00000342000003480000034600000356000003570000032000000949004c004c004f00000949004c004c004100000941004c004c00450000054100530000054f005300000755004d004200000545005200000d43004100450053004100520000054300480000095700490043005a000007430049004100000543004300000543004b000005430047000005430051000005430049000005430045000005430059000007430049004f0000074300490045000005200043000005200051000005200047000003430000034b000003510000034900000548005500000b55004300430045004500000b5500430043004500530000054b0053000009430048004100450000054d00430000054400470000035900000554004b0000054400540000054400440000054500590000054c00490000054b004c00000545005300000545005000000545004200000545004c00000549004200000549004c00000549004e00000549004500000545004900000d440041004e00470045005200000d520041004e00470045005200000d4d0041004e00470045005200000752004700590000074f00470059000009410047004700490000094f004700470049000005450054000007490045005200000344000003470000094a004f00530045000009530041004e00200000035a000003500000054d00450000054d0041000007490053004c000007590053004c00000b5300550047004100520000055300480000094800450049004d00000948004f0045004b00000948004f004c004d00000948004f004c005a000007530049004f00000753004900410000095300490041004e0000055300430000054100490000054f00490000054f004f00000545004e00000555005900000545004400000545004d0000035800000553004b000009540049004f004e0000075400490041000007540043004800000554004800000754005400480000054f004d00000541004d00000557004800000b4500570053004b004900000b4500570053004b005900000b4f00570053004b004900000b4f00570053004b0059000005540053000005460058000007490041005500000745004100550000054100550000054f00550000055a004f0000055a00490000055a0041000033500048004f004e0045005400490043005f0043004f004c004f0047004e0045005f0052004f0057005f0054005900500045000031500048004f004e0045005400490043005f0044004f00550042004c0045005f0052004f0057005f0054005900500045000035500048004f004e0045005400490043005f0043004f004c004f0047004e0045005f0052004f0057005f00530048004100500045000033500048004f004e0045005400490043005f0044004f00550042004c0045005f0052004f0057005f00530048004100500045000031500048004f004e0045005400490043005f0044004f00550042004c0045005f0052004f0057005f0050004100490052000000712fe5d2a28c95429f0839e9b98046ee00042001010803200001052001011111042001010e042001010212070d0a1d030a080812390a081d0308030803032000020320000a0820040a0a1d03080804000102030320000e032000080520011239030407020e0804200103080907061239030308030304200108030607031d0e080e080005080e080e0808062002080e11650707040208121c030307010308070502080e0e122009070602080e0e0e122404070112200306115104070112240307010205200112390e08b77a5c561934e08904001000000400200000040040000004008000000206080306123902060e02060208000308123502100e06000201123903040001010e0400010e0e080003011239031003080004020e08081d0e040001020e050001121c0e050002020e0806000208121c08070003080e121c08080004080e121c0802050002030e08060001124d12350a0003011c1011511011550d0004011c1011511011511011550500010112200500010112240600020112390e0420010103052002010303052002010e0e062003010e0802072004010e0e08020328000e0801000800000000001e01000100540216577261704e6f6e457863657074696f6e5468726f7773010801000200000000001d010018546f6f6c62656c742e537472696e672e50686f6e6574696300005101004c42656772656e7a74652073706569636865727265696e65204bc3b66c6e65722050686f6e6574696b20756e6420766f6c6c7374c3a46e646967657320446f75626c65204d65746170686f6e6500000d0100086765636f6d70617400001801001353514c2053657276657220546f6f6c62656c7400000501000000000c010007312e302e302e30000081a50100060054020f497344657465726d696e697374696301540209497350726563697365015455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d4461746141636365737300000000540e1146696c6c526f774d6574686f644e616d650e46696c6c436f6c6f676e65526f77540e0f5461626c65446566696e6974696f6e2950686f6e65746963436f6465206e76617263686172286d6178292c204572726f72436f646520696e7481c90100060054020f497344657465726d696e697374696301540209497350726563697365015455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d4461746141636365737300000000540e1146696c6c526f774d6574686f644e616d651646696c6c446f75626c654d65746170686f6e65526f77540e0f5461626c65446566696e6974696f6e455072696d617279436f6465206e76617263686172286d6178292c20416c7465726e617465436f6465206e76617263686172286d6178292c204572726f72436f646520696e7404010000000000000000000000000000000000100000000000000000000000000000005060000000000000000000006a6000000020000000000000000000000000000000000000000000005c600000000000000000000000005f436f72446c6c4d61696e006d73636f7265652e646c6c0000000000ff250020001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100100000001800008000000000000000000000000000000100010000003000008000000000000000000000000000000100000000004800000058800000e80300000000000000000000e80334000000560053005f00560045005200530049004f004e005f0049004e0046004f0000000000bd04effe00000100000001000000000000000100000000003f000000000000000400000002000000000000000000000000000000440000000100560061007200460069006c00650049006e0066006f00000000002400040000005400720061006e0073006c006100740069006f006e00000000000000b00448030000010053007400720069006e006700460069006c00650049006e0066006f000000240300000100300030003000300030003400620030000000ae004b00010043006f006d006d0065006e00740073000000420065006700720065006e007a00740065002000730070006500690063006800650072007200650069006e00650020004b00f6006c006e00650072002000500068006f006e006500740069006b00200075006e006400200076006f006c006c0073007400e4006e0064006900670065007300200044006f00750062006c00650020004d00650074006100700068006f006e0065000000000032000900010043006f006d00700061006e0079004e0061006d006500000000006700650063006f006d00700061007400000000005a0019000100460069006c0065004400650073006300720069007000740069006f006e000000000054006f006f006c00620065006c0074002e0053007400720069006e0067002e00500068006f006e00650074006900630000000000300008000100460069006c006500560065007200730069006f006e000000000031002e0030002e0030002e00300000005a001d00010049006e007400650072006e0061006c004e0061006d006500000054006f006f006c00620065006c0074002e0053007400720069006e0067002e00500068006f006e0065007400690063002e0064006c006c00000000002800020001004c006500670061006c0043006f00700079007200690067006800740000002000000062001d0001004f0072006900670069006e0061006c00460069006c0065006e0061006d006500000054006f006f006c00620065006c0074002e0053007400720069006e0067002e00500068006f006e0065007400690063002e0064006c006c0000000000480014000100500072006f0064007500630074004e0061006d00650000000000530051004c002000530065007200760065007200200054006f006f006c00620065006c0074000000340008000100500072006f006400750063007400560065007200730069006f006e00000031002e0030002e0030002e003000000038000800010041007300730065006d0062006c0079002000560065007200730069006f006e00000031002e0030002e0030002e003000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006000000c0000007c3000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000,
        @DeploymentMode nvarchar(max)=N'central',@ConfirmNoExternalConsumers bit=0;
-- Gemeinsamer Lifecycle-Preflight, kein eigenständiger öffentlicher EntryPoint.
-- @Install, @AssemblyBits, @DeploymentMode und @ConfirmNoExternalConsumers
-- werden ausschließlich vom konkreten Deploy-/Uninstall-Adapter gesetzt.
IF @@TRANCOUNT <> 0
BEGIN
    RAISERROR(N'Der Phonetik-Lifecycle akzeptiert keine Caller-Transaktion.',16,1);
    RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
DECLARE @ModuleId nvarchar(128)=N'toolbelt.string.phonetic',
        @VersionProperty sysname=N'Toolbelt.Module.toolbelt.string.phonetic.Version',
        @ModeProperty sysname=N'Toolbelt.Module.toolbelt.string.phonetic.DeploymentMode',
        @InstalledVersion nvarchar(max),@InstalledMode nvarchar(max),
        @Release bit,@AssemblyId int,@InstalledHash varbinary(64),
        @TargetHash varbinary(64)=HASHBYTES(N'SHA2_512',@AssemblyBits),
        @ExpectedHash varbinary(64),@ExpectedAbsent bit=0,
        @ExpectedText nvarchar(max)=N'0xc1155aa10d9fce61ae33cf8e6f6c68528d219db4835d74b3a35e129f851f66e2fca47c99a6f8f74f3d38239f9be84968459366bbfbeb0125c077b61a8d1989e9',
        @Pass int=1,@OwnTransaction bit=0,@SchemaId int,@SchemaOwner int;
DECLARE @Slots TABLE(Name sysname COLLATE DATABASE_DEFAULT PRIMARY KEY,
    Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL,ObjectId int NULL,
    Method sysname NULL,CodeColumns int NOT NULL);
INSERT @Slots VALUES
 (N'TVF_ColognePhonetic','IF',NULL,NULL,1),
 (N'TVF_DoubleMetaphone','IF',NULL,NULL,2),
 (N'TVF_ColognePhoneticCore','FT',NULL,N'EvaluateCologne',1),
 (N'TVF_DoubleMetaphoneCore','FT',NULL,N'EvaluateDoubleMetaphone',2);
IF ISNULL(TRY_CONVERT(int,SERVERPROPERTY(N'ProductMajorVersion')),0) NOT IN(15,16,17)
    THROW 55260,N'Phonetik unterstützt SQL Server 2019,2022,2025.',1;
IF @Install=1 AND (@DeploymentMode IS NULL OR CONVERT(varbinary(max),@DeploymentMode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central')) OR DATALENGTH(@DeploymentMode) NOT IN(10,14))
    THROW 55261,N'DeploymentMode muss local oder central sein.',1;
IF CONVERT(varbinary(max),@ExpectedText)=CONVERT(varbinary(max),N'0x') SET @ExpectedAbsent=1;
ELSE
BEGIN
    IF @ExpectedText IS NULL OR DATALENGTH(@ExpectedText)<>260
       OR CONVERT(varbinary(max),LEFT(@ExpectedText,2))<>CONVERT(varbinary(max),N'0x')
       OR SUBSTRING(@ExpectedText,3,128) COLLATE Latin1_General_100_BIN2 LIKE N'%[^0-9A-Fa-f]%'
       OR DATALENGTH(TRY_CONVERT(varbinary(max),@ExpectedText,1))<>64
       OR TRY_CONVERT(varbinary(max),@ExpectedText,1) IS NULL
        THROW 55262,N'ExpectedInstalledAssemblyHash muss 0x oder ein vollständiger SHA2-512-Hexhash sein.',1;
    SET @ExpectedHash=CONVERT(varbinary(64),@ExpectedText,1);
END;
BEGIN TRY
 WHILE @Pass<=2
 BEGIN
    IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
       OR ISNULL(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
        THROW 55263,N'Vollständige Lifecycle-Metadatensicht fehlt; keine Rechtevergabe.',1;
    SET @InstalledVersion=NULL;SET @InstalledMode=NULL;SET @AssemblyId=NULL;SET @InstalledHash=NULL;
    SELECT @InstalledVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty;
    SELECT @InstalledMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@ModeProperty;
    SET @Release=CASE WHEN CONVERT(varbinary(max),@InstalledVersion)=CONVERT(varbinary(max),N'1.0.0') THEN 1 ELSE 0 END;
    SELECT @AssemblyId=a.assembly_id,@InstalledHash=HASHBYTES(N'SHA2_512',f.content)
    FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
    WHERE a.name=N'Toolbelt_String_Phonetic';
    SET @SchemaId=SCHEMA_ID(N'toolbelt_string');
    SET @SchemaOwner=NULL;
    SELECT @SchemaOwner=principal_id FROM sys.schemas WHERE schema_id=@SchemaId;
    UPDATE s SET ObjectId=o.object_id FROM @Slots s LEFT JOIN sys.objects o
        ON o.schema_id=@SchemaId AND o.name COLLATE DATABASE_DEFAULT=s.Name;
    IF @SchemaId IS NOT NULL AND
       (NOT EXISTS(SELECT 1 FROM sys.schemas WHERE schema_id=@SchemaId AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'toolbelt_string'))
        OR @SchemaOwner IS NULL
        OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=@SchemaId AND minor_id=0 AND name=N'Toolbelt.Managed' AND TRY_CONVERT(int,value)=1)
        OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=@SchemaId AND minor_id=0 AND name=N'Toolbelt.SchemaCategory' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'string')))
        THROW 55264,N'Das vorhandene Schema ist nicht kohärent zugeordnet.',1;
    IF @Release=0 AND (EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name IN(@VersionProperty,@ModeProperty)) OR @AssemblyId IS NOT NULL OR EXISTS(SELECT 1 FROM @Slots WHERE ObjectId IS NOT NULL))
        THROW 55264,N'Unbekannter Modulzustand oder fremde Zielslotbelegung.',2;
    IF @Release=1 AND (@InstalledMode IS NULL OR CONVERT(varbinary(max),@InstalledMode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central')))
        THROW 55264,N'Der installierte Modus ist inkohärent.',3;
    IF (@Release=0 AND @ExpectedAbsent=0) OR (@Release=1 AND @ExpectedAbsent=1)
        THROW 55262,N'Die erwartete Assembly-Anwesenheit stimmt nicht.',2;
    IF @Release=1 AND (@InstalledHash IS NULL OR @InstalledHash<>@ExpectedHash)
        THROW 55265,N'Der installierte Hash stimmt nicht mit der Offline-Erwartung überein.',1;
    IF @Release=1 AND
      (NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@AssemblyId AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_String_Phonetic') AND permission_set=1 AND is_user_defined=1 AND principal_id=@SchemaOwner)
       OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@AssemblyId)<>1
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.Managed' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'bit' AND TRY_CONVERT(bit,value)=1)
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@ModuleId))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'1.0.0')))
        THROW 55264,N'Assemblytyp, Eigentümer oder Marker sind inkohärent.',4;
    IF @Release=1 AND EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id=s.ObjectId WHERE
       o.object_id IS NULL OR CONVERT(varbinary(max),o.name)<>CONVERT(varbinary(max),s.Name) OR CONVERT(varbinary(2),o.type)<>CONVERT(varbinary(2),s.Kind)
       OR COALESCE(o.principal_id,@SchemaOwner)<>@SchemaOwner
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.Managed' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'bit' AND TRY_CONVERT(bit,value)=1)
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@ModuleId))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'1.0.0'))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.Visibility' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),CASE WHEN s.Kind='FT' THEN N'internal' ELSE N'public' END)))
        THROW 55264,N'Slottypen, Eigentümer oder Marker sind inkohärent.',5;
    IF @Release=1 AND EXISTS(SELECT 1 FROM @Slots s WHERE s.Kind='FT' AND NOT EXISTS
       (SELECT 1 FROM sys.assembly_modules m WHERE m.object_id=s.ObjectId AND m.assembly_id=@AssemblyId AND m.null_on_null_input=0 AND m.execute_as_principal_id IS NULL
        AND CONVERT(varbinary(max),m.assembly_class)=CONVERT(varbinary(max),N'Toolbelt.String.Phonetic.PhoneticBridge') AND CONVERT(varbinary(max),m.assembly_method)=CONVERT(varbinary(max),s.Method)))
        THROW 55264,N'Die CLR-EntryPoint-Bindung ist inkohärent.',6;
    IF @Release=1 AND EXISTS(SELECT 1 FROM @Slots s WHERE
       (SELECT COUNT(*) FROM sys.parameters WHERE object_id=s.ObjectId AND parameter_id>0)<>1
       OR NOT EXISTS(SELECT 1 FROM sys.parameters WHERE object_id=s.ObjectId AND parameter_id=1 AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'@Text') AND system_type_id=231 AND user_type_id=system_type_id AND max_length=-1 AND is_output=0 AND has_default_value=0)
       OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=s.ObjectId)<>s.CodeColumns+1
       OR EXISTS(SELECT 1 FROM sys.columns c WHERE c.object_id=s.ObjectId AND
          (c.user_type_id<>c.system_type_id OR
           (c.column_id<=s.CodeColumns AND (c.system_type_id<>CASE WHEN s.Kind='FT' THEN 231 ELSE 167 END OR c.max_length<>-1 OR c.is_nullable<>1 OR CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),CASE WHEN s.CodeColumns=1 THEN N'PhoneticCode' WHEN c.column_id=1 THEN N'PrimaryCode' ELSE N'AlternateCode' END)))
           OR(s.Kind='IF' AND c.column_id<=s.CodeColumns AND CONVERT(varbinary(max),c.collation_name)<>CONVERT(varbinary(max),N'Latin1_General_100_BIN2'))
           OR(c.column_id=s.CodeColumns+1 AND(c.system_type_id<>56 OR c.max_length<>4 OR CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'ErrorCode'))))))
        THROW 55264,N'Parameter oder Ergebnisfelder sind inkohärent.',7;
    IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d WHERE
       (EXISTS(SELECT 1 FROM @Slots WHERE ObjectId=d.referenced_id)
        OR(d.referenced_id IS NULL AND (d.referenced_database_name IS NULL OR d.referenced_database_name COLLATE DATABASE_DEFAULT=DB_NAME()) AND d.referenced_schema_name COLLATE DATABASE_DEFAULT=N'toolbelt_string' AND EXISTS(SELECT 1 FROM @Slots WHERE Name=d.referenced_entity_name COLLATE DATABASE_DEFAULT)))
        AND NOT EXISTS(SELECT 1 FROM @Slots WHERE ObjectId=d.referencing_id))
        THROW 55266,N'Ein fremder SQL-Verbraucher blockiert den Lifecycle.',1;
    IF EXISTS(SELECT 1 FROM sys.assembly_modules m WHERE m.assembly_id=@AssemblyId AND NOT EXISTS(SELECT 1 FROM @Slots WHERE Kind='FT' AND ObjectId=m.object_id))
       OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@AssemblyId)
        THROW 55266,N'Ein fremder Assembly-Verbraucher blockiert den Lifecycle.',2;
    IF @Install=0 AND @Release=1 AND CONVERT(varbinary(max),@InstalledMode)=CONVERT(varbinary(max),N'central') AND @ConfirmNoExternalConsumers<>1
        THROW 55267,N'Central-Uninstall benötigt explizite Consumerbestätigung.',1;
    IF @Install=1
    BEGIN
       IF @AssemblyBits IS NULL OR DATALENGTH(@AssemblyBits)<1024 OR @TargetHash IS NULL THROW 55268,N'AssemblyBits enthält kein vollständiges Binary.',1;
       IF NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr enabled' AND value_in_use=1)
          OR NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr strict security' AND value_in_use=1)
          THROW 55268,N'CLR enabled und strict security müssen bereits wirksam sein.',2;
       IF NOT EXISTS(SELECT 1 FROM sys.trusted_assemblies WHERE hash=@TargetHash) THROW 55268,N'Der exakte Zielhash ist nicht separat autorisiert.',3;
       IF @AssemblyId IS NULL AND @SchemaId IS NOT NULL AND @SchemaOwner<>USER_ID() THROW 55269,N'Neue Assembly und vorhandenes Schema benötigen denselben effektiven Eigentümer.',1;
       IF @SchemaId IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE SCHEMA'),0)<>1 THROW 55269,N'CREATE SCHEMA fehlt.',2;
       IF @SchemaId IS NOT NULL AND ISNULL(HAS_PERMS_BY_NAME(N'toolbelt_string',N'SCHEMA',N'ALTER'),0)<>1 THROW 55269,N'Schema-ALTER fehlt.',3;
       IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE FUNCTION'),0)<>1 THROW 55269,N'CREATE FUNCTION fehlt.',4;
       IF @AssemblyId IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE ASSEMBLY'),0)<>1 THROW 55269,N'CREATE ASSEMBLY fehlt.',5;
       IF @AssemblyId IS NOT NULL AND @InstalledHash<>@TargetHash AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'ALTER ANY ASSEMBLY'),0)<>1 THROW 55269,N'ALTER ANY ASSEMBLY fehlt.',6;
    END;
    IF @Pass=1
    BEGIN
       BEGIN TRANSACTION;SET @OwnTransaction=1;
       DECLARE @LockResult int;
       EXEC @LockResult=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.string.phonetic',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
       IF @LockResult<0 THROW 55270,N'Ein paralleler Phonetik-Lifecycle ist aktiv.',1;
    END;
    SET @Pass+=1;
 END;
 IF @Install=1 AND @SchemaId IS NULL
 BEGIN
    EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_string];';
    EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_string';
    EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'string',@level0type=N'SCHEMA',@level0name=N'toolbelt_string';
 END;
 IF @Release=1
 BEGIN
    DROP FUNCTION toolbelt_string.TVF_ColognePhonetic;
    DROP FUNCTION toolbelt_string.TVF_DoubleMetaphone;
    DROP FUNCTION toolbelt_string.TVF_ColognePhoneticCore;
    DROP FUNCTION toolbelt_string.TVF_DoubleMetaphoneCore;
 END;
 IF @Install=1
 BEGIN
    IF @AssemblyId IS NULL OR @InstalledHash<>@TargetHash
    BEGIN
       DECLARE @Ddl nvarchar(max)=CASE WHEN @AssemblyId IS NULL THEN N'CREATE' ELSE N'ALTER' END+N' ASSEMBLY [Toolbelt_String_Phonetic] FROM '+CONVERT(nvarchar(max),@AssemblyBits,1)+N' WITH PERMISSION_SET=SAFE;';
       EXEC sys.sp_executesql @Ddl;
    END;
 END
 ELSE
 BEGIN
    IF @Release=1
    BEGIN
       DROP ASSEMBLY Toolbelt_String_Phonetic;
       EXEC sys.sp_dropextendedproperty @name=@VersionProperty;
       EXEC sys.sp_dropextendedproperty @name=@ModeProperty;
       IF NOT EXISTS(SELECT 1 FROM sys.objects WHERE schema_id=@SchemaId) AND NOT EXISTS(SELECT 1 FROM sys.types WHERE schema_id=@SchemaId AND is_user_defined=1) AND NOT EXISTS(SELECT 1 FROM sys.xml_schema_collections WHERE schema_id=@SchemaId) DROP SCHEMA toolbelt_string;
    END;
    COMMIT TRANSACTION;SET @OwnTransaction=0;
 END;
END TRY
BEGIN CATCH
 IF @OwnTransaction=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
-- Interner FT: eager speicherreine Bridge, NULL-/Fehlerzeile bleibt sichtbar.
CREATE FUNCTION toolbelt_string.TVF_ColognePhoneticCore(@Text nvarchar(max))
RETURNS TABLE (PhoneticCode nvarchar(max), ErrorCode int)
AS EXTERNAL NAME [Toolbelt_String_Phonetic].[Toolbelt.String.Phonetic.PhoneticBridge].[EvaluateCologne];
GO
-- Interner FT: beide vollständigen Codes werden vor der einzelnen Zeile ermittelt.
CREATE FUNCTION toolbelt_string.TVF_DoubleMetaphoneCore(@Text nvarchar(max))
RETURNS TABLE (PrimaryCode nvarchar(max), AlternateCode nvarchar(max), ErrorCode int)
AS EXTERNAL NAME [Toolbelt_String_Phonetic].[Toolbelt.String.Phonetic.PhoneticBridge].[EvaluateDoubleMetaphone];
GO
-- ============================================================================
-- Objekt:          toolbelt_string.TVF_ColognePhonetic
-- Typ:             Inline TVF
-- Zweck:           Vollständige begrenzte Kölner Phonetik ohne Vergleichsoption.
-- Vertrag:         Documentation/Architecture/PHONETIC_CONTRACT.md
-- Parameter:       @Text nvarchar(max), kein Default
-- Resultset:       PhoneticCode varchar(max) NULL, ErrorCode int
-- Dependencies:    eigener SAFE-Kern TVF_ColognePhoneticCore
-- Rechte:          SELECT; keine Runtime-Metadaten-/Hashprüfung
-- Versionen:       SQL Server 2019/2022/2025
-- Plattformen:     Windows/Linux, Qualifikation noch offen
-- Fehlerverhalten: Status0..3, technische CLR-Defekte bleiben technische Fehler
-- Performance:     4096 UTF16-Einheiten; keine Parallelitäts-/Heapzusage
-- Einschränkungen: geschlossenes Alphabet; keine optionale Normalisierung
-- ============================================================================
CREATE FUNCTION toolbelt_string.TVF_ColognePhonetic(@Text nvarchar(max))
RETURNS TABLE
AS RETURN
(
    SELECT CONVERT(varchar(max),PhoneticCode COLLATE Latin1_General_100_BIN2) COLLATE Latin1_General_100_BIN2 AS PhoneticCode, ErrorCode
    FROM toolbelt_string.TVF_ColognePhoneticCore(@Text)
);
GO
-- ============================================================================
-- Objekt:          toolbelt_string.TVF_DoubleMetaphone
-- Typ:             Inline TVF
-- Zweck:           Vollständiger primärer und alternativer Double-Metaphone-Code.
-- Vertrag:         Documentation/Architecture/PHONETIC_CONTRACT.md
-- Parameter:       @Text nvarchar(max), kein Default
-- Resultset:       PrimaryCode/AlternateCode varchar(max) NULL, ErrorCode int
-- Dependencies:    eigener SAFE-Kern TVF_DoubleMetaphoneCore
-- Rechte:          SELECT; keine Runtime-Metadaten-/Hashprüfung
-- Versionen:       SQL Server 2019/2022/2025
-- Plattformen:     Windows/Linux, Qualifikation noch offen
-- Fehlerverhalten: Status0..3, technische CLR-Defekte bleiben technische Fehler
-- Performance:     4096 UTF16-Einheiten; kein Vierzeichenclamp
-- Einschränkungen: geschlossenes Alphabet; terminales Alternativ-Leerbyte bleibt
-- ============================================================================
CREATE FUNCTION toolbelt_string.TVF_DoubleMetaphone(@Text nvarchar(max))
RETURNS TABLE
AS RETURN
(
    SELECT CONVERT(varchar(max),PrimaryCode COLLATE Latin1_General_100_BIN2) COLLATE Latin1_General_100_BIN2 AS PrimaryCode,
           CONVERT(varchar(max),AlternateCode COLLATE Latin1_General_100_BIN2) COLLATE Latin1_General_100_BIN2 AS AlternateCode, ErrorCode
    FROM toolbelt_string.TVF_DoubleMetaphoneCore(@Text)
);
GO
-- Abschluss derselben eigenen SQLCMD-Transaktion; kein separater EntryPoint.
IF @@TRANCOUNT<>1 OR XACT_STATE()<>1
    THROW 55270,N'Der eigene Lifecycle-Transaktionszustand fehlt.',2;
BEGIN TRY
 DECLARE @AssemblyMarkerId int=(SELECT assembly_id FROM sys.assemblies WHERE CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_String_Phonetic'));
 DECLARE @Version sql_variant=CONVERT(nvarchar(16),N'1.0.0'),
         @Module sql_variant=CONVERT(nvarchar(128),N'toolbelt.string.phonetic'),
         @Managed sql_variant=CONVERT(bit,1),
         @Mode sql_variant=CONVERT(nvarchar(16),N'central'),
         @Schema sysname=N'toolbelt_string',@Name sysname,@Visibility sql_variant;
 DECLARE @Properties TABLE(Name sysname,Value sql_variant);
 INSERT @Properties VALUES
 (N'Toolbelt.Module.toolbelt.string.phonetic.Version',@Version),
 (N'Toolbelt.Module.toolbelt.string.phonetic.DeploymentMode',@Mode);
 DECLARE @Property sysname,@Value sql_variant;
 DECLARE DatabaseMarkers CURSOR LOCAL FAST_FORWARD FOR SELECT Name,Value FROM @Properties;
 OPEN DatabaseMarkers;FETCH NEXT FROM DatabaseMarkers INTO @Property,@Value;
 WHILE @@FETCH_STATUS=0
 BEGIN
  IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@Property)
   EXEC sys.sp_updateextendedproperty @name=@Property,@value=@Value;
  ELSE EXEC sys.sp_addextendedproperty @name=@Property,@value=@Value;
  FETCH NEXT FROM DatabaseMarkers INTO @Property,@Value;
 END;
 CLOSE DatabaseMarkers;DEALLOCATE DatabaseMarkers;
 DECLARE ObjectMarkers CURSOR LOCAL FAST_FORWARD FOR SELECT name FROM sys.objects WHERE schema_id=SCHEMA_ID(@Schema) AND name IN
  (N'TVF_ColognePhonetic',N'TVF_DoubleMetaphone',N'TVF_ColognePhoneticCore',N'TVF_DoubleMetaphoneCore');
 OPEN ObjectMarkers;FETCH NEXT FROM ObjectMarkers INTO @Name;
 WHILE @@FETCH_STATUS=0
 BEGIN
  SET @Visibility=CONVERT(nvarchar(16),CASE WHEN RIGHT(@Name,4)=N'Core' THEN N'internal' ELSE N'public' END);
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=@Managed,@level0type=N'SCHEMA',@level0name=@Schema,@level1type=N'FUNCTION',@level1name=@Name;
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.ModuleId',@value=@Module,@level0type=N'SCHEMA',@level0name=@Schema,@level1type=N'FUNCTION',@level1name=@Name;
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.ModuleVersion',@value=@Version,@level0type=N'SCHEMA',@level0name=@Schema,@level1type=N'FUNCTION',@level1name=@Name;
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Visibility',@value=@Visibility,@level0type=N'SCHEMA',@level0name=@Schema,@level1type=N'FUNCTION',@level1name=@Name;
  FETCH NEXT FROM ObjectMarkers INTO @Name;
 END;
 CLOSE ObjectMarkers;DEALLOCATE ObjectMarkers;
 IF (SELECT COUNT(*) FROM sys.objects WHERE schema_id=SCHEMA_ID(@Schema) AND name IN
 (N'TVF_ColognePhonetic',N'TVF_DoubleMetaphone',N'TVF_ColognePhoneticCore',N'TVF_DoubleMetaphoneCore'))<>4
  THROW 55264,N'Der vollständige Zielslotbestand fehlt.',8;
 -- Die Assembly bleibt bei gleichem Binary bestehen; vorhandene bekannte
 -- Marker werden aktualisiert, die Funktionen wurden atomar neu angelegt.
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyMarkerId AND name=N'Toolbelt.Managed')
 BEGIN
  EXEC sys.sp_updateextendedproperty @name=N'Toolbelt.Managed',@value=@Managed,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_String_Phonetic';
  EXEC sys.sp_updateextendedproperty @name=N'Toolbelt.ModuleId',@value=@Module,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_String_Phonetic';
  EXEC sys.sp_updateextendedproperty @name=N'Toolbelt.ModuleVersion',@value=@Version,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_String_Phonetic';
 END
 ELSE
 BEGIN
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=@Managed,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_String_Phonetic';
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.ModuleId',@value=@Module,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_String_Phonetic';
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.ModuleVersion',@value=@Version,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_String_Phonetic';
 END;
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.string.phonetic
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.string.regex
:On Error exit
-- RETURN beendet den gesamten ersten Batch; SQLCMD stoppt vor weiteren Batches.
IF @@TRANCOUNT <> 0
BEGIN
    RAISERROR(N'Der Regex-Lifecycle akzeptiert keine Caller-Transaktion.', 16, 1);
    RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @VersionProperty sysname = N'Toolbelt.Module.toolbelt.string.regex.Version',
        @ModeProperty sysname = N'Toolbelt.Module.toolbelt.string.regex.DeploymentMode',
        @InstalledVersion nvarchar(max), @InstalledMode nvarchar(max),
        @Release int, @AssemblyId int, @InstalledAssemblyHash varbinary(64),
        @Pass int = 1, @OwnTransaction bit = 0;
DECLARE @Slots TABLE (Name sysname COLLATE DATABASE_DEFAULT PRIMARY KEY, SinceRelease int NOT NULL,
                      Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL, ObjectId int NULL);
INSERT @Slots(Name, SinceRelease, Kind) VALUES
    (N'SVF_RegexIsMatch', 10, 'FS'),
    (N'SVF_RegexInstr', 10, 'FS'),
    (N'SVF_RegexCount', 10, 'FS'),
    (N'SVF_RegexReplace', 11, 'FN'),
    (N'SVF_RegexSubstring', 11, 'FN'),
    (N'SVF_RegexReplaceCore', 11, 'FS'),
    (N'SVF_RegexSubstringCore', 11, 'FS'),
    (N'TVF_RegexMatches', 12, 'IF'),
    (N'TVF_RegexSplit', 12, 'IF'),
    (N'TVF_RegexMatchesCore', 12, 'FT'),
    (N'TVF_RegexSplitCore', 12, 'FT'),
    (N'TVF_RegexCaptures', 13, 'IF'),
    (N'SVF_RegexReplaceGroups', 13, 'FN'),
    (N'TVF_RegexCapturesCore', 13, 'FT'),
    (N'SVF_RegexReplaceGroupsCore', 13, 'FS');
DECLARE @DeploymentMode nvarchar(16) = LOWER(N'central'),
        @AssemblyBits varbinary(max) = 0x4d5a90000300000004000000ffff0000b800000000000000400000000000000000000000000000000000000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a2400000000000000504500004c01030033bbe9970000000000000000e00022200b013000006a00000008000000000000da8900000020000000a000000000001000200000000200000400000000000000060000000000000000e000000002000000000000030060850000100000100000000010000010000000000000100000000000000000000000888900004f00000000a000005c0400000000000000000000000000000000000000c000000c0000006c8900001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000080000000000000000000000082000004800000000000000000000002e74657874000000e069000000200000006a000000020000000000000000000000000000200000602e727372630000005c04000000a0000000060000006c0000000000000000000000000000400000402e72656c6f6300000c00000000c0000000020000007200000000000000000000000000004000004200000000000000000000000000000000bc8900000000000048000000020005003c4b0000303e000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001b30020055000000010000110f00280f00000a2d090f01280f00000a2c067e1000000a2a0f00281100000a28040000060a0f01281100000a0428050000060b07066f1200000a731300000a0cde11267201000070722500007028110000067a082a00000001100000000033000f420011150000011b30040043010000020000110f00280f00000a2d090f01280f00000a2c067e1400000a2a0f02281500000a2d0a0f02281600000a172f10729d00007072d300007028110000067a0f03281500000a2d0a0f03281600000a172f10729d000070720f01007028110000067a0f04281500000a2d130f04281600000a2c1a0f04281600000a172e10729d000070725501007028110000067a0f00281100000a28040000060a0f02281600000a066f1700000a1758310716731800000a2a0f01281100000a0e0573360000060b07060f02281600000a17596f380000060c170d2b0d0706086f390000060c0917580d086f1900000a2c0a090f03281600000a32e1086f1900000a2d0a16731800000a1304de3c0f04281600000a2c11086f1a00000a086f1b00000a5817582b08086f1a00000a1758731800000a1304de11267201000070722500007028110000067a11042a00011000000000be00712f0111150000011b300400b6000000030000110f00280f00000a2d090f01280f00000a2c067e1400000a2a0f02281500000a2d0a0f02281600000a172f10729d00007072d300007028110000067a0f00281100000a28040000060a0f02281600000a066f1700000a1758310716731800000a2a0f01281100000a0573360000060b160c07060f02281600000a17596f380000060d2b0d0817d60c0706096f390000060d096f1900000a2deb08731800000a1304de11267201000070722500007028110000067a11042a00000110000000006e0034a20011150000017e026f1700000a2000001000311072cf010070720302007028110000067a022a1b3004005b00000004000011026f1700000a18d820401f00003110726902007072a102007028110000067a0328060000060a0206185f16fe0306175f16fe0328080000060b07067e04000004731c00000a0cde11267209030070723d03007028110000067a082a0001100000000039000f4800111900000113300200ef000000050000110f00280f00000a2c10729103007072c103007028110000067a160a160b160c160d0f00281100000a13051613062b77110511066f1d00000a130711071f69350e11071f632e1611071f692e1d2b4211071f6d2e2211071f732e292b34062c0628070000067a170a2b37072c0628070000067a170b2b2a082c0628070000067a170c2b1d092c0628070000067a170d2b10729103007072fd03007028110000067a110617581306110611056f1700000a3f7bffffff06075f2c107291030070725304007028110000067a20000200001304072c06110417601304082c06110418601304092c0711041f1060130411042a427291030070729304007028110000062a2a0203041428090000062a00133005004103000006000011026f1700000a1f1058731e00000a0a052c07731f00000a2b01140b052c0805734b0000062b01140c732000000a0d16130416130516130638c80200000211066f1d00000a130711071f3f354411071f2459450b000000f801000051020000510200005102000092000000ee000000720100007201000051020000510200002802000011071f3f3b69010000384302000011071f5b594504000000430000001b00000023020000aa01000011071f7b594503000000680100000d0100000d020000380e020000021206061604280a000006082c0f08176a166a73450000066f4c00000617130417130538110200000212060604280b000006082c0f08176a166a73450000066f4c00000617130417130538ea0100000911046f2100000a052d0e0672df0400706f2200000a262b38050212066f49000006130a0672e70400706f2200000a110a7b1a0000046f2200000a1f3e6f2300000a2607086f2400000a05734b0000060c161304161305388e010000096f2500000a2c0411042d0628100000067a061f296f2300000a26096f2600000a26082c2d086f50000006130b120b05110b7b1d000004176a6f470000067d1d000004076f2700000a0c08110b6f4c000006171304171305383101000011042d0628100000067a061f7c6f2300000a26082c06086f4f000006161304161305380a01000011052d0628100000067a0611076f2300000a26082c160811071f2bfe0111071f3f2e03152b01176f4e00000616130538d600000011052d0628100000067a0212060612081209280e000006082c0a08110811096f4e00000616130538aa000000061f5e6f2300000a26082c0f08166a166a73450000066f4c000006171304161305388400000006032d0772ef0400702b0572f50400706f2200000a26082c0f08166a166a73450000066f4c0000061713041613052b54061f2e6f2300000a26082c0f08176a166a73450000066f4c0000061713041713052b3128100000067a061207282800000a282900000a6f2200000a26082c0f08176a166a73450000066f4c0000061713041713051106175813061106026f1700000a3f2bfdffff096f2500000a2d0c026f1700000a2c0a11042d0628100000067a082c0c05086f500000066f4a000006066f2a00000a2a00000013300300a60100000700001103034a17580b075407026f1700000a320628100000067a02034a6f1d00000a0a061f5e355b061f2459450b0000003601000046010000460100004601000036010000360100003601000036010000460100003601000036010000061f3f3b2e010000061f5b594504000000150100001501000015010000150100003820010000061f642e56061f663bf3000000061f6e594510000000aa000000ca0000005b000000ca000000aa0000001c000000aa000000ca000000ca00000033000000ca000000ca000000ca000000ba000000ba000000ba00000038c500000004052d0772f90400702b0572050500706f2200000a262a04052d07720d0500702b05722d0500706f2200000a262a052c0d0472490500706f2200000a262a040e042d07725f0500702b0572790500706f2200000a262a034a1958026f1700000a2f2a02034a17586f1d00000a1f7b331c02034a18586f1d00000a1f4c330e02034a19586f1d00000a1f7d2e0628100000067a04729f0500706f2200000a2603034a1958542a041f5c6f2300000a066f2300000a262a041f5c6f2300000a066f2300000a262a28100000067a0000133006004601000008000011034a17580a160b160c160d732b00000a1304732b00000a130506026f1700000a3c0f01000002066f1d00000a1f5e4001010000170c0617580a38f600000002066f1d00000a130611061f5d3319072d0628100000067a04110411050805280c0000060306542a11061f5b2e0a11061f5efe01075f2c0628100000067a11061f5c408d000000061758026f1700000a320628100000067a020617586f1d00000a130711071f642e0e11071f732e0811071f77fe012b0117252c4a11046f2c00000a163114110411046f2c00000a17596f2d00000a1f2d2e18061858026f1700000a2f13020618586f1d00000a1f2d330628100000067a02120011051705280a0000062b0c02120011041705280a0000060d2b1c11061f2dfe01095f2c0628100000067a110411066f2300000a26160d170b0617580a06026f1700000a3ffefeffff28100000067a000013300300fa00000009000011036f2c00000a2c1e72ab05007003252d0426142b056f2a00000a72af050070282e00000a2b01140a046f2c00000a2c1e72ab05007004252d0426142b056f2a00000a72af050070282e00000a2b01140b0e042c03072d2b021f5b6f2300000a26052c09021f5e6f2300000a2602036f2f00000a046f2f00000a1f5d6f2300000a262a72b30500700772bf050070282e00000a0c052d33062d0902086f2200000a262a0272df0400706f2200000a066f2200000a1f7c6f2300000a086f2200000a1f296f2300000a262a0272c30500706f2200000a26062c0f02066f2200000a1f7c6f2300000a2602086f2200000a72d10500706f2200000a262a0000133005000d0000000a00001102030412001201280e0000062a00000013300300d80000000b000011034a17580a05021200280f000006540e04054a54160b06026f1700000a2f3d02066f1d00000a1f2c33320617580a06026f1700000a2f1b02066f1d00000a283000000a2c0d0e04021200280f000006542b0a0e0420e803000054170b06026f1700000a2f2502066f1d00000a1f7d331a054a20e803000030110e044a20e803000030070e044a054a2f0628100000067a041f7b6f2300000a054a6f3100000a260e044a054afe0116fe0107602c16041f2c6f2300000a26072d0a040e044a6f3100000a26041f7d6f2300000a26030654072c040e0415542a13300300720000000a000011034a026f1700000a2f0f02034a6f1d00000a283000000a2d0628100000067a160a2b3402034a6f1d00000a1f30590b0620e8030000300d0620ffffff7f07591f0a5b310628100000067a061f0a5a07580a03034a175854034a026f1700000a2f0f02034a6f1d00000a283000000a2db3062a427209030070723d03007028110000062a4a0272e305007003282e00000a733200000a2a000013300700920000000c000011022c08026f3300000a2c067e3400000a2a026f3500000a036a310c0472e905007028110000067a026f3500000a698d2a0000010a160b2b3e052c07056f3b0000062602076a06072000100000068e690759283600000a6f3700000a0c08166a3010729d000070724d06007028110000067a070869580b07068e6932bc052c07056f3b0000062606733800000a733900000a2a000013300500400000000d00001104021e729d0000701428120000068113000001047113000001733a0000060a05031a72910300700628120000068113000001060571130000016f3d000006062a133006004b00000000000000026f3300000a2d08036f3300000a2c067e1000000a2a02200000100072cf0100701428120000060320a00f00007269020070142812000006041a729103007014281200000628010000062a00133007008f0000000e000011026f3300000a2d08036f3300000a2c067e1400000a2a0f02281500000a2d0a0f02281600000a172f10729d00007072d300007028110000067a02200000100072cf0100701428120000060a0f02281600000a1200281100000a6f1700000a1758310716731800000a2a060320a00f0000726902007014281200000604051a729103007014281200000628030000062a0013300900c20000000e000011026f3300000a2d08036f3300000a2c067e1400000a2a0f02281500000a2d390f02281600000a17322f0f03281500000a2d260f03281600000a17321c0f04281500000a2d130f04281600000a2c1a0f04281600000a172e10729d000070729d06007028110000067a02200000100072cf0100701428120000060a0f02281600000a1200281100000a6f1700000a1758310716731800000a2a060320a00f0000726902007014281200000604050e040e051a729103007014281200000628020000062a000013300800da0000000f000011026f3300000a2d14036f3300000a2d0c0e072c0e046f3300000a2c067e3400000a2a0e061e729d0000701428120000060a06733a0000060b050e040e0716fe0328200000060e051a72910300700728120000060c07086f3d00000602077b0e00000472cf0100700728120000060d0e072c1404077b0e00000472010700700728120000062b057e3400000a13040320401f0000726902007007281200000613050e072d0f091105050e0408060728220000062a0e071733110911051104050e0408060728240000062a0911051104050e0408060728340000062a520203283a00000a04050e040e051628170000062a46020304050e040e050e061728170000062a46020304050e040e050e061828170000062a0013300800d400000010000011026f3300000a2d08036f3300000a2c07168d100000012a0e041e729d0000701428120000060a06733a0000060b0f02281500000a2d2b0f02281600000a1732210f05281500000a2d180f05281600000a17320e0f05281600000a20a08601003110729d000070724107007028110000067a051a72910300700728120000060c07086f3d00000602077b0e00000472cf0100700728120000060d0320401f0000726902007007281200000613040e0618330f0911040408060e0507282d0000062a0911040408060e050e0617fe010728250000062a3e020304050e040e0516281b0000062a4e020317283b00000a04050e0417281b0000062a3e020304050e040e0518281b0000062a13300200a600000011000011160a160b160c160d0213041613053884000000110411056f1d00000a1306082c04160c2b6c11061f5c3304170c2b62092c0a11061f5d3359160d2b5511061f5b3304170d2b4b11061f283319061758250a1f403110728307007072bf07007028110000067a11061f2933040617590a11061f7c331c071758250b200004000031107283070070721108007028110000067a110517581305110511046f1700000a3f6effffff2aea0f00281500000a2d200f00281600000a1732160f01281500000a2d0d0f01281600000a0416fe012f10729d000070725f08007028110000067a2ab60f00280f00000a2d090f01280f00000a2c067e3400000a2a020304050e040e050e05733a00000628220000062a0013300500ea000000120000110f00280f00000a2d090f01280f00000a2c067e3400000a2a04051628200000060e060e046f3d0000060f00281100000a0a0e060672cf0100706f3c0000060e060f01281100000a6f3e0000060f02281600000a17590b07066f1700000a31067e3400000a2a160c2b6a0e0606076f410000060d096f1900000a2c61081758250c0f03281600000a3332732b00000a13040e06110406096f1a00000a096f1b00000a6f4200000611046f2a00000a0e066f3b00000626733900000a2a096f1a00000a096f1b00000a58096f1b00000a16fe01580b07066f1700000a318d0e066f3b000006267e3400000a2ae20f00280f00000a2d120f01280f00000a2d090f02280f00000a2c067e3400000a2a020304050e040e050e060e06733a00000628240000062a001330060050010000130000110f00280f00000a2d120f01280f00000a2d090f02280f00000a2c067e3400000a2a050e041728200000060e070e056f3d0000060f00281100000a0a0f02281100000a0b0e070672cf0100706f3c0000060e070772010700706f3c0000060e070f01281100000a6f3e0000060f03281600000a17590c08066f1700000a3102022a732b00000a0d161304161305388b0000000e0706086f41000006130611066f1900000a39800000001105175813050f04281600000a2c0b11050f04281600000a333f0e070906110411066f1a00000a1104596f420000060e07090716076f1700000a6f4200000611066f1a00000a11066f1b00000a5813040f04281600000a2d2711066f1a00000a11066f1b00000a5811066f1b00000a16fe01580c08066f1700000a3e69ffffff0e0709061104066f1700000a1104596f42000006096f2a00000a0e076f3b00000626733900000a2a1330070080010000140000110f00280f00000a2d090f01280f00000a2c07168d050000022a0e07252d08260e04733a00000610070f02281500000a2d2b0f02281600000a1732210f05281500000a2d180f05281600000a17320e0f05281600000a20a08601003110729d00007072a708007028110000067a0e07056f3d0000060f00281100000a0a0e070672cf0100706f3c0000060e070f01281100000a6f3e0000060f02281600000a17590b733c00000a0c166a0d07066f1700000a310a0e076f3b00000626082a16130438840000000e0706076f41000006130511056f1900000a2c7c0e062c310806110411056f1a00000a1104590f05281600000a12030e07282600000611056f1a00000a11056f1b00000a5813042b20080611056f1a00000a11056f1b00000a0f05281600000a12030e07282600000611056f1a00000a11056f1b00000a5811056f1b00000a16fe01580b07066f1700000a3e70ffffff0e062c1d08061104066f1700000a1104590f05281600000a12030e0728260000060e076f3b00000626082a1330050097000000150000110e066f3b00000626026f3d00000a0e0432107217090070724709007028110000067a0e050e054c056ad6550e054c0e067b0e0000046a3110729709007072cd09007028110000067a0304056f3e00000a0a0e066f3b0000062602734300000625026f3d00000a6a176a587d1400000425046a176a587d1500000425056a7d1600000425067d170000046f3f00000a0e066f3b000006262a42020304050e040e05161428250000062a52020317731800000a04050e04171428250000062a000000133002004d000000160000110274050000020a03067b14000004734000000a812300000104067b15000004734000000a812300000105067b16000004734000000a81230000010e04067b17000004733900000a81130000012a86021f5f2e1a021f413205021f5a3110021f613209021f7afe0216fe012a162a172a6a02282a0000062d10021f303209021f39fe0216fe012a162a172a0000133007002f00000017000011734100000a0a0f00280f00000a2d090f01280f00000a2c02062a020304050e040e050e04733a000006282d0000062a001b300900c201000018000011734100000a0a0f00280f00000a2d090f01280f00000a2c02062a0f02281500000a2d2b0f02281600000a1732210f05281500000a2d180f05281600000a17320e0f05281600000a20a08601003110729d000070724107007028110000067a0e06056f3d0000060f00281100000a0b0e060772cf0100706f3c0000060e060f01281100000a076f1700000a6f3f0000060c0f02281600000a17590d166a1304166a1305087b1f0000046f4200000a3afa0000000e066f3b00000626062a0e0607096f41000006130611066f1900000a39e50000001104176a581304087b1f0000046f4300000a130738890000001207284400000a130811066f4500000a11087b1a0000046f4600000a130911096f4700000a6f4800000a2d1a060e060f05281600000a120511041108166a14282e0000062b4316130a2b2e060e060f05281600000a120511041108110a17586a11096f4700000a110a6f4900000a282e000006110a1758130a110a11096f4700000a6f4800000a32c21207284a00000a3a6bffffffde0e1207fe160600001b6f4b00000adc11066f1a00000a11066f1b00000a5811066f1b00000a16fe01580d09076f1700000a3e04ffffff0e066f3b00000626062a0000011000000200e7009c83010e0000000013300500d200000019000011036f3b00000626026f4c00000a0432107217090070722d0a007028110000067a054c0e057b190000046f1700000a6a580e072c090e076f1b00000a2b01166a580a06037b0e0000046a3110729709007072670a007028110000067a050655027351000006250e047d28000004250e057d2a000004250e067d29000004250e0714fe037d2b000004250e072c0b0e076f1a00000a17582b01167d2c000004250e072c090e076f1b00000a2b01167d2d000004250e072c090e076f4d00000a2b01147d2e0000046f4e00000a036f3b000006262a000013300200ce0000001a00001102740a0000020a03067b28000004734000000a812300000104067b2a0000047b18000004731800000a811600000105067b29000004734000000a81230000010e04067b2a0000047b19000004733900000a81130000010e05067b2b000004731300000a81120000010e06067b2b0000042d077e4f00000a2b0c067b2c0000046a734000000a81230000010e07067b2b0000042d077e4f00000a2b0c067b2d0000046a734000000a81230000010e08067b2b0000042d077e3400000a2b0b067b2e000004733900000a81130000012a4272c10a007072fd0a007028110000062a00133003004d0000001b0000110e046f3b00000626026f5000000a2000000100321072840b007072bc0b007028110000067a021200fe150b0000021200037d2f0000041200047d300000041200057d31000004066f5100000a2a0000001b300500490200001c000011735200000a0a160b160c380b020000046f3b00000626021f24086f5300000a0d046f3b0000062609163ff8010000090c0807310c060708075914042831000006081758250c026f1700000a320628300000067a02086f1d00000a1f24331506081714042831000006081758250c0b38a701000014130402086f1d00000a1f313f9100000002086f1d00000a1f393d83000000161305046f3b0000062602086f1d00000a1f30591306110520ffffff7f1106591f0a5b310628300000067a11051f0a5a11065813050817580c08026f1700000a2f1602086f1d00000a1f30320b02086f1d00000a1f3931ab1105037b1f0000046f4200000a310628300000067a037b1f000004110517596f5400000a130438f800000002086f1d00000a1f7b40e4000000081758250c130708026f1700000a2f0e02086f1d00000a282a0000062d2228300000067a046f3b00000626081107592080000000320628300000067a0817580c08026f1700000a2f0e02086f1d00000a282b0000062dcd08026f1700000a2f0b02086f1d00000a1f7d2e0628300000067a021107081107596f3e00000a13080817580c037b1f0000046f4300000a13092b2f1209284400000a130a046f3b00000626110a7b1b0000042c16110a7b190000041108285500000a2c06110a1304de191209284a00000a2dc8de0e1209fe160600001b6f4b00000adc11042d0c28300000067a28300000067a0616161104042831000006080b08026f1700000a3fe9fdffff026f1700000a0731110607026f1700000a075914042831000006046f3b00000626062a000000011000000200b3013cef010e00000000e20f00280f00000a2d120f01280f00000a2d090f02280f00000a2c067e3400000a2a020304050e040e050e060e06733a00000628340000062a0000001b300600060200001d0000110f00280f00000a2d120f01280f00000a2d090f02280f00000a2c067e3400000a2a050e041728200000060e070e056f3d0000060f00281100000a0a0e070672cf0100706f3c0000060e070f02281100000a72010700706f3c0000060e070f01281100000a066f1700000a6f3f0000060b0f02281100000a070e0728320000060c0e076f3b000006260f03281600000a17590d09066f1700000a3102022a732b00000a130416130516130638210100000e0706096f41000006130711076f1900000a39160100001106175813060f04281600000a2c0e11060f04281600000a40d20000000e07110406110511076f1a00000a1105596f42000006086f5600000a13082b7c1208285700000a130911097b310000042d200e0711040f02281100000a11097b2f00000411097b300000046f420000062b4a11076f4500000a11097b310000047b1a0000046f4600000a130a0e07110406110a6f1900000a2d03162b07110a6f1a00000a110a6f1900000a2d03162b07110a6f1b00000a6f420000061208285800000a3a78ffffffde0e1208fe160800001b6f4b00000adc11076f1a00000a11076f1b00000a5813050f04281600000a2d2711076f1a00000a11076f1b00000a5811076f1b00000a16fe01580d09066f1700000a3ed3feffff0e071104061105066f1700000a1105596f4200000611046f2a00000a0e076f3b00000626733900000a2a000001100000020001018c8d010e0000000052230000000000406f40285900000a80040000042ac602285a00000a7d090000040220fa0000007d0b00000402285b00000a02030428050000067d0a000004022837000006262aa620f40100006a027b090000046f5c00000a5925166a3010720100007072200c007028110000067a692a00000013300400960000001e0000112b410217022837000006185b285d00000a7d0b00000402027b0a0000046f2a00000a027b0a0000046f5e00000a027b0b0000046c285900000a731c00000a7d0a000004027b0b00000402283700000630b1027b0a00000403046f5f00000a02283700000626256f1900000a2c2802027b0c00000417580a067d0c0000040620a0860100311072820c007072ae0c007028110000067a2a000013300300370000001e00001102283700000626046f1a00000a046f1b00000a58046f1b00000a16fe01580a06036f1700000a300902030628380000062a286000000a2a00133003009b0000000000000002285a00000a7d0d00000402285b00000a0f01280f00000a2d260f01281100000a72220d0070286100000a2c230f01281100000a72340d0070286100000a2c10729d00007072400d007028110000067a020f01281100000a72220d0070285500000a2d0720000080002b0520000010007d0e000004020f01281100000a72220d0070285500000a2d0720d00700002b0520f40100007d0f0000042aaa027b0f0000046a027b0d0000046f5c00000a5925166a30107201000070728e0d007028110000067a692a8a02283b00000626036f1700000a027b0e000004310c0472000e007028110000067a2ad60f01280f00000a2d0f0f01281100000a6f1700000a1a3110729103007072720e007028110000067a020328060000067d110000042a00133005009000000000000000036f1700000a20401f00003110726902007072dc0e007028110000067a03281f0000060203027b11000004185f16fe03027b11000004175f16fe0328080000067d10000004027b100000046f1700000a2000fa00003110726902007072540f007028110000067a0220fa00000002283b000006283600000a7d130000040202027b1300000428400000067d120000042a13300500990000001f000011036f1700000a20401f00003110726902007072dc0e007028110000067a03281f0000060473460000060a0203027b11000004185f16fe03027b11000004175f16fe030628090000067d10000004027b100000046f1700000a2000fa00003110726902007072540f007028110000067a0220fa00000002283b000006283600000a7d130000040202027b1300000428400000067d12000004062a0000001b3003003c0000002000001102283b00000626027b10000004027b11000004036c285900000a731c00000a02283b000006260ade11267209030070723d03007028110000067a062a011000000000070022290011190000011b30040061000000210000112b26021702283b000006185b285d00000a7d130000040202027b1300000428400000067d12000004027b1300000402283b00000630cc00027b1200000403046f5f00000a02283b000006260ade11267201000070729c0f007028110000067a062a0000000110000000003700174e001115000001fa02283b00000626036f2c00000a6a0e046ad6027b0e0000046a3110729709007072f20f007028110000067a0304050e046f6200000a2602283b000006262a1e02285b00000a2a1e02285b00000a2a3e02037d1c00000402047d1d0000042a9202736300000a7d1f00000402736400000a7d2000000402285b00000a02037d1e0000042a3e20a18601006a030458286500000a2a4e027b1e0000046a176a58030458286500000a2a1b3004009301000022000011140a044a1758036f1700000a3c0601000003044a17586f1d00000a1f3f40f5000000044a185813041104036f1700000a2f1103110425175813046f1d00000a1f3c2e0628100000067a110413051104036f1700000a2f0f0311046f1d00000a282a0000062d0628100000067a1104175813042b061104175813041104036f1700000a2f0f0311046f1d00000a282b0000062de11104036f1700000a2f180311046f1d00000a1f3e330c11041105592080000000310628100000067a03110511041105596f3e00000a0a027b200000046f6600000a13062b161206286700000a061b286800000a2c0628100000067a1206286900000a2de1de0e1206fe160a00001b6f4b00000adc027b20000004066f6a00000a04110454027b1f0000046f4200000a1f4033107283070070724c10007028110000067a027b1f0000046f4200000a17580b1201286b00000a286c00000a0c734400000625077d180000042506252d0226087d19000004250614fe037d1b0000042572a010007008286d00000a7d1a0000040d027b1f000004096f6e00000a092a00011000000200d60023f9000e000000009e027b210000042d0e037b1d00000420a08601006a311072a810007072e810007028110000067a2a3a02285b00000a02037d220000042a5602284d00000602037d2400000402177d260000042a000000133004006900000000000000027b260000042d012a027c23000004027b22000004027c230000047b1c000004027c240000047b1c0000046f480000067d1c000004027c23000004027b22000004027c230000047b1d000004027c240000047b1d0000046f470000067d1d00000402167d260000042a00000013300500a400000019000011027c240000047b1c000004166a3128027b220000047b1e0000046a027c240000047b1c0000045b0a0416323206046a286500000a0a2b2704163205046a0a2b1e027c240000047b1d000004166a310c027b22000004177d21000004166a0a02027b220000047b1e0000046a176a58027c240000047b1c000004036a5a286500000a20a18601006a027c240000047b1d000004065a286500000a73450000067d240000042a13300400710000000000000002284d000006027b270000042d1502027b230000047d2500000402177d270000042b4102027c250000047b1c000004027c230000047b1c000004286500000a027c250000047b1d000004027c230000047b1d000004286f00000a73450000067d25000004027c23000004fe15070000022a3602284f000006027b250000042a1e02285b00000a2a0042534a4201000100000000000c00000076342e302e33303331390000000005006c0000004c120000237e0000b8120000580d000023537472696e6773000000001020000064110000235553007431000010000000234755494400000084310000ac0c000023426c6f620000000000000002000001571d02080902000000fa01330016000001000000320000000b0000003100000051000000130100006f0000000900000016000000220000000a0000000100000003000000090000000000b00501000000000006005803a1080600c503a10806009a0239080f00c10800000600c2027c06060024037c060600ac037c06060078037c06060091037c060600ae02820806008c0282080600f2027c060600d50a2e0d060041032e0d0600d90243040600c40af20506002d06f2050a001106e3080a005d04e3080e00b90c5a090e0005075a090a001000e3080e008d045a090e00b7095a090600f306f2050600d906f2050600a307080c0e00010040000a00f409e3080a000f03e5070a009701e5070a009101e5070600df018b090600090040000a001900e3088b00160800000e0069075a090e005f025a090e009304390806003802f20506006904f20506007507f2050600af04f2050e00a0065a090e008e065a090600eb01f20506002007f20506005907670606001300f20506008507f20500000000220000000000010001008101100095079d0c41000100010003011000a405000041000900360003011000220c000041000d003a0003011000790c000041001400430003011000480600004100180044000b011000d50c0000a1001c004500030110001c06000041001e0046000301100014020000410022004b00030110005b0c00004100280051000b011000950b0000a1002f0052005180650a130351802f0913035180d10713033100c20b16035180520a130351803c0a13035180de0413035180790913032100f4041a030100bf0c1f030100dc0b13030100de0513032300ee041a032300110b13032300e50a13030300490723030300bc0926030100bf0c1f030100cf0b1303030037052a030300b0062a030300d0042a030300e703230303003705130303000f0223030300ff012303030067012d030300f9052a030300040d2a032300bf0413032300e30930032100dd0839030300ec0c2d032100280641030100750145030100bd0b45030100020445030100b50b2d030100f3032d03030018052a030300fa042a03030069074903030057012d030300c30613030300d00413030300e70323030300a90b13030300d0041303030069074903502000000000960086044d030100c4200000000096002e085803040024220000000096007e0b69030a00f822000000009100e40bb9000e001823000000009100b30c76030f009023000000009100aa097e0311008b240000000091002b04850312009c2400000000910040078a031200a824000000009100400791031500f8270000000091002b029a031900ac290000000091001b0aa5031e00002b000000009100fd09af032200082c000000009100b907bb032700242c000000009100b907c4032a00082d0000000091007a07d1032f00862d000000009100310785033100972d0000000091000608d8033100ac2d000000009100d801df0333004c2e000000009100140cea033700982e000000009600a000f9033b00f02e0000000096003d0104043e008c2f000000009600c500110442005c30000000009100b4002204480042310000000096008a003604500057310000000096007600470456006931000000009600110147045d007c3100000000910000015a0464005c32000000009600d7006d046b006c320000000096002b017f0471008032000000009600eb006d04760090320000000091003e0d8f047c004233000000009100810a94047d007d3300000000960070049d048000ac330000000091005c05ae048600a234000000009600a601c1048d00dc340000000091004705d404940038360000000091003a06e9049c00c437000000009100660cfe04a4006738000000009600d0081105ab007838000000009600000b2305b1009038000000009600750c3305b600e938000000009100a50bed00bb000b39000000009100890bed00bc00283900000000960018091105bd00643900000000910073054705c300443b000000009100490c5b05ca00243c000000009600570c7205d200fe3c0000000091001d0b8503db00103d000000009100920b9305db006c3d000000009100300ba405e000d43f000000009600d709c104e30010400000000091008905d404ea0034420000000091182708b305f20049420000000083182108b705f2007b4200000000810039044800f400a8420000000083007f048402f4004c43000000008300030cbe05f60090430000000083182108c605f800374400000000830039044800f90062440000000083000e04cc05f90085440000000083003f09c605fb00bc4400000000830018041000fc0058450000000083000509d205fd000046000000008100cb0ad905ff0058460000000083007f0484020001d8460000000083008a01df05020117470000000086182108060006011f4700000000861821080600060127470000000083182108e805060137470000000083182108010008015c470000000083006b00ee0509016c470000000083006000ee050b0180470000000083004202f4050d013049000000008300fc0cfc050f01584900000000831821080206100167490000000083007200fc0511018049000000008100a90406001201f849000000008300cc0c08061201a84a000000008300820206001401254b0000000083009d040e061401334b00000000861821080600140100000100f20b000002005107000003004d0900000100f20b00000200510700000300af0b00000400bb0100000500cc06000006004d0900000100f20b00000200510700000300af0b000004004d0900000100f20b000001005107000002004d09000001004d09000001005107000002002102000003006f02000001005107000002002102000003006f0200000400260900000100510700000200970c00000300f80b00000400130a000005006f0200000100510700000200970c00000300f80b000004006f0200000100f80b00000200660b00000300590b000004006d01000005006f0200000100510700000200970c00000300f80b00000100510700000200970c00000300f80b020004000106020005000906000001005107000002000c0800000100c60100000200d00100000100ed0300000200170b00000300c60110100400380c00000100f701000002004d0902000300810102000400c40900000100f20b000002005107000003004d0900000100f20b00000200510700000300af0b000004004d0900000100f20b00000200510700000300af0b00000400bb0100000500cc06000006004d0900000100f20b00000200510700000300410b00000400af0b00000500bb01000006004d0900000700f70100000800cb0100000100f20b00000200510700000300af0b00000400bb01000005004d0900000600f70100000100f20b00000200510700000300410b00000400af0b00000500bb01000006004d0900000700f70100000100f20b00000200510700000300410b00000400af0b00000500bb01000006004d0900000700f70100000100f20b00000200510700000300af0b000004004d0900000500f70100000600b00a00000700cb0100000100f20b00000200510700000300af0b000004004d0900000500f70100000600b00a00000100f20b000002005107000003004d0900000400f70100000500b00a00000100f20b00000200510700000300af0b000004004d0900000500f70100000600b00a00000100510700000100af0b00000200bb0100000300b30100000100f20b00000200510700000300af0b00000400bb01000005004d0900000600f70100000100f20b00000200510700000300af0b00000400bb01000005004d0900000600f70100000700380c00000100f20b00000200510700000300410b00000400af0b00000500bb01000006004d0900000700f70100000100f20b00000200510700000300410b00000400af0b00000500bb01000006004d0900000700f70100000800380c00000100f20b00000200510700000300af0b000004004d0900000500f70100000600b00a000007000b0b10100800380c00000100b80a00000200f20b00000300af0b00000400d70400000500b00a00000600770a00000700380c00000100f20b00000200510700000300af0b000004004d0900000500f70100000600b00a00000100f20b000002005107000003004d0900000400f70100000500b00a00000100850c020002003f0502000300be0602000400d70402000500ed0300000100590000000100590000000100f20b00000200510700000300af0b000004004d0900000500f70100000600b00a00000100f20b00000200510700000300af0b000004004d0900000500f70100000600b00a00000700380c00000100b80a00000200380c00000300b00a000004004f01000005002505000006005b0600000700090500000800670200000100850c020002002505020003003205020004000905020005000a02020006005f0102000700be0602000800d70402000900ed0300000100a10a00000200af0b00000300d704000004006f0700000500380c000001003b0c00000200280600000300380c00000100f20b00000200510700000300410b00000400af0b00000500bb01000006004d0900000700f70100000100f20b00000200510700000300410b00000400af0b00000500bb01000006004d0900000700f70100000800380c000001005107000002004d0900000100ed03000002000c0800000100ed0300000200a70a00000100f70100000100ed0300000200c50c000001004d0900000100510700000100510700000200cb0400000100750800000100f20b000002000c0800000100b107000002003b0c00000300af0b00000400d704000001000106000002000c0d00000100cb04000001003500000002003e00000001003500000002003e0000000100510700000200970c00000100e40c00000100280600000100e40c00000100000800000200df07090021080100110021080600190021080a00290021081000310021081000390021081000410021081000490021081000510021081500590021081000610021081000710021081a00790021081000f100210806009900d30528009100d9052c009900e3033000a1008b043400910021081500b100d9054400b100d3052800b100e30348004901b4044800b100210801002901300a280031018d0c48003101b4044800a10021085f004901ea097400d900210801000c00210806001400210806001400a404a200d9008a01a800d9008a01ae000c00a404a2001400740b480014006507b4000c006507b400510167043000a1003102b900810067043000d90021080600d900b4044800d900ea0974004901bd0ad600d9008a01dd005101f80aed00d9008a01f200d10021081000e900d30528009900d905ff00e900b4040301590136060701e9005b000d01490121081601990021081000e900ca053501b100ec0a47011c00210806001c00740b48004901750489011c007200a2001901210894012400210806002c00740b48002c001308d20134004d0bb400b900cc09e4016101e905ea012901f808f1016901740b48006901e905f7013400ff0b280071017a0206002400740b48003101e303300024007200a2001901d90507023c00740b48003c007200a2003c00210806004901230435022c00e9053b024901140d41023c001308d20144004d0bb4004400ff0b2800890064086f023901400c750281002108060039014c0803015901890c0701a1009e097f02a1008d048402b9004e0d8b024901200d4102d9008a019f022c00210806004c002108060059013606ae024c001308d20154004d0bb40049015309cb025400ff0b28004c007200a20081014a02d40289016704da024901bd0ae1022c007200a2005901890cae0208000400f00208000800f50208000c00fa0208001400f50208001800ff0208001c0004030800200009031200d9000e0312008d020e032e000b0013062e0013001c062e001b003b062e00230044062e002b006c062e003300ae062e003b00bc062e004300d5062e004b00f5062e005300fb062e005b0025072e00630032072e006b003807800273008207a00273008207c0027300820700037300820720037300820740037300820780037300ca08a0037300ca08c0037300910a200039004c00570068007900be00c300d000e300e800f8001c01210126013a014d01570161016d0185018f019901ab01fe0102020c02190247027b02900295029a02b40295009c007d01a301ca01dc0111026702a702c4020480000001000300000000000000000000009d0c0000040000000000000000000000e702370000000000040000000000000000000000e7022b0000000000040000000000000000000000e702f20500000000030002000400020005000200060002000700020008000200090002000a0002000b0002000000000000537461636b6031004c69737460310053716c496e7433320053716c496e743634003c4d6f64756c653e0053797374656d2e44617461006d73636f726c69620053797374656d2e436f6c6c656374696f6e732e47656e657269630052656164004d696e696d756d41646400486973746f72794164640052656765785265706c616365426f756e646564005265676578537562737472696e67426f756e64656400526567657849734d61746368426f756e646564005472616e73666f726d426f756e646564005265676578496e737472426f756e6465640052656765784d617463686573426f756e6465640052656765784361707475726573426f756e6465640052656c6174696f6e73426f756e6465640052656765785265706c61636547726f757073426f756e64656400526567657853706c6974426f756e646564005265676578436f756e74426f756e6465640063686172676564004d617463686564006d617463686564004e616d6564006e65676174656400616363756d756c617465640073656c656374656400417070656e640053797374656d446174614163636573734b696e640052656765785265706c616365007265706c616365006f6363757272656e636500636f6465006d6f6465006d65737361676500496e74616b650049456e756d657261626c650049446973706f7361626c650070726f66696c6500456e67696e654e616d650067726f75704e616d6500436170747572654672616d65006d756c74696c696e6500417070656e644573636170650056616c756554797065004465636c617265006765745f496e76617269616e7443756c74757265004361707475726500636170747572650069676e6f72654361736500446973706f736500416c7465726e61746500477569644174747269627574650044656275676761626c6541747472696275746500436f6d56697369626c6541747472696275746500417373656d626c795469746c65417474726962757465005461726765744672616d65776f726b41747472696275746500417373656d626c7946696c6556657273696f6e4174747269627574650053716c46756e6374696f6e41747472696275746500417373656d626c794465736372697074696f6e41747472696275746500536563757269747952756c657341747472696275746500436f6d70696c6174696f6e52656c61786174696f6e7341747472696275746500417373656d626c7950726f6475637441747472696275746500417373656d626c79436f7079726967687441747472696275746500417373656d626c79436f6d70616e794174747269627574650052756e74696d65436f6d7061746962696c697479417474726962757465006765745f56616c75650076616c756500686173416c7465726e617469766500616c7465726e617469766500436865636b53697a6500496e697469616c697a6500496e6465784f66004475706c6963617465466c61670052656d61696e696e670053797374656d2e52756e74696d652e56657273696f6e696e670053716c537472696e6700546f537472696e67005265676578537562737472696e670053656172636800526567657849734d617463680053746f7077617463680046696e697368005075736800466c757368004d617468006765745f4c656e67746800496e7075744c656e67746800696e7075744c656e677468006c656e6774680052324d617847726f7570446570746800436c6f636b00636c6f636b00436170747572654f7264696e616c00636170747572654f7264696e616c004d617463684f7264696e616c006d617463684f7264696e616c0067726f75704f7264696e616c006f7264696e616c0052656765785265706c616365496e7465726e616c005265676578537562737472696e67496e7465726e616c0052656765784361707475726573496e7465726e616c0052656765785265706c61636547726f757073496e7465726e616c00523154726176657273616c00546f6f6c62656c742e537472696e672e52656765782e646c6c006765745f4e756c6c006765745f49734e756c6c007375636365737366756c006765745f4974656d0053797374656d004d696e696d756d006d696e696d756d006d6178696d756d0053716c426f6f6c65616e0043617074757265506c616e00706c616e0054696d655370616e004d696e004275696c6452656c6174696f6e00436170747572654465636c61726174696f6e006465636c61726174696f6e0053797374656d2e476c6f62616c697a6174696f6e0053797374656d2e5265666c656374696f6e0043617074757265436f6c6c656374696f6e0047726f7570436f6c6c656374696f6e005374617274506f736974696f6e007374617274506f736974696f6e0072657475726e4f7074696f6e00496e76616c69644f7065726174696f6e457863657074696f6e00417267756d656e74457863657074696f6e0052656765784d6174636854696d656f7574457863657074696f6e00537472696e67436f6d70617269736f6e00496e76616c69645061747465726e005472616e736c6174655061747465726e007061747465726e0043756c74757265496e666f00506f700047726f75700067726f7570004368617200526561644e756d6265720049466f726d617450726f766964657200526567657850726f766964657200537472696e674275696c646572006275696c64657200417070656e64426f756e6465645175616e746966696572004d61785175616e746966696572007570706572004d6963726f736f66742e53716c5365727665722e536572766572006c6f776572004572726f7200637572736f7200476574456e756d657261746f72002e63746f72002e6363746f72005265676578496e7374720053797374656d2e446961676e6f7374696373006765745f456c61707365644d696c6c697365636f6e64730046726f6d4d696c6c697365636f6e6473006d696c6c697365636f6e64730053797374656d2e52756e74696d652e496e7465726f7053657276696365730053797374656d2e52756e74696d652e436f6d70696c6572536572766963657300446562756767696e674d6f6465730052656765784d617463686573006e616d65730053797374656d2e446174612e53716c5479706573006765745f436170747572657300496e697469616c697a6543617074757265730052656765784361707475726573006361707475726573004d61785061747465726e42797465730056616c6964617465466c61677300666c61677300457175616c730053797374656d2e546578742e526567756c617245787072657373696f6e730052324d6178416c7465726e6174696f6e730053797374656d2e436f6c6c656374696f6e73006765745f4f7074696f6e730050617273654f7074696f6e730052656765784f7074696f6e73006f7074696f6e73006765745f47726f7570730052656765785265706c61636547726f757073006765745f43686172730053716c436861727300417070656e645472616e736c61746564436c61737300696e436c61737300417070656e64436861726163746572436c617373006765745f537563636573730052325472616e736c61746564436f6465556e6974730052325061747465726e436f6465556e697473004d6178496e707574436f6465556e6974730074657874556e6974730056616c69646174655472616e73666f726d6174696f6e417267756d656e74730070617274730070726576696f7573006d6178526f777300726f777300436f6e636174004f626a65637400436f6e73747275637400536563757269747952756c6553657400427564676574006f705f496d706c69636974004973446967697400526567657853706c69740073706c6974004c696d6974006c696d697400496e76616c69645265706c6163656d656e740050617273655265706c6163656d656e74007265706c6163656d656e74006765745f43757272656e74006173636969436f6e74656e74006e6f726d616c436f6e74656e74006765745f436f756e74005265676578436f756e74004e616d6550617274004164645265706c6163656d656e7450617274004e616d655374617274007374617274006861734c617374006c617374004d6174636854696d656f757400726567657854696d656f75740074696d656f75740056616c6964617465496e70757400696e707574006f7574707574004d6f76654e6578740053797374656d2e5465787400496e74616b65436f6e74657874005472616e73666f726d6174696f6e436f6e7465787400636f6e746578740053746172744e65770041646443617074757265526f770046696c6c43617074757265526f770041646452656c6174696f6e526f770046696c6c52656c6174696f6e526f7700726f77004d6178006765745f496e64657800696e64657800546f6f6c62656c742e537472696e672e526567657800437265617465526567657800726567657800707265666978005175616e74696679004361707475726553756d6d6172790073756d6d617279004e756c6c61626c65486973746f72790056616c6964617465486973746f727900686973746f7279006f705f457175616c697479006f705f496e657175616c6974790053797374656d2e536563757269747900436865636b436f6d706c6578697479006765745f456d7074790000235400420058005f00520045004700450058005f00540049004d0045004f0055005400007744006900650020006600650073007400650020004100750073006600fc006800720075006e00670073006700720065006e007a006500200076006f006e00200032003500300020006d0073002000770075007200640065002000fc00620065007200730063006800720069007400740065006e002e0001355400420058005f00520045004700450058005f0049004e00560041004c00490044005f0041005200470055004d0045004e005400003b5300740061007200740020006d0075007300730020006d0069006e00640065007300740065006e0073002000310020007300650069006e002e0000454f006300630075007200720065006e006300650020006d0075007300730020006d0069006e00640065007300740065006e0073002000310020007300650069006e002e000079520065007400750072006e004f007000740069006f006e0020006d007500730073002000300020006600fc00720020005300740061007200740020006f006400650072002000310020006600fc007200200045006e00640065002d00650078006b006c00750073006900760020007300650069006e002e0001335400420058005f00520045004700450058005f0049004e005000550054005f0054004f004f005f004c004100520047004500006549006e007000750074002000640061007200660020006800f600630068007300740065006e0073002000320020004d006900420020005500540046002d00310036002d0044006100740065006e00200065006e007400680061006c00740065006e002e0001375400420058005f00520045004700450058005f005000410054005400450052004e005f0054004f004f005f004c00410052004700450000675000610074007400650072006e002000640061007200660020006800f600630068007300740065006e0073002000380030003000300020005500540046002d00310036002d0042007900740065007300200065006e007400680061006c00740065006e002e0001335400420058005f00520045004700450058005f0049004e00560041004c00490044005f005000410054005400450052004e0000535000610074007400650072006e002000690073007400200069006d00200054006f006f006c00620065006c0074002d004400690061006c0065006b007400200075006e006700fc006c007400690067002e00012f5400420058005f00520045004700450058005f0049004e00560041004c00490044005f0046004c00410047005300003b46006c0061006700730020006400fc007200660065006e0020006e00690063006800740020004e0055004c004c0020007300650069006e002e000155450072006c0061007500620074002000730069006e00640020006100750073007300630068006c0069006500df006c00690063006800200063002c00200069002c0020006d00200075006e006400200073002e00013f6300200075006e0064002000690020007300630068006c0069006500df0065006e002000650069006e0061006e0064006500720020006100750073002e00014b46006c0061006700730020006400fc007200660065006e0020006e006900630068007400200064006f007000700065006c007400200076006f0072006b006f006d006d0065006e002e00010728003f003a00000728003f003c0000055c007a0000032400000b5b0030002d0039005d00010730002d003900011f5b005c007800300039002d005c007800300044005c007800320030005d00011b5c007800300039002d005c007800300044005c00780032003000011541002d005a0061002d007a0030002d0039005f0001195b0041002d005a0061002d007a0030002d0039005f005d00012528003f002d0069003a005b0041002d005a0061002d007a0030002d0039005f005d002900010b5c0070007b004c007d0000035b0000035d00000b28003f002d0069003a0001032900000d28003f00210028003f003a000011290029005b005c0073005c0053005d0000053a0020000063440069006500200076006f007200680061006e00640065006e00650020005500540046002d00310036002d004700720065006e007a0065002000770075007200640065002000fc00620065007200730063006800720069007400740065006e002e00014f4400650072002000620065006700720065006e007a0074006500200049006e00740061006b0065002000690073007400200075006e0076006f006c006c0073007400e4006e006400690067002e000163530074006100720074002c0020004f006300630075007200720065006e006300650020006f006400650072002000520065007400750072006e004f007000740069006f006e002000690073007400200075006e006700fc006c007400690067002e00013f5400420058005f00520045004700450058005f005200450050004c004100430045004d0045004e0054005f0054004f004f005f004c00410052004700450000415300740061007200740020006f0064006500720020004d006100780052006f00770073002000690073007400200075006e006700fc006c007400690067002e00013b5400420058005f00520045004700450058005f005000410054005400450052004e005f0054004f004f005f0043004f004d0050004c004500580000514700720075007000700065006e00760065007200730063006800610063006800740065006c0075006e0067002000fc006200650072007300630068007200650069007400650074002000360034002e00014d41006c007400650072006e006100740069006f006e00730061006e007a00610068006c002000fc00620065007200730063006800720065006900740065007400200031003000320034002e0001475300740061007200740020006f0064006500720020004f006300630075007200720065006e00630065002000690073007400200075006e006700fc006c007400690067002e00016f53007400610072007400200075006e00640020004d006100780052006f007700730020006d00fc007300730065006e0020006700fc006c007400690067006500200070006f0073006900740069007600650020004700720065006e007a0065006e0020007300650069006e002e00012f5400420058005f00520045004700450058005f0054004f004f005f004d0041004e0059005f0052004f0057005300004f44006900650020004d006100780052006f00770073002d004700720065006e007a0065002000770075007200640065002000fc00620065007200730063006800720069007400740065006e002e0001355400420058005f00520045004700450058005f004f00550054005000550054005f0054004f004f005f004c004100520047004500005f4400690065002000450072006700650062006e00690073007400650078007400730075006d006d0065002000fc0062006500720073006300680072006500690074006500740020006400610073002000500072006f00660069006c002e0001394d006100780052006f00770073002000770075007200640065002000fc00620065007200730063006800720069007400740065006e002e0001594300610070007400750072006500740065007800740065002000fc00620065007200730063006800720065006900740065006e0020006400690065002000500072006f00660069006c006700720065006e007a0065002e00013b5400420058005f00520045004700450058005f0049004e00560041004c00490044005f005200450050004c004100430045004d0045004e0054000080855200650070006c006100630065006d0065006e0074002000690073007400200075006e006700fc006c0074006900670020006f0064006500720020007600650072007700650069007300740020006100750066002000650069006e006500200075006e00620065006b0061006e006e007400650020004700720075007000700065002e0001375400420058005f00520045004700450058005f005200450050004c004100430045004d0045004e0054005f004c0049004d004900540000635200650070006c006100630065006d0065006e0074002000640061007200660020006800f600630068007300740065006e00730020003600350035003300360020005400650069006c006500200065006e007400680061006c00740065006e002e000161440061007300200047006500730061006d007400620075006400670065007400200076006f006e00200035003000300020006d0073002000770075007200640065002000fc00620065007200730063006800720069007400740065006e002e00012b5400420058005f00520045004700450058005f004d0041005400430048005f004c0049004d004900540000734800f600630068007300740065006e007300200031003000300030003000300020006500720066006f006c00670072006500690063006800650020004d006100740063006800730063006800720069007400740065002000730069006e0064002000650072006c0061007500620074002e0001117300740061006e006400610072006400000b6c006100720067006500004d500072006f00660069006c00650020006d0075007300730020007300740061006e00640061007200640020006f0064006500720020006c00610072006700650020007300650069006e002e000071440061007300200047006500730061006d007400620075006400670065007400200064006500720020005400720061006e00730066006f0072006d006100740069006f006e002000770075007200640065002000fc00620065007200730063006800720069007400740065006e002e00017144006900650020005500540046002d00310036002d0047007200f600df0065006e006700720065006e007a00650020006400650073002000500072006f00660069006c0073002000770075007200640065002000fc00620065007200730063006800720069007400740065006e002e00016946006c0061006700730020006d00fc007300730065006e0020006800f600630068007300740065006e00730020007600690065007200200043006f0064006500650069006e00680065006900740065006e00200065006e007400680061006c00740065006e002e0001775000610074007400650072006e002000640061007200660020006800f600630068007300740065006e0073002000380030003000300020005500540046002d00310036002d0043006f0064006500650069006e00680065006900740065006e00200065006e007400680061006c00740065006e002e0001474400610073002000fc006200650072007300650074007a007400650020005000610074007400650072006e00200069007300740020007a0075002000670072006f00df002e0001554400690065002000530075006300680073006300680072006900740074006700720065006e007a0065002000770075007200640065002000fc00620065007200730063006800720069007400740065006e002e0001594400610073002000450072006700650062006e00690073002000fc0062006500720073006300680072006500690074006500740020006400690065002000500072006f00660069006c006700720065006e007a0065002e0001534800f600630068007300740065006e007300200036003400200043006100700074007500720065006700720075007000700065006e002000730069006e0064002000650072006c0061007500620074002e000107740062007800003f5400420058005f00520045004700450058005f0043004100500054005500520045005f0048004900530054004f00520059005f004c0049004d0049005400007944006900650020006b006f006e00730065007200760061007400690076006500200043006100700074007500720065002d0048006900730074006f00720079002d004700720065006e007a0065002000770075007200640065002000fc00620065007200730063006800720069007400740065006e002e0001000032a68764fc5cc8468650349b8d77e7f000042001010803200001052001011111042001010e04200101020520010111350707030e1251114903200002030611490320000e042001020e0a07050e120c125d08115903061159032000080a07050e120c08125d115907070311610e1251082003010e116111450b07080202020211610e080304200103081b070c126d151271011224122415127101020202080308081218111c06151271011224051512710102052001011300052001126d0e052001126d0304200013000400010e0e04070203080c070808020202126d126d03030507030e0e0e0600030e0e0e0e052001126d1c040702080804070208020400010203052001126d080607031d03080a0306114d0320000a0500020808080820040a0a1d030808052001011d030407011210040701114d0e0706114d1210114d114d114d114d04000012750c0705114d1210114d114d114d050001115908090707080802020e08030907050e0808125d126d0b07070e0e08126d0808125d0f07060e08151280890112140a08125d07151280890112140307010e0520020e08080407011214042001010a0907011512808901122807151280890112281e070b151280890112280e1220080a0a125d1511809101121812181280950807151280890112180920001511809101130007151180910112180520001280b10620011280950e0520001280b5062001128099080307010a0407011228040611808d040701112c071512808901112c1b070b1512808901112c08080812180808080e151180910112181218052002080308052001130008050002020e0e1f070b0e12201512808901112c08126d0808125d1511809101112c112c128095071511809101112c05000111450d05000012809d030701080420001161062002125d0e08040000125d04070112200407011251040701125d072003126d0e08080615128089010e0500020a0a0a0f07070e080e1218080815118091010e0615118091010e080003020e0e1180bd0500001280c10620010e1280c90500020e0e0e08b77a5c561934e089040000100004401f000004e80300000400fa000004400000000400040000040000000002060803061145040612809d0306125102060e0306116102060a020602080615128089011218070615128089010e030612200306111c030612180a00031149114d114d114d1000061159114d114d115911591159114d0c00041159114d114d1159114d07000212510e114d0600011161114d04000012690600030e0e02020800040e0e020212200a0005010e1008126d0202090004010e1008126d020b000501126d126d126d0202080003010e1008126d0c0005010e1008126d10081008060002080e100806000212690e0e0a0004114d1275080e12100e000412101275127510114d10114d0a000311491275127512750c0004115912751275115912751000061159127512751159115911591275130008114d127512751275115911591275127508100006114d127512751159115912751275120007114d1275127512751159115912751275120007128085127512751159127512751159081100061280851275127511591275127511590f000512808512751275127512751159040001010e080003011159115902100006114d114d114d11591159114d114d120007114d114d114d11591159114d114d1210120007114d114d114d114d11591159114d114d140008114d114d114d114d11591159114d114d1210140008128085114d114d1159114d114d115902121012000701151280890112140e080808100a1210110006128085114d114d1159114d114d11590f0005128085114d114d114d114d1159130005011c1011808d1011808d1011808d10114d130007128085114d114d1159114d114d115912101600080115128089011228121008100a0a12180a128099200009011c1011808d1011591011808d10114d1011491011808d1011808d10114d100005011512808901112c0808121812100e00031512808901112c0e1220121003000001062002010e114d072002125d0e125d05200101114d052002010e0e06200212200e0805200112510808200401126d0e0808052002010a0a0520020a0a0a07200212180e100805200101111c052001011220052002010808042000111c0801000800000000001e01000100540216577261704e6f6e457863657074696f6e5468726f7773010801000200000000002701002253514c2053657276657220546f6f6c62656c742052656765782050726f766964657200004101003c534146452053514c20434c522070726f766964657220666f722074686520626f756e64656420546f6f6c62656c74207265676578206469616c65637400000d0100086765636f6d70617400001801001353514c2053657276657220546f6f6c62656c7400001f01001a436f7079726967687420c2a9204765726861726420506973636800000501000000002901002439334346364439442d453243382d343532302d423441452d31364446383341304538423000000c010007312e332e302e3000000501000200004901001a2e4e45544672616d65776f726b2c56657273696f6e3d76342e380100540e144672616d65776f726b446973706c61794e616d65122e4e4554204672616d65776f726b20342e388146010004005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e6973746963005402094973507265636973650181c5010006005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d4461746141636365737300000000540e1146696c6c526f774d6574686f644e616d650f46696c6c52656c6174696f6e526f77540e0f5461626c65446566696e6974696f6e484f7264696e616c20626967696e742c205374617274506f736974696f6e20626967696e742c204c656e67746820626967696e742c2056616c7565206e76617263686172286d61782954020f497344657465726d696e697374696300540209497350726563697365018219010006005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d4461746141636365737300000000540e1146696c6c526f774d6574686f644e616d650e46696c6c43617074757265526f77540e0f5461626c65446566696e6974696f6e809c4d617463684f7264696e616c20626967696e742c2047726f75704f7264696e616c20696e742c20436170747572654f7264696e616c20626967696e742c2047726f75704e616d65206e7661726368617228313238292c204d617463686564206269742c205374617274506f736974696f6e20626967696e742c204c656e67746820626967696e742c2056616c7565206e76617263686172286d61782954020f497344657465726d696e6973746963005402094973507265636973650100000000000000000000000010000000000000000000000000000000b08900000000000000000000ca890000002000000000000000000000000000000000000000000000bc890000000000000000000000005f436f72446c6c4d61696e006d73636f7265652e646c6c0000000000ff2500200010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100100000001800008000000000000000000000000000000100010000003000008000000000000000000000000000000100000000004800000058a00000000400000000000000000000000434000000560053005f00560045005200530049004f004e005f0049004e0046004f0000000000bd04effe00000100030001000000000003000100000000003f000000000000000400000002000000000000000000000000000000440000000100560061007200460069006c00650049006e0066006f00000000002400040000005400720061006e0073006c006100740069006f006e00000000000000b00460030000010053007400720069006e006700460069006c00650049006e0066006f0000003c030000010030003000300030003000340062003000000092003d00010043006f006d006d0065006e0074007300000053004100460045002000530051004c00200043004c0052002000700072006f0076006900640065007200200066006f0072002000740068006500200062006f0075006e00640065006400200054006f006f006c00620065006c00740020007200650067006500780020006400690061006c006500630074000000000032000900010043006f006d00700061006e0079004e0061006d006500000000006700650063006f006d00700061007400000000006e0023000100460069006c0065004400650073006300720069007000740069006f006e0000000000530051004c002000530065007200760065007200200054006f006f006c00620065006c0074002000520065006700650078002000500072006f007600690064006500720000000000300008000100460069006c006500560065007200730069006f006e000000000031002e0033002e0030002e003000000054001a00010049006e007400650072006e0061006c004e0061006d006500000054006f006f006c00620065006c0074002e0053007400720069006e0067002e00520065006700650078002e0064006c006c00000058001a0001004c006500670061006c0043006f007000790072006900670068007400000043006f0070007900720069006700680074002000a9002000470065007200680061007200640020005000690073006300680000005c001a0001004f0072006900670069006e0061006c00460069006c0065006e0061006d006500000054006f006f006c00620065006c0074002e0053007400720069006e0067002e00520065006700650078002e0064006c006c000000480014000100500072006f0064007500630074004e0061006d00650000000000530051004c002000530065007200760065007200200054006f006f006c00620065006c0074000000340008000100500072006f006400750063007400560065007200730069006f006e00000031002e0033002e0030002e003000000038000800010041007300730065006d0062006c0079002000560065007200730069006f006e00000031002e0033002e0030002e003000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000c000000dc3900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000, @AssemblyHash varbinary(64);
IF TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion')) NOT IN (15, 16, 17)
    THROW 52030, N'Dieses Modul unterstützt SQL Server 2019, 2022 und 2025.', 1;
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 52031, N'DeploymentMode muss local oder central sein.', 1;
IF @AssemblyBits IS NULL OR DATALENGTH(@AssemblyBits) < 1024
    THROW 52043, N'AssemblyBits enthält kein plausibles Release-Binary.', 1;
SET @AssemblyHash = HASHBYTES(N'SHA2_512', @AssemblyBits);
-- Explizite Offline-Erwartung; niemals aus dem aktuellen Katalog ableiten.
DECLARE @ExpectedInstalledAssemblyHashText nvarchar(max) = N'0xc353c0242a2854baca8996c6e2429b9efa755ee696b8e9497b288c5cdd8252f752b2504c4d84d5a35f419186247636afb3b9d6f73d2e4f93315793037341dcb8',
        @ExpectedInstalledAssemblyHash varbinary(64), @ExpectedAbsence bit = 0;
IF CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText) = CONVERT(varbinary(max), N'0x')
    SET @ExpectedAbsence = 1;
ELSE
BEGIN
    IF @ExpectedInstalledAssemblyHashText IS NULL
       OR DATALENGTH(@ExpectedInstalledAssemblyHashText) <> 260
       OR CONVERT(varbinary(max), LEFT(@ExpectedInstalledAssemblyHashText, 2)) <> CONVERT(varbinary(max), N'0x')
       OR SUBSTRING(@ExpectedInstalledAssemblyHashText, 3, 128) COLLATE Latin1_General_100_BIN2 LIKE N'%[^0-9A-Fa-f]%'
       OR TRY_CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText, 1) IS NULL
       OR DATALENGTH(TRY_CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText, 1)) <> 64
        THROW 52046, N'ExpectedInstalledAssemblyHash muss 0x oder exakt 128 Hexzeichen nach 0x enthalten.', 1;
    SET @ExpectedInstalledAssemblyHash = TRY_CONVERT(varbinary(64), @ExpectedInstalledAssemblyHashText, 1);
END;
BEGIN TRY
    WHILE @Pass <= 2
    BEGIN
        -- Beide Durchläufe lesen den aktuellen Katalog; der zweite läuft unter AppLock.
        SET @InstalledVersion = NULL;
        SET @InstalledMode = NULL;
        SET @AssemblyId = NULL;
        SET @InstalledAssemblyHash = NULL;
        SELECT @InstalledVersion = TRY_CONVERT(nvarchar(max), value)
        FROM sys.extended_properties
        WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @VersionProperty;
        SELECT @InstalledMode = TRY_CONVERT(nvarchar(max), value)
        FROM sys.extended_properties
        WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @ModeProperty;
        SET @Release = CASE CONVERT(varbinary(max), @InstalledVersion)
            WHEN CONVERT(varbinary(max), N'1.0.0') THEN 10
            WHEN CONVERT(varbinary(max), N'1.1.0') THEN 11
            WHEN CONVERT(varbinary(max), N'1.2.0') THEN 12
            WHEN CONVERT(varbinary(max), N'1.3.0') THEN 13 ELSE 0 END;
        IF @Release = 0 AND EXISTS (SELECT 1 FROM sys.extended_properties
            WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @VersionProperty)
            THROW 52032, N'Die installierte Modulversion ist nicht bekannt.', 1;
        SELECT @AssemblyId = a.assembly_id,
               @InstalledAssemblyHash = HASHBYTES(N'SHA2_512', f.content)
        FROM sys.assemblies a LEFT JOIN sys.assembly_files f
          ON f.assembly_id = a.assembly_id AND f.file_id = 1
        WHERE a.name = N'Toolbelt_String_Regex';
        UPDATE s SET ObjectId = o.object_id FROM @Slots s
        LEFT JOIN sys.objects o ON o.schema_id = SCHEMA_ID(N'toolbelt_string') AND o.name COLLATE DATABASE_DEFAULT = s.Name COLLATE DATABASE_DEFAULT;

        IF @Release = 0 AND (@AssemblyId IS NOT NULL OR @InstalledMode IS NOT NULL
            OR EXISTS (SELECT 1 FROM @Slots WHERE ObjectId IS NOT NULL))
            THROW 52033, N'Zielobjekte ohne bekannten Versionsmarker sind fremd belegt.', 7;
        IF @Release > 0 AND (@InstalledMode IS NULL OR
            CONVERT(varbinary(max), @InstalledMode) NOT IN
            (CONVERT(varbinary(max), N'local'), CONVERT(varbinary(max), N'central')))
            THROW 52033, N'Der installierte DeploymentMode ist nicht kohärent.', 1;
        IF SCHEMA_ID(N'toolbelt_string') IS NOT NULL AND
          (NOT EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 3
            AND major_id = SCHEMA_ID(N'toolbelt_string') AND minor_id = 0
            AND name = N'Toolbelt.Managed' AND TRY_CONVERT(int, value) = 1)
           OR NOT EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 3
            AND major_id = SCHEMA_ID(N'toolbelt_string') AND minor_id = 0
            AND name = N'Toolbelt.SchemaCategory'
            AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), value)) = CONVERT(varbinary(max), N'string')))
            THROW 52033, N'Das vorhandene Schema hat keine eigene Toolbelt-Zuordnung.', 2;
        IF @Release > 0 AND EXISTS
          (SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id = s.ObjectId
           WHERE s.SinceRelease <= @Release AND
           (o.object_id IS NULL OR o.type COLLATE DATABASE_DEFAULT <> s.Kind COLLATE DATABASE_DEFAULT
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.Managed'
              AND TRY_CONVERT(int, e.value) = 1)
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleId'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), N'toolbelt.string.regex'))
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleVersion'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), @InstalledVersion))))
            THROW 52033, N'Das installierte Release-Objektmanifest ist nicht kohärent.', 3;
        -- Historische Releasebytes werden explizit gebunden, nicht aus clr_name erschlossen.
        IF @Release = 0 AND @ExpectedAbsence = 0
           OR @Release > 0 AND @ExpectedAbsence = 1
            THROW 52046, N'Die erwartete Assembly-Anwesenheit passt nicht zum geprüften Modulzustand.', 2;
        IF @Release > 0 AND (@InstalledAssemblyHash IS NULL
            OR @InstalledAssemblyHash <> @ExpectedInstalledAssemblyHash)
            THROW 52047, N'Der installierte Assemblyhash entspricht nicht der expliziten Offline-Erwartung.', 1;
        IF @Release > 0 AND (@AssemblyId IS NULL OR @InstalledAssemblyHash IS NULL
          OR NOT EXISTS (SELECT 1 FROM sys.assemblies a WHERE a.assembly_id = @AssemblyId
              AND a.permission_set_desc = N'SAFE_ACCESS' AND a.is_user_defined = 1)
          OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.Managed' AND TRY_CONVERT(int, e.value) = 1)
          OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleId'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), N'toolbelt.string.regex'))
          OR (@Release = 13 AND NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleVersion'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), @InstalledVersion))))
            THROW 52033, N'Die installierte Assembly-Zuordnung ist nicht kohärent.', 4;
        IF EXISTS (SELECT 1 FROM sys.sql_expression_dependencies d
              JOIN @Slots s ON s.ObjectId = d.referenced_id AND s.SinceRelease <= @Release
              WHERE NOT EXISTS (SELECT 1 FROM @Slots own WHERE own.ObjectId = d.referencing_id AND own.SinceRelease <= @Release))
            THROW 52038, N'Eine fremde same-database Dependency blockiert den Lifecycle.', 1;
        IF EXISTS (SELECT 1 FROM sys.assembly_modules m WHERE m.assembly_id = @AssemblyId
              AND NOT EXISTS (SELECT 1 FROM @Slots s WHERE s.ObjectId = m.object_id AND s.SinceRelease <= @Release AND s.Kind IN ('FS', 'FT')))
           OR EXISTS (SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id = @AssemblyId)
            THROW 52038, N'Ein fremder Assembly-Verbraucher blockiert den Lifecycle.', 2;
        IF EXISTS (SELECT 1 FROM @Slots s JOIN sys.assembly_modules m ON m.object_id = s.ObjectId
              WHERE s.SinceRelease <= @Release AND s.Kind IN ('FS', 'FT') AND m.assembly_id <> @AssemblyId)
            THROW 52033, N'Ein CLR-Kern verweist auf eine andere Assembly.', 5;
        IF NOT EXISTS (SELECT 1 FROM sys.configurations WHERE name = N'clr enabled' AND value_in_use = 1)
            THROW 52040, N'CLR ist nicht aktiviert; der Lifecycle ändert keine Instanzoption.', 1;
        IF NOT EXISTS (SELECT 1 FROM sys.configurations WHERE name = N'clr strict security' AND value_in_use = 1)
            THROW 52042, N'clr strict security muss aktiviert bleiben.', 1;
        IF @AssemblyHash IS NULL OR NOT EXISTS (SELECT 1 FROM sys.trusted_assemblies WHERE hash = @AssemblyHash)
            THROW 52045, N'Der exakte Release-Hash ist nicht freigegeben.', 1;
        -- Neue Slots gehören keinem Vorgängerrelease, auch mit imitierten Markern.
        IF EXISTS (SELECT 1 FROM @Slots WHERE SinceRelease > @Release AND ObjectId IS NOT NULL)
            OR (@Release = 0 AND (@AssemblyId IS NOT NULL OR @InstalledMode IS NOT NULL))
            THROW 52033, N'Ein Zielslot oder die Assembly ist fremd belegt.', 6;
        IF SCHEMA_ID(N'toolbelt_string') IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA'), 0) <> 1
            THROW 52034, N'CREATE SCHEMA fehlt.', 1;
        IF SCHEMA_ID(N'toolbelt_string') IS NOT NULL AND ISNULL(HAS_PERMS_BY_NAME(N'toolbelt_string', N'SCHEMA', N'ALTER'), 0) <> 1
            THROW 52034, N'ALTER auf toolbelt_string fehlt.', 2;
        IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION'), 0) <> 1
            THROW 52034, N'CREATE FUNCTION fehlt.', 3;
        IF @AssemblyId IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE ASSEMBLY'), 0) <> 1
            THROW 52034, N'CREATE ASSEMBLY fehlt.', 4;
        IF @AssemblyId IS NOT NULL AND @InstalledAssemblyHash <> @AssemblyHash
           AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'ALTER ANY ASSEMBLY'), 0) <> 1
            THROW 52034, N'ALTER ANY ASSEMBLY fehlt.', 5;
        IF @Pass = 1
        BEGIN
            BEGIN TRANSACTION;
            SET @OwnTransaction = 1;
            DECLARE @LockResult int;
            EXEC @LockResult = sys.sp_getapplock
                  @Resource = N'toolbelt.deploy.toolbelt.string.regex',
                  @LockMode = N'Exclusive', @LockOwner = N'Transaction',
                  @LockTimeout = 0, @DbPrincipal = N'public';
            IF @LockResult < 0
                THROW 52035, N'Ein paralleler Regex-Lifecycle ist bereits aktiv.', 1;
        END;
        SET @Pass += 1;
    END;
    IF SCHEMA_ID(N'toolbelt_string') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_string];';
        EXEC sys.sp_addextendedproperty @name = N'Toolbelt.Managed', @value = 1,
             @level0type = N'SCHEMA', @level0name = N'toolbelt_string';
        EXEC sys.sp_addextendedproperty @name = N'Toolbelt.SchemaCategory', @value = N'string',
             @level0type = N'SCHEMA', @level0name = N'toolbelt_string';
    END;
    IF @Release >= 10 DROP FUNCTION [toolbelt_string].[SVF_RegexCount];
    IF @Release >= 10 DROP FUNCTION [toolbelt_string].[SVF_RegexInstr];
    IF @Release >= 10 DROP FUNCTION [toolbelt_string].[SVF_RegexIsMatch];
    IF @Release >= 11 DROP FUNCTION [toolbelt_string].[SVF_RegexReplace];
    IF @Release >= 13 DROP FUNCTION [toolbelt_string].[SVF_RegexReplaceGroups];
    IF @Release >= 11 DROP FUNCTION [toolbelt_string].[SVF_RegexSubstring];
    IF @Release >= 13 DROP FUNCTION [toolbelt_string].[TVF_RegexCaptures];
    IF @Release >= 12 DROP FUNCTION [toolbelt_string].[TVF_RegexMatches];
    IF @Release >= 12 DROP FUNCTION [toolbelt_string].[TVF_RegexSplit];
    IF @Release >= 11 DROP FUNCTION [toolbelt_string].[SVF_RegexReplaceCore];
    IF @Release >= 13 DROP FUNCTION [toolbelt_string].[SVF_RegexReplaceGroupsCore];
    IF @Release >= 11 DROP FUNCTION [toolbelt_string].[SVF_RegexSubstringCore];
    IF @Release >= 13 DROP FUNCTION [toolbelt_string].[TVF_RegexCapturesCore];
    IF @Release >= 12 DROP FUNCTION [toolbelt_string].[TVF_RegexMatchesCore];
    IF @Release >= 12 DROP FUNCTION [toolbelt_string].[TVF_RegexSplitCore];
    IF @InstalledAssemblyHash IS NULL OR @InstalledAssemblyHash <> @AssemblyHash
    BEGIN
        DECLARE @AssemblyDdl nvarchar(max) =
            CASE WHEN @AssemblyId IS NULL THEN N'CREATE' ELSE N'ALTER' END
            + N' ASSEMBLY [Toolbelt_String_Regex] FROM ' + CONVERT(nvarchar(max), @AssemblyBits, 1)
            + N' WITH PERMISSION_SET = SAFE;';
        EXEC sys.sp_executesql @AssemblyDdl;
    END;
END TRY
BEGIN CATCH
    IF @OwnTransaction = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

SET ANSI_NULLS ON;
GO

-- ============================================================================
-- Objekt: toolbelt_string.SVF_RegexReplaceCore (intern)
-- Typ: CLR SVF; Zweck: SAFE-CLR-Kern der öffentlichen Replace-Fassade.
-- Vertrag: Documentation/SVF_RegexReplace.md; Parameter: max-Texte, Start=1,
-- Occurrence=0, Flags=c, Profile=standard; Resultset: nvarchar(max).
-- Dependencies: SAFE Toolbelt_String_Regex; Rechte: SELECT/REFERENCES.
-- Versionen: SQL Server 2019/2022/2025; Plattformen: Windows/Linux.
-- Fehlerverhalten: SQL 6522 / TBX_REGEX_*; keine Teilresultate/Seiteneffekte.
-- Performance: vollständige Materialisierung, kooperatives Gesamtbudget.
-- Einschränkungen: UTF-16-Positionen, keine Captures oder Backreferences.
-- ============================================================================
-- Technischer CLR-Kern: max-Parameter besitzen hier keine Defaults, weil
-- SQL Server diese für CLR-Funktionen zurückweist (1096).
CREATE FUNCTION [toolbelt_string].[SVF_RegexReplaceCore]
(
      @Input nvarchar(max)
    , @Pattern nvarchar(max)
    , @Replacement nvarchar(max)
    , @Start int
    , @Occurrence int
    , @Flags nvarchar(max)
    , @Profile nvarchar(max)
)
RETURNS nvarchar(max)
WITH CALLED ON NULL INPUT
AS EXTERNAL NAME [Toolbelt_String_Regex].[Toolbelt.String.Regex.RegexProvider].[RegexReplaceBounded];
GO

-- ============================================================================
-- Objekt: toolbelt_string.SVF_RegexReplace
-- Typ: T-SQL SVF; Zweck: Regex-Gesamttreffer durch literal Unicode ersetzen.
-- Vertrag: Documentation/SVF_RegexReplace.md; max-Texte, Start=1,
-- Occurrence=0, Flags=c, Profile=standard; Ergebnis: nvarchar(max).
-- Dependencies: interner SAFE-CLR-Kern; Rechte: SELECT/REFERENCES.
-- Versionen: SQL Server 2019/2022/2025; Plattformen: Windows/Linux.
-- Fehler: SQL 6522 / TBX_REGEX_*; NULL-Short-Circuit, keine Teilresultate.
-- Performance: Materialisierung und zusätzlicher SVF-Aufrufoverhead;
-- keine Inlining-/iTVF-Zusage, kooperatives Gesamtbudget im CLR-Kern.
-- Einschränkungen: UTF-16-Positionen, keine Capture-Ausgabe/Backreferences.
-- ============================================================================
CREATE FUNCTION [toolbelt_string].[SVF_RegexReplace]
(
      @Input nvarchar(max), @Pattern nvarchar(max), @Replacement nvarchar(max)
    , @Start int = 1, @Occurrence int = 0
    , @Flags nvarchar(max) = N'c', @Profile nvarchar(max) = N'standard'
)
RETURNS nvarchar(max)
AS
BEGIN
    -- Nach Unicode-Decoding vereinheitlicht die Fassade Collation-Metadaten,
    -- damit zentrale max-Defaults nicht mit Caller-Collations kollidieren.
    RETURN [toolbelt_string].[SVF_RegexReplaceCore](@Input COLLATE DATABASE_DEFAULT, @Pattern COLLATE DATABASE_DEFAULT, @Replacement COLLATE DATABASE_DEFAULT, @Start, @Occurrence, @Flags COLLATE DATABASE_DEFAULT, @Profile COLLATE DATABASE_DEFAULT);
END;
GO

-- ============================================================================
-- Objekt: toolbelt_string.SVF_RegexSubstringCore (intern)
-- Typ: CLR SVF; Zweck: SAFE-CLR-Kern der öffentlichen Substring-Fassade.
-- Vertrag: Documentation/SVF_RegexSubstring.md; Parameter: max-Texte,
-- Start=1, Occurrence=1, Flags=c, Profile=standard; Resultset: nvarchar(max).
-- Dependencies: SAFE Toolbelt_String_Regex; Rechte: SELECT/REFERENCES.
-- Versionen: SQL Server 2019/2022/2025; Plattformen: Windows/Linux.
-- Fehlerverhalten: SQL 6522 / TBX_REGEX_*; ohne Treffer NULL, leerer Treffer N''.
-- Performance: vollständige Materialisierung, kooperatives Gesamtbudget.
-- Einschränkungen: UTF-16-Positionen, keine Capture-Ausgabe/Backreferences.
-- ============================================================================
CREATE FUNCTION [toolbelt_string].[SVF_RegexSubstringCore]
(
      @Input nvarchar(max)
    , @Pattern nvarchar(max)
    , @Start int
    , @Occurrence int
    , @Flags nvarchar(max)
    , @Profile nvarchar(max)
)
RETURNS nvarchar(max)
WITH CALLED ON NULL INPUT
AS EXTERNAL NAME [Toolbelt_String_Regex].[Toolbelt.String.Regex.RegexProvider].[RegexSubstringBounded];
GO

-- ============================================================================
-- Objekt: toolbelt_string.SVF_RegexSubstring
-- Typ: T-SQL SVF; Zweck: n-ten Regex-Gesamttreffer als Unicode-Text liefern.
-- Vertrag: Documentation/SVF_RegexSubstring.md; max-Texte, Start=1,
-- Occurrence=1, Flags=c, Profile=standard; Ergebnis: nvarchar(max).
-- Dependencies: interner SAFE-CLR-Kern; Rechte: SELECT/REFERENCES.
-- Versionen: SQL Server 2019/2022/2025; Plattformen: Windows/Linux.
-- Fehler: SQL 6522 / TBX_REGEX_*; ohne Treffer NULL, leerer Treffer N''.
-- Performance: Materialisierung und zusätzlicher SVF-Aufrufoverhead;
-- keine Inlining-/iTVF-Zusage, kooperatives Gesamtbudget im CLR-Kern.
-- Einschränkungen: UTF-16-Positionen, keine Capture-Ausgabe/Backreferences.
-- ============================================================================
CREATE FUNCTION [toolbelt_string].[SVF_RegexSubstring]
(
      @Input nvarchar(max), @Pattern nvarchar(max)
    , @Start int = 1, @Occurrence int = 1
    , @Flags nvarchar(max) = N'c', @Profile nvarchar(max) = N'standard'
)
RETURNS nvarchar(max)
AS
BEGIN
    RETURN [toolbelt_string].[SVF_RegexSubstringCore](@Input COLLATE DATABASE_DEFAULT, @Pattern COLLATE DATABASE_DEFAULT, @Start, @Occurrence, @Flags COLLATE DATABASE_DEFAULT, @Profile COLLATE DATABASE_DEFAULT);
END;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE FUNCTION [toolbelt_string].[SVF_RegexIsMatch]
(
      @Input   nvarchar(max)
    , @Pattern nvarchar(max)
    , @Flags   nvarchar(4) = N'c'
)
RETURNS bit
WITH CALLED ON NULL INPUT
AS EXTERNAL NAME
    [Toolbelt_String_Regex]
    .[Toolbelt.String.Regex.RegexProvider]
    .[RegexIsMatchBounded];
GO

CREATE FUNCTION [toolbelt_string].[SVF_RegexInstr]
(
      @Input        nvarchar(max)
    , @Pattern      nvarchar(max)
    , @Start        int = 1
    , @Occurrence   int = 1
    , @ReturnOption int = 0
    , @Flags        nvarchar(4) = N'c'
)
RETURNS int
WITH CALLED ON NULL INPUT
AS EXTERNAL NAME
    [Toolbelt_String_Regex]
    .[Toolbelt.String.Regex.RegexProvider]
    .[RegexInstrBounded];
GO

CREATE FUNCTION [toolbelt_string].[SVF_RegexCount]
(
      @Input   nvarchar(max)
    , @Pattern nvarchar(max)
    , @Start   int = 1
    , @Flags   nvarchar(4) = N'c'
)
RETURNS int
WITH CALLED ON NULL INPUT
AS EXTERNAL NAME
    [Toolbelt_String_Regex]
    .[Toolbelt.String.Regex.RegexProvider]
    .[RegexCountBounded];
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO
-- Interne SAFE-CLR-TVFs: kanonischer Regexdialekt, kein Datenzugriff.
-- Vollständig materialisierte Ergebnisse; SQL6522 mit TBX_REGEX_*-Präfix.
-- Ohne Defaults: SQL CLR akzeptiert keine Defaults an max-Parametern.
CREATE FUNCTION toolbelt_string.TVF_RegexMatchesCore
(@Input nvarchar(max), @Pattern nvarchar(max), @Start int,
 @Flags nvarchar(max), @Profile nvarchar(max), @MaxRows int)
RETURNS TABLE(Ordinal bigint, StartPosition bigint, Length bigint, Value nvarchar(max))
AS EXTERNAL NAME [Toolbelt_String_Regex].[Toolbelt.String.Regex.RegexProvider].[RegexMatchesBounded];
GO
CREATE FUNCTION toolbelt_string.TVF_RegexSplitCore
(@Input nvarchar(max), @Pattern nvarchar(max),
 @Flags nvarchar(max), @Profile nvarchar(max), @MaxRows int)
RETURNS TABLE(Ordinal bigint, StartPosition bigint, Length bigint, Value nvarchar(max))
AS EXTERNAL NAME [Toolbelt_String_Regex].[Toolbelt.String.Regex.RegexProvider].[RegexSplitBounded];
GO
-- ============================================================================
-- Objekt: toolbelt_string.TVF_RegexMatches; Typ: inline TVF.
-- Zweck: nicht überlappende Gesamttreffer, keine Capture-Ausgabe.
-- Vertrag: Documentation/TVF_RegexMatches.md; Parameter: Input/Pattern max,
-- Start=1, Flags=c, Profile=standard, MaxRows=10000 (höchstens 100000).
-- Resultset: Ordinal/StartPosition/Length bigint, Value nvarchar(max).
-- Dependencies: interner SAFE-CLR-Kern; Rechte: SELECT auf dieser TVF.
-- Versionen/Plattformen: SQL Server 2019/2022/2025, Windows/Linux.
-- Fehler: SQL6522/TBX_REGEX_*; vollständig geprüft vor Ausgabe.
-- Performance: begrenzte Materialisierung; keine Streaming-/Plan-Zusage.
-- Einschränkungen: UTF-16, keine Captures/Backreferences; NULL => 0 Zeilen.
-- ============================================================================
CREATE FUNCTION toolbelt_string.TVF_RegexMatches
(@Input nvarchar(max), @Pattern nvarchar(max), @Start int = 1,
 @Flags nvarchar(max) = N'c', @Profile nvarchar(max) = N'standard', @MaxRows int = 10000)
RETURNS TABLE
AS RETURN
    SELECT Ordinal, StartPosition, Length, Value
    FROM toolbelt_string.TVF_RegexMatchesCore(@Input COLLATE DATABASE_DEFAULT,
        @Pattern COLLATE DATABASE_DEFAULT, @Start, @Flags COLLATE DATABASE_DEFAULT,
        @Profile COLLATE DATABASE_DEFAULT, @MaxRows);
GO
-- ============================================================================
-- Objekt: toolbelt_string.TVF_RegexSplit; Typ: inline TVF.
-- Zweck: vollständige Quelle an Regexseparatoren in Originaltokens zerlegen.
-- Vertrag: Documentation/TVF_RegexSplit.md; Parameter: Input/Pattern max,
-- Flags=c, Profile=standard, MaxRows=10000 (höchstens 100000), kein Start.
-- Resultset: Ordinal/StartPosition/Length bigint, Value nvarchar(max).
-- Dependencies: interner SAFE-CLR-Kern; Rechte: SELECT auf dieser TVF.
-- Versionen/Plattformen: SQL Server 2019/2022/2025, Windows/Linux.
-- Fehler: SQL6522/TBX_REGEX_*; keine verwertbaren Teilergebnisse.
-- Performance: begrenzte Materialisierung, kein relationaler Regexparser.
-- Einschränkungen: UTF-16; Leertrenner konsumieren nichts, nur Suchcursor+1;
-- Rand-/Zwischenleertokens erhalten, keine Captures/Entquotierung.
-- ============================================================================
CREATE FUNCTION toolbelt_string.TVF_RegexSplit
(@Input nvarchar(max), @Pattern nvarchar(max),
 @Flags nvarchar(max) = N'c', @Profile nvarchar(max) = N'standard', @MaxRows int = 10000)
RETURNS TABLE
AS RETURN
    SELECT Ordinal, StartPosition, Length, Value
    FROM toolbelt_string.TVF_RegexSplitCore(@Input COLLATE DATABASE_DEFAULT,
        @Pattern COLLATE DATABASE_DEFAULT, @Flags COLLATE DATABASE_DEFAULT,
        @Profile COLLATE DATABASE_DEFAULT, @MaxRows);
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO
-- Interne SAFE-CLR-Kerne ohne max-Parameterdefaults; kein Datenzugriff.
CREATE FUNCTION toolbelt_string.TVF_RegexCapturesCore
(@Input nvarchar(max), @Pattern nvarchar(max), @Start int,
 @Flags nvarchar(max), @Profile nvarchar(max), @MaxRows int)
RETURNS TABLE(MatchOrdinal bigint, GroupOrdinal int, CaptureOrdinal bigint,
 GroupName nvarchar(128), Matched bit, StartPosition bigint, Length bigint, Value nvarchar(max))
AS EXTERNAL NAME [Toolbelt_String_Regex].[Toolbelt.String.Regex.RegexProvider].[RegexCapturesBounded];
GO
CREATE FUNCTION toolbelt_string.SVF_RegexReplaceGroupsCore
(@Input nvarchar(max), @Pattern nvarchar(max), @Replacement nvarchar(max),
 @Start int, @Occurrence int, @Flags nvarchar(max), @Profile nvarchar(max))
RETURNS nvarchar(max)
WITH CALLED ON NULL INPUT
AS EXTERNAL NAME [Toolbelt_String_Regex].[Toolbelt.String.Regex.RegexProvider].[RegexReplaceGroupsBounded];
GO
-- ============================================================================
-- Objekt: toolbelt_string.TVF_RegexCaptures; Typ: inline TVF.
-- Zweck: alle Capture-Wiederholungen nach Treffer/Gruppe/Capture ausgeben.
-- Vertrag: Documentation/Architecture/REGEX_CAPTURE_REPLACE_CONTRACT.md.
-- Parameter: Input/Pattern max, Start=1, Flags=c, Profile=standard,
-- MaxRows=10000 (1..100000); 64 Gruppen, erfolgreiche Pfadhistory <=100000.
-- Resultset: MatchOrdinal/CaptureOrdinal/Position/Length bigint, GroupOrdinal
-- int, GroupName nvarchar(128), Matched bit, Value nvarchar(max).
-- Dependencies: interner SAFE-CLR-Kern; Rechte: SELECT auf dieser TVF.
-- Versionen/Plattformen: SQL Server 2019/2022/2025, Windows/Linux.
-- Fehler: SQL6522/TBX_REGEX_*; atomare Materialisierung vor erster Zeile.
-- Performance: endliche Profil-/Zeilen-/Textgrenzen, kooperatives Budget;
-- keine Heap-/Backtracking-Garantie. GroupName+Value zählen zum Textbudget.
-- Einschränkungen: UTF-16; keine Pattern-Backreferences; NULL => 0 Zeilen.
-- Gruppenöffnung bestimmt Ordinal; unbeteiligt => CaptureOrdinal0/Matched0
-- und NULL-Position/Length/Value, tatsächlicher Leercapture => Matched1.
-- Ausgabeordnung: ORDER BY MatchOrdinal, GroupOrdinal, CaptureOrdinal.
-- ============================================================================
CREATE FUNCTION toolbelt_string.TVF_RegexCaptures
(@Input nvarchar(max), @Pattern nvarchar(max), @Start int = 1,
 @Flags nvarchar(max) = N'c', @Profile nvarchar(max) = N'standard', @MaxRows int = 10000)
RETURNS TABLE
AS RETURN
    SELECT MatchOrdinal, GroupOrdinal, CaptureOrdinal, GroupName, Matched, StartPosition, Length, Value
    FROM toolbelt_string.TVF_RegexCapturesCore(@Input COLLATE DATABASE_DEFAULT,
        @Pattern COLLATE DATABASE_DEFAULT, @Start, @Flags COLLATE DATABASE_DEFAULT,
        @Profile COLLATE DATABASE_DEFAULT, @MaxRows);
GO
-- ============================================================================
-- Objekt: toolbelt_string.SVF_RegexReplaceGroups; Typ: T-SQL SVF.
-- Zweck: Gesamttreffer mit $N/${Name}/$$ gruppenbezogen ersetzen.
-- Vertrag: Documentation/Architecture/REGEX_CAPTURE_REPLACE_CONTRACT.md.
-- Parameter: Input/Pattern/Replacement max, Start=1, Occurrence=0 (alle),
-- Flags=c, Profile=standard; Ergebnis nvarchar(max), NULL => NULL.
-- Dependencies: interner SAFE-CLR-Kern; Rechte: SELECT/REFERENCES.
-- Versionen/Plattformen: SQL Server 2019/2022/2025, Windows/Linux.
-- Fehler: SQL6522/TBX_REGEX_*; strikte Referenzprüfung vor erster Suche.
-- Performance: begrenzte Materialisierung, kooperatives Gesamtbudget.
-- Einschränkungen: letzter erfolgreicher Capture je Gruppe; unbeteiligt leer;
-- positive vollständige ASCII-Dezimalreferenz ohne führende Null; ${Name}
-- nur explizit benannt. Backslash literal; erzeugte Dollarzeichen nicht parsen.
-- Ohne entsprechenden Treffer bleibt Input unverändert; UTF-16-Startposition.
-- ============================================================================
CREATE FUNCTION toolbelt_string.SVF_RegexReplaceGroups
(@Input nvarchar(max), @Pattern nvarchar(max), @Replacement nvarchar(max),
 @Start int = 1, @Occurrence int = 0,
 @Flags nvarchar(max) = N'c', @Profile nvarchar(max) = N'standard')
RETURNS nvarchar(max)
AS
BEGIN
    RETURN toolbelt_string.SVF_RegexReplaceGroupsCore(@Input COLLATE DATABASE_DEFAULT,
        @Pattern COLLATE DATABASE_DEFAULT, @Replacement COLLATE DATABASE_DEFAULT,
        @Start, @Occurrence, @Flags COLLATE DATABASE_DEFAULT, @Profile COLLATE DATABASE_DEFAULT);
END;
GO

SET NOCOUNT ON;
BEGIN TRY
    IF @@TRANCOUNT <> 1
        THROW 52039, N'Die Deployment-Transaktion ist vorzeitig beendet worden.', 1;

    DECLARE
          @VersionProperty sysname =
              N'Toolbelt.Module.toolbelt.string.regex.Version'
        , @ModeProperty sysname =
              N'Toolbelt.Module.toolbelt.string.regex.DeploymentMode'
        , @DeploymentMode nvarchar(16) = LOWER(N'central');

    IF EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 0 AND name = @VersionProperty)
        EXEC sys.sp_updateextendedproperty @name = @VersionProperty, @value = N'1.3.0';
    ELSE
        EXEC sys.sp_addextendedproperty @name = @VersionProperty, @value = N'1.3.0';

    IF EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 0 AND name = @ModeProperty)
        EXEC sys.sp_updateextendedproperty @name = @ModeProperty, @value = @DeploymentMode;
    ELSE
        EXEC sys.sp_addextendedproperty @name = @ModeProperty, @value = @DeploymentMode;

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties AS ep
           INNER JOIN sys.assemblies AS a ON a.assembly_id = ep.major_id
           WHERE ep.class = 5 AND ep.name = N'Toolbelt.Managed'
             AND a.name = N'Toolbelt_String_Regex'
       )
        EXEC sys.sp_updateextendedproperty
              @name = N'Toolbelt.Managed', @value = 1
            , @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_Regex';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.Managed', @value = 1
            , @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_Regex';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties AS ep
           INNER JOIN sys.assemblies AS a ON a.assembly_id = ep.major_id
           WHERE ep.class = 5 AND ep.name = N'Toolbelt.ModuleId'
             AND a.name = N'Toolbelt_String_Regex'
       )
        EXEC sys.sp_updateextendedproperty
              @name = N'Toolbelt.ModuleId', @value = N'toolbelt.string.regex'
            , @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_Regex';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.ModuleId', @value = N'toolbelt.string.regex'
            , @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_Regex';

    IF EXISTS (SELECT 1 FROM sys.extended_properties e JOIN sys.assemblies a ON a.assembly_id = e.major_id
               WHERE e.class = 5 AND e.name = N'Toolbelt.ModuleVersion' AND a.name = N'Toolbelt_String_Regex')
        EXEC sys.sp_updateextendedproperty @name = N'Toolbelt.ModuleVersion', @value = N'1.3.0',
             @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_Regex';
    ELSE
        EXEC sys.sp_addextendedproperty @name = N'Toolbelt.ModuleVersion', @value = N'1.3.0',
             @level0type = N'ASSEMBLY', @level0name = N'Toolbelt_String_Regex';

    DECLARE @FunctionName sysname;
    DECLARE FunctionCursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT name
        FROM sys.objects
        WHERE schema_id = SCHEMA_ID(N'toolbelt_string')
          AND name IN (N'SVF_RegexIsMatch', N'SVF_RegexInstr', N'SVF_RegexCount', N'SVF_RegexReplace', N'SVF_RegexSubstring', N'SVF_RegexReplaceCore', N'SVF_RegexSubstringCore', N'TVF_RegexMatches', N'TVF_RegexSplit', N'TVF_RegexMatchesCore', N'TVF_RegexSplitCore', N'TVF_RegexCaptures', N'SVF_RegexReplaceGroups', N'TVF_RegexCapturesCore', N'SVF_RegexReplaceGroupsCore');
    OPEN FunctionCursor;
    FETCH NEXT FROM FunctionCursor INTO @FunctionName;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.Managed', @value = 1
            , @level0type = N'SCHEMA', @level0name = N'toolbelt_string'
            , @level1type = N'FUNCTION', @level1name = @FunctionName;
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.ModuleId', @value = N'toolbelt.string.regex'
            , @level0type = N'SCHEMA', @level0name = N'toolbelt_string'
            , @level1type = N'FUNCTION', @level1name = @FunctionName;
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.ModuleVersion', @value = N'1.3.0'
            , @level0type = N'SCHEMA', @level0name = N'toolbelt_string'
            , @level1type = N'FUNCTION', @level1name = @FunctionName;
        DECLARE @Visibility nvarchar(16) = CASE WHEN @FunctionName IN (N'SVF_RegexReplaceCore', N'SVF_RegexSubstringCore',N'TVF_RegexMatchesCore',N'TVF_RegexSplitCore', N'TVF_RegexCapturesCore', N'SVF_RegexReplaceGroupsCore') THEN N'internal' ELSE N'public' END;
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.Visibility', @value = @Visibility
            , @level0type = N'SCHEMA', @level0name = N'toolbelt_string'
            , @level1type = N'FUNCTION', @level1name = @FunctionName;
        FETCH NEXT FROM FunctionCursor INTO @FunctionName;
    END;
    CLOSE FunctionCursor;
    DEALLOCATE FunctionCursor;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF CURSOR_STATUS(N'local', N'FunctionCursor') >= 0 CLOSE FunctionCursor;
    IF CURSOR_STATUS(N'local', N'FunctionCursor') > -3 DEALLOCATE FunctionCursor;
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.string.regex
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.archive.zip-memory
:On Error exit
-- RAISERROR statt THROW: Caller-Transaktionen bei XACT_ABORT ON nicht beschädigen.
IF @@TRANCOUNT<>0
BEGIN
    RAISERROR(N'TBX_ZIP_LIFECYCLE_CALLER_TRANSACTION: Deploy benötigt einen eigenen Transaktionsscope.',16,1);
    RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @VersionProperty sysname =
          N'Toolbelt.Module.toolbelt.archive.zip-memory.Version'
    , @ModeProperty sysname =
          N'Toolbelt.Module.toolbelt.archive.zip-memory.DeploymentMode'
    , @DependencyVersionProperty sysname =
          N'Toolbelt.Module.toolbelt.core.result-table.Version'
    , @AssemblyName sysname =
          N'Toolbelt_Archive_ZipMemory'
    , @DeploymentMode nvarchar(16) =
          LOWER(N'central')
    , @InstalledVersion nvarchar(64)
    , @ProductMajorVersion int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @AssemblyBits varbinary(max) =
          0x4d5a90000300000004000000ffff0000b800000000000000400000000000000000000000000000000000000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a2400000000000000504500004c010300c912bb900000000000000000e00022200b013000009600000008000000000000deb400000020000000c00000000000100020000000020000040000000000000006000000000000000000010000020000000000000300608500001000001000000000100000100000000000001000000000000000000000008cb400004f00000000c00000580400000000000000000000000000000000000000e000000c00000070b400001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000080000000000000000000000082000004800000000000000000000002e74657874000000e4940000002000000096000000020000000000000000000000000000200000602e727372630000005804000000c000000006000000980000000000000000000000000000400000402e72656c6f6300000c00000000e0000000020000009e00000000000000000000000000004000004200000000000000000000000000000000c0b40000000000004800000002000500e04e00009065000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001b3005007a00000001000011020304050e0428050000060ade610b076f90000006076f0d00000a286b0000060ade4c262079c800007201000070286b0000060ade39262079c80000727d000070286b0000060ade26262079c8000072f9000070286b0000060ade13262079c800007273010070286b0000060ade00178d07000002251606a22a000001400000000000000e0e001509000002000000000e23001317000001000000000e36001318000001000000000e49001319000001000000000e5c00131a0000011b3004007800000002000011020328060000060bde6c0c086f90000006086f0d00000a288c0000060ade4c262079c8000072e9010070288c0000060ade39262079c80000727d000070288c0000060ade26262079c8000072f9000070288c0000060ade13262079c800007273010070288c0000060ade00178d08000002251606a22a072a01400000000000000a0a001509000002000000000a1f001317000001000000000a32001318000001000000000a45001319000001000000000a5800131a000001133002008e010000030000110274070000020a03066f590000060b1201280e00000a2d077e0f00000a2b13066f590000060b1201281000000a731100000a811b00000104066f5b0000062c0d066f5b000006731200000a2b057e1300000a811300000105066f5d0000062c0d066f5d000006731200000a2b057e1300000a81130000010e04066f5f0000060c1202281400000a2d077e1500000a2b13066f5f0000060c1202281600000a731700000a81140000010e05066f610000060c1202281400000a2d077e1500000a2b13066f610000060c1202281600000a731700000a81140000010e06066f630000060b1201280e00000a2d077e0f00000a2b13066f630000060b1201281000000a731100000a811b0000010e07066f650000060b1201280e00000a2d077e0f00000a2b13066f650000060b1201281000000a731100000a811b0000010e08066f670000060d1203281800000a2d077e1900000a2b13066f670000060d1203281a00000a731b00000a81160000010e09066f690000062c0d066f69000006731c00000a2b057e1d00000a811c0000012a00001330020090020000040000110274080000020a03066f6e0000060b1201280e00000a2d077e0f00000a2b13066f6e0000060b1201281000000a731100000a811b00000104066f700000062c0d066f70000006731200000a2b057e1300000a811300000105066f720000060b1201280e00000a2d077e0f00000a2b13066f720000060b1201281000000a731100000a811b0000010e04066f740000062c0d066f74000006731200000a2b057e1300000a81130000010e05066f760000060c1202281800000a2d077e1900000a2b13066f760000060c1202281a00000a731b00000a81160000010e06066f780000060d1203281400000a2d077e1500000a2b13066f780000060d1203281600000a731700000a81140000010e07066f7a0000060d1203281400000a2d077e1500000a2b13066f7a0000060d1203281600000a731700000a81140000010e08066f7c0000060b1201280e00000a2d077e0f00000a2b13066f7c0000060b1201281000000a731100000a811b0000010e09066f7e0000060b1201280e00000a2d077e0f00000a2b13066f7e0000060b1201281000000a731100000a811b0000010e0a066f800000060c1202281800000a2d077e1900000a2b13066f800000060c1202281a00000a731b00000a81160000010e0b066f820000060c1202281800000a2d077e1900000a2b13066f820000060c1202281a00000a731b00000a81160000010e0c066f840000060b1201280e00000a2d077e0f00000a2b13066f840000060b1201281000000a731100000a811b0000010e0d066f860000060c1202281800000a2d077e1900000a2b13066f860000060c1202281a00000a731b00000a81160000010e0e066f880000062c0d066f88000006731200000a2b057e1300000a81130000010e0f066f8a000006810400001b2a1b3007009902000005000011022c10026f1e00000a2d08026f1f00000a2d102078c800007267020070738f0000067a0f01282000000a2d0e0f01282100000a6f2200000a2d102078c8000072e1020070738f0000067a0f01282100000a6f2200000a200004000031102078c80000721d030070738f0000067a0f02282300000a2d1a0f02282400000a166a310f0f02282400000a20000000046a31102078c800007281030070738f0000067a0f03282500000a2d130f03282600000a7e2700000a282800000a2c102078c8000072e9030070738f0000067a0f04282900000a2c102078c800007253040070738f0000067a026f1f00000a20000000106a3110207dc8000072a1040070738f0000067a026f2a00000a0a140b066f2b00000a2d0f06026f1f00000a28070000060b070a06026f1f00000a73200000060c080f01282100000a28080000060d096f4a0000061f415f16fe032c450f04282c00000a2c10207cc80000723c050070738f0000067a096f42000006096f4e000006096f50000006096f48000006096f4c0000061714286c0000061306dd05010000096f480000062c19096f480000061e2e10207fc800007298050070738f0000067a096f500000060f02282400000a3110207dc800007235060070738f0000067a096f4e00000620000000086a3110207dc80000728d060070738f0000067a096f50000006096f4e0000060f03282600000a280e0000060809280c00000608090f02282400000a0f03282600000a14280d000006130411048e6a096f500000062e102080c80000723a070070738f0000067a110414281000000613051105096f4c0000062e102080c8000072ef070070738f0000067a096f42000006096f4e000006096f50000006096f480000061105161104286c0000061306de0a072c06076f2d00000adc11062a000000411c0000020000000c010000800100008c0200000a000000000000001b300f00f401000006000011022c10026f1e00000a2d08026f1f00000a2d102078c800007267020070738f0000067a0f01282e00000a2d180f01282f00000a17320e0f01282f00000a201027000031102078c800007276080070738f0000067a026f1f00000a20000000106a3110207dc8000072a1040070738f0000067a026f2a00000a0a140b066f2b00000a2d0f06026f1f00000a28070000060b070a06026f1f00000a73200000060c0828160000060d096f390000062d0c280100002b1307dd37010000096f390000060f01282f00000a3110207dc8000072d2080070738f0000067a0809142809000006130411046f3100000a2d0c280100002b1307ddf90000001104280a000006130511046f3100000a8d08000002130616130838bc000000110411086f3200000a130911096f4a0000061f415f16fe03130a11096f42000006280b000006130b1106110811096f4000000611096f4200000611096f5800000611096f4e00000611096f5000000611096f4800000611096f4c000006110a11096f480000062c0a11096f480000061e3307110a16fe012b0116110511096f420000066f3300000a2d03172b0e110511096f420000066f3400000a110b723e090070283500000a110b11096f52000006288d000006a2110817581308110811046f3100000a3f36ffffff11061307de0a072c06076f2d00000adc11072a411c0000020000007b0000006c010000e70100000a000000000000001330040084000000070000110320ffffff7f6a3103162b020369733600000a0a20004001008d360000010b166a0c020716078e696f3700000a0d092c2f08096a580c0820000000106a3116066f2d00000a207dc800007248090070738f0000067a060716096f3800000a2bc208032e16066f2d00000a2079c8000072ba090070738f0000067a06166a6f3900000a062a1330030073000000080000110228160000060a02061428090000060b140c160d1613042b3b0711046f3200000a130511056f42000006031a283a00000a2c1b0917580d09173110207bc8000072530a0070738f0000067a11050c1104175813041104076f3100000a32bb082d10207ac8000072d10a0070738f0000067a082a0013300b001f02000009000011036f3b000006036f3d000006580a036f3900000620102700003110207dc8000072330b0070738f0000067a06036f370000062e10207fc8000072c40b0070738f0000067a036f3b0000060b036f39000006733b00000a0c160d389f010000042c06046f3c00000a02071f2e6a6f2600000602076f2400000620504b01022e102079c8000072810c0070738f0000067a02071e6a586f23000006130402071f0a6a586f23000006130502071f106a586f24000006130602071f146a586f24000006130702071f186a586f24000006130802071f1c6a586f23000006130902071f1e6a586f23000006130a02071f206a586f23000006130b02071f226a586f23000006130c02071f2a6a586f24000006130d02071f0c6a586f23000006130e02071f0e6a586f23000006130f1107152e131108152e0e110d152e09110c20ffff00003310207fc8000072fd0c0070738f0000067a110c2c10207fc8000072710d0070738f0000067a1f2e6a11096a58110a6a58110b6a581310020711106f2600000602071f2e6a5811096f25000006131111111104280f000006131211126f2200000a20000400003110207dc8000072d30d0070738f0000067a09175811121111110d6e11051104110611076e11086e110f110e2811000006036f3b000006733f0000061313021113280c0000060811136f3d00000a071110580b0917580d09036f390000063f55feffff07062e102079c8000072580e0070738f0000067a082a00133004004a0000000a000011283e00000a733f00000a0a160b2b3002076f3200000a6f420000060c060812036f4000000a2d0a0608176f4100000a2b0a06080917586f4200000a0717580b07026f3100000a32c7062a0000133003006c01000000000000026f2200000a18321f02166f4300000a284400000a2c1102176f4300000a1f3a330672b40e00702a026f2200000a16311c02166f4300000a1f2f2e0b02166f4300000a1f5c330672d40e00702a0272e60e0070283500000a2d720272ec0e00701a6f4500000a162f630272f40e00701a6f4500000a162f540272fc0e00701a6f4500000a162f450272060f00701a6f4500000a162f360272ec0e00701a6f4600000a2d280272f40e00701a6f4600000a2d1a0272100f00706f4700000a2d0d0272180f00706f4700000a2c0672200f00702a026f2200000a39830000000272420f0070283500000a2d760272460f00701a6f4600000a2d6802724c0f00701a6f4800000a2d5a0272520f00701a6f4500000a162f4b0272560f00701a6f4500000a162f3c02725c0f00701a6f4500000a162f2d0272640f00701a6f4500000a162f1e02726c0f00701a6f4500000a162f0f0272720f00701a6f4500000a16320672780f00702a723e0900702a13300500760100000b000011036f460000060a02061f1e6a6f2600000602066f2400000620504b03042e102079c8000072920f0070738f0000067a02061c6a586f2300000602061e6a586f230000060b02061f0e6a586f240000060c02061f126a586f240000060d02061f166a586f24000006130402061f1a6a586f23000006130502061f1c6a586f23000006130625204f0800005f036f4a000006204f0800005f2e102079c800007200100070738f0000067a07036f480000062e102079c8000072a9100070738f0000067a061f1e6a5811056a5811066a58130702061f1e6a5811056a11066a586f26000006021107036f4e0000066f2600000602061f1e6a5811056f25000006036f4400000628130000062d102079c80000724a110070738f0000067a1107036f4e00000658036f5400000631102079c8000072db110070738f0000067a1e5f2d2e08036f4c0000063315096e036f4e000006330b11046e036f500000062e102079c80000724f120070738f0000067a0311076f570000062a00001b300500480100000c00001102036f56000006036f4e0000066f270000060a04176a32120420000000046a3009036f50000006043110207dc8000072f0120070738f0000067a036f50000006b78d360000010b060c140d166a1304036f480000061e330d061617734900000a0d090c2b1e036f4e000006036f500000062e102080c80000725a130070738f0000067a20004001008d360000011305166a13060e042c070e046f3c00000a0811051611058e696f3700000a130711072d02de54110611076a5813061106130411060430071106078e6a3110207dc8000072f7130070738f0000067a1106036f4e00000605280e00000611051607110611076adab71107284a00000a2b96092c06096f2d00000adc066f290000062c102079c800007265140070738f0000067a078e6a11042e102079c8000072d9140070738f0000067a071308de0a062c06066f4b00000adc11082a41340000020000004f000000ae000000fd0000000a000000000000000200000013000000280100003b0100000a00000000000000133002004100000000000000022d012a032d10207ec800007257150070738f0000067a02284c00000a03284c00000a284d00000a04284e00000a2c10207ec8000072f0150070738f0000067a2a860320000800005f2d0c7e15000004026f4f00000a2a7e14000004026f4f00000a2a00133004003b0000000d000011150a160b2b2c032c0f0720ffff00005f2d06036f3c00000a7e16000004060207916120ff0000005f95061e64610a0717580b07028e6932ce06662a001b300600a30000000e000011031f1f5f185a0a031b631f3f5f0b031f0b631f1f5f0c021f1f5f0d021b631f0f5f130420bc070000021f09631f7f5f581305032d0e022d0b1206fe150400001b11062a081f173027071f3b3022061f3b301d110417321811041f0c30120917320e091f1f30091105203b080000310b1206fe150400001b11062a001105110409080706735000000a735100000a1306de0f261207fe150400001b11071306de0011062a000110000000007b001691000f2700000113300300430000000f00001120000100008d3e0000010a160b2b2a070c160d2b1808175f2d050817642b09202083b8ed081764610c0917580d091e32e40607089e0717580b076e068e696a32ce062a00133003002400000010000011028e69038e692e02162a160a2b0e0206910306912e02162a0617580a06028e6932ec172a3202039102031758911e62602a7a02039102031758911e626002031858911f10626002031958911f1862602a133004005e01000011000011026f210000061f166a2f102079c800007254160070738f0000067a026f2100000620150001006a285200000a690a026f21000006066a590b0207066f250000060c088e691f16590d38fa0000000809281500000620504b050640e500000008091f145828140000061304091f1658110458088e6940ca00000007096a58130508091a58281400000608091c582814000006130608091e582814000006130708091f0a582814000006130808091f0c582815000006130908091f10582815000006130a2d0a11062d06110711082e10207fc8000072710d0070738f0000067a110720ffff00002e13110820ffff00002e0a1109152e05110a153310207fc8000072fd0c0070738f0000067a110a6e11096e58130b110b1105300a110b026f2100000631102079c8000072d0160070738f0000067a11051108110a6e11096e73360000062a0917590d09163cfffeffff2079c800007234170070738f0000067a0000133002001d0100001200001102390901000002282200000a0b071d3ba5000000071f0c59450600000005000000da0000001c000000da000000330000009300000038d50000000216284300000a0c081f462e45081f492e2e38be0000000216284300000a0c081f442e3d081f522e4738a700000002729e170070283500000a2d6238950000000272c0170070283500000a2d5838830000000272da170070283500000a2d5e2b740272f4170070283500000a2d3f2b65027212180070283500000a2d382b56027230180070283500000a2d392b47027240180070283500000a2d322b382096c800000a2b362098c800000a2b2e2099c800000a2b26209ac800000a2b1e209bc800000a2b16209cc800000a2b0e209ec800000a2b06209fc800000a020673920000062a0000001b3004007700000013000011739300000625285300000a7d470000040a06026f5400000a7d47000004de4d0b06077b440000047d4500000406076f0d00000a7d46000004de322606209bc800007d450000040672641800707d46000004de192606209ec800007d450000040672ce1800707d46000004de00178d0b000002251606a22a0001280000000011000e1f001b0a000002000011000e3a001929000001000011000e530019190000019273a200000625027d5900000425037d5a000004fe06a3000006735500000a28180000062a000000133003005a0000000000000073a400000625027d5b00000425037d5c00000425047d5d00000425057d5e000004250e047d5f000004250e057d60000004250e067d61000004250e077d62000004250e087d63000004fe06a5000006735500000a28180000062a000013300200410000001400001102740b0000020a03067b45000004731100000a811b00000104067b460000042c0d067b46000004731200000a2b057e1300000a811300000105067b47000004512a0000001b30050013010000150000110f00282000000a2d210f01282e00000a2d180f01282f00000a17320e0f01282f00000a2000080000310b72c017007028170000067a0f00282100000a0a066f2200000a2c4c066f2200000a0f01282f00000a303d06166f4300000a1f2f2e3206066f2200000a17596f4300000a1f2f2e20061f5c6f5600000a162f15061f3a6f5600000a162f0a06166f5600000a16320b72c017007028170000067a06178d3a00000125161f2f9d6f5700000a0b160c2b3507089a0d096f2200000a2c1a0972420f0070283500000a2d0d0972e60e0070283500000a2c0b72c017007028170000067a0817580c08078e6932c5001617735800000a066f5900000a735a00000a1304de0c2672c017007028170000067a11042a00011000000000ee001604010c2a0000011b3006001106000016000011026f1e00000a3a2f0100000f01282e00000a3a230100000f01282f00000a2c0d0f01282f00000a1e400d0100000f02282e00000a3a010100000f02282f00000a173ff40000000f02282f00000a20000400003de30000000f03282e00000a3ad70000000f03282f00000a173fca0000000f03282f00000a20000800003db90000000f04282300000a3aad0000000f04282400000a176a3f9f0000000f04282400000a20000000026a3d8d0000000f05282300000a3a810000000f05282400000a176a32760f05282400000a20000000086a30670f06282300000a2d5e0f06282400000a176a32530f06282400000a20000000096a30440f07282300000a2d3b0f07282400000a176a32300f07282400000a20000080086a30210f08282e00000a2d180f08282f00000a17320e0f08282f00000a2060ea0000310b729e17007028170000067a0f08282f00000a73950000060a026f1f00000a0f07282400000a310b721218007028170000067a0f07282400000a0673970000060b026f2a00000a0c086f2b00000a2c0808166a6f3900000a20004001008d360000010d166a13042b12110411056a58130407091611056f3800000a080916098e696f3700000a2513051630dd1104026f1f00000a2e0b724018007028170000067a07166a6f3900000a07285b00000a17735c00000a130611060f02282f00000a0f03282f00000a0f04282400000a0f05282400000a06281e00000613070f06282400000a06739700000613081108285b00000a17735d00000a130911076f5e00000a130c38f1010000120c285f00000a130d066f96000006110d11086f6000000a7d4b000004110920504b03046f6100000a11091f146f6200000a110920000800006f6200000a11090f01282f00000ad16f6200000a1109166f6200000a11091f216f6200000a1109166f6100000a1109166f6100000a1109110d7b4a0000046f6100000a1109110d7b480000048e69d16f6200000a1109166f6200000a1109110d7b480000046f6300000a11086f6000000a130e07110d7b490000046f3900000a15130f110d7b4a00000413100f01282f00000a1e331711102d131108188d360000012516199c16186f3800000a0f01282f00000a1e330411102d03142b0911081617736400000a13112b78066f960000060709161110098e69286500000a6f3700000a1313111316300b724018007028170000067a1613142b207e16000004110f091114916120ff0000005f95110f1e6461130f1114175813141114111332da11112c0d1111091611136f3800000a2b0b1108091611136f3800000a111011135913101110163083de0c11112c0711116f2d00000adc066f96000006110d110f667d4c000004110d11086f6000000a110edab87d4d00000411086f6000000a13121108110d7b4b0000041f0e6a586f3900000a1109110d7b4c0000046f6100000a1109110d7b4d0000046f6100000a110811126f3900000a120c286600000a3a03feffffde0e120cfe160b00001b6f4b00000adc11086f6000000a130a11076f5e00000a130c38d9000000120c285f00000a1315066f96000006110920504b01026f6100000a11091f146f6200000a11091f146f6200000a110920000800006f6200000a11090f01282f00000ad16f6200000a1109166f6200000a11091f216f6200000a110911157b4c0000046f6100000a110911157b4d0000046f6100000a110911157b4a0000046f6100000a110911157b480000048e69d16f6200000a1109166f6200000a1109166f6200000a1109166f6200000a1109166f6200000a1109166f6100000a110911157b4b000004b86f6100000a110911157b480000046f6300000a120c286600000a3a1bffffffde0e120cfe160b00001b6f4b00000adc11086f6000000a110adab8130b110920504b05066f6100000a1109166f6200000a1109166f6200000a110911076f6700000ad16f6200000a110911076f6700000ad16f6200000a1109110b6f6100000a1109110ab86f6100000a1109166f6200000a11096f6800000a066f9600000611086f6900000a066f96000006735a00000a1316de2e11092c0711096f4b00000adc11082c0711086f4b00000adc11062c0711066f4b00000adc072c06076f4b00000adc11162a00000041ac0000020000004403000081000000c50300000c00000000000000020000003d02000004020000410400000e000000000000000200000061040000ec0000004d0500000e000000000000000200000034020000ac030000e00500000c000000000000000200000025020000c7030000ec0500000c0000000000000002000000f001000008040000f80500000c00000000000000020000007a0100008a040000040600000a000000000000001b300400e40100001700001173a60000060a060e057d6400000406026f6a00000a7d6500000406fe06a7000006736b00000a0b071f0c6a6f6c00000a026f6d00000a2054425a573309026f6d00000a172e0b724018007028170000067a026f6d00000a0c086e036a310b721218007028170000067a08736e00000a0d283e00000a736f00000a1304161305166a1306161307382a010000071f106a6f6c00000a026f7000000a026f6d00000a1308026f7100000a1309251105300b724018007028170000067a130511082c12110820ffff0000350911086e04195a6a310b72c017007028170000067a110905360b721218007028170000067a1106110985d6130611060e04310b721218007028170000067a0711086e110985d66f6c00000a0211086f7200000a130a1617735800000a110a6f4f00000a130bde0c2672c017007028170000067a110b731200000a04731100000a281c000006261104110b6f7300000a2c0b72f417007028170000067a1104110b176f7400000a09739400000625110a7d4800000425067b650000046f6000000a7d49000004251109697d4a0000046f7500000a067b65000004256f6000000a1109586f3900000a11071758130711076a086e3fccfeffff067b650000046f6000000a067b650000046f7600000a2e0b724018007028170000067a092a0110000000001d01122f010c18000001c21617735800000a801400000420b5010000287700000a287800000a287900000a8015000004281200000680160000042ad602287a00000a036f7b00000a2c08036f2b00000a2d102079c800007240190070738f0000067a02037d17000004020428220000062a1e027b180000042a2202037d180000042a3e02031828250000061628140000062a3e02031a28250000061628150000062a1330050044000000180000110203046a2826000006048d360000010a027b17000004036f3900000a160b2b1e027b1700000406070407596f3700000a0c082d06737c00000a7a0708580b070432de062abe03166a321904166a321403022821000006300b04022821000006035931102079c8000072a8190070738f0000067a2a5a0203042826000006027b17000004030473280000062a8602287d00000a02037d19000004027b19000004046f3900000a02057d1a0000042a1e027b1a0000042a0a172a0a162a0a162a1a737e00000a7a1a737e00000a7a1a737e00000a7a00133004004200000019000011027b1a0000042d02162a056a027b1a000004285200000a690a027b190000040304066f3700000a0b072d06737c00000a7a02027b1a000004076a597d1a000004072a062a1a737e00000a7a1a737e00000a7a1a737e00000a7a220203287f00000a2a9202287a00000a020328380000060204283a0000060205283c000006020e04283e0000062a1e027b1b0000042a2202037d1b0000042a1e027b1c0000042a2202037d1c0000042a1e027b1d0000042a2202037d1d0000042a1e027b1e0000042a2202037d1e0000042a00133002005c0000000000000002287a00000a020328410000060204284300000602052845000006020e042847000006020e052849000006020e06284b000006020e07284d000006020e08284f000006020e092851000006020e0a2853000006020e0b28550000062a1e027b1f0000042a2202037d1f0000042a1e027b200000042a2202037d200000042a1e027b210000042a2202037d210000042a1e027b220000042a2202037d220000042a1e027b230000042a2202037d230000042a1e027b240000042a2202037d240000042a1e027b250000042a2202037d250000042a1e027b260000042a2202037d260000042a1e027b270000042a2202037d270000042a1e027b280000042a2202037d280000042a1e027b290000042a2202037d290000042a1e027b2a0000042a2202037d2a0000042a9e02284200000672121a00701a6f4800000a2d1202284200000672520f00701a6f4800000a2a172a1e027b2b0000042a2202037d2b0000042a1e027b2c0000042a2202037d2c0000042a1e027b2d0000042a2202037d2d0000042a1e027b2e0000042a2202037d2e0000042a1e027b2f0000042a2202037d2f0000042a1e027b300000042a2202037d300000042a1e027b310000042a2202037d310000042a1e027b320000042a2202037d320000042a1e027b330000042a2202037d330000042a66736d0000062502738000000a6f5a00000625036f5c0000062a00133003005300000000000000736d00000625026f5e0000062503738100000a6f600000062504738100000a6f620000062505738000000a6f64000006250e04738000000a6f66000006250e05738200000a6f68000006250e066f6a0000062a1e02287a00000a2a1e027b340000042a2202037d340000042a1e027b350000042a2202037d350000042a1e027b360000042a2202037d360000042a1e027b370000042a2202037d370000042a1e027b380000042a2202037d380000042a1e027b390000042a2202037d390000042a1e027b3a0000042a2202037d3a0000042a1e027b3b0000042a2202037d3b0000042a1e027b3c0000042a2202037d3c0000042a1e027b3d0000042a2202037d3d0000042a1e027b3e0000042a2202037d3e0000042a1e027b3f0000042a2202037d3f0000042a1e027b400000042a2202037d400000042a1e027b410000042a2202037d410000042a1e027b420000042a2202037d420000042a66738e0000062502738000000a6f6f00000625036f710000062a133003009c00000000000000738e0000062502738000000a6f7300000625036f750000062504738200000a6f770000062505738100000a6f79000006250e04738100000a6f7b000006250e05738000000a6f7d000006250e06738000000a6f7f000006250e07738200000a6f81000006250e08738200000a6f83000006250e09738000000a6f85000006250e0a738200000a6f87000006250e0b6f89000006250e0c6f8b0000062a1e02287a00000a2a3e0204288300000a020328910000062a1e027b430000042a2202037d430000042a7a0272161a00700372341a0070288400000a288300000a02047d440000042a1e02287a00000a2a1e02287a00000a2a6602288500000a7d4e00000402287a00000a02037d4f0000042a82027b4e0000046f8600000a027b4f0000046a320b723018007028170000067a2a5602288700000a02037d5000000402047d510000042a00000013300600750000001a000011027b510000046f96000006026f6000000a056ad60a06027b50000004310b721218007028170000067a06026f8800000a6a312d02027b500000040620001000006a026f8800000a6a186ad8288900000a288900000a285200000ab76f8a00000a02030405288b00000a027b510000046f960000062a4e02178d360000012516039c16176f3800000a2a1e027b570000042a2202037d570000042a1e027b580000042a2202037d580000042a001b3003000a0200001b00001102287a00000a032c4005176a323b0520000000106a30320e0417322d0e04201027000030240e05176a321e0e0520000000046a30140e06176a320e0e077e2700000a282800000a2c0b72721a0070738c00000a7a04166a32040405310b72b61a0070738d00000a7a020e087d54000004020e057d55000004020e077d560000040228a100000602030473200000067d52000004027b5200000428160000060a066f390000060e04310b72da1a0070738d00000a7a027b52000004060e0828090000060b02283e00000a738e00000a7d5300000402076f3100000a8d33000001289b000006160c38fb0000000228a100000607086f3200000a0d027b53000004096f420000066f8f00000a2c0b72f81a0070738d00000a7a096f4a0000061f415f2d11096f480000062c14096f480000061e2e0b721e1b0070738d00000a7a096f42000006280b000006723e090070289000000a2d08096f580000062c0b72481b0070738d00000a7a096f500000060e05301f096f4e00000620000000086a3011096f500000060e0602289c00000659310b72741b0070738d00000a7a096f50000006096f4e0000060e07280e0000060202289c000006096f5000000658289d000006027b53000004096f42000006096f9100000a02289a00000608096f42000006a20817580c08076f3100000a3ff9feffff0228a1000006de0f130472a01b00701104739200000a7a2a0000411c00000000000006000000f4010000fa0100000f0000000900000236027b53000004036f8f00000a2a00001b300500830000001c0000110228a1000006027b530000040312006f9300000a2d0b72d41b0070738d00000a7a027b5200000406027b55000004027b56000004027b54000004280d0000060b078e6a066f50000006331407027b540000042810000006066f4c0000062e0b72f61b0070738d00000a7a0228a1000006070cde0d0d72a01b007009739200000a7a082a0001100000000000007474000d0900000252027b540000042c0b027b540000046f3c00000a2a1e02287a00000a2a4a027b59000004027b5a000004281c0000062a1e02287a00000a2a133009003c00000000000000027b5b000004027b5c000004027b5d000004027b5e000004027b5f000004027b60000004027b61000004027b62000004027b63000004281d0000062a1e02287a00000a2ada027b640000046f9600000603166a321a03027b650000046f7600000a027b650000046f6000000a59310b724018007028170000067a2a0042534a4201000100000000000c00000076342e302e33303331390000000005006c00000004200000237e000070200000c816000023537472696e677300000000383700001c1c00002355530054530000100000002347554944000000645300002c12000023426c6f620000000000000002000001571da209090a000000fa01330016000001000000450000001200000065000000a7000000eb0000009300000016000000970000001c0000000800000033000000600000000e000000010000000300000010000000010000000000f00b0100000000000600d008dc0f06002209dc0f06002908920f0f00fc0f000006005108300d0600b308300d06000909300d0600f008300d06003d08bd0f06008108300d060068085c0a0600b313ab0c06003a0a76150a009e08500f0a00f905500f0a00f305500f0600f3068f120a00c7119e100a00760a9e100a003a019e100a006c0b9e100a00b20c9e100e00680d60010600af0d76150600e10d600106005c0d60010a0019019e100a00c9159e1006009f00ab0c06007407ab0c06008a0c60010600840c60010600d5008d01060022018d010600290dab0c0600d6008d0106006f0bab0c0e00760c090d0600930dab0c06009800ab0c06002d0eab0c0600c80d76150600ec0e600106003a0f600193007a0f00000600aa00ab0c06000e08dc0f0600dc0c60010600350eab0c0e00940a920f0600830aab0c0600ad15ab0c0600b3008d0106005209ab0c06003f0eab0c06002b0fab0c0600c1008d010600920eab0c0e005506090d0600170fab0c0600ff06ab0c06000801ab0c0600a40aab0c06002a0a76150e00df0b090d0600270b76150600170b761506007d0dab0c06001b0eab0c000000005701000000000100010081011000000ff51531000100010003011000de0e0000310017002000030110002e0c00007d0019002800030110001416000031001b003600030110007601000031001f003f0003011000d314000031002b00590003011000f5140000310034006e0003011000f60d0000c50043008f00030110000b0e0000c5004400920003011000621300003100450093000301100070160000310048009400030110003d0b000031004e00950003011000110f000081005000970002011000fa0c0000310052009a00030110001700000031005900a200030110002d00000031005b00a400030110000100000031006400a60051806b11a5045180e510a50451806410a8045180e611a5045180ac12a8045180a607ab045180bb07ab045180d207ab045180080aa80451806212a8045180170aa8045180020aa8045180f909a80451804f12a80451808506ae0451804009ae0451800402ae045180b20bae0451805b0bae043100c613b1043100ba13b1043100ea06b5042100910cb9040100bf03a50421004d06b9040100510aa50401003405a50401001204a80401008e05a50401009903a5040100d703a80401007e03ae0401008f04bd0401006b05a50401002103a8040100d304a8040100a802ab0401004b04a50401006c04a50401001405c10401008e05a50401004c05a5040100f503c90401006003ae0401007e03ae0401004b04d00401006c04d00401002103c9040100a802c9040100dd02d7040100bf02bd040100f503c90401006003ae040100d703c90401007e03ae040100d605d70401004b04d00401006c04d00401002103c9040100a802c9040100dd02d7040100fa02d7040100b605c90401004403d7040100f804ae0401001405c1040100f503a8042300bc0ea8040300ab0ea8040300af06ae040300eb01de0403006007bd0403000414a5040300bf0aa80403001214a5040300a801ab0403001702ab042100490be2042100d113a8042100cd14a5042100490be7042100f90eeb0421007a10ef0421001415f9042100d911a5042100890eb60001003004fe040100af04a5040600650755000600cd144c0006009507de04060046064c0006006f104c000600cb124c0006007c165f000600c60b5f0006009f095f00060089075f000600d1134c000600250fe70406004e06b90450200000000096006016020501001821000000009600d31511050600dc210000000096008b151a050800782300000000960093153a0512001426000000009100ab1370052200d828000000009100581011052700f42a000000009100520c7f052900842b000000009100561688052b00042c0000000091000b1090052d00302e000000009100d812a1053000882e0000000091004513b20531000030000000009100ca0eb70532008431000000009100b801bf0534000c330000000091005d0ecf05390059330000000091004b07d8053c007c33000000009100f100df053e00c4330000000091006a07e80540008434000000009100e506f3054200d434000000009100cf0bf805420004350000000091004301000644001135000000009100040107064600303500000000910010160e0648009c360000000091006b0f15064900c837000000009100e2141b064a007438000000009600f61227064b009c380000000096000d1330064d0004390000000096005e134706560054390000000096000b0755065a00843a0000000096008b095e065c00504100000000910046107506650050430000000091188b0f88066b008143000000008618850f8c066b00b743000000008608a90aa8006d00bf43000000008108b40a63006d00c843000000008600430193066e00d843000000008600040198066f00e843000000008600b3109d0670003844000000008600d106a40672006844000000008600400caa0674007f44000000008618850fb1067600a144000000008608430aa8007900a94400000000c608ac0148007900ac4400000000c6084f0b48007900af4400000000c608010848007900b24400000000c608a90aa8007900b94400000000c608420da8007900c04400000000c6084f0d63007900c84400000000c600b30135017a00164500000000c6009e0a06007d00184500000000c600560bb9067d001f4500000000c600dc0a63007f00264500000000c60008083d0180002d4500000000c400f107150083003645000000008618850fc10684005b45000000008608d813a80088006345000000008108e313630088006c450000000086081710ac00890074450000000081082810010089007d450000000086085c14a8008a008545000000008108771463008a008e45000000008608aa09a8008b009645000000008108c30963008b00a045000000008618850fc9068c000846000000008608830bac0097001046000000008108940b0100970019460000000086081c072100980021460000000081082a07100098002a4600000000860836112c03990032460000000081084911720099003b460000000086081e14a8009a004346000000008108341463009a004c460000000086080806ac009b0054460000000081081e0601009b005d460000000086080b12ac009c006546000000008108231201009c006e46000000008608dd005a039d007646000000008108e70012039d007f46000000008608bd10a8009e008746000000008108d11063009e009046000000008608f810a8009f0098460000000081080e1163009f00a1460000000086086f13de06a000a9460000000081088213e706a000b2460000000086085c14a800a100ba4600000000810877146300a100c346000000008608ee13a800a200cb4600000000860800146300a200d4460000000086082a164800a300fc46000000008608970ef106a3000447000000008108a70ef906a3000d470000000086089a062100a4001547000000008108ab061000a4001e470000000086081c072100a50026470000000081082a071000a5002f47000000008608bd100207a6003747000000008108d1100a07a6004047000000008608f8100207a70048470000000081080e110a07a70051470000000086080806f106a80059470000000081081e06f906a8006247000000008608dd00f106a9006a47000000008108e700f906a900734700000000860832021307aa007b4700000000810842021b07aa008447000000008608c4012c03ab008c47000000008108d5017200ab0095470000000096009e072407ac00b047000000009600c3122b07ae000f48000000008618850f0600b5001748000000008608970ef106b5001f48000000008108a70ef906b50028480000000086089a062100b6003048000000008108ab061000b6003948000000008608830bf106b7004148000000008108940bf906b7004a480000000086081c072100b80052480000000081082a071000b8005b480000000086082a161307b90063480000000081083a161b07b9006c48000000008608bd100207ba007448000000008108d1100a07ba007d48000000008608f8100207bb0085480000000081080e110a07bb008e480000000086080806f106bc0096480000000081081e06f906bc009f48000000008608dd00f106bd00a748000000008108e700f906bd00b04800000000860832021307be00b84800000000810842021b07be00c1480000000086085e021307bf00c94800000000810878021b07bf00d2480000000086082915f106c000da480000000081083c15f906c000e34800000000860865061307c100eb4800000000810874061b07c100f44800000000860827132100c200fc4800000000810836131000c20005490000000086086f13de06c3000d490000000081088213e706c30016490000000096009e073807c4003049000000009600c3123f07c600d849000000008618850f0600d300e049000000008618850f5607d300f049000000008608970eac00d500f849000000008108a70e0100d500014a000000008318850f5c07d600204a000000008618850f0600d800284a000000008618850f0600d800304a000000008318850f0100d8004a4a000000008300370b0600d9006b4a000000008318850f6207d900844a00000000c60008083d01db00054b00000000c6004d096907de00194b00000000860882106e07df00214b00000000810890107307df002a4b0000000086088b11a800e000324b000000008108a2116300e0003c4b000000008618850f7907e100704d0000000086008612d601e900804d0000000086006415b002ea00204e000000008100370b0600eb00354e000000008618850f0600eb003d4e0000000083005b008a07eb00504e000000008618850f0600eb00584e00000000830078008a07eb00a04e000000008618850f0600eb00a84e00000000830043006300eb00000001008009000002005b0700000300fd1100000400750e000005002202000001008009000002006f10000001007a0902000200b70e02000300bc06020004005b0702000500261102000600241102000700340602000800fe0002000900520202000a00e601000001007a0902000200b70e02000300bc0602000400a50b020005005b07020006004a1602000700261102000800241102000900340602000a00fe0002000b00520202000c00920202000d004f1502000e00830602000f005313020010009513000001008009000002005b0700000300fd1100000400750e000005002202000001008009000002006f10000001004e0600000200cd0a00000100f90e00000200380700000100f90e00000200fb01101003001415000001007a10000001005b0700000100f90e00000200851600000100f90e00000200851600000300fd1100000400750e10100500141500000100241100000200261100000300500e000001007a09000002007912000001007a0910100200141500000100f907000002007d0700000100b01400000200b514000001007a0900000200a914000001007a0900000200a91400000100f90e00000100ec15000001001f0d00000100650700000200cd14000001009507000002004606000003006f1000000400cb12000005007c1600000600c60b000007009f0900000800890700000900d113000001009f1502000200b70e02000300bc0602000400f30100000100650700000200cd14000001009507000002004606000003006f1000000400cb12000005007c1600000600c60b000007009f0900000800890700000900d11300000100f90e000002006f1000000300cb12000004007c1600000500c60b00000600250f00000100920c00000200e60a000001007a0900000100a91400000100a91400000100a914000002005e1500000100a914000002005e1500000100a91400000200e60a000001004e0600000200a91400000300e60a000001007a09000001001e0f00000200a914000003005e1500000100a91400000200e70c000001007a09000001001e0f00000200a914000003005e15000001008a0a00000100a91400000200391000000300921400000400dc09000001007a09000001007a09000001007a09000001007a0900000100a50b000002005b07000003005c11000004004a14000005003406000006003b1200000700fe0000000800261100000900241100000a00951300000b009214000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a0900000100b70e00000200bc06000001005b0700000200261100000300241100000400340600000500fe0000000600520200000700e601000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a09000001007a0900000100b70e00000200bc0600000100a50b000002005b07000003004a1600000400261100000500241100000600340600000700fe0000000800520200000900920200000a004f1500000b00830600000c00531300000d00951300000100b70e00000200c906000001007a0900000100ec1500000200c30e000001007a0900000100a71500000200250f000001001e0f00000200a914000003005e15000001007a09000001007a09000001007a09000001004e0600000200e60a000003007b1100000400ed1200000500d91100000600b91100000700890e000008001415000001006507000001006507000001005e150900850f01001100850f06001900850f0a002900850f10003100850f10003900850f10004100850f10004900850f15005100850f10005900850f10007100850f06007901850f060089018e0621000c0061094800d9001e0c4c000c0057095000d900850f01009900850f100099001e0c5500140061094800a1001e0c5f00140057095000a100850f63001c0061094800b1001e0c6e001c0057095000b100850f1500e100850f7200e1001e0c78009100180c48009100a90aa8009900180c48009900570921009901a90aac00a100180c4800a1005709a800a900180c4800a9005709b00029018507b6002901cc0cbb00b100180c48009100230cc500f9004f0b4800b10057094800f900f1070600d900180c4800d9005709ac00a101bf16ee002c001f15ac003400990c0a013c00b31518013c00990c1e019901a51625010101850f0100f900b3013501f90008083d01f9004f0d630099017f1257014400850f01001901de060600440000028701c101770b9a013c00850fa0013c006e09ab013c000002b4013c00a20cb4019901a212bc01d101470fc1019901f109c6019901f60ace019901ed0ad6019901ed0ace013101850ff901e101bf150302e901f10706002901bb1410022901ee0c17022901bd0cbb006900800a2302f100850f43022400850f8701f901d80c690291000f0c7c024c00de0650004c00850f89029901f1099e029901c714a3020102850faa026900d011b0029100850f720069004e01ea025901850fef026101850fef025400770f00035c0008155000f900420da8006101080812036101080817036101080872003101850f1c03f901d80c26035c006d15480054001f15ac0061019e0a06000101ab152c035901670cc5006400850f89026400de068701590104015a035400850f01006c00850fa00159010f01ac0059012f0166035901b3106a036c00b31518016c000002b401540000028701f900a90aa8001102010b70031902010b76036900370a7c036100850f0600f900ac014800c900850f0600f900850f06002102850f0600f900f10715000c00850f87011400850f87011c00850f87018901850f10009901a4139403910182159b039101a50fa8000101850f060001018b16ac00f901a3156902010198160100010108083d012902850f1000b900850f10007400850fa0017400b31518019901b116250174000002b401b900850fbf0374006e09ab010a000400db030a000800e40308000c00ed030a001000f20308001400fb0309001800000409001c000504090020000a04080024000f0408002800140408002c001904080030001e040800340023040800380028040e003c002d040e00400036040e00440047040e00480066040e004c0087041200bd00a0041200e100a0041200fd00a00420005b00f7082e000b00ce072e001300d7072e001b00f6072e002300ff072e002b002d082e00330073082e003b0081082e0043009a082e004b00a0082e005300ad0840005b00370b030263000f04230263000f04430263000f04010363000f0420035b00f60d40035b00f60d610363000f0480035b009a0f810363000f04a0035b00e210a10363000f04c10363000f04e10363000f04010463000f04200463000f04210463000f04400463000f04410463000f04610463000f04810463000f04a10463000f04c10463000f04e10463000f04010563000f04210563000f04410563000f04610563000f04810563000f04a10563000f04c10563000f04e10563000f04010663000f04210663000f04410663000f04610663000f04810663000f04a10663000f04c10663000f04e00663000f04e10663000f04000763000f04010763000f04200763000f04210763000f04400763000f04410763000f04600763000f04610763000f04800763000f04810763000f04a00763000f04a10763000f04c00763000f04c10763000f04e10763000f04000863000f04010863000f04200863000f04210863000f04400863000f04410863000f04600863000f04610863000f04800863000f04a00863000f04c00863000f04e00863000f04000963000f04200963000f04400963000f04600963000f04800963000f04a00963000f04c00963000f04e00963000f04000a63000f04200a63000f04400a63000f04600a63000f04800a63000f04a00a63000f04c00a63000f04e00a63000f04e10a63000f04010b63000f04200b63000f04400b63000f04600b63000f04800b63000f04a00b63000f04c00b63000f04e00b63000f04000c63000f04200c63000f04400c63000f04600c63000f04800c63000f04a00c63000f04c00c63000f04e00c63000f04000d63000f04200d63000f04400d63000f04c00d63000f04e00d63000f04000e63000f04200e63000f04400e63000f04600e63000f04800e63000f04a00e63000f04c00e63000f04e00e63000f04000f63000f04200f63000f04400f63000f04600f63000f04800f63000f04a00f63000f04c00f63000f04e00f63000f04001063000f04201063000f04401063000f04601063000f04801063000f04a01063000f04c01063000f04e01063000f04001163000f04201163000f04401163000f04601163000f04001263000f04201263000f04401363000f04601363000f04801363000f04a01363000f041a0025002e007c009700ca002b01450160018d01db01e60129022e024d02550259026f0275028f029402b602310388038f03a103a503c70303000100040002000500080006000c000700190008002200090031000f0032000000df0a8f070000470a8f070000b00193070000530b93070000050893070000df0a8f070000530d8f070000a2148f0700002c10970700007b148f070000c7098f070000980b9707000051079b0700004d119f07000038148f070000220697070000271297070000f800a4070000e8108f07000012118f0700008613a80700007b148f07000004148f0700003e1693070000ab0eb1070000af069b07000051079b070000e810b90700001211b90700002206b1070000f800b10700004602c1070000d9019f070000ab0eb1070000af069b070000980bb107000051079b0700003e16c1070000e810b90700001211b90700002206b1070000f800b10700004602c10700007c02c10700004015b10700007806c107000048139b0700008613a8070000ab0e970700009410c9070000a6118f0702002100030001002200030002002900050002002a00070002002b00090002002c000b0002002d000d0002002e000f0001002f000f0002003700110001003800110002003900130001003a00130002003b00150001003c00150002003d00170001003e001700020040001900010041001900020042001b00010043001b00020044001d00010045001d00020046001f00010047001f0002004800210001004900210002004a00230001004b00230002004c00250001004d00250002004e00270001004f002700020050002900010051002900020052002b00010053002b00020054002d00010055002d00020056002f00010057002f0002005800310002005900330001005a00330002005b00350001005c00350002005d00370001005e00370002005f003900010060003900020061003b00010062003b00020063003d00010064003d00020065003f00010066003f0002006700410001006800410002006900430001006a00430002006e00450001006f004500020070004700010071004700020072004900010073004900020074004b00010075004b00020076004d00010077004d00020078004f00010079004f0002007a00510001007b00510002007c00530001007d00530002007e00550001007f005500020080005700010081005700020082005900010083005900020084005b00010085005b00020086005d00010087005d00020088005f00010089005f0002008a00610001008b00610002009000630001009100630002009a00650001009b00650002009c00670001009d0067004200590068009000fa00020110017f018102f8020a0353035e03b603048000000100040000000000000000000000f5150000040000000000000000000000d203840100000000040000000000000000000000d2036a0100000000040000000000000000000000d203ab0c00000000030002000400020005000200060002000700020008000200090002000a0002000b0002000c0002000d0002000e0002000f0002001000020011000200120002006100f5000000003c3e635f5f446973706c6179436c61737336335f30003c3e635f5f446973706c6179436c61737335355f30003c3e635f5f446973706c6179436c61737335365f30003c52656164577269746572456e74726965733e625f5f30003c456e636f64655772697465724e616d655374617475733e625f5f30003c437265617465577269746572417263686976655374617475733e625f5f300046756e636031004e756c6c61626c65603100416374696f6e60310049436f6c6c656374696f6e60310049457175616c697479436f6d7061726572603100494c6973746031006765745f4372633332007365745f437263333200436f6d707574654372633332006372633332005265616455496e7433320052656164496e7433320053716c496e7433320044696374696f6e6172796032005265616455496e7436340053716c496e743634005265616455496e743136006765745f55544638003c4d6f64756c653e0053797374656d2e494f0053797374656d2e4461746100456e7472794d65746164617461006d73636f726c69620053797374656d2e436f6c6c656374696f6e732e47656e6572696300437263006765745f43616e5265616400526561645061796c6f6164006765745f456e7472795061796c6f6164007365745f456e7472795061796c6f616400656e7472795061796c6f6164007061796c6f616400656f636400416464005061746844726976655175616c696669656400436f6d70726573736564006661696c4966456e63727970746564006765745f4973456e63727970746564007365745f4973456e63727970746564006973456e63727970746564006765745f497345787472616374696f6e537570706f72746564007365745f497345787472616374696f6e537570706f7274656400697345787472616374696f6e537570706f72746564003c43726333323e6b5f5f4261636b696e674669656c64003c456e7472795061796c6f61643e6b5f5f4261636b696e674669656c64003c4973456e637279707465643e6b5f5f4261636b696e674669656c64003c497345787472616374696f6e537570706f727465643e6b5f5f4261636b696e674669656c64003c436f6d7072657373696f6e4d6574686f643e6b5f5f4261636b696e674669656c64003c497350617468536166653e6b5f5f4261636b696e674669656c64003c4572726f724d6573736167653e6b5f5f4261636b696e674669656c64003c456e7472794e616d653e6b5f5f4261636b696e674669656c64003c43656e7472616c4469726563746f727953697a653e6b5f5f4261636b696e674669656c64003c4c656e6774683e6b5f5f4261636b696e674669656c64003c456e7472794f7264696e616c3e6b5f5f4261636b696e674669656c64003c4572726f724e756d6265723e6b5f5f4261636b696e674669656c64003c546f74616c456e74726965733e6b5f5f4261636b696e674669656c64003c506172744e616d65733e6b5f5f4261636b696e674669656c64003c436f6d7072657373656442797465733e6b5f5f4261636b696e674669656c64003c556e636f6d7072657373656442797465733e6b5f5f4261636b696e674669656c64003c456e7472794e616d6542797465733e6b5f5f4261636b696e674669656c64003c4465636c61726564546f74616c42797465733e6b5f5f4261636b696e674669656c64003c47656e6572616c507572706f7365466c6167733e6b5f5f4261636b696e674669656c64003c506174685374617475733e6b5f5f4261636b696e674669656c64003c4c6173744d6f64696669656441743e6b5f5f4261636b696e674669656c64003c4f66667365743e6b5f5f4261636b696e674669656c64003c5061796c6f61644f66667365743e6b5f5f4261636b696e674669656c64003c4c6f63616c4865616465724f66667365743e6b5f5f4261636b696e674669656c64003c43656e7472616c4469726563746f72794f66667365743e6b5f5f4261636b696e674669656c64003c4475706c6963617465436f756e743e6b5f5f4261636b696e674669656c64003c49734469726563746f72793e6b5f5f4261636b696e674669656c640053797374656d446174614163636573734b696e64006765745f436f6d7072657373696f6e4d6574686f64007365745f436f6d7072657373696f6e4d6574686f6400636f6d7072657373696f6e4d6574686f64006d6574686f64005f736f7572636500436f6d7072657373696f6e4d6f6465006765745f49735061746853616665007365745f497350617468536166650069735061746853616665006765745f4d657373616765006765745f4572726f724d657373616765007365745f4572726f724d657373616765006572726f724d657373616765006d657373616765005265717569726552616e676500496e766f6b65004275696c644372635461626c650049456e756d657261626c650049446973706f7361626c6500456e636f64655772697465724e616d65006765745f456e7472794e616d65007365745f456e7472794e616d6500726571756573746564456e7472794e616d65004465636f6465456e7472794e616d6500656e7472794e616d65006e616d6500436f6e76657274446f734461746554696d6500646f7354696d65004f6e65006d6178456e76656c6f706500656e76656c6f7065004661696c757265004c6f63616c4865616465725369676e61747572650043656e7472616c4865616465725369676e617475726500456e644f6643656e7472616c4469726563746f72795369676e617475726500446973706f736500646f7344617465006765745f43616e577269746500436f6d70696c657247656e6572617465644174747269627574650044656275676761626c6541747472696275746500436f6d56697369626c6541747472696275746500417373656d626c795469746c65417474726962757465005461726765744672616d65776f726b41747472696275746500417373656d626c7946696c6556657273696f6e4174747269627574650053716c46756e6374696f6e41747472696275746500417373656d626c794465736372697074696f6e41747472696275746500436f6d70696c6174696f6e52656c61786174696f6e7341747472696275746500417373656d626c7950726f6475637441747472696275746500417373656d626c79436f6d70616e794174747269627574650052756e74696d65436f6d7061746962696c69747941747472696275746500506174684162736f6c75746500577269746542797465006765745f56616c7565006765745f48617356616c75650054727947657456616c75650076616c7565007a6970417263686976650043726561746557726974657241726368697665006d617841726368697665006765745f43656e7472616c4469726563746f727953697a65007365745f43656e7472616c4469726563746f727953697a650063656e7472616c4469726563746f727953697a6500496e6465784f660055746638466c6167005374726f6e67456e6372797074696f6e466c6167004461746144657363726970746f72466c61670055544638456e636f64696e6700476574456e636f64696e67006765745f52656d61696e696e67005f72656d61696e696e670053797374656d2e52756e74696d652e56657273696f6e696e670053716c537472696e6700476574537472696e6700646973706f73696e670053746f70776174636800466c757368004d617468006765745f4c656e677468007365745f4c656e677468005061796c6f61644c656e6774680065787065637465644c656e677468005365744c656e677468006c656e67746800456e6473576974680053746172747357697468006765745f457863657074696f6e46616c6c6261636b004465636f64657246616c6c6261636b00456e636f64657246616c6c6261636b00436865636b00577269746572436c6f636b00636c6f636b006765745f43616e5365656b00506174684e6f6e43616e6f6e6963616c0053716c446563696d616c006765745f4f7264696e616c006765745f456e7472794f7264696e616c007365745f456e7472794f7264696e616c00656e7472794f7264696e616c0050617468506172656e7454726176657273616c006d6178546f74616c0042797465417272617973457175616c00436f6d7072657373696f6e4c6576656c00546f6f6c62656c742e417263686976652e5a69704d656d6f72792e646c6c006765745f4e756c6c006765745f49734e756c6c006765745f53747265616d00426f756e6465645265616453747265616d004f70656e426f756e64656453747265616d00436f7079546f5365656b61626c6553747265616d006765745f4261736553747265616d004465666c61746553747265616d004d656d6f727953747265616d005f73747265616d006765745f4974656d007365745f4974656d0053797374656d0053716c426f6f6c65616e006f705f477265617465725468616e006f705f4c6573735468616e004d696e005365656b4f726967696e006f726967696e006f705f4469766973696f6e004172636869766553657373696f6e0053797374656d2e494f2e436f6d7072657373696f6e006f7065726174696f6e00416374696f6e0053797374656d2e5265666c656374696f6e006765745f506f736974696f6e007365745f506f736974696f6e00494f457863657074696f6e00496e76616c696444617461457863657074696f6e004e6f74537570706f72746564457863657074696f6e00417267756d656e744f75744f6652616e6765457863657074696f6e004465636f64657246616c6c6261636b457863657074696f6e00456e636f64657246616c6c6261636b457863657074696f6e00456e644f6653747265616d457863657074696f6e005a697050726f7669646572457863657074696f6e00577269746572457863657074696f6e00417267756d656e74457863657074696f6e004f766572666c6f77457863657074696f6e00537472696e67436f6d70617269736f6e006d6178696d756d526174696f00456e666f726365436f6d7072657373696f6e526174696f006d6178436f6d7072657373696f6e526174696f006d6178526174696f0043686172006765745f4572726f724e756d626572007365745f4572726f724e756d626572006572726f724e756d626572006e756d6265720056616c69646174654c6f63616c48656164657200417263686976655265616465720042696e61727952656164657200726561646572005a6970456e74727950726f766964657200577269746572427566666572006275666665720074696d657200537472696e67436f6d70617265720042696e6172795772697465720049734c6574746572004d6963726f736f66742e53716c5365727665722e536572766572005772697465724572726f7200476574456e756d657261746f72002e63746f72002e6363746f720053797374656d2e446961676e6f7374696373006765745f456c61707365644d696c6c697365636f6e64730053797374656d2e52756e74696d652e496e7465726f7053657276696365730053797374656d2e52756e74696d652e436f6d70696c6572536572766963657300446562756767696e674d6f6465730052656164456e7472696573006765745f546f74616c456e7472696573007365745f546f74616c456e747269657300746f74616c456e74726965730052656164577269746572456e7472696573004c697374456e7472696573004d6178456e7472696573006d6178456e747269657300656e7472696573006765745f506172744e616d6573007365745f506172744e616d65730053797374656d2e446174612e53716c547970657300526561644279746573006765745f436f6d707265737365644279746573007365745f436f6d707265737365644279746573004d6178436f6d707265737365644279746573006765745f556e636f6d707265737365644279746573007365745f556e636f6d70726573736564427974657300756e636f6d707265737365644279746573006765745f456e7472794e616d654279746573007365745f456e7472794e616d65427974657300656e7472794e616d654279746573004d6178417263686976654279746573006d6178417263686976654279746573006765745f4465636c61726564546f74616c4279746573007365745f4465636c61726564546f74616c4279746573006d6178546f74616c42797465730053716c4279746573004765744279746573006d6178506172744279746573004d6178457874726163746564456e7472794279746573006d6178456e7472794279746573006765745f47656e6572616c507572706f7365466c616773007365745f47656e6572616c507572706f7365466c6167730067656e6572616c507572706f7365466c6167730052656c6576616e744c6f63616c466c61677300436f6d7072657373696f6e4f7074696f6e466c61677300666c61677300457175616c7300436f6e7461696e730053797374656d2e436f6c6c656374696f6e73006765745f4368617273004d6178456e7472794e616d65436861726163746572730053756363657373006d61784e616d65556e697473004275696c644475706c6963617465436f756e7473006d6178506172747300456e636f64655772697465724e616d655374617475730043726561746557726974657241726368697665537461747573006765745f50617468537461747573007365745f50617468537461747573004765745061746853746174757300706174685374617475730046696c6c577269746572537461747573006765745f4c6173744d6f6469666965644174007365745f4c6173744d6f6469666965644174006c6173744d6f646966696564417400436f6e6361740045787472616374004f626a656374004370343337537472696374005574663853747269637400627564676574006765745f4f6666736574007365745f4f6666736574006765745f5061796c6f61644f6666736574007365745f5061796c6f61644f6666736574004c6f63616c4f6666736574006765745f4c6f63616c4865616465724f6666736574007365745f4c6f63616c4865616465724f6666736574006c6f63616c4865616465724f6666736574006765745f43656e7472616c4469726563746f72794f6666736574007365745f43656e7472616c4469726563746f72794f66667365740063656e7472616c4469726563746f72794f6666736574006f6666736574006c656674007269676874006f705f496d706c696369740053706c6974006c696d69740050726f7669646572526573756c7400577269746572537461747573526573756c740050726f76696465724c697374526573756c74006765745f43757272656e7400636865636b706f696e74006765745f436f756e74006765745f4475706c6963617465436f756e74007365745f4475706c6963617465436f756e74006475706c6963617465436f756e7400636f756e74005265616450617274004d6f76654e6578740053797374656d2e546578740053746172744e65770046696c6c526f770046696c6c4c697374526f7700726f77004d6178006d617800546f417272617900436f6e7461696e734b657900426c6f636b436f70790053716c42696e617279004c6973745a6970456e747269657346726f6d42696e6172790063617465676f727900546f6f6c62656c742e417263686976652e5a69704d656d6f72790052656164456e644f6643656e7472616c4469726563746f7279006765745f49734469726563746f7279007365745f49734469726563746f72790069734469726563746f72790046696e64456e74727900457874726163745a6970456e74727900577269746572456e747279006d6178456e74727900656e747279006765745f4361706163697479007365745f4361706163697479006f705f457175616c697479006f705f496e657175616c69747900456d70747900000000007b44006500720020006b006f006d007000720069006d006900650072007400650020005a00490050002d005000610079006c006f00610064002000690073007400200075006e006700fc006c0074006900670020006f00640065007200200075006e0076006f006c006c0073007400e4006e006400690067002e00017b450069006e0020005a00490050002d0045006e007400720079002d004e0061006d0065002000760065007200770065006e006400650074002000650069006e006500200075006e006700fc006c00740069006700650020005a00650069006300680065006e006b006f00640069006500720075006e0067002e00017944006500720020005a00490050002d0043006f006e007400610069006e0065007200200065006e00640065007400200069006e006e0065007200680061006c0062002000650069006e00650072002000620065006e00f600740069006700740065006e00200053007400720075006b007400750072002e00017544006500720020005a00490050002d0043006f006e007400610069006e006500720020006b006f006e006e007400650020006e006900630068007400200076006f006c006c0073007400e4006e006400690067002000670065006c006500730065006e002000770065007200640065006e002e00017d44006500720020005a00490050002d0043006f006e007400610069006e00650072002000690073007400200073007400720075006b0074007500720065006c006c00200075006e006700fc006c0074006900670020006f00640065007200200075006e0076006f006c006c0073007400e4006e006400690067002e00017940005a0069007000410072006300680069007600650020006d007500730073002000650069006e0065006e0020006e00690063006800740020006c0065006500720065006e0020005a00490050002d0043006f006e007400610069006e0065007200200065006e007400680061006c00740065006e002e00013b400045006e007400720079004e0061006d00650020006d007500730073002000670065007300650074007a00740020007300650069006e002e000063400045006e007400720079004e0061006d0065002000640061007200660020006800f600630068007300740065006e0073002000310030003200340020005a00650069006300680065006e00200065006e007400680061006c00740065006e002e00016740004d006100780045006e007400720079004200790074006500730020006d0075007300730020007a007700690073006300680065006e0020003100200075006e00640020003600370031003000380038003600340020006c0069006500670065006e002e00006940004d006100780043006f006d007000720065007300730069006f006e0052006100740069006f0020006d00750073007300200067007200f600df006500720020006f00640065007200200067006c0065006900630068002000310020007300650069006e002e00014d40004600610069006c004900660045006e0063007200790070007400650064002000640061007200660020006e00690063006800740020004e0055004c004c0020007300650069006e002e0000809944006500720020005a00490050002d0043006f006e007400610069006e00650072002000fc0062006500720073006300680072006500690074006500740020006400610073002000680061007200740065002000500072006f00760069006400650072006c0069006d0069007400200076006f006e0020003200360038003400330035003400350036002000420079007400650073002e00015b440065007200200061006e006700650066006f0072006400650072007400650020005a00490050002d0045006e00740072007900200069007300740020007600650072007300630068006c00fc007300730065006c0074002e0001809b44006900650020005a0049005000200043006f006d007000720065007300730069006f006e0020004d006500740068006f0064002000770069007200640020006e006900630068007400200075006e0074006500720073007400fc0074007a0074002e0020005a0075006c00e40073007300690067002000730069006e00640020006e007500720020003000200075006e006400200038002e00015744006500720020005a00490050002d0045006e007400720079002000fc00620065007200730063006800720065006900740065007400200040004d006100780045006e00740072007900420079007400650073002e000180ab44006500720020006b006f006d007000720069006d006900650072007400650020005a00490050002d0045006e007400720079002000fc0062006500720073006300680072006500690074006500740020006400610073002000680061007200740065002000500072006f00760069006400650072006c0069006d0069007400200076006f006e0020003100330034003200310037003700320038002000420079007400650073002e000180b344006900650020007400610074007300e400630068006c0069006300680020006100750073006700650067006500620065006e00650020005000610079006c006f00610064002d004c00e4006e006700650020007300740069006d006d00740020006e00690063006800740020006d00690074002000640065006d002000430065006e007400720061006c0020004400690072006500630074006f00720079002000fc00620065007200650069006e002e000180854400690065002000430052004300330032002d0050007200fc00660075006e00670020006400650073002000640065006b006f006d007000720069006d00690065007200740065006e0020005000610079006c006f00610064007300200069007300740020006600650068006c00670065007300630068006c006100670065006e002e00015b40004d006100780045006e007400720069006500730020006d0075007300730020007a007700690073006300680065006e0020003100200075006e00640020003100300030003000300020006c0069006500670065006e002e00006b44006100730020005a0049005000200065006e0074006800e4006c00740020006d00650068007200200045006e0074007200690065007300200061006c007300200040004d006100780045006e007400720069006500730020007a0075006c00e4007300730074002e0001097300610066006500007144006500720020005a00490050002d0043006f006e007400610069006e00650072002000fc0062006500720073006300680072006500690074006500740020006400610073002000680061007200740065002000500072006f00760069006400650072006c0069006d00690074002e000180974400690065002000670065006c006500730065006e00650020004100720063006800690076006c00e4006e006700650020007300740069006d006d00740020006e00690063006800740020006d006900740020006400650072002000760061007200620069006e0061007200790028006d006100780029002d004c00e4006e00670065002000fc00620065007200650069006e002e00017d440065007200200061006e006700650066006f00720064006500720074006500200045006e007400720079002d004e0061006d0065002000690073007400200069006d0020005a00490050002d0041007200630068006900760020006e0069006300680074002000650069006e006400650075007400690067002e000161440065007200200061006e006700650066006f0072006400650072007400650020005a00490050002d0045006e0074007200790020007700750072006400650020006e006900630068007400200067006500660075006e00640065006e002e0001808f44006100730020005a00490050002d004100720063006800690076002000fc0062006500720073006300680072006500690074006500740020006400610073002000680061007200740065002000500072006f00760069006400650072006c0069006d0069007400200076006f006e00200031003000300030003000200045006e00740072006900650073002e000180bb5a0075007300e40074007a006c0069006300680065002000430065006e007400720061006c002d004400690072006500630074006f00720079002d0044006100740065006e007300e40074007a0065002000770065007200640065006e00200069006e0020006400690065007300650072002000500072006f00760069006400650072002d00560065007200730069006f006e0020006e006900630068007400200075006e0074006500720073007400fc0074007a0074002e00017b450069006e002000430065006e007400720061006c002d004400690072006500630074006f00720079002d004800650061006400650072002000620065007300690074007a0074002000650069006e006500200075006e006700fc006c00740069006700650020005300690067006e0061007400750072002e0001735a00490050003600340020007700690072006400200076006f006e0020006400690065007300650072002000500072006f00760069006400650072002d00560065007200730069006f006e0020006e006900630068007400200075006e0074006500720073007400fc0074007a0074002e0001614d0075006c00740069002d004400690073006b002d005a00490050002d0041007200630068006900760065002000770065007200640065006e0020006e006900630068007400200075006e0074006500720073007400fc0074007a0074002e00018083450069006e00200045006e007400720079002d004e0061006d0065002000fc00620065007200730063006800720065006900740065007400200064006900650020006d006100780069006d0061006c00650020004c00e4006e0067006500200076006f006e002000310030003200340020005a00650069006300680065006e002e00015b4400690065002000430065006e007400720061006c002d004400690072006500630074006f00720079002d0047007200f600df0065002000690073007400200069006e006b006f006e00730069007300740065006e0074002e00011f640072006900760065002d007100750061006c006900660069006500640001116100620073006f006c0075007400650000052e002e0000072e002e002f0000072e002e005c0000092f002e002e002f0000095c002e002e005c0000072f002e002e0000075c002e002e00002170006100720065006e0074002d00740072006100760065007200730061006c0001032e0000052e002f0000052f002e0000035c0000052f002f0000072f002e002f0000075c002e005c0000052f005c0000055c002f0000196e006f006e00630061006e006f006e006900630061006c00006d44006500720020004c006f00630061006c002000460069006c00650020004800650061006400650072002000620065007300690074007a0074002000650069006e006500200075006e006700fc006c00740069006700650020005300690067006e0061007400750072002e000180a7470065006e006500720061006c002d0050007500720070006f00730065002d0046006c00610067007300200076006f006e0020004c006f00630061006c002000480065006100640065007200200075006e0064002000430065006e007400720061006c0020004400690072006500630074006f007200790020007300740069006d006d0065006e0020006e0069006300680074002000fc00620065007200650069006e002e0001809f43006f006d007000720065007300730069006f006e0020004d006500740068006f006400200076006f006e0020004c006f00630061006c002000480065006100640065007200200075006e0064002000430065006e007400720061006c0020004400690072006500630074006f007200790020007300740069006d006d00740020006e0069006300680074002000fc00620065007200650069006e002e0001808f45006e007400720079002d004e0061006d006500200076006f006e0020004c006f00630061006c002000480065006100640065007200200075006e0064002000430065006e007400720061006c0020004400690072006500630074006f007200790020007300740069006d006d00740020006e0069006300680074002000fc00620065007200650069006e002e00017344006500720020006b006f006d007000720069006d006900650072007400650020005000610079006c006f00610064002000fc006200650072006c00610070007000740020006400610073002000430065006e007400720061006c0020004400690072006500630074006f00720079002e0001809f4300520043003300320020006f00640065007200200047007200f600df0065006e00200076006f006e0020004c006f00630061006c002000480065006100640065007200200075006e0064002000430065006e007400720061006c0020004400690072006500630074006f007200790020007300740069006d006d0065006e0020006e0069006300680074002000fc00620065007200650069006e002e0001695a00490050002d0045006e007400720079002000fc0062006500720073006300680072006500690074006500740020006400690065002000660065007300740065002000450078007400720061006b00740069006f006e0073006700720065006e007a0065002e0001809b530074006f007200650064002d0045006e007400720079002000620065007300690074007a007400200075006e007400650072007300630068006900650064006c00690063006800650020006b006f006d007000720069006d0069006500720074006500200075006e006400200075006e006b006f006d007000720069006d0069006500720074006500200047007200f600df0065006e002e00016d44006900650020007400610074007300e400630068006c00690063006800650020005000610079006c006f00610064002000fc00620065007200730063006800720065006900740065007400200040004d006100780045006e00740072007900420079007400650073002e00017344006500720020006b006f006d007000720069006d006900650072007400650020005000610079006c006f0061006400200065006e0074006800e4006c00740020006e00690063006800740020006b006f006e00730075006d00690065007200740065002000420079007400650073002e00017d44006900650020007400610074007300e400630068006c00690063006800650020005a00490050002d0045006e0074007200790067007200f600df0065002000770065006900630068007400200076006f006e0020006400650072002000440065006b006c00610072006100740069006f006e002000610062002e00018097440069006500200043006f006d007000720065007300730069006f006e00200052006100740069006f002000690073007400200077006500670065006e002000650069006e006500720020006b006f006d007000720069006d00690065007200740065006e00200047007200f600df006500200076006f006e0020003000200075006e007a0075006c00e40073007300690067002e00016344006500720020005a00490050002d0045006e007400720079002000fc00620065007200730063006800720065006900740065007400200040004d006100780043006f006d007000720065007300730069006f006e0052006100740069006f002e00017b44006500720020005a00490050002d0043006f006e007400610069006e0065007200200069007300740020007a00750020006b00750072007a0020006600fc0072002000650069006e0065006e0020006700fc006c0074006900670065006e00200045004f00430044002d005200650063006f00720064002e000163430065006e007400720061006c0020004400690072006500630074006f007200790020004f006600660073006500740020006f00640065007200200047007200f600df0065002000690073007400200075006e006700fc006c007400690067002e00016945004f00430044002d005300690067006e006100740075007200200077007500720064006500200069006d0020005a00490050002d0043006f006e007400610069006e006500720020006e006900630068007400200067006500660075006e00640065006e002e00012149004e00560041004c00490044005f0041005200470055004d0045004e005400001949004e00560041004c00490044005f004e0041004d004500001946004f0052004d00410054005f004c0049004d0049005400001d4400550050004c00490043004100540045005f004e0041004d004500001d5200450053004f0055005200430045005f004c0049004d0049005400000f540049004d0045004f005500540000235400520041004e00530050004f00520054005f0049004e00560041004c004900440000695400420058005f005a00490050005f00570052004900540045005f0046004f0052004d00410054005f004c0049004d00490054003a0020004e0075006d0065007200690073006300680065007300200046006f0072006d00610074006c0069006d00690074002e0000715400420058005f005a00490050005f00570052004900540045005f005400520041004e00530050004f00520054005f0049004e00560041004c00490044003a00200045006e00760065006c006f0070006500200075006e0076006f006c006c0073007400e4006e006400690067002e00016744006500720020005a00490050002d00450069006e006700610062006500730074007200650061006d00200069007300740020006e00690063006800740020006c0065007300620061007200200075006e00640020007300650065006b006200610072002e000169450069006e00650020005a00490050002d0053007400720075006b00740075007200200076006500720077006500690073007400200061007500df0065007200680061006c0062002000640065007300200043006f006e007400610069006e006500720073002e0001032f00001d5400420058005f005a00490050005f00570052004900540045005f00003d3a0020005a00490050002d005700720069007400650072002d00560065007200740072006100670020007600650072006c00650074007a0074002e00014355006e006700fc006c007400690067006500200074006500630068006e006900730063006800650020005a00490050002d004700720065006e007a0065006e002e0001235a00490050005f0041005200430048004900560045005f004c0049004d0049005400001d5a00490050005f0050004100520054005f004c0049004d004900540000255a00490050005f004400550050004c00490043004100540045005f00500041005200540000295a00490050005f0055004e0053005500500050004f0052005400450044005f005000410052005400002b5a00490050005f004e004f004e00430041004e004f004e004900430041004c005f005000410052005400002b5a00490050005f0050004100520054005f004f0052005f00530055004d005f004c0049004d004900540000335a00490050005f005300540052005500430054005500520045005f004f0052005f005200450053004f00550052004300450000215a00490050005f0050004100520054005f004d0049005300530049004e00470000255a00490050005f0050004100520054005f0049004e0054004500470052004900540059000068771269f192424b85a334f70ba7c98a00042001010803200001052001011111042001010e0420010102060702121c12240320000e080703122012451224130704121c1511750108151175010a1511750102051511750108032000020306116d04200013000306114d05151175010a03061151042001010a05151175010203061159052001011d0503061171130704122015117501081511750102151175010a06151175011179100707127d128081120c12181d0509121c0320000a03200008052000118095040611809509000202118095118095042000127d23070c127d128081120c12141512808501121815128089020e081d12201245081218020e061001001d1e00040a01122007151280d501121807151280850112180520011300080715128089020e0805200102130006200113011300050002020e0e0907041280811d050a08072003081d050808072003011d050808110706121415128085011218121808081218080003020e0e1180dd1e07140a0a15128091011218080808090909080808080908080a1d050e121807151280910112180520010113000c070415128089020e08080e080500001280e10a200101151280e5011300082002021300101301072002011300130104200103080400010203072002080e1180dd072002020e1180dd042001020e0a07080a0809090908080a12070912101d05127d1280990a1d050a081d0509200301127d1180ed020c0005011280d1081280d108080600011180950a0b00021180951180951180950520010e1d050407020908140708080808080808151175011179151175011179092006010808080808080707041d09090908030701080f070c080a1d0508080a08080809090a0500020a0a0a050703080803060702122c1228040000124907151280a1011249052002011c18040701122c0907050e1d0e080e124904200108030620011d0e1d030520020102020520011d050e33071712341238127d1d050a081280ad1512809101123012381280b10a09151180b501123012300a09081280990a080812301249040000123508200301127d1235020715128091011230092000151180b501130007151180b50112300420010109042001010709200301127d118105020500020808080420001d0521070c1248151280b9010a091512809101123015128089020e02080a08090b1d050e06151280b9010a032000090715128089020e020320000b0520011d050805000012810905000012810d0b000312350812810912810d0607031d05080804070208080600030e0e0e0e0500001280c90307010a10070512141512808501121808121812240815128089020e1218072002010e1280c50a070412181d051d05122408b77a5c561934e0890800000010000000000800000008000000000410270000080000000400000000040004000004504b030404504b010204504b050604010000000406000000040800000004400000000400080000044f080000087300610066006500106100620073006f006c007500740065001e640072006900760065002d007100750061006c00690066006900650064002070006100720065006e0074002d00740072006100760065007200730061006c00186e006f006e00630061006e006f006e006900630061006c00040000000002060a02060802060902060e0306123503061d090306127d03061d050706151175011179060615117501080606151175010a060615117501020306124904061280c9030612340306120c090615128089020e1218040612808d03061d0e0e000512451249114d11511155115908000212451249116d1f000a011c10116d10114d10114d10115110115110116d10116d101159101171350010011c10116d10114d10116d10114d10115910115110115110116d10116d10115910115910116d10115910114d101511750111790e0005121c1249114d115111551159080002128081127d0a0700021218120c0e10000315128085011218120c121412808d10000115128089020e08151280850112180400010e0e07000201120c12180f00051d05120c12180a11809512808d080003010a0a1180950600020e1d0508080002091d0512808d0a000215117501117908080400001d09070002021d051d05060002081d0508060002091d05080600011214120c05000112280e0b00011245151280a10112490800021245114d116d16000912451249116d116d116d1151115111511151116d0d0004011c10116d10114d1012490800021249114d116d16000912491249116d116d116d1151115111511151116d120006151280910112301280ad08080a0a12340300000106200201127d0a042001080a042001090a0620021d050a08052002010a0a06200212100a0a07200301127d0a0a0720020a0a1180c1072004010a080a0a14200b01080e1d050a0808090a0a1511750111790a082000151175011179092001011511750111790720001511750108082001011511750108072000151175010a08200101151175010a0720001511750102082001011511750102060002121c080e0c0007121c0e0a0a0808021d050600021220080e16000d1220080e020a0a0808020208020e15117501117905200201080e052002010e08062002010a123404200101050420001d0e052001011d0e10200801127d0a0a080a0a11809512808d04200012490328000a03280002032800080328000e0428001d05032800090828001511750111790728001511750108072800151175010a07280015117501020428001d0e0801000800000000001e01000100540216577261704e6f6e457863657074696f6e5468726f7773010801000200000000002d010028546f6f6c62656c742041726368697665205a4950204d656d6f727920434c522050726f7669646572000045010040534146452053514c20434c522070726f766964657220666f7220626f756e64656420696e2d6d656d6f7279205a495020656e7472792065787472616374696f6e00000d0100086765636f6d70617400001801001353514c2053657276657220546f6f6c62656c7400000501000000000c010007312e342e302e3000004901001a2e4e45544672616d65776f726b2c56657273696f6e3d76342e380100540e144672616d65776f726b446973706c61794e616d65122e4e4554204672616d65776f726b20342e38823e010006005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630154020949735072656369736501540e1146696c6c526f774d6574686f644e616d650746696c6c526f77540e0f5461626c65446566696e6974696f6e80c84572726f724e756d62657220696e742c204572726f724d657373616765206e766172636861722834303030292c20456e7472794e616d65206e766172636861722831303234292c20436f6d70726573736564427974657320626967696e742c20556e636f6d70726573736564427974657320626967696e742c20436f6d7072657373696f6e4d6574686f6420696e742c20437263333220696e742c204973456e63727970746564206269742c20456e7472795061796c6f61642076617262696e617279286d61782982bd010006005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630154020949735072656369736501540e1146696c6c526f774d6574686f644e616d650b46696c6c4c697374526f77540e0f5461626c65446566696e6974696f6e81434572726f724e756d62657220696e742c204572726f724d657373616765206e766172636861722834303030292c20456e7472794f7264696e616c20696e742c20456e7472794e616d65206e766172636861722831303234292c2049734469726563746f7279206269742c20436f6d70726573736564427974657320626967696e742c20556e636f6d70726573736564427974657320626967696e742c20436f6d7072657373696f6e4d6574686f6420696e742c20437263333220696e742c204973456e63727970746564206269742c20497345787472616374696f6e537570706f72746564206269742c204475706c6963617465436f756e7420696e742c2049735061746853616665206269742c2050617468537461747573206e76617263686172283332292c204c6173744d6f6469666965644174206461746574696d653228302981a2010004005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d4461746141636365737300000000540e1146696c6c526f774d6574686f644e616d651046696c6c577269746572537461747573540e0f5461626c65446566696e6974696f6e444572726f724e756d62657220696e742c204572726f724d657373616765206e766172636861722834303030292c205061796c6f61642076617262696e617279286d6178298146010004005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e697374696301540209497350726563697365018146010004005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630054020949735072656369736501000000000000000000000000000010000000000000000000000000000000b4b400000000000000000000ceb40000002000000000000000000000000000000000000000000000c0b40000000000000000000000005f436f72446c6c4d61696e006d73636f7265652e646c6c0000000000ff2500200010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100100000001800008000000000000000000000000000000100010000003000008000000000000000000000000000000100000000004800000058c00000fc0300000000000000000000fc0334000000560053005f00560045005200530049004f004e005f0049004e0046004f0000000000bd04effe00000100040001000000000004000100000000003f000000000000000400000002000000000000000000000000000000440000000100560061007200460069006c00650049006e0066006f00000000002400040000005400720061006e0073006c006100740069006f006e00000000000000b0045c030000010053007400720069006e006700460069006c00650049006e0066006f0000003803000001003000300030003000300034006200300000009a004100010043006f006d006d0065006e0074007300000053004100460045002000530051004c00200043004c0052002000700072006f0076006900640065007200200066006f007200200062006f0075006e00640065006400200069006e002d006d0065006d006f007200790020005a0049005000200065006e007400720079002000650078007400720061006300740069006f006e000000000032000900010043006f006d00700061006e0079004e0061006d006500000000006700650063006f006d00700061007400000000007a0029000100460069006c0065004400650073006300720069007000740069006f006e000000000054006f006f006c00620065006c0074002000410072006300680069007600650020005a004900500020004d0065006d006f0072007900200043004c0052002000500072006f007600690064006500720000000000300008000100460069006c006500560065007200730069006f006e000000000031002e0034002e0030002e00300000005e001f00010049006e007400650072006e0061006c004e0061006d006500000054006f006f006c00620065006c0074002e0041007200630068006900760065002e005a00690070004d0065006d006f00720079002e0064006c006c00000000002800020001004c006500670061006c0043006f00700079007200690067006800740000002000000066001f0001004f0072006900670069006e0061006c00460069006c0065006e0061006d006500000054006f006f006c00620065006c0074002e0041007200630068006900760065002e005a00690070004d0065006d006f00720079002e0064006c006c0000000000480014000100500072006f0064007500630074004e0061006d00650000000000530051004c002000530065007200760065007200200054006f006f006c00620065006c0074000000340008000100500072006f006400750063007400560065007200730069006f006e00000031002e0034002e0030002e003000000038000800010041007300730065006d0062006c0079002000560065007200730069006f006e00000031002e0034002e0030002e0030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b000000c000000e03400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
    , @AssemblyHash varbinary(64)
    , @InstalledAssemblyHash varbinary(64);

IF @ProductMajorVersion NOT IN (15, 16, 17)
    THROW 51330, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 51331, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;

IF OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable', N'P') IS NULL
    THROW 51332, N'Die Dependency toolbelt_core.USP_PrepareResultTable fehlt.', 1;
IF NOT EXISTS
   (
       SELECT 1
       FROM sys.extended_properties
       WHERE class = 0
         AND major_id = 0
         AND minor_id = 0
         AND name = @DependencyVersionProperty
   )
    THROW 51332, N'Die Dependency toolbelt.core.result-table ist nicht als Modul registriert.', 1;

DECLARE @DependencyVersion nvarchar(64)=(SELECT TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@DependencyVersionProperty);
IF @DependencyVersion IS NULL OR PARSENAME(@DependencyVersion,4) IS NOT NULL
 OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)) IS NULL OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,3))<1
 OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)) IS NULL OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,2))<0
 OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,1)) IS NULL OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,1))<0
 OR CONVERT(varbinary(128),@DependencyVersion)<>CONVERT(varbinary(128),CONCAT(TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)),N'.',TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)),N'.',TRY_CONVERT(int,PARSENAME(@DependencyVersion,1))))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(128),value))=CONVERT(varbinary(max),N'toolbelt.core.result-table'))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable') AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@DependencyVersion))
 THROW 51332,N'Die ResultTable-Dependency >=1.0.0 besitzt keinen kanonischen übereinstimmenden Vertrag.',2;

IF NOT EXISTS
   (
       SELECT 1
       FROM sys.configurations
       WHERE name = N'clr enabled'
         AND value_in_use = 1
   )
    THROW 51340, N'CLR ist auf dieser Instanz nicht aktiviert. Das Modul ändert keine Instanzoption.', 1;

IF NOT EXISTS
   (
       SELECT 1
       FROM sys.configurations
       WHERE name = N'clr strict security'
         AND value_in_use = 1
   )
    THROW 51342, N'clr strict security muss aktiviert bleiben.', 1;

IF @AssemblyBits IS NULL OR DATALENGTH(@AssemblyBits) < 1024
    THROW 51343, N'AssemblyBits enthält kein plausibles CLR-Release-Binary.', 1;

SET @AssemblyHash = HASHBYTES(N'SHA2_512', @AssemblyBits);

IF @AssemblyHash IS NULL
   OR NOT EXISTS
      (
          SELECT 1
          FROM sys.trusted_assemblies
          WHERE hash = @AssemblyHash
      )
    THROW 51345, N'Der exakte SHA2-512-Hash der CLR-ZIP-Assembly ist auf dieser Instanz nicht freigegeben.', 1;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), value)
FROM sys.extended_properties
WHERE class = 0
  AND major_id = 0
  AND minor_id = 0
  AND name = @VersionProperty;

SELECT @InstalledAssemblyHash = HASHBYTES(N'SHA2_512', af.content)
FROM sys.assemblies AS a
INNER JOIN sys.assembly_files AS af
  ON af.assembly_id = a.assembly_id
 AND af.file_id = 1
WHERE a.name = @AssemblyName;

IF @InstalledVersion IS NOT NULL
   AND @InstalledVersion NOT IN (N'1.0.0', N'1.1.0', N'1.2.0', N'1.3.0', N'1.4.0')
    THROW 51333, N'Die installierte Modulversion ist diesem Deployment nicht bekannt.', 1;

IF @InstalledVersion IS NULL
   AND
   (
       OBJECT_ID(N'toolbelt_archive.USP_ExtractZipEntryFromBinary') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.USP_ListZipEntriesFromBinary') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.TVF_InternalExtractZipEntryClr') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.TVF_InternalListZipEntriesClr') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.USP_CreateZipFromEntries') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterName') IS NOT NULL
       OR OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterArchive') IS NOT NULL
       OR EXISTS
          (
              SELECT 1
              FROM sys.assemblies
              WHERE name = @AssemblyName
          )
   )
    THROW 51334, N'Ein Zielobjekt oder die Assembly stammt nicht aus einem bekannten Toolbelt-Release.', 1;

IF EXISTS(SELECT 1 FROM sys.objects o WHERE o.schema_id=SCHEMA_ID(N'toolbelt_archive')
 AND o.name IN(N'USP_CreateZipFromEntries',N'TVF_InternalZipWriterName',N'TVF_InternalZipWriterArchive')
 AND (@InstalledVersion NOT IN(N'1.3.0',N'1.4.0') OR @InstalledVersion IS NULL OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE e.class=1 AND e.major_id=o.object_id AND e.minor_id=0
 AND e.name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(128),e.value)=N'toolbelt.archive.zip-memory')))
 THROW 51334,N'Ein Writerziel ist nicht als Toolbelt-ZIP-Objekt markiert.',2;

IF SCHEMA_ID(N'toolbelt_archive') IS NULL
   AND HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    THROW 51335, N'In der Installationsdatenbank fehlt CREATE SCHEMA.', 1;
IF SCHEMA_ID(N'toolbelt_archive') IS NOT NULL
   AND HAS_PERMS_BY_NAME(N'toolbelt_archive', N'SCHEMA', N'ALTER') <> 1
    THROW 51335, N'Für toolbelt_archive fehlt ALTER.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE PROCEDURE') <> 1
    THROW 51335, N'In der Installationsdatenbank fehlt CREATE PROCEDURE.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
    THROW 51335, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;

IF EXISTS
   (
       SELECT 1
       FROM sys.assemblies
       WHERE name = @AssemblyName
   )
BEGIN
    IF ISNULL(@InstalledAssemblyHash, 0x) <> @AssemblyHash
       AND HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'ALTER ANY ASSEMBLY') <> 1
        THROW 51335, N'Für die vorhandene CLR-ZIP-Assembly fehlt ALTER ANY ASSEMBLY.', 1;
END
ELSE IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE ASSEMBLY') <> 1
    THROW 51335, N'In der Installationsdatenbank fehlt CREATE ASSEMBLY.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE @LockResult int;
    EXEC @LockResult = sys.sp_getapplock
          @Resource = N'toolbelt.deploy.toolbelt.archive.zip-memory'
        , @LockMode = N'Exclusive'
        , @LockOwner = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
        THROW 51337, N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.', 1;

    IF EXISTS(SELECT 1 FROM sys.objects o WHERE o.schema_id=SCHEMA_ID(N'toolbelt_archive')
     AND o.name IN(N'USP_CreateZipFromEntries',N'TVF_InternalZipWriterName',N'TVF_InternalZipWriterArchive')
     AND (@InstalledVersion NOT IN(N'1.3.0',N'1.4.0') OR @InstalledVersion IS NULL OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE e.class=1 AND e.major_id=o.object_id AND e.minor_id=0
     AND e.name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(128),e.value)=N'toolbelt.archive.zip-memory')))
     THROW 51334,N'Writerziel kollidiert nach Deploymentlock.',3;

    IF SCHEMA_ID(N'toolbelt_archive') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_archive];';

        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.Managed'
            , @value = 1
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_archive';

        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.SchemaCategory'
            , @value = N'archive'
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_archive';
    END;

    DROP FUNCTION IF EXISTS
        [toolbelt_archive].[TVF_InternalExtractZipEntryClr];

    DROP FUNCTION IF EXISTS
        [toolbelt_archive].[TVF_InternalListZipEntriesClr];
    DROP FUNCTION IF EXISTS [toolbelt_archive].[TVF_InternalZipWriterName];
    DROP FUNCTION IF EXISTS [toolbelt_archive].[TVF_InternalZipWriterArchive];

    IF @InstalledAssemblyHash IS NULL
       OR @InstalledAssemblyHash <> @AssemblyHash
    BEGIN
        DECLARE @AssemblyDdl nvarchar(max) =
            CASE
                WHEN EXISTS
                     (
                         SELECT 1
                         FROM sys.assemblies
                         WHERE name = @AssemblyName
                     )
                    THEN N'ALTER ASSEMBLY [Toolbelt_Archive_ZipMemory]'
                ELSE N'CREATE ASSEMBLY [Toolbelt_Archive_ZipMemory]'
            END
            + N' FROM '
            + CONVERT(nvarchar(max), @AssemblyBits, 1)
            + N' WITH PERMISSION_SET = SAFE;';

        EXEC sys.sp_executesql @AssemblyDdl;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/*
 * Interner Providervertrag. Öffentliche Aufrufer verwenden ausschließlich
 * toolbelt_archive.USP_ExtractZipEntryFromBinary.
 */
IF OBJECT_ID(N'toolbelt_archive.TVF_InternalExtractZipEntryClr', N'FT') IS NOT NULL
    DROP FUNCTION [toolbelt_archive].[TVF_InternalExtractZipEntryClr];
GO

CREATE FUNCTION [toolbelt_archive].[TVF_InternalExtractZipEntryClr]
(
      @ZipArchive          varbinary(max)
    , @EntryName           nvarchar(1024)
    , @MaxEntryBytes       bigint
    , @MaxCompressionRatio decimal(9,2)
    , @FailIfEncrypted     bit
)
RETURNS TABLE
(
      ErrorNumber          int
    , ErrorMessage         nvarchar(4000)
    , EntryName            nvarchar(1024)
    , CompressedBytes      bigint
    , UncompressedBytes    bigint
    , CompressionMethod    int
    , Crc32                int
    , IsEncrypted          bit
    , EntryPayload         varbinary(max)
)
AS EXTERNAL NAME
    [Toolbelt_Archive_ZipMemory]
    .[Toolbelt.Archive.ZipMemory.ZipEntryProvider]
    .[ExtractZipEntry];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE FUNCTION [toolbelt_archive].[TVF_InternalListZipEntriesClr]
(
      @ZipArchive varbinary(max)
    , @MaxEntries int
)
RETURNS TABLE
(
      ErrorNumber          int            NULL
    , ErrorMessage         nvarchar(4000) NULL
    , EntryOrdinal         int            NULL
    , EntryName            nvarchar(1024) NULL
    , IsDirectory          bit            NULL
    , CompressedBytes      bigint         NULL
    , UncompressedBytes    bigint         NULL
    , CompressionMethod    int            NULL
    , Crc32                int            NULL
    , IsEncrypted          bit            NULL
    , IsExtractionSupported bit           NULL
    , DuplicateCount       int            NULL
    , IsPathSafe           bit            NULL
    , PathStatus           nvarchar(32)   NULL
    , LastModifiedAt       datetime2(0)   NULL
)
AS EXTERNAL NAME
    [Toolbelt_Archive_ZipMemory]
    .[Toolbelt.Archive.ZipMemory.ZipEntryProvider]
    .[ListZipEntriesFromBinary];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_archive].[USP_ExtractZipEntryFromBinary]
(
      @ZipArchive          varbinary(max) = NULL
    , @EntryName           nvarchar(1024) = NULL
    , @MaxEntryBytes       bigint         = 16777216
    , @MaxCompressionRatio decimal(9,2)   = 200.00
    , @FailIfEncrypted     bit            = 1
    , @ResultTable         sysname        = NULL
    , @KeepData            bit            = 0
    , @Debug               tinyint        = 0
    , @Hilfe               bit            = 0
)
AS
BEGIN
    SET NOCOUNT ON;

    SET @FailIfEncrypted = ISNULL(@FailIfEncrypted, 1);
    SET @KeepData = ISNULL(@KeepData, 0);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    IF @Hilfe = 1
    BEGIN
        DECLARE @Help TABLE
        (
              HelpContractVersion varchar(16)    NOT NULL
            , SchemaName          sysname        NOT NULL
            , ObjectName          sysname        NOT NULL
            , Section             varchar(32)    NOT NULL
            , Ordinal             int            NOT NULL
            , ItemName            sysname        NULL
            , SqlDataType         varchar(256)   NULL
            , IsRequired          bit            NULL
            , IsNullable          bit            NULL
            , DefaultValue        nvarchar(4000) NULL
            , Description         nvarchar(max)  NOT NULL
            , ExampleSql          nvarchar(max)  NULL
        );

        INSERT INTO @Help
        (
              HelpContractVersion
            , SchemaName
            , ObjectName
            , Section
            , Ordinal
            , ItemName
            , SqlDataType
            , IsRequired
            , IsNullable
            , DefaultValue
            , Description
            , ExampleSql
        )
        VALUES
          ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'DESCRIPTION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Extrahiert einen einzelnen benannten ZIP-Entry aus einem varbinary(max)-Archiv im Speicher. Der interne SAFE-CLR-Provider unterstützt ZIP Methods 0 und 8 und prüft die CRC32 des tatsächlichen Payloads.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'PARAMETER', 1
          , N'@ZipArchive', 'varbinary(max)', 1, 0, N'NULL'
          , N'ZIP-Container als In-memory-BLOB. Das harte Providerlimit beträgt 268435456 Bytes.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'PARAMETER', 2
          , N'@EntryName', 'nvarchar(1024)', 1, 0, N'NULL'
          , N'Exakter Entry-Name. Der CLR-Provider vergleicht ordinal und case-sensitive.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'PARAMETER', 3
          , N'@MaxEntryBytes', 'bigint', 0, 1, N'16777216'
          , N'Obere Grenze für die tatsächlich ausgegebene unkomprimierte Entry-Größe.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'PARAMETER', 4
          , N'@MaxCompressionRatio', 'decimal(9,2)', 0, 1, N'200.00'
          , N'Obere Grenze für tatsächliche und deklarierte UncompressedBytes/CompressedBytes.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'PARAMETER', 5
          , N'@FailIfEncrypted', 'bit', 0, 1, N'1'
          , N'1 lehnt verschlüsselte Entries ab. 0 liefert IsEncrypted=1 und keinen Payload.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'PARAMETER', 6
          , N'@ResultTable', 'sysname', 0, 1, N'NULL'
          , N'Optionale bestehende lokale Temp-Tabelle für den USP-ResultTable-Pfad.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'PARAMETER', 7
          , N'@KeepData', 'bit', 0, 1, N'0'
          , N'Gilt nur mit @ResultTable und wird an USP_PrepareResultTable weitergegeben.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'PARAMETER', 8
          , N'@Debug', 'tinyint', 0, 1, N'0'
          , N'Standardisierter USP-Debugparameter.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'PARAMETER', 9
          , N'@Hilfe', 'bit', 0, 1, N'0'
          , N'1 liefert ausschließlich dieses Help-Resultset.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'RESULT_COLUMN', 1
          , N'EntryName', 'nvarchar(1024)', 1, 0, NULL
          , N'Exakter Entry-Name aus dem Central Directory.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'RESULT_COLUMN', 2
          , N'CompressedBytes', 'bigint', 1, 0, NULL
          , N'Komprimierte Entry-Größe laut Central Directory.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'RESULT_COLUMN', 3
          , N'UncompressedBytes', 'bigint', 1, 0, NULL
          , N'Unkomprimierte Entry-Größe, nach erfolgreicher Extraktion gegen die tatsächliche Ausgabe geprüft.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'RESULT_COLUMN', 4
          , N'CompressionMethod', 'int', 1, 0, NULL
          , N'ZIP Compression Method. Unterstützt werden 0 (Stored) und 8 (Deflate).'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'RESULT_COLUMN', 5
          , N'Crc32', 'int', 0, 1, NULL
          , N'CRC32 des tatsächlichen Payloads als SQL-int-Bitmuster. Bei verschlüsseltem Status stammt der Wert aus dem Central Directory.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'RESULT_COLUMN', 6
          , N'IsEncrypted', 'bit', 1, 0, NULL
          , N'1 kennzeichnet einen als verschlüsselt markierten Entry.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'RESULT_COLUMN', 7
          , N'EntryPayload', 'varbinary(max)', 0, 1, NULL
          , N'Dekomprimierter Payload. Bei @FailIfEncrypted=0 und verschlüsseltem Entry ist der Wert NULL.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'ERROR', 1
          , N'51320-51329', NULL, NULL, NULL, NULL
          , N'Parameter-, ZIP-Struktur-, Limit-, Feature-, Integritäts- und Providerfehlerbereich.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'PERMISSION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Erforderlich sind EXECUTE auf diesem Objekt und bei @ResultTable zusätzlich EXECUTE auf toolbelt_core.USP_PrepareResultTable.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'LIMITATION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Nicht unterstützt: ZIP64, Multi-Disk, Verschlüsselungsentschlüsselung, Deflate64, unbekannte Methods und zusätzliche Central-Directory-Datensätze.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'LIMITATION', 2
          , NULL, NULL, NULL, NULL, NULL
          , N'Harte Providerlimits: 268435456 Archivbytes, 134217728 komprimierte Entry-Bytes und 10000 Entries.'
          , NULL )
        , ( '1.0', N'toolbelt_archive', N'USP_ExtractZipEntryFromBinary', 'EXAMPLE', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Extrahiert deflated.txt aus einem synthetischen ZIP-BLOB.'
          , N'DECLARE @ZipArchive varbinary(max) = 0x...;
EXEC toolbelt_archive.USP_ExtractZipEntryFromBinary
      @ZipArchive = @ZipArchive
    , @EntryName = N''deflated.txt'';' );

        SELECT
              HelpContractVersion
            , SchemaName
            , ObjectName
            , Section
            , Ordinal
            , ItemName
            , SqlDataType
            , IsRequired
            , IsNullable
            , DefaultValue
            , Description
            , ExampleSql
        FROM @Help
        ORDER BY
              CASE Section
                  WHEN 'DESCRIPTION' THEN 1
                  WHEN 'PARAMETER' THEN 2
                  WHEN 'RESULT_COLUMN' THEN 3
                  WHEN 'ERROR' THEN 4
                  WHEN 'PERMISSION' THEN 5
                  WHEN 'LIMITATION' THEN 6
                  WHEN 'EXAMPLE' THEN 7
                  ELSE 8
              END
            , Ordinal;

        RETURN 0;
    END;

    IF @ZipArchive IS NULL OR DATALENGTH(@ZipArchive) = 0
        THROW 51320, N'@ZipArchive muss einen nicht leeren ZIP-Container enthalten.', 1;
    IF @EntryName IS NULL OR LEN(@EntryName) = 0
        THROW 51320, N'@EntryName muss gesetzt sein.', 1;
    IF @MaxEntryBytes IS NULL
       OR @MaxEntryBytes <= 0
       OR @MaxEntryBytes > 67108864
        THROW 51320, N'@MaxEntryBytes muss zwischen 1 und 67108864 liegen.', 1;
    IF @MaxCompressionRatio IS NULL OR @MaxCompressionRatio < 1
        THROW 51320, N'@MaxCompressionRatio muss größer oder gleich 1 sein.', 1;

    IF OBJECT_ID(N'toolbelt_archive.TVF_InternalExtractZipEntryClr', N'FT') IS NULL
        THROW 51329, N'Der interne CLR-ZIP-Provider ist nicht installiert.', 1;

    DECLARE @ProviderResult TABLE
    (
          ErrorNumber       int            NULL
        , ErrorMessage      nvarchar(4000) NULL
        , EntryName         nvarchar(1024) NULL
        , CompressedBytes   bigint         NULL
        , UncompressedBytes bigint         NULL
        , CompressionMethod int            NULL
        , Crc32             int            NULL
        , IsEncrypted       bit            NULL
        , EntryPayload      varbinary(max) NULL
    );

    INSERT INTO @ProviderResult
    (
          ErrorNumber
        , ErrorMessage
        , EntryName
        , CompressedBytes
        , UncompressedBytes
        , CompressionMethod
        , Crc32
        , IsEncrypted
        , EntryPayload
    )
    SELECT
          ErrorNumber
        , ErrorMessage
        , EntryName
        , CompressedBytes
        , UncompressedBytes
        , CompressionMethod
        , Crc32
        , IsEncrypted
        , EntryPayload
    FROM toolbelt_archive.TVF_InternalExtractZipEntryClr
    (
          @ZipArchive
        , @EntryName
        , @MaxEntryBytes
        , @MaxCompressionRatio
        , @FailIfEncrypted
    );

    IF (SELECT COUNT_BIG(*) FROM @ProviderResult) <> 1
        THROW 51329, N'Der interne CLR-ZIP-Provider lieferte keinen eindeutigen Status.', 1;

    DECLARE
          @ProviderErrorNumber int
        , @ProviderErrorMessage nvarchar(2048);

    SELECT
          @ProviderErrorNumber = ErrorNumber
        , @ProviderErrorMessage =
              CONVERT(nvarchar(2048), LEFT(ErrorMessage, 2048))
    FROM @ProviderResult;

    IF @ProviderErrorNumber IS NOT NULL
    BEGIN
        IF @ProviderErrorNumber NOT BETWEEN 51320 AND 51329
            THROW 51329, N'Der interne CLR-ZIP-Provider lieferte einen ungültigen Fehlercode.', 1;

        SET @ProviderErrorMessage =
            COALESCE(NULLIF(@ProviderErrorMessage, N''), N'Der CLR-ZIP-Provider hat den Vorgang abgebrochen.');

        THROW @ProviderErrorNumber, @ProviderErrorMessage, 1;
    END;

    CREATE TABLE #tbx_ZipMemory_ResultSource
    (
          EntryName         nvarchar(1024) NOT NULL
        , CompressedBytes   bigint         NOT NULL
        , UncompressedBytes bigint         NOT NULL
        , CompressionMethod int            NOT NULL
        , Crc32             int            NULL
        , IsEncrypted       bit            NOT NULL
        , EntryPayload      varbinary(max) NULL
    );

    INSERT INTO #tbx_ZipMemory_ResultSource
    (
          EntryName
        , CompressedBytes
        , UncompressedBytes
        , CompressionMethod
        , Crc32
        , IsEncrypted
        , EntryPayload
    )
    SELECT
          EntryName
        , CompressedBytes
        , UncompressedBytes
        , CompressionMethod
        , Crc32
        , IsEncrypted
        , EntryPayload
    FROM @ProviderResult;

    IF @ResultTable IS NULL
    BEGIN
        SELECT
              EntryName
            , CompressedBytes
            , UncompressedBytes
            , CompressionMethod
            , Crc32
            , IsEncrypted
            , EntryPayload
        FROM #tbx_ZipMemory_ResultSource;

        RETURN 0;
    END;

    IF OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable', N'P') IS NULL
        THROW 51329, N'Die ResultTable-Dependency toolbelt_core.USP_PrepareResultTable ist nicht installiert.', 1;

    CREATE TABLE #tbx_ZipMemory_ResultShape
    (
          EntryName         nvarchar(1024) NOT NULL
        , CompressedBytes   bigint         NOT NULL
        , UncompressedBytes bigint         NOT NULL
        , CompressionMethod int            NOT NULL
        , Crc32             int            NULL
        , IsEncrypted       bit            NOT NULL
        , EntryPayload      varbinary(max) NULL
    );

    EXEC toolbelt_core.USP_PrepareResultTable
          @ResultTableToAlter = @ResultTable
        , @LikeTable          = N'#tbx_ZipMemory_ResultShape'
        , @KeepData           = @KeepData
        , @Debug              = @Debug;

    DECLARE @InsertSql nvarchar(max) =
        N'INSERT INTO ' + QUOTENAME(@ResultTable) + N'
        (
              EntryName
            , CompressedBytes
            , UncompressedBytes
            , CompressionMethod
            , Crc32
            , IsEncrypted
            , EntryPayload
        )
        SELECT
              EntryName
            , CompressedBytes
            , UncompressedBytes
            , CompressionMethod
            , Crc32
            , IsEncrypted
            , EntryPayload
        FROM #tbx_ZipMemory_ResultSource;';

    EXEC sys.sp_executesql @InsertSql;

    RETURN 0;
END;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_archive].[USP_ListZipEntriesFromBinary]
(
      @ZipArchive  varbinary(max) = NULL
    , @MaxEntries  int            = 10000
    , @ResultTable sysname        = NULL
    , @KeepData    bit            = 0
    , @Debug       tinyint        = 0
    , @Hilfe       bit            = 0
)
AS
BEGIN
    SET NOCOUNT ON;

    SET @KeepData = ISNULL(@KeepData, 0);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    IF @Hilfe = 1
    BEGIN
        DECLARE @Help TABLE
        (
              HelpContractVersion varchar(16)    NOT NULL
            , SchemaName          sysname        NOT NULL
            , ObjectName          sysname        NOT NULL
            , Section             varchar(32)    NOT NULL
            , Ordinal             int            NOT NULL
            , ItemName            sysname        NULL
            , SqlDataType         varchar(256)   NULL
            , IsRequired          bit            NULL
            , IsNullable          bit            NULL
            , DefaultValue        nvarchar(4000) NULL
            , Description         nvarchar(max)  NOT NULL
            , ExampleSql          nvarchar(max)  NULL
        );

        INSERT INTO @Help
        (
              HelpContractVersion, SchemaName, ObjectName, Section, Ordinal
            , ItemName, SqlDataType, IsRequired, IsNullable, DefaultValue
            , Description, ExampleSql
        )
        VALUES
          ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'DESCRIPTION', 1,
           NULL, NULL, NULL, NULL, NULL,
           N'Listet deklarierte Metadaten aller Central-Directory-Entries eines klassischen Single-Disk-ZIP aus varbinary(max), ohne Payloads zu lesen oder zu dekomprimieren.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'PARAMETER', 1,
           N'@ZipArchive', 'varbinary(max)', 1, 0, N'NULL',
           N'Nicht leerer ZIP-Container im Speicher; hartes Limit 268435456 Bytes.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'PARAMETER', 2,
           N'@MaxEntries', 'int', 0, 0, N'10000',
           N'Zulässige Zahl der Entries zwischen 1 und dem harten Limit 10000.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'PARAMETER', 3,
           N'@ResultTable', 'sysname', 0, 1, N'NULL',
           N'Optionale bestehende lokale Temp-Tabelle für den ResultTable-Pfad.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'PARAMETER', 4,
           N'@KeepData', 'bit', 0, 1, N'0',
           N'Gilt nur mit @ResultTable und steuert Replace oder Append.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'PARAMETER', 5,
           N'@Debug', 'tinyint', 0, 1, N'0', N'Standardisierter USP-Debugparameter.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'PARAMETER', 6,
           N'@Hilfe', 'bit', 0, 1, N'0', N'1 liefert ausschließlich dieses Help-Resultset.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 1,
           N'EntryOrdinal', 'int', 1, 0, NULL, N'Einsbasierte Position im Central Directory.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 2,
           N'EntryName', 'nvarchar(1024)', 1, 0, NULL, N'Exakt dekodierter, nicht normalisierter Entry-Name.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 3,
           N'IsDirectory', 'bit', 1, 0, NULL, N'Aus einem abschließenden Schrägstrich abgeleitete Directory-Markierung.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 4,
           N'CompressedBytes', 'bigint', 1, 0, NULL, N'Deklarierte komprimierte Größe.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 5,
           N'UncompressedBytes', 'bigint', 1, 0, NULL, N'Deklarierte unkomprimierte Größe.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 6,
           N'CompressionMethod', 'int', 1, 0, NULL, N'Numerischer ZIP-Methodenwert.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 7,
           N'Crc32', 'int', 1, 0, NULL, N'Deklarierte und beim Listing nicht neu berechnete CRC32.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 8,
           N'IsEncrypted', 'bit', 1, 0, NULL, N'Verschlüsselungsstatus aus den General-Purpose-Flags.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 9,
           N'IsExtractionSupported', 'bit', 1, 0, NULL, N'1 nur für unverschlüsselte Methods 0 und 8.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 10,
           N'DuplicateCount', 'int', 1, 0, NULL, N'Ordinal und case-sensitive gezählte Namensduplikate.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 11,
           N'IsPathSafe', 'bit', 1, 0, NULL, N'1 nur für einen kanonischen relativen Pfad.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 12,
           N'PathStatus', 'varchar(32)', 1, 0, NULL, N'safe, absolute, drive-qualified, parent-traversal oder noncanonical.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'RESULT_COLUMN', 13,
           N'LastModifiedAt', 'datetime2(0)', 0, 1, NULL, N'DOS-Zeit ohne Zeitzonenbehauptung; bei ungültigem Wert NULL.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'ERROR', 1,
           N'51320-51329', NULL, NULL, NULL, NULL,
           N'Parameter-, Struktur-, Limit-, Feature- und Providerfehlerbereich.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'LIMITATION', 1,
           NULL, NULL, NULL, NULL, NULL,
           N'ZIP64 und Multi-Disk werden abgelehnt. Metadaten sind keine Integritätsbestätigung des Payloads.', NULL)
        , ('1.0', N'toolbelt_archive', N'USP_ListZipEntriesFromBinary', 'EXAMPLE', 1,
           NULL, NULL, NULL, NULL, NULL, N'Listet alle Entries eines ZIP-BLOBs.',
           N'EXEC toolbelt_archive.USP_ListZipEntriesFromBinary @ZipArchive = 0x...;');

        SELECT
              HelpContractVersion, SchemaName, ObjectName, Section, Ordinal
            , ItemName, SqlDataType, IsRequired, IsNullable, DefaultValue
            , Description, ExampleSql
        FROM @Help
        ORDER BY
              CASE Section
                  WHEN 'DESCRIPTION' THEN 1
                  WHEN 'PARAMETER' THEN 2
                  WHEN 'RESULT_COLUMN' THEN 3
                  WHEN 'ERROR' THEN 4
                  WHEN 'PERMISSION' THEN 5
                  WHEN 'LIMITATION' THEN 6
                  WHEN 'EXAMPLE' THEN 7
                  ELSE 8
              END
            , Ordinal;

        RETURN 0;
    END;

    IF @ZipArchive IS NULL OR DATALENGTH(@ZipArchive) = 0
        THROW 51320, N'@ZipArchive muss einen nicht leeren ZIP-Container enthalten.', 1;
    IF @MaxEntries IS NULL OR @MaxEntries < 1 OR @MaxEntries > 10000
        THROW 51320, N'@MaxEntries muss zwischen 1 und 10000 liegen.', 1;
    IF OBJECT_ID(N'toolbelt_archive.TVF_InternalListZipEntriesClr', N'FT') IS NULL
        THROW 51329, N'Der interne CLR-ZIP-Metadatenprovider ist nicht installiert.', 1;

    DECLARE @ProviderResult TABLE
    (
          ErrorNumber           int            NULL
        , ErrorMessage          nvarchar(4000) NULL
        , EntryOrdinal          int            NULL
        , EntryName             nvarchar(1024) NULL
        , IsDirectory           bit            NULL
        , CompressedBytes       bigint         NULL
        , UncompressedBytes     bigint         NULL
        , CompressionMethod     int            NULL
        , Crc32                 int            NULL
        , IsEncrypted           bit            NULL
        , IsExtractionSupported bit            NULL
        , DuplicateCount        int            NULL
        , IsPathSafe            bit            NULL
        , PathStatus            nvarchar(32)   NULL
        , LastModifiedAt        datetime2(0)   NULL
    );

    INSERT INTO @ProviderResult
    (
          ErrorNumber, ErrorMessage, EntryOrdinal, EntryName, IsDirectory
        , CompressedBytes, UncompressedBytes, CompressionMethod, Crc32
        , IsEncrypted, IsExtractionSupported, DuplicateCount, IsPathSafe
        , PathStatus, LastModifiedAt
    )
    SELECT
          ErrorNumber, ErrorMessage, EntryOrdinal, EntryName, IsDirectory
        , CompressedBytes, UncompressedBytes, CompressionMethod, Crc32
        , IsEncrypted, IsExtractionSupported, DuplicateCount, IsPathSafe
        , PathStatus, LastModifiedAt
    FROM toolbelt_archive.TVF_InternalListZipEntriesClr(@ZipArchive, @MaxEntries);

    IF EXISTS (SELECT 1 FROM @ProviderResult WHERE ErrorNumber IS NOT NULL)
    BEGIN
        IF (SELECT COUNT_BIG(*) FROM @ProviderResult) <> 1
            THROW 51329, N'Der interne CLR-ZIP-Metadatenprovider lieferte einen inkonsistenten Fehlerstatus.', 1;

        DECLARE
              @ProviderErrorNumber int
            , @ProviderErrorMessage nvarchar(2048);

        SELECT
              @ProviderErrorNumber = ErrorNumber
            , @ProviderErrorMessage = CONVERT(nvarchar(2048), LEFT(ErrorMessage, 2048))
        FROM @ProviderResult;

        IF @ProviderErrorNumber NOT BETWEEN 51320 AND 51329
            THROW 51329, N'Der interne CLR-ZIP-Metadatenprovider lieferte einen ungültigen Fehlercode.', 1;

        SET @ProviderErrorMessage = COALESCE(NULLIF(@ProviderErrorMessage, N''), N'Der CLR-ZIP-Metadatenprovider hat den Vorgang abgebrochen.');
        THROW @ProviderErrorNumber, @ProviderErrorMessage, 1;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM @ProviderResult
           WHERE EntryOrdinal IS NULL
              OR EntryName IS NULL
              OR IsDirectory IS NULL
              OR CompressedBytes IS NULL
              OR UncompressedBytes IS NULL
              OR CompressionMethod IS NULL
              OR Crc32 IS NULL
              OR IsEncrypted IS NULL
              OR IsExtractionSupported IS NULL
              OR DuplicateCount IS NULL
              OR IsPathSafe IS NULL
              OR PathStatus IS NULL
       )
        THROW 51329, N'Der interne CLR-ZIP-Metadatenprovider lieferte eine unvollständige Datenzeile.', 1;

    CREATE TABLE #tbx_ZipList_ResultSource
    (
          EntryOrdinal          int            NOT NULL
        , EntryName             nvarchar(1024) NOT NULL
        , IsDirectory           bit            NOT NULL
        , CompressedBytes       bigint         NOT NULL
        , UncompressedBytes     bigint         NOT NULL
        , CompressionMethod     int            NOT NULL
        , Crc32                 int            NOT NULL
        , IsEncrypted           bit            NOT NULL
        , IsExtractionSupported bit            NOT NULL
        , DuplicateCount        int            NOT NULL
        , IsPathSafe            bit            NOT NULL
        , PathStatus            varchar(32)    NOT NULL
        , LastModifiedAt        datetime2(0)   NULL
    );

    INSERT INTO #tbx_ZipList_ResultSource
    SELECT
          EntryOrdinal, EntryName, IsDirectory, CompressedBytes
        , UncompressedBytes, CompressionMethod, Crc32, IsEncrypted
        , IsExtractionSupported, DuplicateCount, IsPathSafe
        , CONVERT(varchar(32), PathStatus), LastModifiedAt
    FROM @ProviderResult;

    IF @ResultTable IS NULL
    BEGIN
        SELECT
              EntryOrdinal, EntryName, IsDirectory, CompressedBytes
            , UncompressedBytes, CompressionMethod, Crc32, IsEncrypted
            , IsExtractionSupported, DuplicateCount, IsPathSafe, PathStatus
            , LastModifiedAt
        FROM #tbx_ZipList_ResultSource
        ORDER BY EntryOrdinal;
        RETURN 0;
    END;

    IF OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable', N'P') IS NULL
        THROW 51329, N'Die ResultTable-Dependency toolbelt_core.USP_PrepareResultTable ist nicht installiert.', 1;

    CREATE TABLE #tbx_ZipList_ResultShape
    (
          EntryOrdinal          int            NOT NULL
        , EntryName             nvarchar(1024) NOT NULL
        , IsDirectory           bit            NOT NULL
        , CompressedBytes       bigint         NOT NULL
        , UncompressedBytes     bigint         NOT NULL
        , CompressionMethod     int            NOT NULL
        , Crc32                 int            NOT NULL
        , IsEncrypted           bit            NOT NULL
        , IsExtractionSupported bit            NOT NULL
        , DuplicateCount        int            NOT NULL
        , IsPathSafe            bit            NOT NULL
        , PathStatus            varchar(32)    NOT NULL
        , LastModifiedAt        datetime2(0)   NULL
    );

    EXEC toolbelt_core.USP_PrepareResultTable
          @ResultTableToAlter = @ResultTable
        , @LikeTable          = N'#tbx_ZipList_ResultShape'
        , @KeepData           = @KeepData
        , @Debug              = @Debug;

    DECLARE @InsertSql nvarchar(max) =
        N'INSERT INTO ' + QUOTENAME(@ResultTable) + N'
        SELECT
              EntryOrdinal, EntryName, IsDirectory, CompressedBytes
            , UncompressedBytes, CompressionMethod, Crc32, IsEncrypted
            , IsExtractionSupported, DuplicateCount, IsPathSafe, PathStatus
            , LastModifiedAt
        FROM #tbx_ZipList_ResultSource;';

    EXEC sys.sp_executesql @InsertSql;
    RETURN 0;
END;
GO
SET ANSI_NULLS ON;
-- Interne CLR-Status-TVFs, Modul1.3.0; keine öffentliche Fach-API.
-- Zweck: validierter UTF8-Namenstransport und bounded Binary-Envelope→ZIP.
-- DataAccess/SystemDataAccess None; keine Datenabfrage/Datei-I/O/Rechteausweitung.
-- Eine Statuszeile ErrorNumber/ErrorMessage/Payload; USP setzt TSQL-THROW um.
-- Erwartete Fehler51350–51359, unerwartete Enginefehler bleiben Originalfehler.
-- Dependency: Toolbelt_Archive_ZipMemory, Assemblyrelease 1.3.0 (SAFE).
SET QUOTED_IDENTIFIER ON;
GO
-- Name-Binding: strenges UTF-16-Validieren vor UTF-8-Encoding; eine Statuszeile.
CREATE FUNCTION toolbelt_archive.TVF_InternalZipWriterName(@Name nvarchar(max), @MaxUnits int)
RETURNS TABLE(ErrorNumber int, ErrorMessage nvarchar(4000), Payload varbinary(max))
AS EXTERNAL NAME [Toolbelt_Archive_ZipMemory].[Toolbelt.Archive.ZipMemory.ZipEntryProvider].[EncodeWriterNameStatus];
GO
-- Archive-Binding: TBZW-Version-1-Envelope ohne ContextConnection/Dateifallback;
-- vollständiges Stored-/Deflate-ZIP oder erwarteter Statusfehler, nie Teiloutput.
CREATE FUNCTION toolbelt_archive.TVF_InternalZipWriterArchive
(@Envelope varbinary(max), @Method int, @MaxEntries int, @MaxNameUnits int,
 @MaxEntry bigint, @MaxTotal bigint, @MaxArchive bigint, @MaxEnvelope bigint, @Budget int)
RETURNS TABLE(ErrorNumber int, ErrorMessage nvarchar(4000), Payload varbinary(max))
AS EXTERNAL NAME [Toolbelt_Archive_ZipMemory].[Toolbelt.Archive.ZipMemory.ZipEntryProvider].[CreateWriterArchiveStatus];
GO
-- ============================================================================
-- Objekt: toolbelt_archive.USP_CreateZipFromEntries; Typ: Stored Procedure
-- Zweck: Begrenztes In-memory-ZIP aus caller-lokaler Entrytabelle erzeugen.
-- Vertrag: Documentation/USP_CreateZipFromEntries.md; USP_CONTRACT 1.0.
-- Parameter: EntryTable, Stored/Deflate, positive Ressourcenlimits; Standard-
-- Defaults 256 Entries/16 MiB Entry/64 MiB Summe/68 MiB Output und Envelope.
-- Resultset: ArchivePayload, ArchiveBytes, EntryCount, TotalPayloadBytes,
-- CompressionMethod; Dependencies: SAFE-ZIP-CLR, ResultTable >=1.0.0.
-- Rechte: EXECUTE, eigene lokale Temps; keine Rechte-/Trustausweitung.
-- Versionen: SQL Server 2019/2022/2025; Plattformen: Windows/Linux.
-- Fehler: 51350–51359; keine Teilarchive, callerfreundliche Savepoints.
-- Performance: Snapshot/Envelope/Output materialisiert, LOB-.WRITE statt
-- wachsender Variablenkonkatenation; CLR-Budget kooperativ, kein SQL-Timeout.
-- Einschränkungen: kein Datei-I/O/ZIP64/TVP/Encryption; Readerlimits bleiben.
-- ============================================================================
CREATE OR ALTER PROCEDURE toolbelt_archive.USP_CreateZipFromEntries
      @EntryTable sysname = NULL
    , @CompressionMethod varchar(max) = 'Stored'
    , @MaxEntries int = 256
    , @MaxEntryNameCodeUnits int = 1024
    , @MaxEntryBytes bigint = 16777216
    , @MaxTotalPayloadBytes bigint = 67108864
    , @MaxArchiveBytes bigint = 71303168
    , @MaxEnvelopeBytes bigint = 71303168
    , @WriterBudgetMilliseconds int = 30000
    , @ResultTable sysname = NULL
    , @KeepData bit = 0
    , @Debug tinyint = 0
    , @Hilfe bit = 0
AS
BEGIN
    SET NOCOUNT ON;
    SELECT @KeepData=ISNULL(@KeepData,0), @Debug=ISNULL(@Debug,0), @Hilfe=ISNULL(@Hilfe,0);
    IF @Hilfe = 1
    BEGIN
        -- Reiner Helpweg ignoriert fachliche Parameter und Dependencies.
        DECLARE @Help TABLE(HelpContractVersion varchar(16) NOT NULL,SchemaName sysname NOT NULL,ObjectName sysname NOT NULL,Section varchar(32) NOT NULL,Ordinal int NOT NULL,ItemName sysname NULL,SqlDataType varchar(256) NULL,IsRequired bit NULL,IsNullable bit NULL,DefaultValue nvarchar(4000) NULL,Description nvarchar(max) NOT NULL,ExampleSql nvarchar(max) NULL);
        INSERT @Help SELECT CONVERT(varchar(16),'1.0') AS HelpContractVersion,
               CONVERT(sysname,N'toolbelt_archive') AS SchemaName,
               CONVERT(sysname,N'USP_CreateZipFromEntries') AS ObjectName,
               CONVERT(varchar(32),v.Section) AS Section, v.Ordinal,
               CONVERT(sysname,v.ItemName) AS ItemName,
               CONVERT(varchar(256),v.SqlDataType) AS SqlDataType,
               CONVERT(bit,v.IsRequired) AS IsRequired,
               CONVERT(bit,v.IsNullable) AS IsNullable,
               CONVERT(nvarchar(4000),v.DefaultValue) AS DefaultValue,
               CONVERT(nvarchar(max),v.Description) AS Description,
               CONVERT(nvarchar(max),v.ExampleSql) AS ExampleSql
        FROM (VALUES
        ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'Erzeugt ein begrenztes ZIP aus Ordinal int, EntryName nvarchar(max), Payload varbinary(max) einer vorhandenen caller-lokalen Temp-Tabelle.',NULL),
        ('PARAMETER',1,N'@EntryTable','sysname',1,0,N'NULL',N'Vorhandene lokale Temp-Tabelle, kein freies SQL.',NULL),
        ('PARAMETER',2,N'@CompressionMethod','varchar(max)',0,0,N'Stored',N'Exakt Stored oder Deflate; Default Stored.',NULL),
        ('PARAMETER',3,N'@MaxEntries','int',0,0,N'256',N'Positiv, höchstens 1024 Entries.',NULL),
        ('PARAMETER',4,N'@MaxEntryNameCodeUnits','int',0,0,N'1024',N'Positiv, höchstens 2048 UTF-16-Codeeinheiten; Reader bleibt 1024.',NULL),
        ('PARAMETER',5,N'@MaxEntryBytes','bigint',0,0,N'16777216',N'Positiv, höchstens 33554432 Payloadbytes je Entry.',NULL),
        ('PARAMETER',6,N'@MaxTotalPayloadBytes','bigint',0,0,N'67108864',N'Positiv, höchstens 134217728 Payloadbytes insgesamt.',NULL),
        ('PARAMETER',7,N'@MaxArchiveBytes','bigint',0,0,N'71303168',N'Positiv, höchstens 150994944 Outputbytes inklusive ZIP-Header.',NULL),
        ('PARAMETER',8,N'@MaxEnvelopeBytes','bigint',0,0,N'71303168',N'Positiv, höchstens 142606336 Transportbytes inklusive Namen/Framing.',NULL),
        ('PARAMETER',9,N'@WriterBudgetMilliseconds','int',0,0,N'30000',N'1 bis 60000, kooperatives CLR-Budget; keine SQL-End-to-End-Frist.',NULL),
        ('PARAMETER',10,N'@ResultTable','sysname',0,1,N'NULL',N'NULL: SELECT, sonst vorhandene lokale Temp-Tabelle; nicht identisch zum Input.',NULL),
        ('PARAMETER',11,N'@KeepData','bit',0,0,N'0',N'0 Replace; 1 Append nach USP-Vertrag.',NULL),
        ('PARAMETER',12,N'@Debug','tinyint',0,0,N'0',N'Nur Messages ohne Payloads oder Entrynamen.',NULL),
        ('PARAMETER',13,N'@Hilfe','bit',0,0,N'0',N'1: ausschließlich diese Hilfe, keine fachlichen Prüfungen/Mutation.',NULL),
        ('RESULT_COLUMN',1,N'ArchivePayload','varbinary(max)',NULL,0,NULL,N'Vollständig finalisiertes ZIP-Binary.',NULL),
        ('RESULT_COLUMN',2,N'ArchiveBytes','bigint',NULL,0,NULL,N'Tatsächliche Archivgröße in Bytes.',NULL),
        ('RESULT_COLUMN',3,N'EntryCount','int',NULL,0,NULL,N'Anzahl vorhandener Dateien, leere Liste erlaubt.',NULL),
        ('RESULT_COLUMN',4,N'TotalPayloadBytes','bigint',NULL,0,NULL,N'Summe unkomprimierter Payloadbytes.',NULL),
        ('RESULT_COLUMN',5,N'CompressionMethod','int',NULL,0,NULL,N'ZIP-Methode 0 Stored oder 8 Deflate.',NULL),
        ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Synthetischer In-memory-Aufruf.',N'CREATE TABLE #ZipInput(Ordinal int, EntryName nvarchar(max), Payload varbinary(max)); INSERT #ZipInput VALUES(1,N''hello.txt'',0x4869); EXEC toolbelt_archive.USP_CreateZipFromEntries @EntryTable=N''#ZipInput'';'),
        ('ERROR',1,N'51350-51359',NULL,NULL,NULL,NULL,N'TBX_ZIP_WRITE_*; kein Teiloutput; Original-Enginefehler und Callertransaktionszustand erhalten.',NULL)
        ) v(Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql)
        ;
        SELECT * FROM @Help ORDER BY Section,Ordinal;
        RETURN 0;
    END;

    IF @CompressionMethod IS NULL OR
       NOT ((@CompressionMethod COLLATE Latin1_General_100_BIN2 = 'Stored' AND DATALENGTH(@CompressionMethod)=6)
         OR (@CompressionMethod COLLATE Latin1_General_100_BIN2 = 'Deflate' AND DATALENGTH(@CompressionMethod)=7))
       OR @MaxEntries IS NULL OR @MaxEntries NOT BETWEEN 1 AND 1024
       OR @MaxEntryNameCodeUnits IS NULL OR @MaxEntryNameCodeUnits NOT BETWEEN 1 AND 2048
       OR @MaxEntryBytes IS NULL OR @MaxEntryBytes NOT BETWEEN 1 AND 33554432
       OR @MaxTotalPayloadBytes IS NULL OR @MaxTotalPayloadBytes NOT BETWEEN 1 AND 134217728
       OR @MaxArchiveBytes IS NULL OR @MaxArchiveBytes NOT BETWEEN 1 AND 150994944
       OR @MaxEnvelopeBytes IS NULL OR @MaxEnvelopeBytes NOT BETWEEN 1 AND 142606336
       OR @WriterBudgetMilliseconds IS NULL OR @WriterBudgetMilliseconds NOT BETWEEN 1 AND 60000
        THROW 51350,N'TBX_ZIP_WRITE_INVALID_ARGUMENT: Parameter oder Ressourcenlimit ungültig.',1;
    DECLARE @DependencyVersion nvarchar(64)=(SELECT TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version');
    IF OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterName',N'FT') IS NULL
       OR OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterArchive',N'FT') IS NULL
       OR OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P') IS NULL
       OR @DependencyVersion IS NULL
       OR PARSENAME(@DependencyVersion,4) IS NOT NULL
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)) IS NULL
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)) IS NULL
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,1)) IS NULL
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)) < 1
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)) < 0
       OR TRY_CONVERT(int,PARSENAME(@DependencyVersion,1)) < 0
       OR CONVERT(varbinary(128),@DependencyVersion) <> CONVERT(varbinary(128),CONCAT(TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)),N'.',TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)),N'.',TRY_CONVERT(int,PARSENAME(@DependencyVersion,1))))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(128),value))=CONVERT(varbinary(max),N'toolbelt.core.result-table'))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable') AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@DependencyVersion))
        THROW 51357,N'TBX_ZIP_WRITE_DEPENDENCY: ZIP-Writer oder ResultTable >=1.0.0 fehlt.',1;
    IF @EntryTable IS NULL OR LEFT(@EntryTable,1)<>N'#' OR LEFT(@EntryTable,2)=N'##'
       OR LEN(@EntryTable)>116 OR CHARINDEX(N'.',@EntryTable)>0
       OR (@ResultTable IS NOT NULL AND (LEFT(@ResultTable,1)<>N'#' OR LEFT(@ResultTable,2)=N'##' OR LEN(@ResultTable)>116 OR CHARINDEX(N'.',@ResultTable)>0))
        THROW 51351,N'TBX_ZIP_WRITE_INPUT_SCHEMA: Nur vorhandene caller-lokale Temps sind zulässig.',1;
    DECLARE @InputId int=OBJECT_ID(N'tempdb..'+QUOTENAME(@EntryTable),N'U'),
            @OutputId int=CASE WHEN @ResultTable IS NOT NULL THEN OBJECT_ID(N'tempdb..'+QUOTENAME(@ResultTable),N'U') END;
    IF @InputId IS NULL OR (@ResultTable IS NOT NULL AND @OutputId IS NULL) OR @InputId=@OutputId
        THROW 51351,N'TBX_ZIP_WRITE_INPUT_SCHEMA: Temp fehlt oder Input und Output sind identisch.',2;
    IF (SELECT COUNT(*) FROM tempdb.sys.columns WHERE object_id=@InputId AND
          ((name COLLATE Latin1_General_100_BIN2=N'Ordinal' AND system_type_id=56 AND max_length=4)
          OR (name COLLATE Latin1_General_100_BIN2=N'EntryName' AND system_type_id=231 AND max_length=-1)
          OR (name COLLATE Latin1_General_100_BIN2=N'Payload' AND system_type_id=165 AND max_length=-1))
          AND is_computed=0 AND encryption_type IS NULL) <> 3
        THROW 51351,N'TBX_ZIP_WRITE_INPUT_SCHEMA: Erwartet Ordinal int, EntryName nvarchar(max), Payload varbinary(max).',3;
    IF XACT_STATE()=-1 THROW 51350,N'TBX_ZIP_WRITE_INVALID_ARGUMENT: Callertransaktion nicht committable.',2;
    IF LEFT(@EntryTable,15)=N'#tbx_ZipWriter_' OR LEFT(@ResultTable,15)=N'#tbx_ZipWriter_'
        THROW 51351,N'TBX_ZIP_WRITE_INPUT_SCHEMA: Interne Helpernamen sind reserviert.',4;

    -- Keine MARS-/Parallelmutation derselben Caller-Temps während des
    -- synchronen Aufrufs. Eine Lese-Transaktion stabilisiert Preflight/Snapshot.
    DECLARE @OwnTransaction bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,
            @SavepointSet bit=0,
            @Savepoint varchar(32)='tbxZW'+REPLACE(CONVERT(varchar(36),NEWID()),'-',''),
            @Sql nvarchar(max), @Count bigint, @Total bigint, @Invalid bigint,
            @TooLarge bigint, @Duplicate bigint, @Envelope varbinary(max),
            @Archive varbinary(max), @Method int=CASE WHEN @CompressionMethod='Stored' THEN 0 ELSE 8 END;
    BEGIN TRY
        IF @OwnTransaction=1 BEGIN TRANSACTION;
        ELSE BEGIN SAVE TRANSACTION @Savepoint; SET @SavepointSet=1; END;
        SET @Sql=N'SELECT @Count=COUNT_BIG(*), @Total=COALESCE(SUM(CONVERT(bigint,DATALENGTH(Payload))),0),
          @Invalid=COALESCE(SUM(CONVERT(bigint,CASE WHEN Ordinal IS NULL OR Ordinal<1 OR EntryName IS NULL OR Payload IS NULL THEN 1 ELSE 0 END)),0),
          @TooLarge=COALESCE(SUM(CONVERT(bigint,CASE WHEN DATALENGTH(Payload)>@EntryMax OR DATALENGTH(EntryName)>CONVERT(bigint,@NameMax)*2 THEN 1 ELSE 0 END)),0)
          FROM '+QUOTENAME(@EntryTable)+N' WITH(HOLDLOCK);
          SELECT @Duplicate=COUNT_BIG(*) FROM(SELECT Ordinal FROM '+QUOTENAME(@EntryTable)+N' GROUP BY Ordinal HAVING COUNT_BIG(*)>1)d;';
        EXEC sys.sp_executesql @Sql,N'@Count bigint OUTPUT,@Total bigint OUTPUT,@Invalid bigint OUTPUT,@TooLarge bigint OUTPUT,@Duplicate bigint OUTPUT,@EntryMax bigint,@NameMax int',
            @Count OUTPUT,@Total OUTPUT,@Invalid OUTPUT,@TooLarge OUTPUT,@Duplicate OUTPUT,@MaxEntryBytes,@MaxEntryNameCodeUnits;
        IF @Invalid>0 OR @Duplicate>0 THROW 51350,N'TBX_ZIP_WRITE_INVALID_ARGUMENT: NULL, ungültige oder doppelte Ordinals.',3;
        IF @Count>@MaxEntries OR @Total>@MaxTotalPayloadBytes OR @TooLarge>0
            THROW 51354,N'TBX_ZIP_WRITE_RESOURCE_LIMIT: Input überschreitet die Ressourcenlimits.',1;
        CREATE TABLE #tbx_ZipWriter_Snapshot(Ordinal int NOT NULL PRIMARY KEY, EntryName nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL, Payload varbinary(max) NOT NULL, NameBytes varbinary(max) NULL, NameError int NULL);
        SET @Sql=N'INSERT #tbx_ZipWriter_Snapshot(Ordinal,EntryName,Payload) SELECT Ordinal,EntryName,Payload FROM '+QUOTENAME(@EntryTable)+N' WITH(HOLDLOCK);';
        EXEC sys.sp_executesql @Sql;
        -- Encoding wird vor verlustbehafteter UTF8-Konvertierung durch CLR mit
        -- Exceptionfallback validiert; Namensduplikate inklusive Länge/Bytes.
        UPDATE s SET NameBytes=p.Payload,NameError=p.ErrorNumber
        FROM #tbx_ZipWriter_Snapshot s CROSS APPLY toolbelt_archive.TVF_InternalZipWriterName(EntryName COLLATE DATABASE_DEFAULT,@MaxEntryNameCodeUnits) p;
        IF EXISTS(SELECT 1 FROM #tbx_ZipWriter_Snapshot WHERE NameError IS NULL OR NameError<>0 OR NameBytes IS NULL)
            THROW 51352,N'TBX_ZIP_WRITE_INVALID_NAME: Name oder UTF-16 ungültig.',1;
        IF EXISTS(SELECT 1 FROM #tbx_ZipWriter_Snapshot a JOIN #tbx_ZipWriter_Snapshot b ON a.Ordinal<b.Ordinal
            AND DATALENGTH(a.NameBytes)=DATALENGTH(b.NameBytes) AND a.NameBytes=b.NameBytes)
            THROW 51353,N'TBX_ZIP_WRITE_DUPLICATE_NAME: Binär identische Namen.',1;
        DECLARE @EnvelopeSize bigint=12+@Total+@Count*16+(SELECT COALESCE(SUM(CONVERT(bigint,DATALENGTH(NameBytes))),0) FROM #tbx_ZipWriter_Snapshot);
        IF @EnvelopeSize>@MaxEnvelopeBytes THROW 51354,N'TBX_ZIP_WRITE_RESOURCE_LIMIT: Envelope inklusive Namen/Framing zu groß.',2;
        CREATE TABLE #tbx_ZipWriter_Envelope(Value varbinary(max) NOT NULL);
        DECLARE @CountBinary binary(4)=CONVERT(binary(4),CONVERT(int,@Count));
        INSERT #tbx_ZipWriter_Envelope VALUES(0x54425A5701000000+SUBSTRING(@CountBinary,4,1)+SUBSTRING(@CountBinary,3,1)+SUBSTRING(@CountBinary,2,1)+SUBSTRING(@CountBinary,1,1));
        DECLARE @Ordinal int,@Name varbinary(max),@Payload varbinary(max),@Chunk varbinary(max);
        DECLARE EntryCursor CURSOR LOCAL FAST_FORWARD FOR SELECT Ordinal,NameBytes,Payload FROM #tbx_ZipWriter_Snapshot ORDER BY Ordinal;
        OPEN EntryCursor;
        FETCH NEXT FROM EntryCursor INTO @Ordinal,@Name,@Payload;
        WHILE @@FETCH_STATUS=0
        BEGIN
            -- REVERSE(binary) liefert varchar und ist deshalb kein sicherer
            -- Binarytransport. Byteweise SUBSTRING bleibt varbinary.
            DECLARE @OrdinalBinary binary(4)=CONVERT(binary(4),@Ordinal),@NameBinary binary(4)=CONVERT(binary(4),DATALENGTH(@Name)),@PayloadBinary binary(8)=CONVERT(binary(8),CONVERT(bigint,DATALENGTH(@Payload)));
            SET @Chunk=SUBSTRING(@OrdinalBinary,4,1)+SUBSTRING(@OrdinalBinary,3,1)+SUBSTRING(@OrdinalBinary,2,1)+SUBSTRING(@OrdinalBinary,1,1)
              +SUBSTRING(@NameBinary,4,1)+SUBSTRING(@NameBinary,3,1)+SUBSTRING(@NameBinary,2,1)+SUBSTRING(@NameBinary,1,1)
              +SUBSTRING(@PayloadBinary,8,1)+SUBSTRING(@PayloadBinary,7,1)+SUBSTRING(@PayloadBinary,6,1)+SUBSTRING(@PayloadBinary,5,1)
              +SUBSTRING(@PayloadBinary,4,1)+SUBSTRING(@PayloadBinary,3,1)+SUBSTRING(@PayloadBinary,2,1)+SUBSTRING(@PayloadBinary,1,1)+@Name;
            -- .WRITE fügt LOB-Teile an; kein @Envelope=@Envelope+Payload mit
            -- quadratischen Komplettkopien bei vielen Entries.
            UPDATE #tbx_ZipWriter_Envelope SET Value.WRITE(@Chunk,NULL,0);
            UPDATE #tbx_ZipWriter_Envelope SET Value.WRITE(@Payload,NULL,0);
            FETCH NEXT FROM EntryCursor INTO @Ordinal,@Name,@Payload;
        END;
        CLOSE EntryCursor; DEALLOCATE EntryCursor;
        SELECT @Envelope=Value FROM #tbx_ZipWriter_Envelope;
        IF DATALENGTH(@Envelope)<>@EnvelopeSize THROW 51358,N'TBX_ZIP_WRITE_TRANSPORT_INVALID: Envelope-Länge widersprüchlich.',1;
        DECLARE @Provider TABLE(ErrorNumber int,ErrorMessage nvarchar(4000),Payload varbinary(max));
        INSERT @Provider SELECT ErrorNumber,ErrorMessage,Payload
        FROM toolbelt_archive.TVF_InternalZipWriterArchive(@Envelope,@Method,@MaxEntries,@MaxEntryNameCodeUnits,@MaxEntryBytes,@MaxTotalPayloadBytes,@MaxArchiveBytes,@MaxEnvelopeBytes,@WriterBudgetMilliseconds);
        IF (SELECT COUNT(*) FROM @Provider)<>1 THROW 51359,N'TBX_ZIP_WRITE_PROVIDER_FAILURE: Statusrow fehlt oder mehrdeutig.',1;
        DECLARE @ProviderError int,@ProviderMessage nvarchar(4000);
        SELECT @ProviderError=ErrorNumber,@ProviderMessage=ErrorMessage,@Archive=Payload FROM @Provider;
        IF @ProviderError IS NULL OR @ProviderError NOT BETWEEN 0 AND 51359 OR (@ProviderError<>0 AND @ProviderError<51350)
            THROW 51359,N'TBX_ZIP_WRITE_PROVIDER_FAILURE: Fehlerstatus ungültig.',2;
        IF @ProviderError<>0 THROW @ProviderError,@ProviderMessage,1;
        IF @Archive IS NULL THROW 51359,N'TBX_ZIP_WRITE_PROVIDER_FAILURE: Archiv fehlt.',1;
        CREATE TABLE #tbx_ZipWriter_Result(ArchivePayload varbinary(max) NOT NULL,ArchiveBytes bigint NOT NULL,EntryCount int NOT NULL,TotalPayloadBytes bigint NOT NULL,CompressionMethod int NOT NULL);
        INSERT #tbx_ZipWriter_Result VALUES(@Archive,DATALENGTH(@Archive),CONVERT(int,@Count),@Total,@Method);
        IF @ResultTable IS NOT NULL
        BEGIN
            EXEC toolbelt_core.USP_PrepareResultTable @ResultTableToAlter=@ResultTable,@LikeTable=N'#tbx_ZipWriter_Result',@KeepData=@KeepData,@Debug=@Debug;
            SET @Sql=N'INSERT '+QUOTENAME(@ResultTable)+N'(ArchivePayload,ArchiveBytes,EntryCount,TotalPayloadBytes,CompressionMethod) SELECT ArchivePayload,ArchiveBytes,EntryCount,TotalPayloadBytes,CompressionMethod FROM #tbx_ZipWriter_Result;';
            EXEC sys.sp_executesql @Sql;
        END;
        IF @OwnTransaction=1 COMMIT TRANSACTION;
        IF @Debug>0 PRINT N'ZIP-Writer: vollständiges Archiv erfolgreich erzeugt; Inhalte werden nicht ausgegeben.';
        IF @ResultTable IS NULL SELECT ArchivePayload,ArchiveBytes,EntryCount,TotalPayloadBytes,CompressionMethod FROM #tbx_ZipWriter_Result;
        DROP TABLE #tbx_ZipWriter_Result,#tbx_ZipWriter_Envelope,#tbx_ZipWriter_Snapshot;
        RETURN 0;
    END TRY
    BEGIN CATCH
        IF @OwnTransaction=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
        ELSE IF @OwnTransaction=0 AND @SavepointSet=1 AND XACT_STATE()=1 ROLLBACK TRANSACTION @Savepoint;
        -- Lokale statische Temps werden bei Scopeende auch dann entfernt,
        -- wenn ein Caller-Doom-Zustand kein weiteres DDL erlaubt.
        THROW;
    END CATCH;
END;
GO

SET NOCOUNT ON;

BEGIN TRY
    IF @@TRANCOUNT = 0
        THROW 51339, N'Die Deployment-Transaktion ist vorzeitig beendet worden.', 1;

    DECLARE
          @VersionProperty sysname =
              N'Toolbelt.Module.toolbelt.archive.zip-memory.Version'
        , @ModeProperty sysname =
              N'Toolbelt.Module.toolbelt.archive.zip-memory.DeploymentMode';

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0
             AND major_id = 0
             AND minor_id = 0
             AND name = @VersionProperty
       )
        EXEC sys.sp_updateextendedproperty
              @name = @VersionProperty
            , @value = N'1.4.0';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = @VersionProperty
            , @value = N'1.4.0';

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0
             AND major_id = 0
             AND minor_id = 0
             AND name = @ModeProperty
       )
        EXEC sys.sp_updateextendedproperty
              @name = @ModeProperty
            , @value = N'central';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = @ModeProperty
            , @value = N'central';

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           INNER JOIN sys.assemblies AS a
             ON a.assembly_id = ep.major_id
           WHERE ep.class = 5
             AND ep.name = N'Toolbelt.Managed'
             AND a.name = N'Toolbelt_Archive_ZipMemory'
       )
        EXEC sys.sp_updateextendedproperty
              @name = N'Toolbelt.Managed'
            , @value = 1
            , @level0type = N'ASSEMBLY'
            , @level0name = N'Toolbelt_Archive_ZipMemory';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.Managed'
            , @value = 1
            , @level0type = N'ASSEMBLY'
            , @level0name = N'Toolbelt_Archive_ZipMemory';

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           INNER JOIN sys.assemblies AS a
             ON a.assembly_id = ep.major_id
           WHERE ep.class = 5
             AND ep.name = N'Toolbelt.ModuleId'
             AND a.name = N'Toolbelt_Archive_ZipMemory'
       )
        EXEC sys.sp_updateextendedproperty
              @name = N'Toolbelt.ModuleId'
            , @value = N'toolbelt.archive.zip-memory'
            , @level0type = N'ASSEMBLY'
            , @level0name = N'Toolbelt_Archive_ZipMemory';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.ModuleId'
            , @value = N'toolbelt.archive.zip-memory'
            , @level0type = N'ASSEMBLY'
            , @level0name = N'Toolbelt_Archive_ZipMemory';

    DECLARE @ObjectName sysname,@ObjectType varchar(16),@Property sysname,@PropertyValue nvarchar(128);
    DECLARE WriterMarkers CURSOR LOCAL FAST_FORWARD FOR
    SELECT o.name,CASE WHEN o.type='P' THEN 'PROCEDURE' ELSE 'FUNCTION' END,p.Name,p.Value
    FROM sys.objects o CROSS APPLY(VALUES(N'Toolbelt.ModuleId',N'toolbelt.archive.zip-memory'),(N'Toolbelt.ModuleVersion',N'1.4.0'),(N'Toolbelt.Visibility',CASE WHEN o.type='P' THEN N'public' ELSE N'internal' END))p(Name,Value)
    WHERE o.schema_id=SCHEMA_ID(N'toolbelt_archive') AND o.name IN(N'USP_CreateZipFromEntries',N'TVF_InternalZipWriterName',N'TVF_InternalZipWriterArchive');
    OPEN WriterMarkers; FETCH NEXT FROM WriterMarkers INTO @ObjectName,@ObjectType,@Property,@PropertyValue;
    WHILE @@FETCH_STATUS=0 BEGIN
      IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_archive.'+QUOTENAME(@ObjectName)) AND minor_id=0 AND name=@Property)
       EXEC sys.sp_updateextendedproperty @name=@Property,@value=@PropertyValue,@level0type=N'SCHEMA',@level0name=N'toolbelt_archive',@level1type=@ObjectType,@level1name=@ObjectName;
      ELSE EXEC sys.sp_addextendedproperty @name=@Property,@value=@PropertyValue,@level0type=N'SCHEMA',@level0name=N'toolbelt_archive',@level1type=@ObjectType,@level1name=@ObjectName;
      FETCH NEXT FROM WriterMarkers INTO @ObjectName,@ObjectType,@Property,@PropertyValue;
    END; CLOSE WriterMarkers; DEALLOCATE WriterMarkers;
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.archive.zip-memory
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.file.csv-memory
:On Error exit
DECLARE @Install bit=1,@Bits varbinary(max)=0x4d5a90000300000004000000ffff0000b800000000000000400000000000000000000000000000000000000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a2400000000000000504500004c010300824aa1ca0000000000000000e00022200b013000002a000000060000000000003a49000000200000006000000000001000200000000200000400000000000000060000000000000000a000000002000000000000030060850000100000100000000010000010000000000000100000000000000000000000e84800004f000000006000009c03000000000000000000000000000000000000008000000c000000cc4800001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000080000000000000000000000082000004800000000000000000000002e746578740000004029000000200000002a000000020000000000000000000000000000200000602e727372630000009c0300000060000000040000002c0000000000000000000000000000400000402e72656c6f6300000c00000000800000000200000030000000000000000000000000000040000042000000000000000000000000000000001c490000000000004800000002000500402f00008c19000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004e027201000070281500000a02037d010000042a5602281600000a02037d0200000402047d030000042afa7304000006257e1700000a7d0d000004257e1800000a7d0e000004257e1900000a7d0f00000425281a00000a7d110000042502731b00000a7d100000042a1e02281600000a2a32022c07026f1c00000a2a172a5602176a32040203310b2007d8000073010000067a2a13300300fd000000010000110228050000062d0a026f1d00000a176a2e0b2004d8000073010000067a02166a6f1e00000a0a061f222e15061f0d2e10061f0a2e0b062c0806281f00000a2c0b2004d8000073010000067a140b0328050000063a9d000000036f1d00000a176a320e036f1d00000a20800000006a310b2004d8000073010000067a036f2000000a0b160c2b690708930d09062e12091f222e0d091f0d2e08091f0a2e03092d0b2004d8000073010000067a09282100000a2c250817d6078e692e0c070817d693282200000a2d0b2004d8000073010000067a0817d60c2b1309282200000a2c0b2004d8000073010000067a0817d60c08078e693291060773020000062a000000133003002500000002000011052c0604058e692e02162a160a2b10020306d6930506932e02162a0617d60a060432ec172ad21ffe731200000625027d1e00000425037d2000000425047d1a00000425057d1c000004250e047d22000004250e057d240000042a000013300500f700000003000011281a00000a0a027b0c0000043a8c000000027b070000048d1d0000010b027b0b0000042d18027b04000004027b050000040716078e69282300000a2b59160c027b05000004027b06000004d60d027b0500000413042b2907082517d60c027b040000041104939d027b040000041104931f223306110417d61304110417d6130411040932d208078e692e0b7235000070732400000a7a07732500000a0a730400000625027b0a0000042d07725f0000702b057269000070732600000a7d0d00000425027b09000004732700000a7d0e00000425027b08000004731b00000a7d0f00000425067d110000042516731b00000a7d100000042a0013300400fb000000040000110228050000062c48042d08037b030000042d0b200bd8000073010000067a1203fe15060000021203037b030000047d120000041203167d130000041203037b030000048e696a186ad87d14000004092a026f1d00000a20000080006a310b2007d8000073010000067a026f2000000a0a0616068e69037b0300000428080000060b166a0c0613041613052b341104110593130611061f22330908176ad60c170b2b181106037b020000042e0c11061f0d2e0611061f0a3302170b110517581305110511048e6932c41203fe15060000021203067d120000041203077d130000041203186a068e696a08d6072d03162b01186ad6d87d14000004092a00133004009a00000005000011027b1400000403310b7277000070732400000a7a027b14000004186a5bb78d1d0000010a160b027b130000042c0906072517d60b1f229d027b120000040c160d2b29080993130406072517d60b11049d027b130000042c0f11041f22330906072517d60b1f229d0917580d09088e6932d1027b130000042c0906072517d60b1f229d07068e692e0b72b9000070732400000a7a06732500000a2a00001b30060048010000060000110f04282800000a2d1b0f05282900000a2d120f06282800000a2d090f07282800000a2c0b2007d8000073010000067a0f04282a00000a20a08601006a28060000060f05282b00000a6a20000400006a28060000060f06282a00000a2040420f006a28060000060f07282a00000a20000000016a28060000060228050000062d090f02282c00000a2c0b2004d8000073010000067a030528070000060b026f1d00000a0f07282a00000a186a5b310b2007d8000073010000067a026f2000000a0a06070f02282d00000a0f04282a00000a0f05282b00000a0f06282a00000a28090000066f0f00000a0c2b07086f0c00000a26086f0b00000a2df1de0a082c06086f0a00000adcde190d178d050000022516097b010000042803000006a21304de2406070f02282d00000a0f04282a00000a0f05282b00000a0f06282a00000a280e0000062a11042a4134000002000000e900000013000000fc0000000a00000000000000000000000000000008010000080100001900000002000002d21ffe731a00000625027d3000000425037d3200000425047d3400000425057d36000004250e047d38000004250e057d3a0000042a0000001330020042000000070000110274050000020a03067b0d000004810c00000104067b0e000004810d00000105067b0f000004810e0000010e04067b11000004510e05067b10000004810e0000012a00001b30030049000000080000110f03282c00000a2c0b2004d8000073010000067a02030428070000060f03282d00000a280b0000067b14000004732700000a0ade120b16077b01000004da6a732700000a0ade00062a000000011000000000000035350012020000021330030050000000000000000f03282c00000a2d090f04282800000a2c0b7277000070732400000a7a0f04282a00000a20000000016a280600000602030428070000060f03282d00000a280b0000060f04282a00000a280c0000062a6602281600000a02037d1600000402282e00000a7d180000042a26021ffe7d160000042a13300600a204000009000011027b160000040a062c0906173b71030000162a02157d1600000402167d2500000402167d2600000402166a7d2700000402166a7d280000043850040000027b270000040b0207176ad67d2700000402027b190000042c0c027b27000004176afe012b01167d2900000402027b190000042d08027b270000042b09027b27000004176ada7d2a000004027b290000042d19027b2a000004027b1b000004310b2007d8000073010000067a02167d2b000004027b25000004027b1d0000048e692f13027b1d000004027b25000004931f22fe012b01160c027b250000040d16130408395e010000027b25000004130702110717d67d25000004027b250000040d161306027b2500000413052b7f027b1d000004027b25000004931f223356027b2500000417d6027b1d0000048e692f29027b1d000004027b2500000417d6931f223316110417d6130402027b2500000418d67d250000042b33027b25000004130702110717d67d25000004110713051713062b2b110417d61304027b25000004130702110717d67d25000004027b25000004027b1d0000048e693f6effffff11062d0b2005d8000073010000067a027b25000004027b1d0000048e693cd8000000027b1d000004027b2500000493027b1f0000047b020000043bbb000000027b1d000004027b25000004931f0d3ba7000000027b1d000004027b25000004931f0a3b930000002005d8000073010000067a027b1d000004027b25000004931f22330b2005d8000073010000067a027b25000004130702110717d67d25000004110417d61304027b25000004027b1d0000048e692f3c027b1d000004027b2500000493027b1f0000047b020000042e22027b1d000004027b25000004931f0d2e11027b1d000004027b25000004931f0a3380027b250000041305027b2b000004130702110717d67d2b000004027b280000040b0207176ad67d28000004027b2b000004027b21000004300e027b28000004027b23000004310b2007d8000073010000067a021208fe15040000021208027b1d0000047d040000041208097d050000041208110509da7d06000004120811047d070000041208027b2b0000047d080000041208027b2a0000047d090000041208027b290000047d0a0000041208087d0b0000041208027b290000042d20082d1d027b1d00000409110509da027b1f0000047b0300000428080000062b01167d0c00000411087d1700000402177d16000004172a02157d16000004027b25000004027b1d0000048e692f31027b1d000004027b2500000493027b1f0000047b020000043317027b25000004130702110717d67d2500000438e6fcffff027b25000004027b1d0000048e692f51027b1d000004027b25000004931f0d3340027b2500000417d6027b1d0000048e692e13027b1d000004027b2500000417d6931f0a2e0b2005d8000073010000067a02027b2500000418d67d250000042b33027b25000004027b1d0000048e692f23027b1d000004027b25000004931f0a3312027b25000004130702110717d67d25000004027b260000042d0e02027b2b0000047d260000042b19027b26000004027b2b0000042e0b2006d8000073010000067a027b25000004027b1d0000048e693f9dfbffff162a1e027b170000042a1a732f00000a7a32027b170000048c040000022a000013300200730000000a000011027b160000041ffe3318027b18000004282e00000a330b02167d16000004020a2b071673120000060a06027b1e0000047d1d00000406027b200000047d1f00000406027b1a0000047d1900000406027b1c0000047d1b00000406027b220000047d2100000406027b240000047d23000004062a1e0228180000062a6602281600000a02037d2c00000402282e00000a7d2e0000042a0000001b3002002a00000002000011027b2c0000040a061ffd2e040617330a00de0702281d000006dc02147d3b000004021ffe7d2c0000042a0000011000000200110002130007000000001b300700ac0000000b000011027b2c0000040b072c0b07172e6f160add9500000002157d2c00000402027b2f000004027b31000004027b33000004027b35000004027b37000004027b3900000428090000066f0f00000a7d3b000004021ffd7d2c0000042b2b027b3b0000046f0c00000a0c0208280a0000067d2d00000402177d2c000004170ade2d021ffd7d2c000004027b3b0000046f0b00000a2dc802281d00000602147d3b000004160ade0702281b000006dc062a0110000004000000a3a30007000000006e02157d2c000004027b3b0000042c0b027b3b0000046f0a00000a2a1e027b2d0000042a1a732f00000a7a1e027b2d0000042a0013300200730000000c000011027b2c0000041ffe3318027b2e000004282e00000a330b02167d2c000004020a2b0716731a0000060a06027b300000047d2f00000406027b320000047d3100000406027b340000047d3300000406027b360000047d3500000406027b380000047d3700000406027b3a0000047d39000004062a1e0228210000062a0042534a4201000100000000000c00000076342e302e33303331390000000005006c00000034090000237e0000a0090000f808000023537472696e67730000000098120000e4000000235553007c1300001000000023475549440000008c1300000006000023426c6f620000000000000002000001571fa20b0902000000fa01330016000001000000210000000a0000003b00000022000000380000000a0000002f000000010000001c0000000c0000000200000004000000040000000e0000000400000001000000020000000200000000008a030100000000000600cb02d4050600eb02d40506000702a2050f00f405000006002f0233040600ae02330406007c02330406001b02b50506006b04fb030600cb06fb0306007d01fb030a002d0303060a00670003060a00430003060a009c06030606008201fb0306004602d40506000e00d6000600ec01d40506007101fb030600d304890606001c00d60006006501890606006402a2050a0099029e040a003d019e040a0037019e040a000704030606007504fb030600d508fb0306005b04fb0306001e07fb0306004504fb0300000000b8000000000001000100000110001507c40825000100010000011000d206c408290002000200080110002801c4082d000400030000011000d103c40829000d000300080110003e06c4082d0012000500800110008003c40829001500050081011000a506c408290016000d000301100089000000290016001200030110000100000029002c001a002300590111012300bf0414012300120417010300a508170103009908110103005003110103004203110103002c0411010300d1081b0103008b041e01030021011e010300eb031e0103004f0155000300d108590003002c045d000300b9045d0003000d03210103000d031701030021011e01030038061b01538019031b010100db01110101008c08250101000c01110101007f041e0106007a041e010100b9061b010600b4061b010100b00817010600ab0817010100e20629010600dd06290101007106110106006c061101010058061b01060053061b0101004c00110101005b001101010070001b0101007d001b01010094001e010100a1001b010100ab0011010100db01110101008c082d0101000c0111010100b00817010600ab0817010100e20629010600dd062901010097041e01060092041e010100c6061b010600c1061b0101008106110106007c061101010066061b01060061061b0101002a00300150200000000083189c050100010064200000000083189c05380102007a2000000000930087013f010400b9200000000086189c0506000500c120000000009300eb0345010500ce200000000093000f074b010600e420000000009300d50651010800f0210000000091007a035a010a002122000000009300020464010e0058220000000093005e01750114005c23000000009300bc037c0115006424000000009300e601860118000c25000000009600aa018e011a0094260000000091005e01a3012200cc26000000009600c803b00128001c27000000009600a603c4012e008427000000009600b203d1013200e0270000000086189c0501003700fa2700000000e1018f0106003800042800000000e101b60820003800b22c00000000e109d507e0013800ba2c00000000e101ea0606003800c12c00000000e109610830003800d02c00000000e101df04e50138004f2d00000000e1016f0544003800572d0000000086189c0501003800742d00000000e1018f0106003900bc2d00000000e101b60820003900842e000000008100350006003900a02e00000000e1091f0830003900a82e00000000e101ea0606003900af2e00000000e109610830003900b82e00000000e1012b05ee013900372f00000000e1016f054400390000000100600100000100c90400000200260400000100600100000100130300000100130300000200250300000100c90400000200260400000100b008000002009f08000003005a0300000400260400000100b00800000200e206000003007f0400000400b90600000500710600000600580600000100310100000100130300000200e206000003009704000001004a0600000200350600000100bf0800000200c904000003007f04000004001c0400000500b90600000600710600000700580600000800180600000100b00800000200e20600000300970400000400c60600000500810600000600660600000100d903020002004c01020003006f0302000400610302000500130302000600540100000100130300000200c904000003001c0400000400890400000100130300000200c904000003001c0400000400890400000500260600000100db0100000100db0109000a0009005d000900060009005100090055000a0012000a005d000a000e000a0051000a00550009009c05010011009c05060019009c050a0029009c05100031009c05100039009c05100041009c05150089009c051a0099009c050600a100a2010600a900b60820000c0080082b00a90009070600a9008008300014008e053b00b9008e054400c1009c050600c9009c0506001c0080082b0024008e053b0049009c05100051009c0506006100ed0355006900ed0359007100ed035d007900de03610071009c0501007900e7032000790037036e007900f2037200e900c0017700790009037c00e900b0017700e900cc017700f100db088f00f9009c05100079009c059a0061009c05100069009c05a0006900e70320007100e7032000690009036e0071000903cd00e100e7032000e100090320000101f100dd0009019c0506000a00540008012e000b00ff012e00130008022e001b0027022e00230030022e002b0049022e0033008e022e003b009b0220014300a10223014b00f90543014b00f905a0019300c802c0014300900400029300be0420029300be0440028b00f90560028b00f905a0028b00f905c0028b00f905e0028b00f90500038b00f90520038b00f90540038b00f90560038b00f905c0038b00f905e0038b00f90500048b00f90520048b00f90540048b00f905660081008500a500b200bc00d100d600e100ee00f300fa00090001000a00030000002a07f6010000ae07fb0100007007fb010000ae07fb0102001500030002001700050002001e00070002002000090009002600150009002800170009002a00190009002c001b0009002e001d00090030001f000900320021000a00360015000a00380017000a003c0027000a003e001b000a0040001d000a00420029000a00440021002400340049004f00048000000100000000000000000000000000e0080000040000000000000000000000ff00cd0000000000040000000000000000000000ff00c10000000000090007000a00080000000000003c4465636f64653e645f5f310049456e756d657261626c6560310049456e756d657261746f726031003c3e375f5f7772617031003c3e6d5f5f46696e616c6c79310053716c496e743332003c706f736974696f6e3e355f5f32003c77696474683e355f5f330053716c496e743634003c7265636f72643e355f5f34003c63656c6c733e355f5f35003c5363616e3e645f5f35003c6865616465723e355f5f36003c726f773e355f5f37003c636f6c756d6e3e355f5f38003c4d6f64756c653e0053797374656d2e44617461006d73636f726c69620053797374656d2e436f6c6c656374696f6e732e47656e65726963006765745f43757272656e744d616e616765645468726561644964003c3e6c5f5f696e697469616c54687265616449640051756f746564004373764669656c64006669656c640053797374656d446174614163636573734b696e6400726f774b696e64006572726f72436f6465004465636f64650049456e756d657261626c650049446973706f7361626c650056616c756554797065004661696c7572650053797374656d2e49446973706f7361626c652e446973706f736500506172736500497348696768537572726f67617465004973537572726f676174650049734c6f77537572726f67617465003c3e315f5f73746174650051756f746500436f6d70696c657247656e6572617465644174747269627574650044656275676761626c6541747472696275746500436f6d56697369626c6541747472696275746500417373656d626c795469746c65417474726962757465004974657261746f7253746174654d616368696e6541747472696275746500446562756767657248696464656e41747472696275746500417373656d626c7946696c6556657273696f6e4174747269627574650053716c46756e6374696f6e41747472696275746500417373656d626c794465736372697074696f6e41747472696275746500436f6d70696c6174696f6e52656c61786174696f6e734174747269627574650052756e74696d65436f6d7061746962696c697479417474726962757465006765745f56616c75650076616c756500427974654365696c696e67006365696c696e670053716c537472696e67006765745f4c656e677468004465636f6465644c656e677468005261774c656e677468006c656e67746800636f6c756d6e4f7264696e616c00726f774f7264696e616c00457175616c004373764b65726e656c00546f6f6c62656c742e46696c652e4373764d656d6f72792e646c6c004d65617375726543656c6c0051756f746543656c6c00416e616c797a6543656c6c0046696c6c43656c6c0043737643656c6c0063656c6c006765745f4e756c6c006765745f49734e756c6c006765745f4974656d0053797374656d005363616e0053716c426f6f6c65616e004e756c6c546f6b656e006e756c6c546f6b656e00746f6b656e00436f6c756d6e0053797374656d2e5265666c656374696f6e004e6f74537570706f72746564457863657074696f6e00496e76616c69644f7065726174696f6e457863657074696f6e0043686172003c3e335f5f686173486561646572006973486561646572003c3e335f5f686561646572004d6963726f736f66742e53716c5365727665722e536572766572004572726f7200536570617261746f7200736570617261746f720049456e756d657261746f720053797374656d2e436f6c6c656374696f6e732e47656e657269632e49456e756d657261626c653c546f6f6c62656c742e4373762e4373764669656c643e2e476574456e756d657261746f720053797374656d2e436f6c6c656374696f6e732e47656e657269632e49456e756d657261626c653c53797374656d2e4f626a6563743e2e476574456e756d657261746f720053797374656d2e436f6c6c656374696f6e732e49456e756d657261626c652e476574456e756d657261746f72002e63746f720053797374656d2e446961676e6f73746963730053797374656d2e52756e74696d652e496e7465726f7053657276696365730053797374656d2e52756e74696d652e436f6d70696c6572536572766963657300446562756767696e674d6f6465730053797374656d2e446174612e53716c5479706573006d6178496e7075744279746573006d61784f75747075744279746573006d6178427974657300437376416e616c7973697300616e616c79736973003c3e335f5f6d617843656c6c73003c3e335f5f63656c6c73003c3e335f5f6d6178436f6c756d6e73003c3e335f5f636f6c756d6e730053797374656d2e436f6c6c656374696f6e730053716c436861727300437376456e747279506f696e7473003c3e335f5f6d6178526f7773003c3e335f5f726f7773004f626a656374004373764469616c656374003c3e335f5f6469616c6563740053797374656d2e436f6c6c656374696f6e732e49456e756d657261746f722e5265736574004c696d6974004373764661756c7400456e7669726f6e6d656e740053797374656d2e436f6c6c656374696f6e732e47656e657269632e49456e756d657261746f723c546f6f6c62656c742e4373762e4373764669656c643e2e43757272656e740053797374656d2e436f6c6c656374696f6e732e47656e657269632e49456e756d657261746f723c53797374656d2e4f626a6563743e2e43757272656e740053797374656d2e436f6c6c656374696f6e732e49456e756d657261746f722e43757272656e740053797374656d2e436f6c6c656374696f6e732e47656e657269632e49456e756d657261746f723c546f6f6c62656c742e4373762e4373764669656c643e2e6765745f43757272656e740053797374656d2e436f6c6c656374696f6e732e47656e657269632e49456e756d657261746f723c53797374656d2e4f626a6563743e2e6765745f43757272656e740053797374656d2e436f6c6c656374696f6e732e49456e756d657261746f722e6765745f43757272656e74003c3e325f5f63757272656e7400537461727400737461727400496e707574003c3e335f5f696e707574004d6f76654e657874007465787400546f6f6c62656c742e43737600526f7700417272617900436f707900546f6f6c62656c742e46696c652e4373764d656d6f72790000334300530056005f004d0045004d004f00520059005f0042005500530049004e004500530053005f004500520052004f00520000294300530056005f004400450043004f00440045005f0049004e00560041005200490041004e00540000094400410054004100000d48004500410044004500520000414300530056005f00510055004f00540045005f00500052004500560041004c00490044004100540049004f004e005f005200450051005500490052004500440000274300530056005f00510055004f00540045005f0049004e00560041005200490041004e00540000000000d611465c323e1e408af81b991d3d616900042001010803200001052001011111042001010e0420010102052001011241032000020615125901111004200013000320001c06151249011110082000151259011300042000125505151259011c05151249011c030611310306113503061139040000123d070704031d0308030320000a042001030a04000102030420001d0303070108090705123d1d030808080a00050112790812790808052001011d03042001010a0c07071d03020a11181d0308030907051d03081d0308031007051d03120c1512590111101208125d03200008040701121406070211351208030000080c0709080a0208080802081110040701122406070302081110040701122808b77a5c561934e08908000000010000000002060802060303061d0302060a0206020306123d030611100306120c02061c070615125901111006200201031d0305000112140805000102123d050002010a0a080002120c123d123d090004021d0308081d031000061512490111101d03120c020a080a060001121411100900031118123d120c02070002123d11180a140008125d123d123d1171123d11351139113511350c0006125d1d03120c020a080a130006011c10113110113510113910123d1011390c00041135123d123d123d11710e0005123d123d123d123d117111350420001110082000151259011110072000151259011c04280011100328001c0801000800000000001e01000100540216577261704e6f6e457863657074696f6e5468726f77730108010002000000000018010013546f6f6c62656c7420435356204d656d6f727900004401003f42656772656e7a746572204353562d5363616e6e657220756e64206b616e6f6e6973636865205a656c6c666f726d6174696572756e67206f686e6520492f4f00000c010007312e302e302e30000005010000000026010021546f6f6c62656c742e4373762e4373764b65726e656c2b3c5363616e3e645f5f35000081c601000500540e1146696c6c526f774d6574686f644e616d650846696c6c43656c6c54020f497344657465726d696e6973746963015455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d4461746141636365737300000000540e0f5461626c65446566696e6974696f6e5d526f774b696e64206e766172636861722836292c20526f774f7264696e616c20626967696e742c20436f6c756d6e4f7264696e616c20696e742c2056616c7565206e76617263686172286d6178292c204572726f72436f646520696e742d010028546f6f6c62656c742e4373762e437376456e747279506f696e74732b3c4465636f64653e645f5f31000081390100030054020f497344657465726d696e6973746963015455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000004010000000000000000000000000000000000100000000000000000000000000000001049000000000000000000002a4900000020000000000000000000000000000000000000000000001c490000000000000000000000005f436f72446c6c4d61696e006d73636f7265652e646c6c0000000000ff250020001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100100000001800008000000000000000000000000000000100010000003000008000000000000000000000000000000100000000004800000058600000400300000000000000000000400334000000560053005f00560045005200530049004f004e005f0049004e0046004f0000000000bd04effe00000100000001000000000000000100000000003f000000000000000400000002000000000000000000000000000000440000000100560061007200460069006c00650049006e0066006f00000000002400040000005400720061006e0073006c006100740069006f006e00000000000000b004a0020000010053007400720069006e006700460069006c00650049006e0066006f0000007c020000010030003000300030003000340062003000000098004000010043006f006d006d0065006e00740073000000420065006700720065006e007a0074006500720020004300530056002d005300630061006e006e0065007200200075006e00640020006b0061006e006f006e006900730063006800650020005a0065006c006c0066006f0072006d006100740069006500720075006e00670020006f0068006e006500200049002f004f000000500014000100460069006c0065004400650073006300720069007000740069006f006e000000000054006f006f006c00620065006c007400200043005300560020004d0065006d006f00720079000000300008000100460069006c006500560065007200730069006f006e000000000031002e0030002e0030002e003000000058001c00010049006e007400650072006e0061006c004e0061006d006500000054006f006f006c00620065006c0074002e00460069006c0065002e004300730076004d0065006d006f00720079002e0064006c006c0000002800020001004c006500670061006c0043006f00700079007200690067006800740000002000000060001c0001004f0072006900670069006e0061006c00460069006c0065006e0061006d006500000054006f006f006c00620065006c0074002e00460069006c0065002e004300730076004d0065006d006f00720079002e0064006c006c000000340008000100500072006f006400750063007400560065007200730069006f006e00000031002e0030002e0030002e003000000038000800010041007300730065006d0062006c0079002000560065007200730069006f006e00000031002e0030002e0030002e00300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004000000c0000003c3900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000,@Mode nvarchar(max)=N'central',@Confirm bit=0;
-- Gemeinsamer CSV-Lifecycle: read-only Preflight zweimal, dann eigene atomare DDL.
-- Nur Deploy/Uninstall setzen @Install, @Bits, @Mode und @Confirm.
IF @@TRANCOUNT<>0
BEGIN
 RAISERROR(N'TBX_CSV_LIFECYCLE_CALLER_TRANSACTION: Ein eigener Transaktionsscope ist erforderlich.',16,1);
 RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @Module nvarchar(128)=N'toolbelt.file.csv-memory',@Version nvarchar(max),
 @InstalledMode nvarchar(max),@AssemblyId int,@SchemaId int,@SchemaOwner int,
 @Installed bit,@Phase int=0,@OwnTransaction bit=0,@Hash varbinary(64)=HASHBYTES('SHA2_512',@Bits);
DECLARE @Slots TABLE(Name sysname COLLATE DATABASE_DEFAULT PRIMARY KEY,Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL,Method sysname NULL);
INSERT @Slots VALUES(N'USP_ParseCsv','P',NULL),(N'USP_WriteCsv','P',NULL),
 (N'TVF_InternalParseCsv','FT',N'Parse'),(N'SVF_InternalQuoteCsvCell','FS',N'QuoteCell'),(N'SVF_InternalMeasureCsvCell','FS',N'MeasureCell');
DECLARE @Own TABLE(Id int PRIMARY KEY);
-- CLR-Transportsignaturen sind Teil der technischen Releaseidentität.
DECLARE @Parameters TABLE(Name sysname,Ordinal int,ParameterName sysname,TypeId int,Length smallint);
INSERT @Parameters VALUES
 (N'TVF_InternalParseCsv',1,N'@Text',231,-1),(N'TVF_InternalParseCsv',2,N'@Separator',231,4),(N'TVF_InternalParseCsv',3,N'@HasHeader',104,1),(N'TVF_InternalParseCsv',4,N'@NullToken',231,256),
 (N'TVF_InternalParseCsv',5,N'@MaxRows',127,8),(N'TVF_InternalParseCsv',6,N'@MaxColumns',56,4),(N'TVF_InternalParseCsv',7,N'@MaxCells',127,8),(N'TVF_InternalParseCsv',8,N'@MaxInputBytes',127,8),
 (N'SVF_InternalMeasureCsvCell',0,N'',127,8),(N'SVF_InternalMeasureCsvCell',1,N'@Value',231,-1),(N'SVF_InternalMeasureCsvCell',2,N'@Separator',231,4),(N'SVF_InternalMeasureCsvCell',3,N'@NullToken',231,256),(N'SVF_InternalMeasureCsvCell',4,N'@IsHeader',104,1),
 (N'SVF_InternalQuoteCsvCell',0,N'',231,-1),(N'SVF_InternalQuoteCsvCell',1,N'@Value',231,-1),(N'SVF_InternalQuoteCsvCell',2,N'@Separator',231,4),(N'SVF_InternalQuoteCsvCell',3,N'@NullToken',231,256),(N'SVF_InternalQuoteCsvCell',4,N'@IsHeader',104,1),(N'SVF_InternalQuoteCsvCell',5,N'@MaxOutputBytes',127,8);
DECLARE @Columns TABLE(Ordinal int,Name sysname,TypeId int,Length smallint);
INSERT @Columns VALUES(1,N'RowKind',231,12),(2,N'RowOrdinal',127,8),(3,N'ColumnOrdinal',56,4),(4,N'Value',231,-1),(5,N'ErrorCode',56,4);
IF ISNULL(TRY_CONVERT(int,SERVERPROPERTY('ProductMajorVersion')),0) NOT IN(15,16,17)
 THROW 55320,N'CSV benötigt SQL Server 2019, 2022 oder 2025.',1;
IF NOT EXISTS(SELECT 1 FROM sys.databases WHERE database_id=DB_ID() AND compatibility_level IN(150,160,170)
 AND compatibility_level<=CASE TRY_CONVERT(int,SERVERPROPERTY('ProductMajorVersion')) WHEN 15 THEN 150 WHEN 16 THEN 160 WHEN 17 THEN 170 END)
 THROW 55320,N'CSV benötigt einen zur SQL-Version passenden CL150/160/170.',3;
IF @Install=1 AND (@Mode IS NULL OR CONVERT(varbinary(max),@Mode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central')))
 THROW 55320,N'DeploymentMode muss exakt local oder central sein.',2;
IF @Install=1 AND (@Bits IS NULL OR DATALENGTH(@Bits)<1024 OR @Hash IS NULL)
 THROW 55321,N'Vollständiges Releasebinary fehlt.',1;
IF @Install=0 AND (@Confirm IS NULL OR @Confirm NOT IN(0,1))
 THROW 55326,N'ConfirmNoExternalConsumers muss exakt 0 oder 1 sein.',2;
BEGIN TRY
 WHILE @Phase<2
 BEGIN
  IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
   OR ISNULL(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
   THROW 55325,N'Vollständige Sicht auf Lifecyclemetadaten und SQL-Abhängigkeiten fehlt.',1;
  IF @Install=1
  BEGIN
   IF NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr enabled' AND value_in_use=1)
    OR NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr strict security' AND value_in_use=1)
    OR NOT EXISTS(SELECT 1 FROM sys.trusted_assemblies WHERE hash=@Hash)
    THROW 55321,N'CLR, strict security und separat autorisierter exakter Zielhashtrust fehlen.',2;
   DECLARE @DependencyVersion nvarchar(max)=NULL,@DependencyObject int=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P');
   SELECT @DependencyVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
   DECLARE @Major int=TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)),@Minor int=TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)),@Patch int=TRY_CONVERT(int,PARSENAME(@DependencyVersion,1));
   IF @DependencyObject IS NULL OR @Major IS NULL OR @Major<1 OR @Minor IS NULL OR @Minor<0 OR @Patch IS NULL OR @Patch<0
    OR CONVERT(varbinary(max),@DependencyVersion)<>CONVERT(varbinary(max),CONCAT(@Major,N'.',@Minor,N'.',@Patch))
    OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@DependencyObject AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.core.result-table'))
    OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@DependencyObject AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@DependencyVersion))
    THROW 55322,N'Kanonische sameDB-ResultTable-Abhängigkeit >=1.0.0 fehlt.',1;
  END;
  SELECT @Version=NULL,@InstalledMode=NULL,@AssemblyId=NULL,@Installed=0,@SchemaOwner=NULL;
  SELECT @Version=TRY_CONVERT(nvarchar(max),value),@Installed=1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.csv-memory.Version';
  SELECT @InstalledMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.csv-memory.DeploymentMode';
  SELECT @AssemblyId=assembly_id FROM sys.assemblies WHERE name=N'Toolbelt_File_CsvMemory';
  SET @SchemaId=SCHEMA_ID(N'toolbelt_file');
  SELECT @SchemaOwner=principal_id FROM sys.schemas WHERE schema_id=@SchemaId;
  IF @SchemaId IS NOT NULL AND (NOT EXISTS(SELECT 1 FROM sys.schemas WHERE schema_id=@SchemaId AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'toolbelt_file'))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=@SchemaId AND minor_id=0 AND name=N'Toolbelt.Managed' AND TRY_CONVERT(bit,value)=1)
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=@SchemaId AND minor_id=0 AND name=N'Toolbelt.SchemaCategory' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'file')))
   THROW 55324,N'Vorhandenes Schema ist nicht kohärent zugeordnet.',1;
  IF @Installed=1 AND (@Version IS NULL OR CONVERT(varbinary(max),@Version)<>CONVERT(varbinary(max),N'1.0.0') OR @InstalledMode IS NULL OR CONVERT(varbinary(max),@InstalledMode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central')))
   THROW 55324,N'Unbekannter CSV-Release oder inkohärenter Modus.',2;
  IF @Installed=0 AND (EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.csv-memory.DeploymentMode') OR @AssemblyId IS NOT NULL OR EXISTS(SELECT 1 FROM @Slots WHERE OBJECT_ID(N'toolbelt_file.'+QUOTENAME(Name)) IS NOT NULL))
   THROW 55324,N'Fremde Zielslotbelegung oder unvollständiger Modulzustand.',3;
  IF @Installed=1 AND (@AssemblyId IS NULL OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@AssemblyId AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_File_CsvMemory') AND permission_set=1 AND is_user_defined=1 AND principal_id=@SchemaOwner)
   OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@AssemblyId)<>1
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.Managed' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'bit' AND TRY_CONVERT(bit,value)=1)
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Module))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'1.0.0')))
   THROW 55324,N'CSV-Assembly, Eigentümer oder Releasezuordnung ist inkohärent.',4;
  IF @Installed=1 AND EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(s.Name)) WHERE o.object_id IS NULL OR CONVERT(varbinary(max),o.name)<>CONVERT(varbinary(max),s.Name) OR CONVERT(varbinary(max),o.type)<>CONVERT(varbinary(max),s.Kind) OR COALESCE(o.principal_id,@SchemaOwner)<>@SchemaOwner
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.Managed' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'bit' AND TRY_CONVERT(bit,value)=1)
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Module))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'1.0.0'))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.Visibility' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),CASE WHEN s.Kind='P' THEN N'public' ELSE N'internal' END))
   OR(s.Method IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.assembly_modules m WHERE m.object_id=o.object_id AND m.assembly_id=@AssemblyId AND m.null_on_null_input=0 AND m.execute_as_principal_id IS NULL AND CONVERT(varbinary(max),m.assembly_class)=CONVERT(varbinary(max),N'Toolbelt.Csv.CsvEntryPoints') AND CONVERT(varbinary(max),m.assembly_method)=CONVERT(varbinary(max),s.Method))))
   THROW 55324,N'CSV-Slot, Binding, Typ oder Ownershipmarker ist inkohärent.',5;
  IF @Installed=1 AND (EXISTS(SELECT 1 FROM @Parameters e LEFT JOIN sys.parameters p ON p.object_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(e.Name)) AND p.parameter_id=e.Ordinal WHERE p.object_id IS NULL OR CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),e.ParameterName) OR p.system_type_id<>e.TypeId OR p.user_type_id<>p.system_type_id OR p.max_length<>e.Length OR (e.Ordinal>0 AND(p.is_output<>0 OR p.has_default_value<>0)))
   OR EXISTS(SELECT 1 FROM @Slots s WHERE s.Method IS NOT NULL AND (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(s.Name)))<>(SELECT COUNT(*) FROM @Parameters WHERE Name=s.Name))
   OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'toolbelt_file.TVF_InternalParseCsv'))<>5
   OR EXISTS(SELECT 1 FROM @Columns e LEFT JOIN sys.columns c ON c.object_id=OBJECT_ID(N'toolbelt_file.TVF_InternalParseCsv') AND c.column_id=e.Ordinal WHERE c.object_id IS NULL OR CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),e.Name) OR c.system_type_id<>e.TypeId OR c.user_type_id<>c.system_type_id OR c.max_length<>e.Length OR c.is_nullable<>1))
   THROW 55324,N'Interne CLR-Parameter oder nullable Parserfelder sind inkohärent.',7;
  DELETE FROM @Own;
  INSERT @Own SELECT OBJECT_ID(N'toolbelt_file.'+QUOTENAME(Name)) FROM @Slots WHERE @Installed=1;
  IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@AssemblyId AND object_id NOT IN(SELECT Id FROM @Own)) OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@AssemblyId)
   THROW 55325,N'Fremder Assemblyconsumer blockiert CSV-Lifecycle.',2;
  IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d WHERE (d.referenced_id IN(SELECT Id FROM @Own)
   OR(d.referenced_id IS NULL AND (d.referenced_database_name IS NULL OR d.referenced_database_name COLLATE DATABASE_DEFAULT=DB_NAME()) AND d.referenced_schema_name COLLATE DATABASE_DEFAULT=N'toolbelt_file' AND EXISTS(SELECT 1 FROM @Slots WHERE Name COLLATE DATABASE_DEFAULT=d.referenced_entity_name COLLATE DATABASE_DEFAULT))) AND d.referencing_id NOT IN(SELECT Id FROM @Own))
   THROW 55325,N'Fremder SQL-Verbraucher blockiert CSV-Lifecycle.',3;
  IF @Install=0 AND @Installed=0
  BEGIN
   IF @Phase=0 RETURN;
   THROW 55324,N'CSV-Zustand änderte sich während des Preflights.',6;
  END;
  IF @Install=0 AND CONVERT(varbinary(max),@InstalledMode)=CONVERT(varbinary(max),N'central') AND @Confirm<>1
   THROW 55326,N'Zentraler Uninstall benötigt explizite Consumerbestätigung.',1;
  IF @Install=0 AND @Installed=1 AND (ISNULL(HAS_PERMS_BY_NAME(N'toolbelt_file',N'SCHEMA',N'ALTER'),0)<>1 OR ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'ALTER ANY ASSEMBLY'),0)<>1)
   THROW 55327,N'Schema-ALTER/ALTER ANY ASSEMBLY für Uninstall fehlt; keine Rechtevergabe.',7;
  IF @Install=1
  BEGIN
   IF @SchemaId IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE SCHEMA'),0)<>1 THROW 55327,N'CREATE SCHEMA fehlt; keine Rechtevergabe.',1;
   IF @SchemaId IS NOT NULL AND ISNULL(HAS_PERMS_BY_NAME(N'toolbelt_file',N'SCHEMA',N'ALTER'),0)<>1 THROW 55327,N'Schema-ALTER fehlt; keine Rechtevergabe.',2;
   IF @SchemaId IS NOT NULL AND @AssemblyId IS NULL AND @SchemaOwner<>USER_ID() THROW 55327,N'Neue Assembly benötigt denselben effektiven Eigentümer wie das Schema.',3;
   IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE FUNCTION'),0)<>1 OR ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE PROCEDURE'),0)<>1 THROW 55327,N'CREATE FUNCTION/PROCEDURE fehlt; keine Rechtevergabe.',4;
   IF @AssemblyId IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE ASSEMBLY'),0)<>1 THROW 55327,N'CREATE ASSEMBLY fehlt; keine Rechtevergabe.',5;
   IF @AssemblyId IS NOT NULL AND EXISTS(SELECT 1 FROM sys.assembly_files WHERE assembly_id=@AssemblyId AND file_id=1 AND HASHBYTES('SHA2_512',content)<>@Hash) AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'ALTER ANY ASSEMBLY'),0)<>1 THROW 55327,N'ALTER ANY ASSEMBLY fehlt; keine Rechtevergabe.',6;
  END;
  IF @Phase=0
  BEGIN
   BEGIN TRANSACTION;SET @OwnTransaction=1;
   DECLARE @Lock int;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.file.csv-memory',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock<0 THROW 55323,N'Paralleler CSV-Lifecycle aktiv.',1;
  END;
  SET @Phase+=1;
 END;
 IF @Install=1 AND @SchemaId IS NULL
 BEGIN
  EXEC(N'CREATE SCHEMA toolbelt_file');
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_file';
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'file',@level0type=N'SCHEMA',@level0name=N'toolbelt_file';
 END;
 IF @Installed=1
 BEGIN
  DROP PROCEDURE toolbelt_file.USP_ParseCsv;
  DROP PROCEDURE toolbelt_file.USP_WriteCsv;
  DROP FUNCTION toolbelt_file.TVF_InternalParseCsv;
  DROP FUNCTION toolbelt_file.SVF_InternalQuoteCsvCell;
  DROP FUNCTION toolbelt_file.SVF_InternalMeasureCsvCell;
 END;
 IF @Install=1
 BEGIN
  DECLARE @InstalledHash varbinary(64)=(SELECT HASHBYTES('SHA2_512',content) FROM sys.assembly_files WHERE assembly_id=@AssemblyId AND file_id=1);
  IF @InstalledHash IS NULL OR @InstalledHash<>@Hash
  BEGIN
   DECLARE @Ddl nvarchar(max)=CASE WHEN @AssemblyId IS NULL THEN N'CREATE' ELSE N'ALTER' END+N' ASSEMBLY [Toolbelt_File_CsvMemory] FROM '+CONVERT(nvarchar(max),@Bits,1)+N' WITH PERMISSION_SET=SAFE;';
   EXEC sys.sp_executesql @Ddl;
  END;
 END
 ELSE
 BEGIN
  DROP ASSEMBLY Toolbelt_File_CsvMemory;
  EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.file.csv-memory.Version';
  EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.file.csv-memory.DeploymentMode';
  -- Geteiltes Schema/Dependencies und instanzweiter Trust bleiben erhalten.
  COMMIT TRANSACTION;SET @OwnTransaction=0;
 END;
END TRY
BEGIN CATCH
 IF @OwnTransaction=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
-- Interner SAFE-Parsertransport; fünf physisch nullable Unicode-/Statusspalten.
-- Vollständiger Preflight im CLR-Kern; ein isolierter Fachfehlersentinel, unerwartete Fehler original.
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE FUNCTION toolbelt_file.TVF_InternalParseCsv
(@Text nvarchar(max),@Separator nvarchar(2),@HasHeader bit,@NullToken nvarchar(128),@MaxRows bigint,@MaxColumns int,@MaxCells bigint,@MaxInputBytes bigint)
RETURNS TABLE(RowKind nvarchar(6),RowOrdinal bigint,ColumnOrdinal int,[Value] nvarchar(max),ErrorCode int)
AS EXTERNAL NAME [Toolbelt_File_CsvMemory].[Toolbelt.Csv.CsvEntryPoints].[Parse];
GO
-- Interner SAFE-Messtransport; gemeinsamer AnalyzeCell-Kern, keine Fragmentallokation.
-- Nonnegative UTF-16-Bytes oder negativer eigener Fachcode; unerwartetes NULL ist Invariantenfehler.
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE FUNCTION toolbelt_file.SVF_InternalMeasureCsvCell
(@Value nvarchar(max),@Separator nvarchar(2),@NullToken nvarchar(128),@IsHeader bit)
RETURNS bigint
AS EXTERNAL NAME [Toolbelt_File_CsvMemory].[Toolbelt.Csv.CsvEntryPoints].[MeasureCell];
GO
-- Interner SAFE-Quotingtransport; gemeinsamer AnalyzeCell-Kern und eigener Allokationsdeckel.
-- Nur nach vollständiger erfolgreicher Messung/globalem Chargepreflight aufrufen; technische Fehler original.
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE FUNCTION toolbelt_file.SVF_InternalQuoteCsvCell
(@Value nvarchar(max),@Separator nvarchar(2),@NullToken nvarchar(128),@IsHeader bit,@MaxOutputBytes bigint)
RETURNS nvarchar(max)
AS EXTERNAL NAME [Toolbelt_File_CsvMemory].[Toolbelt.Csv.CsvEntryPoints].[QuoteCell];
GO
-- ============================================================================
-- Objekt: toolbelt_file.USP_ParseCsv; Typ: Stored Procedure
-- Zweck: CSV-Text vollständig prüfen und in HEADER-/DATA-Zellen decodieren.
-- Vertrag: CSV_MEMORY_CONTRACT.md; USP_CONTRACT 1.0
-- Parameter: @Text nvarchar(max)=NULL; @Separator nvarchar(2)=N','; @HasHeader bit=0; @NullToken nvarchar(128)=NULL; @MaxRows bigint=100000; @MaxColumns int=1024; @MaxCells bigint=1000000; @MaxInputBytes bigint=16777216; @ResultTable sysname=NULL; @KeepData bit=0; @Debug tinyint=0; @Hilfe bit=0
-- Resultset: RowKind varchar(6) NOT NULL; RowOrdinal bigint NOT NULL; ColumnOrdinal int NOT NULL; Value nvarchar(max) NULL
-- Dependencies: eigene SAFE-CLR-Bindungen; ResultTable >=1.0.0 same_database.
-- Rechte: EXECUTE, caller-lokale Temps; keine Rechtevergabe.
-- Versionen/Plattformen: SQL Server 2019+ CL150+, Windows/Linux; Qualifikation separat.
-- Fehler: 55300..55309; Originalenginefehler; eigene Transaktion oder Caller-Savepoint.
-- Performance: begrenzte private Snapshots, vollständige Charge vor Output; kein Heap-/Grantversprechen.
-- Grenzen: kein Datei-/Netzwerk-I/O, Casting oder Datenbereinigung.
-- ============================================================================
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE toolbelt_file.USP_ParseCsv
 @Text nvarchar(max)=NULL,
 @Separator nvarchar(2)=N',',
 @HasHeader bit=0,
 @NullToken nvarchar(128)=NULL,
 @MaxRows bigint=100000,
 @MaxColumns int=1024,
 @MaxCells bigint=1000000,
 @MaxInputBytes bigint=16777216,
 @ResultTable sysname=NULL,
 @KeepData bit=0,
 @Debug tinyint=0,
 @Hilfe bit=0
AS
BEGIN
 SET NOCOUNT ON;
 IF @Hilfe=1
 BEGIN
  DECLARE @Help TABLE(HelpContractVersion varchar(16) NOT NULL DEFAULT('1.0'),SchemaName sysname NOT NULL DEFAULT(N'toolbelt_file'),ObjectName sysname NOT NULL DEFAULT(N'USP_ParseCsv'),
   Section varchar(32) NOT NULL,Ordinal int NOT NULL,ItemName sysname NULL,SqlDataType varchar(256) NULL,IsRequired bit NULL,IsNullable bit NULL,DefaultValue nvarchar(4000) NULL,Description nvarchar(max) NOT NULL,ExampleSql nvarchar(max) NULL);
  INSERT @Help(Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql) VALUES
  ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'CSV-Text vollständig prüfen und in HEADER-/DATA-Zellen decodieren.',NULL),
  ('PARAMETER',1,N'@Text','nvarchar(max)',1,0,N'NULL',N'CSV-Text im Speicher; NULL ist Argumentfehler, leer liefert keine Zellen.',NULL),
  ('PARAMETER',2,N'@Separator','nvarchar(2)',0,0,N'N'',''',N'Exakt eine zulässige UTF-16-Codeeinheit.',NULL),
  ('PARAMETER',3,N'@HasHeader','bit',0,0,N'0',N'Erster Record ist HEADER; NULL ist ungültig.',NULL),
  ('PARAMETER',4,N'@NullToken','nvarchar(128)',0,1,N'NULL',N'Optionaler exakter NULL-Token; quoted Token bleibt Text.',NULL),
  ('PARAMETER',5,N'@MaxRows','bigint',0,0,N'100000',N'Positive DATA-Recordgrenze bis 100000.',NULL),
  ('PARAMETER',6,N'@MaxColumns','int',0,0,N'1024',N'Positive rechteckige Breite bis 1024.',NULL),
  ('PARAMETER',7,N'@MaxCells','bigint',0,0,N'1000000',N'Positive HEADER+DATA-Zellgrenze bis 1000000.',NULL),
  ('PARAMETER',8,N'@MaxInputBytes','bigint',0,0,N'16777216',N'Positive vollständige UTF-16-Inputbytegrenze bis 16777216.',NULL),
  ('PARAMETER',9,N'@ResultTable','sysname',0,1,N'NULL',N'Vorhandene caller-lokale Temp-Tabelle, sonst SELECT.',NULL),
  ('PARAMETER',10,N'@KeepData','bit',0,1,N'0',N'Replace=0, Append=1; NULL entspricht 0.',NULL),
  ('PARAMETER',11,N'@Debug','tinyint',0,1,N'0',N'Nur Messages ohne Zellinhalte; NULL entspricht 0.',NULL),
  ('PARAMETER',12,N'@Hilfe','bit',0,1,N'0',N'Ausschließlich Hilfe; ignoriert sämtliche anderen Eingaben.',NULL),
  ('RESULT_COLUMN',1,N'RowKind','varchar(6)',1,0,NULL,N'Exakt HEADER oder DATA.',NULL),
  ('RESULT_COLUMN',2,N'RowOrdinal','bigint',1,0,NULL,N'HEADER=0; DATA ab1.',NULL),
  ('RESULT_COLUMN',3,N'ColumnOrdinal','int',1,0,NULL,N'Einsbasierte rechteckige Spalte.',NULL),
  ('RESULT_COLUMN',4,N'Value','nvarchar(max)',1,1,NULL,N'Unveränderter decodierter Text oder SQL-NULL.',NULL),
  ('ERROR',1,N'55300..55309',NULL,NULL,NULL,NULL,N'Begrenzte Argument-/Syntax-/Form-/Budget-/Transportfehler; ursprüngliche Enginefehler bleiben erhalten.',NULL),
  ('PERMISSION',1,NULL,NULL,NULL,NULL,NULL,N'EXECUTE und sichtbare eigene lokale Temps; ResultTable zusätzlich vorhandene Helperberechtigung. Keine Rechteausweitung.',NULL),
  ('LIMITATION',1,NULL,NULL,NULL,NULL,NULL,N'In-memory UTF-16; kein I/O, Casting, Trim oder Streaming. NUL/unpaired Surrogate bleiben Zelltext.',NULL),
  ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Hilfe ohne fachliche Eingaben.',N'EXEC toolbelt_file.USP_ParseCsv @Hilfe=1;');
  SELECT HelpContractVersion,SchemaName,ObjectName,
   Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql
  FROM @Help ORDER BY CASE Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2 WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 WHEN 'PERMISSION' THEN 5 WHEN 'LIMITATION' THEN 6 ELSE 7 END,Ordinal;
  RETURN 0;
 END;
 SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0);
 IF XACT_STATE()=-1 THROW 55309,N'CSV: Callertransaktion ist uncommittable.',1;
 IF @HasHeader IS NULL OR @Text IS NULL THROW 55300,N'CSV: erforderlicher Text oder Headerflag fehlt.',1;
 IF @MaxRows IS NULL OR @MaxRows NOT BETWEEN 1 AND 100000
 OR @MaxColumns IS NULL OR @MaxColumns NOT BETWEEN 1 AND 1024
 OR @MaxCells IS NULL OR @MaxCells NOT BETWEEN 1 AND 1000000
 OR @MaxInputBytes IS NULL OR @MaxInputBytes NOT BETWEEN 1 AND 16777216
  THROW 55303,N'CSV: Ressourcenparameter ist ungültig.',1;
 IF DATALENGTH(@Text)>@MaxInputBytes THROW 55303,N'CSV: Inputbytegrenze überschritten.',1;
 -- Namespacegrenze VOR separater Workbatch-Kompilierung: kein Caller-Temp-Eclipsing.
 IF (@ResultTable IS NOT NULL AND LOWER(LEFT(@ResultTable COLLATE Latin1_General_100_BIN2,5))=N'#tbx_')
 OR OBJECT_ID(N'tempdb..#tbx_CsvParse_Result',N'U') IS NOT NULL
  THROW 55304,N'CSV: reservierter privater Tempnamensbereich ist belegt.',1;
 IF OBJECT_ID(N'toolbelt_file.TVF_InternalParseCsv',N'FT') IS NULL
  THROW 55309,N'CSV: interne CLR-Bindung fehlt.',1;
 -- Fester vertrauenswürdiger SQL-Text; sämtliche Callerwerte sind gebundene Parameter.
 DECLARE @WorkSql nvarchar(max)=N'IF @ResultTable IS NOT NULL
 BEGIN
  DECLARE @CoreId int=OBJECT_ID(N''toolbelt_core.USP_PrepareResultTable'',N''P''),@CoreVersion nvarchar(64),@Major int,@Minor int,@Patch int;
  SELECT @CoreVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND name=N''Toolbelt.Module.toolbelt.core.result-table.Version'';
  SELECT @Major=TRY_CONVERT(int,PARSENAME(@CoreVersion,3)),@Minor=TRY_CONVERT(int,PARSENAME(@CoreVersion,2)),@Patch=TRY_CONVERT(int,PARSENAME(@CoreVersion,1));
  IF @CoreId IS NULL OR @Major IS NULL OR @Major<1 OR @Minor IS NULL OR @Minor<0 OR @Patch IS NULL OR @Patch<0
   OR CONVERT(varbinary(max),@CoreVersion)<>CONVERT(varbinary(max),CONCAT(@Major,N''.'',@Minor,N''.'',@Patch))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@CoreId AND minor_id=0 AND name=N''Toolbelt.ModuleId'' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(128),value))=CONVERT(varbinary(max),N''toolbelt.core.result-table''))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@CoreId AND minor_id=0 AND name=N''Toolbelt.ModuleVersion'' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@CoreVersion))
   THROW 55309,N''CSV: registrierte ResultTable-Dependency >=1.0.0 fehlt oder ist ungeeignet.'',1;
 END;
 DECLARE @Cells TABLE(RowKind nvarchar(6) COLLATE Latin1_General_100_BIN2 NULL,RowOrdinal bigint NULL,ColumnOrdinal int NULL,[Value] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,ErrorCode int NULL);
 -- Vollständiger privater Konsum vor Ausgabe oder Zielmutation; späte CLR-Fehler bleiben Originalfehler.
 INSERT @Cells(RowKind,RowOrdinal,ColumnOrdinal,[Value],ErrorCode)
 SELECT RowKind,RowOrdinal,ColumnOrdinal,[Value],ErrorCode FROM toolbelt_file.TVF_InternalParseCsv(@Text,@Separator,@HasHeader,@NullToken,@MaxRows,@MaxColumns,@MaxCells,@MaxInputBytes);
 IF EXISTS(SELECT 1 FROM @Cells WHERE ErrorCode IS NULL OR (ErrorCode<>0 AND ErrorCode NOT BETWEEN 55300 AND 55309))
  THROW 55309,N''CSV: interner Parserstatus ungültig.'',1;
 DECLARE @ErrorCode int;
 IF EXISTS(SELECT 1 FROM @Cells WHERE ErrorCode<>0)
 BEGIN
  IF (SELECT COUNT_BIG(*) FROM @Cells)<>1 OR EXISTS(SELECT 1 FROM @Cells WHERE RowKind IS NOT NULL OR RowOrdinal IS NOT NULL OR ColumnOrdinal IS NOT NULL OR [Value] IS NOT NULL)
   THROW 55309,N''CSV: Parserfehler ist kein isolierter Sentinel.'',1;
  SELECT @ErrorCode=ErrorCode FROM @Cells;
  DECLARE @ErrorMessage nvarchar(2048)=CASE @ErrorCode
 WHEN 55300 THEN N''CSV: ungültiges Pflichtargument oder Dialekt.''
 WHEN 55301 THEN N''CSV: ungültige Quote- oder Recordsyntax.''
 WHEN 55302 THEN N''CSV: Parserrecords sind nicht rechteckig.''
 WHEN 55303 THEN N''CSV: Ressourcenparameter oder Ressourcengrenze verletzt.''
 WHEN 55304 THEN N''CSV: zulässige caller-lokale Quelle fehlt.''
 WHEN 55305 THEN N''CSV: Quellmetadaten sind nicht exakt unterstützt.''
 WHEN 55306 THEN N''CSV: RowKind, Ordinals, Header oder Rechteck ungültig.''
 WHEN 55307 THEN N''CSV: SQL-NULL ist nicht darstellbar.''
 WHEN 55308 THEN N''CSV: Quelle und ResultTable sind identisch.''
 ELSE N''CSV: interner Transportvertrag verletzt.'' END;
 THROW @ErrorCode,@ErrorMessage,1;
 END;
 IF EXISTS(SELECT 1 FROM @Cells WHERE RowKind IS NULL OR RowOrdinal IS NULL OR ColumnOrdinal IS NULL
  OR CONVERT(varbinary(max),RowKind) NOT IN(CONVERT(varbinary(max),N''HEADER''),CONVERT(varbinary(max),N''DATA''))
  OR ColumnOrdinal NOT BETWEEN 1 AND @MaxColumns
  OR (CONVERT(varbinary(max),RowKind)=CONVERT(varbinary(max),N''HEADER'') AND (@HasHeader=0 OR RowOrdinal<>0 OR [Value] IS NULL))
  OR (CONVERT(varbinary(max),RowKind)=CONVERT(varbinary(max),N''DATA'') AND RowOrdinal NOT BETWEEN 1 AND @MaxRows))
  THROW 55309,N''CSV: interne Parserzellform ungültig.'',1;
 IF (SELECT COUNT_BIG(*) FROM @Cells)>@MaxCells OR EXISTS(SELECT 1 FROM @Cells GROUP BY RowOrdinal,ColumnOrdinal HAVING COUNT_BIG(*)<>1)
  THROW 55309,N''CSV: interne Parsergrenze oder Eindeutigkeit ungültig.'',1;
 CREATE TABLE #tbx_CsvParse_Result(RowKind varchar(6) COLLATE Latin1_General_100_BIN2 NOT NULL,RowOrdinal bigint NOT NULL,ColumnOrdinal int NOT NULL,[Value] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL);
 INSERT #tbx_CsvParse_Result(RowKind,RowOrdinal,ColumnOrdinal,[Value]) SELECT CONVERT(varchar(6),RowKind),RowOrdinal,ColumnOrdinal,[Value] FROM @Cells;
 IF @Debug>0 RAISERROR(N''CSV: vollständiger Parser-Snapshot bereit.'',10,1) WITH NOWAIT;
 IF @ResultTable IS NULL
 BEGIN SELECT RowKind,RowOrdinal,ColumnOrdinal,[Value] FROM #tbx_CsvParse_Result ORDER BY RowOrdinal,ColumnOrdinal; RETURN; END;
 DECLARE @Own bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,@Saved bit=0,@Savepoint varchar(32)=REPLACE(CONVERT(varchar(36),NEWID()),''-'','''');
 BEGIN TRY
  IF @Own=1 BEGIN TRANSACTION; ELSE BEGIN SAVE TRANSACTION @Savepoint; SET @Saved=1; END;
  EXEC toolbelt_core.USP_PrepareResultTable @ResultTableToAlter=@ResultTable,@LikeTable=N''#tbx_CsvParse_Result'',@KeepData=@KeepData,@Debug=@Debug;
  DECLARE @InsertSql nvarchar(max)=N''INSERT ''+QUOTENAME(@ResultTable)+N'' (RowKind,RowOrdinal,ColumnOrdinal,[Value]) SELECT RowKind,RowOrdinal,ColumnOrdinal,[Value] FROM #tbx_CsvParse_Result;'';
  EXEC sys.sp_executesql @InsertSql;
  IF @Own=1 COMMIT TRANSACTION;
 END TRY
 BEGIN CATCH
  IF @Own=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
  ELSE IF @Saved=1 AND XACT_STATE()=1 ROLLBACK TRANSACTION @Savepoint;
  THROW;
 END CATCH;';
 EXEC sys.sp_executesql @WorkSql,N'@Text nvarchar(max),@Separator nvarchar(2),@HasHeader bit,@NullToken nvarchar(128),@MaxRows bigint,@MaxColumns int,@MaxCells bigint,@MaxInputBytes bigint,@ResultTable sysname,@KeepData bit,@Debug tinyint',
  @Text=@Text,@Separator=@Separator,@HasHeader=@HasHeader,@NullToken=@NullToken,@MaxRows=@MaxRows,@MaxColumns=@MaxColumns,@MaxCells=@MaxCells,@MaxInputBytes=@MaxInputBytes,@ResultTable=@ResultTable,@KeepData=@KeepData,@Debug=@Debug;
 RETURN 0;
END;
GO
-- ============================================================================
-- Objekt: toolbelt_file.USP_WriteCsv; Typ: Stored Procedure
-- Zweck: Rechteckige Textzellen kanonisch zu CSV im Speicher schreiben.
-- Vertrag: CSV_MEMORY_CONTRACT.md; USP_CONTRACT 1.0
-- Parameter: @CellsTable sysname=NULL; @Separator nvarchar(2)=N','; @HasHeader bit=0; @NullToken nvarchar(128)=NULL; @LineEnding varchar(4)='CRLF'; @MaxRows bigint=100000; @MaxColumns int=1024; @MaxCells bigint=1000000; @MaxValueBytes bigint=16777216; @MaxOutputBytes bigint=16777216; @ResultTable sysname=NULL; @KeepData bit=0; @Debug tinyint=0; @Hilfe bit=0
-- Resultset: CsvText nvarchar(max) NOT NULL; DataRows bigint NOT NULL; ColumnCount int NOT NULL
-- Dependencies: eigene SAFE-CLR-Bindungen; ResultTable >=1.0.0 same_database.
-- Rechte: EXECUTE, caller-lokale Temps; keine Rechtevergabe.
-- Versionen/Plattformen: SQL Server 2019+ CL150+, Windows/Linux; Qualifikation separat.
-- Fehler: 55300..55309; Originalenginefehler; eigene Transaktion oder Caller-Savepoint.
-- Performance: begrenzte private Snapshots, vollständige Charge vor Output; kein Heap-/Grantversprechen.
-- Grenzen: kein Datei-/Netzwerk-I/O, Casting oder Datenbereinigung.
-- ============================================================================
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE toolbelt_file.USP_WriteCsv
 @CellsTable sysname=NULL,
 @Separator nvarchar(2)=N',',
 @HasHeader bit=0,
 @NullToken nvarchar(128)=NULL,
 @LineEnding varchar(4)='CRLF',
 @MaxRows bigint=100000,
 @MaxColumns int=1024,
 @MaxCells bigint=1000000,
 @MaxValueBytes bigint=16777216,
 @MaxOutputBytes bigint=16777216,
 @ResultTable sysname=NULL,
 @KeepData bit=0,
 @Debug tinyint=0,
 @Hilfe bit=0
AS
BEGIN
 SET NOCOUNT ON;
 IF @Hilfe=1
 BEGIN
  DECLARE @Help TABLE(HelpContractVersion varchar(16) NOT NULL DEFAULT('1.0'),SchemaName sysname NOT NULL DEFAULT(N'toolbelt_file'),ObjectName sysname NOT NULL DEFAULT(N'USP_WriteCsv'),
   Section varchar(32) NOT NULL,Ordinal int NOT NULL,ItemName sysname NULL,SqlDataType varchar(256) NULL,IsRequired bit NULL,IsNullable bit NULL,DefaultValue nvarchar(4000) NULL,Description nvarchar(max) NOT NULL,ExampleSql nvarchar(max) NULL);
  INSERT @Help(Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql) VALUES
  ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'Rechteckige Textzellen kanonisch zu CSV im Speicher schreiben.',NULL),
  ('PARAMETER',1,N'@CellsTable','sysname',1,0,N'NULL',N'Vorhandene lokale Temp-Tabelle mit exakt vier eingebauten Zellspalten.',NULL),
  ('PARAMETER',2,N'@Separator','nvarchar(2)',0,0,N'N'',''',N'Exakt eine zulässige UTF-16-Codeeinheit.',NULL),
  ('PARAMETER',3,N'@HasHeader','bit',0,0,N'0',N'Erster Record ist HEADER; NULL ist ungültig.',NULL),
  ('PARAMETER',4,N'@NullToken','nvarchar(128)',0,1,N'NULL',N'Optionaler exakter NULL-Token; quoted Token bleibt Text.',NULL),
  ('PARAMETER',5,N'@LineEnding','varchar(4)',0,0,N'''CRLF''',N'Exakt CRLF oder LF; Abschluss auch nach letztem Record.',NULL),
  ('PARAMETER',6,N'@MaxRows','bigint',0,0,N'100000',N'Positive DATA-Recordgrenze bis 100000.',NULL),
  ('PARAMETER',7,N'@MaxColumns','int',0,0,N'1024',N'Positive rechteckige Breite bis 1024.',NULL),
  ('PARAMETER',8,N'@MaxCells','bigint',0,0,N'1000000',N'Positive HEADER+DATA-Zellgrenze bis 1000000.',NULL),
  ('PARAMETER',9,N'@MaxValueBytes','bigint',0,0,N'16777216',N'Positive globale UTF-16-Snapshotbytegrenze bis 16777216; NULL zählt 0.',NULL),
  ('PARAMETER',10,N'@MaxOutputBytes','bigint',0,0,N'16777216',N'Positive vollständige UTF-16-Outputbytegrenze bis 16777216.',NULL),
  ('PARAMETER',11,N'@ResultTable','sysname',0,1,N'NULL',N'Vorhandene caller-lokale Temp-Tabelle, sonst SELECT.',NULL),
  ('PARAMETER',12,N'@KeepData','bit',0,1,N'0',N'Replace=0, Append=1; NULL entspricht 0.',NULL),
  ('PARAMETER',13,N'@Debug','tinyint',0,1,N'0',N'Nur Messages ohne Zellinhalte; NULL entspricht 0.',NULL),
  ('PARAMETER',14,N'@Hilfe','bit',0,1,N'0',N'Ausschließlich Hilfe; ignoriert sämtliche anderen Eingaben.',NULL),
  ('RESULT_COLUMN',1,N'CsvText','nvarchar(max)',1,0,NULL,N'Vollständiger CSV-Text; leere Quelle ohne Header ergibt leer.',NULL),
  ('RESULT_COLUMN',2,N'DataRows','bigint',1,0,NULL,N'Anzahl DATA-Records.',NULL),
  ('RESULT_COLUMN',3,N'ColumnCount','int',1,0,NULL,N'Rechteckige Breite; leere Quelle ohne Header ergibt 0.',NULL),
  ('ERROR',1,N'55300..55309',NULL,NULL,NULL,NULL,N'Begrenzte Argument-/Syntax-/Form-/Budget-/Transportfehler; ursprüngliche Enginefehler bleiben erhalten.',NULL),
  ('PERMISSION',1,NULL,NULL,NULL,NULL,NULL,N'EXECUTE und sichtbare eigene lokale Temps; ResultTable zusätzlich vorhandene Helperberechtigung. Keine Rechteausweitung.',NULL),
  ('LIMITATION',1,NULL,NULL,NULL,NULL,NULL,N'In-memory UTF-16; kein I/O, Casting, Trim oder Streaming. NUL/unpaired Surrogate bleiben Zelltext.',NULL),
  ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Hilfe ohne fachliche Eingaben.',N'EXEC toolbelt_file.USP_WriteCsv @Hilfe=1;');
  SELECT HelpContractVersion,SchemaName,ObjectName,
   Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql
  FROM @Help ORDER BY CASE Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2 WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 WHEN 'PERMISSION' THEN 5 WHEN 'LIMITATION' THEN 6 ELSE 7 END,Ordinal;
  RETURN 0;
 END;
 SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0);
 IF XACT_STATE()=-1 THROW 55309,N'CSV: Callertransaktion ist uncommittable.',1;
 IF @HasHeader IS NULL THROW 55300,N'CSV: erforderlicher Text oder Headerflag fehlt.',1;
 IF @MaxRows IS NULL OR @MaxRows NOT BETWEEN 1 AND 100000
 OR @MaxColumns IS NULL OR @MaxColumns NOT BETWEEN 1 AND 1024
 OR @MaxCells IS NULL OR @MaxCells NOT BETWEEN 1 AND 1000000
 OR @MaxValueBytes IS NULL OR @MaxValueBytes NOT BETWEEN 1 AND 16777216
 OR @MaxOutputBytes IS NULL OR @MaxOutputBytes NOT BETWEEN 1 AND 16777216
  THROW 55303,N'CSV: Ressourcenparameter ist ungültig.',1;
 IF @CellsTable IS NULL OR DATALENGTH(@CellsTable) NOT BETWEEN 4 AND 232 OR LEFT(@CellsTable,1) COLLATE Latin1_General_100_BIN2<>N'#' OR LEFT(@CellsTable,2) COLLATE Latin1_General_100_BIN2=N'##' OR QUOTENAME(@CellsTable) IS NULL
  THROW 55304,N'CSV: caller-lokaler Tempname erforderlich.',1;
 IF @LineEnding IS NULL OR CONVERT(varbinary(max),@LineEnding) NOT IN(0x43524C46,0x4C46) THROW 55300,N'CSV: LineEnding muss exakt CRLF oder LF sein.',1;
 -- Namespacegrenze VOR separater Workbatch-Kompilierung: kein Caller-Temp-Eclipsing.
 IF (@ResultTable IS NOT NULL AND LOWER(LEFT(@ResultTable COLLATE Latin1_General_100_BIN2,5))=N'#tbx_')
 OR LOWER(LEFT(@CellsTable COLLATE Latin1_General_100_BIN2,5))=N'#tbx_'
 OR OBJECT_ID(N'tempdb..#tbx_CsvWrite_Input',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_CsvWrite_Measure',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_CsvWrite_Fragments',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_CsvWrite_Records',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_CsvWrite_Result',N'U') IS NOT NULL
  THROW 55304,N'CSV: reservierter privater Tempnamensbereich ist belegt.',1;
 IF OBJECT_ID(N'toolbelt_file.SVF_InternalMeasureCsvCell',N'FS') IS NULL OR OBJECT_ID(N'toolbelt_file.SVF_InternalQuoteCsvCell',N'FS') IS NULL
  THROW 55309,N'CSV: interne CLR-Bindung fehlt.',1;
 -- Fester vertrauenswürdiger SQL-Text; sämtliche Callerwerte sind gebundene Parameter.
 DECLARE @WorkSql nvarchar(max)=N'IF @ResultTable IS NOT NULL
 BEGIN
  DECLARE @CoreId int=OBJECT_ID(N''toolbelt_core.USP_PrepareResultTable'',N''P''),@CoreVersion nvarchar(64),@Major int,@Minor int,@Patch int;
  SELECT @CoreVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND name=N''Toolbelt.Module.toolbelt.core.result-table.Version'';
  SELECT @Major=TRY_CONVERT(int,PARSENAME(@CoreVersion,3)),@Minor=TRY_CONVERT(int,PARSENAME(@CoreVersion,2)),@Patch=TRY_CONVERT(int,PARSENAME(@CoreVersion,1));
  IF @CoreId IS NULL OR @Major IS NULL OR @Major<1 OR @Minor IS NULL OR @Minor<0 OR @Patch IS NULL OR @Patch<0
   OR CONVERT(varbinary(max),@CoreVersion)<>CONVERT(varbinary(max),CONCAT(@Major,N''.'',@Minor,N''.'',@Patch))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@CoreId AND minor_id=0 AND name=N''Toolbelt.ModuleId'' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(128),value))=CONVERT(varbinary(max),N''toolbelt.core.result-table''))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@CoreId AND minor_id=0 AND name=N''Toolbelt.ModuleVersion'' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@CoreVersion))
   THROW 55309,N''CSV: registrierte ResultTable-Dependency >=1.0.0 fehlt oder ist ungeeignet.'',1;
 END;
 DECLARE @InputId int=OBJECT_ID(N''tempdb..''+QUOTENAME(@CellsTable),N''U'');
 IF @InputId IS NULL THROW 55304,N''CSV: caller-lokale Quelle fehlt oder ist nicht sichtbar.'',1;
 IF @ResultTable IS NOT NULL AND OBJECT_ID(N''tempdb..''+QUOTENAME(@ResultTable),N''U'')=@InputId THROW 55308,N''CSV: Quelle und ResultTable sind identisch.'',1;
 DECLARE @Expected TABLE(Name sysname NOT NULL,TypeId int NOT NULL,Length smallint NOT NULL);
 INSERT @Expected VALUES(N''RowKind'',167,6),(N''RowOrdinal'',127,8),(N''ColumnOrdinal'',56,4),(N''Value'',231,-1);
 IF (SELECT COUNT(*) FROM tempdb.sys.columns WHERE object_id=@InputId)<>4
 OR EXISTS(SELECT 1 FROM @Expected e WHERE NOT EXISTS(SELECT 1 FROM tempdb.sys.columns c WHERE c.object_id=@InputId
  AND CONVERT(varbinary(256),c.name)=CONVERT(varbinary(256),e.Name) AND c.system_type_id=e.TypeId
  AND c.user_type_id=c.system_type_id AND c.max_length=e.Length AND c.is_computed=0 AND c.is_hidden=0))
  THROW 55305,N''CSV: Quelle benötigt genau die vier eingebauten Zellspalten.'',1;
 DECLARE @Probe bigint=toolbelt_file.SVF_InternalMeasureCsvCell(N'''',@Separator,@NullToken,CONVERT(bit,0)),@ErrorCode int;
 IF @Probe IS NULL OR (@Probe<0 AND @Probe NOT BETWEEN -55309 AND -55300) OR @Probe>0 THROW 55309,N''CSV: interner Messstatus ungültig.'',1;
 IF @Probe<0
 BEGIN
  SET @ErrorCode=TRY_CONVERT(int,-CONVERT(decimal(38,0),@Probe));
  DECLARE @ErrorMessage nvarchar(2048)=CASE @ErrorCode
 WHEN 55300 THEN N''CSV: ungültiges Pflichtargument oder Dialekt.''
 WHEN 55301 THEN N''CSV: ungültige Quote- oder Recordsyntax.''
 WHEN 55302 THEN N''CSV: Parserrecords sind nicht rechteckig.''
 WHEN 55303 THEN N''CSV: Ressourcenparameter oder Ressourcengrenze verletzt.''
 WHEN 55304 THEN N''CSV: zulässige caller-lokale Quelle fehlt.''
 WHEN 55305 THEN N''CSV: Quellmetadaten sind nicht exakt unterstützt.''
 WHEN 55306 THEN N''CSV: RowKind, Ordinals, Header oder Rechteck ungültig.''
 WHEN 55307 THEN N''CSV: SQL-NULL ist nicht darstellbar.''
 WHEN 55308 THEN N''CSV: Quelle und ResultTable sind identisch.''
 ELSE N''CSV: interner Transportvertrag verletzt.'' END;
 THROW @ErrorCode,@ErrorMessage,1;
 END;
 DECLARE @Own bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,@Saved bit=0,@Savepoint varchar(32)=REPLACE(CONVERT(varchar(36),NEWID()),''-'',''''),@Sql nvarchar(max);
 BEGIN TRY
  IF @Own=1 BEGIN TRANSACTION; ELSE BEGIN SAVE TRANSACTION @Savepoint; SET @Saved=1; END;
  -- Metadatencharge vor jeder LOB-Kopie, begrenzter Scan und stabiler Snapshot.
  DECLARE @Limit bigint=@MaxCells+1,@PreCells bigint,@PreBytes bigint,@PreDataRows bigint,@PreColumn int;
  SET @Sql=N''SELECT @c=COUNT_BIG(*),@b=COALESCE(SUM(CONVERT(bigint,DATALENGTH([Value]))),0),@r=COUNT_BIG(DISTINCT CASE WHEN CONVERT(varbinary(max),RowKind)=0x44415441 THEN RowOrdinal END),@k=MAX(ColumnOrdinal) FROM(SELECT TOP (@limit) RowKind,RowOrdinal,ColumnOrdinal,[Value] FROM ''+QUOTENAME(@CellsTable)+N'' WITH(TABLOCK,HOLDLOCK)) bounded;'';
  EXEC sys.sp_executesql @Sql,N''@limit bigint,@c bigint OUTPUT,@b bigint OUTPUT,@r bigint OUTPUT,@k int OUTPUT'',@Limit,@PreCells OUTPUT,@PreBytes OUTPUT,@PreDataRows OUTPUT,@PreColumn OUTPUT;
  IF @PreCells>@MaxCells OR @PreBytes>@MaxValueBytes OR @PreDataRows>@MaxRows OR @PreColumn>@MaxColumns THROW 55303,N''CSV: Zell-, Record-, Spalten- oder Snapshotbytegrenze überschritten.'',1;
  CREATE TABLE #tbx_CsvWrite_Input(RowKind varchar(6) COLLATE Latin1_General_100_BIN2 NULL,RowOrdinal bigint NULL,ColumnOrdinal int NULL,[Value] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL);
  SET @Sql=N''INSERT #tbx_CsvWrite_Input(RowKind,RowOrdinal,ColumnOrdinal,[Value]) SELECT TOP (@limit) RowKind,RowOrdinal,ColumnOrdinal,[Value] FROM ''+QUOTENAME(@CellsTable)+N'' WITH(TABLOCK,HOLDLOCK);'';
  EXEC sys.sp_executesql @Sql,N''@limit bigint'',@Limit;
  IF (SELECT COUNT_BIG(*) FROM #tbx_CsvWrite_Input)>@MaxCells
   OR (SELECT COALESCE(SUM(CONVERT(bigint,DATALENGTH([Value]))),0) FROM #tbx_CsvWrite_Input)>@MaxValueBytes
   THROW 55303,N''CSV: Zell- oder Snapshotbytegrenze überschritten.'',1;
  IF EXISTS(SELECT 1 FROM #tbx_CsvWrite_Input WHERE RowKind IS NULL OR RowOrdinal IS NULL OR ColumnOrdinal IS NULL
   OR CONVERT(varbinary(max),RowKind) NOT IN(0x484541444552,0x44415441)
   OR ColumnOrdinal NOT BETWEEN 1 AND @MaxColumns
   OR (CONVERT(varbinary(max),RowKind)=0x484541444552 AND (@HasHeader=0 OR RowOrdinal<>0))
   OR (CONVERT(varbinary(max),RowKind)=0x44415441 AND RowOrdinal<1))
   OR EXISTS(SELECT 1 FROM #tbx_CsvWrite_Input GROUP BY RowOrdinal,ColumnOrdinal HAVING COUNT_BIG(*)<>1)
   THROW 55306,N''CSV: RowKind, Ordinals oder Headerform ungültig.'',1;
  IF EXISTS(SELECT 1 FROM #tbx_CsvWrite_Input WHERE [Value] IS NULL AND (CONVERT(varbinary(max),RowKind)=0x484541444552 OR @NullToken IS NULL))
   THROW 55307,N''CSV: SQL-NULL ist nicht darstellbar.'',1;
  DECLARE @DataRows bigint=(SELECT COUNT_BIG(DISTINCT RowOrdinal) FROM #tbx_CsvWrite_Input WHERE CONVERT(varbinary(max),RowKind)=0x44415441),
   @ColumnCount int=COALESCE((SELECT MAX(ColumnOrdinal) FROM #tbx_CsvWrite_Input),0),
   @HeaderCells bigint=(SELECT COUNT_BIG(*) FROM #tbx_CsvWrite_Input WHERE CONVERT(varbinary(max),RowKind)=0x484541444552);
  IF @DataRows>@MaxRows THROW 55303,N''CSV: DATA-Recordgrenze überschritten.'',1;
  IF (@HasHeader=1 AND (@HeaderCells=0 OR @HeaderCells<>@ColumnCount)) OR (@HasHeader=0 AND @HeaderCells<>0)
   OR EXISTS(SELECT 1 FROM #tbx_CsvWrite_Input GROUP BY RowOrdinal HAVING MIN(ColumnOrdinal)<>1 OR MAX(ColumnOrdinal)<>@ColumnCount OR COUNT_BIG(*)<>@ColumnCount)
   OR (@DataRows>0 AND ((SELECT MIN(RowOrdinal) FROM #tbx_CsvWrite_Input WHERE CONVERT(varbinary(max),RowKind)=0x44415441)<>1 OR (SELECT MAX(RowOrdinal) FROM #tbx_CsvWrite_Input WHERE CONVERT(varbinary(max),RowKind)=0x44415441)<>@DataRows))
   THROW 55306,N''CSV: Quelle ist kein vollständiges rechteckiges Zellraster.'',1;
  -- Das zuvor geprüfte eindeutige Zellraster auch für den vollständigen
  -- Fragment-/Maßabgleich indizieren und gezielte Zellzugriffe ermöglichen.
  -- Unbenannte Temp-Constraints vermeiden Namenskollisionen zwischen Sitzungen.
  CREATE TABLE #tbx_CsvWrite_Measure(RowOrdinal bigint NOT NULL,ColumnOrdinal int NOT NULL,Bytes bigint NULL,PRIMARY KEY CLUSTERED(RowOrdinal,ColumnOrdinal));
  INSERT #tbx_CsvWrite_Measure SELECT RowOrdinal,ColumnOrdinal,toolbelt_file.SVF_InternalMeasureCsvCell([Value],@Separator,@NullToken,CONVERT(bit,CASE WHEN RowOrdinal=0 THEN 1 ELSE 0 END)) FROM #tbx_CsvWrite_Input;
  IF EXISTS(SELECT 1 FROM #tbx_CsvWrite_Measure WHERE Bytes IS NULL OR (Bytes<0 AND Bytes NOT BETWEEN -55309 AND -55300))
   THROW 55309,N''CSV: interner Messstatus ungültig.'',1;
  IF EXISTS(SELECT 1 FROM #tbx_CsvWrite_Measure WHERE Bytes<0)
  BEGIN
   SELECT TOP(1) @ErrorCode=TRY_CONVERT(int,-CONVERT(decimal(38,0),Bytes)) FROM #tbx_CsvWrite_Measure WHERE Bytes<0 ORDER BY RowOrdinal,ColumnOrdinal;
   DECLARE @MeasuredErrorMessage nvarchar(2048)=N''CSV: fachlicher Zellmessfehler.'';
   THROW @ErrorCode,@MeasuredErrorMessage,1;
  END;
  IF EXISTS(SELECT 1 FROM #tbx_CsvWrite_Measure WHERE Bytes>@MaxOutputBytes OR Bytes%2<>0)
   THROW 55303,N''CSV: Zelloutputgrenze überschritten.'',1;
  DECLARE @Records bigint=@DataRows+CASE WHEN @HasHeader=1 THEN 1 ELSE 0 END,
   @Ending nvarchar(2)=CASE WHEN CONVERT(varbinary(4),@LineEnding)=0x43524C46 THEN CONVERT(nvarchar(2),NCHAR(13)+NCHAR(10)) ELSE CONVERT(nvarchar(2),NCHAR(10)) END,@OutputBytes bigint;
  SELECT @OutputBytes=COALESCE(SUM(Bytes),0)+@Records*DATALENGTH(@Ending)+(@PreCells-@Records)*CONVERT(bigint,DATALENGTH(@Separator)) FROM #tbx_CsvWrite_Measure;
  IF @OutputBytes>@MaxOutputBytes THROW 55303,N''CSV: globale Outputbytegrenze überschritten.'',1;
  -- Erst der vollständige globale Charge-PASS erlaubt LOB-Fragmente und Aggregation.
  CREATE TABLE #tbx_CsvWrite_Fragments(RowOrdinal bigint NOT NULL,ColumnOrdinal int NOT NULL,Fragment nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,PRIMARY KEY CLUSTERED(RowOrdinal,ColumnOrdinal));
  INSERT #tbx_CsvWrite_Fragments SELECT RowOrdinal,ColumnOrdinal,toolbelt_file.SVF_InternalQuoteCsvCell([Value],@Separator,@NullToken,CONVERT(bit,CASE WHEN RowOrdinal=0 THEN 1 ELSE 0 END),@MaxOutputBytes) FROM #tbx_CsvWrite_Input;
  IF EXISTS(SELECT 1 FROM #tbx_CsvWrite_Fragments f JOIN #tbx_CsvWrite_Measure m ON m.RowOrdinal=f.RowOrdinal AND m.ColumnOrdinal=f.ColumnOrdinal WHERE f.Fragment IS NULL OR DATALENGTH(f.Fragment)<>m.Bytes)
   THROW 55309,N''CSV: Quotingcharge und Fragment weichen ab.'',1;
  CREATE TABLE #tbx_CsvWrite_Records(RowOrdinal bigint NOT NULL,RecordText nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL);
  INSERT #tbx_CsvWrite_Records SELECT RowOrdinal,STRING_AGG(CONVERT(nvarchar(max),Fragment),@Separator) WITHIN GROUP(ORDER BY ColumnOrdinal) FROM #tbx_CsvWrite_Fragments GROUP BY RowOrdinal;
  CREATE TABLE #tbx_CsvWrite_Result(CsvText nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL,DataRows bigint NOT NULL,ColumnCount int NOT NULL);
  INSERT #tbx_CsvWrite_Result SELECT COALESCE(STRING_AGG(CONVERT(nvarchar(max),RecordText)+@Ending,N'''') WITHIN GROUP(ORDER BY RowOrdinal),N''''),@DataRows,@ColumnCount FROM #tbx_CsvWrite_Records;
  IF (SELECT DATALENGTH(CsvText) FROM #tbx_CsvWrite_Result)<>@OutputBytes THROW 55309,N''CSV: globale Outputcharge weicht ab.'',1;
  IF @Debug>0 RAISERROR(N''CSV: vollständiges Writergebnis bereit.'',10,1) WITH NOWAIT;
  IF @ResultTable IS NOT NULL
  BEGIN
   EXEC toolbelt_core.USP_PrepareResultTable @ResultTableToAlter=@ResultTable,@LikeTable=N''#tbx_CsvWrite_Result'',@KeepData=@KeepData,@Debug=@Debug;
   SET @Sql=N''INSERT ''+QUOTENAME(@ResultTable)+N'' (CsvText,DataRows,ColumnCount) SELECT CsvText,DataRows,ColumnCount FROM #tbx_CsvWrite_Result;'';
   EXEC sys.sp_executesql @Sql;
  END;
  IF @Own=1 COMMIT TRANSACTION;
  IF @ResultTable IS NULL SELECT CsvText,DataRows,ColumnCount FROM #tbx_CsvWrite_Result;
 END TRY
 BEGIN CATCH
  IF @Own=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
  ELSE IF @Saved=1 AND XACT_STATE()=1 ROLLBACK TRANSACTION @Savepoint;
  THROW;
 END CATCH;';
 EXEC sys.sp_executesql @WorkSql,N'@CellsTable sysname,@Separator nvarchar(2),@HasHeader bit,@NullToken nvarchar(128),@LineEnding varchar(4),@MaxRows bigint,@MaxColumns int,@MaxCells bigint,@MaxValueBytes bigint,@MaxOutputBytes bigint,@ResultTable sysname,@KeepData bit,@Debug tinyint',
  @CellsTable=@CellsTable,@Separator=@Separator,@HasHeader=@HasHeader,@NullToken=@NullToken,@LineEnding=@LineEnding,@MaxRows=@MaxRows,@MaxColumns=@MaxColumns,@MaxCells=@MaxCells,@MaxValueBytes=@MaxValueBytes,@MaxOutputBytes=@MaxOutputBytes,@ResultTable=@ResultTable,@KeepData=@KeepData,@Debug=@Debug;
 RETURN 0;
END;
GO
-- Abschluss der eigenen Deploymenttransaktion; nur exakt fünf bekannte Slots markieren.
BEGIN TRY
 IF @@TRANCOUNT<>1 OR XACT_STATE()<>1 THROW 55329,N'Eigene CSV-Deploymenttransaktion fehlt.',1;
 DECLARE @Module sql_variant=CONVERT(nvarchar(128),N'toolbelt.file.csv-memory'),@Version sql_variant=CONVERT(nvarchar(16),N'1.0.0'),@Managed sql_variant=CONVERT(bit,1),@Mode sql_variant=CONVERT(nvarchar(16),N'central');
 DECLARE @Property sysname,@Value sql_variant,@Object sysname,@Type varchar(16);
 DECLARE @Properties TABLE(Name sysname,Value sql_variant);
 INSERT @Properties VALUES(N'Toolbelt.Module.toolbelt.file.csv-memory.Version',@Version),(N'Toolbelt.Module.toolbelt.file.csv-memory.DeploymentMode',@Mode);
 DECLARE DatabaseMarkers CURSOR LOCAL FAST_FORWARD FOR SELECT Name,Value FROM @Properties;
 OPEN DatabaseMarkers;FETCH NEXT FROM DatabaseMarkers INTO @Property,@Value;
 WHILE @@FETCH_STATUS=0
 BEGIN
  IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=@Property) EXEC sys.sp_updateextendedproperty @name=@Property,@value=@Value;
  ELSE EXEC sys.sp_addextendedproperty @name=@Property,@value=@Value;
  FETCH NEXT FROM DatabaseMarkers INTO @Property,@Value;
 END;
 CLOSE DatabaseMarkers;DEALLOCATE DatabaseMarkers;
 DECLARE @Slots TABLE(Name sysname,Kind char(2));
 INSERT @Slots VALUES(N'USP_ParseCsv','P'),(N'USP_WriteCsv','P'),(N'TVF_InternalParseCsv','FT'),(N'SVF_InternalQuoteCsvCell','FS'),(N'SVF_InternalMeasureCsvCell','FS');
 IF EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(s.Name)) WHERE o.object_id IS NULL OR CONVERT(varbinary(max),o.name)<>CONVERT(varbinary(max),s.Name) OR CONVERT(varbinary(max),o.type)<>CONVERT(varbinary(max),s.Kind))
  THROW 55329,N'Der vollständige fünfteilige CSV-Zielslotbestand fehlt.',2;
 DECLARE ObjectMarkers CURSOR LOCAL FAST_FORWARD FOR SELECT s.Name,CASE WHEN s.Kind='P' THEN 'PROCEDURE' ELSE 'FUNCTION' END,p.Name,p.Value FROM @Slots s CROSS APPLY(VALUES(N'Toolbelt.Managed',@Managed),(N'Toolbelt.ModuleId',@Module),(N'Toolbelt.ModuleVersion',@Version),(N'Toolbelt.Visibility',CONVERT(sql_variant,CONVERT(nvarchar(16),CASE WHEN s.Kind='P' THEN N'public' ELSE N'internal' END))))p(Name,Value);
 OPEN ObjectMarkers;FETCH NEXT FROM ObjectMarkers INTO @Object,@Type,@Property,@Value;
 WHILE @@FETCH_STATUS=0
 BEGIN
  EXEC sys.sp_addextendedproperty @name=@Property,@value=@Value,@level0type=N'SCHEMA',@level0name=N'toolbelt_file',@level1type=@Type,@level1name=@Object;
  FETCH NEXT FROM ObjectMarkers INTO @Object,@Type,@Property,@Value;
 END;
 CLOSE ObjectMarkers;DEALLOCATE ObjectMarkers;
 DECLARE @AssemblyId int=(SELECT assembly_id FROM sys.assemblies WHERE CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_File_CsvMemory'));
 IF @AssemblyId IS NULL THROW 55329,N'Die CSV-Zielassembly fehlt.',3;
 DELETE FROM @Properties;INSERT @Properties VALUES(N'Toolbelt.Managed',@Managed),(N'Toolbelt.ModuleId',@Module),(N'Toolbelt.ModuleVersion',@Version);
 DECLARE AssemblyMarkers CURSOR LOCAL FAST_FORWARD FOR SELECT Name,Value FROM @Properties;
 OPEN AssemblyMarkers;FETCH NEXT FROM AssemblyMarkers INTO @Property,@Value;
 WHILE @@FETCH_STATUS=0
 BEGIN
  IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND name=@Property)
   EXEC sys.sp_updateextendedproperty @name=@Property,@value=@Value,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_File_CsvMemory';
  ELSE EXEC sys.sp_addextendedproperty @name=@Property,@value=@Value,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_File_CsvMemory';
  FETCH NEXT FROM AssemblyMarkers INTO @Property,@Value;
 END;
 CLOSE AssemblyMarkers;DEALLOCATE AssemblyMarkers;
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.file.csv-memory
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.json.constructors
:On Error exit
-- Erst-/Repeat1.3 sowie explizite bekannte1.2→1.3-Migration; kein Downgrade.
IF @@TRANCOUNT>0
BEGIN
 RAISERROR(N'JSON_LIFECYCLE_CALLER_TRANSACTION: aktive Callertransaktion ist ausgeschlossen.',16,1);
 RETURN;
END;
IF OBJECT_ID(N'tempdb..#tbx_JsonConstructorDeployState',N'U') IS NOT NULL
 THROW 53623,N'JSON lifecycle: reservierter Deploymentzustand ist belegt.',1;
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;
DECLARE @Mode nvarchar(max)=N'central',@Version nvarchar(max),@InstalledMode nvarchar(max),
 @Registered bit,@ModeRegistered bit,@SchemaId int,@Pass int=0,@LockResult int,@PreviousCount int,
 @InitialVersion varbinary(max),@InitialMode varbinary(max),@InitialRegistered bit,@InitialSchemaId int,@InitialClrTuple varbinary(max),@CurrentClrTuple varbinary(max),
 @DependencyVersion nvarchar(max),@DependencyId int,@Major int,@Minor int,@Patch int;
DECLARE @Slots TABLE(Id int PRIMARY KEY,Name sysname COLLATE DATABASE_DEFAULT NOT NULL,Kind char(2) NOT NULL);
INSERT @Slots VALUES(1,N'USP_JsonConstructInternal','P'),(2,N'USP_JsonArray','P'),(3,N'USP_JsonObject','P'),
 (4,N'USP_JsonArraysByGroup','P'),(5,N'USP_JsonObjectsByGroup','P'),
 (6,N'FT_JsonEntryEvaluateInternal','FT'),(7,N'AGF_JsonArray','AF'),(8,N'AGF_JsonObject','AF');
-- Modullokale geschlossene Registryzeile; kein Targethash als KnownInstalled-Fallback.
DECLARE @KnownHash varbinary(64)=0xFF266A2FC46EB4101D87BC046AEF63197B985C8CCBAEA40F372E9918D1254C44F1F2CF8CED7942383625D28E2E1AF5BF6164FA8A16B3DD5A16DF5957FAA34276,
 @KnownArtifactId varchar(64)='e5d0a37f7643a1a7bbe17602ab0d8457bc959464e97496f45f6ddbe92fa15525',@AssemblyId int,@AssemblyOwner int,@InstalledHash varbinary(64),
 @EffectiveOwner int,@KnownMode nvarchar(16),@KnownCount int,@CreatingSlots bit=0;
DECLARE @Parameters TABLE(Slot sysname,Id int,Name sysname,TypeId int,Length smallint);
INSERT @Parameters VALUES
(N'AGF_JsonArray',0,N'',231,-1),
(N'AGF_JsonArray',1,N'@Ordinal',56,4),
(N'AGF_JsonArray',2,N'@ValueKind',231,-1),
(N'AGF_JsonArray',3,N'@Value',231,-1),
(N'AGF_JsonArray',4,N'@Profile',48,1),
(N'AGF_JsonObject',0,N'',231,-1),
(N'AGF_JsonObject',1,N'@Ordinal',56,4),
(N'AGF_JsonObject',2,N'@Key',231,-1),
(N'AGF_JsonObject',3,N'@ValueKind',231,-1),
(N'AGF_JsonObject',4,N'@Value',231,-1),
(N'AGF_JsonObject',5,N'@Profile',48,1),
(N'FT_JsonEntryEvaluateInternal',1,N'@ObjectMode',104,1),
(N'FT_JsonEntryEvaluateInternal',2,N'@Key',231,-1),
(N'FT_JsonEntryEvaluateInternal',3,N'@ValueKind',231,-1),
(N'FT_JsonEntryEvaluateInternal',4,N'@Value',231,-1),
(N'FT_JsonEntryEvaluateInternal',5,N'@Stage',48,1),
(N'FT_JsonEntryEvaluateInternal',6,N'@Policy',48,1);
DECLARE @Columns TABLE(Id int,Name sysname,TypeId int,Length smallint);
INSERT @Columns VALUES
(1,N'Fragment',231,-1),
(2,N'ErrorNumber',56,4),
(3,N'ErrorState',56,4),
(4,N'FaultPhase',48,1),
(5,N'RawValueBytes',127,8),
(6,N'KeyBytes',127,8),
(7,N'StrongMinimumBytes',127,8),
(8,N'FragmentBytes',127,8);
-- Target1.3 separat; die historische1.2-Knownzeile bleibt unverändert.
DECLARE @TargetKnownHash varbinary(64)=0x8ab08a17d1be0b861043463e223154dffbed8273bc2c197cd7c8b791c3c06c4af418358e8e743d72068a3a9f726f7f85f50bcfa431df0484202ab562e1edb4bf,
 @TargetArtifactId varchar(64)='a6d81103af18a73a14e58339abb8c7835e0d16d559951cfc3a03d305b63e4a23';
-- Qualifizierte Offline-Corezeile; keine Trustfreigabe und keine Runtimeableitung.
DECLARE @JsonCoreKnownHash varbinary(64)=0x4680e9d34a0870924b5ca003cc5983882fc8ffb653e702bcc549e5f65dde11934c55ba7b356b519503ac5ce1e2478fe64876fea0295176ff13b5b4a6ab61b894,
 @JsonCoreArtifactId varchar(64)='975d4a84bb86e80b6e5844d6e86785ae0e98b13ee44c0f66c021507a23e0f888',
 @JsonCoreId int,@JsonCoreOwner int,@JsonCoreHash varbinary(64),
 @JsonCoreVersion nvarchar(max),@JsonCoreStoredMode nvarchar(max),
 @JsonCoreExpectedMode nvarchar(max),@JsonCoreRequired bit=1,@JsonCoreRemoving bit=0;
DECLARE @JsonCoreMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);
DECLARE @TargetBits varbinary(max)=0x4d5a90000300000004000000ffff0000b800000000000000400000000000000000000000000000000000000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a2400000000000000504500004c01030076fd68830000000000000000e00022200b013000007a00000006000000000000de9900000020000000a000000000001000200000000200000400000000000000040000000000000000e0000000020000000000000300408500001000001000000000100000100000000000001000000000000000000000008c9900004f00000000a00000180300000000000000000000000000000000000000c000000c000000709900001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000080000000000000000000000082000004800000000000000000000002e74657874000000f079000000200000007a000000020000000000000000000000000000200000602e727372630000001803000000a0000000040000007c0000000000000000000000000000400000402e72656c6f6300000c00000000c0000000020000008000000000000000000000000000004000004200000000000000000000000000000000c0990000000000004800000002000500186900005830000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009202280900000a02037d0100000402047d0200000402057d04000004020e047d030000042a00000013300200540000000000000002280900000a02037d0500000402047d0600000402057d07000004020e047d08000004020e057d09000004020e067d0a000004020e077d0b000004020e087d0c000004020e097d0d000004020e0a7d0e0000042a133003003c00000001000011038e69048e69280a00000a0a160b2b1903078f27000001040791280b00000a0c082c02082a0717d60b070632e3038e690d1203048e69280c00000a2a1e02280900000a2a2a022d0628350000067a2a8202172e060218fe012b0117280500000602172e0620a08601002a20102700002a8a02172e060218fe012b0117280500000602172e0720000000016a2a20000020006a2a8a02172e060218fe012b0117280500000602172e0720000040026a2a20000050006a2a0000133002004200000000000000021759450500000002000000080000000e000000140000001a0000002b1e72010000702a720f0000702a72190000702a72290000702a72370000702a28350000067a0000133004004e000000020000110214fe032805000006026f0d00000a18d88d270000010a160b2b28061807d802076f0e00000a20ff0000005fb49c061807d817d602076f0e00000a1e63b49c0717d60b07026f0d00000a32cf062a0000133006004000000003000011028e69185d16fe012805000006028e69185b8d2a0000010a160b2b170607021807d891021807d817d6911e6260b69d0717d60b07068e6932e306730f00000a2a133003002400000004000011028e69038e692e02162a160a2b0e0206910306912e02162a0617d60a06028e6932ec172a13300a006502000005000011042c14048e2c10048e69032806000006fe0216fe012b01162805000006046f1000000a740200001b0a067e54000004252d17267e53000004fe0675000006731100000a258054000004280100002b166a0b166a0c166a0d166a1304166a1305731300000a130616130938570100000611099a130a110a2c27110a7b0100000416311d11092c16110a7b0100000406110917da9a7b01000004fe022b04172b01162805000006110a7b040000042809000006130b02110a7b02000004110b110a7b030000041716281400000a130c110c7b1500000a16fe01280500000607110c7b1600000ad60b08110c7b1600000ad6110c7b1700000ad6022d03162b011c6ad60c09110c7b1800000ad60d1104110c7b1900000ad6130407032807000006304208186a068e696ad8d6186ad6032807000006302e09186a068e696ad8d6186ad6032807000006301a1104186a068e696ad8d6186ad6032807000006fe0216fe012b01162805000006022c35110a7b02000004280a000006130d1105110d8e696ad613051105032807000006fe0216fe0128050000061106110d6f1a00000a2b1f061109110a7b0100000414110a7b04000004110a7b030000047301000006a2110917d613091109068e693f9ffeffff11066f1b00000a130711077e10000004280200002b17130e2b247e100000041107110e17da9a1107110e9a6f0300000616fe042805000006110e17d6130e110e11078e6932d420900000006a1a6a068e696ad8d61a6a11078e696ad8d61105d61f106a068e696ad8d607d613081108032808000006fe0216fe012805000006020306110707080911041105186a5b110873020000062a0000001b30030069030000060000110214fe032805000006027b05000004027b06000004027b07000004280d0000060a067b09000004027b090000043348067b0a000004027b0a000004333a067b0b000004027b0b000004332c067b0c000004027b0c000004331e067b0d000004027b0d0000043310067b0e000004027b0e000004fe012b01162805000006067b080000048e69027b080000048e69fe012805000006160b2b1e067b08000004079a027b08000004079a280c00000628050000060717d60b07067b080000048e6932d7731d00000a0c08281e00000a17731f00000a0d097e0f0000046f2000000a09196f2100000a091f706f2100000a09067b0e0000046f2200000a09067b0500000416fe03b46f2300000a091a6f2300000a09067b060000046f2300000a09166f2300000a09166f2400000a09067b070000048e696a6f2200000a09067b090000046f2200000a09067b0a0000046f2200000a09067b0b0000046f2200000a09067b0c0000046f2200000a09067b0d0000046f2200000a09067b070000048e696f2500000a09067b080000048e696f2500000a09067b070000048e696f2500000a09166f2500000a09166f2100000a09166f2100000a09067b090000046f2200000a091e8d270000016f2000000a067b0700000413051613062b1a110511069a13070911077b010000046f2500000a110617581306110611058e6932de067b0800000413081613062b1f110811069a13090911098e696f2500000a0911096f2000000a110617581306110611088e6932d9067b07000004130516130638b0000000110511069a130a067b050000042d03152b1c067b08000004110a7b02000004280a0000067e10000004280300002b130b067b050000042c0a110b16fe0416fe012b0117280500000609110a7b010000046f2500000a09110b6f2500000a09110a7b040000046f2300000a09166f2300000a09166f2100000a110a7b030000042d0909156f2500000a2b20110a7b03000004280a000006130c09110c8e696f2500000a09110c6f2000000a110617581306110611058e693f45ffffff096f2700000a086f2800000a130411048e6a067b0e0000041f206adafe012805000006282900000a130d09110d11046f2a00000a6f2000000ade0c110d2c07110d6f2b00000adc096f2700000a086f2800000a130ede14092c06096f2b00000adc082c06086f2b00000adc110e2a000000414c0000020000002503000011000000360300000c0000000000000002000000d40000007e020000520300000a0000000000000002000000c7000000950200005c0300000a00000000000000133005004d000000070000110316320d032000800000fe0216fe012b01162805000006038d270000010a160b2b250206070307da6f2c00000a0c0816310b080307dafe0216fe012b011628050000060708d60b070332d7062a0000001b300600e605000008000011021f70280f0000060a06732d00000a732e00000a130e110e1e6f2f00000a7e0f000004280c0000062c17110e6f3000000a19330d110e6f3000000a1f70fe012b01162805000006110e6f3100000a0b110e6f3200000a130f110f17300a110f17fe0103fe012b01162805000006110e6f3200000a1afe012805000006110e6f3200000a13091109172e07110918fe012b01172805000006110e6f3200000a2d0c110e6f3300000a16fe012b01162805000006110e6f3100000a0c110e6f3100000a0d110e6f3100000a1304110e6f3100000a1305110e6f3100000a1306110e6f3100000a1307110e6f3400000a130a110e6f3400000a130b110e6f3400000a130c110e6f3400000a2d15110e6f3000000a2d0c110e6f3000000a16fe012b01162805000006110e6f3100000a1308110e1e6f2f00000a1e8d27000001280c0000062805000006de0c110e2c07110e6f2b00000adc08166a312608110928060000066a301b110a6a083315110c6a08330f110b6a032d04166a2b0108fe012b0116280500000609166a32280911092807000006301e11080933191107166a3213110711092807000006186a5bfe0216fe012b011628050000061104166a321c110511043216110611053210110611092807000006fe0216fe012b01162805000006186a08d8186ad6130d1104110dd61109280700000630211105110dd61109280700000630131106110dd611092807000006fe0216fe012b01162805000006032d0e11072d07110409fe012b2b162b281107110b6a3220110720000400006a110b6ad83012110409186a1107d8d61c6a08d8d6fe012b011628050000060720900000006a1a6a110a6ad8d61a6a110b6ad8d6186a1107d8d61f106a110c6ad8d61108d6330f0711092808000006fe0216fe012b0116280500000602060720900000006ada736d0000061310110a8d2800000113111613182b371111111811106f700000069e111111189416311711182c1011111118941111111817da94fe022b04172b01162805000006111817d613181118110a32c3110b8d0500001b1312166a131316131938a300000011106f70000006131a111a163112111a20000800003009111a185d16fe012b011628050000061113111a6ad613131113186a1107d8fe0216fe01280500000611107b52000004111a6a1a6a110b1119da17da6ad8d61f106a110c6ad8d61108d6fe0416fe012805000006111211191110111a6f6e000006a211192c1b7e100000041112111917da9a111211199a6f0300000616fe042b01172805000006111917d613191119110b3f54ffffff1113186a1107d8fe012805000006110b8d300000011314110c8d020000021315166a131616131b383501000011106f70000006131c11106f70000006131d11101a6f6e000006131e111e1691131f111f17321a111f1b3015111e17912d0f111e18912d09111e199116fe012b0116280500000611106f700000061320111c1111111b94fe012805000006141321032c2f111d163210111d110b2f0a1114111d9116fe012b011628050000061114111d179c1112111d9a280b00000613212b0a111d15fe012805000006111f182e1111201632091120185d16fe012b08162b05112015fe012805000006141322112016325811206a11092807000006fe0216fe012805000006111611206ad6131611161108301e11107b5200000411206a1f106a110c111bda17da6ad8d6fe0416fe012b0116280500000611101120110928070000066f6f00000613221115111b111c1121111f11227301000006a2111b17d6131b111b110c3fc2feffff11161108fe012805000006111413231613242b1011231124912805000006112417581324112411238e6932e811106f710000060311091115280d000006131711177b0900000409333811177b0a0000041104332d11177b0b0000041105332211177b0c0000041106331711177b0d0000041107330c11177b0e00000407fe012b011628050000061613252b1f11177b0800000411259a111211259a280c0000062805000006112517d613251125110b32db11171326de0c11102c0711106f2b00000adc11262a000041340000020000001600000032010000480100000c0000000000000002000000aa0200002d030000d70500000c0000000000000013300200220000000900001102502c0c02507b0500000404fe012b01162805000006030428100000060a0206512a861e8d2700000125d04f000004283500000a800f000004730400000680100000042a13300400cf0000000400001102280900000a02037d1100000402047d1200000402057d13000004020e047d14000004020e057d15000004020e067d16000004020e077d17000004020e087d18000004020e097d19000004020e0a7d1a000004020e0d7d1b000004020e0e7d1c000004020e0f7d1d0000040e0b2c070e0c14fe032b01162815000006020e0b6f1000000a740600001b7d1e000004020e0c8e698d0500001b7d1f000004160a2b260e0c069a14fe032815000006027b1f000004060e0c069a6f1000000a740500001ba20617d60a060e0c8e6932d32a1e02280900000a2a2a022d0628350000067a2aba0217320a021f0cfe0216fe012b0116281500000602173302162a02183302172a021f093207021f0b3002192a182a000000133004006100000004000011030416250a540654021f0c3302162a0217320a021f0bfe0216fe012b011628150000060302172e1002182e0c021f092f072068d100002b052067d100005404021a3204021d3114021e2e0d021f092f03172b0b021dda2b06182b030217da54172a000000133005004d000000070000110316320d032000080000fe0216fe012b01162815000006038d270000010a160b2b250206070307da6f2c00000a0c0816310b080307dafe0216fe012b011628150000060708d60b070332d7062a0000001b300200860100000a000011022c09028e691f70fe012b0116281500000673140000060a02732d00000a732e00000a0b071e6f2f00000a7e32000004280c0000062c15076f3000000a19330c076f3000000a1f70fe012b0116281500000606076f3100000a7d2000000406076f3200000a7d2800000406076f3200000a7d2900000406076f3200000a7d2a000004076f3200000a16fe01281500000606076f3300000a7d2b00000406076f3100000a7d2100000406076f3100000a7d2200000406076f3100000a7d2300000406076f3100000a7d2400000406076f3100000a7d2500000406076f3100000a7d2600000406076f3400000a7d2c00000406076f3400000a7d2d00000406076f3400000a7d2e00000406076f3400000a7d2f00000406076f3000000a7d3000000406076f3000000a7d3100000406076f3100000a7d27000004071e6f2f00000a1e8d27000001280c0000062815000006de0a072c06076f2b00000adc067b2800000417301a067b2800000417fe0103330e067b290000041afe0216fe012b01162815000006062a0000411c000002000000240000002d010000510100000a00000000000000133002005c00000000000000027b210000042d52027b220000042d4a027b230000042d42027b240000042d3a027b250000042d32027b260000042d2a027b2c0000042d22027b2d0000042d1a027b2f0000042d12027b300000042d0a027b3100000416fe032a172a133003006500000000000000027b2b00000420fe0000005f2d55027b2200000403304c027b23000004186a027b21000004d8186ad6d6033036027b24000004186a027b21000004d8186ad6d6033020027b25000004186a027b21000004d8186ad6d603300a027b3100000416fe032a172a000000133004003b0500000b000011027b29000004193056027b2a00000419304d027b2b00000420ff0000003540027b2000000420900000006a3232027b20000004027b2a000004172e11027b2a000004182e0820900000006a2b0b027b2a0000042808000006fe0216fe012b01162815000006027b2e0000042d64027b270000042d5c027b21000004166a3252027b22000004166a3248027b23000004166a323e027b24000004166a3234027b25000004166a322a027b26000004166a3220027b2c000004163217027b2d00000416320e027b2f00000416fe0416fe012b01162815000006027b310000042c4a027b310000041f0c301e027b30000004027b310000042816000006330b027b2f00000416fe022b01162815000006027b3100000417330b027b2800000417fe012b011728150000062b19027b2f0000042d0b027b3000000416fe012b01162815000006027b290000042c09027b29000004183370027b2000000420900000006a330b02281a00000616fe012b01162815000006027b290000042d1a027b2a0000042d0b027b2b00000416fe012b011628150000062a027b2a000004192e09027b2b000004173316027b2b0000042c0b027b2b00000417fe012b04172b011628150000062a027b2a000004172e09027b2a00000418330d027b2b000004175f16fe012b01162815000006027b2a00000428070000060a027b2a00000428060000060b027b2900000417336d027b2000000420900000006a3358027b21000004076a176ad6334b027b2b0000042d43027b220000042d3b027b230000042d33027b240000042d2b027b250000042d23027b260000042d1b027b2c0000042d13027b2d0000042d0b027b3100000416fe012b011628150000062a027b21000004176a324b027b21000004076a3041027b2200000406176ad63035027b2300000406176ad63029027b2400000406176ad6301d027b2500000406176ad63011027b2600000406186a5bfe0216fe012b01162815000006027b2b000004185f16fe030c027b2b0000041a5f16fe030d027b2c0000046a027b210000040816fe036ada0916fe036adafe0216fe012815000006092c0e027b2c00000416fe022815000006082d17092d14027b2c0000046a027b21000004fe012815000006027b2d0000046a027b21000004302a027b2d0000046a027b26000004301b027b2600000420000400006a027b2d0000046ad8fe0216fe012b01162815000006027b310000042c0e027b2c00000416fe022815000006027b2000000420900000006a1a6a027b2c0000046ad8d61a6a027b2d0000046ad8d6186a027b26000004d8d6fe012815000006186a027b21000004d8186ad61304027b2200000406300e027b230000041104d606fe022b01171305027b280000042d36027b2d0000042d23027b260000042d1b027b2b0000041f285f2d10027b23000004027b22000004fe012b0116281500000638e1000000027b23000004027b22000004fe0416fe012815000006027b2300000406176ad62f20027b23000004027b220000041c6a027b21000004d8d6fe0416fe01281500000611053a98000000027b2b0000041e5f16fe031306027b2b0000041f205f16fe031307027b2d0000046a027b21000004110616fe036ada110716fe036adafe0216fe01281500000611072c0e027b2d00000416fe02281500000611062d1811072d14027b2d0000046a027b21000004fe012815000006186a027b26000004d8027b23000004027b22000004da1c6a027b21000004d8dafe0216fe01281500000611052c24027b2d0000042d16027b260000042d0e027b2b0000041f205f16fe012b011628150000060206281b00000628150000062a0013300400060100000c0000110214fe03281500000673140000060a06027b110000047d2800000406027b120000047d2900000406027b130000047d2a00000406027b140000047d2b00000406027b150000047d2100000406027b160000047d2200000406027b170000047d2300000406027b180000047d2400000406027b190000047d2500000406027b1a0000047d2600000406027b1e0000048e697d2c00000406027b1f0000048e697d2d00000406027b1b0000047d2f00000406027b1c0000047d3000000406027b1d0000047d310000040620900000006a1a6a067b2c0000046ad8d61a6a067b2d0000046ad8d6186a067b26000004d8d67d20000004067b2800000417fe0216fe012815000006062a000013300400ee0000000d000011038e69027b2c000004330d048e69027b2d000004fe012b01162815000006160b2b22030794163112072c0c030794030717da94fe022b04172b011628150000060717d60b07038e6932d8166a0a160c2b6904089a2c1e04089a8e2c1804089a8e692000080000300c04089a8e69185d16fe012b011628150000060604089a8e69185b6ad60a06027b26000004fe0216fe012815000006082c177e33000004040817da9a04089a6f0300000616fe042b011728150000060817d60c08048e69329106027b26000004fe012815000006027b310000042c1703027b2f000004280400002b16fe0416fe0128150000062a00001b300300400100000e000011731d00000a0a06281e00000a17731f00000a0b077e320000046f2000000a07196f2100000a071f706f2100000a07027b200000046f2200000a07027b280000046f2300000a07027b290000046f2300000a07027b2a0000046f2300000a07166f2300000a07027b2b0000046f2400000a07027b210000046f2200000a07027b220000046f2200000a07027b230000046f2200000a07027b240000046f2200000a07027b250000046f2200000a07027b260000046f2200000a07027b2c0000046f2500000a07027b2d0000046f2500000a07166f2500000a07027b2f0000046f2500000a07027b300000046f2100000a07027b310000046f2100000a07166a6f2200000a071e8d270000016f2000000a076f2700000a066f2800000a258e691f70fe0128150000060cde14072c06076f2b00000adc062c06066f2b00000adc082a413400000200000013000000170100002a0100000a0000000000000002000000060000002e010000340100000a000000000000001b300300070100000f00001102281d0000060a06281c00000606027b1e000004027b1f000004281e000006731d00000a0b07281e00000a17731f00000a0c0806281f0000066f2000000a027b1e00000413041613052b15110411059413060811066f2500000a110517581305110511048e6932e3027b1f00000413071613052b1f110711059a13080811088e696f2500000a0811086f2000000a110517581305110511078e6932d9086f2700000a076f2800000a0d098e6a067b200000041f206adafe012815000006282900000a1309081109096f2a00000a6f2000000ade0c11092c0711096f2b00000adc086f2700000a076f2800000a130ade14082c06086f2b00000adc072c06076f2b00000adc110a2a00012800000200c40010d4000c0000000002003200bef0000a0000000002002500d5fa000a000000001b300f00200200001000001104281c000006047b2000000420900000006ada0a282900000a0b0703161f7003166f3700000a26047b2c0000048d280000010c047b2d0000048d0500001b0d1613052b5d061a6afe0416fe012815000006021a28180000061306061a6ada0a071106161a1106166f3700000a26081105110616283800000a9e0811059416311511052c0e0811059408110517da94fe022b04172b01162815000006110517d613051105088e69329c166a130416130738c3000000061a6afe0416fe012815000006021a28180000061308061a6ada0a071108161a1108166f3700000a26110816283800000a1309110916311a1109200008000030111109185d2d0b11096a06fe0216fe012b01162815000006110411096ad613041104186a047b26000004d8fe0216fe0128150000060911070211092818000006a20611096ada0a070911079a1611090911079a166f3700000a2611072c197e3300000409110717da9a0911079a6f0300000616fe042b01172815000006110717d613071107098e693f33ffffff06166afe01281500000607168d2700000116166f3900000a26021f202818000006076f3a00000a280c0000062815000006040809281e000006047b28000004047b29000004047b2a000004047b2b000004047b21000004047b22000004047b23000004047b24000004047b25000004047b260000040809047b2f000004047b30000004047b310000047313000006130ade0a072c06076f2b00000adc110a2a411c0000020000001a000000f9010000130200000a00000000000000861e8d2700000125d04f000004283500000a8032000004730400000680330000042aaa02280900000a0314fe03281500000602037d3600000402037b050000047d34000004021a7d350000042a00000013300300490000000000000002280900000a032c17037b1200000419300e037b1100000417fe0216fe012b0116281500000602037d3700000402037b1100000417fe017d3400000402037b120000047d350000042aaa02283b00000a032c0c042c09048e691f70fe012b0116281500000602037d3800000402047d390000042a133005005900000004000011027b3a000004027b390000048e692f3a05027b390000048e69027b3a000004da280a00000a0a027b39000004027b3a000004030406283c00000a02027b3a00000406d67d3a000004062a027b380000040304056f2c00000a2a0a172a0a162a0a162a1a733d00000a7a1a733d00000a7a1a733d00000a7a1a733d00000a7a1a733d00000a7a1a733d00000a7a1a733d00000a7a220203283e00000a2a1b3003005b00000011000011022c077e3f00000a2b01162815000006021f7028180000060a060328190000060b077b290000041a3321020673250000060c0803281000000673230000060dde18082c06086f2b00000adc020607282100000673240000062a092a0001100000020032000f41000a000000001330020096000000000000000214fe032815000006027b350000041a3337027b360000042c1d027b370000042d15027b360000047b05000004027b34000004fe012b01162815000006027b36000004280e0000062a027b370000042c33027b360000042d2b027b370000047b1100000417fe01027b340000043315027b370000047b12000004027b35000004fe012b01162815000006027b3700000428200000062a000013300200220000001200001102502c0c02507b3400000404fe012b01162815000006030428320000060a0206512a2e7241000070734000000a2a2e7277000070734000000a2a2a022d0628350000067a2a00000013300200630200001300001102395702000002280d00000a0a06195945090000003600000053000000cd00000066010000050000002402000024020000540100000c010000381f0200000218280e00000a0b071f453512071f442e77071f453b840000003800020000071f4f2e50071f503b8700000038ee0100000216280e00000a0b071f4b3b9c000000071f523ba900000038d10100000216280e00000a0b071f4b594504000000aa000000ce000000b0010000bc00000038ab0100000272b3000070284100000a3aef00000038960100000272c3000070284100000a3ae600000038810100000272d3000070284100000a3ae9000000386c0100000272e3000070284100000a3ada00000038570100000272f3000070284100000a3aa100000038420100000272ff000070284100000a3a98000000382d010000027207010070284100000a3a8f000000381801000002720f010070284100000a2d773806010000027227010070284100000a2d7d38f4000000027231010070284100000a2d7138e200000002723b010070284100000a2d7138d0000000027245010070284100000a2d5338be00000002725b010070284100000a2d4738ac00000072690100702a72a30100702a72d50100702a720f0200702a72410200702a72730200702a72a10200702a72d70200702a720d0300702a72410300702a72750300702a72b90300702a031759450c0000000200000002000000080000000e0000000e0000000e0000000e000000140000001a0000001a0000001a000000200000002b2472ed0300702a72230400702a725d0400702a72950400702a72c90400702a720f0500702a28350000067a28350000067ad202734200000a7d49000004027304000006734300000a7d4a00000402734400000a7d4b00000402280900000a02037d3b0000042a86027b3c000004172e0b027b3c00000418fe012b01172837000006027b3c0000042a3602283a000006b428070000062a3602283a000006b428060000062a2e0203176ad6284500000a2abe02166a321303166a320e0321ffffffffffffff7ffe042b011628370000060203186a5b3005186a02d82a03176ad62a000013300400aa000000140000110302283b000006283e0000060a0402283b000006283e0000060b02027b4400000406d602283b000006283d0000067d4400000402027b4500000406d607d6027b3b0000042d03162b011c6ad602283b000006283d0000067d4500000402027b4600000405720f000070284100000a2d03062b021e6ad6057201000070284100000a2d03162b011a6ad607d6027b3b0000042d03162b011c6ad602283b000006283d0000067d460000042a0000133002004f00000000000000027201000070284100000a2d3602720f000070284100000a2d2b027219000070284100000a2d20027229000070284100000a2d15027237000070284100000a2d0a2b0a172a182a192a1a2a1b2a162a3e027b4200000416fe0128370000062a3a02177d420000040228430000062a0000133008007900000015000011020202020202166a250a7d4800000406250a7d4700000406250a7d4600000406250a7d4500000406250a7d44000004067d430000040202020216250b7d4000000407250b7d3f00000407250b7d3e000004077d3d000004027b490000046f4600000a027b4a0000046f4700000a027b4b0000046f4800000a2a8e027b4a0000046f4700000a02166a7d4800000402027b3d0000041fdf5f7d3d0000042a36186a027b43000004d8186ad62a0013300200b300000000000000027b3d0000041c5f2c0672c30000702a027b3d0000041e5f2c0672ff0000702a027b3d0000041f105f2c06720f0100702a027b4400000402283b000006310672070100702a027b45000004022845000006d602283b000006310672d30000702a027b3d0000041f205f2c0672e30000702a027b3d0000041f405f2c0672270100702a027b3d00000420800000005f2c0672310100702a027b46000004022845000006d602283b000006310672450100702a142a00133002007b00000016000011022841000006027b410000042d09027b3c00000419330672b30000702a027b3c0000042d0672410500702a027b4300000402283c0000066a310672f30000702a0228460000060a062c02062a027b400000042c06723b0100702a027b47000004022845000006d602283b0000063106725b0100702a724d0500702a0013300500d100000015000011027b410000042d09027b3c0000041933070228430000062a027b3c0000042d070228430000062a027b4300000402283c0000066a311902283c0000066a176ad60a02284300000602067d430000042a027b4400000402283b0000063015027b45000004022845000006d602283b00000631060228440000060228460000062c2302020216250b7d4000000407250b7d3f000004077d3e00000402166a7d470000042b10027b400000042c0802166a7d47000004022847000006724d050070284900000a2c0b027b4b0000046f4800000a2a000000133002004b00000000000000027b400000042c2d03027b3e000004322403027b3e000004333004027b3f000004321204027b3f000004331e05027b400000042f1502037d3e00000402047d3f00000402057d400000042a4a026f4a00000a2d07026f4b00000a2a166a2a0000133005007400000017000011026f4a00000a2d1903166a32140320ffffff7f6a300b026f4b00000a03fe012b0116283700000603b78d2a0000010a166a0b2b3520008000006a0307da284500000ab70c02070607b7086f4c00000a0d09166a310a09086afe0216fe012b011628370000060709d60b070332c706730f00000a2a133006005704000018000011022841000006042c0a052c070e0414fe032b011628370000060f05284d00000a2d1d0f05284e00000a172e100f05284e00000a182e03162b07182b04172b01160a02027b3c00000406607d3c00000402027b410000040616fe01607d41000004027b410000042d09027b3c0000041933070228480000062a02027b43000004176ad602283c0000066a283d0000067d43000004027b4300000402283c0000066a31070228480000062a0f01284f00000a2d0c0f01285000000a16fe022b01160b072c24027b490000040f01285000000a6f5100000a2d1e02027b3d0000041a607d3d0000042b0e02027b3d00000418607d3d000004027b3b0000042d04166a2b0604284a0000060c05284a0000060d0e04284a0000061304027b3b0000042c19046f4a00000a2d0e082c0b0820000400006afe022b04172b01161305056f4a00000a2d07091d6afe022b011711052c0e02027b3d0000041e607d3d000004252c0f02027b3d0000041f10607d3d0000041104166a320f08166a320a09166afe0416fe012b011628370000062d090509284b0000062b0114130611062840000006130711072d0f02027b3d0000041f40607d3d0000041106720f000070284100000a0e046f4a00000a2e1202027b3d0000042080000000607d3d000004021104081106283f000006141308027b4400000402283b0000063015027b45000004022845000006d602283b00000631080228440000062b4c027b3b0000042c4411052d400408284b00000613081108280a000006130b027b4a000004110b6f5200000a2c1002027b4800000408d67d480000042b0f02027b3d0000041f20607d3d0000040228460000062c070228480000062a0e046f4a00000a2d0b0e041104284b0000062b01141309027b3b0000041108110611091716281400000a130a110a7b1500000a2d6a02027b47000004110a7b1900000ad602283b000006283d0000067d47000004027b400000043a81010000027b47000004022845000006d602283b0000063d69010000072837000006027b4b0000040f01285000000a11081107110973010000066f5300000a384101000007393b010000110a7b1500000a2067d100003352110a7b5400000a173348027b3b0000042c1e171108720f000070141716281400000a7b1500000a2067d10000fe012b0116130c020f01285000000a110c16fe01110c2d03182b0117284900000638db000000110a7b1500000a2068d100003352110a7b5400000a17320f110a7b5400000a1cfe0216fe012b01162837000006020f01285000000a18110a7b5400000a172e18110a7b5400000a182e0b110a7b5400000a17d62b041e2b011928490000062b7b110a7b1500000a2067d100003338110a7b5400000a18320f110a7b5400000a1afe0216fe012b01162837000006020f01285000000a19110a7b5400000a1dd628490000062b35110a7b1500000a20900300003321110a7b5400000a17fe012837000006020f01285000000a181f0c28490000062b0628350000067a0228480000062a001b300500c102000019000011022841000006032c10037b3b000004027b3b000004fe012b01162837000006036f410000060203330702284e0000062a02027b3c000004037b3c000004607d3c00000402027b41000004037b41000004607d41000004027b410000042d09027b3c0000041933070228480000062a027b3c0000042d012a02027b43000004037b43000004d602283c0000066a283d0000067d43000004027b4300000402283c0000066a31070228480000062a02027b3d000004037b3d000004607d3d00000402027b44000004037b44000004d602283b000006283d0000067d4400000402027b45000004037b45000004d602283b000006283d0000067d4500000402027b46000004037b46000004d602283b000006283d0000067d4600000402027b47000004037b47000004d602283b000006283d0000067d47000004037b490000046f5500000a0a2b241200285600000a0b027b49000004076f5100000a2d0e02027b3d0000041a607d3d0000041200285700000a2dd3de0e1200fe160a00001b6f2b00000adc027b4400000402283b0000063015027b45000004022845000006d602283b00000631080228440000062b6b037b4a0000046f5800000a0c2b441202285900000a6f1000000a740500001b0d027b4a000004096f5200000a2c1502027b48000004098e69185b6ad67d480000042b0f02027b3d0000041f20607d3d0000041202285a00000a2db3de0e1202fe160b00001b6f2b00000adc037b400000042c1802037b3e000004037b3f000004037b4000000428490000060228460000062d7a027b400000042d72027b47000004022845000006d602283b000006305d037b4b0000046f5b00000a13042b351204285c00000a1305027b4b00000411057b0100000411057b0200000411057b0400000411057b0300000473010000066f5300000a1204285d00000a2dc2de0e1204fe160c00001b6f2b00000adc0228480000062a00000001280000020043013174010e000000000200b901510a020e0000000002006a0242ac020e00000000133003002501000000000000027b410000042d09027b3c0000041933070228480000062a027b3c0000042d012a02186a027b43000004d802283c0000066a283d0000067d43000004027b4300000402283c0000066a31070228480000062a02186a027b44000004d802283b000006283d0000067d4400000402186a027b45000004d802283b000006283d0000067d4500000402186a027b46000004d802283b000006283d0000067d4600000402186a027b47000004d802283b000006283d0000067d47000004027b490000046f5e00000a16310e02027b3d0000041a607d3d000004027b4400000402283b0000063015027b45000004022845000006d602283b00000631080228440000062b1d027b4a0000046f5f00000a16310f02027b3d0000041f20607d3d0000040228480000062a0000001b300500850100001a000011022841000006027b3b00000473390000060a06027b3c0000047d3c00000406027b410000047d4100000406027b430000047d4300000406027b440000047d4400000406027b450000047d4500000406027b460000047d4600000406027b470000047d4700000406027b480000047d4800000406027b3d0000047d3d00000406027b3e0000047d3e00000406027b3f0000047d3f00000406027b400000047d40000004027b490000046f5500000a0b2b151201285600000a0c067b49000004086f5100000a261201285700000a2de2de0e1201fe160a00001b6f2b00000adc027b4a0000046f5800000a0d2b211203285900000a1304067b4a00000411046f1000000a740500001b6f5200000a261203285a00000a2dd6de0e1203fe160b00001b6f2b00000adc027b4b0000046f5b00000a13052b351205285c00000a1306067b4b00000411067b0100000411067b0200000411067b0400000411067b0300000473010000066f5300000a1205285d00000a2dc2de0e1205fe160c00001b6f2b00000adc062a000000012800000200ae0022d0000e000000000200ea002e18010e00000000020033014275010e00000000133004005f00000000000000022847000006724d050070284100000a2c16027b4b0000046f6000000a6a027b43000004fe012b01162837000006027b4b0000046f6100000a257e56000004252d17267e55000004fe0678000006731100000a258056000004280100002b2a0013300600250100001b0000110228470000060a067241050070284100000a2c14027b3b0000042d0672590500702a725f0500702a06724d050070284900000a2c1206027b400000042838000006734000000a7a0228500000060b027b47000004022845000006d6186a5bb7736200000a0c08027b3b0000042d041f5b2b021f7b6f6300000a26160d2b6707099a1304027b3b00000411047b0200000411047b04000004280900000611047b030000041717281400000a130511057b1500000a2d0c11057b6400000a14fe032b01162837000006092c09081f2c6f6300000a260811057b6400000a6f6500000a260917d60d09078e69329308027b3b0000042d041f5d2b021f7d6f6300000a26186a086f6600000a6ad8027b47000004022845000006d6fe012837000006086f6700000a2a0000001b300f009a0100001c0000110228470000060a06724d050070284100000a2c75027b3b00000402283a000006b4022850000006280d000006130511057b09000004027b44000004333e11057b0a000004027b45000004332f11057b0b000004027b46000004332011057b0c000004027b47000004331111057b0d000004027b48000004fe012b01162837000006110573230000062a067241050070284100000a2d230672f3000070284100000a2d130672b3000070284100000a2d03192b07182b04172b01160b027b490000046f5e00000a8d280000010c027b49000004086f6800000a027b4a0000046f5f00000a8d0500001b0d161304027b4a0000046f5800000a13062b1e1206285900000a13070911042517d6130411076f1000000a740500001ba21206285a00000a2dd9de0e1206fe160b00001b6f2b00000adc027b3b00000416fe03b407027b3c000004b4027b3d000004027b4100000416fe0360b8027b43000004027b44000004027b45000004027b46000004027b47000004027b480000040809027b3e000004027b3f000004b6027b40000004b6731300000673240000062a0000011000000200f9002b24010e0000000013300500460200001d0000110214fe03283700000602283300000626027b3400000473390000060a027b350000041a40fa000000027b360000040b0714fe03283700000606077b060000047d3c00000406077b070000048e696a7d4300000406077b090000047d4400000406077b0a0000047d4500000406077b0b0000047d4600000406077b0c0000047d4700000406077b0d0000047d48000004077b070000040c160d2b4808099a1304067b4900000411047b010000046f5100000a26067b4b00000411047b0100000411047b0200000411047b0400000411047b0300000473010000066f5300000a0917580d09088e6932b2077b080000041305160d2b221105099a1306067b4a00000411066f1000000a740500001b6f5200000a260917580d0911058e6932d7381c010000027b370000041307110714fe0328370000060611077b130000047d3c0000040611077b14000004175f16fe037d410000040611077b150000047d430000040611077b160000047d440000040611077b170000047d450000040611077b180000047d460000040611077b190000047d470000040611077b1a0000047d480000040611077b1400000420fe0000005f847d3d0000040611077b1b0000047d3e0000040611077b1c0000047d3f0000040611077b1d0000047d4000000411077b1e0000041308160d2b18110809941309067b4900000411096f5100000a260917580d0911088e6932e111077b1f0000041305160d2b221105099a130a067b4a000004110a6f1000000a740500001b6f5200000a260917580d0911058e6932d7066f48000006062a360203283200000628530000062a13300400180000001e00001102285200000628330000060a030616068e696f6900000a2a920275140000012d100275350000012d080275360000012c0628350000062a28360000062a56022c0b027b4200000416fe012b011628370000062a001b3002001c0000000000000002147d4c000004021673390000067d4c000004de0628560000067a2a01100000000007000e1500061c0000011b3006003c00000000000000027b4c0000042857000006027b4c00000403286a00000a04050e046f4c000006de19027b4c0000042c0b027b4c0000046f4200000628560000067a2a0110000000000000222200191c0000011b3002004c00000000000000027b4c00000428570000060314fe032837000006037b4c0000042857000006027b4c000004037b4c0000046f4d000006de19027b4c0000042c0b027b4c0000046f4200000628560000067a2a0110000000000000323200191c0000011b300200740000001f000011027b4c0000042857000006027b4c0000046f470000060a06724d050070284900000a2c24067241050070284900000a2c1706027b4c0000047b400000042838000006734000000a7a00027b4c0000046f510000066f6b00000a736c00000a0bde11027b4c0000046f4200000628560000067a072a0110000000004900186100111c0000011b30020026000000200000110314fe032837000006036f6d00000a1628540000060a02067d4c000004de0628560000067a2a000001100000000000001f1f00061c0000011b300200350000001e000011027b4c00000428570000060314fe032837000006027b4c0000046f5200000628330000060a03066f2000000ade0628560000067a2a00000001100000000000002e2e00061c0000011e02280900000a2a1b3002001c0000000000000002147d4d000004021773390000067d4d000004de0628560000067a2a01100000000007000e1500061c0000011b3006003900000000000000027b4d0000042857000006027b4d0000040304050e040e056f4c000006de19027b4d0000042c0b027b4d0000046f4200000628560000067a2a00000001100000000000001f1f00191c0000011b3002004c00000000000000027b4d00000428570000060314fe032837000006037b4d0000042857000006027b4d000004037b4d0000046f4d000006de19027b4d0000042c0b027b4d0000046f4200000628560000067a2a0110000000000000323200191c0000011b300200740000001f000011027b4d0000042857000006027b4d0000046f470000060a06724d050070284900000a2c24067241050070284900000a2c1706027b4d0000047b400000042838000006734000000a7a00027b4d0000046f510000066f6b00000a736c00000a0bde11027b4d0000046f4200000628560000067a072a0110000000004900186100111c0000011b30020026000000200000110314fe032837000006036f6d00000a1728540000060a02067d4d000004de0628560000067a2a000001100000000000001f1f00061c0000011b300200350000001e000011027b4d00000428570000060314fe032837000006027b4d0000046f5200000628330000060a03066f2000000ade0628560000067a2a00000001100000000000002e2e00061c0000011e02280900000a2a2a022d0673790000067a2a6e0214fe032866000006026f4a00000a2d07026f4b00000a2a166a2a00133005008500000017000011022c21026f4a00000a2d1903166a32140320000080006a300b026f4b00000a03fe012b0116286600000603b78d2a0000010a166a0b2b3520008000006a0307da284500000ab70c02070607b7086f4c00000a0d09166a310a09086afe0216fe012b011628660000060709d60b070332c7026f4b00000a03fe01286600000606730f00000a2a8a736e00000a25027d1600000a25037d1700000a25047d1500000a25057d5400000a2a13300200c800000000000000027b1500000a2d02162a027b1500000a2063d100002e1a027b1500000a2065d100002e0d027b1500000a2066d1000033021b2a027b1500000a2067d10000334a027b5400000a173322027b6f00000a172e0b027b6f00000a18fe012b01172866000006027b6f00000ab42a027b5400000a18320e027b5400000a1afe0216fe012b011628660000061a2a027b1500000a2068d10000332b027b5400000a172e1a027b5400000a19320e027b5400000a1cfe0216fe012b04162b01172866000006192a73790000067a1b3006009a020000210000110f00287000000a2d310f04284d00000a2d280f05284d00000a2d1f0f04284e00000a2c0a0f04284e00000a17330c0f05284e00000a17fe012b01162866000006032c09042c060514fe032b011628660000060f00287100000a0a062d04166a2b060328670000060b0528670000060c0428670000060d07166a320f08166a320a09166afe0416fe012b01162866000006186a08d81304186a07d81305062c2a036f4a00000a2d0c072c090720000400006a3116110411052063d1000017286900000613063846010000046f4a00000a2d05091d6a3116110411052065d100001828690000061306382301000004092868000006130911097201000070284900000a2c4e1109720f000070284900000a2c4011097219000070284900000a2c3211097229000070284900000a2c2411097237000070284900000a2c16110411052065d10000172869000006130638be0000001109720f000070284100000a056f4a00000a2e16110411052066d10000172869000006130638940000000820000080006a310b7265050070734000000a7a062d03142b0703072868000006130a056f4a00000a2d09050828680000062b0114130b0f04284e00000a2c1006110a1109110b1617281400000a2b0c06110a1109110b287200000a13060f04284e00000a17332c11097237000070284100000a2c1e11067b1500000a2068d10000331011067b5400000a18330673790000067a1106286a00000613070f04284e00000a2d1911067b6400000a2d0d11067b1900000a166afe012b04162b011728660000060f04284e00000a17331511067b1500000a2d0c11067b6400000a14fe032b0117286600000611061107737a0000061308178d0700000125161108a2130cde182672a5050070734000000a7a267265050070734000000a7a110c2a00004134000000000000000000007f0200007f0200000c0000001600000200000000000000007f0200008b0200000c0000001c0000011330020077000000220000110275170000020a062d0b72a5050070734000000a7a03067b570000045104067b58000004811700000105067b5900000481170000010e04067b5a00000481180000010e05067b5b00000481250000010e06067b5c00000481250000010e07067b5d00000481250000010e08067b5e00000481250000012ace02280900000a02037d5000000402057d5200000402282900000a7d51000004027b510000040416048e6904166f3700000a262a0013300600520000001e00001103163217032000800000300f036a027b52000004fe0216fe012b01162805000006027b5000000403280f0000060a02027b52000004036ada7d52000004027b510000040616068e6906166f3700000a26062a0000133006007b000000230000110316321903185d2d14036a04300f036a027b52000004fe0216fe012b0116280500000603185b8d2a0000010a160b2b4020008000000307da280a00000a0c0208286e0000060d1613042b1c06071104d6185b0911049109110417d6911e6260b69d110418d6130411040832df0708d60b070332bc06730f00000a2a0013300300200000001e000011021a286e0000060a0616910617911e62600618911f1062600619911f1862602a133004004600000000000000027b52000004166afe012805000006027b51000004168d2700000116166f3900000a26027b500000041f20280f000006027b510000046f3a00000a280c00000628050000062a32027b510000046f7300000a2a2e737400000680530000042a1e02280900000a2a00133002002400000004000011032c060414fe032b01162805000006037b010000040a1200047b01000004280c00000a2a2e737700000680550000042a1e02280900000a2a133002001500000004000011037b010000040a1200047b01000004280c00000a2a320272a5050070284000000a2a000013300200690100000000000002280900000a032c35037b1500000a16322c037b5400000a163223037b1600000a166a3219037b1700000a166a320f037b1900000a166afe0416fe012b01162866000006037b1500000a2c19037b5400000a16310d04173209041bfe0216fe012b12162b0f037b5400000a2d060416fe012b01162866000006037b1500000a2c17037b6400000a2d0c037b1900000a166afe012b04162b01172866000006037b6400000a2c1c186a037b6400000a6f0d00000a6ad8037b1900000afe01286600000602037b6400000a2c12037b6400000a6f6b00000a736c00000a2b05286a00000a7d5700000402037b1500000a737400000a7d5800000402037b5400000a737400000a7d590000040204737500000a7d5a00000402037b1600000a737600000a7d5b00000402037b1700000a737600000a7d5c00000402037b7700000a2d077e7800000a2b0b037b1800000a737600000a7d5d00000402037b1900000a737600000a7d5e0000042a00000042534a4201000100000000000c00000076342e302e33303331390000000005006c00000084140000237e0000f01400003c0c000023537472696e6773000000002c210000e80500002355530014270000100000002347554944000000242700003409000023426c6f620000000000000002000001571fa229090a000000fa0133001600000100000036000000170000005e0000007a000000af0000000400000078000000010000000b0000002300000002000000090000000a0000000c000000010000000100000004000000050000000400000000006b060100000000000600b60402090600d604020906003804e7080f002209000006004c0420070600840420070600c70ae2060600480082010600600082010a00ec0a4c0a0600c90631010600810831010600ab00da0b0600cf0631010600130831010600a802e20606001d04020906003b00e20606001507310106009607e2060e00540082011200240a410912007c0041091200060541095700cf0800002700cf08000006005008590b0600a607e2061200ba0aa20812006304a20812002d05a2081200a104a20812001a02a20812001402a20806009502070a1200f70641091200970041090600c605e20606000905e20606008700e20606007305e2060600ef07e2060600ac0be2060a0012034c0a0a00b20b4c0a06005e05590b0600e906da0b0600fa06e2060600330a02090600b402e20606009508e20606006b07e2060e00560731010600810731010000000000010000000001000100010110000e0c4c0a1d000100010001011000d5034c0a1d00050002000101100066084c0a1d000f0003008101100066014c0a1d000f00050001011000e7034c0a1d00110013000101100007084c0a1d00200014008101100071014c0a1d003200150001011000f2034c0a1d003400230001011000b6064c0a3900380025008101100070084c0a1d003b00320081011000420a4c0a1d003b003500010110003a084c0a1d003b00390080011000fc0b4c0a1d004c00560001211000ad034c0a1d004c0058000121100099034c0a1d004d005f008101100072024c0a1d004e00660000010000090100001d004f006d0003011000190800001d0050006d0003211000620100001d005300730003211000620100001d0055007600030110003a030000510057007900030110007f0b00001d0057007a0026004f06b2002600d20b370326001205370326002402e3032600490252022600da02e30326003109e6032600ac0aeb0326006e0bb50026000603b50026008405b5002600420bb5002600890ab50026006d09b50031007c01f00331006a08f40326005a02e3032600660ae30326003706e3032600ee09f80326002f01b50026006e0bb50026000603b50026008405b5002600420bb5002600890ab50026004f06b20026006203fb0326005605fb032600fa08fe032600ac0aeb0306005f06b50006002f01b50006006e0bb50006000603b50006008405b5000600420bb5000600890ab50006006009b50006005a02e3030600660ae30306003706e3030600ee09f8030600fd05b20006000006b2000600d107b20006004f06b20006006203fb0306005605fb0331007c01f00331006a08f40326005a0252022600660ae3032600f10102042600e00a06042100cd0b0a0421002008f0030100dd01b20023004902520203003706b2000300ee09b20003004b06b20003004a03b20003005205b2000300d30252020300d401520203002f01b50003006e0bb50003000603b50003008405b5000300420bb5000300890ab5002100fe080e042100b10a15042100b7011d0401005e08250401005e08250451806c0ab5003301b200b5002100d6060a042100b405290406006705b5003600fc002d041600010031043600fc00390416001a0031042300fc0a3d042300f90741042300fb03410423006203450423006e0bcc032300d20bcc0323008405cc032300420bcc035020000000008618da08490401007820000000008618da0851040500d82000000000e6010a0363040f002021000000008618da08060011002821000000009600cf016b04110033210000000096002c01700412005421000000009600e107750413007721000000009600dc07750414009c2100000000960024027a041500ec210000000096008c0a7f0416004822000000009600690b85041700942200000000960065068b041800c422000000009600fd0193041a00382500000000960017049d041d00fc28000000009100c10aa4041e005829000000009600a401ac042000802f000000009600c807b4042200ae2f000000009118e008be042500d02f000000008618da08c2042500ab30000000008618da0806003400b330000000009600cf016b043400be30000000009600bd08d8043500f0300000000096009d06dd0436006031000000009600c10aa4043900bc310000000096007603e6043b006c330000000091005101ee043d00d433000000009100ce0af4043e0048340000000096007c03fb0440009039000000009100760b01054100a43a000000009100fe0908054200a03b000000009100a50913054500203d00000000960017041a0546005c3e000000009600c40b21054700a440000000009118e008be044a00c640000000008618da082c054a00f440000000008618da0832054b004941000000008618da0838054c00744100000000c600a40149014e00d94100000000c6089d0197025100dc4100000000c608100497025100df4100000000c608260697025100e24100000000c608cb0598015100e94100000000c6083c0798015100f04100000000c608490712015100f74100000000c600c00506005200fe4100000000c6002d0640055200054200000000c600e205120154000c4200000000c60017047e035500134200000000c4006e03420258001c42000000009600a40147055900944200000000960017044f055b003843000000009600c80756055c006643000000009600fb0360055f0072430000000096002e0260055f007e43000000009600cf016b045f008c43000000009600640265056000fb45000000008618da08420262003046000000008108c7023f0063005246000000008108d40798016300604600000000810828013f0063006e46000000009100b60a830263007a460000000093007a0a83026500ac46000000008100980a6b0567006447000000009100fd0472056a00bf47000000008100a10206006b00cf47000000008600b00706006b00e047000000008100470106006b006548000000008100a70a06006b008948000000008108830b98016b009848000000008100870340036b005849000000008600f00240036b00e0490000000081003e0506006b00c04a000000008100320677056b00174b000000009100ef057e056e002c4b000000009100f70b84056f00ac4b000000008600bf018b05710010500000000086008a029905760008530000000081004805060077003c5400000000860000039f057700f855000000008100a901a40577006456000000008600b9054003770098570000000086002d0baa0577005059000000009600290baf057700a25b000000009600a401b6057800b05b000000008600170488017a00d45b0000000093004106be057b00f95b0000000093002e08c5057c00105c000000008600db0a06007d00485c000000008600c003cb057d00a05c0000000086008a02d7058100085d000000008600cb03dd058200985d00000000e601a401e2058200dc5d00000000e6011704e8058300305e000000008618da0806008400385e000000008600db0a06008400705e000000008600c0038b058400c85e0000000086008a02ee058900305f000000008600cb03dd058a00c05f00000000e601a401e2058a00046000000000e6011704e8058b005860000000008618da0806008c006060000000009100cf016b048c006b60000000009100ef057e058d008860000000009100f70b84058e0019610000000091002305f40590003c610000000091006203fd0594001062000000009600070403069500ec640000000096007b0b16069b006f65000000008618da083706a400a46500000000860090028e01a7000466000000008600c3014006a8008c66000000008600f80a3f00aa00b866000000008600b9050600aa000a6700000000e6016e030600aa001767000000009118e008be04aa002367000000008618da080600aa002c670000000083000b004606aa005c67000000009118e008be04ac006867000000008618da080600ac00706700000000830024004606ac009167000000008318da080600ae00a067000000008318da084e06ae0000000100570600000200d60b000003002902000004001805000001005f0200000200e20200000300390900000400b10a00000500720b000006003603000007008b0500000800490b00000900920a00000a00ea0200000100570100000200600100000100600100000100e70700000100e70700000100e707000001003f06000001001805000001006001000001005701000002006001000001005f0200000200e202000003003c0b00000100010400000100b40a00000200b50700000100d606000002003c02000001001e0500000200d606000003003c02000001005f0200000200fa09000003003c0600000400f40900000500b50700000600720b000007003603000008008b0500000900490b00000a00920a00000b00fe0800000c00b10a00000d00570600000e00680300000f005a05000001006001000001005a05000001005a0502000200000802000300010400000100b40a00000200b50700000100e80900000200370b00000100fb0500000100fb0500000200e50700000100fb0500000100b40a00000100fb0500000200fe0800000300b10a00000100fb0500000100b40a00000100d60600000200200800000300fb0500000100f70100000100e60a00000100300200000200e80900000100600100000200cf0700000300b50700000100180500000100cf0700000200b40a00000100b50700000100600100000200cf0700000300b507000001007a0500000100d606000002003c02000001000104000001001e0500000200d606000003003c0200000100320700000100f802000002005a05000001005f0200000100180500000200e50700000100920a00000200e50700000100d60500000200ec0500000300650b000001002902000001005706000002006803000003005a05000001002d0a000001002d0a00000200f60500000100570600000200d60b00000300290200000400180500000500e202000001007b08000001006c0b000001003c0b000002003c0200000100490b00000100c608000001005e08000001005706000002000a0200000300180500000400e202000001001805000001002708000001008e0800000100570600000200d60b000003000a0200000400180500000500e202000001001805000001002708000001008e08000001001805000001008c0b000001008c0b00000200e20100000100720b00000200d60b00000300000800000400010400000100e50800000100540200000200d60b000003000a02000004001805000005006c0200000600bd0b00000100dd0602000200050b02000300f40702000400dc0302000500540302000600780902000700df0902000800920902000900bf0900000100b40a00000200200800000300cd0b00000100b50700000100e80900000200e50700000100570100000200600100000100570100000200600100000100e508000002006803040006000f007d0010007d00130041000900da0801001100da0806001900da080a002900da0810003100da0810008900da080600f100da081c000101da0806003900da0806003101110729003901b7072f004101b70734004901cb053f0049011a0a43004901da084e005901000376001c00da0885005901240b8b002400da08060061010704a50051003702b2005100cd09b5005100d609b50051008609b5005100b109b5002400bf01b80024009e0bbe005901240bc4005900da0806007101f300f7006100da08fd00610017040701610017040d01610017041201610017041701610017041c016100170401005901920521016100c005060059009e0b31016900920336017901a8053b0181006e0306007100a40149015900da0807017900da088801790056098e017900a000940179008d0098017900f4049c0179006700a001790072003f0089018e0bac0159019205d601790117061a02990185002502790103062c0279019f0531017100da0806005901f70b3502a101da08060071006e034202990102075202a100da0810004901220c5f023c00da0806004400da0872024c00da0806003101110783023c00e90706004400e90706004c00e907060049012e0c5f02b10092069702b100cb059801b100a401a302c10092069702c1000e059c01b90092069702b9000e053f003c00bf01be024400bf01be024c00bf01b8005100fb03b2003c00cc08dd0254000e0bec025400500b97024400cc08dd025c000e0bec025c00500b97024c00cc08f80264000e0bec026400500b97023c001a0b3f0044001a0b3f004c001a0b3f004c009e0bbe00d900da080100d900030231035100fc0a3703d90003023a03d900cb053f003900710540033c00c1075903710017047e03b100890686034901a60b9103b100da084e007900a7069b035100da08060051005f03b20021019206970221010e0597026101150cb40379016e030600b900da080100c100da0817012901da0812015100eb01520229019806cc030a003801da032e000b0061062e0013006a062e001b0089062e00230092062e002b00b106e3013b00b90803023b00b908430233002c09830233002c09a30233002c09600d4300be0622003900480054005800d70042015101a701b901c001cb01d001e401ed010502470255025a0289028e0293029b02ac02c402080323034403600379038b039603a003bd03c2030a0001000d0006000000a101550600001404550600002a0655060000ef05590600004d0759060000da025d060000e107590600002c015d060000870b590602002700030002002800050002002900070002002a00090002002b000b0001002c000b0002003a000d0002003b000f0002003c00110002004500130015007a007e009e00a401b60165026b027c02e602f1020103e89900004f000480000001000300000000000000000000004c0a0000040000000000000000000000d1035901000000000100000000000000000000000000240300000000040000000000000000000000d103e20600000000040000000000000000000000d1033b0100000000130005001400050015000d001600110017001100250099003900d2004d00d2006d00e0010000003c3e395f5f31305f30003c4275696c643e625f5f31305f30003c3e395f5f34345f30003c536f727465645061796c6f61643e625f5f34345f3000436f6d70617269736f6e60310049436f6d7061726572603100536f727465645365746031004c6973746031005265616455496e7433320052656164496e7433320053716c496e74333200546f496e7433320052656164496e7436340053716c496e743634005265616455496e743136005348413235360033424437344638364645383541334544353539344330394130443535333444373032464133354636303933364232443931424330324143344434354433393937006765745f55544638003c3e39003c4d6f64756c653e003c50726976617465496d706c656d656e746174696f6e44657461696c733e006765745f4d61784e0053797374656d2e494f0053797374656d2e4461746100436c6561724461746100416e7944617461006d73636f726c6962003c3e630056616c6964436f646563004661756c74436f646563004d616769630053797374656d2e436f6c6c656374696f6e732e47656e65726963006765745f43616e5265616400536f727465645061796c6f6164007061796c6f6164004164640054657874426f756e646564004e65656400506f69736f6e65640075736564006578706563746564005374726f6e6756616c69640076616c6964004275696c6400417070656e640076616c75654b696e640053797374656d446174614163636573734b696e64006b696e64005265736f7572636500436f64650065787065637465644d6f6465004f626a6563744d6f6465006f626a6563744d6f6465006d6f6465004d657373616765007374616765004a736f6e456e7472794576616c75617465427269646765004d657267650054616b650049456e756d657261626c6500557361626c650049446973706f7361626c650052756e74696d654669656c6448616e646c65006765745f50726f66696c6500496e76616c696450726f66696c650070726f66696c65006672616d65004f7574636f6d65006f7574636f6d6500436c6f6e650050726500436f6d70617265004a736f6e43616e6f6e6963616c436f726500546f6f6c62656c742e4a736f6e436f72650070726500436f6e74726163744661696c7572650052616e6b5068617365006661756c74506861736500526177506861736500706861736500446973706f73650050617273650048656164657247617465004265666f72654c61746500437265617465004a736f6e4f626a656374416767726567617465004a736f6e417272617941676772656761746500416363756d756c617465005465726d696e61746500565374617465006572726f725374617465004661756c745374617465005472616e73706f72745374617465007374617465004576616c75617465006765745f43616e577269746500436f6d70696c657247656e6572617465644174747269627574650044656275676761626c6541747472696275746500417373656d626c795469746c654174747269627574650053716c55736572446566696e656441676772656761746541747472696275746500417373656d626c7946696c6556657273696f6e4174747269627574650053716c46756e6374696f6e41747472696275746500436f6d70696c6174696f6e52656c61786174696f6e734174747269627574650052756e74696d65436f6d7061746962696c697479417474726962757465005265616442797465004b696e64427974650053716c42797465006765745f56616c75650076616c7565006c69766500446566656e73697665004942696e61727953657269616c697a65004e6f726d616c697a65004d6572676553656c660052616e6b5461670074616700456e636f64696e670052656d61696e696e6700546f537472696e6700646973706f73696e67005374726f6e67007374726f6e670042696e617279536561726368006765745f4861736800436f6d707574654861736800686173680046696e69736800466c757368004d617468006765745f4c656e6774680076616c75654c656e677468005365744c656e677468006b65794c656e677468006c656e677468004e69004e6b005472616e73666f726d46696e616c426c6f636b005472616e73666f726d426c6f636b006765745f43616e5365656b0052616e6b004d61736b006d61736b00546563686e6963616c0052616e6b4f7264696e616c006f7264696e616c00546f74616c00457175616c00546f6f6c62656c742e4a736f6e436f6e7374727563746f72732e646c6c006765745f4e756c6c006765745f49734e756c6c004c656761637953716c006765745f4261736553747265616d004865616465725265706c617953747265616d004d656d6f727953747265616d0073747265616d006974656d0053797374656d0048617368416c676f726974686d0053716c426f6f6c65616e0049734c6974746c65456e6469616e004d696e005365656b4f726967696e0053797374656d2e5265666c656374696f6e00636f6e646974696f6e006765745f506f736974696f6e007365745f506f736974696f6e00496e76616c696444617461457863657074696f6e004e6f74537570706f72746564457863657074696f6e00456e644f6653747265616d457863657074696f6e00496e76616c69644f7065726174696f6e457863657074696f6e00506f69736f6e00436f6d70617265546f00436f7079546f0052656164496e746f004e70006765745f4361700053746174654361700063617000436c6561720043686172006572726f724e756d626572006e756d626572004661756c744865616465720042696e6172795265616465720068656164657200726561646572004e6565644275696c646572004f776e65644167677265676174654275696c64657200537472696e674275696c646572006275696c64657200427974654f726465720044697370617463686572006f746865720042696e6172795772697465720077726974657200426974436f6e766572746572004d6963726f736f66742e53716c5365727665722e536572766572005068617365466f72006572726f7200476574456e756d657261746f72002e63746f72002e6363746f720053797374656d2e446961676e6f737469637300496473006964730053797374656d2e52756e74696d652e436f6d70696c6572536572766963657300446562756767696e674d6f64657300456e747269657300656e74726965730053797374656d2e446174612e53716c547970657300526561644279746573005061796c6f61644279746573004672616d6542797465730072617756616c75654279746573005374726f6e674279746573007374726f6e674d696e696d756d427974657300486561646572427974657300467261676d656e74427974657300667261676d656e744279746573005261774279746573004b65794279746573006b6579427974657300627974657300466c61677300666c61677300636c730053656374696f6e730053797374656d2e436f6c6c656374696f6e73006765745f43686172730053716c43686172730063686172730052756e74696d6548656c70657273004167664572726f727300546f6f6c62656c742e4a736f6e436f6e7374727563746f727300436c617373004d617856616c7565556e69747300427974657346726f6d556e697473004b6579556e69747300756e697473004164644c656e677468436f73747300436c6561724b657973006b6579730053617400466f726d6174004578616374004f626a656374004c6174654f7242756467657400496e6974004661756c74006661756c7400456e747279526573756c7400496e7400467261676d656e7400667261676d656e74006765745f43757272656e74006765745f436f756e7400536f72740046726f6d5472616e73706f727400686f737400696e707574004f7574707574006f7574707574004d6f76654e6578740053797374656d2e54657874006b696e6454657874005261770072617700566965770046696c6c526f77006765745f53796e74617800496e697469616c697a65417272617900546f417272617900546f436861724172726179004a736f6e506f6c69637900706f6c6963790052656164426f647900626f6479004b6579006b65790053797374656d2e53656375726974792e43727970746f67726170687900436f707900416767726567617465426f756e646172790056456e747279005261774f6e6c79456e747279006f705f457175616c697479006f705f496e657175616c69747900000d73007400720069006e00670000096e0075006c006c00000f62006f006f006c00650061006e00000d6e0075006d0062006500720000096a0073006f006e0000355400420058005f004a0053004f004e005f004100470047005f00530054004100540045005f0049004e00560041004c0049004400003b5400420058005f004a0053004f004e005f004100470047005f005200450053004f0055005200430045005f004600410049004c00550052004500000f500052004f00460049004c004500000f4f005200440049004e0041004c00000f5000520045005f004d0049004e00000f4400550050005f004b0045005900000b43004f0055004e00540000074b0045005900000752004100570000174b0049004e0044005f004c0045004e0047005400480000094b0049004e00440000094e0055004c004c0000094c0041005400450000155300540052004f004e0047005f004d0049004e00000d4f005500540050005500540000395400420058005f004a0053004f004e005f004100470047005f00500052004f00460049004c0045005f0049004e00560041004c004900440000315400420058005f004a0053004f004e005f004100470047005f0045004e005400520059005f004c0049004d004900540000395400420058005f004a0053004f004e005f004100470047005f004f005200440049004e0041004c005f0049004e00560041004c004900440000315400420058005f004a0053004f004e005f004100470047005f004b00450059005f0049004e00560041004c004900440000315400420058005f004a0053004f004e005f004100470047005f004b0049004e0044005f004c0045004e00470054004800002d5400420058005f004a0053004f004e005f004100470047005f005200410057005f004c0049004d004900540000355400420058005f004a0053004f004e005f004100470047005f004d0049004e0049004d0055004d005f004c0049004d004900540000355400420058005f004a0053004f004e005f004100470047005f004400550050004c00490043004100540045005f004b004500590000335400420058005f004a0053004f004e005f004100470047005f004b0049004e0044005f0049004e00560041004c004900440000335400420058005f004a0053004f004e005f004100470047005f004e0055004c004c005f0049004e00560041004c004900440000435400420058005f004a0053004f004e005f004100470047005f005300540052004f004e0047005f004d0049004e0049004d0055004d005f004c0049004d004900540000335400420058005f004a0053004f004e005f004100470047005f004f00550054005000550054005f004c0049004d004900540000355400420058005f004a0053004f004e005f004100470047005f00550054004600310036005f0049004e00560041004c004900440000395400420058005f004a0053004f004e005f004100470047005f0042004f004f004c00450041004e005f0049004e00560041004c004900440000375400420058005f004a0053004f004e005f004100470047005f004e0055004d004200450052005f0049004e00560041004c004900440000335400420058005f004a0053004f004e005f004100470047005f004a0053004f004e005f0049004e00560041004c004900440000455400420058005f004a0053004f004e005f004100470047005f004400450043004f004400450044005f00550054004600310036005f0049004e00560041004c004900440000315400420058005f004a0053004f004e005f004100470047005f00440045005000540048005f004c0049004d0049005400000b45004d00500054005900000b560041004c004900440000055b005d0000057b007d00003f5400420058005f004a0053004f004e005f0045004e005400520059005f005200450053004f0055005200430045005f004600410049004c00550052004500003f5400420058005f004a0053004f004e005f0045004e005400520059005f0041004400410050005400450052005f0043004f004e005400520041004300540000000000057824c9e55d6040a3f9afdfda2cb2c000042001010803200001052001011111042001010e06151221011d0505200101117506070408080808050002080808042001080504200108080507021d05080320000804200103080507021d0308052001011d03030701081d070f1d12080a0a0a0a0a151225011d051d1d050a0812080e12291d05080320001c031d120806151249011208052002011c180d100102011d1e00151249011e00040a01120806151225011d050c00061229020e0e0e1180b50202060802060a0520010113000520001d13000d100102011d1e00151221011e00040a011d051f070f120c08122d12311d051d12080812081d1d051d051208081d0512351d050500001280b90920030112391280b902052001011d050420010107042001010a042001010504200101090f100103081d1e001e00151221011e000420001d0504000012350620011d051d050607031d050808072003081d0508083607271d050a0a0a0a0a0a0a0a050808080a123d05124c1d081d1d050a1d021d12080a120c0808080808081d0505080e0e1d020808120c0520010112390520011d0508032000070320000a0320000503200009021d05040701120c090002011280ad1180c9021d08060702121c123d0a07080a0802020a020202040701121c0507030a080809100102081d1e001e00030a0108080703122d12311d0517070b121c122d12311d051d0808081d1d051d0512351d0514070b0a12351d081d1d050a081d05081d050812180a2005081d0508081d0508060002081d05080820031d051d0508080c0005011280ad081280ad080804200101020a07041d05121c1228122402060204070112240407020803050002020e0e05151255010806151255011d0509200101151221011300061512250112080500020a0a0a0407020a0a0407020a080307010e032000020707041d030a080a0820040a0a1d03080811070d08020a0a0a020e050e0e12291d0502052001021300180706151165010808151165011d051d051511690112081208082000151165011300051511650108042000130006151165011d05082000151169011300061511690112081a07071234151165010808151165011d051d0515116901120812080d07060e1d1208126d0812081229052001126d0302060e052001126d0e0320000e1407080e051d081d1d0508120c151165011d051d05062001011d130018070b1234120c1d12080812081d1d051d0512181d08081d050407011d05072003011d05080804000012590507020e12590420001d030407011234042000123913070d020a0a0a0a0a122905125c0e0e0e12808d0800041229020e0e0e040701125c0907051d0308081d0508040611809508b77a5c561934e08908000080000000000002060504061d120804061d1d0503061d050306121002060902060703061d080306120c0306121803061239060615125501080706151255011d050706151225011208030612340306123503061250070615124901120803061254030612590306115d0306116107200401080e050e11200a0102051d12081d1d050a0a0a0a0a0a072002081d051d05040001010204000108050400010a050400010e050500011d050e0500010e1d05070002021d051d05090003120c02051d12080600011d05120c0700021d05123908070002120c1239020900030110120c1239020300000115200f01050505090a0a0a0a0a0a1d081d1d050807070400010707080003020710081008070002121c1d050205000102121c06000202121c0a05000101121c060001121c12180a000301121c1d081d1d050600011d05121c0600011d0512180a0003121812391d05121c05200101120c0520010112180720020112391d050620020a0a114d07000212241239020600011d0512240900030110122412390204000012510500020e0e08062003010a0a0e040001050e062003010808080500010a12590600020e12590a0d200501115d125912591259116105200101123404200012340520001d12080420001224060001123412240700021234123902060001127112710500010112340b200401115d12591259116105200101123c042000125905200101123d05200101123105200101124008000412290a0a080805000105122912000612808d11809112591259125911611161200009011c10125910115d10115d101161101180951011809510118095101180950820030112391d050a0520020e080a072002081208120806200201122905032800020328000a032800080801000800000000001e01000100540216577261704e6f6e457863657074696f6e5468726f7773010801000200000000001e010019546f6f6c62656c742e4a736f6e436f6e7374727563746f727300000c010007312e332e302e30000081f901000400540e1146696c6c526f774d6574686f644e616d650746696c6c526f77540e0f5461626c65446566696e6974696f6e80a3467261676d656e74206e76617263686172286d6178292c204572726f724e756d62657220696e742c204572726f72537461746520696e742c204661756c7450686173652074696e79696e742c2052617756616c7565427974657320626967696e742c204b6579427974657320626967696e742c205374726f6e674d696e696d756d427974657320626967696e742c20467261676d656e74427974657320626967696e745455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000072010002000000050054080b4d61784279746553697a65ffffffff5402124973496e76617269616e74546f4e756c6c73005402174973496e76617269616e74546f4475706c696361746573005402124973496e76617269616e74546f4f726465720154020d49734e756c6c4966456d70747900040100000000000000000000000000000000000010000000000000000000000000000000b49900000000000000000000ce990000002000000000000000000000000000000000000000000000c0990000000000000000000000005f436f72446c6c4d61696e006d73636f7265652e646c6c0000000000ff25002000100000000054425841474633000000000000000000000000000000000000000000000000000000000000000100100000001800008000000000000000000000000000000100010000003000008000000000000000000000000000000100000000004800000058a00000bc0200000000000000000000bc0234000000560053005f00560045005200530049004f004e005f0049004e0046004f0000000000bd04effe00000100030001000000000003000100000000003f000000000000000400000002000000000000000000000000000000440000000100560061007200460069006c00650049006e0066006f00000000002400040000005400720061006e0073006c006100740069006f006e00000000000000b0041c020000010053007400720069006e006700460069006c00650049006e0066006f000000f801000001003000300030003000300034006200300000005c001a000100460069006c0065004400650073006300720069007000740069006f006e000000000054006f006f006c00620065006c0074002e004a0073006f006e0043006f006e007300740072007500630074006f00720073000000300008000100460069006c006500560065007200730069006f006e000000000031002e0033002e0030002e00300000005c001e00010049006e007400650072006e0061006c004e0061006d006500000054006f006f006c00620065006c0074002e004a0073006f006e0043006f006e007300740072007500630074006f00720073002e0064006c006c0000002800020001004c006500670061006c0043006f00700079007200690067006800740000002000000064001e0001004f0072006900670069006e0061006c00460069006c0065006e0061006d006500000054006f006f006c00620065006c0074002e004a0073006f006e0043006f006e007300740072007500630074006f00720073002e0064006c006c000000340008000100500072006f006400750063007400560065007200730069006f006e00000031002e0033002e0030002e003000000038000800010041007300730065006d0062006c0079002000560065007200730069006f006e00000031002e0033002e0030002e00300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009000000c000000e03900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
IF @TargetBits IS NULL OR HASHBYTES(N'SHA2_512',@TargetBits)<>@TargetKnownHash
 THROW 53623,N'JSON lifecycle: Targetbinary ist kein qualifiziertes bekanntes Artefakt.',1;
BEGIN TRY
 WHILE @Pass<2
 BEGIN
  -- Vollständiger identischer Preflight vor und unter der AppLock.
  IF COALESCE(TRY_CONVERT(int,SERVERPROPERTY(N'ProductMajorVersion')),0) NOT IN(15,16,17)
   THROW 53620,N'JSON lifecycle: SQL-Version wird nicht unterstützt.',1;
  IF CONVERT(varbinary(max),@Mode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))
   THROW 53621,N'JSON lifecycle: Deployment-Modus ist ungültig.',1;
  IF COALESCE((SELECT compatibility_level FROM sys.databases WHERE database_id=DB_ID()),0)<150
   THROW 53629,N'JSON lifecycle: Compatibility Level wird nicht unterstützt.',1;
  IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
   OR COALESCE(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
   THROW 53622,N'JSON lifecycle: vollständige Metadatensicht fehlt.',1;
  SELECT @Version=NULL,@InstalledMode=NULL,@Registered=0,@ModeRegistered=0,@SchemaId=SCHEMA_ID(N'toolbelt_json');
  SELECT @Registered=1,@Version=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
   WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.Version';
  SELECT @ModeRegistered=1,@InstalledMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
   WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.DeploymentMode';
  IF @Pass=1 AND(@Registered<>@InitialRegistered
   OR COALESCE(CONVERT(varbinary(max),@Version),0x)<>COALESCE(@InitialVersion,0x)
   OR COALESCE(CONVERT(varbinary(max),@InstalledMode),0x)<>COALESCE(@InitialMode,0x)
   OR COALESCE(@SchemaId,-1)<>COALESCE(@InitialSchemaId,-1))
   THROW 53627,N'JSON lifecycle: Zustand hat sich unter Lock verändert.',1;
  IF (@Registered=0 AND @ModeRegistered=1) OR(@Registered=1 AND
   (@Version IS NULL OR CONVERT(varbinary(max),@Version) NOT IN(CONVERT(varbinary(max),N'1.2.0'),CONVERT(varbinary(max),N'1.3.0'))
    OR @ModeRegistered=0 OR @InstalledMode IS NULL
    OR CONVERT(varbinary(max),@InstalledMode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))
    OR @SchemaId IS NULL))
  BEGIN
   IF @Pass=1 THROW 53627,N'JSON lifecycle: Releasezustand unter Lock ist inkohärent.',1;
   THROW 53623,N'JSON lifecycle: Releasezustand ist unbekannt oder inkohärent.',1;
  END;
  SET @PreviousCount=CASE WHEN @Registered=0 THEN 0 WHEN CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.0.0') THEN 3 WHEN CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.1.0') THEN 5 ELSE 8 END;
  IF EXISTS(SELECT 1 FROM @Slots s WHERE s.Id>@PreviousCount AND OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name)) IS NOT NULL)
  BEGIN
   IF @Pass=1 THROW 53627,N'JSON lifecycle: neuer Zielslot unter Lock ist fremd.',1;
   THROW 53624,N'JSON lifecycle: neuer Zielslot ist bereits fremd belegt.',1;
  END;
  -- Bekannte Namen ohne vollständige Marker/Proceduretyp sind keine Ownership.
  IF EXISTS(SELECT 1 FROM @Slots s WHERE s.Id<=@PreviousCount AND NOT EXISTS
   (SELECT 1 FROM sys.objects o WHERE o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
    AND CONVERT(varbinary(2),o.type)=CONVERT(varbinary(2),s.Kind) AND CONVERT(varbinary(256),o.name)=CONVERT(varbinary(256),s.Name)
    AND EXISTS(SELECT 1 FROM sys.extended_properties ep WHERE ep.class=1 AND ep.major_id=o.object_id AND ep.minor_id=0
     AND ep.name=N'Toolbelt.ModuleId' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),ep.value))=CONVERT(varbinary(max),N'toolbelt.json.constructors'))
    AND EXISTS(SELECT 1 FROM sys.extended_properties ep WHERE ep.class=1 AND ep.major_id=o.object_id AND ep.minor_id=0
     AND ep.name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),ep.value))=CONVERT(varbinary(max),@Version))
    AND EXISTS(SELECT 1 FROM sys.extended_properties ep WHERE ep.class=1 AND ep.major_id=o.object_id AND ep.minor_id=0
     AND ep.name=N'Toolbelt.DeploymentMode' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),ep.value))=CONVERT(varbinary(max),@InstalledMode))))
  BEGIN
   IF @Pass=1 THROW 53627,N'JSON lifecycle: Ownership unter Lock ist inkohärent.',1;
   THROW 53623,N'JSON lifecycle: Release-Ownership ist inkohärent.',1;
  END;
  SELECT @KnownMode=CONVERT(nvarchar(16),@InstalledMode),@KnownCount=@PreviousCount,@CreatingSlots=1;
-- SQLCMD-Include im gemeinsamen Preflight, erneut unter derselben AppLock.
-- Keine Prozedur, keine eigene Mutation und keine Katalogzeile als Registryautorität.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
 THROW 53622,N'JSON lifecycle: vollständige CLR-/Dependency-Metadatensicht fehlt.',1;
IF @CreatingSlots=1 OR CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0')
BEGIN
 SELECT @JsonCoreExpectedMode=@Mode,@JsonCoreRequired=1;
-- Pure SQLCMD-Include: keine Helper-USP, Mutation, Trust- oder Ownerreparatur.
-- KnownArtifact.sql deklariert den Scope. Aufruf vor/unter der gemeinsamen Lock.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 THROW 55622,N'JSON Core: vollständige Assemblymetadatensicht fehlt.',1;
SELECT @JsonCoreId=NULL,@JsonCoreOwner=NULL,@JsonCoreHash=NULL,@JsonCoreVersion=NULL,@JsonCoreStoredMode=NULL;
SELECT @JsonCoreVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.Version';
SELECT @JsonCoreStoredMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode';
SELECT @JsonCoreId=a.assembly_id,@JsonCoreOwner=a.principal_id,@JsonCoreHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonCore';
IF @JsonCoreId IS NULL
BEGIN
 IF @JsonCoreRequired=1 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0
  AND name IN(N'Toolbelt.Module.toolbelt.json.core.Version',N'Toolbelt.Module.toolbelt.json.core.DeploymentMode'))
  THROW 55623,N'JSON Core: erforderliche bekannte Dependency fehlt oder ist inkohärent.',1;
END
ELSE
BEGIN
 IF @JsonCoreVersion IS NULL OR CONVERT(varbinary(max),@JsonCoreVersion)<>CONVERT(varbinary(max),N'1.0.0')
  OR @JsonCoreStoredMode IS NULL OR CONVERT(varbinary(max),@JsonCoreStoredMode)<>CONVERT(varbinary(max),@JsonCoreExpectedMode)
  OR @JsonCoreHash IS NULL OR @JsonCoreHash<>@JsonCoreKnownHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@JsonCoreId AND is_user_defined=1 AND permission_set=1 AND is_visible=0
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonCore'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@JsonCoreId)<>1
  THROW 55623,N'JSON Core: keine kohärente bekannte technische SAFE-Assembly.',1;
 DELETE FROM @JsonCoreMarkers;
 INSERT @JsonCoreMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.core'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.0.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@JsonCoreExpectedMode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@JsonCoreKnownHash)),
 (N'Toolbelt.ArtifactId',CONVERT(sql_variant,@JsonCoreArtifactId));
 IF EXISTS(SELECT 1 FROM @JsonCoreMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@JsonCoreId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value)
   AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55623,N'JSON Core: typisiertes bekanntes Markertuple ist inkohärent.',1;
 -- Die technische Dependency stellt keine eigenen oder fremden SQL-Slots bereit.
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: direkter SQL-Verbraucher blockiert den technischen Corevertrag.',1;
 IF @JsonCoreRemoving=1 AND EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: verbleibende Assemblyverbraucher blockieren den Abbau.',1;
END;
END;
SELECT @AssemblyId=NULL,@AssemblyOwner=NULL,@InstalledHash=NULL;
SELECT @AssemblyId=a.assembly_id,@AssemblyOwner=a.principal_id,@InstalledHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonConstructors';
DECLARE @ExpectedInstalledHash varbinary(64)=CASE WHEN CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0') THEN @TargetKnownHash ELSE @KnownHash END,
 @ExpectedInstalledArtifact varchar(64)=CASE WHEN CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0') THEN @TargetArtifactId ELSE @KnownArtifactId END;
IF @Version IS NULL OR CONVERT(varbinary(max),@Version) NOT IN(CONVERT(varbinary(max),N'1.2.0'),CONVERT(varbinary(max),N'1.3.0'))
BEGIN
 IF @AssemblyId IS NOT NULL THROW 53624,N'JSON lifecycle: neuer Assemblyslot ist fremd belegt.',1;
END
ELSE
BEGIN
 IF @AssemblyId IS NULL OR @InstalledHash IS NULL OR @InstalledHash<>@ExpectedInstalledHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@AssemblyId AND permission_set=1 AND is_user_defined=1
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonConstructors'))
  THROW 53623,N'JSON lifecycle: installierte Assembly ist kein bekanntes SAFE-Artefakt.',1;
 -- Die geschlossene Offlinezeile ist eigenständig, nicht der Targethash oder clr_name.
 IF NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
  AND name=N'Toolbelt.Managed' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'int'
  AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=4 AND DATALENGTH(value)=4 AND CONVERT(int,value)=1)
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.ModuleId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=128 AND DATALENGTH(value)=52
   AND CONVERT(varbinary(max),CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),N'toolbelt.json.constructors'))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.ModuleVersion' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=32 AND DATALENGTH(value)=10
   AND CONVERT(varbinary(max),CONVERT(nvarchar(16),value))=CONVERT(varbinary(max),@Version))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.DeploymentMode' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=32 AND DATALENGTH(value)=DATALENGTH(@KnownMode)
   AND CONVERT(varbinary(max),CONVERT(nvarchar(16),value))=CONVERT(varbinary(max),@KnownMode))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.AssemblySha512' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'varbinary'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=64 AND DATALENGTH(value)=64 AND CONVERT(varbinary(64),value)=@ExpectedInstalledHash)
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.ArtifactId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'varchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=64 AND DATALENGTH(value)=64
   AND CONVERT(varbinary(max),CONVERT(varchar(64),value))=CONVERT(varbinary(max),@ExpectedInstalledArtifact))
  THROW 53623,N'JSON lifecycle: typisiertes Assemblymarkertuple ist inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.assembly_modules m ON m.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
   WHERE s.Kind IN('FT','AF') AND (m.object_id IS NULL OR m.assembly_id<>@AssemblyId
    OR m.assembly_class IS NULL OR CONVERT(varbinary(max),m.assembly_class)<>CONVERT(varbinary(max),CASE s.Name
     WHEN N'FT_JsonEntryEvaluateInternal' THEN N'Toolbelt.JsonConstructors.JsonEntryEvaluateBridge'
     WHEN N'AGF_JsonArray' THEN N'Toolbelt.JsonConstructors.JsonArrayAggregate' ELSE N'Toolbelt.JsonConstructors.JsonObjectAggregate' END)
    OR (s.Kind='FT' AND (m.assembly_method IS NULL OR CONVERT(varbinary(max),m.assembly_method)<>CONVERT(varbinary(max),N'Evaluate')))
    OR (s.Kind='AF' AND m.assembly_method IS NOT NULL)))
  THROW 53623,N'JSON lifecycle: bekannte CLR-Bindings sind inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @Parameters e WHERE NOT EXISTS(SELECT 1 FROM sys.parameters p
  WHERE p.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(e.Slot)) AND p.parameter_id=e.Id
   AND CONVERT(varbinary(max),p.name)=CONVERT(varbinary(max),e.Name) AND p.system_type_id=e.TypeId
   AND p.user_type_id=p.system_type_id AND p.max_length=e.Length AND (p.parameter_id=0 OR p.is_output=0)))
  OR EXISTS(SELECT 1 FROM sys.parameters p JOIN @Slots s ON p.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
   WHERE s.Kind IN('FT','AF') AND NOT EXISTS(SELECT 1 FROM @Parameters e WHERE e.Slot=s.Name AND e.Id=p.parameter_id))
  THROW 53623,N'JSON lifecycle: CLR-Parametersignatur ist inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @Columns e WHERE NOT EXISTS(SELECT 1 FROM sys.columns c
  WHERE c.object_id=OBJECT_ID(N'toolbelt_json.FT_JsonEntryEvaluateInternal') AND c.column_id=e.Id
   AND CONVERT(varbinary(max),c.name)=CONVERT(varbinary(max),e.Name) AND c.system_type_id=e.TypeId
   AND c.user_type_id=c.system_type_id AND c.max_length=e.Length AND c.is_nullable=1))
  OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_JsonEntryEvaluateInternal'))<>8
  THROW 53623,N'JSON lifecycle: CLR-Bridgeresultschema ist inkohärent.',1;
END;
IF CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0')
 AND NOT EXISTS(SELECT 1 FROM sys.assembly_references WHERE assembly_id=@AssemblyId AND referenced_assembly_id=@JsonCoreId)
 THROW 53623,N'JSON lifecycle: bekannte1.3-Assembly referenziert den erforderlichen Core nicht.',1;
-- Vollständiger Verbrauchercheck; fremde direkte CLR-Slots und Assemblyreferenzen ebenfalls.
IF @AssemblyId IS NOT NULL AND (EXISTS(SELECT 1 FROM sys.assembly_modules m WHERE m.assembly_id=@AssemblyId
 AND NOT EXISTS(SELECT 1 FROM @Slots s WHERE OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))=m.object_id))
 OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@AssemblyId))
 THROW 53626,N'JSON lifecycle: fremder Assemblyverbraucher blockiert Lifecycle.',1;
IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d JOIN @Slots t ON d.referenced_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(t.Name))
 WHERE t.Id<=@KnownCount AND NOT EXISTS(SELECT 1 FROM @Slots s WHERE s.Id<=@KnownCount AND d.referencing_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))))
 THROW 53626,N'JSON lifecycle: fremder SQL-Verbraucher blockiert Lifecycle.',1;
IF @SchemaId IS NOT NULL
BEGIN
 SELECT @EffectiveOwner=MIN(COALESCE(o.principal_id,sc.principal_id))
  FROM @Slots s JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
  JOIN sys.schemas sc ON sc.schema_id=o.schema_id WHERE s.Id<=@KnownCount;
 IF @EffectiveOwner IS NULL SELECT @EffectiveOwner=principal_id FROM sys.schemas WHERE schema_id=@SchemaId;
 IF @EffectiveOwner IS NULL OR EXISTS(SELECT 1 FROM @Slots s JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
  JOIN sys.schemas sc ON sc.schema_id=o.schema_id WHERE s.Id<=@KnownCount AND COALESCE(o.principal_id,sc.principal_id)<>@EffectiveOwner)
  OR (@AssemblyId IS NOT NULL AND (@AssemblyOwner IS NULL OR @AssemblyOwner<>@EffectiveOwner))
  THROW 53623,N'JSON lifecycle: kohärente vorhandene Owner fehlen; keine Ownerreparatur.',1;
 -- Neue CLR-Objekte erben den Schemaowner. Ohne Owneränderung muss eine
 -- Migration bereits dazu kohärent sein; Repeat erhält explizite Owner.
 IF @CreatingSlots=1 AND @KnownCount<8 AND @KnownCount>0 AND @EffectiveOwner<>(SELECT principal_id FROM sys.schemas WHERE schema_id=@SchemaId)
  THROW 53623,N'JSON lifecycle: neue Slots würden inkohärente Owner erben.',1;
END;
IF (@CreatingSlots=1 OR CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0'))
 AND (@JsonCoreOwner IS NULL OR @JsonCoreOwner<>COALESCE(@EffectiveOwner,USER_ID()))
 THROW 53623,N'JSON lifecycle: Core-/Constructorowner sind inkohärent; keine Ownerreparatur.',1;
  -- SQL6282 verhindert ALTER bei neuer Core-Referenz. Der bekannte1.2-Pfad
  -- ersetzt daher nur drei eigene CLR-Slots/Assembly atomar. Fremde Rechte,
  -- Zusatzmetadaten oder explizite Owner dürfen dabei niemals verloren gehen.
  -- In beiden Pässen vor dem ersten DROP prüfen; keine GRANT-/Ownerreparatur.
  IF @AssemblyId IS NOT NULL AND CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.2.0')
  BEGIN
   IF EXISTS(SELECT 1 FROM sys.database_permissions p WHERE
      (p.class=5 AND p.major_id=@AssemblyId) OR
      (p.class=1 AND p.major_id IN(SELECT OBJECT_ID(N'toolbelt_json.'+QUOTENAME(Name)) FROM @Slots WHERE Kind IN('FT','AF'))))
    OR EXISTS(SELECT 1 FROM @Slots s JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
      WHERE s.Kind IN('FT','AF') AND o.principal_id IS NOT NULL)
    OR @EffectiveOwner<>(SELECT principal_id FROM sys.schemas WHERE schema_id=@SchemaId)
    OR EXISTS(SELECT 1 FROM sys.extended_properties e WHERE
      (e.class=5 AND e.major_id=@AssemblyId AND (e.minor_id<>0 OR e.name NOT IN
       (N'Toolbelt.Managed',N'Toolbelt.ModuleId',N'Toolbelt.ModuleVersion',N'Toolbelt.DeploymentMode',N'Toolbelt.AssemblySha512',N'Toolbelt.ArtifactId')))
      OR (e.class=1 AND e.major_id IN(SELECT OBJECT_ID(N'toolbelt_json.'+QUOTENAME(Name)) FROM @Slots WHERE Kind IN('FT','AF'))
       AND (e.minor_id<>0 OR e.name NOT IN(N'Toolbelt.ModuleId',N'Toolbelt.ModuleVersion',N'Toolbelt.ContractVersion',N'Toolbelt.DeploymentMode',N'Toolbelt.SourceHash'))))
    THROW 53622,N'JSON lifecycle:1.2-Migration würde direkte Rechte, explizite Owner oder zusätzliche CLR-Metadaten verlieren; kein automatischer Austausch.',1;
  END;
  SELECT @CurrentClrTuple=CONVERT(varbinary(max),(SELECT s.Id,OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name)) ObjectId,
   o.principal_id ObjectOwner,sc.principal_id SchemaOwner,@AssemblyId AssemblyId,@AssemblyOwner AssemblyOwner,
   @JsonCoreId CoreId,@JsonCoreOwner CoreOwner
   FROM @Slots s LEFT JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
   LEFT JOIN sys.schemas sc ON sc.schema_id=o.schema_id ORDER BY s.Id FOR XML RAW,BINARY BASE64));
  IF @Pass=0 SET @InitialClrTuple=@CurrentClrTuple;
  ELSE IF @CurrentClrTuple<>@InitialClrTuple THROW 53627,N'JSON lifecycle: Objekt-/Assemblyidentität hat sich unter Lock verändert.',1;
  IF NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr enabled' AND value_in_use=1)
   OR NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr strict security' AND value_in_use=1)
   OR COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE ASSEMBLY'),0)<>1
   OR COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE FUNCTION'),0)<>1
   THROW 53622,N'JSON lifecycle: CLR-Konfiguration oder vorhandene Installationsrechte fehlen.',1;
  IF @AssemblyId IS NOT NULL AND COALESCE(HAS_PERMS_BY_NAME(N'Toolbelt_JsonConstructors',N'ASSEMBLY',N'ALTER'),0)<>1
   THROW 53622,N'JSON lifecycle: vorhandenes Assembly-ALTER-Recht fehlt.',1;
  IF (@SchemaId IS NULL AND COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE SCHEMA'),0)<>1)
   OR(@SchemaId IS NOT NULL AND COALESCE(HAS_PERMS_BY_NAME(N'toolbelt_json',N'SCHEMA',N'ALTER'),0)<>1)
   OR COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE PROCEDURE'),0)<>1
   THROW 53622,N'JSON lifecycle: erforderliche Installationsrechte fehlen.',1;
  SET @DependencyVersion=NULL;
  SELECT @DependencyVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
   WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
  SELECT @DependencyId=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P'),
   @Major=TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)),@Minor=TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)),@Patch=TRY_CONVERT(int,PARSENAME(@DependencyVersion,1));
  IF @DependencyId IS NULL OR @Major IS NULL OR @Major<1 OR @Minor IS NULL OR @Minor<0 OR @Patch IS NULL OR @Patch<0
   OR CONVERT(varbinary(max),@DependencyVersion)<>CONVERT(varbinary(max),CONCAT(@Major,N'.',@Minor,N'.',@Patch))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@DependencyId AND minor_id=0 AND name=N'Toolbelt.ModuleId'
    AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.core.result-table'))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@DependencyId AND minor_id=0 AND name=N'Toolbelt.ModuleVersion'
    AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@DependencyVersion))
   THROW 53622,N'JSON lifecycle: registrierte ResultTable-Dependency ist ungeeignet.',1;
  IF @Pass=0
  BEGIN
   SELECT @InitialRegistered=@Registered,@InitialVersion=CONVERT(varbinary(max),@Version),
    @InitialMode=CONVERT(varbinary(max),@InstalledMode),@InitialSchemaId=@SchemaId;
   BEGIN TRANSACTION;
   EXEC @LockResult=sys.sp_getapplock @Resource=N'toolbelt.deploy.json.shared-core',@LockMode=N'Shared',
    @LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @LockResult IS NULL OR @LockResult<0 THROW 53627,N'JSON lifecycle: gemeinsame Core-AppLock ist nicht verfügbar.',1;
   EXEC @LockResult=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.json.constructors',@LockMode=N'Exclusive',
    @LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @LockResult IS NULL OR @LockResult<0 THROW 53627,N'JSON lifecycle: AppLock ist nicht verfügbar.',1;
  END;
  SET @Pass+=1;
 END;
 -- Die fünf Procedures behalten ihre ObjectIds und vorhandenen Rechte.
 -- Drei eigene CLR-ObjectIds und AssemblyId werden neu erzeugt; Namen,
 -- Signaturen, effektiver Owner und AGF-Wireform bleiben erhalten.
 -- Alle Fremdverbraucher/verlustgefährdeten Tupel wurden zweimal ausgeschlossen.
 -- DROP/CREATE/Marker bleiben bis zur finalen Prüfung in derselben Transaktion.
 IF @AssemblyId IS NOT NULL AND CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.2.0')
 BEGIN
  DROP AGGREGATE toolbelt_json.AGF_JsonArray;
  DROP AGGREGATE toolbelt_json.AGF_JsonObject;
  DROP FUNCTION toolbelt_json.FT_JsonEntryEvaluateInternal;
  DROP ASSEMBLY [Toolbelt_JsonConstructors] WITH NO DEPENDENTS;
  SET @AssemblyId=NULL;
 END;
 IF @SchemaId IS NULL
 BEGIN
  EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_json];';
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_json';
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'json',@level0type=N'SCHEMA',@level0name=N'toolbelt_json';
 END;
 -- Neue Assembly erhält den bereits vorhandenen Schemaowner, niemals Ownerreparatur.
 IF @AssemblyId IS NULL
 BEGIN
  SELECT @EffectiveOwner=principal_id FROM sys.schemas WHERE name=N'toolbelt_json';
  DECLARE @AssemblyOwnerName sysname=USER_NAME(@EffectiveOwner),@AssemblySql nvarchar(max);
  IF @AssemblyOwnerName IS NULL THROW 53622,N'JSON lifecycle: vorhandener Schemaowner ist nicht sichtbar.',1;
  SET @AssemblySql=N'CREATE ASSEMBLY [Toolbelt_JsonConstructors] AUTHORIZATION '+QUOTENAME(@AssemblyOwnerName)
   +N' FROM '+CONVERT(nvarchar(max),@TargetBits,1)+N' WITH PERMISSION_SET=SAFE;';
  EXEC sys.sp_executesql @AssemblySql;
 END;
 -- Eigener über GO erreichbarer Zustand; kein Löschen gleichnamiger Callertemps.
 CREATE TABLE #tbx_JsonConstructorDeployState(DeploymentMode nvarchar(16) NOT NULL);
 DECLARE @StateMode nvarchar(16)=CONVERT(nvarchar(16),@Mode);
 -- Erst nach Caller- und Namensraumprüfung gegen die eigene Tempstruktur kompilieren.
 EXEC sys.sp_executesql N'INSERT #tbx_JsonConstructorDeployState(DeploymentMode) VALUES(@Mode);',
  N'@Mode nvarchar(16)',@Mode=@StateMode;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
-- Technische Bridge: Stage0 vor echtem ISJSON, Stage1 danach; keine öffentliche API.
IF OBJECT_ID(N'toolbelt_json.FT_JsonEntryEvaluateInternal') IS NULL
 EXEC sys.sp_executesql N'CREATE FUNCTION toolbelt_json.FT_JsonEntryEvaluateInternal
(@ObjectMode bit,@Key nvarchar(max),@ValueKind nvarchar(max),@Value nvarchar(max),@Stage tinyint,@Policy tinyint)
RETURNS TABLE
(Fragment nvarchar(max) NULL,ErrorNumber int NULL,ErrorState int NULL,FaultPhase tinyint NULL,
 RawValueBytes bigint NULL,KeyBytes bigint NULL,StrongMinimumBytes bigint NULL,FragmentBytes bigint NULL)
AS EXTERNAL NAME [Toolbelt_JsonConstructors].[Toolbelt.JsonConstructors.JsonEntryEvaluateBridge].[Evaluate];';
GO
-- Einzeln freigegebene SAFE-Aggregate; Profile und Wireversion sind im bekannten Binary gebunden.
IF OBJECT_ID(N'toolbelt_json.AGF_JsonArray') IS NULL
 EXEC sys.sp_executesql N'CREATE AGGREGATE toolbelt_json.AGF_JsonArray
(@Ordinal int,@ValueKind nvarchar(max),@Value nvarchar(max),@Profile tinyint)
RETURNS nvarchar(max)
EXTERNAL NAME [Toolbelt_JsonConstructors].[Toolbelt.JsonConstructors.JsonArrayAggregate];';
GO
IF OBJECT_ID(N'toolbelt_json.AGF_JsonObject') IS NULL
 EXEC sys.sp_executesql N'CREATE AGGREGATE toolbelt_json.AGF_JsonObject
(@Ordinal int,@Key nvarchar(max),@ValueKind nvarchar(max),@Value nvarchar(max),@Profile tinyint)
RETURNS nvarchar(max)
EXTERNAL NAME [Toolbelt_JsonConstructors].[Toolbelt.JsonConstructors.JsonObjectAggregate];';
GO
-- Interner kanonischer Prüf-/Escapingkern. Kein SQL-Text aus Values wird ausgeführt.
-- Vollständiger privater Snapshot und begrenzte Fragmente vor ResultTable-Mutation.
CREATE OR ALTER PROCEDURE toolbelt_json.USP_JsonConstructInternal
 @ObjectMode bit=NULL,@EntriesTable sysname=NULL,@MaxEntries int=NULL,@MaxTotalValueBytes bigint=NULL,
 @MaxResultBytes bigint=NULL,@GroupMode bit=0,@ResultTable sysname=NULL,@KeepData bit=0,@Debug tinyint=0,@Hilfe bit=0
AS
BEGIN
 SET NOCOUNT ON;
 IF @Hilfe=1
 BEGIN
  DECLARE @Help TABLE(Section varchar(32) NOT NULL,Ordinal int NOT NULL,ItemName sysname NULL,SqlDataType varchar(256) NULL,IsRequired bit NULL,IsNullable bit NULL,DefaultValue nvarchar(4000) NULL,Description nvarchar(max) NOT NULL,ExampleSql nvarchar(max) NULL);
  INSERT @Help VALUES
  ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'Interner kanonischer JSON-Prüf-/Escaping-/Routingkern; kein zusätzlicher öffentlicher Konstruktor.',NULL),
  ('PARAMETER',1,N'@ObjectMode','bit',1,0,NULL,N'0 Array, 1 Object; ausschließlich technischer Modus.',NULL),
  ('PARAMETER',2,N'@EntriesTable','sysname',1,0,NULL,N'Caller-lokale Eingabetabelle.',NULL),
  ('PARAMETER',3,N'@MaxEntries','int',1,0,NULL,N'Positive Grenze bis 100000.',NULL),
  ('PARAMETER',4,N'@MaxTotalValueBytes','bigint',1,0,NULL,N'Positive Gesamtwertbytes bis 16777216.',NULL),
  ('PARAMETER',5,N'@MaxResultBytes','bigint',1,0,NULL,N'Positive Ergebnisbytes bis 16777216.',NULL),
  ('PARAMETER',6,N'@GroupMode','bit',0,0,N'0',N'0 ungruppiert, 1 gruppiert; ausschließlich technischer Modus.',NULL),
  ('PARAMETER',7,N'@ResultTable','sysname',0,1,NULL,N'SELECT oder lokale ResultTable.',NULL),
  ('PARAMETER',8,N'@KeepData','bit',1,0,NULL,N'Replace/Append vom Wrapper normalisiert.',NULL),
  ('PARAMETER',9,N'@Debug','tinyint',1,0,NULL,N'Nur Messages.',NULL),
  ('PARAMETER',10,N'@Hilfe','bit',0,1,N'0',N'Help ohne fachliche Prüfung oder Mutation.',NULL),
  ('RESULT_COLUMN',1,N'JsonValue','nvarchar(max)',1,0,NULL,N'GroupMode 0: einzige Spalte/eine Zeile; GroupMode 1: zweite Spalte/eine Zeile je vorhandener Gruppe.',NULL),
  ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Öffentliche Fassade bevorzugen.',N'EXEC toolbelt_json.USP_JsonArray @Hilfe=1;');
  IF @GroupMode=1
  BEGIN
   UPDATE @Help SET Ordinal=2 WHERE Section='RESULT_COLUMN';
   INSERT @Help VALUES('RESULT_COLUMN',1,N'GroupOrdinal','int',1,0,NULL,N'GroupMode 1: positive Gruppe, erste Spalte; GroupMode 0 besitzt nur JsonValue.',NULL);
  END;
  SELECT CAST('1.0' AS varchar(16)) HelpContractVersion,CAST(N'toolbelt_json' AS sysname) SchemaName,
  CAST(N'USP_JsonConstructInternal' AS sysname) ObjectName,Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql FROM @Help ORDER BY Section,Ordinal;
  RETURN;
 END;
 IF @ObjectMode IS NULL OR @GroupMode IS NULL OR @MaxEntries IS NULL OR @MaxEntries NOT BETWEEN 1 AND 100000
 OR @MaxTotalValueBytes IS NULL OR @MaxTotalValueBytes NOT BETWEEN 1 AND 16777216
 OR @MaxResultBytes IS NULL OR @MaxResultBytes NOT BETWEEN 1 AND 16777216
 THROW 53600,N'JSON: ungültiger Ressourcenparameter.',1;
 DECLARE @DependencyId int=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P'),@Version nvarchar(64),@Major int,@Minor int,@Patch int;
 SELECT @Version=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
 SELECT @Major=TRY_CONVERT(int,PARSENAME(@Version,3)),@Minor=TRY_CONVERT(int,PARSENAME(@Version,2)),@Patch=TRY_CONVERT(int,PARSENAME(@Version,1));
 IF @DependencyId IS NULL OR @Major IS NULL OR @Major<1 OR @Minor IS NULL OR @Minor<0 OR @Patch IS NULL OR @Patch<0
 OR CONVERT(varbinary(max),@Version)<>CONVERT(varbinary(max),CONCAT(@Major,N'.',@Minor,N'.',@Patch))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@DependencyId AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND TRY_CONVERT(nvarchar(128),value)=N'toolbelt.core.result-table')
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@DependencyId AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@Version))
 THROW 53610,N'JSON: registrierte ResultTable-Dependency >=1.0.0 fehlt oder ist ungeeignet.',1;
 IF @EntriesTable IS NULL OR LEFT(@EntriesTable,1) COLLATE Latin1_General_100_BIN2<>N'#'
 OR LEFT(@EntriesTable,2) COLLATE Latin1_General_100_BIN2=N'##'
 OR LEFT(LOWER(@EntriesTable COLLATE Latin1_General_100_BIN2),5) COLLATE Latin1_General_100_BIN2=N'#tbx_'
 OR QUOTENAME(@EntriesTable) IS NULL
 THROW 53601,N'JSON: caller-lokale Eingabetabelle erforderlich.',1;
 DECLARE @InputId int=OBJECT_ID(N'tempdb..'+@EntriesTable,N'U');
 IF @InputId IS NULL THROW 53601,N'JSON: Eingabetabelle fehlt oder ist nicht sichtbar.',2;
 IF @ResultTable IS NOT NULL AND OBJECT_ID(N'tempdb..'+@ResultTable,N'U')=@InputId
 THROW 53601,N'JSON: Eingabe und Ausgabe dürfen nicht dieselbe Tabelle sein.',3;
 DECLARE @Required TABLE(Name sysname,TypeId int,MaxLength smallint);
 INSERT @Required VALUES(N'Ordinal',56,4),(N'ValueKind',231,-1),(N'Value',231,-1);
 IF @GroupMode=1 INSERT @Required VALUES(N'GroupOrdinal',56,4);
 IF @ObjectMode=1 INSERT @Required VALUES(N'Key',231,-1);
 IF EXISTS(SELECT 1 FROM @Required r WHERE NOT EXISTS
 (SELECT 1 FROM tempdb.sys.columns c WHERE c.object_id=@InputId
 AND CONVERT(varbinary(256),c.name)=CONVERT(varbinary(256),r.Name)
 AND c.system_type_id=r.TypeId AND c.user_type_id=c.system_type_id AND c.max_length=r.MaxLength AND c.is_computed=0))
 THROW 53601,N'JSON: erforderliche Spalten besitzen nicht den exakten Typvertrag.',4;
 DECLARE @Own bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,@Saved bit=0,@Savepoint varchar(32)=REPLACE(CONVERT(varchar(36),NEWID()),'-','');
 BEGIN TRY
  IF @Own=1 BEGIN TRANSACTION;
  ELSE BEGIN SAVE TRANSACTION @Savepoint; SET @Saved=1; END;
 -- Metadatenaggregate vor jeder privaten LOB-Kopie. Der caller-lokale Input
 -- bleibt per Tabellen-S-Lock/HOLDLOCK bis zum konsistenten Snapshot stabil;
 -- bei fremder Transaktion gilt deren reguläre Lock-Lebensdauer.
 DECLARE @SnapshotLimit int=@MaxEntries+1,@PreCount bigint,@PreValueBytes bigint,@PreKeyBytes bigint,
 @PreGroups bigint,@SyntaxBytes bigint,@BadGroup int,@BadOrdinal int,@BadKey int,@BadKindLength int,@DuplicateOrdinal bit,@Sql nvarchar(max);
 SET @Sql=N'SELECT @c=COUNT_BIG(*),@v=COALESCE(SUM(CONVERT(bigint,DATALENGTH([Value]))),0),'
 +N'@k='+CASE WHEN @ObjectMode=1 THEN N'COALESCE(SUM(CONVERT(bigint,DATALENGTH([Key]))),0)' ELSE N'0' END
 +N',@g='+CASE WHEN @GroupMode=1 THEN N'COUNT_BIG(DISTINCT GroupOrdinal)' ELSE N'CONVERT(bigint,1)' END
 +N',@badg='+CASE WHEN @GroupMode=1 THEN N'COALESCE(MAX(CASE WHEN GroupOrdinal IS NULL OR GroupOrdinal<=0 THEN 1 ELSE 0 END),0)' ELSE N'0' END
 +N',@o=COALESCE(MAX(CASE WHEN Ordinal IS NULL OR Ordinal<=0 THEN 1 ELSE 0 END),0),'
 +N'@b='+CASE WHEN @ObjectMode=1 THEN N'COALESCE(MAX(CASE WHEN [Key] IS NULL OR DATALENGTH([Key])=0 OR DATALENGTH([Key])>2048 THEN 1 ELSE 0 END),0)' ELSE N'0' END
 +N',@t=COALESCE(MAX(CASE WHEN ValueKind IS NULL OR DATALENGTH(ValueKind)>14 THEN 1 ELSE 0 END),0) '
 +N'FROM(SELECT TOP (@Limit) '+CASE WHEN @GroupMode=1 THEN N'GroupOrdinal,' ELSE N'' END+N'Ordinal,ValueKind,[Value]'+CASE WHEN @ObjectMode=1 THEN N',[Key]' ELSE N'' END
 +N' FROM '+QUOTENAME(@EntriesTable)+N' WITH(TABLOCK,HOLDLOCK)) bounded;';
 EXEC sys.sp_executesql @Sql,N'@Limit int,@c bigint OUTPUT,@v bigint OUTPUT,@k bigint OUTPUT,@g bigint OUTPUT,@badg int OUTPUT,@o int OUTPUT,@b int OUTPUT,@t int OUTPUT',
 @SnapshotLimit,@PreCount OUTPUT,@PreValueBytes OUTPUT,@PreKeyBytes OUTPUT,@PreGroups OUTPUT,@BadGroup OUTPUT,@BadOrdinal OUTPUT,@BadKey OUTPUT,@BadKindLength OUTPUT;
 IF @PreCount>@MaxEntries THROW 53609,N'JSON: Entrylimit überschritten.',1;
 SET @Sql=N'SELECT @d=CASE WHEN EXISTS(SELECT Ordinal FROM '+QUOTENAME(@EntriesTable)+N' WITH(TABLOCK,HOLDLOCK) GROUP BY '+CASE WHEN @GroupMode=1 THEN N'GroupOrdinal,' ELSE N'' END+N'Ordinal HAVING COUNT_BIG(*)>1) THEN 1 ELSE 0 END;';
 EXEC sys.sp_executesql @Sql,N'@d bit OUTPUT',@DuplicateOrdinal OUTPUT;
 IF @BadGroup=1 THROW 53602,N'JSON: GroupOrdinal muss positiv und nicht NULL sein.',2;
 IF @BadOrdinal=1 OR @DuplicateOrdinal=1 THROW 53602,N'JSON: Ordinals müssen positiv und eindeutig sein.',1;
 IF @BadKey=1 THROW 53603,N'JSON: Key ist NULL, leer oder länger als 1024 Codeeinheiten.',1;
 IF @BadKindLength=1 THROW 53605,N'JSON: ValueKind ist NULL oder überschreitet die maximale Kindlänge.',2;
 IF @PreValueBytes>@MaxTotalValueBytes THROW 53609,N'JSON: Gesamtwertbytes vor Snapshot überschritten.',2;
 SET @SyntaxBytes=CASE WHEN @PreCount=0 THEN CASE WHEN @GroupMode=1 THEN 0 ELSE 4 END ELSE 4*@PreGroups+2*(@PreCount-@PreGroups) END;
 IF @PreValueBytes+@PreKeyBytes+@SyntaxBytes
 +CASE WHEN @ObjectMode=1 THEN 6*@PreCount ELSE 0 END>@MaxResultBytes
 THROW 53609,N'JSON: minimale Ergebnisbytegrenze vor Snapshot überschritten.',4;
 CREATE TABLE #tbx_JsonConstructor_Input
 (GroupOrdinal int NULL,Ordinal int NULL,[Key] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
 ValueKind nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
 [Value] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL);
 SET @Sql=N'INSERT #tbx_JsonConstructor_Input(GroupOrdinal,Ordinal,[Key],ValueKind,[Value]) SELECT TOP (@Limit) '
 +CASE WHEN @GroupMode=1 THEN N'GroupOrdinal' ELSE N'CONVERT(int,1)' END+N',Ordinal,'
 +CASE WHEN @ObjectMode=1 THEN N'[Key]' ELSE N'CAST(NULL AS nvarchar(max))' END
 +N',ValueKind,[Value] FROM '+QUOTENAME(@EntriesTable)+N' WITH(TABLOCK,HOLDLOCK);';
 -- Ein Statement liefert den Snapshot; eine überzählige Zeile genügt zum Limitfehler.
 EXEC sys.sp_executesql @Sql,N'@Limit int',@SnapshotLimit;
 IF (SELECT COUNT_BIG(*) FROM #tbx_JsonConstructor_Input)>@MaxEntries THROW 53609,N'JSON: Entrylimit überschritten.',1;
 IF EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input WHERE GroupOrdinal IS NULL OR GroupOrdinal<=0)
 THROW 53602,N'JSON: GroupOrdinal muss positiv und nicht NULL sein.',2;
 IF EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input WHERE Ordinal IS NULL OR Ordinal<=0)
 OR EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input GROUP BY GroupOrdinal,Ordinal HAVING COUNT(*)>1)
 THROW 53602,N'JSON: Ordinals müssen positiv und eindeutig sein.',1;
 IF @ObjectMode=1 AND EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input WHERE [Key] IS NULL OR DATALENGTH([Key])=0 OR DATALENGTH([Key])>2048)
 THROW 53603,N'JSON: Key ist NULL, leer oder länger als 1024 Codeeinheiten.',1;
 -- BIN2 allein folgt SQL-Padding. Die zusätzliche Bytelänge unterscheidet 'a'/'a '.
 IF @ObjectMode=1 AND EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input GROUP BY GroupOrdinal,CONVERT(varbinary(2048),[Key]),DATALENGTH([Key]) HAVING COUNT(*)>1)
 THROW 53604,N'JSON: doppelte binär identische Keys.',1;
 IF EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input WHERE ValueKind IS NULL OR
 CONVERT(varbinary(max),ValueKind) NOT IN(0x73007400720069006E006700,0x6E0075006D00620065007200,0x62006F006F006C00650061006E00,0x6E0075006C006C00,0x6A0073006F006E00))
 THROW 53605,N'JSON: ValueKind muss exakt string/number/boolean/null/json sein.',1;
 IF EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input WHERE (ValueKind=N'null' AND [Value] IS NOT NULL) OR(ValueKind<>N'null' AND [Value] IS NULL))
 THROW 53606,N'JSON: SQL-NULL ist ausschließlich für Kind null erforderlich.',1;
 IF (SELECT COALESCE(SUM(CONVERT(bigint,DATALENGTH([Value]))),0) FROM #tbx_JsonConstructor_Input)>@MaxTotalValueBytes
 THROW 53609,N'JSON: Gesamtwertbytes überschritten.',2;
 -- Untere Ergebnisgrenze vor Escaping/Fragmentkopien; die Keysumme ist
 -- durch das Resultbudget begrenzt, nicht nur die einzelne Keylänge.
 DECLARE @MinimumBytes bigint,@InputCount bigint=(SELECT COUNT_BIG(*) FROM #tbx_JsonConstructor_Input);
 SELECT @PreGroups=COUNT_BIG(DISTINCT GroupOrdinal) FROM #tbx_JsonConstructor_Input;
 SET @SyntaxBytes=CASE WHEN @InputCount=0 THEN CASE WHEN @GroupMode=1 THEN 0 ELSE 4 END ELSE 4*@PreGroups+2*(@InputCount-@PreGroups) END;
 SELECT @MinimumBytes=COALESCE(SUM(CONVERT(bigint,CASE WHEN ValueKind=N'null' THEN 8 ELSE DATALENGTH([Value]) END)
 +CASE WHEN ValueKind=N'string' THEN 4 ELSE 0 END
 +CASE WHEN @ObjectMode=1 THEN CONVERT(bigint,DATALENGTH([Key]))+6 ELSE 0 END),0)
 +@SyntaxBytes FROM #tbx_JsonConstructor_Input;
 IF @MinimumBytes>@MaxResultBytes THROW 53609,N'JSON: minimale Ergebnisbytegrenze überschritten.',4;
 CREATE TABLE #tbx_JsonConstructor_Fragments(GroupOrdinal int NOT NULL,Ordinal int NOT NULL,Fragment nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL);
 DECLARE @GroupOrdinal int,@Ordinal int,@Key nvarchar(max),@Kind nvarchar(max),@Value nvarchar(max),
 @Stage tinyint,@BridgeCode int,@BridgeState int,@BridgePhase tinyint,@ExpectedRaw bigint,@ExpectedKey bigint,@ExpectedStrong bigint;
 DECLARE @Entry TABLE(Fragment nvarchar(max) NULL,ErrorNumber int NULL,ErrorState int NULL,FaultPhase tinyint NULL,
 RawValueBytes bigint NULL,KeyBytes bigint NULL,StrongMinimumBytes bigint NULL,FragmentBytes bigint NULL);
 -- Kostenpass verwendet denselben bekannten CLR-Kern in kleinen Stringspans.
 -- Er erzeugt keine vollständigen expandierten Fragmente. Alle fachlichen
 -- Fehler werden in ursprünglicher Reihenfolge vor dem globalen Budget geprüft.
 DECLARE @CostPass tinyint=0,@ExactTotal bigint=0,@StringCost bigint,
 @FullString nvarchar(max),@Chunk nvarchar(1024),@ChunkStart int,@ChunkUnits int,@FullUnits int;
 DECLARE @ChunkCost TABLE(Fragment nvarchar(max) NULL,ErrorNumber int NULL,FragmentBytes bigint NULL);
 DECLARE Entries CURSOR LOCAL FAST_FORWARD FOR SELECT GroupOrdinal,Ordinal,[Key],ValueKind,[Value] FROM #tbx_JsonConstructor_Input ORDER BY GroupOrdinal,Ordinal;
 WHILE @CostPass<=1
 BEGIN
 OPEN Entries;
 FETCH NEXT FROM Entries INTO @GroupOrdinal,@Ordinal,@Key,@Kind,@Value;
 WHILE @@FETCH_STATUS=0
 BEGIN
  -- Der einzige fachliche Entrykern ist die bekannte CLR-Bridge. Globale
  -- Snapshot-/Budget-/Priorityregeln bleiben vor diesen begrenzten Kopien.
  SELECT @Stage=0,@ExpectedRaw=COALESCE(CONVERT(bigint,DATALENGTH(@Value)),0),
   @ExpectedKey=CASE WHEN @ObjectMode=1 THEN CONVERT(bigint,DATALENGTH(@Key)) ELSE 0 END;
  SET @ExpectedStrong=CASE WHEN @Kind=N'null' THEN 8 ELSE @ExpectedRaw END
   +CASE WHEN @Kind=N'string' THEN 4 ELSE 0 END+CASE WHEN @ObjectMode=1 THEN @ExpectedKey+6 ELSE 0 END;
  WHILE @Stage<=1
  BEGIN
   DELETE FROM @Entry;
   IF @CostPass=0 AND @Stage=1 AND @Kind=N'string'
   BEGIN
    SET @FullString=@Value; SET @Value=N''; SET @ExpectedRaw=0;
    SET @ExpectedStrong=4+CASE WHEN @ObjectMode=1 THEN @ExpectedKey+6 ELSE 0 END;
   END;
   INSERT @Entry SELECT Fragment,ErrorNumber,ErrorState,FaultPhase,RawValueBytes,KeyBytes,StrongMinimumBytes,FragmentBytes
    FROM toolbelt_json.FT_JsonEntryEvaluateInternal(@ObjectMode,@Key,@Kind,@Value,@Stage,CONVERT(tinyint,1));
   IF (SELECT COUNT_BIG(*) FROM @Entry)<>1
    THROW 53611,N'JSON: interner Bridgevertrag ist inkohärent.',1;
   IF EXISTS(SELECT 1 FROM @Entry WHERE ErrorNumber IS NULL OR ErrorState IS NULL OR FaultPhase IS NULL
    OR RawValueBytes IS NULL OR KeyBytes IS NULL OR StrongMinimumBytes IS NULL OR FragmentBytes IS NULL
    OR RawValueBytes<>@ExpectedRaw OR KeyBytes<>@ExpectedKey OR StrongMinimumBytes<>@ExpectedStrong
    OR FragmentBytes<0 OR FragmentBytes%2<>0
    OR (@Stage=0 AND (Fragment IS NOT NULL OR FragmentBytes<>0))
    OR (ErrorNumber=0 AND (ErrorState<>0 OR FaultPhase<>0
      OR (@Stage=1 AND (Fragment IS NULL OR FragmentBytes<>DATALENGTH(Fragment)))))
    OR (ErrorNumber<>0 AND (Fragment IS NOT NULL OR FragmentBytes<>0))
    OR NOT((ErrorNumber=0 AND ErrorState=0 AND FaultPhase=0)
     OR (ErrorNumber=53607 AND ErrorState=1 AND (FaultPhase=2 OR (FaultPhase=1 AND @ObjectMode=1)))
     OR (@Stage=1 AND ErrorNumber=53607 AND ErrorState BETWEEN 2 AND 4 AND FaultPhase=4 AND @Kind=N'json')
     OR (@Stage=1 AND ErrorNumber=53608 AND ErrorState=1 AND FaultPhase=3 AND @Kind=N'boolean')
     OR (@Stage=1 AND ErrorNumber=53608 AND ErrorState BETWEEN 3 AND 6 AND FaultPhase=3 AND @Kind=N'number')))
    THROW 53611,N'JSON: interner Bridgevertrag ist inkohärent.',1;
   SELECT @BridgeCode=ErrorNumber,@BridgeState=ErrorState,@BridgePhase=FaultPhase FROM @Entry;
   IF @BridgeCode=53607 AND @BridgeState=1 THROW 53607,N'JSON: ungültige Unicode-Surrogatfolge.',1;
   IF @BridgeCode=53607 AND @BridgeState=2 THROW 53607,N'JSON: decodierte Unicode-Surrogatfolge ungültig.',2;
   IF @BridgeCode=53607 AND @BridgeState=3 THROW 53607,N'JSON: decodierte Unicode-Surrogatfolge ungültig.',3;
   IF @BridgeCode=53607 AND @BridgeState=4 THROW 53607,N'JSON: decodierte Unicode-Surrogatfolge ungültig.',4;
   IF @BridgeCode=53608 AND @BridgeState=1 THROW 53608,N'JSON: Booleanliteral ungültig.',1;
   IF @BridgeCode=53608 AND @BridgeState=3 THROW 53608,N'JSON: Zahlenliteral ungültig.',3;
   IF @BridgeCode=53608 AND @BridgeState=4 THROW 53608,N'JSON: Zahlenliteral ungültig.',4;
   IF @BridgeCode=53608 AND @BridgeState=5 THROW 53608,N'JSON: Zahlenliteral ungültig.',5;
   IF @BridgeCode=53608 AND @BridgeState=6 THROW 53608,N'JSON: Zahlenliteral ungültig.',6;
   IF @Stage=0 AND @Kind=N'json'
   BEGIN
    IF ISJSON(@Value)<>1 THROW 53608,N'JSON: Fragment muss vollständiges Objekt oder Array sein.',2;
   END;
   SET @Stage+=1;
  END;
  IF @CostPass=0
  BEGIN
   SELECT @StringCost=FragmentBytes FROM @Entry;
   IF @Kind=N'string'
   BEGIN
    SET @FullUnits=CONVERT(int,DATALENGTH(@FullString)/2); SET @ChunkStart=1;
    WHILE @ChunkStart<=@FullUnits
    BEGIN
     SET @ChunkUnits=CASE WHEN @FullUnits-@ChunkStart+1>1024 THEN 1024 ELSE @FullUnits-@ChunkStart+1 END;
     -- Ein Surrogatpaar darf keine Span-Grenze kreuzen; Raw-UTF16 wurde bereits geprüft.
     IF UNICODE(SUBSTRING(@FullString COLLATE Latin1_General_100_BIN2,@ChunkStart+@ChunkUnits-1,1)) BETWEEN 55296 AND 56319
      SET @ChunkUnits-=1;
     IF @ChunkUnits<=0 THROW 53611,N'JSON: Stringkostenspan ist inkohärent.',2;
     SET @Chunk=SUBSTRING(@FullString COLLATE Latin1_General_100_BIN2,@ChunkStart,@ChunkUnits);
     DELETE @ChunkCost;
     INSERT @ChunkCost SELECT Fragment,ErrorNumber,FragmentBytes
      FROM toolbelt_json.FT_JsonEntryEvaluateInternal(CONVERT(bit,0),NULL,N'string',@Chunk,CONVERT(tinyint,1),CONVERT(tinyint,1));
     IF (SELECT COUNT_BIG(*) FROM @ChunkCost)<>1 OR EXISTS(SELECT 1 FROM @ChunkCost WHERE
      ErrorNumber IS NULL OR ErrorNumber<>0 OR Fragment IS NULL OR FragmentBytes IS NULL
      OR FragmentBytes<>DATALENGTH(Fragment) OR FragmentBytes<4)
      THROW 53611,N'JSON: Stringkostenbridge ist inkohärent.',2;
     SELECT @StringCost+=FragmentBytes-4 FROM @ChunkCost;
     SET @ChunkStart+=@ChunkUnits;
    END;
   END;
   SET @ExactTotal+=@StringCost;
  END
  ELSE INSERT #tbx_JsonConstructor_Fragments SELECT @GroupOrdinal,@Ordinal,Fragment FROM @Entry;
  FETCH NEXT FROM Entries INTO @GroupOrdinal,@Ordinal,@Key,@Kind,@Value;
 END;
 CLOSE Entries;
 IF @CostPass=0 AND @ExactTotal+@SyntaxBytes>@MaxResultBytes
  THROW 53609,N'JSON: Ergebnisbytegrenze überschritten.',3;
 SET @CostPass+=1;
 END;
 DEALLOCATE Entries;
 DECLARE @Count bigint=(SELECT COUNT_BIG(*) FROM #tbx_JsonConstructor_Fragments),@Bytes bigint;
 SELECT @Bytes=COALESCE(SUM(CONVERT(bigint,DATALENGTH(Fragment))),0)+@SyntaxBytes FROM #tbx_JsonConstructor_Fragments;
 IF @Bytes>@MaxResultBytes THROW 53609,N'JSON: Ergebnisbytegrenze überschritten.',3;
 CREATE TABLE #tbx_JsonConstructor_Result(JsonValue nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL);
 CREATE TABLE #tbx_JsonConstructor_GroupResult(GroupOrdinal int NOT NULL,JsonValue nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL);
 -- Ein globaler Preflight vor jeder Aggregation und vor dem einzigen Routing.
 -- Feste unterschiedliche Referenzschemas bewahren die alte Einspaltenausgabe.
 IF @GroupMode=1
 INSERT #tbx_JsonConstructor_GroupResult SELECT GroupOrdinal,
 CASE WHEN @ObjectMode=1 THEN N'{' ELSE N'[' END
 +STRING_AGG(Fragment,N',') WITHIN GROUP(ORDER BY Ordinal)
 +CASE WHEN @ObjectMode=1 THEN N'}' ELSE N']' END
 FROM #tbx_JsonConstructor_Fragments GROUP BY GroupOrdinal;
 ELSE
 INSERT #tbx_JsonConstructor_Result SELECT CASE WHEN @ObjectMode=1 THEN N'{' ELSE N'[' END
 +COALESCE(STRING_AGG(Fragment,N',') WITHIN GROUP(ORDER BY Ordinal),N'')
 +CASE WHEN @ObjectMode=1 THEN N'}' ELSE N']' END FROM #tbx_JsonConstructor_Fragments;
 IF @Debug>0 RAISERROR(N'JSON: vollständig validiertes Ergebnis bereit.',10,1) WITH NOWAIT;
 IF @ResultTable IS NULL
 BEGIN
  IF @Own=1 COMMIT;
  IF @GroupMode=1 SELECT GroupOrdinal,JsonValue FROM #tbx_JsonConstructor_GroupResult ORDER BY GroupOrdinal;
  ELSE SELECT JsonValue FROM #tbx_JsonConstructor_Result;
  RETURN;
 END;
  IF @GroupMode=1
  BEGIN
   EXEC toolbelt_core.USP_PrepareResultTable @ResultTableToAlter=@ResultTable,@LikeTable=N'#tbx_JsonConstructor_GroupResult',@KeepData=@KeepData,@Debug=@Debug;
   SET @Sql=N'INSERT '+QUOTENAME(@ResultTable)+N'(GroupOrdinal,JsonValue) SELECT GroupOrdinal,JsonValue FROM #tbx_JsonConstructor_GroupResult;';
  END
  ELSE
  BEGIN
   EXEC toolbelt_core.USP_PrepareResultTable @ResultTableToAlter=@ResultTable,@LikeTable=N'#tbx_JsonConstructor_Result',@KeepData=@KeepData,@Debug=@Debug;
   SET @Sql=N'INSERT '+QUOTENAME(@ResultTable)+N'(JsonValue) SELECT JsonValue FROM #tbx_JsonConstructor_Result;';
  END;
  EXEC sys.sp_executesql @Sql;
  IF @Own=1 COMMIT;
 END TRY
 BEGIN CATCH
  IF @Own=1 AND XACT_STATE()<>0 ROLLBACK;
  ELSE IF @Saved=1 AND XACT_STATE()=1 ROLLBACK TRANSACTION @Savepoint;
  THROW;
 END CATCH;
END;
GO
-- ============================================================================
-- Objekt: toolbelt_json.USP_JsonArray; Typ: Stored Procedure
-- Zweck: Begrenzte JSON-Konstruktion aus caller-lokaler #Temp mit expliziten Kinds.
-- Vertrag: Documentation/USP_JsonArray.md; USP_CONTRACT 1.0
-- Parameter: EntriesTable sysname; positive MaxEntries/MaxTotalValueBytes/MaxResultBytes
-- Resultset: JsonValue nvarchar(max) NOT NULL, genau eine Zeile.
-- Dependencies: toolbelt.core.result-table >=1.0.0 same_database
-- Rechte: EXECUTE; eigene lokale Temps; keine Rechteausweitung.
-- Versionen: SQL Server 2019/2022/2025, Compatibility >=150; Windows/Linux.
-- Fehler: 53600-53610; vollständige Prüfung vor Zielmutation, Originalenginefehler.
-- Performance: begrenzter Snapshot, Fragmente und geordnete LOB-Aggregation.
-- Grenzen: keine Inferenz/PrettyPrint/Aggregate/Patch; kein unbegrenzter Aufruf.
-- ============================================================================
CREATE OR ALTER PROCEDURE toolbelt_json.USP_JsonArray
 @EntriesTable sysname=NULL,
 @MaxEntries int=10000,
 @MaxTotalValueBytes bigint=2097152,
 @MaxResultBytes bigint=2097152,
 @ResultTable sysname=NULL,
 @KeepData bit=0,
 @Debug tinyint=0,
 @Hilfe bit=0
AS
BEGIN
 SET NOCOUNT ON;
 SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0),@Hilfe=COALESCE(@Hilfe,0);
 IF @Hilfe=1
 BEGIN
  DECLARE @Help TABLE(Section varchar(32) NOT NULL,Ordinal int NOT NULL,ItemName sysname NULL,SqlDataType varchar(256) NULL,IsRequired bit NULL,IsNullable bit NULL,DefaultValue nvarchar(4000) NULL,Description nvarchar(max) NOT NULL,ExampleSql nvarchar(max) NULL);
  INSERT @Help VALUES
  ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'JSON-Array aus Ordinal/ValueKind/Value; vollständig validiert und atomar geroutet.',NULL),
  ('PARAMETER',1,N'@EntriesTable','sysname',1,0,N'NULL',N'Bestehende caller-lokale #Temp, exakte erforderliche Typen, zusätzliche Spalten ignoriert.',NULL),
  ('PARAMETER',2,N'@MaxEntries','int',0,0,N'10000',N'Positive Grenze bis 100000; Ordinals positiv/eindeutig, Lücken erlaubt.',NULL),
  ('PARAMETER',3,N'@MaxTotalValueBytes','bigint',0,0,N'2097152',N'Summe DATALENGTH(Value), SQL-NULL zählt 0; höchstens 16777216.',NULL),
  ('PARAMETER',4,N'@MaxResultBytes','bigint',0,0,N'2097152',N'Exakte UTF-16-Ergebnisbytes einschließlich Escapes/Keys/Syntax; höchstens 16777216.',NULL),
  ('PARAMETER',5,N'@ResultTable','sysname',0,1,N'NULL',N'NULL: SELECT; sonst bestehende lokale Temp-Tabelle, nicht Eingabeobjekt.',NULL),
  ('PARAMETER',6,N'@KeepData','bit',0,1,N'0',N'Replace=0, Append=1; NULL entspricht 0.',NULL),
  ('PARAMETER',7,N'@Debug','tinyint',0,1,N'0',N'Nur Messages ohne Payloadinhalte; NULL entspricht 0.',NULL),
  ('PARAMETER',8,N'@Hilfe','bit',0,1,N'0',N'Help zuerst; ignoriert sämtliche anderen Parameter ohne Seiteneffekte.',NULL),
  ('RESULT_COLUMN',1,N'JsonValue','nvarchar(max)',1,0,NULL,N'Genau ein JSON-Wert, BIN2; leere Eingabe [].',NULL),
  ('ERROR',1,N'53600-53610',NULL,NULL,NULL,NULL,N'Parameter/Schema/Ordinal/Key/Kind/NULL/Unicode/Literal/Ressourcen/Dependency; Enginefehler unverändert.',NULL),
  ('PERMISSION',1,NULL,NULL,NULL,NULL,NULL,N'EXECUTE und lokale Temp-Sicht; ResultTable-Pfad zusätzlich Helper-EXECUTE.',NULL),
  ('LIMITATION',1,NULL,NULL,NULL,NULL,NULL,N'Nur string/number/boolean/null/json; json ist vollständiges Objekt/Array, kein Scalar. Keine Typinferenz.',NULL),
  ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Caller-Eingabe wird nicht mutiert.',N'CREATE TABLE #Entries(Ordinal int,ValueKind nvarchar(max),[Value] nvarchar(max)); EXEC toolbelt_json.USP_JsonArray @EntriesTable=N''#Entries'';');
  SELECT CAST('1.0' AS varchar(16)) HelpContractVersion,CAST(N'toolbelt_json' AS sysname) SchemaName,
  CAST(N'USP_JsonArray' AS sysname) ObjectName,Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql
  FROM @Help ORDER BY CASE Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2 WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 WHEN 'PERMISSION' THEN 5 WHEN 'LIMITATION' THEN 6 ELSE 7 END,Ordinal;
  RETURN;
 END;
 -- Diese Sicherheitsgrenze liegt vor Core-Compilation: ein Callerobjekt im
 -- reservierten Namespace kann sonst interne #Temp-Metadaten eclipsen und
 -- schon beim Compile statt des Vertragsfehlers einen Enginefehler auslösen.
 IF LEFT(LOWER(@EntriesTable COLLATE Latin1_General_100_BIN2),5) COLLATE Latin1_General_100_BIN2=N'#tbx_'
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Input',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Fragments',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Units',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Result',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_GroupResult',N'U') IS NOT NULL
 THROW 53601,N'JSON: reservierter interner Temp-Namespace ist im Caller belegt.',5;
 EXEC toolbelt_json.USP_JsonConstructInternal @ObjectMode=0,@EntriesTable=@EntriesTable,@MaxEntries=@MaxEntries,
 @MaxTotalValueBytes=@MaxTotalValueBytes,@MaxResultBytes=@MaxResultBytes,@ResultTable=@ResultTable,@KeepData=@KeepData,@Debug=@Debug;
END;
GO
-- ============================================================================
-- Objekt: toolbelt_json.USP_JsonObject; Typ: Stored Procedure
-- Zweck: Begrenzte JSON-Konstruktion aus caller-lokaler #Temp mit expliziten Kinds.
-- Vertrag: Documentation/USP_JsonObject.md; USP_CONTRACT 1.0
-- Parameter: EntriesTable sysname; positive MaxEntries/MaxTotalValueBytes/MaxResultBytes
-- Resultset: JsonValue nvarchar(max) NOT NULL, genau eine Zeile.
-- Dependencies: toolbelt.core.result-table >=1.0.0 same_database
-- Rechte: EXECUTE; eigene lokale Temps; keine Rechteausweitung.
-- Versionen: SQL Server 2019/2022/2025, Compatibility >=150; Windows/Linux.
-- Fehler: 53600-53610; vollständige Prüfung vor Zielmutation, Originalenginefehler.
-- Performance: begrenzter Snapshot, Fragmente und geordnete LOB-Aggregation.
-- Grenzen: keine Inferenz/PrettyPrint/Aggregate/Patch; kein unbegrenzter Aufruf.
-- ============================================================================
CREATE OR ALTER PROCEDURE toolbelt_json.USP_JsonObject
 @EntriesTable sysname=NULL,
 @MaxEntries int=10000,
 @MaxTotalValueBytes bigint=2097152,
 @MaxResultBytes bigint=2097152,
 @ResultTable sysname=NULL,
 @KeepData bit=0,
 @Debug tinyint=0,
 @Hilfe bit=0
AS
BEGIN
 SET NOCOUNT ON;
 SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0),@Hilfe=COALESCE(@Hilfe,0);
 IF @Hilfe=1
 BEGIN
  DECLARE @Help TABLE(Section varchar(32) NOT NULL,Ordinal int NOT NULL,ItemName sysname NULL,SqlDataType varchar(256) NULL,IsRequired bit NULL,IsNullable bit NULL,DefaultValue nvarchar(4000) NULL,Description nvarchar(max) NOT NULL,ExampleSql nvarchar(max) NULL);
  INSERT @Help VALUES
  ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'JSON-Object aus Ordinal/ValueKind/Value/Key; vollständig validiert und atomar geroutet.',NULL),
  ('PARAMETER',1,N'@EntriesTable','sysname',1,0,N'NULL',N'Bestehende caller-lokale #Temp, exakte erforderliche Typen, zusätzliche Spalten ignoriert.',NULL),
  ('PARAMETER',2,N'@MaxEntries','int',0,0,N'10000',N'Positive Grenze bis 100000; Ordinals positiv/eindeutig, Lücken erlaubt.',NULL),
  ('PARAMETER',3,N'@MaxTotalValueBytes','bigint',0,0,N'2097152',N'Summe DATALENGTH(Value), SQL-NULL zählt 0; höchstens 16777216.',NULL),
  ('PARAMETER',4,N'@MaxResultBytes','bigint',0,0,N'2097152',N'Exakte UTF-16-Ergebnisbytes einschließlich Escapes/Keys/Syntax; höchstens 16777216.',NULL),
  ('PARAMETER',5,N'@ResultTable','sysname',0,1,N'NULL',N'NULL: SELECT; sonst bestehende lokale Temp-Tabelle, nicht Eingabeobjekt.',NULL),
  ('PARAMETER',6,N'@KeepData','bit',0,1,N'0',N'Replace=0, Append=1; NULL entspricht 0.',NULL),
  ('PARAMETER',7,N'@Debug','tinyint',0,1,N'0',N'Nur Messages ohne Payloadinhalte; NULL entspricht 0.',NULL),
  ('PARAMETER',8,N'@Hilfe','bit',0,1,N'0',N'Help zuerst; ignoriert sämtliche anderen Parameter ohne Seiteneffekte.',NULL),
  ('RESULT_COLUMN',1,N'JsonValue','nvarchar(max)',1,0,NULL,N'Genau ein JSON-Wert, BIN2; leere Eingabe {}.',NULL),
  ('ERROR',1,N'53600-53610',NULL,NULL,NULL,NULL,N'Parameter/Schema/Ordinal/Key/Kind/NULL/Unicode/Literal/Ressourcen/Dependency; Enginefehler unverändert.',NULL),
  ('PERMISSION',1,NULL,NULL,NULL,NULL,NULL,N'EXECUTE und lokale Temp-Sicht; ResultTable-Pfad zusätzlich Helper-EXECUTE.',NULL),
  ('LIMITATION',1,NULL,NULL,NULL,NULL,NULL,N'Nur string/number/boolean/null/json; json ist vollständiges Objekt/Array, kein Scalar. Keine Typinferenz.',NULL),
  ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Caller-Eingabe wird nicht mutiert.',N'CREATE TABLE #Entries(Ordinal int,[Key] nvarchar(max),ValueKind nvarchar(max),[Value] nvarchar(max)); EXEC toolbelt_json.USP_JsonObject @EntriesTable=N''#Entries'';');
  SELECT CAST('1.0' AS varchar(16)) HelpContractVersion,CAST(N'toolbelt_json' AS sysname) SchemaName,
  CAST(N'USP_JsonObject' AS sysname) ObjectName,Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql
  FROM @Help ORDER BY CASE Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2 WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 WHEN 'PERMISSION' THEN 5 WHEN 'LIMITATION' THEN 6 ELSE 7 END,Ordinal;
  RETURN;
 END;
 -- Diese Sicherheitsgrenze liegt vor Core-Compilation: ein Callerobjekt im
 -- reservierten Namespace kann sonst interne #Temp-Metadaten eclipsen und
 -- schon beim Compile statt des Vertragsfehlers einen Enginefehler auslösen.
 IF LEFT(LOWER(@EntriesTable COLLATE Latin1_General_100_BIN2),5) COLLATE Latin1_General_100_BIN2=N'#tbx_'
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Input',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Fragments',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Units',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Result',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_GroupResult',N'U') IS NOT NULL
 THROW 53601,N'JSON: reservierter interner Temp-Namespace ist im Caller belegt.',5;
 EXEC toolbelt_json.USP_JsonConstructInternal @ObjectMode=1,@EntriesTable=@EntriesTable,@MaxEntries=@MaxEntries,
 @MaxTotalValueBytes=@MaxTotalValueBytes,@MaxResultBytes=@MaxResultBytes,@ResultTable=@ResultTable,@KeepData=@KeepData,@Debug=@Debug;
END;
GO
-- ============================================================================
-- Objekt: toolbelt_json.USP_JsonArraysByGroup; Typ: Stored Procedure
-- Zweck: Begrenzte JSON-Konstruktion aus caller-lokaler #Temp mit expliziten Kinds.
-- Vertrag: Documentation/USP_JsonArraysByGroup.md; USP_CONTRACT 1.0
-- Parameter: EntriesTable sysname; positive MaxEntries/MaxTotalValueBytes/MaxResultBytes
-- Resultset: GroupOrdinal int NOT NULL; JsonValue nvarchar(max) NOT NULL, eine Zeile je vorhandener Gruppe.
-- Dependencies: toolbelt.core.result-table >=1.0.0 same_database
-- Rechte: EXECUTE; eigene lokale Temps; keine Rechteausweitung.
-- Versionen: SQL Server 2019/2022/2025, Compatibility >=150; Windows/Linux.
-- Fehler: 53600-53610; vollständige Prüfung vor Zielmutation, Originalenginefehler.
-- Performance: begrenzter Snapshot, Fragmente und geordnete LOB-Aggregation.
-- Grenzen: keine Inferenz/PrettyPrint/Aggregate/Patch; kein unbegrenzter Aufruf.
-- ============================================================================
CREATE OR ALTER PROCEDURE toolbelt_json.USP_JsonArraysByGroup
 @EntriesTable sysname=NULL,
 @MaxEntries int=10000,
 @MaxTotalValueBytes bigint=2097152,
 @MaxResultBytes bigint=2097152,
 @ResultTable sysname=NULL,
 @KeepData bit=0,
 @Debug tinyint=0,
 @Hilfe bit=0
AS
BEGIN
 SET NOCOUNT ON;
 SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0),@Hilfe=COALESCE(@Hilfe,0);
 IF @Hilfe=1
 BEGIN
  DECLARE @Help TABLE(Section varchar(32) NOT NULL,Ordinal int NOT NULL,ItemName sysname NULL,SqlDataType varchar(256) NULL,IsRequired bit NULL,IsNullable bit NULL,DefaultValue nvarchar(4000) NULL,Description nvarchar(max) NOT NULL,ExampleSql nvarchar(max) NULL);
  INSERT @Help VALUES
  ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'JSON-Array aus GroupOrdinal/Ordinal/ValueKind/Value; vollständig validiert und atomar geroutet.',NULL),
  ('PARAMETER',1,N'@EntriesTable','sysname',1,0,N'NULL',N'Bestehende caller-lokale #Temp, exakte erforderliche Typen, zusätzliche Spalten ignoriert.',NULL),
  ('PARAMETER',2,N'@MaxEntries','int',0,0,N'10000',N'Positive Grenze bis 100000; GroupOrdinal positiv; (GroupOrdinal,Ordinal) eindeutig; globale Grenze.',NULL),
  ('PARAMETER',3,N'@MaxTotalValueBytes','bigint',0,0,N'2097152',N'Summe DATALENGTH(Value), SQL-NULL zählt 0; höchstens 16777216.',NULL),
  ('PARAMETER',4,N'@MaxResultBytes','bigint',0,0,N'2097152',N'Exakte UTF-16-Ergebnisbytes einschließlich Escapes/Keys/Syntax; höchstens 16777216.',NULL),
  ('PARAMETER',5,N'@ResultTable','sysname',0,1,N'NULL',N'NULL: SELECT; sonst bestehende lokale Temp-Tabelle, nicht Eingabeobjekt.',NULL),
  ('PARAMETER',6,N'@KeepData','bit',0,1,N'0',N'Replace=0, Append=1; NULL entspricht 0.',NULL),
  ('PARAMETER',7,N'@Debug','tinyint',0,1,N'0',N'Nur Messages ohne Payloadinhalte; NULL entspricht 0.',NULL),
  ('PARAMETER',8,N'@Hilfe','bit',0,1,N'0',N'Help zuerst; ignoriert sämtliche anderen Parameter ohne Seiteneffekte.',NULL),
  ('RESULT_COLUMN',1,N'GroupOrdinal','int',1,0,NULL,N'Positive Gruppenordinal, Lücken erlaubt; SELECT sortiert danach.',NULL),
  ('RESULT_COLUMN',2,N'JsonValue','nvarchar(max)',1,0,NULL,N'Ein JSON-Wert je Gruppe, BIN2; leere Eingabe erzeugt null Zeilen.',NULL),
  ('ERROR',1,N'53600-53610',NULL,NULL,NULL,NULL,N'Parameter/Schema/Ordinal/Key/Kind/NULL/Unicode/Literal/Ressourcen/Dependency; Enginefehler unverändert.',NULL),
  ('PERMISSION',1,NULL,NULL,NULL,NULL,NULL,N'EXECUTE und lokale Temp-Sicht; ResultTable-Pfad zusätzlich Helper-EXECUTE.',NULL),
  ('LIMITATION',1,NULL,NULL,NULL,NULL,NULL,N'Nur string/number/boolean/null/json; json ist vollständiges Objekt/Array, kein Scalar. Keine Typinferenz.',NULL),
  ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Caller-Eingabe wird nicht mutiert.',N'CREATE TABLE #Entries(GroupOrdinal int,Ordinal int,ValueKind nvarchar(max),[Value] nvarchar(max)); EXEC toolbelt_json.USP_JsonArraysByGroup @EntriesTable=N''#Entries'';');
  SELECT CAST('1.0' AS varchar(16)) HelpContractVersion,CAST(N'toolbelt_json' AS sysname) SchemaName,
  CAST(N'USP_JsonArraysByGroup' AS sysname) ObjectName,Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql
  FROM @Help ORDER BY CASE Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2 WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 WHEN 'PERMISSION' THEN 5 WHEN 'LIMITATION' THEN 6 ELSE 7 END,Ordinal;
  RETURN;
 END;
 -- Diese Sicherheitsgrenze liegt vor Core-Compilation: ein Callerobjekt im
 -- reservierten Namespace kann sonst interne #Temp-Metadaten eclipsen und
 -- schon beim Compile statt des Vertragsfehlers einen Enginefehler auslösen.
 IF LEFT(LOWER(@EntriesTable COLLATE Latin1_General_100_BIN2),5) COLLATE Latin1_General_100_BIN2=N'#tbx_'
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Input',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Fragments',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Units',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Result',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_GroupResult',N'U') IS NOT NULL
 THROW 53601,N'JSON: reservierter interner Temp-Namespace ist im Caller belegt.',5;
 EXEC toolbelt_json.USP_JsonConstructInternal @ObjectMode=0,@EntriesTable=@EntriesTable,@MaxEntries=@MaxEntries,
 @MaxTotalValueBytes=@MaxTotalValueBytes,@MaxResultBytes=@MaxResultBytes,@GroupMode=1,@ResultTable=@ResultTable,@KeepData=@KeepData,@Debug=@Debug;
END;
GO
-- ============================================================================
-- Objekt: toolbelt_json.USP_JsonObjectsByGroup; Typ: Stored Procedure
-- Zweck: Begrenzte JSON-Konstruktion aus caller-lokaler #Temp mit expliziten Kinds.
-- Vertrag: Documentation/USP_JsonObjectsByGroup.md; USP_CONTRACT 1.0
-- Parameter: EntriesTable sysname; positive MaxEntries/MaxTotalValueBytes/MaxResultBytes
-- Resultset: GroupOrdinal int NOT NULL; JsonValue nvarchar(max) NOT NULL, eine Zeile je vorhandener Gruppe.
-- Dependencies: toolbelt.core.result-table >=1.0.0 same_database
-- Rechte: EXECUTE; eigene lokale Temps; keine Rechteausweitung.
-- Versionen: SQL Server 2019/2022/2025, Compatibility >=150; Windows/Linux.
-- Fehler: 53600-53610; vollständige Prüfung vor Zielmutation, Originalenginefehler.
-- Performance: begrenzter Snapshot, Fragmente und geordnete LOB-Aggregation.
-- Grenzen: keine Inferenz/PrettyPrint/Aggregate/Patch; kein unbegrenzter Aufruf.
-- ============================================================================
CREATE OR ALTER PROCEDURE toolbelt_json.USP_JsonObjectsByGroup
 @EntriesTable sysname=NULL,
 @MaxEntries int=10000,
 @MaxTotalValueBytes bigint=2097152,
 @MaxResultBytes bigint=2097152,
 @ResultTable sysname=NULL,
 @KeepData bit=0,
 @Debug tinyint=0,
 @Hilfe bit=0
AS
BEGIN
 SET NOCOUNT ON;
 SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0),@Hilfe=COALESCE(@Hilfe,0);
 IF @Hilfe=1
 BEGIN
  DECLARE @Help TABLE(Section varchar(32) NOT NULL,Ordinal int NOT NULL,ItemName sysname NULL,SqlDataType varchar(256) NULL,IsRequired bit NULL,IsNullable bit NULL,DefaultValue nvarchar(4000) NULL,Description nvarchar(max) NOT NULL,ExampleSql nvarchar(max) NULL);
  INSERT @Help VALUES
  ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'JSON-Object aus GroupOrdinal/Ordinal/ValueKind/Value/Key; vollständig validiert und atomar geroutet.',NULL),
  ('PARAMETER',1,N'@EntriesTable','sysname',1,0,N'NULL',N'Bestehende caller-lokale #Temp, exakte erforderliche Typen, zusätzliche Spalten ignoriert.',NULL),
  ('PARAMETER',2,N'@MaxEntries','int',0,0,N'10000',N'Positive Grenze bis 100000; GroupOrdinal positiv; (GroupOrdinal,Ordinal) eindeutig; globale Grenze.',NULL),
  ('PARAMETER',3,N'@MaxTotalValueBytes','bigint',0,0,N'2097152',N'Summe DATALENGTH(Value), SQL-NULL zählt 0; höchstens 16777216.',NULL),
  ('PARAMETER',4,N'@MaxResultBytes','bigint',0,0,N'2097152',N'Exakte UTF-16-Ergebnisbytes einschließlich Escapes/Keys/Syntax; höchstens 16777216.',NULL),
  ('PARAMETER',5,N'@ResultTable','sysname',0,1,N'NULL',N'NULL: SELECT; sonst bestehende lokale Temp-Tabelle, nicht Eingabeobjekt.',NULL),
  ('PARAMETER',6,N'@KeepData','bit',0,1,N'0',N'Replace=0, Append=1; NULL entspricht 0.',NULL),
  ('PARAMETER',7,N'@Debug','tinyint',0,1,N'0',N'Nur Messages ohne Payloadinhalte; NULL entspricht 0.',NULL),
  ('PARAMETER',8,N'@Hilfe','bit',0,1,N'0',N'Help zuerst; ignoriert sämtliche anderen Parameter ohne Seiteneffekte.',NULL),
  ('RESULT_COLUMN',1,N'GroupOrdinal','int',1,0,NULL,N'Positive Gruppenordinal, Lücken erlaubt; SELECT sortiert danach.',NULL),
  ('RESULT_COLUMN',2,N'JsonValue','nvarchar(max)',1,0,NULL,N'Ein JSON-Wert je Gruppe, BIN2; leere Eingabe erzeugt null Zeilen.',NULL),
  ('ERROR',1,N'53600-53610',NULL,NULL,NULL,NULL,N'Parameter/Schema/Ordinal/Key/Kind/NULL/Unicode/Literal/Ressourcen/Dependency; Enginefehler unverändert.',NULL),
  ('PERMISSION',1,NULL,NULL,NULL,NULL,NULL,N'EXECUTE und lokale Temp-Sicht; ResultTable-Pfad zusätzlich Helper-EXECUTE.',NULL),
  ('LIMITATION',1,NULL,NULL,NULL,NULL,NULL,N'Nur string/number/boolean/null/json; json ist vollständiges Objekt/Array, kein Scalar. Keine Typinferenz.',NULL),
  ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Caller-Eingabe wird nicht mutiert.',N'CREATE TABLE #Entries(GroupOrdinal int,Ordinal int,[Key] nvarchar(max),ValueKind nvarchar(max),[Value] nvarchar(max)); EXEC toolbelt_json.USP_JsonObjectsByGroup @EntriesTable=N''#Entries'';');
  SELECT CAST('1.0' AS varchar(16)) HelpContractVersion,CAST(N'toolbelt_json' AS sysname) SchemaName,
  CAST(N'USP_JsonObjectsByGroup' AS sysname) ObjectName,Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql
  FROM @Help ORDER BY CASE Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2 WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 WHEN 'PERMISSION' THEN 5 WHEN 'LIMITATION' THEN 6 ELSE 7 END,Ordinal;
  RETURN;
 END;
 -- Diese Sicherheitsgrenze liegt vor Core-Compilation: ein Callerobjekt im
 -- reservierten Namespace kann sonst interne #Temp-Metadaten eclipsen und
 -- schon beim Compile statt des Vertragsfehlers einen Enginefehler auslösen.
 IF LEFT(LOWER(@EntriesTable COLLATE Latin1_General_100_BIN2),5) COLLATE Latin1_General_100_BIN2=N'#tbx_'
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Input',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Fragments',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Units',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_Result',N'U') IS NOT NULL
 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructor_GroupResult',N'U') IS NOT NULL
 THROW 53601,N'JSON: reservierter interner Temp-Namespace ist im Caller belegt.',5;
 EXEC toolbelt_json.USP_JsonConstructInternal @ObjectMode=1,@EntriesTable=@EntriesTable,@MaxEntries=@MaxEntries,
 @MaxTotalValueBytes=@MaxTotalValueBytes,@MaxResultBytes=@MaxResultBytes,@GroupMode=1,@ResultTable=@ResultTable,@KeepData=@KeepData,@Debug=@Debug;
END;
GO

BEGIN TRY
 IF XACT_STATE()<>1 OR @@TRANCOUNT<>1 OR OBJECT_ID(N'tempdb..#tbx_JsonConstructorDeployState',N'U') IS NULL
  THROW 53628,N'JSON lifecycle: eigene Deploymenttransaktion ist unvollständig.',1;
 DECLARE @Slots TABLE(Id int PRIMARY KEY,Name sysname COLLATE DATABASE_DEFAULT NOT NULL,Kind char(2) NOT NULL);
 INSERT @Slots VALUES(1,N'USP_JsonConstructInternal','P'),(2,N'USP_JsonArray','P'),(3,N'USP_JsonObject','P'),
 (4,N'USP_JsonArraysByGroup','P'),(5,N'USP_JsonObjectsByGroup','P'),
 (6,N'FT_JsonEntryEvaluateInternal','FT'),(7,N'AGF_JsonArray','AF'),(8,N'AGF_JsonObject','AF');
 IF EXISTS(SELECT 1 FROM @Slots WHERE OBJECT_ID(N'toolbelt_json.'+QUOTENAME(Name),Kind) IS NULL)
  THROW 53628,N'JSON lifecycle: Releaseobjekte sind unvollständig.',1;
 DECLARE @Mode nvarchar(16)=(SELECT DeploymentMode FROM #tbx_JsonConstructorDeployState),@Id int=1,@Name sysname,@ObjectId int,
  @LevelType varchar(16),@Kind char(2),@PropertyId int,@PropertyName sysname,@PropertyValue nvarchar(4000);
 DECLARE @Properties TABLE(Id int PRIMARY KEY,Name sysname,Value nvarchar(4000));
 WHILE @Id<=8
 BEGIN
  SELECT @Name=Name,@Kind=Kind FROM @Slots WHERE Id=@Id;
  SET @ObjectId=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(@Name),@Kind);
  SET @LevelType=CASE @Kind WHEN 'P' THEN 'PROCEDURE' WHEN 'AF' THEN 'AGGREGATE' ELSE 'FUNCTION' END;
  INSERT @Properties VALUES(1,N'Toolbelt.ModuleId',N'toolbelt.json.constructors'),(2,N'Toolbelt.ModuleVersion',N'1.3.0'),
   (3,N'Toolbelt.ContractVersion',N'1.0'),(4,N'Toolbelt.DeploymentMode',@Mode),
   (5,N'Toolbelt.SourceHash',CASE WHEN @Kind='P' THEN CONVERT(nvarchar(64),HASHBYTES(N'SHA2_256',CONVERT(varbinary(max),OBJECT_DEFINITION(@ObjectId))),2)
    WHEN @Kind='FT' THEN N'FCB13D767B7E0E449F8C7BDADCCE8344D4D4953D7EA098D07A3D4D115FCD868E'
    ELSE N'6A87B485C7862097A46164C077C875CBD32B76F2336A0757B25729684772350C' END);
  SET @PropertyId=1;
  WHILE @PropertyId<=5
  BEGIN
   SELECT @PropertyName=Name,@PropertyValue=Value FROM @Properties WHERE Id=@PropertyId;
   IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@ObjectId AND minor_id=0 AND name=@PropertyName)
    EXEC sys.sp_updateextendedproperty @name=@PropertyName,@value=@PropertyValue,@level0type=N'SCHEMA',@level0name=N'toolbelt_json',@level1type=@LevelType,@level1name=@Name;
   ELSE EXEC sys.sp_addextendedproperty @name=@PropertyName,@value=@PropertyValue,@level0type=N'SCHEMA',@level0name=N'toolbelt_json',@level1type=@LevelType,@level1name=@Name;
   SET @PropertyId+=1;
  END;
  DELETE FROM @Properties;
  SET @Id+=1;
 END;
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.Version')
  EXEC sys.sp_updateextendedproperty @name=N'Toolbelt.Module.toolbelt.json.constructors.Version',@value=N'1.3.0';
 ELSE EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Module.toolbelt.json.constructors.Version',@value=N'1.3.0';
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.DeploymentMode')
  EXEC sys.sp_updateextendedproperty @name=N'Toolbelt.Module.toolbelt.json.constructors.DeploymentMode',@value=@Mode;
 ELSE EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Module.toolbelt.json.constructors.DeploymentMode',@value=@Mode;
-- Modullokale geschlossene Registryzeile; kein Targethash als KnownInstalled-Fallback.
DECLARE @KnownHash varbinary(64)=0xFF266A2FC46EB4101D87BC046AEF63197B985C8CCBAEA40F372E9918D1254C44F1F2CF8CED7942383625D28E2E1AF5BF6164FA8A16B3DD5A16DF5957FAA34276,
 @KnownArtifactId varchar(64)='e5d0a37f7643a1a7bbe17602ab0d8457bc959464e97496f45f6ddbe92fa15525',@AssemblyId int,@AssemblyOwner int,@InstalledHash varbinary(64),
 @EffectiveOwner int,@KnownMode nvarchar(16),@KnownCount int,@CreatingSlots bit=0;
DECLARE @Parameters TABLE(Slot sysname,Id int,Name sysname,TypeId int,Length smallint);
INSERT @Parameters VALUES
(N'AGF_JsonArray',0,N'',231,-1),
(N'AGF_JsonArray',1,N'@Ordinal',56,4),
(N'AGF_JsonArray',2,N'@ValueKind',231,-1),
(N'AGF_JsonArray',3,N'@Value',231,-1),
(N'AGF_JsonArray',4,N'@Profile',48,1),
(N'AGF_JsonObject',0,N'',231,-1),
(N'AGF_JsonObject',1,N'@Ordinal',56,4),
(N'AGF_JsonObject',2,N'@Key',231,-1),
(N'AGF_JsonObject',3,N'@ValueKind',231,-1),
(N'AGF_JsonObject',4,N'@Value',231,-1),
(N'AGF_JsonObject',5,N'@Profile',48,1),
(N'FT_JsonEntryEvaluateInternal',1,N'@ObjectMode',104,1),
(N'FT_JsonEntryEvaluateInternal',2,N'@Key',231,-1),
(N'FT_JsonEntryEvaluateInternal',3,N'@ValueKind',231,-1),
(N'FT_JsonEntryEvaluateInternal',4,N'@Value',231,-1),
(N'FT_JsonEntryEvaluateInternal',5,N'@Stage',48,1),
(N'FT_JsonEntryEvaluateInternal',6,N'@Policy',48,1);
DECLARE @Columns TABLE(Id int,Name sysname,TypeId int,Length smallint);
INSERT @Columns VALUES
(1,N'Fragment',231,-1),
(2,N'ErrorNumber',56,4),
(3,N'ErrorState',56,4),
(4,N'FaultPhase',48,1),
(5,N'RawValueBytes',127,8),
(6,N'KeyBytes',127,8),
(7,N'StrongMinimumBytes',127,8),
(8,N'FragmentBytes',127,8);
-- Target1.3 separat; die historische1.2-Knownzeile bleibt unverändert.
DECLARE @TargetKnownHash varbinary(64)=0x8ab08a17d1be0b861043463e223154dffbed8273bc2c197cd7c8b791c3c06c4af418358e8e743d72068a3a9f726f7f85f50bcfa431df0484202ab562e1edb4bf,
 @TargetArtifactId varchar(64)='a6d81103af18a73a14e58339abb8c7835e0d16d559951cfc3a03d305b63e4a23';
-- Qualifizierte Offline-Corezeile; keine Trustfreigabe und keine Runtimeableitung.
DECLARE @JsonCoreKnownHash varbinary(64)=0x4680e9d34a0870924b5ca003cc5983882fc8ffb653e702bcc549e5f65dde11934c55ba7b356b519503ac5ce1e2478fe64876fea0295176ff13b5b4a6ab61b894,
 @JsonCoreArtifactId varchar(64)='975d4a84bb86e80b6e5844d6e86785ae0e98b13ee44c0f66c021507a23e0f888',
 @JsonCoreId int,@JsonCoreOwner int,@JsonCoreHash varbinary(64),
 @JsonCoreVersion nvarchar(max),@JsonCoreStoredMode nvarchar(max),
 @JsonCoreExpectedMode nvarchar(max),@JsonCoreRequired bit=1,@JsonCoreRemoving bit=0;
DECLARE @JsonCoreMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);
 DECLARE @Version nvarchar(max)=N'1.3.0',@SchemaId int=SCHEMA_ID(N'toolbelt_json');
 SELECT @KnownMode=@Mode,@KnownCount=8;
 DECLARE @MarkerId int=1,@MarkerName sysname,@MarkerValue sql_variant,
  @ModuleIdValue nvarchar(64)=N'toolbelt.json.constructors',@ModuleVersionValue nvarchar(16)=N'1.3.0',
  @ModeValue nvarchar(16)=@Mode,@ArtifactValue varchar(64)=@TargetArtifactId;
 DECLARE @AssemblyMarkers TABLE(Id int PRIMARY KEY,Name sysname,Value sql_variant);
 INSERT @AssemblyMarkers VALUES(1,N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),(2,N'Toolbelt.ModuleId',CONVERT(sql_variant,@ModuleIdValue)),
  (3,N'Toolbelt.ModuleVersion',CONVERT(sql_variant,@ModuleVersionValue)),(4,N'Toolbelt.DeploymentMode',CONVERT(sql_variant,@ModeValue)),
  (5,N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@TargetKnownHash)),(6,N'Toolbelt.ArtifactId',CONVERT(sql_variant,@ArtifactValue));
 WHILE @MarkerId<=6
 BEGIN
  SELECT @MarkerName=Name,@MarkerValue=Value FROM @AssemblyMarkers WHERE Id=@MarkerId;
  IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=(SELECT assembly_id FROM sys.assemblies WHERE name=N'Toolbelt_JsonConstructors') AND minor_id=0 AND name=@MarkerName)
   EXEC sys.sp_updateextendedproperty @name=@MarkerName,@value=@MarkerValue,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_JsonConstructors';
  ELSE EXEC sys.sp_addextendedproperty @name=@MarkerName,@value=@MarkerValue,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_JsonConstructors';
  SET @MarkerId+=1;
 END;
-- SQLCMD-Include im gemeinsamen Preflight, erneut unter derselben AppLock.
-- Keine Prozedur, keine eigene Mutation und keine Katalogzeile als Registryautorität.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
 THROW 53622,N'JSON lifecycle: vollständige CLR-/Dependency-Metadatensicht fehlt.',1;
IF @CreatingSlots=1 OR CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0')
BEGIN
 SELECT @JsonCoreExpectedMode=@Mode,@JsonCoreRequired=1;
-- Pure SQLCMD-Include: keine Helper-USP, Mutation, Trust- oder Ownerreparatur.
-- KnownArtifact.sql deklariert den Scope. Aufruf vor/unter der gemeinsamen Lock.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 THROW 55622,N'JSON Core: vollständige Assemblymetadatensicht fehlt.',1;
SELECT @JsonCoreId=NULL,@JsonCoreOwner=NULL,@JsonCoreHash=NULL,@JsonCoreVersion=NULL,@JsonCoreStoredMode=NULL;
SELECT @JsonCoreVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.Version';
SELECT @JsonCoreStoredMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode';
SELECT @JsonCoreId=a.assembly_id,@JsonCoreOwner=a.principal_id,@JsonCoreHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonCore';
IF @JsonCoreId IS NULL
BEGIN
 IF @JsonCoreRequired=1 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0
  AND name IN(N'Toolbelt.Module.toolbelt.json.core.Version',N'Toolbelt.Module.toolbelt.json.core.DeploymentMode'))
  THROW 55623,N'JSON Core: erforderliche bekannte Dependency fehlt oder ist inkohärent.',1;
END
ELSE
BEGIN
 IF @JsonCoreVersion IS NULL OR CONVERT(varbinary(max),@JsonCoreVersion)<>CONVERT(varbinary(max),N'1.0.0')
  OR @JsonCoreStoredMode IS NULL OR CONVERT(varbinary(max),@JsonCoreStoredMode)<>CONVERT(varbinary(max),@JsonCoreExpectedMode)
  OR @JsonCoreHash IS NULL OR @JsonCoreHash<>@JsonCoreKnownHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@JsonCoreId AND is_user_defined=1 AND permission_set=1 AND is_visible=0
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonCore'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@JsonCoreId)<>1
  THROW 55623,N'JSON Core: keine kohärente bekannte technische SAFE-Assembly.',1;
 DELETE FROM @JsonCoreMarkers;
 INSERT @JsonCoreMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.core'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.0.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@JsonCoreExpectedMode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@JsonCoreKnownHash)),
 (N'Toolbelt.ArtifactId',CONVERT(sql_variant,@JsonCoreArtifactId));
 IF EXISTS(SELECT 1 FROM @JsonCoreMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@JsonCoreId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value)
   AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55623,N'JSON Core: typisiertes bekanntes Markertuple ist inkohärent.',1;
 -- Die technische Dependency stellt keine eigenen oder fremden SQL-Slots bereit.
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: direkter SQL-Verbraucher blockiert den technischen Corevertrag.',1;
 IF @JsonCoreRemoving=1 AND EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: verbleibende Assemblyverbraucher blockieren den Abbau.',1;
END;
END;
SELECT @AssemblyId=NULL,@AssemblyOwner=NULL,@InstalledHash=NULL;
SELECT @AssemblyId=a.assembly_id,@AssemblyOwner=a.principal_id,@InstalledHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonConstructors';
DECLARE @ExpectedInstalledHash varbinary(64)=CASE WHEN CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0') THEN @TargetKnownHash ELSE @KnownHash END,
 @ExpectedInstalledArtifact varchar(64)=CASE WHEN CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0') THEN @TargetArtifactId ELSE @KnownArtifactId END;
IF @Version IS NULL OR CONVERT(varbinary(max),@Version) NOT IN(CONVERT(varbinary(max),N'1.2.0'),CONVERT(varbinary(max),N'1.3.0'))
BEGIN
 IF @AssemblyId IS NOT NULL THROW 53624,N'JSON lifecycle: neuer Assemblyslot ist fremd belegt.',1;
END
ELSE
BEGIN
 IF @AssemblyId IS NULL OR @InstalledHash IS NULL OR @InstalledHash<>@ExpectedInstalledHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@AssemblyId AND permission_set=1 AND is_user_defined=1
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonConstructors'))
  THROW 53623,N'JSON lifecycle: installierte Assembly ist kein bekanntes SAFE-Artefakt.',1;
 -- Die geschlossene Offlinezeile ist eigenständig, nicht der Targethash oder clr_name.
 IF NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
  AND name=N'Toolbelt.Managed' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'int'
  AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=4 AND DATALENGTH(value)=4 AND CONVERT(int,value)=1)
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.ModuleId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=128 AND DATALENGTH(value)=52
   AND CONVERT(varbinary(max),CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),N'toolbelt.json.constructors'))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.ModuleVersion' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=32 AND DATALENGTH(value)=10
   AND CONVERT(varbinary(max),CONVERT(nvarchar(16),value))=CONVERT(varbinary(max),@Version))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.DeploymentMode' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=32 AND DATALENGTH(value)=DATALENGTH(@KnownMode)
   AND CONVERT(varbinary(max),CONVERT(nvarchar(16),value))=CONVERT(varbinary(max),@KnownMode))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.AssemblySha512' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'varbinary'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=64 AND DATALENGTH(value)=64 AND CONVERT(varbinary(64),value)=@ExpectedInstalledHash)
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.ArtifactId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'varchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=64 AND DATALENGTH(value)=64
   AND CONVERT(varbinary(max),CONVERT(varchar(64),value))=CONVERT(varbinary(max),@ExpectedInstalledArtifact))
  THROW 53623,N'JSON lifecycle: typisiertes Assemblymarkertuple ist inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.assembly_modules m ON m.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
   WHERE s.Kind IN('FT','AF') AND (m.object_id IS NULL OR m.assembly_id<>@AssemblyId
    OR m.assembly_class IS NULL OR CONVERT(varbinary(max),m.assembly_class)<>CONVERT(varbinary(max),CASE s.Name
     WHEN N'FT_JsonEntryEvaluateInternal' THEN N'Toolbelt.JsonConstructors.JsonEntryEvaluateBridge'
     WHEN N'AGF_JsonArray' THEN N'Toolbelt.JsonConstructors.JsonArrayAggregate' ELSE N'Toolbelt.JsonConstructors.JsonObjectAggregate' END)
    OR (s.Kind='FT' AND (m.assembly_method IS NULL OR CONVERT(varbinary(max),m.assembly_method)<>CONVERT(varbinary(max),N'Evaluate')))
    OR (s.Kind='AF' AND m.assembly_method IS NOT NULL)))
  THROW 53623,N'JSON lifecycle: bekannte CLR-Bindings sind inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @Parameters e WHERE NOT EXISTS(SELECT 1 FROM sys.parameters p
  WHERE p.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(e.Slot)) AND p.parameter_id=e.Id
   AND CONVERT(varbinary(max),p.name)=CONVERT(varbinary(max),e.Name) AND p.system_type_id=e.TypeId
   AND p.user_type_id=p.system_type_id AND p.max_length=e.Length AND (p.parameter_id=0 OR p.is_output=0)))
  OR EXISTS(SELECT 1 FROM sys.parameters p JOIN @Slots s ON p.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
   WHERE s.Kind IN('FT','AF') AND NOT EXISTS(SELECT 1 FROM @Parameters e WHERE e.Slot=s.Name AND e.Id=p.parameter_id))
  THROW 53623,N'JSON lifecycle: CLR-Parametersignatur ist inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @Columns e WHERE NOT EXISTS(SELECT 1 FROM sys.columns c
  WHERE c.object_id=OBJECT_ID(N'toolbelt_json.FT_JsonEntryEvaluateInternal') AND c.column_id=e.Id
   AND CONVERT(varbinary(max),c.name)=CONVERT(varbinary(max),e.Name) AND c.system_type_id=e.TypeId
   AND c.user_type_id=c.system_type_id AND c.max_length=e.Length AND c.is_nullable=1))
  OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_JsonEntryEvaluateInternal'))<>8
  THROW 53623,N'JSON lifecycle: CLR-Bridgeresultschema ist inkohärent.',1;
END;
IF CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0')
 AND NOT EXISTS(SELECT 1 FROM sys.assembly_references WHERE assembly_id=@AssemblyId AND referenced_assembly_id=@JsonCoreId)
 THROW 53623,N'JSON lifecycle: bekannte1.3-Assembly referenziert den erforderlichen Core nicht.',1;
-- Vollständiger Verbrauchercheck; fremde direkte CLR-Slots und Assemblyreferenzen ebenfalls.
IF @AssemblyId IS NOT NULL AND (EXISTS(SELECT 1 FROM sys.assembly_modules m WHERE m.assembly_id=@AssemblyId
 AND NOT EXISTS(SELECT 1 FROM @Slots s WHERE OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))=m.object_id))
 OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@AssemblyId))
 THROW 53626,N'JSON lifecycle: fremder Assemblyverbraucher blockiert Lifecycle.',1;
IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d JOIN @Slots t ON d.referenced_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(t.Name))
 WHERE t.Id<=@KnownCount AND NOT EXISTS(SELECT 1 FROM @Slots s WHERE s.Id<=@KnownCount AND d.referencing_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))))
 THROW 53626,N'JSON lifecycle: fremder SQL-Verbraucher blockiert Lifecycle.',1;
IF @SchemaId IS NOT NULL
BEGIN
 SELECT @EffectiveOwner=MIN(COALESCE(o.principal_id,sc.principal_id))
  FROM @Slots s JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
  JOIN sys.schemas sc ON sc.schema_id=o.schema_id WHERE s.Id<=@KnownCount;
 IF @EffectiveOwner IS NULL SELECT @EffectiveOwner=principal_id FROM sys.schemas WHERE schema_id=@SchemaId;
 IF @EffectiveOwner IS NULL OR EXISTS(SELECT 1 FROM @Slots s JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
  JOIN sys.schemas sc ON sc.schema_id=o.schema_id WHERE s.Id<=@KnownCount AND COALESCE(o.principal_id,sc.principal_id)<>@EffectiveOwner)
  OR (@AssemblyId IS NOT NULL AND (@AssemblyOwner IS NULL OR @AssemblyOwner<>@EffectiveOwner))
  THROW 53623,N'JSON lifecycle: kohärente vorhandene Owner fehlen; keine Ownerreparatur.',1;
 -- Neue CLR-Objekte erben den Schemaowner. Ohne Owneränderung muss eine
 -- Migration bereits dazu kohärent sein; Repeat erhält explizite Owner.
 IF @CreatingSlots=1 AND @KnownCount<8 AND @KnownCount>0 AND @EffectiveOwner<>(SELECT principal_id FROM sys.schemas WHERE schema_id=@SchemaId)
  THROW 53623,N'JSON lifecycle: neue Slots würden inkohärente Owner erben.',1;
END;
IF (@CreatingSlots=1 OR CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0'))
 AND (@JsonCoreOwner IS NULL OR @JsonCoreOwner<>COALESCE(@EffectiveOwner,USER_ID()))
 THROW 53623,N'JSON lifecycle: Core-/Constructorowner sind inkohärent; keine Ownerreparatur.',1;
 DROP TABLE #tbx_JsonConstructorDeployState;
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.json.constructors
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.json.schema
:On Error exit
IF @@TRANCOUNT>0
BEGIN
 RAISERROR(N'JSON_SCHEMA_CALLER_TRANSACTION: aktive Callertransaktion ausgeschlossen.',16,1);
 RETURN;
END;
IF OBJECT_ID(N'tempdb..#tbx_JsonSchema_DeployState',N'U') IS NOT NULL
 THROW 55633,N'JSON Schema lifecycle: reservierter Callerzustand belegt.',1;
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;
DECLARE @Mode nvarchar(max)=N'central',@Bits varbinary(max)=0x4d5a90000300000004000000ffff0000b800000000000000400000000000000000000000000000000000000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a2400000000000000504500004c0103005ebf10870000000000000000e00022200b013000006400000006000000000000768300000020000000a000000000001000200000000200000400000000000000040000000000000000e000000002000000000000030040850000100000100000000010000010000000000000100000000000000000000000248300004f00000000a00000600300000000000000000000000000000000000000c000000c000000088300001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000080000000000000000000000082000004800000000000000000000002e746578740000007c630000002000000064000000020000000000000000000000000000200000602e727372630000006003000000a000000004000000660000000000000000000000000000400000402e72656c6f6300000c00000000c0000000020000006a000000000000000000000000000040000042000000000000000000000000000000005883000000000000480000000200050068530000a02f000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005602280a00000a02037d0200000402047d030000042a000013300400990000000100001103026f0b00000a33067e010000042a170a02036f0c00000a1f2b2e0b02036f0c00000a1f2d332904176a6f0d00000a02036f0c00000a1f2d3302150a0317d610012b0d04176a6f0d00000a0317d6100103026f0b00000a2f0b02036f0c00000a1f302edf03026f0b00000a33067e010000042a026f0b00000a03da0b04186a076ad8176ad66f0d00000a060203076f0e00000a73010000062a000000133005009400000002000011022d067e010000042a02166a320402ba2b0b166a02176ad6daba176ad70a060b160c03176a6f0d00000a0817d60c071f0a6a5c0b072deb03086a6f0d00000a088d270000010d0817da13042b2203176a6f0d00000a0911041f306a061f0a6a5ed7879d061f0a6a5c0a110417da13041104162fd903086a176ad66f0d00000a02166a3203172b011509730f00000a73010000062a13300300670000000300001104176a6f0d00000a026f0b00000a036f0b00000a2e12026f0b00000a036f0b00000a3202172a152a160a2b3004176a6f0d00000a02066f0c00000a03066f0c00000a2e1402066f0c00000a03066f0c00000a3202172a152a0617d60a06026f0b00000a32c7162a00133004004c0000000000000004176a6f0d00000a027b02000004037b020000042e12027b02000004037b020000043202172a152a027b020000042d02162a027b02000004027b03000004037b03000004042804000006d82a13300300680000000400001104176a6f0d00000a032d02022a030428030000060a027b020000042d02062a027b02000004067b02000004330902060428070000062a027b03000004067b030000040428040000060b072d067e010000042a071630090602046f080000062a02060428080000062a13300500e400000005000011027b030000046f0b00000a037b030000046f0b00000a281000000a17d60a04066a6f0d00000a068d270000010b027b030000046f0b00000a17da0c037b030000046f0b00000a17da0d1613040617da13062b5c04176a6f0d00000a110408162f03162b13027b03000004082517da0c6f0c00000a1f30dad609162f03162b13037b03000004092517da0d6f0c00000a1f30dad613070711061f3011071f0a5dd6b69d11071f0a5b1304110617da13061106162f9f0716931f30fe01130504066a11056ada176ad66f0d00000a027b02000004071105061105da731100000a73010000062a13300500010100000600001104027b030000046f0b00000a6a6f0d00000a027b030000046f0b00000a8d270000010a037b030000046f0b00000a17da0b160c027b030000046f0b00000a17da13042b5904176a6f0d00000a027b0300000411046f0c00000a1f30da08da07162f03162b13037b03000004072517da0b6f0c00000a1f30dada1305110516fe040c1105162f0711051f0ad613050611041f301105d6b69d110417da13041104162fa2082c0b7201000070731200000a7a160d2b0c04176a6f0d00000a0917d60d09068e692f070609931f302ee709068e6933067e010000042a04068e696a096ada176ad66f0d00000a027b020000040609068e6909da731100000a73010000062a46167e1300000a730100000680010000042a7202280a00000a02037d0400000402047d0500000402057d060000042a133002004800000000000000026f1400000a2c0d026f1400000a7b1500000a2c0b7221000070731200000a7a02036f1600000a6f1700000a182e0b723d000070731200000a7a02036f1800000a04280d0000062aae02162f0b7257000070731900000a7a031f0a6a6f0d00000a0f00281a00000a281b00000a03280d0000062a13300400630100000700001102166f0c00000a1f2d2e03172b01150a0616fe040b070c2b0c03176a6f0d00000a0817d60c08026f0b00000a2f1602086f0c00000a1f652e0b02086f0c00000a1f4533d50807da0d03096a6f0d00000a098d27000001130416130516130616130707130d2b3903176a6f0d00000a02110d6f0c00000a130e110e1f2e33051713072b16110411052517d61305110e9d11072c06110617d61306110d17d6130d110d0832c2161308110517da13092b0e03176a6f0d00000a110817d61308110811052f0911041108931f302ee311081105332703176a6f0d00000a1672630000707e01000004730a0000062a03176a6f0d00000a110917da130911091108310911041109931f302ee311051109da17da130a11091108da17d6130b08026f0b00000a2e0c020817d60328020000062b057e01000004110a6a11066ada036f06000006130c03110b6a176ad66f0d00000a0611041108110b731100000a110c730a0000062aaa03176a6f0d00000a027b040000042c18027b060000047e01000004036f0500000616fe0416fe012a172a5603176a6f0d00000a027b0400000416fe0416fe012a13300400010100000800001104176a6f0d00000a027b04000004037b040000042e12027b04000004037b040000043202172a152a027b040000042d02162a027b06000004027b050000046f0b00000a6a046f06000006037b06000004037b050000046f0b00000a6a046f060000060a06046f050000060b072c09027b0400000407d82a027b050000046f0b00000a037b050000046f0b00000a281000000a0c160d2b6404176a6f0d00000a09027b050000046f0b00000a32041f302b0c027b05000004096f0c00000a130409037b050000046f0b00000a32041f302b0c037b05000004096f0c00000a1305110411052e12027b04000004110411053203172b0115d82a0917d60d09083298162a960204281c00000a02037d0700000402047d0800000402057d09000004020e047d0a0000042a0013300300670000000000000002280a00000a02037d0b00000402047d0c00000404186a036f1d00000a6ad8196ad66f0d00000a0204731e00000a7d0d00000402036f1d00000a731f00000a7d0e00000402036f1d00000a732000000a7d0f000004027b0f0000041672670000706f2100000a2a0013300600c401000009000011027b0b000004036f1600000a0a160b066f2200000a0d2b160717d60b027b0b000004096f1600000a6f2300000a0d09162fe6027b0c000004076a176ad66f0d00000a07732400000a0c066f2200000a13042b1c0811046f2500000a027b0b00000411046f1600000a6f2300000a13041104162fdf04394801000007173e41010000027b0c000004076a6f0d00000a078d2d0000011305176a1306381a010000166a130738010100001107b7130811071106d6076a282600000ab713091109130a1107186a1106d8d6076a282600000ab7130b1107b7130c388d000000027b0c000004176a6f0d00000a110a110b2f4c110811092f43027b0d000004027b0b0000040811086f2700000a6f1600000a6f2800000a027b0b00000408110a6f2700000a6f1600000a6f2800000a6f2900000a16fe0216fe012b04162b0117130d1105110c110d2d0f08110a2517d6130a6f2700000a2b0d0811082517d613086f2700000a9e110c17d6130c110c110b3f6affffff1107b7130e2b20027b0c000004176a6f0d00000a08110e1105110e946f2a00000a110e17d6130e110e110b32da1107186a1106d8d613071107076a3ff6feffff1106186ad813061106076a3fddfeffff082a1b300300c70000000a000011027b0c000004176a6f0d00000a027b0e0000040312006f2b00000a3a98000000027b0b000004036f1600000a6f1700000a1a2e02152a02031628130000060c027b0c000004086f2c00000a6a176ad66f0d00000a086f2c00000a027b0d000004732d00000a0a086f2e00000a0d2b231203282f00000a130406027b0b00000411046f1600000a6f2800000a11046f3000000a1203283100000a2dd4de0e1203fe160500001b6f3200000adc027b0e00000403066f3300000a060412016f3400000a2d02152a072a000110000002006d00309d000e0000000013300400670100000b000011027b0c000004176a6f0d00000a027b0f0000040312006f3500000a2c02062a027b0c00000420810000006a6f0d00000a20810000008d2d0000010b160c030d2b38027b0c000004176a6f0d00000a08078e69330b7269000070731200000a7a07082517d60c099e027b0b000004096f1600000a6f3600000a0d027b0f0000040912006f3500000a2cb838d0000000070817da250c941304027b0b00000411046f1600000a1305027b0b00000411056f3600000a6f1600000a130611066f1700000a1a331611056f2800000a027b0c000004281600000613072b4a16130811066f2200000a13092b1a027b0b00000411096f1600000a6f2300000a1309110817d613081109110433e0027b0c0000041f0a6a6f0d00000a1208281a00000a281b00000a1307027b0c000004066f0b00000a6a11076f0b00000a6ad6186ad66f0d00000a0672810000701107283700000a0a027b0f0000041104066f2100000a08163d29ffffff062a00133003007e0000000c00001103186a026f0b00000a6ad8176ad66f0d00000a18026f0b00000ad8733800000a0a020b160c2b3a07086f0c00000a0d091f7e330e0672850000706f3900000a262b1b091f2f330e06728b0000706f3900000a262b0806096f3a00000a260817580c08076f0b00000a32bd03066f3b00000a6a6f0d00000a066f3c00000a2a9a0304020528150000060e042c0e0e046f0b00000a20800000003103142b020e0473110000067a0000001b3005009b0300000d000011027b0b000004036f1600000a6f3d00000a0a066f0b00000a2c0b06166f0c00000a1f232e1602729100007072a90000700372c30000706f17000006027b0c000004196a066f0b00000a6ad8186ad66f0d00000a066f0b00000a17da8d310000010b160c17130538bb0000000611056f0c00000a130611061f25337c110518d6066f0b00000a32160272cd00007072eb0000700372c30000706f1700000606110517d62513056f0c00000a2819000006130706110517d62513056f0c00000a2819000006130811071632051108162f160272cd00007072eb0000700372c30000706f1700000607082517d60c11071f10d81108d6b49c2b291106281a0000062d160272cd00007072eb0000700372c30000706f1700000607082517d60c1106869c110517d613051105066f0b00000a3f38ffffff001617733e00000a0716086f3f00000a0dde1f260272cd00007072eb0000700372c30000706f17000006151309dd33020000096f0b00000a2d02162a09166f0c00000a1f2f2e160272cd00007072eb0000700372c30000706f1700000616130417130a38ed010000110a130b2b13027b0c000004176a6f0d00000a110b17d6130b110b096f0b00000a2f0c09110b6f0c00000a1f2f33d7027b0c000004186a110b110ada6ad8176ad66f0d00000a110b110ada733800000a130c110a130e2b6d09110e6f0c00000a130f110f1f7e334d110e17d625130e110b2e1809110e6f0c00000a1f302e2209110e6f0c00000a1f312e160272cd00007072eb0000700372c30000706f1700000609110e6f0c00000a1f302e041f2f2b021f7e130f110c110f6f3a00000a26110e17d6130e110e110b328d110c6f3c00000a130d1104163f01010000027b0b00000411046f1600000a131011106f1700000a1a3311021104110d6f14000006130438d700000011106f1700000a1b40c7000000161311110d6f0b00000a16311e110d6f0b00000a172e11110d166f0c00000a1f30fe0116fe012b04172b01161312110d13131613142b4e111311146f0c00000a1315027b0c000004176a6f0d00000a11151f30321811151f393012111120ffffff7f11151f30dada1f0a5b31051613122b1e11111f0ad81115d61f30da1311111417581314111411136f0b00000a32a711122d03152b0711106f2200000a13042b14027b0b00000411046f1600000a6f2300000a1304110416320f11112517da13111630dd2b03151304110b096f0b00000a2e13110b17d6130a110a096f0b00000a3e06feffff11042a11092a0001100000000034011246011f13000001d6021f30320a021f393005021f30da2a021f41320d021f463008021f41da1f0ad62a021f613205021f663102152a021f61da1f0ad62aca021f413205021f5a3126021f613205021f7a311c021f303205021f393112720101007002284000000a16fe0416fe012a172a00000013300300530000000000000002157d1800000402280a00000a0e04186a0e056ad81b6ad66f0d00000a02037d1000000402047d11000004020e0505732d00000a7d12000004020e0505734100000a7d1300000402734200000a7d140000042a00133003006c00000003000011027b140000046f2c00000a027b140000046f4300000a333f027b140000046f4300000a2c0f027b140000046f4300000a18d82b011a0a04066a027b140000046f2c00000a6ad66f0d00000a027b14000004066f4400000a04176a6f0d00000a027b14000004036f2500000a2a13300300680000000000000002280a00000a02037d19000004037b0c000004186a037b0b0000046f1d00000a6ad8196ad66f0d00000a02037b0b0000046f1d00000a734500000a7d1a00000402037b0d000004734600000a7d1b00000402037b0b0000046f1d00000a732400000a7d1c0000042a1b300500950100000e000011021614281f0000062b78027b190000047b0c000004176a6f0d00000a027b1b0000046f4700000a0a1200284800000a261200284900000a0d1203284a00000a0b1200284900000a0d1203284b00000a0c1200284c00000a027b1b000004086f4d00000a2602027b1a000004076f4e00000a2820000006027b1c000004076f2500000a027b1b0000046f4f00000a163d77ffffff027b1c0000046f2e00000a130438890000001204282f00000a1305027b1a00000411056f4e00000a130611067b1200000472c300007012076f3400000a2c5c027b19000004110728180000061308110816320f027b1a00000411086f5000000a2d1c027b1900000472cd0000707229010070110772c30000706f17000006110611087d1800000411061108027b190000047b0c0000046f1c0000061204283100000a3a6bffffffde0e1204fe160500001b6f3200000adc027b1c0000046f2e00000a13042b1c1204282f00000a130902027b1a00000411096f4e00000a28250000061204283100000a2ddbde0e1204fe160500001b6f3200000adc0228260000062a000000011c00000200a0009c3c010e00000000020057012980010e0000000013300500c00000000f000011027b190000047b0c000004176a6f0d00000a027b1a000004036f5000000a3a87000000027b190000047b0b000004036f1600000a027b19000004036f150000060a6f1700000a1a2e03162b12027b1900000403166f130000066f2c00000a0b0306027b190000047b0d000004027b190000047b0c00000407731b0000060c027b1a00000403086f5100000a027b190000047b0c000004176a6f0d00000a027b1b00000406036f5200000a042c120403027b190000047b0c0000046f1c0000062a1b3006007706000010000011027b190000047b0b000004037b100000046f1600000a0a066f1700000a1a2e25066f1700000a172e1c027b1900000472cd000070723f010070037b10000004146f17000006066f1700000a17332e03177d1500000403027b190000047b0b000004037b100000046f1800000a7257010070285300000a7d160000042a027b19000004037b10000004176f130000066f2e00000a0b38c10500001201282f00000a0c027b190000047b0b000004086f1600000a0d096f2800000a1304027b190000047b0c00000411046f0b00000a6a176ad66f0d00000a037b120000041104086f3000000a110439570500001104280b00000a130611061a5945110000002f0000005000000001050000050000009b000000f2000000690200007a00000001050000d10000000105000001050000130100000105000001050000010500007f02000038fc040000110417280c00000a130711071f613b4901000011071f693b2a01000011071f733b0b01000038d2040000110416280c00000a130711071f243b3501000011071f743b4201000038b1040000110416280c00000a130711071f243b5601000011071f693b6301000011071f743b2e0100003887040000110416280c00000a130711071f643b5801000011071f703b650100003866040000110417280c00000a130711071f61594505000000900100003e0400004e0100003e0400006401000011071f693b710100003830040000110417280c00000a130711071f613bc701000011071f693ba8010000380f040000110417280c00000a130711071f613bd201000011071f693bb301000038ee03000011041f0a280c00000a130711071f613bdc01000011071f693bbd01000038cc03000011047261010070285300000a3ad301000038b603000011047271010070285300000a3a7003000038a003000011047281010070285300000a3a5a030000388a030000110472c3000070285300000a3ad8010000387403000011047291010070285300000a3aa8020000385e0300001104729b010070285300000a3aac0100003848030000110472a7010070285300000a3aa50100003832030000110472b3010070285300000a3add010000381c030000110472bf010070285300000a3a6a0100003806030000110472d7010070285300000a3abe01000038f0020000110472ef010070285300000a3a3e01000038da02000011047201020070285300000a3a0002000038c402000011047213020070285300000a3a0502000038ae02000011047225020070285300000a3aef010000389802000011047237020070285300000a3af500000038820200001104724d020070285300000a3a2d010000386c02000011047277020070285300000a3aad010000385602000011047293020070285300000a3a970100003840020000110472af020070285300000a3a81010000382a020000110472c3020070285300000a3a6b0100003814020000110472d7020070285300000a3ace01000038fe010000110472f9020070285300000a3ab801000038e801000002081911042821000006027b190000047b0d000004096f3d00000a721b0300706f2900000a39d6010000027b19000004729100007072750300700811046f1700000638b90100000208191104282100000638aa01000002081a11042821000006027b1900000408176f130000066f2e00000a13082b121208282f00000a130902110903281f0000061208283100000a2de5dd6a0100001208fe160500001b6f3200000adc020803281f000006384f01000002081b11042821000006027b1900000408166f13000006256f2c00000a2d18027b1900000472cd00007072810300700811046f170000066f2e00000a13082b121208282f00000a130a02110a03281f0000061208283100000a2de5ddef0000001208fe160500001b6f3200000adc02081104282200000638d3000000020308282300000638c600000002081811042821000006027b190000047b0b00000408027b190000047b0c000004280b00000613051105027b190000047b0c0000046f0e0000062c141105027b190000047b0c0000046f0f0000062d18027b1900000472cd00007072810300700811046f17000006037b13000004110411056f5400000a2b4d02081811042821000006037b130000041104027b190000047b0b00000408027b190000047b0c000004280b0000066f5400000a2b18027b190000047291000070729b0300700811046f170000061201283100000a3a33faffffde0e1201fe160500001b6f3200000adc2a00414c000002000000ce04000022000000f00400000e000000000000000200000049050000220000006b0500000e000000000000000200000094000000d4050000680600000e00000000000000c6027b190000047b0b000004036f1600000a6f1700000a042e17027b1900000472cd000070728103007003056f170000062a00001b300500be0000001100001102031b042821000006027b1900000403166f130000060a027b190000047b0c000004066f2c00000a6a176ad66f0d00000a066f2c00000a027b190000047b0d000004732d00000a0b066f2e00000a0c2b531202282f00000a0d020919042821000006027b190000047b0b000004096f1600000a6f3d00000a13040711046f5500000a2c17027b1900000472cd000070728103007009046f17000006071104096f3000000a1202283100000a2da4de0e1202fe160500001b6f3200000adc2a00000110000002004f0060af000e000000001b300600d600000012000011027b190000047b0b000004046f1600000a6f1700000a19330e03020428240000067d170000042a02041b72910100702821000006027b1900000404166f13000006256f2c00000a2d1b027b1900000472cd00007072810300700472910100706f170000066f2e00000a0a2b501200282f00000a0b02071972910100702821000006020728240000060c037b17000004085f2c1b027b1900000472cd00007072810300700772910100706f1700000603257b1700000408607d170000041200283100000a2da7de0e1200fe160500001b6f3200000adc2a00000110000002006a005dc7000e00000000133005002201000013000011027b190000047b0b000004036f1600000a6f3d00000a0a027b190000047b0c000004066f0b00000a6a176ad66f0d00000a0639ce00000006280b00000a0b071a594504000000350000008f0000001c0000000500000038aa0000000616280c00000a0c081f622e32081f692e3c38930000000616280c00000a0c081f6e2e39081f6f2e52081f732e3e2b7a0672c3030070285300000a2d5c2b6b0672cd030070285300000a2d4f2b5c0672dd030070285300000a2d4c2b4d0672ed030070285300000a2d332b3e0672fb030070285300000a2d262b2f067209040070285300000a2d192b20067217040070285300000a2d0d2b11172a182a1a2a1e2a1f102a1f202a1f402a027b1900000472cd00007072810300700372910100706f17000006162a0000133006007f01000014000011027b190000047b0c000004176a6f0d00000a037b140000046f2c00000a0a06182f012a027b190000047b0c000004066a6f0d00000a068d2d0000010b176a0c3832010000166a0d381d01000009b713040908d6066a282600000ab713051105130609186a08d8d6066a282600000ab7130709b7130838aa000000027b190000047b0c000004176a6f0d00000a110611072f5b110411052f52027b190000047b0d000004027b1a000004037b1400000411046f2700000a6f4e00000a7b11000004027b1a000004037b1400000411066f2700000a6f4e00000a7b110000046f2900000a16fe0216fe012b04162b0117130907110811092d14037b1400000411062517d613066f2700000a2b12037b1400000411042517d613046f2700000a9e110817d61308110811073f4dffffff09b7130a2b29027b190000047b0c000004176a6f0d00000a037b14000004110a07110a946f2a00000a110a17d6130a110a110732d109186a08d8d60d09066a3fdbfeffff08186ad80c08066a3fc6feffff2a001b300500d501000015000011027b190000047b0c000004027b190000047b0b0000046f1d00000a6a027b1a0000046f5600000a6ad6176ad66f0d00000a027b190000047b0b0000046f1d00000a8d310000010a027b1a0000046f5600000a17d68d0e0000020b027b1c0000046f2e00000a0c384d0100001202282f00000a0d027b190000047b0c000004176a6f0d00000a0609913a2b01000017130407161205fe150e0000021205097d330000041105a40e0000020609179c38fe000000027b190000047b0c000004176a6f0d00000a07110417daa30e0000021306027b1a00000411067b330000046f4e00000a130711067b3400000411077b140000046f2c00000a33150611067b33000004189c110417da130438a200000011077b1400000412067c34000004254a1309110917d65411096f2700000a130807110417da1106a40e0000020611089117334411077b1200000472c3000070120a6f3400000a2c0b110811077b180000042e0411082b02110a130b027b1900000472910000707223040070110b72c30000706f17000006061108912d25061108179c0711042517d613041205fe150e000002120511087d330000041105a40e0000021104163dfafeffff1202283100000a3aa7feffffde0e1202fe160500001b6f3200000adc2a000000411c0000020000006600000060010000c60100000e000000000000001e027b1d0000042a2202037d1d0000042a1e027b1e0000042a2202037d1e0000042a1e027b1f0000042a2202037d1f0000042a1e027b200000042a2202037d200000042a1e027b210000042a2202037d210000042a1e027b220000042a2202037d220000042a1e027b230000042a2202037d230000042a1e027b240000042a2202037d240000042a1e027b250000042a2202037d250000042a1e027b260000042a2202037d260000042a1e02280a00000a2a7202734000000603734000000604050e040e050e060e07283d0000062a001b3005007b02000016000011047237040070285700000a2d4705176a32420520000000016a30390e04176a32330e0420000010006a30290e051732240e052080000000301b0e06176a32150e062040420f006a300b0e071632060e071f64310b725f040070735800000a7a0e0717d6735900000a0a733b00000625727f0400706f280000062572370400706f2e0000060b06076f5a00000a026f420000062d08036f420000062c2206728f0400701205fe150c00001b1105728f04007016283f000006066f5b00000a2a0e06735c00000a0c140d161304186a036f43000006d80e04311272a104007072ad040070141473110000067a03086f4400000672cd0000700e0508283e000006731d000006256f1e000006171304186a026f43000006d805311272a104007072c7040070141473110000067a02086f4400000672e50400700e0508283e00000613061106060e0773450000060d096f4700000606097b310000042d0772ff0400702b05720b050070097b3100000416fe01735d00000a097b310000042d03142b05722d050070097b32000004283f000006dde0000000260672a10400701205fe150c00001b11057253050070092c08097b320000042b0116283f000006ddb400000013070711042d0911077b090000042b01146f340000060711042d03142b0711077b090000046f320000060711077b0a0000046f360000060e0716fe0113080e0716314f06733b0000062572750500706f2800000625176f2a00000625076f330000066f3400000625076f310000066f320000062511077b0a0000046f360000062511077b080000046f380000066f5a00000a0611077b070000041205fe150c00001b110511077b080000041108283f000006de00066f5b00000a2a00011c00000000cb00c994012c1c0000010000cb00c9c001b404000002133005007e00000017000011020405285e00000a256f1400000a7b1500000a18331272a10400707281050070141473110000067a256f1400000a7b1500000a2c0e037299050070141473110000067a256f5f00000a2d12729100007072b1050070141473110000067a250573120000060b12006f6000000a2d0e070372d705007006146f17000006072a00001b300300570000001800001102166f6100000a056f38000006026f6200000a0a2b271200286300000a25036f2c0000062572370400706f2e00000625046f300000060e046f3a0000061200286400000a2dd0de0e1200fe160d00001b6f3200000adc2a0001100000020014003448000e000000003a02280a00000a02037d280000042a3a02280a00000a02037d290000042a7a027b290000042c0c027b290000046f6500000a2a027b2800000414fe012a86027b290000042c0c027b290000046f6600000a2a027b280000046f0b00000a6a2abe03186a022843000006d86f0d00000a027b290000042c11027b290000046f6700000a730f00000a2a027b280000042a00133003006b0000000000000002280a00000a02037d2a00000402047d2b00000402057d2d000004020e047d2e00000402047b0c0000047d2c000004027b2c000004047b0b0000046f1d00000a6a196ad66f0d00000a02736800000a7d2f00000402047b0b0000046f1d00000a736900000a7d300000042a00133003009600000019000011027b2f0000046f6a00000a027b2f0000046f6b00000a3344027b2f0000046f6b00000a2c0f027b2f0000046f6b00000a18d82b011a0a027b2c000004066a027b2f0000046f6a00000a6ad66f0d00000a027b2f000004066f6c00000a027b2c000004176a6f0d00000a027b2f0000041201fe150f0000021201037d350000041201047d360000041201057d37000004076f6d00000a2a00001b300900740400001a0000110216161628460000063854040000027b2c000004176a6f0d00000a027b2f000004027b2f0000046f6a00000a17da6f6e00000a0a027b2f000004027b2f0000046f6a00000a17da6f6f00000a027b2a0000047b1a000004067b350000046f4e00000a0b027b2b0000047b0b000004067b360000046f1600000a0c067b3700000415332102067b36000004077b10000004724d02007072f3050070284c00000638be030000067b370000041f123cb1030000077b150000042c28077b160000043a9e03000002067b36000004077b1000000414721b060070284c000006388103000002077b10000004067b36000004067b3700000417d62846000006067b370000042d24077b18000004163f5303000002077b18000004067b36000004162846000006383b030000067b37000004173b2f030000067b37000004284d0000060d077b120000040912046f3400000a3910030000067b37000004130611061859450c000000050000006200000062000000ad0000003e0100003e0100006701000067010000b2010000b2010000dc010000dc010000381202000017086f1700000a1f1f5f621305086f1700000a18332002067b360000042848000006027b2c0000046f0e0000062c0711051f40601305077b1700000411055f3a8602000002067b360000041104097235060070284c000006386d020000086f1700000a1a40610200000207067b36000004110409027b2b000004067b36000004166f130000066f2c00000a067b3700000419fe01723f060070725d06007028490000063822020000086f1700000a1a4016020000027b2a0000047b190000041104166f130000066f2e00000a13072b4d1207282f00000a1308027b2b000004067b36000004027b2a0000047b190000047b0b00000411086f1600000a6f3d00000a6f14000006162f1402067b36000004110809727b060070284c0000061207283100000a2daadd9f0100001207fe160500001b6f3200000adc086f1700000a1a40850100000207067b360000041104067b370000041dfe01284a0000063868010000086f1700000a1b405c0100000207067b36000004110409027b2b000004067b36000004166f130000066f2c00000a067b370000041efe01728d06007072a10600702849000006381d010000086f1700000a1b40110100000207067b360000041104067b370000041f0bfe01284b00000638f3000000086f1700000a1940e70000000207067b36000004110409086f7000000a067b370000041f0cfe0172b506007072cb060070284900000638b8000000086f1700000a1840ac00000002067b360000042848000006077b13000004096f7100000a027b2c0000046f100000061309067b370000041f0e2e2f067b370000041f0f2e1e067b370000041f102e0a110916fe0416fe012b16110916fe0216fe012b0c110916fe022b05110916fe042c4702067b36000004110409067b370000041f0e2e29067b370000041f0f2e18067b370000041f102e0772e10600702b1372050700702b0c72290700702b057239070070284c000006027b2f0000046f6a00000a163d9bfbffff2a01100000020066025dc3020e0000000013300300440000001b000011027b2c000004176a6f0d00000a027b300000040312006f7200000a2d25027b2b0000047b0b00000403027b2c000004280b0000060a027b3000000403066f7300000a062a133005004b000000030000110e05027b2c000004280c000006037b130000040e046f7100000a027b2c0000046f100000060a0e062d060616fe022b040616fe042c140204050e040e062d040e082b020e07284c0000062a0013300400ce0000001c000011027b2b00000404176f130000060a037b12000004723702007012016f3400000a0c066f2c00000a17da0d389700000006096f2700000a1304082d03152b28027b2a0000047b1900000407027b2b0000047b0b00000411046f1600000a6f2800000a6f1400000613050e042d12110516320d02110511041628460000062b440e042c401105162f3b027b2a0000047b1a000004056f4e00000a130611067b150000042d0c020511041628460000062b1311067b160000042d0a020511041528460000060917da0d09163c62ffffff2a000013300400a40000001d000011027b2b00000404166f130000060a140c037b1200000472d701007012016f3400000a2c13027b2a0000047b1900000407166f130000060c082c08086f2c00000a2b01160d066f2c00000a17da13042b4e027b2c000004176a6f0d00000a0e042c17110409321202050611046f2700000a1628460000062b200e042d1c1104092f17020811046f2700000a0611046f2700000a162846000006110417da13041104162fad2a13300400a70000001e000011027b2c000004176a6f0d00000a02177d31000004027b2d0000046f7400000a17da027b2e000004330802177d320000042a027b2c000004186a6f0d00000a027b2b000004036f150000060a027b2a0000047b19000004046f150000060b027b2d000004733b0000062572750500706f2800000625027b2d0000046f7400000a6f2a00000625066f3200000625076f3400000625056f36000006250e046f380000066f5a00000a2a0013300200b500000000000000021859451000000002000000080000000e000000140000001a00000020000000260000002c00000032000000380000003e000000440000004a00000050000000560000005c0000002b6072910100702a72770200702a72930200702a72010200702a72370200702a724d0200702a72130200702a72250200702a72d70100702a72b30100702a72af0200702a72c30200702a72710100702a72810100702a72d70200702a72f90200702a7249070070731200000a7a000000133008007d000000000000000f02287500000a2d2d0f03287600000a2d240f04287600000a2d1b0f05287700000a2d120f06287600000a2d090f07287700000a2c0b725f040070735800000a7a0273410000060373410000060f02287800000a0f03287900000a0f04287900000a0f05287a00000a0f06287900000a0f07287a00000a283d0000062a00000013300200160100001f0000110274090000020a03066f27000006737b00000a812200000104066f29000006737c00000a812400000105066f2b000006737b00000a81220000010e04066f2d000006737b00000a81220000010e05066f2f0000060b1201287d00000a2d077e7e00000a2b13066f2f0000060b1201287f00000a738000000a81250000010e06066f310000062c12066f31000006288100000a738200000a2b05288300000a510e07066f330000062c12066f33000006288100000a738200000a2b05288300000a510e08066f350000062c0d066f35000006737b00000a2b057e8400000a81220000010e09066f370000062c0d066f37000006737b00000a2b057e8400000a81220000010e0a066f39000006738000000a81250000012a000042534a4201000100000000000c00000076342e302e33303331390000000005006c0000007c110000237e0000e81100004c0d000023537472696e677300000000341f00006c07000023555300a0260000100000002347554944000000b0260000f008000023426c6f620000000000000002000001571da2090902000000fa01330016000001000000370000000f000000370000004f0000009f0000008400000001000000260000001f000000020000000c000000160000000f00000001000000040000000200000000003d07010000000000060059052b0a060079052b0a0600cb04e9090f004b0a00000600f3041b0806003c051b0806000a051b080600df040c0a0600c90b7f070a00d40b64040a00250c640406009b087f070a001f09640406006f00be0006004a00be000a00ad0764043f00d10900000600f5089f0c060049089f0c0e006900be005300d109000006005a00be000a00b202640406002f047f070600b0042b0a060001007f0706004100be000a007c08640412001d0b8d0a120027059d091200c6029d091200c0029d090600c903ed0a120036068d0a12007c008d0a120051008d0a12008e078d0a06004c067f070600c9087f07060069067f07060062087f070a00160c400b06002d087f070600ae080608060054007f070600e5087f0706002d00be000600d5037f07060097057f07060019069f0c06001d069f0c06002100be00060093087f0706000c0006070a005204400b0000000085000000000001000100000110005a0b8e0025000100010001011000d5088e00250004000a000001100076048e0031000700110000011000a3038e0025000b001200800110001a038e00250010001800000110006f038e00250010001b0000011000ef0b8e00250019001d0001011000c00c8e0025001d00270081011000be098e00250027003c0000011000840c8e0025002800400000011000f5078e0025002a00450081011000b8038e00250033004e000b0110000d0400006100330050000b011000180400006100350050003300ba08ab032300d40779002300670b70002100d907790021006e0b70002100b809ab032300930b700023006a03700023006e06700023000a03700023002e0caf032300a906b3032300e306b7032100260bbb032100d00ac8032300ea00790023006e0670002300030ad0032300fc09d8032300650ae10303009907e8030300b605e8030300b30679000300250379002300a903eb0323005a0aef0321001106f80321000309e1030100b10170000100170279000100750270000100fe0170000100980100040100540270000100350270000100ca0170000100e301700001007701e8035680010470002100b30c70002100690707042100a2000b042100370ceb032100ae06b3032100a10b0f042100360b79002100d60a170421002e0b1f0403006701e80303002401e8030300ea00790003009a0c790003009b00790003002e0c79000300bf0879005020000000008118dc09280401006820000000009300400c2e0403001021000000009300330737040600b02100000000910039043f0408002422000000008300420447040b007c220000000083002a074f040d00f022000000008100840357040f00e023000000008100910357041100ed24000000009118e20960041300ff24000000008118dc09640413001c25000000009600a3076c04160070250000000096006e0c760419009c25000000009100ff057e041b000b27000000008600090986041d003627000000008600e20586041e004c2700000000860042048c041f005928000000008318dc09940421008028000000008318dc099c042500f428000000008300cb07a4042700c42a000000008300ce08ae042900a82b0000000083006e0687002b001c2d0000000093002804b4042c00a62d0000000083002507bb042e00d02d000000009300f005c30432008831000000009100df0cca043400be310000000091003f01cf043500f431000000008318dc09d40436005432000000008300b303df043b00cc32000000008318dc09e6043d004033000000008300aa0806003e000035000000008100f200ec043e00cc35000000008100a306f30440009c3c0000000081004a04f9044100d03c000000008100770a28044400ac3d000000008100820a01054600a03e000000008100340408054800d03f000000008100600af30449005c410000000081006b0a06004a005c43000000008608d50208014a006443000000008308e10210004a006d43000000008608bc061f004b007543000000008308cd0601004b007e43000000008608840b08014c0086430000000083088f0b10004c008f43000000008608e10308014d009743000000008308ed0310004d00a04300000000860847010d054e00a843000000008308530115054e00b143000000008608650908014f00b943000000008308790910004f00c243000000008608330908015000ca43000000008308450910005000d343000000008608fa0208015100db43000000008308060310005100e443000000008608410308015200ec430000000083084f0310005200f543000000008608f6005e015300fd430000000083080a01150053000644000000008618dc09060054000e44000000009600a7041e0554002c44000000009300750b2f055c00d046000000009100a104420564005c470000000091005d064c056800d047000000008318dc0910006d00df47000000008318dc095e056e00ee470000000083085e075e016f000d480000000083087806f9026f002f48000000008300ed0064056f006048000000008318dc096a057000d8480000000081006406790574007c49000000008300aa08060077000c4e000000008100de08800577005c4e000000008100720c86057800b44e000000008100b70793058000904f000000008100c607930584004050000000008100eb079c058800f4500000000091000a03a4058c00b851000000009600a704a9058d004452000000009600b80cc505950000000100d907000002006e0b00000100b30c000002007e0c00000300ae0600000100dc0500000200ae0600000100ea0b00000200ff0b00000300ae0600000100130900000200ae0600000100e30b00000200ae0600000100130900000200ae0600000100130900000200ae0600000100d907000002006e0b00000300b80900000100370c00000200e30c00000300ae0600000100780c00000200ae0600000100fe0600000200ae0600000100ae0600000100ae0600000100130900000200ae06000001009a0b000002007a0300000300730600000400120300000100370c00000200ae0600000100740100000200380100000100740100000200020d00000100740100000100020d00000200ae06000001009a0b000002007a0300000300740100000400120300000100ae03000002002f0300000100110c00000100110c00000100740100000200730600000300eb0600000400ae0600000500780c00000100740100000200ae0600000100ae03000001007401000002001909000001007f0300000100740100000200f502000003001203000001007401000002001203000001007f03000002007401000001007401000001007f0300000100dc0500000100dc0500000100dc0500000100dc0500000100dc0500000100dc0500000100dc0500000100dc0500000100dc0500000100dc0500000100a50800000200a20000000300f90300000400b10a00000500a20a00000600940600000700000b00000800360b00000100a50800000200a20000000300f90300000400b10a00000500a20a00000600940600000700000b00000800360b00000100900c000002006f01000003009d0600000400ae0600000100a10b000002009a0b000003007101000004007a03000005002e0100000100b30c00000100690700000100ae0600000100a20000000200370c00000300a10b00000400360b00000100d90000000200e20000000300c408000001007401000001007f0300000200740100000300e20700000400120300000500780c000006008607000007003903000008006703000001007f0300000200740100000300e20700000400f306000001007f0300000200740100000300e20700000400dc0a00000100e20000000200d900000003001203000004007a0300000100c40800000100a50800000200a20000000300f90300000400b10a00000500a20a00000600940600000700000b00000800360b00000100dc0502000200ed0202000300de06020004009a0b02000500f903020006005f01020007008d0902000800570902000900120302000a005d0302000b001e010900dc0901001100dc0906001900dc090a002900dc0910003100dc0910003900dc0910004100dc091500c900dc090600f100dc0906004900dc090600310178061f003101130b230051009c022800310153062d003101dc093c004101d00c58003101dc095e004901dc0910003101450d70005900d40c73005101930b79005900d00b7c008100a90282005900ab0c87005901dc091000610184048c006901400692006100dc0910005900640c1f006900dc09b7000c00dc0901001400dc0901001400f200d00081008d021f00810026061f001c00dc0901001c00f200f6004101de07fc001c006d0702018100ee0c0801690042040c011c00760712010c00d0052e011c00640c1f002400dc093e011c00ce094a012c00580c59012400f200d0002c00960c5e018101990406000c00f200d0002400d0052e011400d0052e0181004d0c1f003101c20b72019100dc0901009100a20281019100a2028701910078061f004900400608018100a60508019101dc09a90199014906af0131010906b7013400dc093e011c00dc0906001c00110d1f001c001e0d01003c00dc0901004400dc09d3014400ce09fa014c00960c5e014c00580c0c0254009c051e025400ee0c59014c00990406004400f80523023c006d0729024400640c1f003c00f60c23023c00f200d0004400f200d00031012b0d50023400f200d0002400f60c23023c00640c1f003101370d5002a901dc0910005c00dc0901005c00f200f6005c00060dca025100dc0928006400dc09f600b901e20ada025900c20a5e015900a60be3025c006d0702015c00ce094a016c00580c59016c00960c5e01e9005e075e01e9007806f902e9009c05fd027400dc0906007c00dc0901007400640c1f007400110d1f0074001e0d01007400f200f60074006d0702017400b90b0100810083061f0034006d0729027c00d0052e017c00f200d0005c00640c1f0011015e075e0119015e075e0121015e075e0111019c05080119019c05f90221019c051f001101dc0910002101dc0901006400c3055e01290164075e0364009c0559012901dc0915001101050c6303e900dc096a03e900550771031101640776030e009c0084032e000b0008062e00130011062e001b0030062e00230039062e002b0052062e00330081062e003b008e06a10343009406c10343009406e10343009406010443009406210443009406410443009406610443009406810443009406a10443009406c10443009406e00443009406000543009406200543009406400543009406600543009406800543009406a00543009406c00543009406e00543009406000643009406200643009406400643009406600643009406800643009406a00643009406c00643009406e00643009406000743009406200743009406400743009406c0094b0099061a003300420046004c0066009900ad00d8001901620179018d01de013002370256026b0275027b028a02a302d402e902110317032b0330033f034f035403090001000b000b000000e502f0050000d106f4050000930bf0050000f103f00500005701f80500007d09f00500004909f00500000a03f00500005303f00500000e01000600006207000600008d06040602002700030001002800030002002900050001002a00050002002b00070001002c00070002002d00090001002e00090002002f000b00010030000b00020031000d00010032000d00020033000f00010034000f0002003500110001003600110002003700130001003800130002003900150001003a001500020042001700020043001900bd00c900f00037015301bc01c401cc0105021702bd02c402f202020309030480000001000000010000000000000000008e0000000400000000000000000000007b03b5000000000001000000000000000000000000006404000000000400000000000000000000007b037f07000000000400000000000000000000007b03a900000000000e0008000f000c0000000000004e756c6c61626c65603100526561644f6e6c79436f6c6c656374696f6e60310049436f6d706172657260310049457175616c697479436f6d706172657260310049526561644f6e6c794c69737460310053716c496e743332004b657956616c756550616972603200536f7274656444696374696f6e61727960320053716c496e743634003c4d6f64756c653e00546f6f6c62656c742e4a736f6e536368656d6100736368656d610053797374656d2e44617461006d73636f726c69620053797374656d2e436f6c6c656374696f6e732e47656e6572696300736368656d61496400646f63756d656e744964005265616400416464006765745f4572726f72735472756e6361746564007365745f4572726f72735472756e6361746564006572726f72735472756e6361746564007472756e636174656400736f7274656400416c6c6f776564006765745f497356616c6964007365745f497356616c696400697356616c696400496e76616c696400696e76616c6964003c4572726f72735472756e63617465643e6b5f5f4261636b696e674669656c64003c497356616c69643e6b5f5f4261636b696e674669656c64003c526f774b696e643e6b5f5f4261636b696e674669656c64003c4b6579776f72643e6b5f5f4261636b696e674669656c64003c4572726f72436f64653e6b5f5f4261636b696e674669656c64003c50726f66696c653e6b5f5f4261636b696e674669656c64003c4572726f724f7264696e616c3e6b5f5f4261636b696e674669656c64003c536368656d61506f696e7465723e6b5f5f4261636b696e674669656c64003c446f63756d656e74506f696e7465723e6b5f5f4261636b696e674669656c64003c5374617475733e6b5f5f4261636b696e674669656c64006765745f46697273744368696c64005370656e6400417070656e64006765745f4b696e64004a736f6e56616c75654b696e640053797374656d446174614163636573734b696e64006765745f526f774b696e64007365745f526f774b696e6400726f774b696e64006b696e64006765745f4b6579776f7264007365745f4b6579776f7264006b6579776f7264004c6f63616c536368656d615265666572656e6365007265666572656e6365006d696e436f6465006765745f4572726f72436f6465007365745f4572726f72436f6465006572726f72436f6465006d6178436f646500536368656d614e6f646500636f6465006e6f6465004164644d61676e69747564650053756274726163744d61676e697475646500536368656d615472656500747265650045646765004a736f6e536368656d614272696467650049456e756d657261626c650049446973706f7361626c65006765745f50726f66696c65007365745f50726f66696c650070726f66696c650050726f66696c654e616d650047726170684672616d65004576616c756174696f6e4672616d65004573636170650056616c756554797065004d61676e6974756465436f6d706172650052657175697265004a736f6e43616e6f6e6963616c436f726500546f6f6c62656c742e4a736f6e436f726500536368656d614661696c757265006765745f496e76617269616e7443756c7475726500446973706f73650050617273650056616c696461746500436f6d70696c657247656e6572617465644174747269627574650044656275676761626c6541747472696275746500436f6d56697369626c6541747472696275746500417373656d626c795469746c6541747472696275746500417373656d626c7946696c6556657273696f6e4174747269627574650053716c46756e6374696f6e41747472696275746500417373656d626c794465736372697074696f6e41747472696275746500436f6d70696c6174696f6e52656c61786174696f6e734174747269627574650052756e74696d65436f6d7061746962696c6974794174747269627574650042797465006765745f56616c7565006765745f537472696e6756616c756500426f6f6c65616e56616c7565006765745f48617356616c75650054727947657456616c75650076616c75650049734e6f6e4e65676174697665005265736f6c76650052656d6f7665004e6f726d616c697a6500496e6465784f660070656e64696e670055544638456e636f64696e67006765745f4e6578745369626c696e670053716c537472696e6700546f537472696e6700476574537472696e6700537562737472696e670046696e6973680050757368004d61746800506174680070617468006765745f4c656e677468006765745f5363616c61724c656e677468006d6178446570746800646570746800436865636b00576f726b00776f726b00547970654d61736b006765745f4572726f724f7264696e616c007365745f4572726f724f7264696e616c006572726f724f7264696e616c006f7264696e616c006164646974696f6e616c006c69746572616c0053797374656d2e436f6c6c656374696f6e732e4f626a6563744d6f64656c004661696c00416464536d616c6c0046726f6d536d616c6c00546f6f6c62656c742e4a736f6e536368656d612e646c6c006765745f4e756c6c006765745f49734e756c6c0073716c006765745f4974656d007365745f4974656d0053797374656d006d696e696d756d0053716c426f6f6c65616e004973426f6f6c65616e0046726f6d546f6b656e004a736f6e546f6b656e004f626a6563744368696c6472656e0041727261794368696c6472656e005369676e007369676e004d696e006c6f636174696f6e0056696f6c6174696f6e00536368656d614576616c756174696f6e0053797374656d2e476c6f62616c697a6174696f6e0053797374656d2e5265666c656374696f6e00417267756d656e744f75744f6652616e6765457863657074696f6e004465636f64657246616c6c6261636b457863657074696f6e00496e76616c69644f7065726174696f6e457863657074696f6e004a736f6e576f726b4c696d6974457863657074696f6e00417267756d656e74457863657074696f6e006a736f6e0052756e0043756c74757265496e666f005a65726f005374657000737465700043686172004d656d6265720045786163744a736f6e4e756d6265720049466f726d617450726f766964657200537472696e674275696c646572006f72646572004973496e7465676572006f74686572006f776e6572004a736f6e4f7264696e616c436f6d7061726572006765745f536368656d61506f696e746572007365745f536368656d61506f696e74657200736368656d61506f696e746572006765745f446f63756d656e74506f696e746572007365745f446f63756d656e74506f696e74657200646f63756d656e74506f696e746572004d6963726f736f66742e53716c5365727665722e53657276657200706f77657200536368656d6156616c696461746f7200476574456e756d657261746f72002e63746f72002e6363746f720053797374656d2e446961676e6f737469637300426f756e6473004b6579776f7264730053797374656d2e52756e74696d652e496e7465726f7053657276696365730053797374656d2e52756e74696d652e436f6d70696c6572536572766963657300446562756767696e674d6f646573004e6f646573004f72646572456467657300436865636b4379636c657300436865636b4e616d657300436865636b54797065730053797374656d2e446174612e53716c5479706573006d6178536368656d614279746573006d6178446f63756d656e744279746573004465636f6465537472696e6773007061746873007461736b73006974656d73005363616e546f6b656e730053797374656d2e436f6c6c656374696f6e73006d61784576616c756174696f6e5374657073006765745f43686172730053716c4368617273006d656d62657273006e756d62657273006d61784572726f727300546f6f6c62656c742e4a736f6e436f6e7374727563746f7273005369676e6564446563696d616c446967697473006469676974730056616c6964617465496e70757473006765745f537461747573007365745f5374617475730073746174757300726f777300436865636b4475706c69636174654b6579730052656d6f7665417400436f6e636174004f626a65637400476574004a736f6e576f726b427564676574006f6666736574006c65667400536368656d61507265666c69676874007269676874006f705f496d706c6963697400756e6974004a736f6e5363616e526573756c74004a736f6e546f6b656e446f63756d656e7400646f63756d656e740046726f6d4578706f6e656e74006765745f506172656e74006765745f43757272656e74006765745f436f756e740046726f6d436f756e7400636f756e7400737461727400536368656d61496e70757400696e707574004d6f76654e6578740053797374656d2e54657874005261775465787400746578740046696c6c526f7700536368656d61526573756c74526f77004d6178006765745f53796e7461780048657800746f6b656e496e646578006765745f4b657900436f6e7461696e734b6579006b6579004173526561644f6e6c79006765745f4361706163697479007365745f4361706163697479006f705f457175616c697479006f705f496e657175616c69747900456d7074790000001f4500580050004f004e0045004e0054005f0042004f00520052004f005700001b4e0055004d004200450052005f00530059004e0054004100580000194e0055004d004200450052005f0054004f004b0045004e00000b63006f0075006e007400000330000001001754004f004b0045004e005f004400450050005400480000032f0000057e00300000057e003100001755004e0053005500500050004f0052005400450044000019450058005400450052004e0041004c005f0052004500460000092400720065006600001d49004e00560041004c00490044005f0053004300480045004d00410000155200450046005f00530059004e0054004100580000272d002e005f007e002100240026002700280029002a002b002c003b003d003a0040002f003f0001155200450046005f00540041005200470045005400001753004300480045004d0041005f0046004f0052004d0000097400720075006500000f240073006300680065006d006100000f6d0069006e0069006d0075006d00000f6d006100780069006d0075006d0000097400790070006500000b7400690074006c006500000b24006400650066007300000b6900740065006d00730000176400650073006300720069007000740069006f006e0000177000720065006600690078004900740065006d0073000011240063006f006d006d0065006e00740000117200650071007500690072006500640000116d0069006e004900740065006d00730000116d00610078004900740065006d0073000015700072006f00700065007200740069006500730000296100640064006900740069006f006e0061006c00500072006f007000650072007400690065007300001b6d0069006e00500072006f007000650072007400690065007300001b6d0061007800500072006f00700065007200740069006500730000136d0069006e004c0065006e0067007400680000136d00610078004c0065006e0067007400680000216500780063006c00750073006900760065004d0069006e0069006d0075006d0000216500780063006c00750073006900760065004d006100780069006d0075006d000059680074007400700073003a002f002f006a0073006f006e002d0073006300680065006d0061002e006f00720067002f00640072006100660074002f0032003000320030002d00310032002f0073006300680065006d006100010b4400520041004600540000194b004500590057004f00520044005f0046004f0052004d0000274b004500590057004f00520044005f0055004e0053005500500050004f00520054004500440000096e0075006c006c00000f62006f006f006c00650061006e00000f69006e0074006500670065007200000d6e0075006d00620065007200000d73007400720069006e006700000d6f0062006a00650063007400000b6100720072006100790000135200450046005f004300590043004c004500002774006f006f006c00620065006c0074002d0032003000320030002d00310032002d0076003100011f53004300480045004d0041005f0041005200470055004d0045004e005400000f530055004d004d004100520059000011530051004c005f004e0055004c004c00000b4c0049004d0049005400001953004300480045004d0041005f0042005900540045005300001d44004f00430055004d0045004e0054005f0042005900540045005300001949004e00560041004c00490044005f004a0053004f004e00000b560041004c0049004400002149004e00560041004c00490044005f0049004e005300540041004e0043004500002549004e005300540041004e00430045005f00560049004f004c004100540049004f004e0000214500560041004c0055004100540049004f004e005f004c0049004d0049005400000b4500520052004f0052000017440045005000540048005f004c0049004d004900540000174a0053004f004e005f00530059004e00540041005800002555004e005000410049005200450044005f0053005500520052004f004700410054004500001b4400550050004c00490043004100540045005f004b004500590000274100440044004900540049004f004e0041004c005f00500052004f00500045005200540059000019460041004c00530045005f0053004300480045004d00410000095400590050004500001d4d0049004e005f00500052004f005000450052005400490045005300001d4d00410058005f00500052004f00500045005200540049004500530000115200450051005500490052004500440000134d0049004e005f004900540045004d00530000134d00410058005f004900540045004d00530000154d0049004e005f004c0045004e0047005400480000154d00410058005f004c0045004e0047005400480000234500580043004c00550053004900560045005f004d004100580049004d0055004d0000234500580043004c00550053004900560045005f004d0049004e0049004d0055004d00000f4d004100580049004d0055004d00000f4d0049004e0049004d0055004d00001f4500560041004c0055004100540049004f004e005f0053005400450050000000000017ef2e08dab2004db7419540f00e4f1c00042001010803200001052001011111042001010e04200101020407020808032000080420010308042001010a0520020e08080807050b0b081d0308052001011d03030701080507021208080b0708081d03080808080808050002080808072003011d0308080907061d03080808080802060e0520001280a9020608052001124108042000115d0420010e080500001280b10620010e1280b913070f080808081d030808020808080812080803090706120808080803030520010112290b1512390208151239020e080615123902080e072002011300130117070f12410815123d010808081d080a0a080808080802080515123d01080520010113000500020a0a0a0520011300080320000e052002080e0e06200201081300140705151239020e080815123d010815114501080808200202130010130106151239020e080b20020108151280bd0113000820001511450113000515114501080420001300032000020f070a0e1d08080808124112410e08080600030e0e0e0e07070412490e080305200112490e0520011249031b07160e1d05080e080803080808080812490e0803124108020e08030520020102020720030e1d050808042001080307151239020e120c071512390208121c06151251020e080a200101151280d10113001b070a151155020e08080e151159020e08151145010808121c0808080a2000151155021300130106151155020e080a2000151159021300130106151159020e080420001301052001021300062001130113000607030e08121c18070b124115114501080812410e120c080315114501080808050002020e0e14070515123d0108151239020e081511450108080e090703151145010808080507030e08030e070b081d080a0a0808080808020818070c1d051d11381511450108080811381138121c0808080819070915123d01122412241229123002151169010212141210020615123d011224051511690102092000151280d9011300050702081214080003122d0e081229052001021008080701151145011224061511450112240320000a0420001d030615123d01113c071512390208120c05070208113c13070a113c121c12410e08080815114501080808040701120c0e070715123d01080802080808121c0f070515123d01080815123d010808080407020e0e0907021224151169010204061180950600011180890e062001011180890400001275040611808908b77a5c561934e0892674006f006f006c00620065006c0074002d0032003000320030002d00310032002d0076003100030612080306122d03061229030612350c061512390208151239020e08070615123902080e0706151239020e080806151239020e120c060615123d01080206020306121408061512390208121c0706151251020e08060615116901020306127503061220070615123d011224070615123d01113c08061512390208120c05200201080e08000312080e08122907000212080a1229070003080e0e1229072002081208122907200212080a12290820021208120812290300000107200301080e1208090003120c122d081229070002120c081229070002120c0e122905200102122907200208120c1229072004010e0e0e0e07200201122d122909200215123d0108080205200208080e0600020e0e1229072004010e0e080e06000208121408040001080304000102030a200501080e1235122908062002010812290520010112140620020108121c05200101121c0720030108115d0e06200201121c080420010808072000151169010208200101151169010210000815126d0112240e0e0e0a0a080a0812000815126d011224122c122c0e0a0a080a0809000412140e0e0812291100050115123d0112240e15116901020e020520010112750520010e12290e2004011220121415123d0112240806200301080808052001120c080c200801121c08080e08020e0e08200401121c0808020720040108080e0e0400010e081b00081280851275127511808911808d11808d11809111808d1180912a000b011c10118089101180911011808910118089101180951012751012751011808910118089101180950328000e032800080728001511690102032800020328000a0801000800000000001e01000100540216577261704e6f6e457863657074696f6e5468726f77730108010002000000000018010013546f6f6c62656c742e4a736f6e536368656d6100002e01002942656772656e7a74657220496e2d6d656d6f7279204a534f4e2d536368656d612d50726f766964657200000c010007312e302e312e30000005010000000004010000008253010006005455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630154020949735072656369736501540e1146696c6c526f774d6574686f644e616d650746696c6c526f77540e0f5461626c65446566696e6974696f6e80dd526f774b696e64206e766172636861722838292c204572726f724f7264696e616c20696e742c20537461747573206e76617263686172283234292c2050726f66696c65206e76617263686172283332292c20497356616c6964206269742c20446f63756d656e74506f696e746572206e76617263686172286d6178292c20536368656d61506f696e746572206e76617263686172286d6178292c204b6579776f7264206e7661726368617228313238292c204572726f72436f6465206e76617263686172283332292c204572726f72735472756e6361746564206269740000000000000000000000000000100000000000000000000000000000004c83000000000000000000006683000000200000000000000000000000000000000000000000000058830000000000000000000000005f436f72446c6c4d61696e006d73636f7265652e646c6c0000000000ff250020001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100100000001800008000000000000000000000000000000100010000003000008000000000000000000000000000000100000000004800000058a00000040300000000000000000000040334000000560053005f00560045005200530049004f004e005f0049004e0046004f0000000000bd04effe00000100000001000000010000000100000001003f000000000000000400000002000000000000000000000000000000440000000100560061007200460069006c00650049006e0066006f00000000002400040000005400720061006e0073006c006100740069006f006e00000000000000b00464020000010053007400720069006e006700460069006c00650049006e0066006f0000004002000001003000300030003000300034006200300000006c002a00010043006f006d006d0065006e00740073000000420065006700720065006e007a00740065007200200049006e002d006d0065006d006f007200790020004a0053004f004e002d0053006300680065006d0061002d00500072006f00760069006400650072000000500014000100460069006c0065004400650073006300720069007000740069006f006e000000000054006f006f006c00620065006c0074002e004a0073006f006e0053006300680065006d0061000000300008000100460069006c006500560065007200730069006f006e000000000031002e0030002e0031002e003000000050001800010049006e007400650072006e0061006c004e0061006d006500000054006f006f006c00620065006c0074002e004a0073006f006e0053006300680065006d0061002e0064006c006c0000002800020001004c006500670061006c0043006f0070007900720069006700680074000000200000005800180001004f0072006900670069006e0061006c00460069006c0065006e0061006d006500000054006f006f006c00620065006c0074002e004a0073006f006e0053006300680065006d0061002e0064006c006c000000340008000100500072006f006400750063007400560065007200730069006f006e00000031002e0030002e0031002e003000000038000800010041007300730065006d0062006c0079002000560065007200730069006f006e00000031002e0030002e0031002e00300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000c000000783300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000,
 @Pass int=0,@Lock int,@Initial varbinary(max),@Current varbinary(max),@OwnerName sysname,@Sql nvarchar(max);
-- Qualifizierte Offline-Schemazeile; keine Trustfreigabe.
DECLARE @SchemaKnownHash varbinary(64)=0x523b65979267457e8326ed2d5ec96d0309e9e1c7d5a0b2fbc0a3de68dcf7a9bb5a4f9cdda704ee0ba9f19097edbfb66eb8d649c0f2941b4a16adc2880bef880f,
 @SchemaArtifactId varchar(64)='22d1e92a612370b3e470c5ed893f6af61e55fd4465fcc3d362d4068e3cc6a02d';
-- Unveränderliche bekannte 1.0.0-Identität für Upgrade und release-aware Uninstall.
DECLARE @SchemaPreviousHash varbinary(64)=0xf67e0f9f3f6e83acc304e8e60bc98ee2610018e654ac4eb6e430f98a9665f9a1c85e90ef97950d348fcc0fc6389de71b214d1f9101835fec9a305ef39c41af21,
 @SchemaPreviousArtifactId varchar(64)='4ae51961dc53bd6aff96bb566e908cbb715d40512f36cffc756e7f2813a3a143';
-- Lokaler geschlossener Manifestzustand, genau zwei eigene SQL-Slots.
DECLARE @SchemaVersion nvarchar(max),@SchemaMode nvarchar(max),@SchemaAssemblyId int,@SchemaAssemblyOwner int,
 @SchemaInstalledHash varbinary(64),@SchemaInstalledArtifactId varchar(64),@SchemaOwner int,@SchemaInstalling bit=0,
 @SchemaResultVersion nvarchar(max),@SchemaResultId int,@SchemaMajor int,@SchemaMinor int,@SchemaPatch int,
 @SchemaConstructorId int,@SchemaConstructorVersion nvarchar(max);
DECLARE @SchemaSlots TABLE(Id int PRIMARY KEY,Name sysname NOT NULL,Kind char(2) NOT NULL);
INSERT @SchemaSlots VALUES(1,N'USP_ValidateJsonSchema','P'),(2,N'FT_ValidateJsonSchemaInternal','FT');
DECLARE @SchemaAssemblyMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);
DECLARE @SchemaConstructorMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);
DECLARE @SchemaParameters TABLE(Id int,Name sysname,TypeId int,Length smallint);
INSERT @SchemaParameters VALUES(1,N'@Json',231,-1),(2,N'@Schema',231,-1),(3,N'@Profile',231,64),
 (4,N'@MaxDocumentBytes',127,8),(5,N'@MaxSchemaBytes',127,8),(6,N'@MaxDepth',56,4),(7,N'@MaxEvaluationSteps',127,8),(8,N'@MaxErrors',56,4);
DECLARE @SchemaColumns TABLE(Id int,Name sysname,TypeId int,Length smallint);
INSERT @SchemaColumns VALUES(1,N'RowKind',231,16),(2,N'ErrorOrdinal',56,4),(3,N'Status',231,48),(4,N'Profile',231,64),
 (5,N'IsValid',104,1),(6,N'DocumentPointer',231,-1),(7,N'SchemaPointer',231,-1),(8,N'Keyword',231,256),
 (9,N'ErrorCode',231,64),(10,N'ErrorsTruncated',104,1);
DECLARE @SchemaPublicParameters TABLE(Id int,Name sysname,TypeId int,Length smallint,AliasName sysname NULL);
INSERT @SchemaPublicParameters SELECT Id,Name,CASE WHEN Id=3 THEN 167 ELSE TypeId END,CASE WHEN Id=3 THEN 32 ELSE Length END,NULL FROM @SchemaParameters;
INSERT @SchemaPublicParameters VALUES(9,N'@ResultTable',231,256,N'sysname'),(10,N'@KeepData',104,1,NULL),(11,N'@Debug',48,1,NULL),(12,N'@Hilfe',104,1,NULL);
-- Qualifizierte Offline-Corezeile; keine Trustfreigabe und keine Runtimeableitung.
DECLARE @JsonCoreKnownHash varbinary(64)=0x4680e9d34a0870924b5ca003cc5983882fc8ffb653e702bcc549e5f65dde11934c55ba7b356b519503ac5ce1e2478fe64876fea0295176ff13b5b4a6ab61b894,
 @JsonCoreArtifactId varchar(64)='975d4a84bb86e80b6e5844d6e86785ae0e98b13ee44c0f66c021507a23e0f888',
 @JsonCoreId int,@JsonCoreOwner int,@JsonCoreHash varbinary(64),
 @JsonCoreVersion nvarchar(max),@JsonCoreStoredMode nvarchar(max),
 @JsonCoreExpectedMode nvarchar(max),@JsonCoreRequired bit=1,@JsonCoreRemoving bit=0;
DECLARE @JsonCoreMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);
-- Target1.3 separat; die historische1.2-Knownzeile bleibt unverändert.
DECLARE @TargetKnownHash varbinary(64)=0x8ab08a17d1be0b861043463e223154dffbed8273bc2c197cd7c8b791c3c06c4af418358e8e743d72068a3a9f726f7f85f50bcfa431df0484202ab562e1edb4bf,
 @TargetArtifactId varchar(64)='a6d81103af18a73a14e58339abb8c7835e0d16d559951cfc3a03d305b63e4a23';
IF CONVERT(varbinary(max),@Mode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))
 THROW 55631,N'JSON Schema lifecycle: ungültiger Deploymentmodus.',1;
IF @Bits IS NULL OR HASHBYTES(N'SHA2_512',@Bits)<>@SchemaKnownHash
 THROW 55633,N'JSON Schema lifecycle: Targetbinary ist kein bekanntes qualifiziertes Artefakt.',1;
SET @SchemaInstalling=1;
BEGIN TRY
 WHILE @Pass<2
 BEGIN
  IF COALESCE(TRY_CONVERT(int,SERVERPROPERTY(N'ProductMajorVersion')),0) NOT IN(15,16,17)
   OR COALESCE((SELECT compatibility_level FROM sys.databases WHERE database_id=DB_ID()),0)<150
   THROW 55630,N'JSON Schema lifecycle: SQL-Version oder Compatibility Level nicht unterstützt.',1;
-- Pure Include: Own2-Slots, bekannte Assembly, Dependencies; keine Mutation.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
 THROW 55632,N'JSON Schema lifecycle: vollständige Metadatensicht fehlt.',1;
SELECT @SchemaVersion=NULL,@SchemaMode=NULL,@SchemaAssemblyId=NULL,@SchemaAssemblyOwner=NULL,@SchemaInstalledHash=NULL,@SchemaInstalledArtifactId=NULL;
SELECT @SchemaVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.Version';
SELECT @SchemaMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.DeploymentMode';
SELECT @SchemaAssemblyId=a.assembly_id,@SchemaAssemblyOwner=a.principal_id,@SchemaInstalledHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1 WHERE a.name=N'Toolbelt_JsonSchema';
IF @SchemaVersion IS NULL
BEGIN
 IF @SchemaAssemblyId IS NOT NULL OR @SchemaMode IS NOT NULL
  OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.Version')
  OR EXISTS(SELECT 1 FROM @SchemaSlots WHERE OBJECT_ID(N'toolbelt_json.'+QUOTENAME(Name)) IS NOT NULL)
  THROW 55634,N'JSON Schema lifecycle: unregistrierter oder fremder Zielslot.',1;
END
ELSE
BEGIN
 SET @SchemaInstalledArtifactId=CASE
  WHEN CONVERT(varbinary(max),@SchemaVersion)=CONVERT(varbinary(max),N'1.0.0') AND @SchemaInstalledHash=@SchemaPreviousHash THEN @SchemaPreviousArtifactId
  WHEN CONVERT(varbinary(max),@SchemaVersion)=CONVERT(varbinary(max),N'1.0.1') AND @SchemaInstalledHash=@SchemaKnownHash THEN @SchemaArtifactId END;
 IF @SchemaInstalledArtifactId IS NULL
  OR @SchemaMode IS NULL OR CONVERT(varbinary(max),@SchemaMode)<>CONVERT(varbinary(max),@Mode)
  OR @SchemaAssemblyId IS NULL OR @SchemaInstalledHash IS NULL
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@SchemaAssemblyId AND is_user_defined=1 AND permission_set=1 AND is_visible=1
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonSchema'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@SchemaAssemblyId)<>1
  THROW 55633,N'JSON Schema lifecycle: unbekannter oder inkohärenter Releasezustand.',1;
 DELETE FROM @SchemaAssemblyMarkers;
 INSERT @SchemaAssemblyMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.schema'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),@SchemaVersion))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@Mode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@SchemaInstalledHash)),(N'Toolbelt.ArtifactId',CONVERT(sql_variant,@SchemaInstalledArtifactId));
 IF EXISTS(SELECT 1 FROM @SchemaAssemblyMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@SchemaAssemblyId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value) AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55633,N'JSON Schema lifecycle: typisiertes Assemblymarkertuple inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @SchemaSlots slot WHERE NOT EXISTS(SELECT 1 FROM sys.objects o
  WHERE o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(slot.Name)) AND CONVERT(varbinary(2),o.type)=CONVERT(varbinary(2),slot.Kind)
   AND CONVERT(varbinary(max),o.name)=CONVERT(varbinary(max),slot.Name)
   AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleId'
    AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.json.schema'))
   AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleVersion'
    AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@SchemaVersion))
   AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.DeploymentMode'
    AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Mode))))
  THROW 55633,N'JSON Schema lifecycle: objektgenaue Ownership inkohärent.',1;
 IF NOT EXISTS(SELECT 1 FROM sys.assembly_modules WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') AND assembly_id=@SchemaAssemblyId
  AND CONVERT(varbinary(max),assembly_class)=CONVERT(varbinary(max),N'Toolbelt.JsonSchema.JsonSchemaBridge')
  AND CONVERT(varbinary(max),assembly_method)=CONVERT(varbinary(max),N'Validate'))
  OR EXISTS(SELECT 1 FROM @SchemaParameters expected WHERE NOT EXISTS(SELECT 1 FROM sys.parameters p
   WHERE p.object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') AND p.parameter_id=expected.Id
    AND CONVERT(varbinary(max),p.name)=CONVERT(varbinary(max),expected.Name) AND p.system_type_id=expected.TypeId
    AND p.user_type_id=p.system_type_id AND p.max_length=expected.Length AND p.is_output=0))
  OR (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal'))<>8
  OR EXISTS(SELECT 1 FROM @SchemaColumns expected WHERE NOT EXISTS(SELECT 1 FROM sys.columns c
   WHERE c.object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') AND c.column_id=expected.Id
    AND CONVERT(varbinary(max),c.name)=CONVERT(varbinary(max),expected.Name) AND c.system_type_id=expected.TypeId
    AND c.user_type_id=c.system_type_id AND c.max_length=expected.Length AND c.is_nullable=1))
  OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal'))<>10
  THROW 55633,N'JSON Schema lifecycle: CLR-Binding-/Parameters-/Spaltenvertrag inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @SchemaPublicParameters expected WHERE NOT EXISTS(SELECT 1 FROM sys.parameters p
  WHERE p.object_id=OBJECT_ID(N'toolbelt_json.USP_ValidateJsonSchema') AND p.parameter_id=expected.Id
   AND CONVERT(varbinary(max),p.name)=CONVERT(varbinary(max),expected.Name) AND p.system_type_id=expected.TypeId
   AND p.max_length=expected.Length AND p.is_output=0
   AND ((expected.AliasName IS NULL AND p.user_type_id=p.system_type_id)
    OR (expected.AliasName IS NOT NULL AND CONVERT(varbinary(max),TYPE_NAME(p.user_type_id))=CONVERT(varbinary(max),expected.AliasName)))))
  OR (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID(N'toolbelt_json.USP_ValidateJsonSchema'))<>12
  THROW 55633,N'JSON Schema lifecycle: öffentliche Parametersignatur inkohärent.',1;
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@SchemaAssemblyId AND object_id<>OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal'))
  OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@SchemaAssemblyId)
  OR EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d JOIN @SchemaSlots target ON d.referenced_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(target.Name))
   WHERE NOT EXISTS(SELECT 1 FROM @SchemaSlots own WHERE d.referencing_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(own.Name))))
  THROW 55636,N'JSON Schema lifecycle: fremder Verbraucher blockiert Lifecycle.',1;
END;
IF @SchemaInstalling=1 OR @SchemaAssemblyId IS NOT NULL
BEGIN
 SELECT @JsonCoreExpectedMode=@Mode,@JsonCoreRequired=1;
-- Pure SQLCMD-Include: keine Helper-USP, Mutation, Trust- oder Ownerreparatur.
-- KnownArtifact.sql deklariert den Scope. Aufruf vor/unter der gemeinsamen Lock.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 THROW 55622,N'JSON Core: vollständige Assemblymetadatensicht fehlt.',1;
SELECT @JsonCoreId=NULL,@JsonCoreOwner=NULL,@JsonCoreHash=NULL,@JsonCoreVersion=NULL,@JsonCoreStoredMode=NULL;
SELECT @JsonCoreVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.Version';
SELECT @JsonCoreStoredMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode';
SELECT @JsonCoreId=a.assembly_id,@JsonCoreOwner=a.principal_id,@JsonCoreHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonCore';
IF @JsonCoreId IS NULL
BEGIN
 IF @JsonCoreRequired=1 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0
  AND name IN(N'Toolbelt.Module.toolbelt.json.core.Version',N'Toolbelt.Module.toolbelt.json.core.DeploymentMode'))
  THROW 55623,N'JSON Core: erforderliche bekannte Dependency fehlt oder ist inkohärent.',1;
END
ELSE
BEGIN
 IF @JsonCoreVersion IS NULL OR CONVERT(varbinary(max),@JsonCoreVersion)<>CONVERT(varbinary(max),N'1.0.0')
  OR @JsonCoreStoredMode IS NULL OR CONVERT(varbinary(max),@JsonCoreStoredMode)<>CONVERT(varbinary(max),@JsonCoreExpectedMode)
  OR @JsonCoreHash IS NULL OR @JsonCoreHash<>@JsonCoreKnownHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@JsonCoreId AND is_user_defined=1 AND permission_set=1 AND is_visible=0
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonCore'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@JsonCoreId)<>1
  THROW 55623,N'JSON Core: keine kohärente bekannte technische SAFE-Assembly.',1;
 DELETE FROM @JsonCoreMarkers;
 INSERT @JsonCoreMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.core'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.0.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@JsonCoreExpectedMode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@JsonCoreKnownHash)),
 (N'Toolbelt.ArtifactId',CONVERT(sql_variant,@JsonCoreArtifactId));
 IF EXISTS(SELECT 1 FROM @JsonCoreMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@JsonCoreId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value)
   AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55623,N'JSON Core: typisiertes bekanntes Markertuple ist inkohärent.',1;
 -- Die technische Dependency stellt keine eigenen oder fremden SQL-Slots bereit.
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: direkter SQL-Verbraucher blockiert den technischen Corevertrag.',1;
 IF @JsonCoreRemoving=1 AND EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: verbleibende Assemblyverbraucher blockieren den Abbau.',1;
END;
 -- Schema installiert/repariert weder ResultTable noch Constructors.
 IF @SchemaInstalling=1
 BEGIN
 SELECT @SchemaResultVersion=NULL;
 SELECT @SchemaResultVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
 SELECT @SchemaResultId=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P'),@SchemaMajor=TRY_CONVERT(int,PARSENAME(@SchemaResultVersion,3)),
  @SchemaMinor=TRY_CONVERT(int,PARSENAME(@SchemaResultVersion,2)),@SchemaPatch=TRY_CONVERT(int,PARSENAME(@SchemaResultVersion,1));
 IF @SchemaResultId IS NULL OR @SchemaMajor IS NULL OR @SchemaMajor<1 OR @SchemaMinor IS NULL OR @SchemaMinor<0 OR @SchemaPatch IS NULL OR @SchemaPatch<0
  OR CONVERT(varbinary(max),@SchemaResultVersion)<>CONVERT(varbinary(max),CONCAT(@SchemaMajor,N'.',@SchemaMinor,N'.',@SchemaPatch))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@SchemaResultId AND minor_id=0 AND name=N'Toolbelt.ModuleId'
   AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.core.result-table'))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@SchemaResultId AND minor_id=0 AND name=N'Toolbelt.ModuleVersion'
   AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@SchemaResultVersion))
  THROW 55632,N'JSON Schema lifecycle: registrierte ResultTable-Dependency >=1.0.0 fehlt.',1;
 END;
 SELECT @SchemaOwner=COALESCE((SELECT principal_id FROM sys.schemas WHERE name=N'toolbelt_json'),USER_ID());
 IF @SchemaOwner IS NULL OR @SchemaOwner<>@JsonCoreOwner OR (@SchemaAssemblyId IS NOT NULL AND @SchemaAssemblyOwner<>@SchemaOwner)
  OR EXISTS(SELECT 1 FROM @SchemaSlots slot JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(slot.Name))
   WHERE COALESCE(o.principal_id,@SchemaOwner)<>@SchemaOwner)
  THROW 55633,N'JSON Schema lifecycle: kohärente vorhandene Owner fehlen; keine Ownerreparatur.',1;
 IF @SchemaAssemblyId IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.assembly_references WHERE assembly_id=@SchemaAssemblyId AND referenced_assembly_id=@JsonCoreId)
  THROW 55633,N'JSON Schema lifecycle: bekannte Assembly referenziert Core nicht.',1;
END;
-- Eine vorliegende Legacy1.2-Assembly würde einen zweiten aktuellen Scanner
-- aktiv lassen. Diese Read-only-Dependencyprüfung verändert Constructors nicht.
IF @SchemaInstalling=1 AND (EXISTS(SELECT 1 FROM sys.assemblies WHERE name=N'Toolbelt_JsonConstructors')
 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.Version'))
BEGIN
 SELECT @SchemaConstructorId=NULL,@SchemaConstructorVersion=NULL;
 SELECT @SchemaConstructorVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.Version';
 SELECT @SchemaConstructorId=a.assembly_id FROM sys.assemblies a JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
  WHERE a.name=N'Toolbelt_JsonConstructors' AND a.permission_set=1 AND a.is_user_defined=1 AND a.principal_id=@JsonCoreOwner
   AND HASHBYTES(N'SHA2_512',f.content)=@TargetKnownHash;
 IF @SchemaConstructorVersion IS NULL OR CONVERT(varbinary(max),@SchemaConstructorVersion)<>CONVERT(varbinary(max),N'1.3.0')
  OR @SchemaConstructorId IS NULL
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.DeploymentMode'
   AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Mode))
  OR NOT EXISTS(SELECT 1 FROM sys.assembly_references WHERE assembly_id=@SchemaConstructorId AND referenced_assembly_id=@JsonCoreId)
  THROW 55633,N'JSON Schema lifecycle: vorhandene Constructors zuerst explizit und kohärent auf1.3 migrieren.',1;
 DELETE FROM @SchemaConstructorMarkers;
 INSERT @SchemaConstructorMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.constructors'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.3.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@Mode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@TargetKnownHash)),(N'Toolbelt.ArtifactId',CONVERT(sql_variant,@TargetArtifactId));
 IF EXISTS(SELECT 1 FROM @SchemaConstructorMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@SchemaConstructorId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value) AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55633,N'JSON Schema lifecycle: Constructor-Dependencytuple inkohärent.',1;
END;
  SELECT @Current=CONVERT(varbinary(max),(SELECT @SchemaVersion Version,@SchemaMode Mode,@SchemaAssemblyId AssemblyId,@SchemaAssemblyOwner AssemblyOwner,
   @SchemaOwner TargetOwner,@JsonCoreId CoreId,@JsonCoreOwner CoreOwner,@SchemaResultId ResultDependencyId,@SchemaResultVersion ResultVersion,
   @SchemaConstructorId ConstructorId,@SchemaConstructorVersion ConstructorVersion,@SchemaInstalledHash InstalledHash,
   @SchemaInstalledArtifactId InstalledArtifactId,SCHEMA_ID(N'toolbelt_json') SchemaId,
   OBJECT_ID(N'toolbelt_json.USP_ValidateJsonSchema') PublicId,OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') BridgeId FOR XML RAW,BINARY BASE64));
  IF @Pass=1 AND @Current<>@Initial THROW 55637,N'JSON Schema lifecycle: Zustand hat sich unter Lock verändert.',1;
  IF NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr enabled' AND value_in_use=1)
   OR NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr strict security' AND value_in_use=1)
   OR COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE PROCEDURE'),0)<>1
   OR COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE FUNCTION'),0)<>1
   OR (SCHEMA_ID(N'toolbelt_json') IS NULL AND COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE SCHEMA'),0)<>1)
   OR (SCHEMA_ID(N'toolbelt_json') IS NOT NULL AND COALESCE(HAS_PERMS_BY_NAME(N'toolbelt_json',N'SCHEMA',N'ALTER'),0)<>1)
   OR (@SchemaAssemblyId IS NULL AND COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE ASSEMBLY'),0)<>1)
   OR (@SchemaAssemblyId IS NOT NULL AND @SchemaInstalledHash<>@SchemaKnownHash
    AND COALESCE(HAS_PERMS_BY_NAME(N'Toolbelt_JsonSchema',N'ASSEMBLY',N'ALTER'),0)<>1)
   THROW 55632,N'JSON Schema lifecycle: CLR-Konfiguration oder vorhandene Installationsrechte fehlen.',1;
  IF @Pass=0
  BEGIN
   SET @Initial=@Current;
   BEGIN TRANSACTION;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.json.shared-core',@LockMode=N'Shared',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock IS NULL OR @Lock<0 THROW 55637,N'JSON Schema lifecycle: gemeinsame Core-AppLock nicht verfügbar.',1;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.json.schema',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock IS NULL OR @Lock<0 THROW 55637,N'JSON Schema lifecycle: Modul-AppLock nicht verfügbar.',1;
  END;
  SET @Pass+=1;
 END;
 IF SCHEMA_ID(N'toolbelt_json') IS NULL
 BEGIN
  EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_json];';
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_json';
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'json',@level0type=N'SCHEMA',@level0name=N'toolbelt_json';
 END;
 IF @SchemaAssemblyId IS NULL
 BEGIN
  SET @OwnerName=USER_NAME(@SchemaOwner);
  IF @OwnerName IS NULL THROW 55632,N'JSON Schema lifecycle: vorhandener Owner nicht sichtbar.',1;
  SET @Sql=N'CREATE ASSEMBLY [Toolbelt_JsonSchema] AUTHORIZATION '+QUOTENAME(@OwnerName)+N' FROM '+CONVERT(nvarchar(max),@Bits,1)+N' WITH PERMISSION_SET=SAFE;';
  EXEC sys.sp_executesql @Sql;
 END;
 ELSE IF @SchemaInstalledHash<>@SchemaKnownHash
 BEGIN
  -- Nur die exakt bekannte Vorgängerversion; unveränderte CLR-Signatur/Core-
  -- Referenz. Eigene Slots, Rechte und ObjectIds bleiben im atomaren ALTER erhalten.
  SET @Sql=N'ALTER ASSEMBLY [Toolbelt_JsonSchema] FROM '+CONVERT(nvarchar(max),@Bits,1)+N' WITH PERMISSION_SET=SAFE;';
  EXEC sys.sp_executesql @Sql;
 END;
 CREATE TABLE #tbx_JsonSchema_DeployState(DeploymentMode nvarchar(16) NOT NULL);
 DECLARE @StateMode nvarchar(16)=CONVERT(nvarchar(16),@Mode);
 EXEC sys.sp_executesql N'INSERT #tbx_JsonSchema_DeployState(DeploymentMode) VALUES(@Mode);',N'@Mode nvarchar(16)',@Mode=@StateMode;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
GO
-- Technischer SAFE-TVF-Slot; öffentliche NOT-NULL-Hülle liegt in der USP.
IF OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') IS NULL
 EXEC sys.sp_executesql N'CREATE FUNCTION toolbelt_json.FT_ValidateJsonSchemaInternal
(@Json nvarchar(max),@Schema nvarchar(max),@Profile nvarchar(32),@MaxDocumentBytes bigint,
 @MaxSchemaBytes bigint,@MaxDepth int,@MaxEvaluationSteps bigint,@MaxErrors int)
RETURNS TABLE
(RowKind nvarchar(8) NULL,ErrorOrdinal int NULL,Status nvarchar(24) NULL,Profile nvarchar(32) NULL,
 IsValid bit NULL,DocumentPointer nvarchar(max) NULL,SchemaPointer nvarchar(max) NULL,
 Keyword nvarchar(128) NULL,ErrorCode nvarchar(32) NULL,ErrorsTruncated bit NULL)
AS EXTERNAL NAME [Toolbelt_JsonSchema].[Toolbelt.JsonSchema.JsonSchemaBridge].[Validate];';
GO
-- ============================================================================
-- Objekt: toolbelt_json.USP_ValidateJsonSchema; Typ: Stored Procedure
-- Zweck: Read-only Schemaurteil im begrenzten Profil toolbelt-2020-12-v1.
-- Vertrag: Documentation/Architecture/JSON_SCHEMA_CONTRACT.md; USP 1.0.
-- Parameter: zwei JSON-Inputs, explizites Profil, nur absenkbare Ressourcen.
-- Resultset: SUMMARY plus bis MaxErrors ERROR; zehn typisierte Spalten.
-- Dependencies: SAFE JsonCore/JsonSchema; ResultTable >=1.0.0, same_database.
-- Rechte: bestehende EXECUTE-/SELECT-Rechte; keine Rechteausweitung.
-- Versionen: SQL Server 2019/2022/2025, Compatibility >=150; Windows/Linux.
-- Fehler: 55600/1 Argument, 55601/1 Bridge; Engine-/Helperfehler unverändert.
-- Performance: iterativer, global budgetierter CLR-Pfad ohne SQL-Kontextzugriff.
-- Grenzen: kein volles Draftprofil; kein Download, Coercion oder Datenänderung.
-- ============================================================================
CREATE OR ALTER PROCEDURE toolbelt_json.USP_ValidateJsonSchema
 @Json nvarchar(max)=NULL,
 @Schema nvarchar(max)=NULL,
 @Profile varchar(32)='toolbelt-2020-12-v1',
 @MaxDocumentBytes bigint=16777216,
 @MaxSchemaBytes bigint=1048576,
 @MaxDepth int=128,
 @MaxEvaluationSteps bigint=1000000,
 @MaxErrors int=100,
 @ResultTable sysname=NULL,
 @KeepData bit=0,
 @Debug tinyint=0,
 @Hilfe bit=0
AS
BEGIN
 SET NOCOUNT ON;
 SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0),@Hilfe=COALESCE(@Hilfe,0);
 IF @Hilfe=1
 BEGIN
  DECLARE @Help TABLE(Section varchar(32) NOT NULL,Ordinal int NOT NULL,ItemName sysname NULL,SqlDataType varchar(256) NULL,IsRequired bit NULL,IsNullable bit NULL,DefaultValue nvarchar(4000) NULL,Description nvarchar(max) NOT NULL,ExampleSql nvarchar(max) NULL);
  INSERT @Help VALUES
  ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'Vollständiges Urteil im begrenzten Profil; Diagnosekürzung beendet die Evaluation nicht. LIMIT hat kein Boolurteil.',NULL),
  ('PARAMETER',1,N'@Json','nvarchar(max)',0,1,N'NULL',N'Instanz; SQL-NULL liefert SQL_NULL.',NULL),
  ('PARAMETER',2,N'@Schema','nvarchar(max)',0,1,N'NULL',N'Schema; vollständiger Preflight vor der Instanz, auch unbenutzte Definitionen.',NULL),
  ('PARAMETER',3,N'@Profile','varchar(32)',0,0,N'toolbelt-2020-12-v1',N'Exakte ASCII-Identität einschließlich Länge; kein Trim oder Casefold.',NULL),
  ('PARAMETER',4,N'@MaxDocumentBytes','bigint',0,0,N'16777216',N'UTF16-Bytes: 1..16777216; Überschreitung LIMIT/DOCUMENT_BYTES.',NULL),
  ('PARAMETER',5,N'@MaxSchemaBytes','bigint',0,0,N'1048576',N'UTF16-Bytes: 1..1048576; Überschreitung LIMIT/SCHEMA_BYTES.',NULL),
  ('PARAMETER',6,N'@MaxDepth','int',0,0,N'128',N'1..128 offene Container; begrenzter Parser stoppt beim Überschreiten.',NULL),
  ('PARAMETER',7,N'@MaxEvaluationSteps','bigint',0,0,N'1000000',N'1..1000000 abstrakte Arbeitseinheiten für alle Phasen; keine CPUzeitgarantie.',NULL),
  ('PARAMETER',8,N'@MaxErrors','int',0,0,N'100',N'0..100 Diagnosen; SUMMARY bleibt erhalten, Urteil erfordert vollständige Evaluation.',NULL),
  ('PARAMETER',9,N'@ResultTable','sysname',0,1,N'NULL',N'NULL: SELECT; sonst vorhandene caller-lokale #Temp gemäß ResultTable-Vertrag.',NULL),
  ('PARAMETER',10,N'@KeepData','bit',0,1,N'0',N'Replace=0, Append=1; NULL entspricht 0.',NULL),
  ('PARAMETER',11,N'@Debug','tinyint',0,1,N'0',N'Nur Messages ohne Payload/Endpoint; NULL entspricht 0.',NULL),
  ('PARAMETER',12,N'@Hilfe','bit',0,1,N'0',N'Help zuerst ohne Argument-/Dependency-/Tempprüfung oder Seiteneffekte.',NULL),
  ('RESULT_COLUMN',1,N'RowKind','varchar(8)',1,0,NULL,N'SUMMARY oder ERROR.',NULL),
  ('RESULT_COLUMN',2,N'ErrorOrdinal','int',1,0,NULL,N'SUMMARY=0, ERROR=1..N; explizite Ergebnisordnung.',NULL),
  ('RESULT_COLUMN',3,N'Status','varchar(24)',1,0,NULL,N'VALID/INVALID_INSTANCE/INVALID_SCHEMA/INVALID_JSON/UNSUPPORTED/SQL_NULL/LIMIT.',NULL),
  ('RESULT_COLUMN',4,N'Profile','varchar(32)',1,0,NULL,N'Exaktes angewandtes Profil.',NULL),
  ('RESULT_COLUMN',5,N'IsValid','bit',0,1,NULL,N'1 bei VALID, 0 bei vollständigem INVALID_INSTANCE; sonst NULL.',NULL),
  ('RESULT_COLUMN',6,N'DocumentPointer','nvarchar(max)',0,1,NULL,N'RFC6901-Ort in der Instanz; leer=root, NULL=unbekannt/nicht betroffen.',NULL),
  ('RESULT_COLUMN',7,N'SchemaPointer','nvarchar(max)',0,1,NULL,N'RFC6901-Ort im Schema; vollständige unveränderte decoded Keys.',NULL),
  ('RESULT_COLUMN',8,N'Keyword','nvarchar(128)',0,1,NULL,N'Zuständiges Keyword; NULL wenn nicht bekannt oder länger als 128 Einheiten.',NULL),
  ('RESULT_COLUMN',9,N'ErrorCode','varchar(32)',0,1,NULL,N'Kanonischer Fehlercode; VALID-SUMMARY ohne Code.',NULL),
  ('RESULT_COLUMN',10,N'ErrorsTruncated','bit',1,0,NULL,N'Unterdrückte Diagnosen; auf allen Zeilen gleicher Endzustand.',NULL),
  ('ERROR',1,N'55600/1',NULL,NULL,NULL,NULL,N'Ungültiges Profil oder Ressourcenargument.',NULL),
  ('ERROR',2,N'55601/1',NULL,NULL,NULL,NULL,N'Interner Transport-/Namespace-/Dependencyvertrag verletzt; kein Fachurteil.',NULL),
  ('LIMITATION',1,NULL,NULL,NULL,NULL,NULL,N'Kein volles Draft2020-12; lokale nichtrekursive Refs, exakte Zahlen/Unicode, kein externer Zugriff.',NULL),
  ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Synthetische Instanz mit einfachem Schema.',N'EXEC toolbelt_json.USP_ValidateJsonSchema @Json=N''42'',@Schema=N''{"type":"integer"}'';');
  SELECT CAST('1.0' AS varchar(16)) HelpContractVersion,CAST(N'toolbelt_json' AS sysname) SchemaName,
   CAST(N'USP_ValidateJsonSchema' AS sysname) ObjectName,Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql
  FROM @Help ORDER BY CASE Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2 WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 WHEN 'LIMITATION' THEN 5 ELSE 6 END,Ordinal;
  RETURN;
 END;
 IF @Profile IS NULL OR CONVERT(varbinary(max),@Profile)<>CONVERT(varbinary(max),'toolbelt-2020-12-v1')
 OR @MaxDocumentBytes IS NULL OR @MaxDocumentBytes NOT BETWEEN 1 AND 16777216
 OR @MaxSchemaBytes IS NULL OR @MaxSchemaBytes NOT BETWEEN 1 AND 1048576
 OR @MaxDepth IS NULL OR @MaxDepth NOT BETWEEN 1 AND 128
 OR @MaxEvaluationSteps IS NULL OR @MaxEvaluationSteps NOT BETWEEN 1 AND 1000000
 OR @MaxErrors IS NULL OR @MaxErrors NOT BETWEEN 0 AND 100
 THROW 55600,N'JSON Schema: ungültiges Profil oder Ressourcenargument.',1;
 -- Guard vor der separaten Batchcompilation verhindert Temp-Eclipsing.
 IF OBJECT_ID(N'tempdb..#tbx_JsonSchema_Result',N'U') IS NOT NULL
 OR LEFT(LOWER(@ResultTable COLLATE Latin1_General_100_BIN2),5) COLLATE Latin1_General_100_BIN2=N'#tbx_'
 THROW 55601,N'JSON Schema: reservierter interner Temp-Namespace ist belegt.',1;
 DECLARE @Dependency int=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P'),@Version nvarchar(64),@Major int,@Minor int,@Patch int;
 SELECT @Version=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
 SELECT @Major=TRY_CONVERT(int,PARSENAME(@Version,3)),@Minor=TRY_CONVERT(int,PARSENAME(@Version,2)),@Patch=TRY_CONVERT(int,PARSENAME(@Version,1));
 IF @Dependency IS NULL OR @Major IS NULL OR @Major<1 OR @Minor IS NULL OR @Minor<0 OR @Patch IS NULL OR @Patch<0
 OR CONVERT(varbinary(max),@Version)<>CONVERT(varbinary(max),CONCAT(@Major,N'.',@Minor,N'.',@Patch))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@Dependency AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(128),value))=CONVERT(varbinary(max),N'toolbelt.core.result-table'))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@Dependency AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@Version))
 THROW 55601,N'JSON Schema: registrierte ResultTable-Dependency >=1.0.0 fehlt oder ist ungeeignet.',1;
 DECLARE @Sql nvarchar(max)=N'
 SET NOCOUNT ON;
 DECLARE @Bridge TABLE(RowKind varchar(8) COLLATE Latin1_General_100_BIN2,ErrorOrdinal int,
 Status varchar(24) COLLATE Latin1_General_100_BIN2,Profile varchar(32) COLLATE Latin1_General_100_BIN2,
 IsValid bit,DocumentPointer nvarchar(max) COLLATE Latin1_General_100_BIN2,SchemaPointer nvarchar(max) COLLATE Latin1_General_100_BIN2,
 Keyword nvarchar(128) COLLATE Latin1_General_100_BIN2,ErrorCode varchar(32) COLLATE Latin1_General_100_BIN2,ErrorsTruncated bit);
 INSERT @Bridge(RowKind,ErrorOrdinal,Status,Profile,IsValid,DocumentPointer,SchemaPointer,Keyword,ErrorCode,ErrorsTruncated)
 SELECT RowKind,ErrorOrdinal,Status,Profile,IsValid,DocumentPointer,SchemaPointer,Keyword,ErrorCode,ErrorsTruncated
 FROM toolbelt_json.FT_ValidateJsonSchemaInternal(@Json,@Schema,@Profile,@MaxDocumentBytes,@MaxSchemaBytes,@MaxDepth,@MaxEvaluationSteps,@MaxErrors);
 DECLARE @Count int=(SELECT COUNT(*) FROM @Bridge),@Status varchar(24),@Truncated bit;
 SELECT @Status=Status,@Truncated=ErrorsTruncated FROM @Bridge WHERE RowKind=''SUMMARY'' AND ErrorOrdinal=0;
 IF @Count NOT BETWEEN 1 AND @MaxErrors+1
 OR (SELECT COUNT(*) FROM @Bridge WHERE RowKind=''SUMMARY'' AND ErrorOrdinal=0)<>1
 OR EXISTS(SELECT 1 FROM @Bridge WHERE RowKind IS NULL OR ErrorOrdinal IS NULL OR Status IS NULL OR Profile IS NULL OR ErrorsTruncated IS NULL
  OR CONVERT(varbinary(max),Profile)<>CONVERT(varbinary(max),@Profile)
  OR Status NOT IN (''VALID'',''INVALID_INSTANCE'',''INVALID_SCHEMA'',''INVALID_JSON'',''UNSUPPORTED'',''SQL_NULL'',''LIMIT'')
  OR DATALENGTH(Status)<>CASE Status WHEN ''VALID'' THEN 5 WHEN ''INVALID_INSTANCE'' THEN 16 WHEN ''INVALID_SCHEMA'' THEN 14 WHEN ''INVALID_JSON'' THEN 12 WHEN ''UNSUPPORTED'' THEN 11 WHEN ''SQL_NULL'' THEN 8 WHEN ''LIMIT'' THEN 5 END
  OR CONVERT(varbinary(max),Status)<>CONVERT(varbinary(max),@Status) OR ErrorsTruncated<>@Truncated
  OR (Status=''VALID'' AND (IsValid IS NULL OR IsValid<>1))
  OR (Status=''INVALID_INSTANCE'' AND (IsValid IS NULL OR IsValid<>0))
  OR (Status NOT IN (''VALID'',''INVALID_INSTANCE'') AND IsValid IS NOT NULL)
  OR (ErrorOrdinal=0 AND RowKind<>''SUMMARY'') OR (ErrorOrdinal>0 AND RowKind<>''ERROR'')
  OR DATALENGTH(RowKind)<>CASE WHEN ErrorOrdinal=0 THEN 7 ELSE 5 END
  OR ErrorOrdinal NOT BETWEEN 0 AND @Count-1)
 OR EXISTS(SELECT ErrorOrdinal FROM @Bridge GROUP BY ErrorOrdinal HAVING COUNT(*)<>1)
 THROW 55601,N''JSON Schema: interner Bridgevertrag verletzt.'',1;
 CREATE TABLE #tbx_JsonSchema_Result(RowKind varchar(8) COLLATE Latin1_General_100_BIN2 NOT NULL,ErrorOrdinal int NOT NULL,
 Status varchar(24) COLLATE Latin1_General_100_BIN2 NOT NULL,Profile varchar(32) COLLATE Latin1_General_100_BIN2 NOT NULL,
 IsValid bit NULL,DocumentPointer nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,SchemaPointer nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
 Keyword nvarchar(128) COLLATE Latin1_General_100_BIN2 NULL,ErrorCode varchar(32) COLLATE Latin1_General_100_BIN2 NULL,ErrorsTruncated bit NOT NULL);
 INSERT #tbx_JsonSchema_Result(RowKind,ErrorOrdinal,Status,Profile,IsValid,DocumentPointer,SchemaPointer,Keyword,ErrorCode,ErrorsTruncated)
 SELECT RowKind,ErrorOrdinal,Status,Profile,IsValid,DocumentPointer,SchemaPointer,Keyword,ErrorCode,ErrorsTruncated FROM @Bridge;
 IF @Debug>0 RAISERROR(N''JSON Schema: vollständige Antwort materialisiert; Routing folgt.'',10,1) WITH NOWAIT;
 IF @ResultTable IS NULL
 BEGIN
  SELECT RowKind,ErrorOrdinal,Status,Profile,IsValid,DocumentPointer,SchemaPointer,Keyword,ErrorCode,ErrorsTruncated
  FROM #tbx_JsonSchema_Result ORDER BY ErrorOrdinal;
  RETURN;
 END;
 DECLARE @Own bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,@Saved bit=0,
 @Savepoint varchar(32)=REPLACE(CONVERT(varchar(36),NEWID()),''-'',''''),@Insert nvarchar(max);
 BEGIN TRY
  IF @Own=1 BEGIN TRANSACTION;
  ELSE BEGIN SAVE TRANSACTION @Savepoint; SET @Saved=1; END;
  EXEC toolbelt_core.USP_PrepareResultTable @ResultTableToAlter=@ResultTable,@LikeTable=N''#tbx_JsonSchema_Result'',@KeepData=@KeepData,@Debug=@Debug;
  SET @Insert=N''INSERT ''+QUOTENAME(@ResultTable)+N''(RowKind,ErrorOrdinal,Status,Profile,IsValid,DocumentPointer,SchemaPointer,Keyword,ErrorCode,ErrorsTruncated)
  SELECT RowKind,ErrorOrdinal,Status,Profile,IsValid,DocumentPointer,SchemaPointer,Keyword,ErrorCode,ErrorsTruncated FROM #tbx_JsonSchema_Result;'';
  EXEC sys.sp_executesql @Insert;
  IF @Own=1 COMMIT;
 END TRY
 BEGIN CATCH
  IF @Own=1 AND XACT_STATE()<>0 ROLLBACK;
  ELSE IF @Saved=1 AND XACT_STATE()=1 ROLLBACK TRANSACTION @Savepoint;
  THROW;
 END CATCH;';
 EXEC sys.sp_executesql @Sql,N'@Json nvarchar(max),@Schema nvarchar(max),@Profile varchar(32),@MaxDocumentBytes bigint,@MaxSchemaBytes bigint,@MaxDepth int,@MaxEvaluationSteps bigint,@MaxErrors int,@ResultTable sysname,@KeepData bit,@Debug tinyint',
 @Json,@Schema,@Profile,@MaxDocumentBytes,@MaxSchemaBytes,@MaxDepth,@MaxEvaluationSteps,@MaxErrors,@ResultTable,@KeepData,@Debug;
END;
GO
BEGIN TRY
 IF XACT_STATE()<>1 OR @@TRANCOUNT<>1 OR OBJECT_ID(N'tempdb..#tbx_JsonSchema_DeployState',N'U') IS NULL
  THROW 55638,N'JSON Schema lifecycle: eigene Deploymenttransaktion unvollständig.',1;
 DECLARE @Mode nvarchar(16)=(SELECT DeploymentMode FROM #tbx_JsonSchema_DeployState),@Name sysname,@Kind char(2),@Level varchar(16),@ObjectId int,@Property sysname,@Value sql_variant;
-- Qualifizierte Offline-Schemazeile; keine Trustfreigabe.
DECLARE @SchemaKnownHash varbinary(64)=0x523b65979267457e8326ed2d5ec96d0309e9e1c7d5a0b2fbc0a3de68dcf7a9bb5a4f9cdda704ee0ba9f19097edbfb66eb8d649c0f2941b4a16adc2880bef880f,
 @SchemaArtifactId varchar(64)='22d1e92a612370b3e470c5ed893f6af61e55fd4465fcc3d362d4068e3cc6a02d';
-- Unveränderliche bekannte 1.0.0-Identität für Upgrade und release-aware Uninstall.
DECLARE @SchemaPreviousHash varbinary(64)=0xf67e0f9f3f6e83acc304e8e60bc98ee2610018e654ac4eb6e430f98a9665f9a1c85e90ef97950d348fcc0fc6389de71b214d1f9101835fec9a305ef39c41af21,
 @SchemaPreviousArtifactId varchar(64)='4ae51961dc53bd6aff96bb566e908cbb715d40512f36cffc756e7f2813a3a143';
-- Lokaler geschlossener Manifestzustand, genau zwei eigene SQL-Slots.
DECLARE @SchemaVersion nvarchar(max),@SchemaMode nvarchar(max),@SchemaAssemblyId int,@SchemaAssemblyOwner int,
 @SchemaInstalledHash varbinary(64),@SchemaInstalledArtifactId varchar(64),@SchemaOwner int,@SchemaInstalling bit=0,
 @SchemaResultVersion nvarchar(max),@SchemaResultId int,@SchemaMajor int,@SchemaMinor int,@SchemaPatch int,
 @SchemaConstructorId int,@SchemaConstructorVersion nvarchar(max);
DECLARE @SchemaSlots TABLE(Id int PRIMARY KEY,Name sysname NOT NULL,Kind char(2) NOT NULL);
INSERT @SchemaSlots VALUES(1,N'USP_ValidateJsonSchema','P'),(2,N'FT_ValidateJsonSchemaInternal','FT');
DECLARE @SchemaAssemblyMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);
DECLARE @SchemaConstructorMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);
DECLARE @SchemaParameters TABLE(Id int,Name sysname,TypeId int,Length smallint);
INSERT @SchemaParameters VALUES(1,N'@Json',231,-1),(2,N'@Schema',231,-1),(3,N'@Profile',231,64),
 (4,N'@MaxDocumentBytes',127,8),(5,N'@MaxSchemaBytes',127,8),(6,N'@MaxDepth',56,4),(7,N'@MaxEvaluationSteps',127,8),(8,N'@MaxErrors',56,4);
DECLARE @SchemaColumns TABLE(Id int,Name sysname,TypeId int,Length smallint);
INSERT @SchemaColumns VALUES(1,N'RowKind',231,16),(2,N'ErrorOrdinal',56,4),(3,N'Status',231,48),(4,N'Profile',231,64),
 (5,N'IsValid',104,1),(6,N'DocumentPointer',231,-1),(7,N'SchemaPointer',231,-1),(8,N'Keyword',231,256),
 (9,N'ErrorCode',231,64),(10,N'ErrorsTruncated',104,1);
DECLARE @SchemaPublicParameters TABLE(Id int,Name sysname,TypeId int,Length smallint,AliasName sysname NULL);
INSERT @SchemaPublicParameters SELECT Id,Name,CASE WHEN Id=3 THEN 167 ELSE TypeId END,CASE WHEN Id=3 THEN 32 ELSE Length END,NULL FROM @SchemaParameters;
INSERT @SchemaPublicParameters VALUES(9,N'@ResultTable',231,256,N'sysname'),(10,N'@KeepData',104,1,NULL),(11,N'@Debug',48,1,NULL),(12,N'@Hilfe',104,1,NULL);
-- Qualifizierte Offline-Corezeile; keine Trustfreigabe und keine Runtimeableitung.
DECLARE @JsonCoreKnownHash varbinary(64)=0x4680e9d34a0870924b5ca003cc5983882fc8ffb653e702bcc549e5f65dde11934c55ba7b356b519503ac5ce1e2478fe64876fea0295176ff13b5b4a6ab61b894,
 @JsonCoreArtifactId varchar(64)='975d4a84bb86e80b6e5844d6e86785ae0e98b13ee44c0f66c021507a23e0f888',
 @JsonCoreId int,@JsonCoreOwner int,@JsonCoreHash varbinary(64),
 @JsonCoreVersion nvarchar(max),@JsonCoreStoredMode nvarchar(max),
 @JsonCoreExpectedMode nvarchar(max),@JsonCoreRequired bit=1,@JsonCoreRemoving bit=0;
DECLARE @JsonCoreMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);
-- Target1.3 separat; die historische1.2-Knownzeile bleibt unverändert.
DECLARE @TargetKnownHash varbinary(64)=0x8ab08a17d1be0b861043463e223154dffbed8273bc2c197cd7c8b791c3c06c4af418358e8e743d72068a3a9f726f7f85f50bcfa431df0484202ab562e1edb4bf,
 @TargetArtifactId varchar(64)='a6d81103af18a73a14e58339abb8c7835e0d16d559951cfc3a03d305b63e4a23';
 DECLARE @ObjectProperties TABLE(Name sysname PRIMARY KEY,Value sql_variant);
 DECLARE @SlotId int=1;
 WHILE @SlotId<=2
 BEGIN
  SELECT @Name=Name,@Kind=Kind FROM @SchemaSlots WHERE Id=@SlotId;
  SET @ObjectId=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(@Name),@Kind);
  IF @ObjectId IS NULL THROW 55638,N'JSON Schema lifecycle: Release-Slots unvollständig.',1;
  SET @Level=CASE @Kind WHEN 'P' THEN 'PROCEDURE' ELSE 'FUNCTION' END;
  INSERT @ObjectProperties VALUES(N'Toolbelt.ModuleId',N'toolbelt.json.schema'),(N'Toolbelt.ModuleVersion',N'1.0.1'),
   (N'Toolbelt.ContractVersion',N'1.0'),(N'Toolbelt.DeploymentMode',@Mode),
   (N'Toolbelt.SourceHash',CASE WHEN @Kind='P' THEN CONVERT(nvarchar(64),HASHBYTES(N'SHA2_256',CONVERT(varbinary(max),OBJECT_DEFINITION(@ObjectId))),2) ELSE CONVERT(nvarchar(64),@SchemaArtifactId) END);
  WHILE EXISTS(SELECT 1 FROM @ObjectProperties)
  BEGIN
   SELECT TOP(1) @Property=Name,@Value=Value FROM @ObjectProperties ORDER BY Name;
   IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@ObjectId AND minor_id=0 AND name=@Property)
    EXEC sys.sp_updateextendedproperty @name=@Property,@value=@Value,@level0type=N'SCHEMA',@level0name=N'toolbelt_json',@level1type=@Level,@level1name=@Name;
   ELSE EXEC sys.sp_addextendedproperty @name=@Property,@value=@Value,@level0type=N'SCHEMA',@level0name=N'toolbelt_json',@level1type=@Level,@level1name=@Name;
   DELETE FROM @ObjectProperties WHERE Name=@Property;
  END;
  SET @SlotId+=1;
 END;
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.Version')
  EXEC sys.sp_updateextendedproperty @name=N'Toolbelt.Module.toolbelt.json.schema.Version',@value=N'1.0.1';
 ELSE EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Module.toolbelt.json.schema.Version',@value=N'1.0.1';
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.DeploymentMode')
  EXEC sys.sp_updateextendedproperty @name=N'Toolbelt.Module.toolbelt.json.schema.DeploymentMode',@value=@Mode;
 ELSE EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Module.toolbelt.json.schema.DeploymentMode',@value=@Mode;
 INSERT @SchemaAssemblyMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.schema'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.0.1'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,@Mode)),(N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@SchemaKnownHash)),
 (N'Toolbelt.ArtifactId',CONVERT(sql_variant,@SchemaArtifactId));
 WHILE EXISTS(SELECT 1 FROM @SchemaAssemblyMarkers)
 BEGIN
  SELECT TOP(1) @Property=Name,@Value=Value FROM @SchemaAssemblyMarkers ORDER BY Name;
  IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=(SELECT assembly_id FROM sys.assemblies WHERE name=N'Toolbelt_JsonSchema') AND minor_id=0 AND name=@Property)
   EXEC sys.sp_updateextendedproperty @name=@Property,@value=@Value,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_JsonSchema';
  ELSE EXEC sys.sp_addextendedproperty @name=@Property,@value=@Value,@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_JsonSchema';
  DELETE FROM @SchemaAssemblyMarkers WHERE Name=@Property;
 END;
 SET @SchemaInstalling=1;
-- Pure Include: Own2-Slots, bekannte Assembly, Dependencies; keine Mutation.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
 THROW 55632,N'JSON Schema lifecycle: vollständige Metadatensicht fehlt.',1;
SELECT @SchemaVersion=NULL,@SchemaMode=NULL,@SchemaAssemblyId=NULL,@SchemaAssemblyOwner=NULL,@SchemaInstalledHash=NULL,@SchemaInstalledArtifactId=NULL;
SELECT @SchemaVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.Version';
SELECT @SchemaMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.DeploymentMode';
SELECT @SchemaAssemblyId=a.assembly_id,@SchemaAssemblyOwner=a.principal_id,@SchemaInstalledHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1 WHERE a.name=N'Toolbelt_JsonSchema';
IF @SchemaVersion IS NULL
BEGIN
 IF @SchemaAssemblyId IS NOT NULL OR @SchemaMode IS NOT NULL
  OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.Version')
  OR EXISTS(SELECT 1 FROM @SchemaSlots WHERE OBJECT_ID(N'toolbelt_json.'+QUOTENAME(Name)) IS NOT NULL)
  THROW 55634,N'JSON Schema lifecycle: unregistrierter oder fremder Zielslot.',1;
END
ELSE
BEGIN
 SET @SchemaInstalledArtifactId=CASE
  WHEN CONVERT(varbinary(max),@SchemaVersion)=CONVERT(varbinary(max),N'1.0.0') AND @SchemaInstalledHash=@SchemaPreviousHash THEN @SchemaPreviousArtifactId
  WHEN CONVERT(varbinary(max),@SchemaVersion)=CONVERT(varbinary(max),N'1.0.1') AND @SchemaInstalledHash=@SchemaKnownHash THEN @SchemaArtifactId END;
 IF @SchemaInstalledArtifactId IS NULL
  OR @SchemaMode IS NULL OR CONVERT(varbinary(max),@SchemaMode)<>CONVERT(varbinary(max),@Mode)
  OR @SchemaAssemblyId IS NULL OR @SchemaInstalledHash IS NULL
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@SchemaAssemblyId AND is_user_defined=1 AND permission_set=1 AND is_visible=1
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonSchema'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@SchemaAssemblyId)<>1
  THROW 55633,N'JSON Schema lifecycle: unbekannter oder inkohärenter Releasezustand.',1;
 DELETE FROM @SchemaAssemblyMarkers;
 INSERT @SchemaAssemblyMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.schema'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),@SchemaVersion))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@Mode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@SchemaInstalledHash)),(N'Toolbelt.ArtifactId',CONVERT(sql_variant,@SchemaInstalledArtifactId));
 IF EXISTS(SELECT 1 FROM @SchemaAssemblyMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@SchemaAssemblyId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value) AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55633,N'JSON Schema lifecycle: typisiertes Assemblymarkertuple inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @SchemaSlots slot WHERE NOT EXISTS(SELECT 1 FROM sys.objects o
  WHERE o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(slot.Name)) AND CONVERT(varbinary(2),o.type)=CONVERT(varbinary(2),slot.Kind)
   AND CONVERT(varbinary(max),o.name)=CONVERT(varbinary(max),slot.Name)
   AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleId'
    AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.json.schema'))
   AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleVersion'
    AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@SchemaVersion))
   AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.DeploymentMode'
    AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Mode))))
  THROW 55633,N'JSON Schema lifecycle: objektgenaue Ownership inkohärent.',1;
 IF NOT EXISTS(SELECT 1 FROM sys.assembly_modules WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') AND assembly_id=@SchemaAssemblyId
  AND CONVERT(varbinary(max),assembly_class)=CONVERT(varbinary(max),N'Toolbelt.JsonSchema.JsonSchemaBridge')
  AND CONVERT(varbinary(max),assembly_method)=CONVERT(varbinary(max),N'Validate'))
  OR EXISTS(SELECT 1 FROM @SchemaParameters expected WHERE NOT EXISTS(SELECT 1 FROM sys.parameters p
   WHERE p.object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') AND p.parameter_id=expected.Id
    AND CONVERT(varbinary(max),p.name)=CONVERT(varbinary(max),expected.Name) AND p.system_type_id=expected.TypeId
    AND p.user_type_id=p.system_type_id AND p.max_length=expected.Length AND p.is_output=0))
  OR (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal'))<>8
  OR EXISTS(SELECT 1 FROM @SchemaColumns expected WHERE NOT EXISTS(SELECT 1 FROM sys.columns c
   WHERE c.object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') AND c.column_id=expected.Id
    AND CONVERT(varbinary(max),c.name)=CONVERT(varbinary(max),expected.Name) AND c.system_type_id=expected.TypeId
    AND c.user_type_id=c.system_type_id AND c.max_length=expected.Length AND c.is_nullable=1))
  OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal'))<>10
  THROW 55633,N'JSON Schema lifecycle: CLR-Binding-/Parameters-/Spaltenvertrag inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @SchemaPublicParameters expected WHERE NOT EXISTS(SELECT 1 FROM sys.parameters p
  WHERE p.object_id=OBJECT_ID(N'toolbelt_json.USP_ValidateJsonSchema') AND p.parameter_id=expected.Id
   AND CONVERT(varbinary(max),p.name)=CONVERT(varbinary(max),expected.Name) AND p.system_type_id=expected.TypeId
   AND p.max_length=expected.Length AND p.is_output=0
   AND ((expected.AliasName IS NULL AND p.user_type_id=p.system_type_id)
    OR (expected.AliasName IS NOT NULL AND CONVERT(varbinary(max),TYPE_NAME(p.user_type_id))=CONVERT(varbinary(max),expected.AliasName)))))
  OR (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID(N'toolbelt_json.USP_ValidateJsonSchema'))<>12
  THROW 55633,N'JSON Schema lifecycle: öffentliche Parametersignatur inkohärent.',1;
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@SchemaAssemblyId AND object_id<>OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal'))
  OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@SchemaAssemblyId)
  OR EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d JOIN @SchemaSlots target ON d.referenced_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(target.Name))
   WHERE NOT EXISTS(SELECT 1 FROM @SchemaSlots own WHERE d.referencing_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(own.Name))))
  THROW 55636,N'JSON Schema lifecycle: fremder Verbraucher blockiert Lifecycle.',1;
END;
IF @SchemaInstalling=1 OR @SchemaAssemblyId IS NOT NULL
BEGIN
 SELECT @JsonCoreExpectedMode=@Mode,@JsonCoreRequired=1;
-- Pure SQLCMD-Include: keine Helper-USP, Mutation, Trust- oder Ownerreparatur.
-- KnownArtifact.sql deklariert den Scope. Aufruf vor/unter der gemeinsamen Lock.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 THROW 55622,N'JSON Core: vollständige Assemblymetadatensicht fehlt.',1;
SELECT @JsonCoreId=NULL,@JsonCoreOwner=NULL,@JsonCoreHash=NULL,@JsonCoreVersion=NULL,@JsonCoreStoredMode=NULL;
SELECT @JsonCoreVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.Version';
SELECT @JsonCoreStoredMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode';
SELECT @JsonCoreId=a.assembly_id,@JsonCoreOwner=a.principal_id,@JsonCoreHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonCore';
IF @JsonCoreId IS NULL
BEGIN
 IF @JsonCoreRequired=1 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0
  AND name IN(N'Toolbelt.Module.toolbelt.json.core.Version',N'Toolbelt.Module.toolbelt.json.core.DeploymentMode'))
  THROW 55623,N'JSON Core: erforderliche bekannte Dependency fehlt oder ist inkohärent.',1;
END
ELSE
BEGIN
 IF @JsonCoreVersion IS NULL OR CONVERT(varbinary(max),@JsonCoreVersion)<>CONVERT(varbinary(max),N'1.0.0')
  OR @JsonCoreStoredMode IS NULL OR CONVERT(varbinary(max),@JsonCoreStoredMode)<>CONVERT(varbinary(max),@JsonCoreExpectedMode)
  OR @JsonCoreHash IS NULL OR @JsonCoreHash<>@JsonCoreKnownHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@JsonCoreId AND is_user_defined=1 AND permission_set=1 AND is_visible=0
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonCore'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@JsonCoreId)<>1
  THROW 55623,N'JSON Core: keine kohärente bekannte technische SAFE-Assembly.',1;
 DELETE FROM @JsonCoreMarkers;
 INSERT @JsonCoreMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.core'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.0.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@JsonCoreExpectedMode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@JsonCoreKnownHash)),
 (N'Toolbelt.ArtifactId',CONVERT(sql_variant,@JsonCoreArtifactId));
 IF EXISTS(SELECT 1 FROM @JsonCoreMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@JsonCoreId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value)
   AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55623,N'JSON Core: typisiertes bekanntes Markertuple ist inkohärent.',1;
 -- Die technische Dependency stellt keine eigenen oder fremden SQL-Slots bereit.
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: direkter SQL-Verbraucher blockiert den technischen Corevertrag.',1;
 IF @JsonCoreRemoving=1 AND EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: verbleibende Assemblyverbraucher blockieren den Abbau.',1;
END;
 -- Schema installiert/repariert weder ResultTable noch Constructors.
 IF @SchemaInstalling=1
 BEGIN
 SELECT @SchemaResultVersion=NULL;
 SELECT @SchemaResultVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
 SELECT @SchemaResultId=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P'),@SchemaMajor=TRY_CONVERT(int,PARSENAME(@SchemaResultVersion,3)),
  @SchemaMinor=TRY_CONVERT(int,PARSENAME(@SchemaResultVersion,2)),@SchemaPatch=TRY_CONVERT(int,PARSENAME(@SchemaResultVersion,1));
 IF @SchemaResultId IS NULL OR @SchemaMajor IS NULL OR @SchemaMajor<1 OR @SchemaMinor IS NULL OR @SchemaMinor<0 OR @SchemaPatch IS NULL OR @SchemaPatch<0
  OR CONVERT(varbinary(max),@SchemaResultVersion)<>CONVERT(varbinary(max),CONCAT(@SchemaMajor,N'.',@SchemaMinor,N'.',@SchemaPatch))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@SchemaResultId AND minor_id=0 AND name=N'Toolbelt.ModuleId'
   AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.core.result-table'))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@SchemaResultId AND minor_id=0 AND name=N'Toolbelt.ModuleVersion'
   AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@SchemaResultVersion))
  THROW 55632,N'JSON Schema lifecycle: registrierte ResultTable-Dependency >=1.0.0 fehlt.',1;
 END;
 SELECT @SchemaOwner=COALESCE((SELECT principal_id FROM sys.schemas WHERE name=N'toolbelt_json'),USER_ID());
 IF @SchemaOwner IS NULL OR @SchemaOwner<>@JsonCoreOwner OR (@SchemaAssemblyId IS NOT NULL AND @SchemaAssemblyOwner<>@SchemaOwner)
  OR EXISTS(SELECT 1 FROM @SchemaSlots slot JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(slot.Name))
   WHERE COALESCE(o.principal_id,@SchemaOwner)<>@SchemaOwner)
  THROW 55633,N'JSON Schema lifecycle: kohärente vorhandene Owner fehlen; keine Ownerreparatur.',1;
 IF @SchemaAssemblyId IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.assembly_references WHERE assembly_id=@SchemaAssemblyId AND referenced_assembly_id=@JsonCoreId)
  THROW 55633,N'JSON Schema lifecycle: bekannte Assembly referenziert Core nicht.',1;
END;
-- Eine vorliegende Legacy1.2-Assembly würde einen zweiten aktuellen Scanner
-- aktiv lassen. Diese Read-only-Dependencyprüfung verändert Constructors nicht.
IF @SchemaInstalling=1 AND (EXISTS(SELECT 1 FROM sys.assemblies WHERE name=N'Toolbelt_JsonConstructors')
 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.Version'))
BEGIN
 SELECT @SchemaConstructorId=NULL,@SchemaConstructorVersion=NULL;
 SELECT @SchemaConstructorVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.Version';
 SELECT @SchemaConstructorId=a.assembly_id FROM sys.assemblies a JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
  WHERE a.name=N'Toolbelt_JsonConstructors' AND a.permission_set=1 AND a.is_user_defined=1 AND a.principal_id=@JsonCoreOwner
   AND HASHBYTES(N'SHA2_512',f.content)=@TargetKnownHash;
 IF @SchemaConstructorVersion IS NULL OR CONVERT(varbinary(max),@SchemaConstructorVersion)<>CONVERT(varbinary(max),N'1.3.0')
  OR @SchemaConstructorId IS NULL
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.DeploymentMode'
   AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Mode))
  OR NOT EXISTS(SELECT 1 FROM sys.assembly_references WHERE assembly_id=@SchemaConstructorId AND referenced_assembly_id=@JsonCoreId)
  THROW 55633,N'JSON Schema lifecycle: vorhandene Constructors zuerst explizit und kohärent auf1.3 migrieren.',1;
 DELETE FROM @SchemaConstructorMarkers;
 INSERT @SchemaConstructorMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.constructors'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.3.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@Mode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@TargetKnownHash)),(N'Toolbelt.ArtifactId',CONVERT(sql_variant,@TargetArtifactId));
 IF EXISTS(SELECT 1 FROM @SchemaConstructorMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@SchemaConstructorId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value) AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55633,N'JSON Schema lifecycle: Constructor-Dependencytuple inkohärent.',1;
END;
 DROP TABLE #tbx_JsonSchema_DeployState;
 COMMIT;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.json.schema
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.file.xlsx-memory
:On Error exit
-- Nichtdoomender Caller-Gate vor SET, eigener Transaktionsscope erforderlich.
IF @@TRANCOUNT<>0
BEGIN
 RAISERROR(N'TBX_XLSX_LIFECYCLE_CALLER_TRANSACTION: Deploy benötigt einen eigenen Transaktionsscope.',16,1);
 RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @Mode nvarchar(max)=N'central',@Bits varbinary(max)=0x4d5a90000300000004000000ffff0000b800000000000000400000000000000000000000000000000000000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a2400000000000000504500004c010300194ff99c0000000000000000e00022200b01300000880000000800000000000082a700000020000000c000000000001000200000000200000400000000000000060000000000000000000100000200000000000003006085000010000010000000001000001000000000000010000000000000000000000030a700004f00000000c00000240400000000000000000000000000000000000000e000000c00000014a700001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000080000000000000000000000082000004800000000000000000000002e7465787400000088870000002000000088000000020000000000000000000000000000200000602e727372630000002404000000c0000000060000008a0000000000000000000000000000400000402e72656c6f6300000c00000000e000000002000000900000000000000000000000000000400000420000000000000000000000000000000064a70000000000004800000002000500d85d00003c49000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001e027b0e0000042a2202037d0e0000042a0000001b300a00ab0100000100001102280d00000a7d0500000402280e00000a730f00000a7d0600000402280e00000a731000000a7d0700000402731100000a7d0800000402281200000a0204252d062673480000067d09000004027b090000046f47000006032d0a7201000070281500000602038e6a2813000006020316731300000a038e6a027b090000047b11000004027b090000047b14000004027b090000047b12000004027b090000047b13000004027b090000047b1c00000402fe0614000006731400000a731500000a7d04000004027b040000046f1600000a0b160c2b2a07089a0d09281a0000060972290000701a6f1700000a2c0e020909281d000006280b000006260817580c08078e6932d0027235000070724d000070280b000006140a6f1800000a13042b321204281900000a13051205281a00000a724f0000701a6f1700000a2c15062c0a726f00007028150000061205281b00000a0a1204281c00000a2dc5de0e1204fe160400001b6f1d00000adc062d0a72a7000070281500000602067d0c00000402280c000006020672db000070280d000006020206281c00000606280b0000067d0d00000402280a0000062a000110000002001e013f5d010e000000001e027b0f0000042a1e0228140000062a1b3003007500000002000011022814000006027b080000046f1e00000a0a2b201200281f00000a0b02077b1e000004281200000602077b1f00000428120000061200282000000a2dd7de0e1200fe160600001b6f1d00000adc02027b080000046f2100000a6a1f106a5a2813000006022814000006027b080000046f2200000a2a00000001100000020012002d3f000e000000001b300400af020000030000110317320e03027b080000046f2100000a310a72f100007028150000060228090000060a732300000a0b732400000a0c02027b080000040317596f2500000a7b20000004280e0000060d16130416130516130616130702027b080000040317596f2500000a7b20000004720d010070280d00000638ca010000096f2600000a1f0f3327096f2700000a7221010070282800000a2c15096f2900000a7229010070282800000a2c03161307096f2600000a1f0f3330096f2700000a729d010070282800000a2c1e096f2900000a7229010070282800000a2c0c096f2a00000a173303161305096f2600000a17405301000011042d1309720d01007072290100702816000006171304096f2900000a7229010070282b00000a3a27010000096f2700000a729d010070282800000a2c29096f2a00000a17fe0116fe011106602c0a72b10100702815000006171306096f2c00000a16fe011305096f2700000a7221010070282800000a2c3e096f2a00000a18330411052d0a72e7010070281500000609720f0200706f2d00000a2000001000721302007028180000061307096f2c00000a2c03161307096f2700000a722f020070282b00000a3a87000000096f2a00000a19330411072d0a72330200702815000006076f2e00000a027b090000047b16000004320a725d020070281500000602091107062808000006130811087b220000046a1f206211087b230000046e6013090811096f2f00000a2c0a72730200702815000006081109176f3000000a0711086f3100000a0220800000006a28130000060209280f0000063a2afeffff11042c0411062d0a72910200702815000006de0a092c06096f1d00000adc077e2f000004252d17267e2e000004fe064d000006733200000a25802f0000046f3300000a02076f2e00000a6a1f106a5a2813000006022814000006076f3400000a2a00411c0000020000004900000019020000620200000a0000000000000013300400170400000400001103720f0200706f2d00000a12011200281900000604072e0a72b102007028150000060372d50200706f2d00000a252d062672d90200700c0872d9020070282b00000a2c580872dd020070282b00000a2c4b0872e1020070282b00000a2c3e0872f5020070282b00000a2c310872fd020070282b00000a2c24087201030070282b00000a2c17087205030070282b00000a2c0a72090300702815000006734a00000625047d2200000425067d2300000425087d240000040d036f2a00000a1304036f2c00000a3af401000038cc010000036f2600000a1740c0010000036f2900000a7229010070282b00000a2c0a72350300702815000006036f2700000a7267030070282800000a2c37036f2a00000a11041758332b097b2a0000042c0a726b030070281500000609177d2a00000409020328100000067d25000004385b010000036f2700000a728b030070282800000a39f0000000036f2a00000a1104175840e1000000097b2b0000042c0a728f030070281500000609177d2b000004090372d50200706f2d00000a252d062672b30300707d28000004097b2800000472b3030070282b00000a2c40097b2800000472c1030070282b00000a2c2e097b2800000472cf030070282b00000a2c1c097b2800000472db030070282b00000a2c0a72ef03007028150000060372210400706f2d00000a130511052c1c09110520ffffff7f72270400702817000006733500000a7d2d000004097b2800000472c1030070282800000a2c0e11052d0a7227040070281500000609020328100000067d270000042b56036f2700000a7251040070282800000a2c3a036f2a00000a11041758332e097b260000042d0d0872e1020070282b00000a2c0a7257040070281500000609020328110000067d260000042b0a723503007028150000060203280f0000062c1a036f2600000a1f0f401efeffff036f2a00000a11044011feffff0872dd020070282800000a2c4d097b2a0000042d0a72830400702815000006097b2500000420ffffff7f7283040070281700000613061106056f3600000a320a72830400702815000006090511066f3700000a7d260000042b210872f5020070282800000a2c14097b2a0000042c0c09097b250000047d260000040872e1020070282800000a2c12097b2a0000042c0a725704007028150000060872fd020070282800000a2c48097b2a0000042c40097b25000004724d000070282b00000a2c2e097b2500000472b3040070282b00000a2c1c097b2500000472b7040070282b00000a2c0a72bb0400702815000006097b2b0000042c1809097b2a0000047d2c00000409097b250000047d2900000402097b24000004281200000602097b25000004281200000602097b26000004281200000602097b27000004281200000602097b28000004281200000602097b290000042812000006092a001b3004007301000005000011140a027b0d0000046f1800000a0c2b311202281900000a0d1203281a00000a72e70400701a6f1700000a2c15062c0a720505007028150000061203281b00000a0a1202281c00000a2dc6de0e1202fe160400001b6f1d00000adc733800000a0b062d02072a02067237050070280d0000060206280e000006130416130538c600000011046f2600000a1740b900000011052d14110472530500707229010070281600000617130511046f2700000a7221040070282800000a398b00000011046f2900000a7229010070282800000a2c7811046f2a00000a172e0a725b0500702815000006076f3600000a027b090000047b17000004320a729705007028150000060211042811000006130602027b0b00000411066f3900000a6a186a5a587d0b000004027b0b000004027b090000047b19000004310a72cb05007028150000060711066f3a00000a021104280f0000063a2dffffff11052d0a72fd0500702815000006de0c11042c0711046f1d00000adc072a00011c000002000e003e4c000e0000000002007a00eb65010c000000001b3005002c03000006000011280e00000a733b00000a0a02027b0c000004280e0000060b160c160d1613041613053894020000076f2600000a1f0f332f076f2700000a7227060070282800000a2c1d076f2900000a7229010070282800000a2c0b076f2a00000a173302160d076f2600000a17404f020000082d1207723506007072290100702816000006170c076f2900000a7229010070282b00000a3a25020000076f2700000a7227060070282800000a2c28076f2a00000a17fe0116fe011104602c0a72470600702815000006171304076f2c00000a16fe010d076f2700000a7275060070282800000a3994000000076f2a00000a17fe0116fe011105602c0a728b06007028150000061713050772c30600706f2d00000a130a110a2c42110a72b3040070282b00000a2c34110a72b7040070282b00000a2c26110a72d5060070282b00000a2c18110a72e1060070282b00000a2c0a72eb060070281500000602110a72b7040070282800000a2d0e110a72e1060070282800000a2b01172802000006076f2700000a720d070070282b00000a3a2d010000076f2a00000a183303092d0a72190700702815000006027b080000046f2100000a027b090000047b15000004320a7245070070281500000607725d0700706f2d00000a1306077267070070726d0700706f3c00000a13070772f60700706f2d00000a252d0626720208007013081106283d00000a2d0a0611066f3e00000a2c0a7212080070281500000611087202080070282b00000a2c2611087238080070282b00000a2c1811087246080070282b00000a2c0a725c080070281500000611072c1b027b0d0000041107728e080070283f00000a12096f4000000a2d0c72a408007028150000062b3b027b08000004734900000625027b080000046f2100000a17587d1d0000042511067d1e0000042511087d1f0000042511097d200000046f4100000a061106176f4200000a0207280f0000063a60fdffff082c1111042c0d027b080000046f2100000a2d0a72d20800702815000006de0a072c06076f1d00000adc027b080000046f1e00000a130b2b12120b281f00000a0228010000067d21000004120b282000000a2de5de0e120bfe160600001b6f1d00000adc2a413400000200000018000000cf020000e70200000a0000000000000002000000fe0200001f0000001d0300000e000000000000001b300400d801000007000011280e00000a731000000a0a280e00000a733b00000a0b0203280e0000060c160d388c010000086f2600000a174080010000092d120872f0080070720c0900702816000006170d086f2700000a7286090070282b00000a3a56010000086f2900000a720c090070282b00000a3a41010000086f2a00000a1740350100000872a00900706f2d00000a13040872b60900706f2d00000a13050872bc0900706f2d00000a13060872c60900706f2d00000a130711042c18110472d4090070282b00000a2c0a72e609007028150000061105283d00000a2d120711056f3e00000a2d0811062c0411072d0a72220a00702815000006071105176f4200000a110672440a00701a6f4300000a2d0a72cf0a007028150000061106726d070070283900000a17586f4400000a1308110872030b0070282800000a2d38110872190b0070282800000a2d2a110872330b0070282800000a2d1c1108724b0b0070282800000a2d0e1108725b0b0070282800000a2c0a72cf0a00702815000006041107281b0000061309027b0400000411096f4500000a2d0a726f0b00702815000006061105729f0b00701108284600000a11096f4700000a0208280f0000063a68feffff092d0a72a30b00702815000006de0a082c06086f1d00000adc062a411c0000020000001e000000ae010000cc0100000a000000000000001b3003007301000008000011160a0272c10b0070280e0000060b383a010000076f2600000a17402e010000062d120772e90b007072f50b00702816000006170a076f2900000a72f50b0070282b00000a3a04010000076f2a00000a1740f800000007726f0c00706f2d00000a0c082d0a72870c00702815000006076f2700000a72b10c0070282800000a2c5c0772c30c00706f2d00000a0d092c0e0972d50c00701a6f4300000a2d0a72870c0070281500000609176f4400000a0d09281a000006027b07000004096f4800000a2c0a72d90c00702815000006027b0700000409086f4700000a2b1c076f2700000a72070d0070282b00000a2c0a72170d007028150000060872490d00701b6f4900000a162f3c0872550d00701b6f4900000a162f2d08725d0d00701b6f4900000a162f1e0872190b00701b6f4900000a162f0f0872330b00701b6f4900000a16320a72170d007028150000060207280f0000063abafeffffde0a072c06076f1d00000adc062d0a726d0d007028150000062a00411c0000020000000e0000004d0100005b0100000a00000000000000133004003300000009000011027b070000040312006f4000000a2c180672a10d007004721b0e0070284600000a282b00000a2c0a72250e007028150000062a0013300300c00000000a000011022814000006027b060000040312006f4a00000a2d5a027b04000004036f4b00000a0a02027b0a000004068e6a587d0a000004027b0a000004027b090000047b13000004310a72510e0070281500000602068e6a1a6a5a20004001006a582813000006027b0600000403066f4c00000a734d00000a25166f4e00000a25146f4f00000a25027b090000047b120000046f5000000a25176a6f5100000a25176f5200000a25176f5300000a25176f5400000a0b0616731300000a07285500000a2ace022814000006036f5600000a022814000006252c1d036f2a00000a027b090000047b18000004310a726f0e007028150000062a133003009b0000000b000011036f2a00000a0a036f2c00000a2c06724d0000702a735700000a0b2b5b036f2600000a17330a728f0e00702815000006036f2600000a192e1d036f2600000a1a2e14036f2600000a1f0e2e0a036f2600000a1f0d332202036f5800000a6f3900000a6a1a6a5a281300000607036f5800000a6f5900000a260203280f0000062c13036f2600000a1f0f3392036f2a00000a063389076f5a00000a2a0013300300d20000000c000011036f2a00000a0a036f2c00000a2c06724d0000702a735700000a0b150c3887000000036f2600000a1f0f330b036f2a00000a083302150c036f2600000a173369036f2900000a7229010070282b00000a2d57036f2700000a72b90e0070282800000a2c0f036f2c00000a2d07036f2a00000a0c036f2700000a72d5020070282800000a2c2408162f20020328100000060d02096f3900000a6a1a6a5a281300000607096f5900000a260203280f0000062c19036f2600000a1f0f4063ffffff036f2a00000a064057ffffff076f5a00000a2a52032c1002036f3900000a6a1a6ad828130000062ace03166a321503027b090000047b1a000004027b0f00000459310a72c10e0070281500000602027b0f00000403587d0f0000042a92027b050000046f5b00000a027b090000047b1b0000046a320a72f30e007028150000062a4672130f007002283f00000a735c00000a7abe026f2a00000a2d1c026f2700000a03282b00000a2d0e026f2900000a04282b00000a2c0a72270f007028150000062a000013300200590000000d00001102283d00000a2c08042815000006162a166a0a020b160c2b3407086f5d00000a0d091f303205091f393106042815000006061f0a6a5a096e581f306a590a06036a31060428150000060817580c08076f3900000a32c306692a4a0203042817000006252d060428150000062a13300600950000000e00001104165403165402283d00000a2c0a72510f00702815000006160a2b2b04044a1f1a5a02062517580a6f5d00000a581f4159175854044a2000400000310a72510f0070281500000606026f3900000a2f1602066f5d00000a1f41320b02066f5d00000a1f5a31b6062c0906026f3900000a330a72510f007028150000060302066f4400000a200000100072510f00702818000006542a00000013300500aa0000000f00001102283d00000a2d4202166f5d00000a1f2f2e37021f5c6f5e00000a162f2c021f3a6f5e00000a162f21021f256f5e00000a162f16021f3f6f5e00000a162f0b021f236f5e00000a16320a726f0f0070281500000602178d3800000125161f2f9d6f5f00000a0a160b2b3906079a0c08724d000070282800000a2d1a08729b0f0070282800000a2d0d08729f0f0070282800000a2c0a726f0f007028150000060717580b07068e6932c12a0000133006002d0100001000001103283d00000a2d37031f3a6f5e00000a162f2c031f5c6f5e00000a162f21031f256f5e00000a162f16031f3f6f5e00000a162f0b031f236f5e00000a16320a72a50f00702815000006733800000a0a0372d50c00701a6f4300000a2d30021f2f6f6000000a163225060216021f2f6f6000000a6f6100000a178d3800000125161f2f9d6f5f00000a6f6200000a03178d3800000125161f2f9d6f6300000a178d3800000125161f2f9d6f5f00000a0b160c2b6207089a0d09729f0f0070282800000a2c22066f3600000a2d0a72dd0f0070281500000606066f3600000a17596f6400000a2b2b09729b0f0070282b00000a2c1e09724d000070282800000a2c0a72a50f0070281500000606096f3a00000a0817580c08078e69329872d50c007006286500000a25281a0000062a00000013300500370000000e000011021f2f6f6000000a0a0616320c02160617586f6100000a2b05724d000070720b100070020617586f4400000a7229000070286600000a2a0013300500970000000e000011027235000070282800000a2c06724d0000702a0272191000701a6f6700000a0a06162f2d02720b1000701a6f4300000a2c1f0272290000701a6f1700000a2c11021c026f3900000a1f0b596f6100000a2a0616320e0272290000701a6f1700000a2d1072291000702815000006724d0000702a02160617586f6100000a02061d58026f3900000a06591f0c596f6100000a283f00000a2a001330030009010000000000000f00286800000a2d5a0f01286800000a2d510f02286800000a2d480f03286900000a2d3f0f04286900000a2d360f05286900000a2d2d0f06286900000a2d240f07286800000a2d1b0f08286900000a2d120f09286a00000a2d090f0a286900000a2c0b724f100070735c00000a7a7348000006250f00286b00000a7d11000004250f01286b00000a7d12000004250f02286b00000a7d13000004250f03286c00000a7d14000004250f04286c00000a7d15000004250f05286c00000a7d16000004250f06286c00000a7d17000004250f07286b00000a7d19000004250f08286c00000a7d18000004250f09286d00000a7d1c000004250f0a286c00000a7d1b000004256f470000062a0000001b300b003b01000011000011736e00000a0a050e040e050e060e070e080e090e0a0e0b0e0c0e0d281e0000060b042c1e0f01286900000a2d0a0f01286c00000a172f0b727b100070735c00000a7a026f6f00000a2c07060ddde8000000026f7000000a077b11000004310b72a9100070735c00000a7a026f7100000a0773030000060c042c44080f01286c00000a6f0700000613041613052b26110411059a1306086f0500000606734e0000062511067d330000046f7200000a110517581305110511048e6932d22b3b086f0600000613071613052b26110711059a1308086f0500000606734e0000062511087d320000046f7200000a110517581305110511078e6932d2086f05000006060dde362672d710007028210000060dde2826720111007028210000060dde1a6f7300000a28200000060dde0d6f7300000a28200000060dde00092a000134000000000600fd03010e2100000100000600fd11010e2200000100000600fd1f010d2300000100000600fd2c010d240000019a0272130f00701a6f4300000a2c0a026f3900000a1f603107723511007010000228210000062a9a178d0b0000022516734e000006252040c90000733500000a7d3000000425027d31000004a22a000013300e002000000000000000027e7400000a160304050e040e050e060e070e080e090e0a0e0b281f0000062a13300e001d0000000000000002031704050e040e050e060e070e080e090e0a0e0b0e0c281f0000062a42022c0702737500000a2a7e7600000a2a000013300200b10000001200001102740b0000020a03067c30000004287700000a2d077e7400000a2b10067c30000004287800000a737900000a811d00000104067b3100000428240000068128000001067b320000040b05072c0d077b1d000004737900000a2b057e7400000a811d0000010e04072c08077b1e0000042b0114282400000681280000010e05072c08077b1f0000042b0114282400000681280000010e06072c0d077b21000004737a00000a2b057e7b00000a81290000012a00000013300200930100001300001102740b0000020a03067c30000004287700000a2d077e7400000a2b10067c30000004287800000a737900000a811d00000104067b3100000428240000068128000001067b330000040b05072c0d077b22000004737900000a2b057e7400000a811d0000010e04072c0d077b23000004737900000a2b057e7400000a811d0000010e05072c08077b240000042b0114282400000681280000010e06072c0d077b2a000004737a00000a2b057e7b00000a81290000010e07072c08077b250000042b0114282400000681280000010e08072c08077b260000042b0114282400000681280000010e09072c0d077b2b000004737a00000a2b057e7b00000a81290000010e0a072c08077b270000042b0114282400000681280000010e0b072c08077b280000042b0114282400000681280000010e0c072c1f077c2d000004287700000a2c12077c2d000004287800000a737900000a2b057e7400000a811d0000010e0d072c0d077b2c000004737a00000a2b057e7b00000a81290000010e0e072c08077b290000042b0114282400000681280000012a32022c07026f3900000a2a162a52734f00000625027d3b00000425167d3a0000042a00000013300400af0000000000000002037d3b000004032c4e027e7c00000a7d3c000004027c3d000004fe150e00001b027c3e000004fe150f00001b027c3f000004fe150f00001b027c40000004fe151000001b027c41000004fe151100001b02147d3800000420000100006a1a6a027b340000042827000006027b35000004282700000658027b36000004282700000658027b37000004282700000658027b380000042827000006586a5a5820000004006a3002022a1928280000062a0013300200530000000e000011022d02172a160a2b3f02066f5d00000a287d00000a2c1d061758250a026f3900000a2e0e02066f5d00000a287e00000a2d12162a02066f5d00000a287e00000a2c02162a0617580a06026f3900000a32b8172a00133002005c0000000000000002726b110070282800000a2d4d027279110070282800000a2d40027289110070282800000a2d33027293110070282800000a2d2602729d110070282800000a2d190272af110070282800000a2d0c0272b9110070282800000a2a172a13300200390100001400001102393101000002283900000a0a061759450a0000000d0000008b000000fa000000460000009a000000fa000000fa0000002a000000c7000000a9000000061f133bb000000038ed0000000216285d00000a0b071f303bb9000000071f403bcf00000038d00000000216285d00000a0b071f232e24071f302e31071f682e3b38b40000000272cb110070282800000a3a80000000389f0000000272d5110070282800000a2d6e388d0000000272e7110070282800000a2d5c2b7e0272f9110070282800000a2d5f2b6f02720b120070282800000a2d3e2b60027211120070282800000a2d2f2b5102721d120070282800000a2d262b42027233120070282800000a2d1d2b3302725b120070282800000a2d1a2b24726b1100702a72931100702a729d1100702a72af1100702a72b91100702a72891100702a142a42021f303209021f39fe0216fe012a162a000013300200fc00000015000011160a160b026f3900000a2d02162a02066f5d00000a1f2b2e0b02066f5d00000a1f2d330e0617580a2b080617580a0717580b06026f3900000a2f0e02066f5d00000a282d0000062de106026f3900000a2f3002066f5d00000a1f2e33250617580a2b080617580a0717580b06026f3900000a2f0e02066f5d00000a282d0000062de1072d02162a06026f3900000a2f6202066f5d00000a1f652e0b02066f5d00000a1f45334c0617580a06026f3900000a2f1a02066f5d00000a1f2b2e0b02066f5d00000a1f2d33040617580a060c2b040617580a06026f3900000a2f0e02066f5d00000a282d0000062de506083302162a06026f3900000afe012a13300200b00000000e000011022c38032d26026f3900000a1f132e19026f3900000a1f15320c026f3900000a1f1bfe022b13172b10162b0d026f3900000a1f0afe0116fe012c02162a160a2b64061a2e04061d330d02066f5d00000a1f2d2e4d162a061f0a330d02066f5d00000a1f542e3b162a061f0d2e05061f10330d02066f5d00000a1f3a2e24162a061f13330d02066f5d00000a1f2e2e12162a02066f5d00000a282d0000062d02162a0617580a06026f3900000a3293172a1330050091040000160000110228270000061f2030330e0428270000061f2030280e0528270000062080000000301a0428270000062000000100300d052827000006200000010031071928280000062a734f00000625027d3400000425037d3900000425047d3500000425057d360000040a02282a0000062c2204282a0000062c1a05282a0000062c120e04282a0000062c090e05282a0000062d08061a28290000062a022c090f01287f00000a2d08061728290000062a0272e1020070282800000a2c1f0f01288000000a2d03042c08061828290000062a052d22061728290000062a0f01288000000a2d1106042d03052c03182b011728290000062a0272dd020070282800000a2c13042c260416288100000a1201288200000a2c160272f5020070282800000a2c110405282b00000a2c08061828290000062a0272d9020070282b00000a2c560272fd020070282b00000a2c490272dd020070282b00000a2c3c0272f5020070282b00000a2c2f0272e1020070282b00000a2c22027205030070282b00000a2c15027201030070282b00000a2c08061c28290000062a0e042c110e04282b0000062d08061828290000062a0e052c090e05282c0000062b01140c0e052c0b082d08061c28290000062a0e042c15082c120e0408282b00000a2c08061828290000062a060e04252d472608252d42260272d9020070282800000a2d2f0272fd020070282800000a2d1b027205030070282800000a2d0772891100702b13729d1100702b0c72791100702b05726b1100707d37000004027201030070282800000a2c09061f0a28290000062a067b370000047289110070282800000a2c44060272dd020070282800000a2d1d0272f5020070282800000a2d100272e1020070282800000a2d03042b01057d3800000406067b380000042c03162b011828290000062a067b370000047279110070282800000a2c550272fd020070282b00000a2c08061828290000062a0472b3040070282b00000a2c150472b7040070282b00000a2c08061a28290000062a060472b7040070282800000a738300000a7d3d000004061628290000062a027205030070282800000a39ca000000067b370000047293110070282b00000a2c1a067b37000004729d110070282b00000a2c08061828290000062a04067b370000047293110070282800000a282f0000062c4804067b370000047293110070282800000a2d18188d320000012516726f120070a22517729b120070a22b0e178d32000001251672d7120070a2288100000a161205288400000a2d08061a28290000062a067b370000047293110070282800000a2c0f061105738500000a7d3e0000042b0d061105738500000a7d3f000004061628290000062a0272d9020070282b00000a2d03042d08061828290000062a046f3900000a208000000031071928280000062a067b370000047293110070282800000a2d12067b37000004729d110070282800000a2c110f06287f00000a2d08061828290000062a0412032831000006130411042c0906110428290000062a067b37000004726b110070282800000a2c1406097b450000047d3c000004061628290000062a0609060f06288600000a283400000628290000062a000000133007002e0200001700001103145102282e0000062d021a2a02166f5d00000a1f2dfe010a02166f5d00000a1f2d2e0b02166f5d00000a1f2b330902176f4400000a100002188d3800000125161f659d25171f459d6f8700000a0b160c0716322e020717586f4400000a1a288100000a1202288200000a2c0a081fc03205081f4031021b2a0216076f6100000a1000021f2e6f5e00000a0d0916320c026f3900000a095917592b01160859130402729b0f0070724d0000706f8800000a178d3800000125161f309d6f6300000a130511056f3900000a2d390373500000062572b30400707d420000042516738900000a7d4500000451162a11051611056f3900000a17596f6100000a1305110417591304110416310f110572b30400701a6f1700000a2dd31104162f2611056f3900000a1104591f2631021b2a11051f30110465738a00000a283f00000a130516130411056f3900000a1f26300611041f2631021b2a1a8d400000011306110513081613092b50110811096f5d00000a1f30596e130a16130b2b241106110b956e1f0a6a5a110a58130c1106110b110c6d9e110c1f2064130a110b1758130b110b11068e6932d4110a2c06738b00000a7a110917581309110911086f3900000a32a51a8d3c000001130716130d2b101107110d1106110d959e110d1758130d110d1a32eb0373500000062511057d420000042511047d4300000425067d44000004251711056f3900000a1104288c00000a288c00000ad21104d20616fe011107738d00000a7d4500000451162a0000133005008600000018000011166a0a026f3900000a1f0e588d380000010b078e690c026f3900000a17590d2b3602096f5d00000a1f30596a2100c0692ac90000005a0658130407081759250c1f306a11041f0a6a5d58d19d11041f0a6a5b0a0917590d09162fc62b1707081759250c1f306a061f0a6a5d58d19d061f0a6a5b0a06166a30e40708078e690859738e00000a2a0000133004007b000000090000110228320000060a066f3900000a0330181f30031758066f3900000a59738a00000a06283f00000a0a032c110616066f3900000a03596f6100000a2b010616288100000a04288f00000a2d02162a0316312806066f3900000a03596f5d00000a1f353216044c21ffffffffffffff7f3302162a04044c176a5855172a00133005002a02000019000011027b440000042c14037b3700000472b9110070282b00000a2c021e2a027b420000040a066f3900000a027b43000004301d1f30027b430000041758066f3900000a59738a00000a06283f00000a0a027b430000042c160616066f3900000a027b43000004596f6100000a2b0106027b430000042c1506066f3900000a027b43000004596f4400000a2b0572b30400700b16288100000a1202288f00000a2d021e2a037b3700000472b9110070282800000a2c31027b42000004027b43000004120328330000062d021e2a03027b440000042d03092b020965739000000a7d41000004162a037b3700000472af110070282800000a2c39082d21027b42000004027b43000004120328330000062c0c092100c0692ac900000032021e2a0309739100000a739200000a7d40000004162a042d08081f3c6a33021d2a042d0508176a32090820dab937006a31021e2a037b370000047293110070282800000a2c1b07178d3800000125161f309d6f9300000a6f3900000a2c031f092a07027b43000004120328330000062d021e2a042d0b08081f3c6afe026a592b01081304042d10206b0700001f0c1f1f739400000a2b0c20700700001717739400000a13061206289500000a11042100c0692ac90000005a58095813051105166a321211057e9600000a13061206289500000a31021e2a037b370000047293110070282800000a2c14031105739700000a738500000a7d3e0000042b12031105739700000a738500000a7d3f000004162a000013300a00c10000001a0000110228360000061f206a30370e0428360000061f206a302b0e05283600000620800000006a301c04283600000620000001006a300e05283600000620000001006a3110178d0c0000022516192828000006a22a178d0c00000225160228370000060f01289800000a2d0e0f01289900000a738300000a2b091200fe150e00001b060428370000060528370000060e0428370000060e0528370000060f06289800000a2d0e0f06289900000a738300000a2b091200fe150e00001b062830000006a22a56022c0f026f9a00000a2d07026f9b00000a2a166a2a66022c14026f9a00000a2d0c026f9c00000a739d00000a2a142a42022c0702737500000a2a7e7600000a2a000013300200490100001b00001102740c0000020a03067b340000042838000006812800000104067c39000004287f00000a2d077e7b00000a2b10067c39000004288000000a737a00000a812900000105067b35000004283800000681280000010e04067b36000004283800000681280000010e05067b3a000004737a00000a81290000010e06067b37000004283800000681280000010e07067c3c000004286a00000a2d0d067b3c0000048c1e0000012b0114510e08067c3d000004287f00000a2d077e7b00000a2b10067c3d000004288000000a737a00000a81290000010e09067b3e000004810f00001b0e0a067b3f000004810f00001b0e0b067b40000004811000001b0e0c067c41000004289e00000a2d077e9f00000a2b10067c4100000428a000000a73a100000a811c0000010e0d067b38000004283800000681280000010e0e067b3b000004737900000a811d0000012a36735100000625027d470000042a32022c07026f3900000a2a162a13300200530000000e000011022d02172a160a2b3f02066f5d00000a287d00000a2c1d061758250a026f3900000a2f0e02066f5d00000a287e00000a2d12162a02066f5d00000a287e00000a2c02162a0617580a06026f3900000a32b8172a0013300700fa0300001c00001102283b0000061f20303e0e04283b0000061f2030330e05283b0000062080000000302504283b0000062000000100301805283b0000062000000100300b0e07283b0000061f20310719283a0000062a02283c0000062c2b04283c0000062c2305283c0000062c1b0e04283c0000062c120e05283c0000062c090e07283c0000062d071a283a0000062a020304050e040e050e0628300000060a067b3b0000042c0c067b3b000004283a0000062a0e0772ed120070282b00000a2c230e0772f9120070282b00000a2c150e077205130070282b00000a2c0718283a0000062a0e052d0718283a0000062a0e0539cf0200000e05283900000a130511051759450a0000000e000000a20000009502000050000000b500000095020000950200002f00000095020000c800000011051f133bd200000038870200000e0516285d00000a130611061f303bd000000011061f403bf100000038660200000e0516285d00000a130611061f232e2711061f302e3411061f682e4138450200000e0572cb110070282800000a3a90000000382f0200000e0572d5110070282800000a2d7d381c0200000e0572e7110070282800000a2d6a38090200000e0572f9110070282800000a3a3901000038f30100000e05720b120070282800000a2d4138e00100000e057211120070282800000a2d2e38cd0100000e05721d120070282800000a2d6138ba0100000e057233120070282800000a3a8400000038a4010000067c3c000004286a00000a2c081f0b283a0000062a067b3c0000040e050e0728420000060b3881010000067b380000042d081f0b283a0000062a067b380000040b3865010000067c3e00000428a200000a2d081f0b283a0000062a067c3e00000428a300000a1307120772d7120070288100000a28a400000a0b382c010000067c3f00000428a200000a2d081f0b283a0000062a067c3f00000428a300000a13071207289500000a7e9600000a13071207289500000a1202283e0000062d071e283a0000062a08739700000a130712077211130070288100000a28a400000a0b38c6000000067c4000000428a500000a2d081f0b283a0000062a067c4000000428a600000a1308120828a700000a21ffbf692ac90000001203283e0000062d071e283a0000062a120409289100000a1b8d320000012516120428a800000a130512057239130070288100000a28a900000aa22517723f130070a22518120428aa00000a130512057239130070288100000a28a900000aa22519723f130070a2251a120428ab00000a130512057239130070288100000a28a900000aa228ac00000a0b2b071c283a0000062a20000100006a1a6a076f3900000a6a5a5820000004006a310719283a0000062a735100000625077d4600000425167d470000042a0000133003003b0000001d0000110220809698006a5b0a0220809698006a5d20404b4c006a320506176a580a060320809698006a5b310604166a55162a040620809698006a5a55172a0013300400960000001e0000110f0028ad00000a0a1a8d400000010b1613042b0e071104061104949e11041758130411041a32ed1f278d380000010c088e690d166a13051913062b2611051f2062071106956e60130707110611071f0a6a5c6d9e11071f0a6a5e13051106175913061106162fd508091759250d1f306a110558d19d0716952db90717952db40718952daf0719952daa0809088e690959738e00000a2a000013300300480000001f000011026fae00000a0a068e6917590b2b240607931f392e1406078f3800000125491758d15306739d00000a2a06071f309d0717590b07162fd872b704007006739d00000a283f00000a2a13300300530000002000001103163010021f300365738a00000a283f00000a2a03026f3900000a310672b30400702a026f3900000a03590a062c0a0216066f6100000a2b0572b30400700b02066f5d00000a1f352f02072a0728400000062a0013300600b00200002100001102283f0000060a0472ed120070282800000a2d0772431300702b05729b0f00700b0472ed120070282800000a2d07729b0f00702b0572431300700c0372e7110070282800000a39da0000000672b3040070282800000a2d12066f3900000a0f0028af00000a5917592b0116130806066f3900000a19592841000006130911096f3900000a19310d724713007013091108175813080f0028b000000a2d0d0672b3040070282b00000a2d07724d0000702b05724f130070130a1d8d320000012516110aa225171109166f5d00000a130b120b28b100000aa2251807a225191109176f4400000aa2251a7253130070a2251b110816320772571300702b05724f130070a2251c110828b200000a130c120c7239130070288100000a28a900000aa228ac00000a2a03720b120070282800000a2d0d037211120070282800000a2b01170d0372b3040070282800000a2d1003720b120070282800000a2d03182b01161304060f0028af00000a092d03162b011859110459284100000613051105178d3800000125161f309d6f9300000a6f3900000a16fe01130611056f3900000a1104301c1f301104175811056f3900000a59738a00000a1105283f00000a130511042c1411051611056f3900000a1104596f6100000a2b02110513071107178d3800000125161f309d6f6300000a130711076f3900000a2d0772b304007013070372d5110070282800000a2c53735700000a130d16130e2b33110e16311711076f3900000a110e59195d2d09110d086f5900000a26110d1107110e6f5d00000a6fb300000a26110e1758130e110e11076f3900000a32c2110d6f5a00000a13070f0028b000000a2d0411062c07724d0000702b05724f130070110711042c1907110511056f3900000a1104596f4400000a283f00000a2b05724d000070092d07724d0000702b05725b130070286600000a2a56022c0f026f9a00000a2d07026f9b00000a2a166a2a66022c14026f9a00000a2d0c026f9c00000a739d00000a2a142a13300b00da0000001a0000110228430000061f206a30430e0428430000061f206a30370e05284300000620800000006a302804284300000620000001006a301a05284300000620000001006a300c0e0728430000061f206a3116178d0e0000022516735100000625197d47000004a22a178d0e00000225160228440000060f01289800000a2d0e0f01289900000a738300000a2b091200fe150e00001b060428440000060528440000060e0428440000060e0528440000060f06289800000a2d0e0f06289900000a738300000a2b091200fe150e00001b060e072844000006283d000006a22a0000133002006b0000002200001102750e0000020a062c23067b4700000416321a067b470000041f0b3010067b470000042c13067b460000042c0b725f13007073b400000a7a03067b460000042c12067b460000046fae00000a73b500000a2b0528b600000a5104067b47000004737900000a811d0000012a00133002005401000000000000027b11000004176a3f3c010000027b1100000420000000016a3d2b010000027b12000004176a3f1e010000027b1200000420000000016a3d0d010000027b13000004176a3f00010000027b1300000420000000046a3def000000027b14000004173fe3000000027b1400000420000100003dd3000000027b15000004173fc7000000027b150000041f203dba000000027b16000004173fae000000027b1600000420a08601003d9e000000027b17000004173f92000000027b170000042050c300003d82000000027b18000004173279027b180000041f40306f027b19000004176a3265027b1900000420000080006a3057027b1a000004176a324d027b1a00000420000000086a303f027b1b000004173236027b1b00000420881300003029027b1c0000047eb700000a28b800000a2d17027b1c00000420c800000073b900000a28ba00000a2c0a729113007028150000062a133002008f000000000000000220000000016a7d110000040220000000016a7d120000040220000000046a7d130000040220000100007d14000004021f207d150000040220a08601007d16000004022050c300007d17000004021f407d180000040220000080006a7d190000040220000000086a7d1a0000040220881300007d1b0000040220c800000073b900000a7d1c00000402281200000a2a1e02281200000a2a1e02281200000a2a2e734c000006802e0000042a1e02281200000a2aca037b22000004047b220000042e12037c22000004047b2200000428bb00000a2a037c23000004047b2300000428bb00000a2a1e02281200000a2a6602177d3a000004027e7c00000a7d3c00000402281200000a2a1e02281200000a2a1e02281200000a2a42534a4201000100000000000c00000076342e302e33303331390000000005006c00000088130000237e0000f4130000e40e000023537472696e677300000000d8220000ac130000235553008436000010000000234755494400000094360000a812000023426c6f620000000000000002000001571da2090902000000fa01330016000001000000440000000e0000004700000051000000c6000000bb00000004000000120000002200000001000000020000000300000011000000010000000500000008000000000006060100000000000600fa032d09060059042d0906005303b7080f004d09000006007b033d070600dd033d07060040043d0706001a043d07060067030e090600ab033d070600920310050600080c73060a003308710e3700e40600000e005905b70806007e000f01060058000f01060038032d0943009b08000006006f000f0147009b0800001200120845061200720a450606004408860d0600ba05730606001e0073060600370073061600ae00a40916006600a4091600b705a40906002602f90a16002a0aa40912008907450606007007860d0e005b07db0006004f07db001600c803710816009d01710816009701710816002a05a40916009a06a40906005102730616004d0ba4090600c8067306060052087306060044000f0106005806db0006003607730606005e06db000600360573060600c207730606003202730612008402450612004b0545061200650845060600ff077306060029000f010600b80773060600dd07210706006900730606008909210706002308730606007a09210706005f0073060600b007730606006a0573060600b100730606009607730600000000c100000000000100010001011000ae05f30631000100010081011000b20bf306310010001e00810110009002f30631001000270080011000ff0df306310011003a0081011000e401f306310011004300020110008b0b0000310011004700020110000f0c000031001d0049000201100027060000310022004a00032110000b01000031002e004b0003011000d50d0000310030004e0005011000600c0000310034004f0003011000c20b000031004200500005011000600c00003100460051005680150cb9055180ef0ab9055180d70ab9052100c704bc052100a405c0052100cf0bc4052100ce09cd052100760bd5052100920bdd050100f409e1050100e709e1052100280db9052100e70acd0501006a01e40501003b01e10551808e0ae1050600060ae10506004e0ae10506001f0ae1050600c90be70506006f0be7050600b40ae7050600620ae70506009205e7050600130ae10506003e0ae1050600fb08e7050600f30722040600de05e70506004702b9050600bf0eb90506004f0db90506009c00e4050600d50de7050600d606e70506006c02b9050600af04b9050600a504b9050600920db90506008b01b90506008104b9050600f00ce4050600b80ce4050600d60ce4050600e50dea053600bd00f10516000100f50506008c08ea050600d401b90506000f0cfd0506002706010603004a01b9050300c00db9050300b60db90503005801b90503009e0db9050300f50c05060300e907e4050300d50be70503000408d10203009d0605060300f0020c06030051020c0603005e02150603000f071e0603007d0bb90503001a02e7050300cf04e4050300bb04d1020300070eb9050300d50be70550200000000086088b00b300010058200000000081089800150001006420000000008618a608250602002c22000000008608330a2d0204003422000000008600050d060004003c220000000086006b0b2d060400d0220000000086009d0a33060400a82500000000810023063a060500cc290000000081005e0a47060800682b000000008100aa0506000800d42e000000008100c90a4f060800d430000000008100b90906000a0070320000000081009d025a060a00b032000000008100500660060c007c330000000081002a0166060d00b033000000008100b60d6c060e005834000000008100b20d6c060f0036350000000081000302100010004b3500000000810009020a0211007f350000000081009e0506001200a435000000009100010672061200b6350000000091001a0d77061300e835000000009100d8047f0616004d36000000009100ea047f0619006036000000009100240386061c000437000000009100350d72061f00bc37000000009100f304a3012000f838000000009100430d8f0622003c390000000091002d0b8f062300e0390000000091008b0b94062400f83a0000000091002a01af062f00743c000000009100b502d0063d009b3c000000009100ba02d0063e00c43c0000000096006b0bd6063f00f03c0000000096009d0af4064b00193d000000009100b60d140758002c3d000000009600600b1b075900ec3d000000009600a70a360760008b3f000000009100990b6f076f00983f000000009100b10174077000b03f00000000910063057a0771006c40000000009100b7009e017300cc40000000009100280c9e01740034410000000091003f0e8f0675007942000000009100420cf10276008c4200000000910087069e01770094430000000091007f068207780050440000000093002f0388077a00f048000000009100ea029c0781002c4b000000009100480e8f068300c04b000000009100fb04a4078400484c000000009100ee05ac078700804e000000009600380cb5078a004d4f0000000091007305cf079100634f0000000091003605d60792007d4f000000009100b60d14079300904f0000000096002c06dd079400e5500000000091008c082208a300f350000000009100990b6f07a4000051000000009100b7009e01a50060510000000093002f032808a6006855000000009100d6083d08ae00b055000000009300670c4508b1005456000000009100860c8f06b200a856000000009100fb044b08b300085700000000930004085108b500c4590000000091007305cf07b800da590000000091005c0ed607b900f4590000000096002f035908ba00dc5a000000009600d10d7608c200545b000000008600f5020600c500b45c000000008618a6080600c5004f5d000000008618a6080600c500575d000000008618a6080600c5005f5d000000009118ac088208c5006b5d000000008618a6080600c500735d0000000083000b008608c500a65d000000008618a6080600c700ae5d000000008618a6080600c700c85d000000008618a6080600c700d05d000000008618a6080600c70000000100c10400000100610e00000200920b00000100ce05000001001c0800000200d90d000003006a0a00000100540d00000200c90100000100540d00000200f80d00000100540d000001001c08000001001c08000001001c0800000100c10400000100580a00000100680e00000100b108000002004c02000003002a0b00000100bb0d00000200e10d00000300920800000100bb0d00000200e10d00000300920800000100bb0d02000200d90d02000300dd06000001004c0200000100c90100000200310c00000100c90100000100fd0500000100c70400000200540d00000300f70500000400cf0b00000500760b00000600ba0a000007006a0a00000800bb0d00000900980500000a00f90700000b00210c00000100770d00000200e60500000300ba0a00000400c70400000500540d00000600f70500000700cf0b00000800760b00000900b10a00000a006a0a00000b00bb0d00000c00980500000d00f90700000e00210c00000100680e00000100680e00000100770d00000200c70400000300540d00000400f70500000500cf0b00000600760b00000700ba0a000008006a0a00000900bb0d00000a00980500000b00f90700000c00210c00000100770d00000200e60500000300c70400000400540d00000500f70500000600cf0b00000700760b00000800ba0a000009006a0a00000a00bb0d00000b00980500000c00f90700000d00210c00000100c10400000100c10402000200920802000300dc0102000400e605020005004c0202000600ca0e02000700a50000000100c10402000200920802000300dc0102000400db0502000500dd0602000600b00202000700fd0c02000800c40d02000900bb0d02000a00c70c02000b00e50002000c00ac0102000d00430102000e00e30c02000f00100200000100c10400000100dc0b00000100d90d00000200dc0b00000100c10400000100c10400000100c10400000100c10400000100c10400000100c10400000200f90200000100510100000200fd0c00000300c40d00000400bb0d00000500310c00000600f30b00000700a50000000100c40d020002000b0800000100840b00000100840b00000200200202000300970a000001000b0800000200d90d00000300a50000000100510100000200fd0c00000300c40d00000400bb0d00000500310c00000600f30b00000700a50000000100c10400000100c10400000100c10400000100c10402000200510102000300fd0c02000400c40d02000500bb0d02000600ee07020007006101020008000b0802000900a50602000a00f90202000b005a0202000c00630202000d00180702000e00a80d02000f00dc0b00000100dc0b00000100bb0d00000100bb0d00000100510100000200fd0c00000300c40d00000400bb0d00000500310c00000600f30b00000700a50000000800d70200000100970a00000200920602000300330100000100c10400000100c10400000100840b00000200b90100000100c10400000200f30b00000300d70200000100c10400000100c10400000100510100000200fd0c00000300c40d00000400bb0d00000500310c00000600f30b00000700a50000000800d702000001006e06020002000f0e02000300dc0b0000010000010000020009010900a60801001100a60806001900a6080a002900a60810003100a60810003900a60810004100a60810004900a60815005100a60810005900a60810009100a60806002901a60806007900c80d2e006901c20533000c00a60841001400a60841001c00a60806006100a60806007901a6085a008101a60861007100a608670071009609780091017a057d001400980885002400ac0c97002c002b0ea9002c007704ae0024007d0db300a101df0206001c009808c2003400ac0ca90034007d0db3001c00100dd2001c00170ed6003c00a60806004400a60806001c0065060701b10077020d01b1003e0213019101a50e1701b100ca001301b1008e05d2009101b10e1701b100730cb300b10033041d013c00100dd2004400330e220144002f0128013c002f0130014c00a60861003c00630d3d013c00170ed6005400a60830015c00100dd2005c00650607015c00a608060091016f05d2005c002f0130016400a6084100b100330498019101d50e9e016400330e22019101ec0ba30114009904a9011c002f01300164002f012801910183057d0091013d05ca017100c00acf019101ec0bd40114002f0128011400330e220191010805e3010c009904a90171001f0df6010c002f012801b900a6080600b9004705fc01b90061080302b900900c0a02b9005c090a02b9009f0b1500b9000c0b1500b900680d1500b100fe020f02b1002a01b300c100a6080600b10077041301c10084011f026100340513017900e3082d021901a60810009101430b38029101080548029101480c4d0291010405480291013d0560025c00fa0166029101590d71025c00e30b01009101d10677029101ec0b820291010405e301e1003a06b300e9003a06b300f1003a06b300e10077042d02e9007704d200f10077048a026c00a608060001013a06b30001016f052d0201017704b0026c002f013001d101d0011301e9004006b5024101a608100041014006b90254008c04b30054007704a900e900a60801004901a608150049014006c502f1004006d102c1010503f102c1011503f10274008c04b30074007704a900d901c2020e03e101e70214037400a60830015101fa0b21037c00a608300174004e0ca9009101510e45039101c1019801f100a60801009101a6084b030902a60806001102dd0d5103f100a60857039101a60869031902e70271038c00a60830016101a6080a028400a608300191017a0671025101a6088a035101840a2d025101b80491035101a6080a0249013a06b30049017704b30059013a06b30059016f052d02590177049e039101a608a3038c008c04b300e1004006ae038c007704a900e100a6080a027c008c04b3007c007704a90051013405c50384008c04b30084007704a9006101840a2d026101560bd200e1013405c5036101db09d2006101ca08d2009101ec0bcd03f100f900e50391011f0e9e03f10016020804f100e404b300c101340513011102b3080c04c100840111042102a60810005901a608a303590131061c04c90068022204c900bc062604c900a6080100c900ad062604e101d3072e040e0004003c040e000800af040e000c0028050a004000b00520005b00ab092e000b0096082e0013009f082e001b00be082e002300c7082e002b00e8082e00330027092e003b0035092e0043004e092e004b0054092e005300610940005b00ab0943015b00ab09c1015b00ab0940046300b00960046300a80ba00663005a0ea008630005111a00b700dc0047015e017701b201db01eb01ef011902250231023d02410254028f02be02ca02f602fb020103320360037e039603a903b203d303d703ea03f003f50317040200010000009c008e080000370a920802000100030001000200030002000400050039004c0053009000a200cb00f90000013601520158019101a902d502db02e302eb020480000001000200000000000000000000008c0e000004000000000000000000000033040201000000000100040000000000000000000000710e00000000040000000000000000000000330473060000000004000000000000000000000033044506000000000400000000000000000000003304ed00000000000700020008000200090002000a0002000b0003000c0004000d0004000e0005000000003c3e395f5f32355f30003c5265616443656c6c733e625f5f32355f30004e756c6c61626c6560310049456e756d657261626c65603100436f6d70617269736f6e60310049457175616c697479436f6d70617265726031004c69737460310055496e7433320053716c496e743332004b657956616c75655061697260320044696374696f6e6172796032006765745f4461746531393034007365745f44617465313930340064617465313930340053716c496e743634005574663136003c3e39003c4d6f64756c653e006765745f4e616d6573706163655552490053797374656d2e494f00666f726d756c610053797374656d2e44617461006765745f44617461006d73636f726c6962003c3e630053797374656d2e436f6c6c656374696f6e732e47656e6572696300526561640041646400726f756e6465640063686172676564007368617265640053746f7265640073746f726564005265736f6c766564007265736f6c766564003c44617465313930343e6b5f5f4261636b696e674669656c6400417070656e6400466f726d756c614b696e640053797374656d446174614163636573734b696e64006b696e6400446973636172640064697363617264005265706c61636500736f75726365006765745f4d657373616765006d65737361676500586c737843656c6c446973706c61794272696467650041646452616e6765004f7574707574436861726765006361636865006765745f5363616c65007363616c650049456e756d657261626c650049446973706f7361626c65006765745f4c6f63616c4e616d65006e616d65004461746554696d65006461746554696d650074696d65004f6e650053746f72656454797065006765745f4e6f64655479706500586d6c4e6f64655479706500586c737843656c6c547970650052657175697265436f6e74656e7454797065007479706500496e7075744661696c757265006765745f496e76617269616e7443756c747572650063756c7475726500446973706f736500547279506172736500446174650056616c69646174650043726561746500497348696768537572726f676174650049734c6f77537572726f6761746500436f6f7264696e617465004576616c7561746500436f6d70696c657247656e6572617465644174747269627574650044656275676761626c6541747472696275746500436f6d56697369626c6541747472696275746500417373656d626c795469746c65417474726962757465005461726765744672616d65776f726b41747472696275746500417373656d626c7946696c6556657273696f6e4174747269627574650053716c46756e6374696f6e41747472696275746500417373656d626c794465736372697074696f6e41747472696275746500436f6d70696c6174696f6e52656c61786174696f6e7341747472696275746500417373656d626c7950726f647563744174747269627574650047657441747472696275746500417373656d626c79436f6d70616e794174747269627574650052756e74696d65436f6d7061746962696c697479417474726962757465006765745f56616c756500436163686556616c7565006765745f48617356616c75650054727947657456616c7565005465787456616c75650052617756616c7565004d617856616c75650076616c75650061726368697665004e65676174697665004e6f6e6e65676174697665006765745f4973506f736974697665005265736f6c7665005175616e74697a65004c617374496e6465784f660053797374656d2e52756e74696d652e56657273696f6e696e670053716c537472696e6700546f537472696e6700537562737472696e67007365745f44746450726f63657373696e670053746f7077617463680046696e697368004d617468006765745f4c656e67746800456e6473576974680053746172747357697468006765745f446570746800646570746800436865636b00636c6f636b0052656164576f726b626f6f6b0053716c446563696d616c006765745f4f7264696e616c0073686565744f7264696e616c00726f774f7264696e616c006f7264696e616c0054656d706f72616c00746f74616c0072656c004661696c00546f6f6c62656c742e46696c652e586c73784d656d6f72792e646c6c005265616443656c6c0046696c6c006765745f4e756c6c006765745f49734e756c6c0053797374656d2e586d6c004f70656e586d6c004d656d6f727953747265616d006765745f4974656d006974656d0053797374656d005472696d0049736f466f726d004e756d626572466f726d006d6178696d756d0053716c426f6f6c65616e00626f6f6c65616e006f705f477265617465725468616e006f705f4c6573735468616e0054696d655370616e004a6f696e00436f6c756d6e00636f6c756d6e004172636869766553657373696f6e00546f6f6c62656c742e586c73782e5175616c696669636174696f6e004475726174696f6e006475726174696f6e0053797374656d2e476c6f62616c697a6174696f6e00416374696f6e0053797374656d2e5265666c656374696f6e00494f457863657074696f6e00496e76616c696444617461457863657074696f6e004465636f64657246616c6c6261636b457863657074696f6e00586d6c457863657074696f6e00496e76616c69644f7065726174696f6e457863657074696f6e004f766572666c6f77457863657074696f6e00537472696e67436f6d70617269736f6e00436f6d70617265546f0043756c74757265496e666f004563686f006563686f00526174696f00726174696f0043686172004e756d626572006e756d62657200586d6c526561646572007265616465720049466f726d617450726f7669646572005a6970456e74727950726f766964657200537472696e674275696c64657200537472696e67436f6d7061726572007365745f586d6c5265736f6c766572004d6963726f736f66742e53716c5365727665722e536572766572004572726f72006572726f7200476574456e756d657261746f72002e63746f72002e6363746f72004162730053797374656d2e446961676e6f7374696373006765745f5365636f6e647300526f756e645365636f6e6473006765745f456c61707365644d696c6c697365636f6e6473004275646765744d696c6c697365636f6e64730053797374656d2e52756e74696d652e496e7465726f7053657276696365730053797374656d2e52756e74696d652e436f6d70696c6572536572766963657300446562756767696e674d6f646573007365745f4d61784368617261637465727346726f6d456e746974696573004461746554696d655374796c6573004e756d6265725374796c6573006765745f506172744e616d65730053797374656d2e446174612e53716c54797065730056616c6964617465436f6e74656e74547970657300636f6e74656e745479706573006765745f4d696e75746573006465636f6465644279746573006d6174657269616c697a656442797465730041726368697665427974657300537472696e67427974657300546f74616c42797465730053716c4279746573006765745f436f756e746564416c6c6f636174696f6e4279746573005061727442797465730062797465730052656164537472696e677300737472696e677300586d6c52656164657253657474696e6773006765745f5469636b73004461795469636b73007469636b73005265616443656c6c730046696c6c43656c6c73006d617843656c6c730063656c6c7300436f6e7461696e73005265616452656c6174696f6e73004f666669636552656c6174696f6e7300776f726b626f6f6b52656c6174696f6e730053797374656d2e436f6c6c656374696f6e73007365745f49676e6f726550726f63657373696e67496e737472756374696f6e7300536f757263654f6652656c6174696f6e7368697073006765745f43686172730053716c4368617273006765745f486f7572730046696c6c536865657473004c697374536865657473007368656574730044696769747300646967697473004c696d697473006c696d69747300556e697473007365745f49676e6f7265436f6d6d656e747300586c7378456e747279506f696e747300446563696d616c506172747300706172747300537461747573007374617475730052656d6f7665417400436f6e63617400666f726d61740054727950617273654578616374004f626a656374005368656574005370726561647368656574006275646765740049735461726765740074617267657400496e746572707265740044696769740053706c69740047657456616c75654f7244656661756c7400526573756c7400436f656666696369656e74006765745f4973456d707479456c656d656e7400496e6372656d656e74007365745f4d617843686172616374657273496e446f63756d656e74006765745f43757272656e7400466f726d756c6150726573656e7400666f726d756c6150726573656e7400436163686550726573656e7400636163686550726573656e740056616c756550726573656e740070726573656e7400436865636b706f696e74006765745f436f756e7400526f6f7400526561645061727400776f726b626f6f6b506172740043616e6f6e6963616c506172740052656c6174696f6e73686970506172740070617274005472696d537461727400536f7274007365745f436c6f7365496e70757400696e707574004d6f76654e6578740053797374656d2e5465787400466f726d756c61546578740054797065645465787400747970656454657874005269636854657874007465787400526177007261770053746172744e65770046696c6c526f7700726f77004d6178006d617800536861726564466f726d756c61496e6465780073756666697800586c737843656c6c446973706c617900646973706c617900546f417272617900546f436861724172726179006765745f4b657900436f6e7461696e734b657900436c617373696679004d756c7469706c7900496e6465784f66416e7900436f70790062696e6172790063617465676f727900546f6f6c62656c742e417263686976652e5a69704d656d6f727900546f6f6c62656c742e46696c652e586c73784d656d6f7279006f705f457175616c697479006f705f496e657175616c697479005669736962696c697479007669736962696c6974790049734e756c6c4f72456d7074790000002749004e005000550054005f004e0055004c004c005f0049004e005400450052004e0041004c00000b2e00720065006c00730000175f00720065006c0073002f002e00720065006c0073000001001f01006f006600660069006300650044006f00630075006d0065006e007400013757004f0052004b0042004f004f004b005f00520045004c004100540049004f004e005f004400550050004c0049004300410054004500003357004f0052004b0042004f004f004b005f00520045004c004100540049004f004e005f004d0049005300530049004e0047000015730068006500650074002e006d00610069006e00001b530048004500450054005f004f005200440049004e0041004c00001377006f0072006b0073006800650065007400000772006f007700007368007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f00730070007200650061006400730068006500650074006d006c002f0032003000300036002f006d00610069006e0000137300680065006500740044006100740061000035530048004500450054005f0044004100540041005f004e0045005300540049004e0047005f0049004e00560041004c0049004400002752004f0057005f004e0045005300540049004e0047005f0049004e00560041004c004900440000037200001b52004f0057005f005200450046004500520045004e0043004500000363000029430045004c004c005f004e0045005300540049004e0047005f0049004e00560041004c00490044000015430045004c004c005f004c0049004d0049005400001d430045004c004c005f004400550050004c0049004300410054004500001f57004f0052004b00530048004500450054005f0045004d005000540059000023430045004c004c005f0052004f0057005f004d00490053004d0041005400430048000003740000036e0000037300001369006e006c0069006e0065005300740072000007730074007200000362000003650000036400002b430045004c004c005f0054005900500045005f0055004e0053005500500050004f0052005400450044000031430045004c004c005f0043004f004e00540045004e0054005f0055004e0053005500500050004f00520054004500440000037600001f560041004c00550045005f004400550050004c004900430041005400450000036600002346004f0052004d0055004c0041005f004400550050004c0049004300410054004500000d6e006f0072006d0061006c00000d730068006100720065006400000b61007200720061007900001364006100740061005400610062006c006500003146004f0052004d0055004c0041005f004b0049004e0044005f0055004e0053005500500050004f005200540045004400000573006900002946004f0052004d0055004c0041005f005300480041005200450044005f0049004e00440045005800000569007300002b49004e004c0049004e0045005f0053005400520049004e0047005f0049004e00560041004c0049004400002f5300480041005200450044005f0053005400520049004e0047005f005200450046004500520045004e00430045000003300000033100002b42004f004f004c00450041004e005f00560041004c00550045005f0049004e00560041004c0049004400001d010073006800610072006500640053007400720069006e006700730001315300480041005200450044005f0053005400520049004e00470053005f004400550050004c0049004300410054004500001b73006800610072006500640053007400720069006e00670073000007730073007400003b5300480041005200450044005f0053005400520049004e0047005f004e0045005300540049004e0047005f0049004e00560041004c004900440000335300480041005200450044005f0053005400520049004e0047005f0043004f0055004e0054005f004c0049004d004900540000315300480041005200450044005f0053005400520049004e0047005f0054004500580054005f004c0049004d004900540000295300480041005200450044005f0053005400520049004e00470053005f0045004d00500054005900000d730068006500650074007300001177006f0072006b0062006f006f006b00002d5300480045004500540053005f004e0045005300540049004e0047005f0049004e00560041004c0049004400001577006f0072006b0062006f006f006b0050007200003757004f0052004b0042004f004f004b005f00500052004f0050004500520054004900450053005f0049004e00560041004c0049004400001164006100740065003100390030003400000b660061006c0073006500000974007200750065000021440041005400450031003900300034005f0049004e00560041004c0049004400000b73006800650065007400002b530048004500450054005f004e0045005300540049004e0047005f0049004e00560041004c00490044000017530048004500450054005f004c0049004d004900540000096e0061006d00650000056900640000808768007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f006f006600660069006300650044006f00630075006d0065006e0074002f0032003000300036002f00720065006c006100740069006f006e0073006800690070007300000b73007400610074006500000f760069007300690062006c0065000025530048004500450054005f004e0041004d0045005f0049004e00560041004c0049004400000d680069006400640065006e0000157600650072007900480069006400640065006e000031530048004500450054005f005600490053004900420049004c004900540059005f0049004e00560041004c00490044000015010077006f0072006b0073006800650065007400012d530048004500450054005f00520045004c004100540049004f004e005f004d0049005300530049004e004700001d57004f0052004b0042004f004f004b005f0045004d00500054005900001b520065006c006100740069006f006e0073006800690070007300007968007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f007000610063006b006100670065002f0032003000300036002f00720065006c006100740069006f006e00730068006900700073000019520065006c006100740069006f006e00730068006900700000155400610072006700650074004d006f006400650000054900640000095400790070006500000d540061007200670065007400001149006e007400650072006e0061006c00003b450058005400450052004e0041004c005f00520045004c004100540049004f004e005f0055004e0053005500500050004f0052005400450044000021520045004c004100540049004f004e005f0049004e00560041004c004900440000808968007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f006f006600660069006300650044006f00630075006d0065006e0074002f0032003000300036002f00720065006c006100740069006f006e00730068006900700073002f000033520045004c004100540049004f004e005f0054005900500045005f0055004e0053005500500050004f0052005400450044000015760062006100500072006f006a006500630074000019650078007400650072006e0061006c004c0069006e006b00001763006f006e006e0065006300740069006f006e007300000f63006f006e00740072006f006c0000136f006c0065004f0062006a00650063007400002f520045004c004100540049004f004e005f005400410052004700450054005f004d0049005300530049004e00470000030100011d520045004c004100540049004f004e005f0045004d0050005400590000275b0043006f006e00740065006e0074005f00540079007000650073005d002e0078006d006c00000b54007900700065007300007968007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f007000610063006b006100670065002f0032003000300036002f0063006f006e00740065006e0074002d0074007900700065007300011743006f006e00740065006e0074005400790070006500002943004f004e00540045004e0054005f0054005900500045005f0049004e00560041004c004900440000114f007600650072007200690064006500001150006100720074004e0061006d00650000032f00002d43004f004e00540045004e0054005f0054005900500045005f004400550050004c0049004300410054004500000f440065006600610075006c007400003143004f004e00540045004e0054005f0054005900500045005f0055004e0053005500500050004f005200540045004400000b6d006100630072006f000007760062006100000f6100630074006900760065005800003358004c00530058005f0043004f004e00540045004e0054005f0054005900500045005f004d0049005300530049004e00470000796100700070006c00690063006100740069006f006e002f0076006e0064002e006f00700065006e0078006d006c0066006f0072006d006100740073002d006f006600660069006300650064006f00630075006d0065006e0074002e00730070007200650061006400730068006500650074006d006c002e0001092b0078006d006c00002b43004f004e00540045004e0054005f0054005900500045005f004d00490053004d004100540043004800001d50004100520054005f00530055004d005f004c0049004d0049005400001f58004d004c005f00440045005000540048005f004c0049004d0049005400002954004500580054005f004e0045005300540049004e0047005f0049004e00560041004c00490044000007720050006800003143004f0055004e005400450044005f0041004c004c004f0043004100540049004f004e005f004c0049004d0049005400001f4200550044004700450054005f004500580043004500450044004500440000135400420058005f0058004c00530058005f00002958004d004c005f0052004f004f0054005f0055004e0053005500500050004f005200540045004400001d430045004c004c005f005200450046004500520045004e0043004500002b50004100520054005f004e0041004d0045005f0055004e0053005500500050004f00520054004500440000032e0000052e002e000037520045004c004100540049004f004e005f005400410052004700450054005f0055004e0053005500500050004f005200540045004400002d520045004c004100540049004f004e005f005400410052004700450054005f00450053004300410050004500000d5f00720065006c0073002f00000f2f005f00720065006c0073002f000025520045004c004100540049004f004e005f0050004100520054005f004e0041004d004500002b5400420058005f0058004c00530058005f004c0049004d00490054005f0043004f004e00460049004700002d5400420058005f0058004c00530058005f00530048004500450054005f004f005200440049004e0041004c00002d5400420058005f0058004c00530058005f0041005200430048004900560045005f004c0049004d004900540000295400420058005f0058004c00530058005f0058004d004c005f0049004e00560041004c004900440000335400420058005f0058004c00530058005f0045004e0043004f00440049004e0047005f0049004e00560041004c004900440000355400420058005f0058004c00530058005f0043004f004e005400410049004e00450052005f0049004e00560041004c0049004400000d6e0075006d00620065007200000f62006f006f006c00650061006e00000974006500780074000009640061007400650000116400610074006500740069006d0065000009740069006d00650000116400750072006100740069006f006e00000930002e0030003000001123002c002300230030002e0030003000001130002e003000300045002b00300030000011680068003a006d006d003a0073007300000530002500000b30002e00300030002500001579007900790079002d006d006d002d0064006400012779007900790079002d006d006d002d00640064002000680068003a006d006d003a007300730001135b0068005d003a006d006d003a0073007300002b79007900790079002d004d004d002d0064006400270054002700480048003a006d006d003a0073007300013b79007900790079002d004d004d002d0064006400270054002700480048003a006d006d003a00730073002e004600460046004600460046004600011579007900790079002d004d004d002d0064006400010b65006e002d0055005300010b640065002d0044004500010b740072002d0054005200012779007900790079002d004d004d002d00640064002000480048003a006d006d003a007300730001054400320000033a0000032c00000731003000300000032d000103450000032b000003250000315400420058005f0058004c00530058005f0044004900530050004c00410059005f00420049004e00440049004e00470000194c0049004d00490054005f0043004f004e0046004900470000004760c218c9306545965f7e1d1af81c3a00042001010803200001052001011111042001010e04200101021307060e1d0e080e15114d020e0e151151020e0e040000123d0500001280b507151241020e1d050a200101151280b901130006151241020e0e06151245011220062002011d0502052002011c18102008011280c50a0a080a0a11651280c10420001d0e072002020e1180cd0a200015114d02130013010615114d020e0e0a2000151151021300130106151151020e0e04200013000420001301032000020a0702151155011220122008200015115501130006151155011220032000080520001d13001c070a151245010e151245011224151241020a0212590202020812240a0615124501122406151241020a020520011300080520001180d50320000e050002020e0e0420010e0e05200102130007200201130013010520010113000615126d0112240920010115126d0113000a070708080e1224080e0805151169010805151245010e1807070e151245010e15114d020e0e151151020e0e1259020e19070c151241020e021259020202020e0e0e0e0e15115501122006151241020e020520020e0e0e040001020e0500020e0e0e08200202130010130117070a151241020e0e151241020e021259020e0e0e0e0e0e0420010e08042001020e0600030e0e0e0e0707040212590e0e072002080e1180cd0307010e0607021d05125d0520011d050e062001011180d9062001011280dd042001010a09000212591280c5125d05070208126105200112610e070704081261080e0320000a0607040a0e08030420010308030701080607031d0e080e04200108030620011d0e1d030b0704151245010e1d0e080e0520020e08080a200101151280e50113000520010e1d030a00020e0e151280e5010e0700040e0e0e0e0e042000116519070915124501122c121c1208127d1d12240812241d122012200615124501122c0420001d050306117504061180a1060702122c122004061180a5060702122c12240306117905151169010207151169011180a907151169011180b105151169010a040001020304070208030507030808080c07061230080e1234081180a90500001280ed0c0004020e1180f51280f91008100005020e1d0e1280f91180fd101180a912070e02080808080e1d091d080e080b080b08052001081d03052002010308050002080808082004010505021d080807050a1d0308080a072003011d0308080c0004020e1180f51280f9100a0b07070e0e0a0a0a0a1180a90620030108080804061180a907070115116901020420001d03052001011d0304070112300306117112070912300e0a0a1180b108031180a91180b10720020e0e1280f90500010e1d0e0307010a0d07081d081d091d0308080b080b0420001d080507021d0308040702080e12070f0e0e0e02080e020e080e0e030812610803200005040001080805200112610304070112380500001280ad030611650700020211651165042001080808b77a5c561934e0897268007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f00730070007200650061006400730068006500650074006d006c002f0032003000300036002f006d00610069006e007868007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f007000610063006b006100670065002f0032003000300036002f00720065006c006100740069006f006e0073006800690070007300808668007400740070003a002f002f0073006300680065006d00610073002e006f00700065006e0078006d006c0066006f0072006d006100740073002e006f00720067002f006f006600660069006300650044006f00630075006d0065006e0074002f0032003000300036002f00720065006c006100740069006f006e00730068006900700073000800c0692ac900000002060e030612390306123d0806151241020e1d050706151241020e0e07061512450112200306121c02060a0206020206080606151169010803061228070615126d0112240306122003061224060615116901020806151169011180a90806151169011180b10606151169010a072002011d05121c0520001d12200620011d1224080c20031224125908151245010e072000151245010e0a2002151241020e0e0e0e052002010e0e05200112590e0520010212590520010e1259040001010e0700030112590e0e060003080e080e080003010e100810080400010e0e1a000b121c1171117111711175117511751175117111751179117520000e127d12808111750211711171117111751175117511751171117511791175050001127d0e1d000c127d128081117111711171117511751175117511711175117911751f000d127d1280811175117111711171117511751175117511711175117911750600011180a10e1a0007011c101175101180a1101175101180a1101180a1101180a538000f011c101175101180a1101175101175101180a1101180a5101180a1101180a1101180a5101180a1101180a1101175101180a5101180a1040001080e0500011230080700021230123008050002020e0213000712300e15116901020e0e0e0e1511690102070002080e101234070003020e08100a080003081234123002190007127d1280ad1180a51280ad1280ad1280ad1280ad1180a50600010a1280ad0600010e1280ad44000f011c101180a1101180a5101180a1101180a1101180a5101180a1101c101180a510151169011180a910151169011180a910151169011180b1101171101180a110117505000112380814000812380e15116901020e0e0e0e15116901020e070003020a0a100a0500010e11790500020e0e080700030e11790e0e1c0008127d1280ad1180a51280ad1280ad1280ad1280ad1180a51280ad0b0003011c101280ad101175030000010720020812241224032800020328000a0801000800000000001e01000100540216577261704e6f6e457863657074696f6e5468726f7773010801000200000000002001001b546f6f6c62656c7420584c5358204d656d6f72792052656164657200003e010039426f756e64656420534146452062696e61727920584c535820776f726b736865657420616e64207370617273652063656c6c2072656164657200000d0100086765636f6d70617400001801001353514c2053657276657220546f6f6c62656c7400000501000000000c010007312e322e302e3000004901001a2e4e45544672616d65776f726b2c56657273696f6e3d76342e380100540e144672616d65776f726b446973706c61794e616d65122e4e4554204672616d65776f726b20342e38040100000081f601000600540e1146696c6c526f774d6574686f644e616d650a46696c6c5368656574735455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630054020949735072656369736501540e0f5461626c65446566696e6974696f6e7e4572726f724e756d62657220696e742c204572726f724d657373616765206e766172636861722834303030292c2053686565744f7264696e616c20696e742c2053686565744e616d65206e76617263686172286d6178292c205669736962696c697479206e76617263686172283136292c2044617465313930342062697482b001000600540e1146696c6c526f774d6574686f644e616d650946696c6c43656c6c735455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630054020949735072656369736501540e0f5461626c65446566696e6974696f6e81384572726f724e756d62657220696e742c204572726f724d657373616765206e766172636861722834303030292c20526f774f7264696e616c20696e742c20436f6c756d6e4f7264696e616c20696e742c2053746f72656454797065206e76617263686172283136292c2056616c756550726573656e74206269742c2052617756616c7565206e76617263686172286d6178292c205465787456616c7565206e76617263686172286d6178292c20466f726d756c6150726573656e74206269742c20466f726d756c6154657874206e76617263686172286d6178292c20466f726d756c614b696e64206e76617263686172283136292c20536861726564466f726d756c61496e64657820696e742c20436163686550726573656e74206269742c20436163686556616c7565206e76617263686172286d61782982a901000600540e1146696c6c526f774d6574686f644e616d650446696c6c5455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e69737469630154020949735072656369736501540e0f5461626c65446566696e6974696f6e813653746f72656454797065206e76617263686172283332292c2056616c756550726573656e74206269742c2052617756616c7565206e76617263686172286d6178292c205465787456616c7565206e76617263686172286d6178292c204563686f507265736572766564206269742c205265736f6c76656454797065206e76617263686172283136292c204e756d62657256616c75652073716c5f76617269616e742c20426f6f6c65616e56616c7565206269742c204461746556616c756520646174652c204461746554696d6556616c7565206461746574696d65322837292c2054696d6556616c75652074696d652837292c204475726174696f6e5469636b7320626967696e742c2054797065645465787456616c7565206e76617263686172286d6178292c20537461747573436f646520696e74819e01000600540e1146696c6c526f774d6574686f644e616d650746696c6c526f77540e0f5461626c65446566696e6974696f6e29446973706c617954657874206e76617263686172286d6178292c20537461747573436f646520696e745455794d6963726f736f66742e53716c5365727665722e5365727665722e446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038390a446174614163636573730000000054557f4d6963726f736f66742e53716c5365727665722e5365727665722e53797374656d446174614163636573734b696e642c2053797374656d2e446174612c2056657273696f6e3d342e302e302e302c2043756c747572653d6e65757472616c2c205075626c69634b6579546f6b656e3d623737613563353631393334653038391053797374656d446174614163636573730000000054020f497344657465726d696e697374696301540209497350726563697365010000000000000000000000000000001000000000000000000000000000000058a70000000000000000000072a7000000200000000000000000000000000000000000000000000064a70000000000000000000000005f436f72446c6c4d61696e006d73636f7265652e646c6c0000000000ff250020001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100100000001800008000000000000000000000000000000100010000003000008000000000000000000000000000000100000000004800000058c00000c80300000000000000000000c80334000000560053005f00560045005200530049004f004e005f0049004e0046004f0000000000bd04effe00000100020001000000000002000100000000003f000000000000000400000002000000000000000000000000000000440000000100560061007200460069006c00650049006e0066006f00000000002400040000005400720061006e0073006c006100740069006f006e00000000000000b00428030000010053007400720069006e006700460069006c00650049006e0066006f0000000403000001003000300030003000300034006200300000008c003a00010043006f006d006d0065006e0074007300000042006f0075006e00640065006400200053004100460045002000620069006e00610072007900200058004c0053005800200077006f0072006b0073006800650065007400200061006e00640020007300700061007200730065002000630065006c006c002000720065006100640065007200000032000900010043006f006d00700061006e0079004e0061006d006500000000006700650063006f006d007000610074000000000060001c000100460069006c0065004400650073006300720069007000740069006f006e000000000054006f006f006c00620065006c007400200058004c005300580020004d0065006d006f007200790020005200650061006400650072000000300008000100460069006c006500560065007200730069006f006e000000000031002e0032002e0030002e00300000005a001d00010049006e007400650072006e0061006c004e0061006d006500000054006f006f006c00620065006c0074002e00460069006c0065002e0058006c00730078004d0065006d006f00720079002e0064006c006c00000000002800020001004c006500670061006c0043006f00700079007200690067006800740000002000000062001d0001004f0072006900670069006e0061006c00460069006c0065006e0061006d006500000054006f006f006c00620065006c0074002e00460069006c0065002e0058006c00730078004d0065006d006f00720079002e0064006c006c0000000000480014000100500072006f0064007500630074004e0061006d00650000000000530051004c002000530065007200760065007200200054006f006f006c00620065006c0074000000340008000100500072006f006400750063007400560065007200730069006f006e00000031002e0032002e0030002e003000000038000800010041007300730065006d0062006c0079002000560065007200730069006f006e00000031002e0032002e0030002e003000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a000000c000000843700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000,
 @Version nvarchar(max),@Hash varbinary(64),@AssemblyId int,@InstalledMode nvarchar(max),
 @Installed bit,@Release int,@Phase int=0,@ProtectFuture bit=1;
IF ISNULL(TRY_CONVERT(int,SERVERPROPERTY('ProductMajorVersion')),0) NOT IN(15,16,17)
 THROW 51530,N'Unterstützt werden SQL Server 2019, 2022 und 2025.',1;
IF CONVERT(varbinary(max),@Mode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))
 THROW 51530,N'DeploymentMode muss exakt local oder central sein.',1;
IF @Bits IS NULL OR DATALENGTH(@Bits)<1024 THROW 51531,N'Plausibles Releasebinary fehlt.',1;
SET @Hash=HASHBYTES('SHA2_512',@Bits);
DECLARE @Dependency TABLE(Id nvarchar(128) NOT NULL,MinimumMinor int NOT NULL,ObjectId int NULL,Version nvarchar(64) NULL);
DECLARE @Slots TABLE(Name sysname COLLATE DATABASE_DEFAULT NOT NULL,Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL,FirstRelease int NOT NULL,Class nvarchar(128) NULL,Method nvarchar(128) NULL);
INSERT @Slots VALUES
 (N'USP_ListXlsxWorksheets','P',10,NULL,NULL),
 (N'USP_ReadXlsxWorksheetCells','P',10,NULL,NULL),
 (N'USP_InternalXlsxRead','P',10,NULL,NULL),
 (N'TVF_InternalXlsxSheets','FT',10,N'Toolbelt.Xlsx.Qualification.XlsxEntryPoints',N'ListSheets'),
 (N'TVF_InternalXlsxCells','FT',10,N'Toolbelt.Xlsx.Qualification.XlsxEntryPoints',N'ReadCells'),
 (N'TVF_InternalInterpretXlsxCell','FT',11,N'Toolbelt.Xlsx.Qualification.XlsxCellType',N'Interpret'),
 (N'TVF_InterpretXlsxCell','IF',11,NULL,NULL),
 (N'TVF_InternalFormatXlsxCell','FT',12,N'Toolbelt.Xlsx.Qualification.XlsxCellDisplayBridge',N'Evaluate'),
 (N'TVF_FormatXlsxCell','IF',12,NULL,NULL);
DECLARE @Own TABLE(Id int NOT NULL PRIMARY KEY);
BEGIN TRY
 WHILE @Phase<2
 BEGIN
  -- Benutzerfreigabe 2026-10-02: vollständige Consumersicht vor Mutation,
  -- im zweiten Durchlauf erneut unter demselben Transaktions-AppLock.
  IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
   OR ISNULL(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
   THROW 51535,N'Vollständige Sicht auf SQL-Abhängigkeiten ist erforderlich.',2;
  IF NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr enabled' AND value_in_use=1)
   OR NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr strict security' AND value_in_use=1)
   OR NOT EXISTS(SELECT 1 FROM sys.trusted_assemblies WHERE hash=@Hash)
   THROW 51531,N'CLR/strict security und exakter Releasehashtrust sind erforderlich.',1;
-- Beide Dependencies werden vor jeder Mutation kanonisch geprüft.
DELETE FROM @Dependency;
INSERT @Dependency SELECT N'toolbelt.core.result-table',0,OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P'),
 TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
INSERT @Dependency SELECT N'toolbelt.archive.zip-memory',4,NULL,TRY_CONVERT(nvarchar(64),value)
 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.archive.zip-memory.Version';
IF (SELECT COUNT(*) FROM @Dependency)<>2 OR EXISTS
 (SELECT 1 FROM @Dependency d
  CROSS APPLY(SELECT TRY_CONVERT(int,PARSENAME(d.Version,3)) Major,
    TRY_CONVERT(int,PARSENAME(d.Version,2)) Minor,TRY_CONVERT(int,PARSENAME(d.Version,1)) Patch) p
  WHERE p.Major IS NULL OR p.Major<>1 OR p.Minor IS NULL OR p.Minor<d.MinimumMinor OR p.Patch IS NULL OR p.Patch<0
    OR CONVERT(varbinary(max),d.Version)<>CONVERT(varbinary(max),CONCAT(p.Major,N'.',p.Minor,N'.',p.Patch))
    OR (d.Id=N'toolbelt.core.result-table' AND (d.ObjectId IS NULL
        OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE e.class=1 AND e.major_id=d.ObjectId AND e.minor_id=0
             AND e.name=N'Toolbelt.ModuleId' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(128),e.value))=CONVERT(varbinary(max),d.Id))
        OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE e.class=1 AND e.major_id=d.ObjectId AND e.minor_id=0
             AND e.name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),e.value))=CONVERT(varbinary(max),d.Version)))))
 THROW 51532,N'Die registrierten ResultTable- und ZIP-Dependencies sind ungeeignet.',1;
IF NOT EXISTS(SELECT 1 FROM sys.assemblies a JOIN sys.extended_properties e ON e.class=5 AND e.major_id=a.assembly_id
 WHERE a.name=N'Toolbelt_Archive_ZipMemory' AND a.permission_set=1 AND e.name=N'Toolbelt.ModuleId'
 AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(128),e.value))=CONVERT(varbinary(max),N'toolbelt.archive.zip-memory'))
 THROW 51532,N'Die kanonische SAFE-ZIP-Assembly fehlt.',1;

-- Keine Hashgleichheit ersetzt die bekannte Release-/Slotidentität.
SELECT @Version=NULL,@Installed=0,@InstalledMode=NULL,@AssemblyId=NULL;
SELECT @Version=TRY_CONVERT(nvarchar(max),value),@Installed=1 FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.Version';
SELECT @InstalledMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode';
IF @Installed=1 AND (@Version IS NULL OR CONVERT(varbinary(max),@Version) NOT IN
 (CONVERT(varbinary(max),N'1.0.0'),CONVERT(varbinary(max),N'1.1.0'),CONVERT(varbinary(max),N'1.2.0')))
 THROW 51534,N'Unbekannter oder inkohärenter XLSX-Release.',1;
IF (@Installed=1 AND (@InstalledMode IS NULL OR CONVERT(varbinary(max),@InstalledMode) NOT IN
 (CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))))
 OR (@Installed=0 AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode'))
 THROW 51534,N'Unbekannter oder inkohärenter XLSX-Modus.',1;
SET @Release=CASE CONVERT(varbinary(max),@Version) WHEN CONVERT(varbinary(max),N'1.0.0') THEN 10 WHEN CONVERT(varbinary(max),N'1.1.0') THEN 11 WHEN CONVERT(varbinary(max),N'1.2.0') THEN 12 ELSE 0 END;
SELECT @AssemblyId=assembly_id FROM sys.assemblies WHERE name=N'Toolbelt_File_XlsxMemory';
IF (@Installed=1 AND @AssemblyId IS NULL) OR (@Installed=0 AND @AssemblyId IS NOT NULL)
 OR (@AssemblyId IS NOT NULL AND (NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@AssemblyId AND permission_set=1
  AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_File_XlsxMemory'))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND name=N'Toolbelt.ModuleId'
 AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.file.xlsx-memory'))))
 THROW 51534,N'Fremde oder inkohärente XLSX-Assembly.',1;
IF EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(s.Name))
 WHERE (@Installed=1 AND s.FirstRelease<=@Release AND
  (o.object_id IS NULL OR CONVERT(varbinary(max),o.name)<>CONVERT(varbinary(max),s.Name)
   OR CONVERT(varbinary(max),o.type)<>CONVERT(varbinary(max),s.Kind)
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleId'
      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.file.xlsx-memory'))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleVersion'
      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Version))
   OR (s.Kind='FT' AND NOT EXISTS(SELECT 1 FROM sys.assembly_modules m WHERE m.object_id=o.object_id AND m.assembly_id=@AssemblyId
      AND CONVERT(varbinary(max),m.assembly_class)=CONVERT(varbinary(max),s.Class)
      AND CONVERT(varbinary(max),m.assembly_method)=CONVERT(varbinary(max),s.Method)))))
  OR ((@Installed=0 OR s.FirstRelease>@Release) AND o.object_id IS NOT NULL AND @ProtectFuture=1))
 THROW 51534,N'XLSX-Slot, Typ oder Eigentumsmarker ist nicht der bekannte Release.',1;
DELETE FROM @Own;
INSERT @Own SELECT OBJECT_ID(N'toolbelt_file.'+QUOTENAME(Name)) FROM @Slots WHERE FirstRelease<=@Release;
IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@AssemblyId AND object_id NOT IN(SELECT Id FROM @Own))
 OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@AssemblyId)
 THROW 51535,N'Fremder Assemblyconsumer blockiert XLSX-Lifecycle.',1;
IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d WHERE d.referenced_id IN
 (SELECT o.Id FROM @Own o JOIN sys.objects a ON a.object_id=o.Id WHERE a.type IN('FT','IF'))
 AND d.referencing_id NOT IN(SELECT Id FROM @Own))
 THROW 51535,N'Fremder Consumer verwendet ein XLSX-Binding.',1;
  IF @Phase=0
  BEGIN
   BEGIN TRANSACTION;
   DECLARE @Lock int;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.file.xlsx-memory',
    @LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock<0 THROW 51533,N'Paralleles XLSX-Deployment aktiv.',1;
  END;
  SET @Phase+=1;
 END;
 IF SCHEMA_ID(N'toolbelt_file') IS NULL
 BEGIN
   EXEC(N'CREATE SCHEMA toolbelt_file');
   EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_file';
   EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'file',@level0type=N'SCHEMA',@level0name=N'toolbelt_file';
 END;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_FormatXlsxCell;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_InternalFormatXlsxCell;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_InterpretXlsxCell;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_InternalInterpretXlsxCell;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_InternalXlsxSheets;
 DROP FUNCTION IF EXISTS toolbelt_file.TVF_InternalXlsxCells;
 DECLARE @InstalledHash varbinary(64)=(SELECT HASHBYTES('SHA2_512',content) FROM sys.assembly_files WHERE assembly_id=@AssemblyId AND file_id=1);
 IF @InstalledHash IS NULL OR @InstalledHash<>@Hash
 BEGIN
   DECLARE @Ddl nvarchar(max)=CASE WHEN @AssemblyId IS NULL THEN N'CREATE' ELSE N'ALTER' END
      +N' ASSEMBLY [Toolbelt_File_XlsxMemory] FROM '+CONVERT(nvarchar(max),@Bits,1)+N' WITH PERMISSION_SET=SAFE;';
   EXEC sys.sp_executesql @Ddl;
 END;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
/*
-- Objekt: toolbelt_file.TVF_InternalFormatXlsxCell (interne CLR-FT).
-- Zweck: Reiner Einzelzell-Anzeigetransport auf unverändertem Typkern.
-- Parameter: Acht Zell-/Ziel-/Kulturparameter, keine Workbook-/Styleauswertung.
-- Resultset: Genau eine nullable Zeile DisplayText nvarchar(max), StatusCode int.
-- Fehler: Erwartete Zellfehler als Status; unerwartete CLR-Fehler original.
-- Performance: Feste Input-/Ausgabequoten, kein externer Datenzugriff.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE FUNCTION toolbelt_file.TVF_InternalFormatXlsxCell
(
 @StoredType nvarchar(max), @ValuePresent bit, @RawValue nvarchar(max),
 @TextValue nvarchar(max), @TargetType nvarchar(max), @FormatCode nvarchar(max),
 @Date1904 bit, @CultureName nvarchar(max)
)
RETURNS TABLE(DisplayText nvarchar(max) NULL, StatusCode int NULL)
AS EXTERNAL NAME [Toolbelt_File_XlsxMemory].[Toolbelt.Xlsx.Qualification.XlsxCellDisplayBridge].[Evaluate];
GO
/*
-- Objekt: toolbelt_file.TVF_FormatXlsxCell.
-- Zweck: Bereits gelesene XLSX-Einzelzelle mit endlichen Formaten anzeigen.
-- Parameter: @StoredType/@RawValue/@TextValue/@TargetType/@FormatCode nvarchar(max),
-- @ValuePresent/@Date1904 bit, @CultureName nvarchar(max), alle Default NULL.
-- Kultur: ausschließlich en-US, de-DE oder tr-TR, ohne Betriebssysteminferenz.
-- Resultset: DisplayText nvarchar(max) nullable und StatusCode int immer gesetzt.
-- NULL: Keine Null-on-null-Abkürzung; genau eine Statuszeile auch bei NULL-Input.
-- Fehler: 0OK/1Absent/2Argument/3Limit/4LexikUTF16/5NumberRange/6Unsupported/
-- 7Serial60/8TemporalRange/9Precision/10ExcelError/11NullBinding; Fehlertext NULL.
-- Rechte: vorhandenes SELECT/Ownershipchain, keine Rechteerteilung.
-- Performance: Typkernbudgets unverändert; Kultur höchstens32 UTF16-Einheiten.
-- Grenzen: Kein Workbook-/SST-/Stylezugriff, keine Formelberechnung oder Daueranzeige.
-- Dependencies: Interne FT in vorhandener SAFE-XLSX-Assembly, Typkern unverändert.
-- Beispiel: SELECT * FROM toolbelt_file.TVF_FormatXlsxCell(N'n',1,N'1.235',NULL,N'number',N'0.00',NULL,N'en-US');
-- Vertrag: Documentation/Architecture/XLSX_CELL_DISPLAY_CONTRACT.md.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER FUNCTION toolbelt_file.TVF_FormatXlsxCell
(
 @StoredType nvarchar(max)=NULL, @ValuePresent bit=NULL, @RawValue nvarchar(max)=NULL,
 @TextValue nvarchar(max)=NULL, @TargetType nvarchar(max)=NULL, @FormatCode nvarchar(max)=NULL,
 @Date1904 bit=NULL, @CultureName nvarchar(max)=NULL
)
RETURNS TABLE AS RETURN
 SELECT CASE WHEN r.StatusCode IS NOT NULL THEN r.DisplayText END DisplayText,
        ISNULL(r.StatusCode,11) StatusCode
 FROM toolbelt_file.TVF_InternalFormatXlsxCell
 (@StoredType,@ValuePresent,@RawValue,@TextValue,@TargetType,@FormatCode,@Date1904,@CultureName) r;
GO
/*
-- Objekt: toolbelt_file.TVF_InternalInterpretXlsxCell (interne CLR-FT)
-- Parameter: Sieben Zell-/Zielparameter; keine Workbook- oder Styleauswertung.
-- Resultset: Genau eine nullable Statuszeile mit 14 Spalten.
-- Fehlerverhalten: Erwartete Zellfehler als Status; unerwartete CLR-Fehler original.
-- Performance: Feste Input-/Ausgabequoten, datenzugriffsfreie Einzelzellinterpretation.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE FUNCTION toolbelt_file.TVF_InternalInterpretXlsxCell
(
 @StoredType nvarchar(max), @ValuePresent bit, @RawValue nvarchar(max),
 @TextValue nvarchar(max), @TargetType nvarchar(max), @FormatCode nvarchar(max), @Date1904 bit
)
RETURNS TABLE
(
 StoredType nvarchar(32) NULL, ValuePresent bit NULL, RawValue nvarchar(max) NULL,
 TextValue nvarchar(max) NULL, EchoPreserved bit NULL, ResolvedType nvarchar(16) NULL,
 NumberValue sql_variant NULL, BooleanValue bit NULL, DateValue date NULL,
 DateTimeValue datetime2(7) NULL, TimeValue time(7) NULL, DurationTicks bigint NULL,
 TypedTextValue nvarchar(max) NULL, StatusCode int NULL
)
AS EXTERNAL NAME [Toolbelt_File_XlsxMemory].[Toolbelt.Xlsx.Qualification.XlsxCellType].[Interpret];
GO
/*
-- Objekt: toolbelt_file.TVF_InterpretXlsxCell
-- Zweck: Bereits gelesene XLSX-Einzelzelle invariant typisieren, ohne Anzeigeformatierung.
-- Parameter: @StoredType nvarchar(max)=NULL (n/b/s/str/inlineStr/d/e),
-- @ValuePresent bit=NULL (XML-v-Presence), @RawValue nvarchar(max)=NULL,
-- @TextValue nvarchar(max)=NULL (bereits aufgelöster Text), @TargetType nvarchar(max)=NULL
-- (number/boolean/text/date/datetime/time/duration), @FormatCode nvarchar(max)=NULL
-- (endliche Zielklassifikation), @Date1904 bit=NULL (n-Date/Datetime benötigt Datumssystem).
-- Resultset: Genau eine Zeile mit StoredType nvarchar(32), ValuePresent bit,
-- RawValue nvarchar(max), TextValue nvarchar(max), EchoPreserved bit,
-- ResolvedType nvarchar(16), NumberValue sql_variant (exaktes SqlDecimal p<=38),
-- BooleanValue bit, DateValue date, DateTimeValue datetime2(7), TimeValue time(7),
-- DurationTicks bigint, TypedTextValue nvarchar(max), StatusCode int.
-- NULL: Echo-/Typedwerte nullable; EchoPreserved/StatusCode logisch immer gesetzt.
-- Ausschließlich NULL-Input liefert eine Statuszeile, keine Null-on-null-Abkürzung.
-- Fehlerverhalten: 0OK/1Absent/2Argument/3Limit/4LexikUTF16/5NumberRange/6Unsupported/
-- 7Serial60/8TemporalRange/9Precision/10ExcelError/11NullBinding. Alle Typedwerte
-- bei Fehler NULL; Status3/11 verwirft Echos atomar. Andere Enginefehler original.
-- Dependencies: Interne FT derselben vorhandenen SAFE-XLSX-Assembly; Moduldependencies
-- ZIP>=1.4.0/ResultTable>=1.0.0 bleiben. Caller benötigt bestehendes SELECT auf der TVF;
-- Deployment erstellt keine Berechtigungen. SQL2019/2022/2025 Windows/Linux Zielmatrix,
-- neue API dort erst nach tatsächlicher integrierter Qualifikation als PASS behandeln.
-- Performance: Input32/32/128/65536/65536 UTF16; Number-/Serialparser128; Ausgabecharge
-- 262144=256+4*Stringunits, keine gesamte Heap-/SQL-Memorygrant-/Laufzeitgarantie.
-- Grenzen: Keine Workbook-/SST-/Style-Neulesung, Cultureinferenz oder Formelberechnung.
-- Beispiel: SELECT * FROM toolbelt_file.TVF_InterpretXlsxCell(N'n',1,N'1',NULL,NULL,NULL,NULL);
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER FUNCTION toolbelt_file.TVF_InterpretXlsxCell
(
 @StoredType nvarchar(max) = NULL, @ValuePresent bit = NULL, @RawValue nvarchar(max) = NULL,
 @TextValue nvarchar(max) = NULL, @TargetType nvarchar(max) = NULL,
 @FormatCode nvarchar(max) = NULL, @Date1904 bit = NULL
)
RETURNS TABLE
AS
RETURN
 SELECT
  CASE WHEN r.StatusCode IS NOT NULL THEN r.StoredType END AS StoredType,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.ValuePresent END AS ValuePresent,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.RawValue END AS RawValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.TextValue END AS TextValue,
  ISNULL(CASE WHEN r.StatusCode IS NOT NULL THEN r.EchoPreserved END,CONVERT(bit,0)) AS EchoPreserved,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.ResolvedType END AS ResolvedType,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.NumberValue END AS NumberValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.BooleanValue END AS BooleanValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.DateValue END AS DateValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.DateTimeValue END AS DateTimeValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.TimeValue END AS TimeValue,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.DurationTicks END AS DurationTicks,
  CASE WHEN r.StatusCode IS NOT NULL THEN r.TypedTextValue END AS TypedTextValue,
  ISNULL(r.StatusCode,11) AS StatusCode
 FROM toolbelt_file.TVF_InternalInterpretXlsxCell
  (@StoredType,@ValuePresent,@RawValue,@TextValue,@TargetType,@FormatCode,@Date1904) AS r;
GO
/*
Interner Statusrow-Provider für USP_ListXlsxWorksheets; keine öffentliche Neben-API.
Dependency Toolbelt_File_XlsxMemory 1.0.0 und Toolbelt_Archive_ZipMemory 1.4.0.
SAFE, DataAccess/SystemDataAccess None. Vollständige Materialisierung vor Rows.
Erwartete Inputfehler: eine ErrorNumber/ErrorMessage-Zeile; unerwartete CLR-Fehler
bleiben Originalfehler. Keine Dateisystem- oder Netzwerkzugriffe.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE FUNCTION toolbelt_file.TVF_InternalXlsxSheets
(
    @XlsxBinary varbinary(max),
    @MaxArchiveBytes bigint,
    @MaxPartBytes bigint,
    @MaxTotalUncompressedBytes bigint,
    @MaxParts int,
    @MaxSheets int,
    @MaxCells int,
    @MaxSharedStrings int,
    @MaxSharedStringBytes bigint,
    @MaxXmlDepth int,
    @MaxCompressionRatio decimal(18,4),
    @BudgetMilliseconds int
)
RETURNS TABLE
(
    ErrorNumber int NULL, ErrorMessage nvarchar(4000) NULL,
    SheetOrdinal int NULL,
    SheetName nvarchar(max) NULL,
    Visibility nvarchar(16) NULL,
    Date1904 bit NULL
)
AS EXTERNAL NAME [Toolbelt_File_XlsxMemory].[Toolbelt.Xlsx.Qualification.XlsxEntryPoints].[ListSheets];
GO
/*
Interner Statusrow-Provider für USP_ReadXlsxWorksheetCells; keine öffentliche Neben-API.
Dependency Toolbelt_File_XlsxMemory 1.0.0 und Toolbelt_Archive_ZipMemory 1.4.0.
SAFE, DataAccess/SystemDataAccess None. Vollständige Materialisierung vor Rows.
Erwartete Inputfehler: eine ErrorNumber/ErrorMessage-Zeile; unerwartete CLR-Fehler
bleiben Originalfehler. Keine Dateisystem- oder Netzwerkzugriffe.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE FUNCTION toolbelt_file.TVF_InternalXlsxCells
(
    @XlsxBinary varbinary(max),
    @SheetOrdinal int,
    @MaxArchiveBytes bigint,
    @MaxPartBytes bigint,
    @MaxTotalUncompressedBytes bigint,
    @MaxParts int,
    @MaxSheets int,
    @MaxCells int,
    @MaxSharedStrings int,
    @MaxSharedStringBytes bigint,
    @MaxXmlDepth int,
    @MaxCompressionRatio decimal(18,4),
    @BudgetMilliseconds int
)
RETURNS TABLE
(
    ErrorNumber int NULL, ErrorMessage nvarchar(4000) NULL,
    RowOrdinal int NULL,
    ColumnOrdinal int NULL,
    StoredType nvarchar(16) NULL,
    ValuePresent bit NULL,
    RawValue nvarchar(max) NULL,
    TextValue nvarchar(max) NULL,
    FormulaPresent bit NULL,
    FormulaText nvarchar(max) NULL,
    FormulaKind nvarchar(16) NULL,
    SharedFormulaIndex int NULL,
    CachePresent bit NULL,
    CacheValue nvarchar(max) NULL
)
AS EXTERNAL NAME [Toolbelt_File_XlsxMemory].[Toolbelt.Xlsx.Qualification.XlsxEntryPoints].[ReadCells];
GO
/*
Interne Compiler-/Routinggrenze der beiden öffentlichen XLSX-USPs.
Kein zusätzlicher öffentlicher Funktionsvertrag. Dependency: SAFE Status-TVFs
und ResultTable-Helper. Reservierte Tempnamen prüft der öffentliche Wrapper
vor EXEC; hier erfolgt die erste Kompilierung der fachlichen Tempstatements.
Erwartete Inputfehler vor Mutation; eigene Transaktion oder Caller-Savepoint.
Direkter Aufruf ist intern, keine Grant-Zusage.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE toolbelt_file.USP_InternalXlsxRead
(
    @ReadCells bit = NULL,
    @XlsxBinary varbinary(max) = NULL,
    @SheetOrdinal int = NULL,
    @MaxArchiveBytes bigint = 16777216,
    @MaxPartBytes bigint = 16777216,
    @MaxTotalUncompressedBytes bigint = 67108864,
    @MaxParts int = 256,
    @MaxSheets int = 32,
    @MaxCells int = 100000,
    @MaxSharedStrings int = 50000,
    @MaxSharedStringBytes bigint = 8388608,
    @MaxXmlDepth int = 64,
    @MaxCompressionRatio decimal(18,4) = 200,
    @BudgetMilliseconds int = 5000,
    @ResultTable sysname = NULL,
    @KeepData bit = 0,
    @Debug tinyint = 0,
    @Hilfe bit = 0
)
AS
BEGIN
    SET NOCOUNT ON;
    IF @Hilfe=1
    BEGIN
        DECLARE @Help TABLE
        (HelpContractVersion varchar(16) NOT NULL DEFAULT '1.0',
         SchemaName sysname NOT NULL DEFAULT N'toolbelt_file',
         ObjectName sysname NOT NULL DEFAULT N'USP_InternalXlsxRead',
         Section varchar(32) NOT NULL, Ordinal int NOT NULL, ItemName sysname NULL,
         SqlDataType varchar(256) NULL, IsRequired bit NULL, IsNullable bit NULL,
         DefaultValue nvarchar(4000) NULL, Description nvarchar(max) NOT NULL, ExampleSql nvarchar(max) NULL);
        INSERT @Help (Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql) VALUES
        ('PARAMETER',1,N'@ReadCells','bit',1,0,N'NULL',N'Interner Modus: 0 Sheetliste, 1 Zellliste; öffentliche USPs bevorzugen.',NULL),
        ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'Begrenzter SAFE Binary-XLSX-Reader; atomarer gewählter Snapshot, keine Datei-/Netzwerkzugriffe, Formelberechnung oder Typinferenz.',NULL),
        ('PARAMETER',2,N'@XlsxBinary','varbinary(max)',0,1,N'NULL',N'NULL liefert keine Zeilen und verändert kein ResultTable.',NULL),
        ('PARAMETER',3,N'@SheetOrdinal','int',1,0,N'NULL',N'Positive Worksheetposition aus ListXlsxWorksheets.',NULL),
        ('PARAMETER',4,N'@MaxArchiveBytes','bigint',0,0,N'16777216',N'Containerbytes, höchstens 16 MiB.',NULL),
        ('PARAMETER',5,N'@MaxPartBytes','bigint',0,0,N'16777216',N'Unkomprimierte Bytes je Part, höchstens 16 MiB.',NULL),
        ('PARAMETER',6,N'@MaxTotalUncompressedBytes','bigint',0,0,N'67108864',N'Deklarierte Gesamtbytes, höchstens 64 MiB.',NULL),
        ('PARAMETER',7,N'@MaxParts','int',0,0,N'256',N'ZIP-Parts, höchstens 256.',NULL),
        ('PARAMETER',8,N'@MaxSheets','int',0,0,N'32',N'Worksheets, höchstens 32.',NULL),
        ('PARAMETER',9,N'@MaxCells','int',0,0,N'100000',N'Vorhandene Zellen im gewählten Sheet, höchstens 100000.',NULL),
        ('PARAMETER',10,N'@MaxSharedStrings','int',0,0,N'50000',N'Shared Strings, höchstens 50000.',NULL),
        ('PARAMETER',11,N'@MaxSharedStringBytes','bigint',0,0,N'8388608',N'Dekodierter Shared-String-UTF16-Text, höchstens 8 MiB.',NULL),
        ('PARAMETER',12,N'@MaxXmlDepth','int',0,0,N'64',N'XML-Tiefe, höchstens 64.',NULL),
        ('PARAMETER',13,N'@MaxCompressionRatio','decimal(18,4)',0,0,N'200',N'Maximales deklarierter Ratio, höchstens 200.',NULL),
        ('PARAMETER',14,N'@BudgetMilliseconds','int',0,0,N'5000',N'Kooperatives Gesamtbudget, höchstens 5000 ms; keine harte Wallclockzusage.',NULL),
        ('PARAMETER',15,N'@ResultTable','sysname',0,1,N'NULL',N'Vorhandene caller-lokale Temp-Tabelle, sonst SELECT.',NULL),
        ('PARAMETER',16,N'@KeepData','bit',0,1,N'0',N'Replace 0 oder Append 1; NULL entspricht 0.',NULL),
        ('PARAMETER',17,N'@Debug','tinyint',0,1,N'0',N'Nur Messages ohne Workbookinhalte.',NULL),
        ('PARAMETER',18,N'@Hilfe','bit',0,1,N'0',N'Ausschließlich standardisierte Hilfe.',NULL),
        ('RESULT_COLUMN',1,N'RowOrdinal','int',1,0,NULL,N'Einsbasierte Zeile.',NULL),
        ('RESULT_COLUMN',2,N'ColumnOrdinal','int',1,0,NULL,N'Einsbasierte Spalte.',NULL),
        ('RESULT_COLUMN',3,N'StoredType','nvarchar(16)',1,0,NULL,N'Gespeicherter Zelltyp, keine Typinferenz.',NULL),
        ('RESULT_COLUMN',4,N'ValuePresent','bit',1,0,NULL,N'Gespeichertes v-Element vorhanden, auch wenn leer.',NULL),
        ('RESULT_COLUMN',5,N'RawValue','nvarchar(max)',1,1,NULL,N'Rohtext aus v, NULL bei fehlendem v.',NULL),
        ('RESULT_COLUMN',6,N'TextValue','nvarchar(max)',1,1,NULL,N'Shared-/Inline-/str-Text, kein Excel-Anzeigeformat.',NULL),
        ('RESULT_COLUMN',7,N'FormulaPresent','bit',1,0,NULL,N'f-Element vorhanden.',NULL),
        ('RESULT_COLUMN',8,N'FormulaText','nvarchar(max)',1,1,NULL,N'Unveränderter Formeltext, keine Berechnung.',NULL),
        ('RESULT_COLUMN',9,N'FormulaKind','nvarchar(16)',1,1,NULL,N'normal, shared, array oder dataTable.',NULL),
        ('RESULT_COLUMN',10,N'SharedFormulaIndex','int',1,1,NULL,N'Gespeichertes si, keine Formelrekonstruktion.',NULL),
        ('RESULT_COLUMN',11,N'CachePresent','bit',1,0,NULL,N'Formel und v-Element vorhanden.',NULL),
        ('RESULT_COLUMN',12,N'CacheValue','nvarchar(max)',1,1,NULL,N'Gespeicherter Formelcache-Rohtext.',NULL),
        ('ERROR',1,N'51520',NULL,NULL,NULL,NULL,N'Begrenzte Kategorie eines erwarteten Input-/Container-/XML-/Feature-/Ressourcenfehlers; keine Teilausgabe.',NULL),
        ('ERROR',2,N'51529',NULL,NULL,NULL,NULL,N'Fehlende oder inkonsistente registrierte Dependency bzw. interner Providervertrag.',NULL),
        ('PERMISSION',1,NULL,NULL,NULL,NULL,NULL,N'EXECUTE auf USP; ResultTable zusätzlich Helper-EXECUTE und Sichtbarkeit der caller-lokalen Tabelle. Keine Rechteausweitung.',NULL),
        ('LIMITATION',1,NULL,NULL,NULL,NULL,NULL,N'Transitional XLSX, klassische Stored-/Deflate-ZIPs. Kein ZIP64, externe Beziehungen, Makros oder Strict Open XML. Unicode bleibt unverändert, Tabellen brauchen explizite Ordinals zum Sortieren.',NULL),
        ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Hilfe ohne fachliche Eingaben.',N'EXEC toolbelt_file.USP_ReadXlsxWorksheetCells @Hilfe=1;');
        -- Technische Hilfe benennt die tatsächliche Modus-0-Resultshape;
        -- ohne expliziten Modus bleibt die dokumentierte Zellshape sichtbar.
        IF @ReadCells=0
        BEGIN
            DELETE FROM @Help WHERE Section='RESULT_COLUMN';
            UPDATE @Help SET IsRequired=0,IsNullable=1,
                Description=N'Für den Sheetlistenmodus nicht verwendet.'
                WHERE Section='PARAMETER' AND ItemName=N'@SheetOrdinal';
            INSERT @Help (Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql) VALUES
            ('RESULT_COLUMN',1,N'SheetOrdinal','int',1,0,NULL,N'Einsbasierte Worksheetposition.',NULL),
            ('RESULT_COLUMN',2,N'SheetName','nvarchar(max)',1,0,NULL,N'Unveränderter Worksheetname.',NULL),
            ('RESULT_COLUMN',3,N'Visibility','nvarchar(16)',1,0,NULL,N'visible, hidden oder veryHidden.',NULL),
            ('RESULT_COLUMN',4,N'Date1904','bit',1,0,NULL,N'Gespeichertes Workbook-Datumssystem.',NULL);
        END;
        SELECT HelpContractVersion,SchemaName,ObjectName,
               Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql
        FROM @Help ORDER BY CASE Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2
           WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 WHEN 'PERMISSION' THEN 5
           WHEN 'LIMITATION' THEN 6 ELSE 7 END,Ordinal;
        RETURN 0;
    END;
    SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0);
    IF @ReadCells IS NULL THROW 51529,N'Interner XLSX-Routingmodus fehlt.',1;
    IF @ReadCells=0
    BEGIN
    CREATE TABLE #tbx_ListXlsxWorksheets_ResultSource
    (
        [SheetOrdinal] int NOT NULL,
        [SheetName] nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL,
        [Visibility] nvarchar(16) COLLATE Latin1_General_100_BIN2 NOT NULL,
        [Date1904] bit NOT NULL
    );
    IF @XlsxBinary IS NULL
    BEGIN
        IF @ResultTable IS NULL SELECT [SheetOrdinal],[SheetName],[Visibility],[Date1904] FROM #tbx_ListXlsxWorksheets_ResultSource;
        RETURN 0;
    END;
    IF OBJECT_ID(N'toolbelt_file.TVF_InternalXlsxSheets',N'FT') IS NULL
        THROW 51529,N'Der interne XLSX-Provider fehlt.',1;
    DECLARE @SheetsSnapshot TABLE
    (ErrorNumber int NULL, ErrorMessage nvarchar(4000) NULL,
        [SheetOrdinal] int NULL,
        [SheetName] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [Visibility] nvarchar(16) COLLATE Latin1_General_100_BIN2 NULL,
        [Date1904] bit NULL
    );
    INSERT @SheetsSnapshot SELECT ErrorNumber,ErrorMessage,[SheetOrdinal],[SheetName],[Visibility],[Date1904]
    FROM toolbelt_file.TVF_InternalXlsxSheets(@XlsxBinary,@MaxArchiveBytes,@MaxPartBytes,@MaxTotalUncompressedBytes,@MaxParts,@MaxSheets,@MaxCells,@MaxSharedStrings,@MaxSharedStringBytes,@MaxXmlDepth,@MaxCompressionRatio,@BudgetMilliseconds);
    IF EXISTS(SELECT 1 FROM @SheetsSnapshot WHERE ErrorNumber IS NOT NULL)
    BEGIN
        IF (SELECT COUNT_BIG(*) FROM @SheetsSnapshot)<>1
            THROW 51529,N'Inkonsistenter XLSX-Statusvertrag.',1;
        DECLARE @SheetsError int,@SheetsMessage nvarchar(2048);
        SELECT @SheetsError=ErrorNumber,@SheetsMessage=CONVERT(nvarchar(2048),ErrorMessage) FROM @SheetsSnapshot;
        IF @SheetsError<>51520 OR @SheetsMessage IS NULL
            THROW 51529,N'Ungültiger XLSX-Statusvertrag.',1;
        THROW @SheetsError,@SheetsMessage,1;
    END;
    IF EXISTS(SELECT 1 FROM @SheetsSnapshot WHERE [SheetOrdinal] IS NULL OR [SheetName] IS NULL OR [Visibility] IS NULL OR [Date1904] IS NULL)
        THROW 51529,N'Unvollständige XLSX-Datenzeile.',1;
    INSERT #tbx_ListXlsxWorksheets_ResultSource([SheetOrdinal],[SheetName],[Visibility],[Date1904]) SELECT [SheetOrdinal],[SheetName],[Visibility],[Date1904] FROM @SheetsSnapshot;
    IF @Debug>0 RAISERROR(N'XLSX: validierter Ergebnissnapshot bereit.',10,1) WITH NOWAIT;
    IF @ResultTable IS NULL
    BEGIN
        SELECT [SheetOrdinal],[SheetName],[Visibility],[Date1904] FROM #tbx_ListXlsxWorksheets_ResultSource ORDER BY SheetOrdinal;
        RETURN 0;
    END;
    DECLARE @SheetsDependencyVersion nvarchar(64),@SheetsDependencyId int=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P');
    SELECT @SheetsDependencyVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties
    WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
    DECLARE @SheetsMajor int=TRY_CONVERT(int,PARSENAME(@SheetsDependencyVersion,3)),
            @SheetsMinor int=TRY_CONVERT(int,PARSENAME(@SheetsDependencyVersion,2)),
            @SheetsPatch int=TRY_CONVERT(int,PARSENAME(@SheetsDependencyVersion,1));
    IF @SheetsDependencyId IS NULL OR @SheetsMajor IS NULL OR @SheetsMajor<1 OR @SheetsMinor IS NULL OR @SheetsMinor<0 OR @SheetsPatch IS NULL OR @SheetsPatch<0
       OR CONVERT(varbinary(max),@SheetsDependencyVersion)<>CONVERT(varbinary(max),CONCAT(@SheetsMajor,N'.',@SheetsMinor,N'.',@SheetsPatch))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@SheetsDependencyId AND minor_id=0
           AND name=N'Toolbelt.ModuleId' AND TRY_CONVERT(nvarchar(128),value)=N'toolbelt.core.result-table')
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@SheetsDependencyId AND minor_id=0
           AND name=N'Toolbelt.ModuleVersion'
           AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@SheetsDependencyVersion))
        THROW 51529,N'ResultTable-Dependency >= 1.0.0 fehlt oder ist ungeeignet.',1;
    DECLARE @SheetsOwnTransaction bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,
            @SheetsSavepoint varchar(32)=REPLACE(CONVERT(varchar(36),NEWID()),'-',''),@SheetsSavepointSet bit=0;
    BEGIN TRY
        IF @SheetsOwnTransaction=1 BEGIN TRANSACTION;
        ELSE BEGIN SAVE TRANSACTION @SheetsSavepoint; SET @SheetsSavepointSet=1; END;
        EXEC toolbelt_core.USP_PrepareResultTable
             @ResultTableToAlter=@ResultTable,@LikeTable=N'#tbx_ListXlsxWorksheets_ResultSource',
             @KeepData=@KeepData,@Debug=@Debug;
        DECLARE @SheetsSql nvarchar(max)=N'INSERT INTO '+QUOTENAME(@ResultTable)
           +N' ([SheetOrdinal],[SheetName],[Visibility],[Date1904]) SELECT [SheetOrdinal],[SheetName],[Visibility],[Date1904] FROM #tbx_ListXlsxWorksheets_ResultSource;';
        EXEC sys.sp_executesql @SheetsSql;
        IF @SheetsOwnTransaction=1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @SheetsOwnTransaction=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
        ELSE IF @SheetsSavepointSet=1 AND XACT_STATE()=1 ROLLBACK TRANSACTION @SheetsSavepoint;
        THROW;
    END CATCH;
    RETURN 0;

    END
    ELSE
    BEGIN
    CREATE TABLE #tbx_ReadXlsxWorksheetCells_ResultSource
    (
        [RowOrdinal] int NOT NULL,
        [ColumnOrdinal] int NOT NULL,
        [StoredType] nvarchar(16) COLLATE Latin1_General_100_BIN2 NOT NULL,
        [ValuePresent] bit NOT NULL,
        [RawValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [TextValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [FormulaPresent] bit NOT NULL,
        [FormulaText] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [FormulaKind] nvarchar(16) COLLATE Latin1_General_100_BIN2 NULL,
        [SharedFormulaIndex] int NULL,
        [CachePresent] bit NOT NULL,
        [CacheValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL
    );
    IF @XlsxBinary IS NULL
    BEGIN
        IF @ResultTable IS NULL SELECT [RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue] FROM #tbx_ReadXlsxWorksheetCells_ResultSource;
        RETURN 0;
    END;
    IF OBJECT_ID(N'toolbelt_file.TVF_InternalXlsxCells',N'FT') IS NULL
        THROW 51529,N'Der interne XLSX-Provider fehlt.',1;
    DECLARE @CellsSnapshot TABLE
    (ErrorNumber int NULL, ErrorMessage nvarchar(4000) NULL,
        [RowOrdinal] int NULL,
        [ColumnOrdinal] int NULL,
        [StoredType] nvarchar(16) COLLATE Latin1_General_100_BIN2 NULL,
        [ValuePresent] bit NULL,
        [RawValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [TextValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [FormulaPresent] bit NULL,
        [FormulaText] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
        [FormulaKind] nvarchar(16) COLLATE Latin1_General_100_BIN2 NULL,
        [SharedFormulaIndex] int NULL,
        [CachePresent] bit NULL,
        [CacheValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL
    );
    INSERT @CellsSnapshot SELECT ErrorNumber,ErrorMessage,[RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue]
    FROM toolbelt_file.TVF_InternalXlsxCells(@XlsxBinary,@SheetOrdinal,@MaxArchiveBytes,@MaxPartBytes,@MaxTotalUncompressedBytes,@MaxParts,@MaxSheets,@MaxCells,@MaxSharedStrings,@MaxSharedStringBytes,@MaxXmlDepth,@MaxCompressionRatio,@BudgetMilliseconds);
    IF EXISTS(SELECT 1 FROM @CellsSnapshot WHERE ErrorNumber IS NOT NULL)
    BEGIN
        IF (SELECT COUNT_BIG(*) FROM @CellsSnapshot)<>1
            THROW 51529,N'Inkonsistenter XLSX-Statusvertrag.',1;
        DECLARE @CellsError int,@CellsMessage nvarchar(2048);
        SELECT @CellsError=ErrorNumber,@CellsMessage=CONVERT(nvarchar(2048),ErrorMessage) FROM @CellsSnapshot;
        IF @CellsError<>51520 OR @CellsMessage IS NULL
            THROW 51529,N'Ungültiger XLSX-Statusvertrag.',1;
        THROW @CellsError,@CellsMessage,1;
    END;
    IF EXISTS(SELECT 1 FROM @CellsSnapshot WHERE [RowOrdinal] IS NULL OR [ColumnOrdinal] IS NULL OR [StoredType] IS NULL OR [ValuePresent] IS NULL OR [FormulaPresent] IS NULL OR [CachePresent] IS NULL)
        THROW 51529,N'Unvollständige XLSX-Datenzeile.',1;
    INSERT #tbx_ReadXlsxWorksheetCells_ResultSource([RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue]) SELECT [RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue] FROM @CellsSnapshot;
    IF @Debug>0 RAISERROR(N'XLSX: validierter Ergebnissnapshot bereit.',10,1) WITH NOWAIT;
    IF @ResultTable IS NULL
    BEGIN
        SELECT [RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue] FROM #tbx_ReadXlsxWorksheetCells_ResultSource ORDER BY RowOrdinal,ColumnOrdinal;
        RETURN 0;
    END;
    DECLARE @CellsDependencyVersion nvarchar(64),@CellsDependencyId int=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P');
    SELECT @CellsDependencyVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties
    WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
    DECLARE @CellsMajor int=TRY_CONVERT(int,PARSENAME(@CellsDependencyVersion,3)),
            @CellsMinor int=TRY_CONVERT(int,PARSENAME(@CellsDependencyVersion,2)),
            @CellsPatch int=TRY_CONVERT(int,PARSENAME(@CellsDependencyVersion,1));
    IF @CellsDependencyId IS NULL OR @CellsMajor IS NULL OR @CellsMajor<1 OR @CellsMinor IS NULL OR @CellsMinor<0 OR @CellsPatch IS NULL OR @CellsPatch<0
       OR CONVERT(varbinary(max),@CellsDependencyVersion)<>CONVERT(varbinary(max),CONCAT(@CellsMajor,N'.',@CellsMinor,N'.',@CellsPatch))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@CellsDependencyId AND minor_id=0
           AND name=N'Toolbelt.ModuleId' AND TRY_CONVERT(nvarchar(128),value)=N'toolbelt.core.result-table')
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@CellsDependencyId AND minor_id=0
           AND name=N'Toolbelt.ModuleVersion'
           AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@CellsDependencyVersion))
        THROW 51529,N'ResultTable-Dependency >= 1.0.0 fehlt oder ist ungeeignet.',1;
    DECLARE @CellsOwnTransaction bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,
            @CellsSavepoint varchar(32)=REPLACE(CONVERT(varchar(36),NEWID()),'-',''),@CellsSavepointSet bit=0;
    BEGIN TRY
        IF @CellsOwnTransaction=1 BEGIN TRANSACTION;
        ELSE BEGIN SAVE TRANSACTION @CellsSavepoint; SET @CellsSavepointSet=1; END;
        EXEC toolbelt_core.USP_PrepareResultTable
             @ResultTableToAlter=@ResultTable,@LikeTable=N'#tbx_ReadXlsxWorksheetCells_ResultSource',
             @KeepData=@KeepData,@Debug=@Debug;
        DECLARE @CellsSql nvarchar(max)=N'INSERT INTO '+QUOTENAME(@ResultTable)
           +N' ([RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue]) SELECT [RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue] FROM #tbx_ReadXlsxWorksheetCells_ResultSource;';
        EXEC sys.sp_executesql @CellsSql;
        IF @CellsOwnTransaction=1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @CellsOwnTransaction=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
        ELSE IF @CellsSavepointSet=1 AND XACT_STATE()=1 ROLLBACK TRANSACTION @CellsSavepoint;
        THROW;
    END CATCH;
    RETURN 0;

    END;
END;
GO
-- ============================================================================
-- Objekt: toolbelt_file.USP_ListXlsxWorksheets
-- Typ: Stored Procedure
-- Zweck: Worksheetliste mit Workbook-Reihenfolge, Visibility und Date1904.
-- Vertrag: USP_CONTRACT 1.0; Documentation/USP_ListXlsxWorksheets.md
-- Parameter: @XlsxBinary varbinary(max)=NULL;
--   @MaxArchiveBytes bigint=16777216; @MaxPartBytes bigint=16777216;
--   @MaxTotalUncompressedBytes bigint=67108864; @MaxParts int=256;
--   @MaxSheets int=32; @MaxCells int=100000; @MaxSharedStrings int=50000;
--   @MaxSharedStringBytes bigint=8388608; @MaxXmlDepth int=64;
--   @MaxCompressionRatio decimal(18,4)=200; @BudgetMilliseconds int=5000;
--   @ResultTable sysname=NULL; @KeepData bit=0; @Debug tinyint=0; @Hilfe bit=0.
-- Resultset: SheetOrdinal int, SheetName nvarchar(max), Visibility nvarchar(16), Date1904 bit;
--   alle Spalten NOT NULL.
-- Dependencies: toolbelt.file.xlsx-memory 1.0.0 / SAFE CLR;
--   toolbelt.archive.zip-memory >=1.4.0; ResultTable-Helper >=1.0.0.
-- Rechte: EXECUTE auf USP; bei ResultTable zusätzlich Helper-EXECUTE.
-- Versionen: SQL Server 2019, 2022, 2025. Plattformen: Windows/Linux, SAFE CLR.
-- Fehlerverhalten: 51520 erwarteter Parser-/Input-/Limitfehler, 51529 Provider-/Dependencyfehler.
--   Keine Teilausgabe; Mutationsscope eigene Transaktion oder Caller-Savepoint.
--   Uncommittable Caller wird nicht zurückgerollt; ursprüngliche Enginefehler bleiben erhalten.
-- Performance: Input/Parts/gewählter Output werden materialisiert, keine Streaming- oder
--   SQL-Memory-Grant-Zusage. Reduzierbare Limits, kooperatives Budget, keine harte Wallclock.
-- Einschränkungen: Transitional XLSX, keine externen Beziehungen/ZIP64/Makros/Dateizugriffe,
--   Styles-/Datums-/Cultureinferenz oder Formelberechnung. NULL-Binary ist früher No-op.
-- ============================================================================
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE toolbelt_file.USP_ListXlsxWorksheets
(
    @XlsxBinary varbinary(max) = NULL,
    @MaxArchiveBytes bigint = 16777216,
    @MaxPartBytes bigint = 16777216,
    @MaxTotalUncompressedBytes bigint = 67108864,
    @MaxParts int = 256,
    @MaxSheets int = 32,
    @MaxCells int = 100000,
    @MaxSharedStrings int = 50000,
    @MaxSharedStringBytes bigint = 8388608,
    @MaxXmlDepth int = 64,
    @MaxCompressionRatio decimal(18,4) = 200,
    @BudgetMilliseconds int = 5000,
    @ResultTable sysname = NULL,
    @KeepData bit = 0,
    @Debug tinyint = 0,
    @Hilfe bit = 0
)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0),@Hilfe=COALESCE(@Hilfe,0);
    IF @Hilfe=1
    BEGIN
        DECLARE @Help TABLE
        (Section varchar(32) NOT NULL, Ordinal int NOT NULL, ItemName sysname NULL,
         SqlDataType varchar(256) NULL, IsRequired bit NULL, IsNullable bit NULL,
         DefaultValue nvarchar(4000) NULL, Description nvarchar(max) NOT NULL, ExampleSql nvarchar(max) NULL);
        INSERT @Help VALUES
        ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'Begrenzter SAFE Binary-XLSX-Reader; atomarer gewählter Snapshot, keine Datei-/Netzwerkzugriffe, Formelberechnung oder Typinferenz.',NULL),
        ('PARAMETER',1,N'@XlsxBinary','varbinary(max)',0,1,N'NULL',N'NULL liefert keine Zeilen und verändert kein ResultTable.',NULL),
        ('PARAMETER',2,N'@MaxArchiveBytes','bigint',0,0,N'16777216',N'Containerbytes, höchstens 16 MiB.',NULL),
        ('PARAMETER',3,N'@MaxPartBytes','bigint',0,0,N'16777216',N'Unkomprimierte Bytes je Part, höchstens 16 MiB.',NULL),
        ('PARAMETER',4,N'@MaxTotalUncompressedBytes','bigint',0,0,N'67108864',N'Deklarierte Gesamtbytes, höchstens 64 MiB.',NULL),
        ('PARAMETER',5,N'@MaxParts','int',0,0,N'256',N'ZIP-Parts, höchstens 256.',NULL),
        ('PARAMETER',6,N'@MaxSheets','int',0,0,N'32',N'Worksheets, höchstens 32.',NULL),
        ('PARAMETER',7,N'@MaxCells','int',0,0,N'100000',N'Vorhandene Zellen im gewählten Sheet, höchstens 100000.',NULL),
        ('PARAMETER',8,N'@MaxSharedStrings','int',0,0,N'50000',N'Shared Strings, höchstens 50000.',NULL),
        ('PARAMETER',9,N'@MaxSharedStringBytes','bigint',0,0,N'8388608',N'Dekodierter Shared-String-UTF16-Text, höchstens 8 MiB.',NULL),
        ('PARAMETER',10,N'@MaxXmlDepth','int',0,0,N'64',N'XML-Tiefe, höchstens 64.',NULL),
        ('PARAMETER',11,N'@MaxCompressionRatio','decimal(18,4)',0,0,N'200',N'Maximales deklarierter Ratio, höchstens 200.',NULL),
        ('PARAMETER',12,N'@BudgetMilliseconds','int',0,0,N'5000',N'Kooperatives Gesamtbudget, höchstens 5000 ms; keine harte Wallclockzusage.',NULL),
        ('PARAMETER',13,N'@ResultTable','sysname',0,1,N'NULL',N'Vorhandene caller-lokale Temp-Tabelle, sonst SELECT.',NULL),
        ('PARAMETER',14,N'@KeepData','bit',0,1,N'0',N'Replace 0 oder Append 1; NULL entspricht 0.',NULL),
        ('PARAMETER',15,N'@Debug','tinyint',0,1,N'0',N'Nur Messages ohne Workbookinhalte.',NULL),
        ('PARAMETER',16,N'@Hilfe','bit',0,1,N'0',N'Ausschließlich standardisierte Hilfe.',NULL),
        ('RESULT_COLUMN',1,N'SheetOrdinal','int',1,0,NULL,N'Einsbasierte Workbook-Reihenfolge.',NULL),
        ('RESULT_COLUMN',2,N'SheetName','nvarchar(max)',1,0,NULL,N'Unveränderter Worksheetname.',NULL),
        ('RESULT_COLUMN',3,N'Visibility','nvarchar(16)',1,0,NULL,N'visible, hidden oder veryHidden.',NULL),
        ('RESULT_COLUMN',4,N'Date1904','bit',1,0,NULL,N'Workbook-Datumsmodus; keine Datumsumrechnung.',NULL),
        ('ERROR',1,N'51520',NULL,NULL,NULL,NULL,N'Begrenzte Kategorie eines erwarteten Input-/Container-/XML-/Feature-/Ressourcenfehlers; keine Teilausgabe.',NULL),
        ('ERROR',2,N'51529',NULL,NULL,NULL,NULL,N'Fehlende oder inkonsistente registrierte Dependency bzw. interner Providervertrag.',NULL),
        ('PERMISSION',1,NULL,NULL,NULL,NULL,NULL,N'EXECUTE auf USP; ResultTable zusätzlich Helper-EXECUTE und Sichtbarkeit der caller-lokalen Tabelle. Keine Rechteausweitung.',NULL),
        ('LIMITATION',1,NULL,NULL,NULL,NULL,NULL,N'Transitional XLSX, klassische Stored-/Deflate-ZIPs. Kein ZIP64, externe Beziehungen, Makros oder Strict Open XML. Unicode bleibt unverändert, Tabellen brauchen explizite Ordinals zum Sortieren.',NULL),
        ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Hilfe ohne fachliche Eingaben.',N'EXEC toolbelt_file.USP_ListXlsxWorksheets @Hilfe=1;');
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
               CAST(N'toolbelt_file' AS sysname) AS SchemaName,
               CAST(N'USP_ListXlsxWorksheets' AS sysname) AS ObjectName,
               Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql
        FROM @Help ORDER BY CASE Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2
           WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 WHEN 'PERMISSION' THEN 5
           WHEN 'LIMITATION' THEN 6 ELSE 7 END,Ordinal;
        RETURN 0;
    END;
    -- NULL und Namespaceprüfung liegen vor der separaten Compilergrenze.
    IF @XlsxBinary IS NULL
    BEGIN
        -- Tablevariable hält auch bei null Zeilen die genaue Result-Nullability;
        -- keine private Temptabelle oder fachliche Core-Kompilierung entsteht.
        DECLARE @Empty TABLE ([SheetOrdinal] int NOT NULL,[SheetName] nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL,[Visibility] nvarchar(16) COLLATE Latin1_General_100_BIN2 NOT NULL,[Date1904] bit NOT NULL);
        IF @ResultTable IS NULL SELECT [SheetOrdinal],[SheetName],[Visibility],[Date1904] FROM @Empty;
        RETURN 0;
    END;
    IF (@ResultTable IS NOT NULL AND LOWER(LEFT(@ResultTable COLLATE Latin1_General_100_BIN2,5))=N'#tbx_')
       OR OBJECT_ID(N'tempdb..#tbx_ListXlsxWorksheets_ResultSource') IS NOT NULL
       OR OBJECT_ID(N'tempdb..#tbx_ReadXlsxWorksheetCells_ResultSource') IS NOT NULL
        THROW 51520,N'Reservierter interner XLSX-Tempnamensbereich.',1;
    -- Fachliche Tempstatements werden erst hinter dieser EXEC-Grenze kompiliert.
    EXEC toolbelt_file.USP_InternalXlsxRead @ReadCells=0,
         @XlsxBinary=@XlsxBinary,
         @MaxArchiveBytes=@MaxArchiveBytes,
         @MaxPartBytes=@MaxPartBytes,
         @MaxTotalUncompressedBytes=@MaxTotalUncompressedBytes,
         @MaxParts=@MaxParts,
         @MaxSheets=@MaxSheets,
         @MaxCells=@MaxCells,
         @MaxSharedStrings=@MaxSharedStrings,
         @MaxSharedStringBytes=@MaxSharedStringBytes,
         @MaxXmlDepth=@MaxXmlDepth,
         @MaxCompressionRatio=@MaxCompressionRatio,
         @BudgetMilliseconds=@BudgetMilliseconds,
         @ResultTable=@ResultTable,
         @KeepData=@KeepData,
         @Debug=@Debug,@SheetOrdinal=NULL;
    RETURN 0;
END;
GO
-- ============================================================================
-- Objekt: toolbelt_file.USP_ReadXlsxWorksheetCells
-- Typ: Stored Procedure
-- Zweck: Sparse vorhandene Zellen mit Rohtext, aufgelöstem Stringtext, Formel und Cache.
-- Vertrag: USP_CONTRACT 1.0; Documentation/USP_ReadXlsxWorksheetCells.md
-- Parameter: @XlsxBinary varbinary(max)=NULL, @SheetOrdinal int=NULL;
--   @MaxArchiveBytes bigint=16777216; @MaxPartBytes bigint=16777216;
--   @MaxTotalUncompressedBytes bigint=67108864; @MaxParts int=256;
--   @MaxSheets int=32; @MaxCells int=100000; @MaxSharedStrings int=50000;
--   @MaxSharedStringBytes bigint=8388608; @MaxXmlDepth int=64;
--   @MaxCompressionRatio decimal(18,4)=200; @BudgetMilliseconds int=5000;
--   @ResultTable sysname=NULL; @KeepData bit=0; @Debug tinyint=0; @Hilfe bit=0.
-- Resultset: RowOrdinal int, ColumnOrdinal int, StoredType nvarchar(16), ValuePresent bit,
--   RawValue/TextValue nvarchar(max) NULL, FormulaPresent bit, FormulaText nvarchar(max) NULL,
--   FormulaKind nvarchar(16) NULL, SharedFormulaIndex int NULL, CachePresent bit,
--   CacheValue nvarchar(max) NULL; übrige Spalten NOT NULL.
-- Dependencies: toolbelt.file.xlsx-memory 1.0.0 / SAFE CLR;
--   toolbelt.archive.zip-memory >=1.4.0; ResultTable-Helper >=1.0.0.
-- Rechte: EXECUTE auf USP; bei ResultTable zusätzlich Helper-EXECUTE.
-- Versionen: SQL Server 2019, 2022, 2025. Plattformen: Windows/Linux, SAFE CLR.
-- Fehlerverhalten: 51520 erwarteter Parser-/Input-/Limitfehler, 51529 Provider-/Dependencyfehler.
--   Keine Teilausgabe; Mutationsscope eigene Transaktion oder Caller-Savepoint.
--   Uncommittable Caller wird nicht zurückgerollt; ursprüngliche Enginefehler bleiben erhalten.
-- Performance: Input/Parts/gewählter Output werden materialisiert, keine Streaming- oder
--   SQL-Memory-Grant-Zusage. Reduzierbare Limits, kooperatives Budget, keine harte Wallclock.
-- Einschränkungen: Transitional XLSX, keine externen Beziehungen/ZIP64/Makros/Dateizugriffe,
--   Styles-/Datums-/Cultureinferenz oder Formelberechnung. NULL-Binary ist früher No-op.
-- ============================================================================
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE toolbelt_file.USP_ReadXlsxWorksheetCells
(
    @XlsxBinary varbinary(max) = NULL,
    @SheetOrdinal int = NULL,
    @MaxArchiveBytes bigint = 16777216,
    @MaxPartBytes bigint = 16777216,
    @MaxTotalUncompressedBytes bigint = 67108864,
    @MaxParts int = 256,
    @MaxSheets int = 32,
    @MaxCells int = 100000,
    @MaxSharedStrings int = 50000,
    @MaxSharedStringBytes bigint = 8388608,
    @MaxXmlDepth int = 64,
    @MaxCompressionRatio decimal(18,4) = 200,
    @BudgetMilliseconds int = 5000,
    @ResultTable sysname = NULL,
    @KeepData bit = 0,
    @Debug tinyint = 0,
    @Hilfe bit = 0
)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT @KeepData=COALESCE(@KeepData,0),@Debug=COALESCE(@Debug,0),@Hilfe=COALESCE(@Hilfe,0);
    IF @Hilfe=1
    BEGIN
        DECLARE @Help TABLE
        (Section varchar(32) NOT NULL, Ordinal int NOT NULL, ItemName sysname NULL,
         SqlDataType varchar(256) NULL, IsRequired bit NULL, IsNullable bit NULL,
         DefaultValue nvarchar(4000) NULL, Description nvarchar(max) NOT NULL, ExampleSql nvarchar(max) NULL);
        INSERT @Help VALUES
        ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'Begrenzter SAFE Binary-XLSX-Reader; atomarer gewählter Snapshot, keine Datei-/Netzwerkzugriffe, Formelberechnung oder Typinferenz.',NULL),
        ('PARAMETER',1,N'@XlsxBinary','varbinary(max)',0,1,N'NULL',N'NULL liefert keine Zeilen und verändert kein ResultTable.',NULL),
        ('PARAMETER',2,N'@SheetOrdinal','int',1,0,N'NULL',N'Positive Worksheetposition aus ListXlsxWorksheets.',NULL),
        ('PARAMETER',3,N'@MaxArchiveBytes','bigint',0,0,N'16777216',N'Containerbytes, höchstens 16 MiB.',NULL),
        ('PARAMETER',4,N'@MaxPartBytes','bigint',0,0,N'16777216',N'Unkomprimierte Bytes je Part, höchstens 16 MiB.',NULL),
        ('PARAMETER',5,N'@MaxTotalUncompressedBytes','bigint',0,0,N'67108864',N'Deklarierte Gesamtbytes, höchstens 64 MiB.',NULL),
        ('PARAMETER',6,N'@MaxParts','int',0,0,N'256',N'ZIP-Parts, höchstens 256.',NULL),
        ('PARAMETER',7,N'@MaxSheets','int',0,0,N'32',N'Worksheets, höchstens 32.',NULL),
        ('PARAMETER',8,N'@MaxCells','int',0,0,N'100000',N'Vorhandene Zellen im gewählten Sheet, höchstens 100000.',NULL),
        ('PARAMETER',9,N'@MaxSharedStrings','int',0,0,N'50000',N'Shared Strings, höchstens 50000.',NULL),
        ('PARAMETER',10,N'@MaxSharedStringBytes','bigint',0,0,N'8388608',N'Dekodierter Shared-String-UTF16-Text, höchstens 8 MiB.',NULL),
        ('PARAMETER',11,N'@MaxXmlDepth','int',0,0,N'64',N'XML-Tiefe, höchstens 64.',NULL),
        ('PARAMETER',12,N'@MaxCompressionRatio','decimal(18,4)',0,0,N'200',N'Maximales deklarierter Ratio, höchstens 200.',NULL),
        ('PARAMETER',13,N'@BudgetMilliseconds','int',0,0,N'5000',N'Kooperatives Gesamtbudget, höchstens 5000 ms; keine harte Wallclockzusage.',NULL),
        ('PARAMETER',14,N'@ResultTable','sysname',0,1,N'NULL',N'Vorhandene caller-lokale Temp-Tabelle, sonst SELECT.',NULL),
        ('PARAMETER',15,N'@KeepData','bit',0,1,N'0',N'Replace 0 oder Append 1; NULL entspricht 0.',NULL),
        ('PARAMETER',16,N'@Debug','tinyint',0,1,N'0',N'Nur Messages ohne Workbookinhalte.',NULL),
        ('PARAMETER',17,N'@Hilfe','bit',0,1,N'0',N'Ausschließlich standardisierte Hilfe.',NULL),
        ('RESULT_COLUMN',1,N'RowOrdinal','int',1,0,NULL,N'Einsbasierte Zeile.',NULL),
        ('RESULT_COLUMN',2,N'ColumnOrdinal','int',1,0,NULL,N'Einsbasierte Spalte.',NULL),
        ('RESULT_COLUMN',3,N'StoredType','nvarchar(16)',1,0,NULL,N'Gespeicherter Zelltyp, keine Typinferenz.',NULL),
        ('RESULT_COLUMN',4,N'ValuePresent','bit',1,0,NULL,N'Gespeichertes v-Element vorhanden, auch wenn leer.',NULL),
        ('RESULT_COLUMN',5,N'RawValue','nvarchar(max)',1,1,NULL,N'Rohtext aus v, NULL bei fehlendem v.',NULL),
        ('RESULT_COLUMN',6,N'TextValue','nvarchar(max)',1,1,NULL,N'Shared-/Inline-/str-Text, kein Excel-Anzeigeformat.',NULL),
        ('RESULT_COLUMN',7,N'FormulaPresent','bit',1,0,NULL,N'f-Element vorhanden.',NULL),
        ('RESULT_COLUMN',8,N'FormulaText','nvarchar(max)',1,1,NULL,N'Unveränderter Formeltext, keine Berechnung.',NULL),
        ('RESULT_COLUMN',9,N'FormulaKind','nvarchar(16)',1,1,NULL,N'normal, shared, array oder dataTable.',NULL),
        ('RESULT_COLUMN',10,N'SharedFormulaIndex','int',1,1,NULL,N'Gespeichertes si, keine Formelrekonstruktion.',NULL),
        ('RESULT_COLUMN',11,N'CachePresent','bit',1,0,NULL,N'Formel und v-Element vorhanden.',NULL),
        ('RESULT_COLUMN',12,N'CacheValue','nvarchar(max)',1,1,NULL,N'Gespeicherter Formelcache-Rohtext.',NULL),
        ('ERROR',1,N'51520',NULL,NULL,NULL,NULL,N'Begrenzte Kategorie eines erwarteten Input-/Container-/XML-/Feature-/Ressourcenfehlers; keine Teilausgabe.',NULL),
        ('ERROR',2,N'51529',NULL,NULL,NULL,NULL,N'Fehlende oder inkonsistente registrierte Dependency bzw. interner Providervertrag.',NULL),
        ('PERMISSION',1,NULL,NULL,NULL,NULL,NULL,N'EXECUTE auf USP; ResultTable zusätzlich Helper-EXECUTE und Sichtbarkeit der caller-lokalen Tabelle. Keine Rechteausweitung.',NULL),
        ('LIMITATION',1,NULL,NULL,NULL,NULL,NULL,N'Transitional XLSX, klassische Stored-/Deflate-ZIPs. Kein ZIP64, externe Beziehungen, Makros oder Strict Open XML. Unicode bleibt unverändert, Tabellen brauchen explizite Ordinals zum Sortieren.',NULL),
        ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Hilfe ohne fachliche Eingaben.',N'EXEC toolbelt_file.USP_ReadXlsxWorksheetCells @Hilfe=1;');
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
               CAST(N'toolbelt_file' AS sysname) AS SchemaName,
               CAST(N'USP_ReadXlsxWorksheetCells' AS sysname) AS ObjectName,
               Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql
        FROM @Help ORDER BY CASE Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2
           WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 WHEN 'PERMISSION' THEN 5
           WHEN 'LIMITATION' THEN 6 ELSE 7 END,Ordinal;
        RETURN 0;
    END;
    -- NULL und Namespaceprüfung liegen vor der separaten Compilergrenze.
    IF @XlsxBinary IS NULL
    BEGIN
        -- Tablevariable hält auch bei null Zeilen die genaue Result-Nullability;
        -- keine private Temptabelle oder fachliche Core-Kompilierung entsteht.
        DECLARE @Empty TABLE ([RowOrdinal] int NOT NULL,[ColumnOrdinal] int NOT NULL,[StoredType] nvarchar(16) COLLATE Latin1_General_100_BIN2 NOT NULL,[ValuePresent] bit NOT NULL,[RawValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,[TextValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,[FormulaPresent] bit NOT NULL,[FormulaText] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,[FormulaKind] nvarchar(16) COLLATE Latin1_General_100_BIN2 NULL,[SharedFormulaIndex] int NULL,[CachePresent] bit NOT NULL,[CacheValue] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL);
        IF @ResultTable IS NULL SELECT [RowOrdinal],[ColumnOrdinal],[StoredType],[ValuePresent],[RawValue],[TextValue],[FormulaPresent],[FormulaText],[FormulaKind],[SharedFormulaIndex],[CachePresent],[CacheValue] FROM @Empty;
        RETURN 0;
    END;
    IF (@ResultTable IS NOT NULL AND LOWER(LEFT(@ResultTable COLLATE Latin1_General_100_BIN2,5))=N'#tbx_')
       OR OBJECT_ID(N'tempdb..#tbx_ListXlsxWorksheets_ResultSource') IS NOT NULL
       OR OBJECT_ID(N'tempdb..#tbx_ReadXlsxWorksheetCells_ResultSource') IS NOT NULL
        THROW 51520,N'Reservierter interner XLSX-Tempnamensbereich.',1;
    -- Fachliche Tempstatements werden erst hinter dieser EXEC-Grenze kompiliert.
    EXEC toolbelt_file.USP_InternalXlsxRead @ReadCells=1,
         @XlsxBinary=@XlsxBinary,
         @SheetOrdinal=@SheetOrdinal,
         @MaxArchiveBytes=@MaxArchiveBytes,
         @MaxPartBytes=@MaxPartBytes,
         @MaxTotalUncompressedBytes=@MaxTotalUncompressedBytes,
         @MaxParts=@MaxParts,
         @MaxSheets=@MaxSheets,
         @MaxCells=@MaxCells,
         @MaxSharedStrings=@MaxSharedStrings,
         @MaxSharedStringBytes=@MaxSharedStringBytes,
         @MaxXmlDepth=@MaxXmlDepth,
         @MaxCompressionRatio=@MaxCompressionRatio,
         @BudgetMilliseconds=@BudgetMilliseconds,
         @ResultTable=@ResultTable,
         @KeepData=@KeepData,
         @Debug=@Debug;
    RETURN 0;
END;
GO
SET NOCOUNT ON;
BEGIN TRY
 IF @@TRANCOUNT<>1 THROW 51539,N'Deploymenttransaktion fehlt.',1;
 DECLARE @Property sysname,@Value nvarchar(128);
 DECLARE ModuleMarkers CURSOR LOCAL FAST_FORWARD FOR SELECT Name,Value FROM
  (VALUES(N'Toolbelt.Module.toolbelt.file.xlsx-memory.Version',N'1.2.0'),
         (N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode',N'central'))p(Name,Value);
 OPEN ModuleMarkers; FETCH NEXT FROM ModuleMarkers INTO @Property,@Value;
 WHILE @@FETCH_STATUS=0
 BEGIN
  IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=@Property)
   EXEC sys.sp_updateextendedproperty @name=@Property,@value=@Value;
  ELSE EXEC sys.sp_addextendedproperty @name=@Property,@value=@Value;
  FETCH NEXT FROM ModuleMarkers INTO @Property,@Value;
 END;
 CLOSE ModuleMarkers; DEALLOCATE ModuleMarkers;
 DECLARE @Object sysname,@Type varchar(16);
 DECLARE ObjectMarkers CURSOR LOCAL FAST_FORWARD FOR
  SELECT o.name,CASE WHEN o.type=N'P' THEN 'PROCEDURE' ELSE 'FUNCTION' END,p.Name,p.Value
  FROM sys.objects o CROSS APPLY(VALUES(N'Toolbelt.ModuleId',N'toolbelt.file.xlsx-memory'),
     (N'Toolbelt.ModuleVersion',N'1.2.0'),
     (N'Toolbelt.Visibility',CASE WHEN o.name IN(N'USP_ListXlsxWorksheets',N'USP_ReadXlsxWorksheetCells',N'TVF_InterpretXlsxCell',N'TVF_FormatXlsxCell') THEN N'public' ELSE N'internal' END))p(Name,Value)
  WHERE o.schema_id=SCHEMA_ID(N'toolbelt_file') AND o.name IN(N'USP_ListXlsxWorksheets',N'USP_ReadXlsxWorksheetCells',N'USP_InternalXlsxRead',N'TVF_InternalXlsxSheets',N'TVF_InternalXlsxCells',N'TVF_InternalInterpretXlsxCell',N'TVF_InterpretXlsxCell',N'TVF_InternalFormatXlsxCell',N'TVF_FormatXlsxCell');
 OPEN ObjectMarkers; FETCH NEXT FROM ObjectMarkers INTO @Object,@Type,@Property,@Value;
 WHILE @@FETCH_STATUS=0
 BEGIN
  IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(@Object)) AND minor_id=0 AND name=@Property)
   EXEC sys.sp_updateextendedproperty @name=@Property,@value=@Value,@level0type=N'SCHEMA',@level0name=N'toolbelt_file',@level1type=@Type,@level1name=@Object;
  ELSE EXEC sys.sp_addextendedproperty @name=@Property,@value=@Value,@level0type=N'SCHEMA',@level0name=N'toolbelt_file',@level1type=@Type,@level1name=@Object;
  FETCH NEXT FROM ObjectMarkers INTO @Object,@Type,@Property,@Value;
 END;
 CLOSE ObjectMarkers; DEALLOCATE ObjectMarkers;
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=(SELECT assembly_id FROM sys.assemblies WHERE name=N'Toolbelt_File_XlsxMemory') AND name=N'Toolbelt.ModuleId')
  EXEC sys.sp_updateextendedproperty @name=N'Toolbelt.ModuleId',@value=N'toolbelt.file.xlsx-memory',@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_File_XlsxMemory';
 ELSE EXEC sys.sp_addextendedproperty @name=N'Toolbelt.ModuleId',@value=N'toolbelt.file.xlsx-memory',@level0type=N'ASSEMBLY',@level0name=N'Toolbelt_File_XlsxMemory';
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.file.xlsx-memory
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
