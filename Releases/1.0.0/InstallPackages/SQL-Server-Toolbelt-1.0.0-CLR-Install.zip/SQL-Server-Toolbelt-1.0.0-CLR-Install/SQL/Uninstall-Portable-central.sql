:ON ERROR EXIT
-- Nur nach Prüfung aller externen Consumer; Trust bleibt erhalten.
:On Error exit
-- Nichtdoomender Caller-Gate vor SET und sämtlichen Mutationen.
IF @@TRANCOUNT<>0
BEGIN
 RAISERROR(N'TBX_XLSX_LIFECYCLE_CALLER_TRANSACTION: Uninstall benötigt einen eigenen Transaktionsscope.',16,1);
 RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @Confirm bit=TRY_CONVERT(bit,N'1'),@Version nvarchar(max),
 @InstalledMode nvarchar(max),@AssemblyId int,@Installed bit,@Release int,@Phase int=0,@ProtectFuture bit=0;
DECLARE @Slots TABLE(Name sysname COLLATE DATABASE_DEFAULT NOT NULL,Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL,FirstRelease int NOT NULL,Class nvarchar(128) NULL,Method nvarchar(128) NULL);
INSERT @Slots VALUES
 (N'USP_ListXlsxWorksheets','P',10,NULL,NULL),
 (N'USP_ReadXlsxWorksheetCells','P',10,NULL,NULL),
 (N'USP_InternalXlsxRead','P',10,NULL,NULL),
 (N'TVF_InternalXlsxSheets','FT',10,N'Toolbelt.Xlsx.Qualification.XlsxEntryPoints',N'ListSheets'),
 (N'TVF_InternalXlsxCells','FT',10,N'Toolbelt.Xlsx.Qualification.XlsxEntryPoints',N'ReadCells'),
 (N'TVF_InternalInterpretXlsxCell','FT',11,N'Toolbelt.Xlsx.Qualification.XlsxCellType',N'Interpret'),
 (N'TVF_InterpretXlsxCell','IF',11,NULL,NULL),
 (N'TVF_InternalFormatXlsxCell','FT',12,N'Toolbelt.Xlsx.Qualification.XlsxCellDisplayBridge',N'Evaluate'),
 (N'TVF_FormatXlsxCell','IF',12,NULL,NULL);
DECLARE @Own TABLE(Id int NOT NULL PRIMARY KEY);
BEGIN TRY
 WHILE @Phase<2
 BEGIN
  -- Benutzerfreigabe 2026-10-02: vollständige Consumersicht vor Mutation,
  -- im zweiten Durchlauf erneut unter demselben Transaktions-AppLock.
  IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
   OR ISNULL(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
   THROW 51535,N'Vollständige Sicht auf SQL-Abhängigkeiten ist erforderlich.',2;
-- Keine Hashgleichheit ersetzt die bekannte Release-/Slotidentität.
SELECT @Version=NULL,@Installed=0,@InstalledMode=NULL,@AssemblyId=NULL;
SELECT @Version=TRY_CONVERT(nvarchar(max),value),@Installed=1 FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.Version';
SELECT @InstalledMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode';
IF @Installed=1 AND (@Version IS NULL OR CONVERT(varbinary(max),@Version) NOT IN
 (CONVERT(varbinary(max),N'1.0.0'),CONVERT(varbinary(max),N'1.1.0'),CONVERT(varbinary(max),N'1.2.0')))
 THROW 51534,N'Unbekannter oder inkohärenter XLSX-Release.',1;
IF (@Installed=1 AND (@InstalledMode IS NULL OR CONVERT(varbinary(max),@InstalledMode) NOT IN
 (CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))))
 OR (@Installed=0 AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode'))
 THROW 51534,N'Unbekannter oder inkohärenter XLSX-Modus.',1;
SET @Release=CASE CONVERT(varbinary(max),@Version) WHEN CONVERT(varbinary(max),N'1.0.0') THEN 10 WHEN CONVERT(varbinary(max),N'1.1.0') THEN 11 WHEN CONVERT(varbinary(max),N'1.2.0') THEN 12 ELSE 0 END;
SELECT @AssemblyId=assembly_id FROM sys.assemblies WHERE name=N'Toolbelt_File_XlsxMemory';
IF (@Installed=1 AND @AssemblyId IS NULL) OR (@Installed=0 AND @AssemblyId IS NOT NULL)
 OR (@AssemblyId IS NOT NULL AND (NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@AssemblyId AND permission_set=1
  AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_File_XlsxMemory'))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND name=N'Toolbelt.ModuleId'
 AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.file.xlsx-memory'))))
 THROW 51534,N'Fremde oder inkohärente XLSX-Assembly.',1;
IF EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(s.Name))
 WHERE (@Installed=1 AND s.FirstRelease<=@Release AND
  (o.object_id IS NULL OR CONVERT(varbinary(max),o.name)<>CONVERT(varbinary(max),s.Name)
   OR CONVERT(varbinary(max),o.type)<>CONVERT(varbinary(max),s.Kind)
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleId'
      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.file.xlsx-memory'))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleVersion'
      AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Version))
   OR (s.Kind='FT' AND NOT EXISTS(SELECT 1 FROM sys.assembly_modules m WHERE m.object_id=o.object_id AND m.assembly_id=@AssemblyId
      AND CONVERT(varbinary(max),m.assembly_class)=CONVERT(varbinary(max),s.Class)
      AND CONVERT(varbinary(max),m.assembly_method)=CONVERT(varbinary(max),s.Method)))))
  OR ((@Installed=0 OR s.FirstRelease>@Release) AND o.object_id IS NOT NULL AND @ProtectFuture=1))
 THROW 51534,N'XLSX-Slot, Typ oder Eigentumsmarker ist nicht der bekannte Release.',1;
DELETE FROM @Own;
INSERT @Own SELECT OBJECT_ID(N'toolbelt_file.'+QUOTENAME(Name)) FROM @Slots WHERE FirstRelease<=@Release;
IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@AssemblyId AND object_id NOT IN(SELECT Id FROM @Own))
 OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@AssemblyId)
 THROW 51535,N'Fremder Assemblyconsumer blockiert XLSX-Lifecycle.',1;

  IF @Installed=0
  BEGIN
   IF @Phase=0 RETURN;
   THROW 51534,N'XLSX-Release änderte sich während des Preflights.',1;
  END;
  IF @Confirm IS NULL OR (@InstalledMode=N'central' AND @Confirm<>1)
   THROW 51536,N'Zentraler Uninstall benötigt ConfirmNoExternalConsumers=1.',1;
  IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies WHERE referenced_id IN(SELECT Id FROM @Own) AND referencing_id NOT IN(SELECT Id FROM @Own))
   THROW 51535,N'Fremder XLSX-Consumer blockiert Uninstall.',1;
  IF @Phase=0
  BEGIN
   BEGIN TRANSACTION;
   DECLARE @Lock int;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.file.xlsx-memory',
    @LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock<0 THROW 51533,N'Paralleler XLSX-Lifecycle aktiv.',1;
  END;
  SET @Phase+=1;
 END;
 IF @Release>=12
 BEGIN
  DROP FUNCTION toolbelt_file.TVF_FormatXlsxCell;
  DROP FUNCTION toolbelt_file.TVF_InternalFormatXlsxCell;
 END;
 IF @Release>=11
 BEGIN
  DROP FUNCTION toolbelt_file.TVF_InterpretXlsxCell;
  DROP FUNCTION toolbelt_file.TVF_InternalInterpretXlsxCell;
 END;
 DROP PROCEDURE toolbelt_file.USP_ListXlsxWorksheets;
 DROP PROCEDURE toolbelt_file.USP_ReadXlsxWorksheetCells;
 DROP PROCEDURE toolbelt_file.USP_InternalXlsxRead;
 DROP FUNCTION toolbelt_file.TVF_InternalXlsxSheets;
 DROP FUNCTION toolbelt_file.TVF_InternalXlsxCells;
 DROP ASSEMBLY Toolbelt_File_XlsxMemory;
 EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.Version';
 EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.file.xlsx-memory.DeploymentMode';
 IF SCHEMA_ID(N'toolbelt_file') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.objects WHERE schema_id=SCHEMA_ID(N'toolbelt_file'))
  AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=SCHEMA_ID(N'toolbelt_file') AND name=N'Toolbelt.Managed' AND TRY_CONVERT(bit,value)=1)
  EXEC(N'DROP SCHEMA toolbelt_file');
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
-- Kanonische Dependencies und instanzweiter Trust bleiben erhalten.

GO
:On Error exit
IF @@TRANCOUNT>0
BEGIN
 RAISERROR(N'JSON_SCHEMA_CALLER_TRANSACTION: aktive Callertransaktion ausgeschlossen.',16,1);
 RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @Confirmation nvarchar(max)=N'1',@Mode nvarchar(max),
 @Pass int=0,@Lock int,@Initial varbinary(max),@Current varbinary(max);
-- Qualifizierte Offline-Schemazeile; keine Trustfreigabe.
DECLARE @SchemaKnownHash varbinary(64)=0x523b65979267457e8326ed2d5ec96d0309e9e1c7d5a0b2fbc0a3de68dcf7a9bb5a4f9cdda704ee0ba9f19097edbfb66eb8d649c0f2941b4a16adc2880bef880f,
 @SchemaArtifactId varchar(64)='22d1e92a612370b3e470c5ed893f6af61e55fd4465fcc3d362d4068e3cc6a02d';
-- Unveränderliche bekannte 1.0.0-Identität für Upgrade und release-aware Uninstall.
DECLARE @SchemaPreviousHash varbinary(64)=0xf67e0f9f3f6e83acc304e8e60bc98ee2610018e654ac4eb6e430f98a9665f9a1c85e90ef97950d348fcc0fc6389de71b214d1f9101835fec9a305ef39c41af21,
 @SchemaPreviousArtifactId varchar(64)='4ae51961dc53bd6aff96bb566e908cbb715d40512f36cffc756e7f2813a3a143';

-- Lokaler geschlossener Manifestzustand, genau zwei eigene SQL-Slots.
DECLARE @SchemaVersion nvarchar(max),@SchemaMode nvarchar(max),@SchemaAssemblyId int,@SchemaAssemblyOwner int,
 @SchemaInstalledHash varbinary(64),@SchemaInstalledArtifactId varchar(64),@SchemaOwner int,@SchemaInstalling bit=0,
 @SchemaResultVersion nvarchar(max),@SchemaResultId int,@SchemaMajor int,@SchemaMinor int,@SchemaPatch int,
 @SchemaConstructorId int,@SchemaConstructorVersion nvarchar(max);
DECLARE @SchemaSlots TABLE(Id int PRIMARY KEY,Name sysname NOT NULL,Kind char(2) NOT NULL);
INSERT @SchemaSlots VALUES(1,N'USP_ValidateJsonSchema','P'),(2,N'FT_ValidateJsonSchemaInternal','FT');
DECLARE @SchemaAssemblyMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);
DECLARE @SchemaConstructorMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);
DECLARE @SchemaParameters TABLE(Id int,Name sysname,TypeId int,Length smallint);
INSERT @SchemaParameters VALUES(1,N'@Json',231,-1),(2,N'@Schema',231,-1),(3,N'@Profile',231,64),
 (4,N'@MaxDocumentBytes',127,8),(5,N'@MaxSchemaBytes',127,8),(6,N'@MaxDepth',56,4),(7,N'@MaxEvaluationSteps',127,8),(8,N'@MaxErrors',56,4);
DECLARE @SchemaColumns TABLE(Id int,Name sysname,TypeId int,Length smallint);
INSERT @SchemaColumns VALUES(1,N'RowKind',231,16),(2,N'ErrorOrdinal',56,4),(3,N'Status',231,48),(4,N'Profile',231,64),
 (5,N'IsValid',104,1),(6,N'DocumentPointer',231,-1),(7,N'SchemaPointer',231,-1),(8,N'Keyword',231,256),
 (9,N'ErrorCode',231,64),(10,N'ErrorsTruncated',104,1);
DECLARE @SchemaPublicParameters TABLE(Id int,Name sysname,TypeId int,Length smallint,AliasName sysname NULL);
INSERT @SchemaPublicParameters SELECT Id,Name,CASE WHEN Id=3 THEN 167 ELSE TypeId END,CASE WHEN Id=3 THEN 32 ELSE Length END,NULL FROM @SchemaParameters;
INSERT @SchemaPublicParameters VALUES(9,N'@ResultTable',231,256,N'sysname'),(10,N'@KeepData',104,1,NULL),(11,N'@Debug',48,1,NULL),(12,N'@Hilfe',104,1,NULL);

-- Qualifizierte Offline-Corezeile; keine Trustfreigabe und keine Runtimeableitung.
DECLARE @JsonCoreKnownHash varbinary(64)=0x4680e9d34a0870924b5ca003cc5983882fc8ffb653e702bcc549e5f65dde11934c55ba7b356b519503ac5ce1e2478fe64876fea0295176ff13b5b4a6ab61b894,
 @JsonCoreArtifactId varchar(64)='975d4a84bb86e80b6e5844d6e86785ae0e98b13ee44c0f66c021507a23e0f888',
 @JsonCoreId int,@JsonCoreOwner int,@JsonCoreHash varbinary(64),
 @JsonCoreVersion nvarchar(max),@JsonCoreStoredMode nvarchar(max),
 @JsonCoreExpectedMode nvarchar(max),@JsonCoreRequired bit=1,@JsonCoreRemoving bit=0;
DECLARE @JsonCoreMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);

-- Target1.3 separat; die historische1.2-Knownzeile bleibt unverändert.
DECLARE @TargetKnownHash varbinary(64)=0x8ab08a17d1be0b861043463e223154dffbed8273bc2c197cd7c8b791c3c06c4af418358e8e743d72068a3a9f726f7f85f50bcfa431df0484202ab562e1edb4bf,
 @TargetArtifactId varchar(64)='a6d81103af18a73a14e58339abb8c7835e0d16d559951cfc3a03d305b63e4a23';

IF CONVERT(varbinary(max),@Confirmation) NOT IN(CONVERT(varbinary(max),N'0'),CONVERT(varbinary(max),N'1'))
 THROW 55635,N'JSON Schema lifecycle: ungültige Consumer-Bestätigung.',1;
BEGIN TRY
 WHILE @Pass<2
 BEGIN
  IF COALESCE(TRY_CONVERT(int,SERVERPROPERTY(N'ProductMajorVersion')),0) NOT IN(15,16,17)
   OR COALESCE((SELECT compatibility_level FROM sys.databases WHERE database_id=DB_ID()),0)<150
   THROW 55630,N'JSON Schema lifecycle: SQL-Version oder Compatibility Level nicht unterstützt.',1;
  SET @Mode=NULL;
  SELECT @Mode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
   WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.DeploymentMode';
  IF @Mode IS NOT NULL AND CONVERT(varbinary(max),@Mode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))
   THROW 55633,N'JSON Schema lifecycle: inkohärenter installierter Modus.',1;
-- Pure Include: Own2-Slots, bekannte Assembly, Dependencies; keine Mutation.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
 THROW 55632,N'JSON Schema lifecycle: vollständige Metadatensicht fehlt.',1;
SELECT @SchemaVersion=NULL,@SchemaMode=NULL,@SchemaAssemblyId=NULL,@SchemaAssemblyOwner=NULL,@SchemaInstalledHash=NULL,@SchemaInstalledArtifactId=NULL;
SELECT @SchemaVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.Version';
SELECT @SchemaMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.DeploymentMode';
SELECT @SchemaAssemblyId=a.assembly_id,@SchemaAssemblyOwner=a.principal_id,@SchemaInstalledHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1 WHERE a.name=N'Toolbelt_JsonSchema';
IF @SchemaVersion IS NULL
BEGIN
 IF @SchemaAssemblyId IS NOT NULL OR @SchemaMode IS NOT NULL
  OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.schema.Version')
  OR EXISTS(SELECT 1 FROM @SchemaSlots WHERE OBJECT_ID(N'toolbelt_json.'+QUOTENAME(Name)) IS NOT NULL)
  THROW 55634,N'JSON Schema lifecycle: unregistrierter oder fremder Zielslot.',1;
END
ELSE
BEGIN
 SET @SchemaInstalledArtifactId=CASE
  WHEN CONVERT(varbinary(max),@SchemaVersion)=CONVERT(varbinary(max),N'1.0.0') AND @SchemaInstalledHash=@SchemaPreviousHash THEN @SchemaPreviousArtifactId
  WHEN CONVERT(varbinary(max),@SchemaVersion)=CONVERT(varbinary(max),N'1.0.1') AND @SchemaInstalledHash=@SchemaKnownHash THEN @SchemaArtifactId END;
 IF @SchemaInstalledArtifactId IS NULL
  OR @SchemaMode IS NULL OR CONVERT(varbinary(max),@SchemaMode)<>CONVERT(varbinary(max),@Mode)
  OR @SchemaAssemblyId IS NULL OR @SchemaInstalledHash IS NULL
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@SchemaAssemblyId AND is_user_defined=1 AND permission_set=1 AND is_visible=1
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonSchema'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@SchemaAssemblyId)<>1
  THROW 55633,N'JSON Schema lifecycle: unbekannter oder inkohärenter Releasezustand.',1;
 DELETE FROM @SchemaAssemblyMarkers;
 INSERT @SchemaAssemblyMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.schema'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),@SchemaVersion))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@Mode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@SchemaInstalledHash)),(N'Toolbelt.ArtifactId',CONVERT(sql_variant,@SchemaInstalledArtifactId));
 IF EXISTS(SELECT 1 FROM @SchemaAssemblyMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@SchemaAssemblyId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value) AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55633,N'JSON Schema lifecycle: typisiertes Assemblymarkertuple inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @SchemaSlots slot WHERE NOT EXISTS(SELECT 1 FROM sys.objects o
  WHERE o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(slot.Name)) AND CONVERT(varbinary(2),o.type)=CONVERT(varbinary(2),slot.Kind)
   AND CONVERT(varbinary(max),o.name)=CONVERT(varbinary(max),slot.Name)
   AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleId'
    AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.json.schema'))
   AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleVersion'
    AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@SchemaVersion))
   AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.DeploymentMode'
    AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Mode))))
  THROW 55633,N'JSON Schema lifecycle: objektgenaue Ownership inkohärent.',1;
 IF NOT EXISTS(SELECT 1 FROM sys.assembly_modules WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') AND assembly_id=@SchemaAssemblyId
  AND CONVERT(varbinary(max),assembly_class)=CONVERT(varbinary(max),N'Toolbelt.JsonSchema.JsonSchemaBridge')
  AND CONVERT(varbinary(max),assembly_method)=CONVERT(varbinary(max),N'Validate'))
  OR EXISTS(SELECT 1 FROM @SchemaParameters expected WHERE NOT EXISTS(SELECT 1 FROM sys.parameters p
   WHERE p.object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') AND p.parameter_id=expected.Id
    AND CONVERT(varbinary(max),p.name)=CONVERT(varbinary(max),expected.Name) AND p.system_type_id=expected.TypeId
    AND p.user_type_id=p.system_type_id AND p.max_length=expected.Length AND p.is_output=0))
  OR (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal'))<>8
  OR EXISTS(SELECT 1 FROM @SchemaColumns expected WHERE NOT EXISTS(SELECT 1 FROM sys.columns c
   WHERE c.object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') AND c.column_id=expected.Id
    AND CONVERT(varbinary(max),c.name)=CONVERT(varbinary(max),expected.Name) AND c.system_type_id=expected.TypeId
    AND c.user_type_id=c.system_type_id AND c.max_length=expected.Length AND c.is_nullable=1))
  OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal'))<>10
  THROW 55633,N'JSON Schema lifecycle: CLR-Binding-/Parameters-/Spaltenvertrag inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @SchemaPublicParameters expected WHERE NOT EXISTS(SELECT 1 FROM sys.parameters p
  WHERE p.object_id=OBJECT_ID(N'toolbelt_json.USP_ValidateJsonSchema') AND p.parameter_id=expected.Id
   AND CONVERT(varbinary(max),p.name)=CONVERT(varbinary(max),expected.Name) AND p.system_type_id=expected.TypeId
   AND p.max_length=expected.Length AND p.is_output=0
   AND ((expected.AliasName IS NULL AND p.user_type_id=p.system_type_id)
    OR (expected.AliasName IS NOT NULL AND CONVERT(varbinary(max),TYPE_NAME(p.user_type_id))=CONVERT(varbinary(max),expected.AliasName)))))
  OR (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID(N'toolbelt_json.USP_ValidateJsonSchema'))<>12
  THROW 55633,N'JSON Schema lifecycle: öffentliche Parametersignatur inkohärent.',1;
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@SchemaAssemblyId AND object_id<>OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal'))
  OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@SchemaAssemblyId)
  OR EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d JOIN @SchemaSlots target ON d.referenced_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(target.Name))
   WHERE NOT EXISTS(SELECT 1 FROM @SchemaSlots own WHERE d.referencing_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(own.Name))))
  THROW 55636,N'JSON Schema lifecycle: fremder Verbraucher blockiert Lifecycle.',1;
END;
IF @SchemaInstalling=1 OR @SchemaAssemblyId IS NOT NULL
BEGIN
 SELECT @JsonCoreExpectedMode=@Mode,@JsonCoreRequired=1;
-- Pure SQLCMD-Include: keine Helper-USP, Mutation, Trust- oder Ownerreparatur.
-- KnownArtifact.sql deklariert den Scope. Aufruf vor/unter der gemeinsamen Lock.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 THROW 55622,N'JSON Core: vollständige Assemblymetadatensicht fehlt.',1;
SELECT @JsonCoreId=NULL,@JsonCoreOwner=NULL,@JsonCoreHash=NULL,@JsonCoreVersion=NULL,@JsonCoreStoredMode=NULL;
SELECT @JsonCoreVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.Version';
SELECT @JsonCoreStoredMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode';
SELECT @JsonCoreId=a.assembly_id,@JsonCoreOwner=a.principal_id,@JsonCoreHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonCore';
IF @JsonCoreId IS NULL
BEGIN
 IF @JsonCoreRequired=1 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0
  AND name IN(N'Toolbelt.Module.toolbelt.json.core.Version',N'Toolbelt.Module.toolbelt.json.core.DeploymentMode'))
  THROW 55623,N'JSON Core: erforderliche bekannte Dependency fehlt oder ist inkohärent.',1;
END
ELSE
BEGIN
 IF @JsonCoreVersion IS NULL OR CONVERT(varbinary(max),@JsonCoreVersion)<>CONVERT(varbinary(max),N'1.0.0')
  OR @JsonCoreStoredMode IS NULL OR CONVERT(varbinary(max),@JsonCoreStoredMode)<>CONVERT(varbinary(max),@JsonCoreExpectedMode)
  OR @JsonCoreHash IS NULL OR @JsonCoreHash<>@JsonCoreKnownHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@JsonCoreId AND is_user_defined=1 AND permission_set=1 AND is_visible=0
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonCore'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@JsonCoreId)<>1
  THROW 55623,N'JSON Core: keine kohärente bekannte technische SAFE-Assembly.',1;
 DELETE FROM @JsonCoreMarkers;
 INSERT @JsonCoreMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.core'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.0.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@JsonCoreExpectedMode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@JsonCoreKnownHash)),
 (N'Toolbelt.ArtifactId',CONVERT(sql_variant,@JsonCoreArtifactId));
 IF EXISTS(SELECT 1 FROM @JsonCoreMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@JsonCoreId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value)
   AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55623,N'JSON Core: typisiertes bekanntes Markertuple ist inkohärent.',1;
 -- Die technische Dependency stellt keine eigenen oder fremden SQL-Slots bereit.
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: direkter SQL-Verbraucher blockiert den technischen Corevertrag.',1;
 IF @JsonCoreRemoving=1 AND EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: verbleibende Assemblyverbraucher blockieren den Abbau.',1;
END;

 -- Schema installiert/repariert weder ResultTable noch Constructors.
 IF @SchemaInstalling=1
 BEGIN
 SELECT @SchemaResultVersion=NULL;
 SELECT @SchemaResultVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
 SELECT @SchemaResultId=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P'),@SchemaMajor=TRY_CONVERT(int,PARSENAME(@SchemaResultVersion,3)),
  @SchemaMinor=TRY_CONVERT(int,PARSENAME(@SchemaResultVersion,2)),@SchemaPatch=TRY_CONVERT(int,PARSENAME(@SchemaResultVersion,1));
 IF @SchemaResultId IS NULL OR @SchemaMajor IS NULL OR @SchemaMajor<1 OR @SchemaMinor IS NULL OR @SchemaMinor<0 OR @SchemaPatch IS NULL OR @SchemaPatch<0
  OR CONVERT(varbinary(max),@SchemaResultVersion)<>CONVERT(varbinary(max),CONCAT(@SchemaMajor,N'.',@SchemaMinor,N'.',@SchemaPatch))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@SchemaResultId AND minor_id=0 AND name=N'Toolbelt.ModuleId'
   AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.core.result-table'))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@SchemaResultId AND minor_id=0 AND name=N'Toolbelt.ModuleVersion'
   AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@SchemaResultVersion))
  THROW 55632,N'JSON Schema lifecycle: registrierte ResultTable-Dependency >=1.0.0 fehlt.',1;
 END;
 SELECT @SchemaOwner=COALESCE((SELECT principal_id FROM sys.schemas WHERE name=N'toolbelt_json'),USER_ID());
 IF @SchemaOwner IS NULL OR @SchemaOwner<>@JsonCoreOwner OR (@SchemaAssemblyId IS NOT NULL AND @SchemaAssemblyOwner<>@SchemaOwner)
  OR EXISTS(SELECT 1 FROM @SchemaSlots slot JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(slot.Name))
   WHERE COALESCE(o.principal_id,@SchemaOwner)<>@SchemaOwner)
  THROW 55633,N'JSON Schema lifecycle: kohärente vorhandene Owner fehlen; keine Ownerreparatur.',1;
 IF @SchemaAssemblyId IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.assembly_references WHERE assembly_id=@SchemaAssemblyId AND referenced_assembly_id=@JsonCoreId)
  THROW 55633,N'JSON Schema lifecycle: bekannte Assembly referenziert Core nicht.',1;
END;
-- Eine vorliegende Legacy1.2-Assembly würde einen zweiten aktuellen Scanner
-- aktiv lassen. Diese Read-only-Dependencyprüfung verändert Constructors nicht.
IF @SchemaInstalling=1 AND (EXISTS(SELECT 1 FROM sys.assemblies WHERE name=N'Toolbelt_JsonConstructors')
 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.Version'))
BEGIN
 SELECT @SchemaConstructorId=NULL,@SchemaConstructorVersion=NULL;
 SELECT @SchemaConstructorVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.Version';
 SELECT @SchemaConstructorId=a.assembly_id FROM sys.assemblies a JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
  WHERE a.name=N'Toolbelt_JsonConstructors' AND a.permission_set=1 AND a.is_user_defined=1 AND a.principal_id=@JsonCoreOwner
   AND HASHBYTES(N'SHA2_512',f.content)=@TargetKnownHash;
 IF @SchemaConstructorVersion IS NULL OR CONVERT(varbinary(max),@SchemaConstructorVersion)<>CONVERT(varbinary(max),N'1.3.0')
  OR @SchemaConstructorId IS NULL
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.DeploymentMode'
   AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Mode))
  OR NOT EXISTS(SELECT 1 FROM sys.assembly_references WHERE assembly_id=@SchemaConstructorId AND referenced_assembly_id=@JsonCoreId)
  THROW 55633,N'JSON Schema lifecycle: vorhandene Constructors zuerst explizit und kohärent auf1.3 migrieren.',1;
 DELETE FROM @SchemaConstructorMarkers;
 INSERT @SchemaConstructorMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.constructors'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.3.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@Mode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@TargetKnownHash)),(N'Toolbelt.ArtifactId',CONVERT(sql_variant,@TargetArtifactId));
 IF EXISTS(SELECT 1 FROM @SchemaConstructorMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@SchemaConstructorId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value) AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55633,N'JSON Schema lifecycle: Constructor-Dependencytuple inkohärent.',1;
END;

  IF @Pass=0 AND @SchemaAssemblyId IS NULL RETURN;
  IF CONVERT(varbinary(max),@Mode)=CONVERT(varbinary(max),N'central') AND @Confirmation=N'0'
   THROW 55635,N'JSON Schema lifecycle: zentrale Consumer-Bestätigung fehlt.',1;
  SELECT @Current=CONVERT(varbinary(max),(SELECT @SchemaVersion Version,@SchemaMode Mode,@SchemaAssemblyId AssemblyId,
   @SchemaAssemblyOwner AssemblyOwner,@SchemaOwner TargetOwner,@JsonCoreId CoreId,@JsonCoreOwner CoreOwner,
   @SchemaInstalledHash InstalledHash,@SchemaInstalledArtifactId InstalledArtifactId,
   SCHEMA_ID(N'toolbelt_json') SchemaId,OBJECT_ID(N'toolbelt_json.USP_ValidateJsonSchema') PublicId,
   OBJECT_ID(N'toolbelt_json.FT_ValidateJsonSchemaInternal') BridgeId FOR XML RAW,BINARY BASE64));
  IF @Pass=1 AND @Current<>@Initial THROW 55637,N'JSON Schema lifecycle: Zustand hat sich unter Lock verändert.',1;
  IF COALESCE(HAS_PERMS_BY_NAME(N'toolbelt_json',N'SCHEMA',N'ALTER'),0)<>1
   OR COALESCE(HAS_PERMS_BY_NAME(N'Toolbelt_JsonSchema',N'ASSEMBLY',N'ALTER'),0)<>1
   THROW 55632,N'JSON Schema lifecycle: vorhandene Uninstallrechte fehlen.',1;
  IF @Pass=0
  BEGIN
   SET @Initial=@Current;
   BEGIN TRANSACTION;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.json.shared-core',@LockMode=N'Shared',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock IS NULL OR @Lock<0 THROW 55637,N'JSON Schema lifecycle: gemeinsame Core-AppLock nicht verfügbar.',1;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.json.schema',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock IS NULL OR @Lock<0 THROW 55637,N'JSON Schema lifecycle: Modul-AppLock nicht verfügbar.',1;
  END;
  SET @Pass+=1;
 END;
 DROP PROCEDURE [toolbelt_json].[USP_ValidateJsonSchema];
 DROP FUNCTION [toolbelt_json].[FT_ValidateJsonSchemaInternal];
 DROP ASSEMBLY [Toolbelt_JsonSchema] WITH NO DEPENDENTS;
 EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.json.schema.Version';
 EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.json.schema.DeploymentMode';
 COMMIT;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
GO

GO
:On Error exit
-- Historischer/aktueller Uninstall entfernt ausschließlich kohärent eigene Slots.
IF @@TRANCOUNT>0
BEGIN
 RAISERROR(N'JSON_LIFECYCLE_CALLER_TRANSACTION: aktive Callertransaktion ist ausgeschlossen.',16,1);
 RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @Confirmation nvarchar(max)=N'1',@Version nvarchar(max),@Mode nvarchar(max),
 @Registered bit,@ModeRegistered bit,@Pass int=0,@Count int,@SchemaId int,@LockResult int,
 @InitialVersion varbinary(max),@InitialMode varbinary(max),@InitialSchemaId int,@InitialClrTuple varbinary(max),@CurrentClrTuple varbinary(max),@Id int,@Name sysname,@DropKind char(2),@Sql nvarchar(max);
DECLARE @Slots TABLE(Id int PRIMARY KEY,Name sysname COLLATE DATABASE_DEFAULT NOT NULL,ObjectId int NULL,Kind char(2) NOT NULL);
INSERT @Slots VALUES(1,N'USP_JsonConstructInternal',NULL,'P'),(2,N'USP_JsonArray',NULL,'P'),(3,N'USP_JsonObject',NULL,'P'),
 (4,N'USP_JsonArraysByGroup',NULL,'P'),(5,N'USP_JsonObjectsByGroup',NULL,'P'),
 (6,N'FT_JsonEntryEvaluateInternal',NULL,'FT'),(7,N'AGF_JsonArray',NULL,'AF'),(8,N'AGF_JsonObject',NULL,'AF');
-- Modullokale geschlossene Registryzeile; kein Targethash als KnownInstalled-Fallback.
DECLARE @KnownHash varbinary(64)=0xFF266A2FC46EB4101D87BC046AEF63197B985C8CCBAEA40F372E9918D1254C44F1F2CF8CED7942383625D28E2E1AF5BF6164FA8A16B3DD5A16DF5957FAA34276,
 @KnownArtifactId varchar(64)='e5d0a37f7643a1a7bbe17602ab0d8457bc959464e97496f45f6ddbe92fa15525',@AssemblyId int,@AssemblyOwner int,@InstalledHash varbinary(64),
 @EffectiveOwner int,@KnownMode nvarchar(16),@KnownCount int,@CreatingSlots bit=0;
DECLARE @Parameters TABLE(Slot sysname,Id int,Name sysname,TypeId int,Length smallint);
INSERT @Parameters VALUES
(N'AGF_JsonArray',0,N'',231,-1),
(N'AGF_JsonArray',1,N'@Ordinal',56,4),
(N'AGF_JsonArray',2,N'@ValueKind',231,-1),
(N'AGF_JsonArray',3,N'@Value',231,-1),
(N'AGF_JsonArray',4,N'@Profile',48,1),
(N'AGF_JsonObject',0,N'',231,-1),
(N'AGF_JsonObject',1,N'@Ordinal',56,4),
(N'AGF_JsonObject',2,N'@Key',231,-1),
(N'AGF_JsonObject',3,N'@ValueKind',231,-1),
(N'AGF_JsonObject',4,N'@Value',231,-1),
(N'AGF_JsonObject',5,N'@Profile',48,1),
(N'FT_JsonEntryEvaluateInternal',1,N'@ObjectMode',104,1),
(N'FT_JsonEntryEvaluateInternal',2,N'@Key',231,-1),
(N'FT_JsonEntryEvaluateInternal',3,N'@ValueKind',231,-1),
(N'FT_JsonEntryEvaluateInternal',4,N'@Value',231,-1),
(N'FT_JsonEntryEvaluateInternal',5,N'@Stage',48,1),
(N'FT_JsonEntryEvaluateInternal',6,N'@Policy',48,1);
DECLARE @Columns TABLE(Id int,Name sysname,TypeId int,Length smallint);
INSERT @Columns VALUES
(1,N'Fragment',231,-1),
(2,N'ErrorNumber',56,4),
(3,N'ErrorState',56,4),
(4,N'FaultPhase',48,1),
(5,N'RawValueBytes',127,8),
(6,N'KeyBytes',127,8),
(7,N'StrongMinimumBytes',127,8),
(8,N'FragmentBytes',127,8);

-- Target1.3 separat; die historische1.2-Knownzeile bleibt unverändert.
DECLARE @TargetKnownHash varbinary(64)=0x8ab08a17d1be0b861043463e223154dffbed8273bc2c197cd7c8b791c3c06c4af418358e8e743d72068a3a9f726f7f85f50bcfa431df0484202ab562e1edb4bf,
 @TargetArtifactId varchar(64)='a6d81103af18a73a14e58339abb8c7835e0d16d559951cfc3a03d305b63e4a23';

-- Qualifizierte Offline-Corezeile; keine Trustfreigabe und keine Runtimeableitung.
DECLARE @JsonCoreKnownHash varbinary(64)=0x4680e9d34a0870924b5ca003cc5983882fc8ffb653e702bcc549e5f65dde11934c55ba7b356b519503ac5ce1e2478fe64876fea0295176ff13b5b4a6ab61b894,
 @JsonCoreArtifactId varchar(64)='975d4a84bb86e80b6e5844d6e86785ae0e98b13ee44c0f66c021507a23e0f888',
 @JsonCoreId int,@JsonCoreOwner int,@JsonCoreHash varbinary(64),
 @JsonCoreVersion nvarchar(max),@JsonCoreStoredMode nvarchar(max),
 @JsonCoreExpectedMode nvarchar(max),@JsonCoreRequired bit=1,@JsonCoreRemoving bit=0;
DECLARE @JsonCoreMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);

IF CONVERT(varbinary(max),@Confirmation) NOT IN(CONVERT(varbinary(max),N'0'),CONVERT(varbinary(max),N'1'))
 THROW 53625,N'JSON lifecycle: Consumer-Bestätigung ist ungültig.',1;
BEGIN TRY
 WHILE @Pass<2
 BEGIN
  IF COALESCE(TRY_CONVERT(int,SERVERPROPERTY(N'ProductMajorVersion')),0) NOT IN(15,16,17)
   THROW 53620,N'JSON lifecycle: SQL-Version wird nicht unterstützt.',1;
  IF COALESCE((SELECT compatibility_level FROM sys.databases WHERE database_id=DB_ID()),0)<150
   THROW 53629,N'JSON lifecycle: Compatibility Level wird nicht unterstützt.',1;
  IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
   OR COALESCE(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
   THROW 53622,N'JSON lifecycle: vollständige Metadatensicht fehlt.',1;
  SELECT @Version=NULL,@Mode=NULL,@Registered=0,@ModeRegistered=0,@SchemaId=SCHEMA_ID(N'toolbelt_json');
  SELECT @Registered=1,@Version=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
   WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.Version';
  SELECT @ModeRegistered=1,@Mode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
   WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.constructors.DeploymentMode';
  IF @Pass=1 AND(@Registered=0 OR COALESCE(CONVERT(varbinary(max),@Version),0x)<>@InitialVersion
   OR COALESCE(CONVERT(varbinary(max),@Mode),0x)<>@InitialMode OR COALESCE(@SchemaId,-1)<>@InitialSchemaId)
   THROW 53627,N'JSON lifecycle: Zustand hat sich unter Lock verändert.',1;
  IF @Registered=0 AND @ModeRegistered=0
  BEGIN
   IF EXISTS(SELECT 1 FROM @Slots WHERE OBJECT_ID(N'toolbelt_json.'+QUOTENAME(Name)) IS NOT NULL)
    OR EXISTS(SELECT 1 FROM sys.assemblies WHERE name=N'Toolbelt_JsonConstructors')
    THROW 53623,N'JSON lifecycle: unregistrierter Zielzustand ist nicht absent.',1;
   RETURN;
  END;
  IF @Registered=0 OR @ModeRegistered=0 OR @SchemaId IS NULL OR @Version IS NULL OR @Mode IS NULL
   OR CONVERT(varbinary(max),@Version) NOT IN(CONVERT(varbinary(max),N'1.0.0'),CONVERT(varbinary(max),N'1.1.0'),CONVERT(varbinary(max),N'1.2.0'),CONVERT(varbinary(max),N'1.3.0'))
   OR CONVERT(varbinary(max),@Mode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))
  BEGIN
   IF @Pass=1 THROW 53627,N'JSON lifecycle: Releasezustand unter Lock ist inkohärent.',1;
   THROW 53623,N'JSON lifecycle: Releasezustand ist unbekannt oder inkohärent.',1;
  END;
  IF CONVERT(varbinary(max),@Mode)=CONVERT(varbinary(max),N'central') AND @Confirmation=N'0'
   THROW 53625,N'JSON lifecycle: zentrale Consumer-Bestätigung fehlt.',1;
  -- Vor der Dependencyabfrage, im Preflight und erneut unter derselben AppLock.
  IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
   OR COALESCE(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
   THROW 53622,N'JSON lifecycle: erforderliche Metadatenrechte für Uninstall fehlen.',1;
  IF COALESCE(HAS_PERMS_BY_NAME(N'toolbelt_json',N'SCHEMA',N'ALTER'),0)<>1
   THROW 53622,N'JSON lifecycle: erforderliche Uninstallrechte fehlen.',1;
  SET @Count=CASE WHEN CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.0.0') THEN 3 WHEN CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.1.0') THEN 5 ELSE 8 END;
  UPDATE @Slots SET ObjectId=CASE WHEN Id<=@Count THEN OBJECT_ID(N'toolbelt_json.'+QUOTENAME(Name)) ELSE NULL END;
  IF EXISTS(SELECT 1 FROM @Slots s WHERE s.Id<=@Count AND NOT EXISTS
   (SELECT 1 FROM sys.objects o WHERE o.object_id=s.ObjectId AND CONVERT(varbinary(2),o.type)=CONVERT(varbinary(2),s.Kind)
    AND CONVERT(varbinary(256),o.name)=CONVERT(varbinary(256),s.Name)
    AND EXISTS(SELECT 1 FROM sys.extended_properties ep WHERE ep.class=1 AND ep.major_id=o.object_id AND ep.minor_id=0
     AND ep.name=N'Toolbelt.ModuleId' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),ep.value))=CONVERT(varbinary(max),N'toolbelt.json.constructors'))
    AND EXISTS(SELECT 1 FROM sys.extended_properties ep WHERE ep.class=1 AND ep.major_id=o.object_id AND ep.minor_id=0
     AND ep.name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),ep.value))=CONVERT(varbinary(max),@Version))
    AND EXISTS(SELECT 1 FROM sys.extended_properties ep WHERE ep.class=1 AND ep.major_id=o.object_id AND ep.minor_id=0
     AND ep.name=N'Toolbelt.DeploymentMode' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),ep.value))=CONVERT(varbinary(max),@Mode))))
  BEGIN
   IF @Pass=1 THROW 53627,N'JSON lifecycle: Ownership unter Lock ist inkohärent.',1;
   THROW 53623,N'JSON lifecycle: Release-Ownership ist inkohärent.',1;
  END;
  SELECT @KnownMode=CONVERT(nvarchar(16),@Mode),@KnownCount=@Count;
-- SQLCMD-Include im gemeinsamen Preflight, erneut unter derselben AppLock.
-- Keine Prozedur, keine eigene Mutation und keine Katalogzeile als Registryautorität.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
 THROW 53622,N'JSON lifecycle: vollständige CLR-/Dependency-Metadatensicht fehlt.',1;
IF @CreatingSlots=1 OR CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0')
BEGIN
 SELECT @JsonCoreExpectedMode=@Mode,@JsonCoreRequired=1;
-- Pure SQLCMD-Include: keine Helper-USP, Mutation, Trust- oder Ownerreparatur.
-- KnownArtifact.sql deklariert den Scope. Aufruf vor/unter der gemeinsamen Lock.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 THROW 55622,N'JSON Core: vollständige Assemblymetadatensicht fehlt.',1;
SELECT @JsonCoreId=NULL,@JsonCoreOwner=NULL,@JsonCoreHash=NULL,@JsonCoreVersion=NULL,@JsonCoreStoredMode=NULL;
SELECT @JsonCoreVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.Version';
SELECT @JsonCoreStoredMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode';
SELECT @JsonCoreId=a.assembly_id,@JsonCoreOwner=a.principal_id,@JsonCoreHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonCore';
IF @JsonCoreId IS NULL
BEGIN
 IF @JsonCoreRequired=1 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0
  AND name IN(N'Toolbelt.Module.toolbelt.json.core.Version',N'Toolbelt.Module.toolbelt.json.core.DeploymentMode'))
  THROW 55623,N'JSON Core: erforderliche bekannte Dependency fehlt oder ist inkohärent.',1;
END
ELSE
BEGIN
 IF @JsonCoreVersion IS NULL OR CONVERT(varbinary(max),@JsonCoreVersion)<>CONVERT(varbinary(max),N'1.0.0')
  OR @JsonCoreStoredMode IS NULL OR CONVERT(varbinary(max),@JsonCoreStoredMode)<>CONVERT(varbinary(max),@JsonCoreExpectedMode)
  OR @JsonCoreHash IS NULL OR @JsonCoreHash<>@JsonCoreKnownHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@JsonCoreId AND is_user_defined=1 AND permission_set=1 AND is_visible=0
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonCore'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@JsonCoreId)<>1
  THROW 55623,N'JSON Core: keine kohärente bekannte technische SAFE-Assembly.',1;
 DELETE FROM @JsonCoreMarkers;
 INSERT @JsonCoreMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.core'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.0.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@JsonCoreExpectedMode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@JsonCoreKnownHash)),
 (N'Toolbelt.ArtifactId',CONVERT(sql_variant,@JsonCoreArtifactId));
 IF EXISTS(SELECT 1 FROM @JsonCoreMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@JsonCoreId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value)
   AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55623,N'JSON Core: typisiertes bekanntes Markertuple ist inkohärent.',1;
 -- Die technische Dependency stellt keine eigenen oder fremden SQL-Slots bereit.
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: direkter SQL-Verbraucher blockiert den technischen Corevertrag.',1;
 IF @JsonCoreRemoving=1 AND EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: verbleibende Assemblyverbraucher blockieren den Abbau.',1;
END;

END;
SELECT @AssemblyId=NULL,@AssemblyOwner=NULL,@InstalledHash=NULL;
SELECT @AssemblyId=a.assembly_id,@AssemblyOwner=a.principal_id,@InstalledHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonConstructors';
DECLARE @ExpectedInstalledHash varbinary(64)=CASE WHEN CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0') THEN @TargetKnownHash ELSE @KnownHash END,
 @ExpectedInstalledArtifact varchar(64)=CASE WHEN CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0') THEN @TargetArtifactId ELSE @KnownArtifactId END;
IF @Version IS NULL OR CONVERT(varbinary(max),@Version) NOT IN(CONVERT(varbinary(max),N'1.2.0'),CONVERT(varbinary(max),N'1.3.0'))
BEGIN
 IF @AssemblyId IS NOT NULL THROW 53624,N'JSON lifecycle: neuer Assemblyslot ist fremd belegt.',1;
END
ELSE
BEGIN
 IF @AssemblyId IS NULL OR @InstalledHash IS NULL OR @InstalledHash<>@ExpectedInstalledHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@AssemblyId AND permission_set=1 AND is_user_defined=1
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonConstructors'))
  THROW 53623,N'JSON lifecycle: installierte Assembly ist kein bekanntes SAFE-Artefakt.',1;
 -- Die geschlossene Offlinezeile ist eigenständig, nicht der Targethash oder clr_name.
 IF NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
  AND name=N'Toolbelt.Managed' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'int'
  AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=4 AND DATALENGTH(value)=4 AND CONVERT(int,value)=1)
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.ModuleId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=128 AND DATALENGTH(value)=52
   AND CONVERT(varbinary(max),CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),N'toolbelt.json.constructors'))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.ModuleVersion' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=32 AND DATALENGTH(value)=10
   AND CONVERT(varbinary(max),CONVERT(nvarchar(16),value))=CONVERT(varbinary(max),@Version))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.DeploymentMode' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=32 AND DATALENGTH(value)=DATALENGTH(@KnownMode)
   AND CONVERT(varbinary(max),CONVERT(nvarchar(16),value))=CONVERT(varbinary(max),@KnownMode))
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.AssemblySha512' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'varbinary'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=64 AND DATALENGTH(value)=64 AND CONVERT(varbinary(64),value)=@ExpectedInstalledHash)
  OR NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE class=5 AND major_id=@AssemblyId AND minor_id=0
   AND name=N'Toolbelt.ArtifactId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'varchar'
   AND SQL_VARIANT_PROPERTY(value,N'MaxLength')=64 AND DATALENGTH(value)=64
   AND CONVERT(varbinary(max),CONVERT(varchar(64),value))=CONVERT(varbinary(max),@ExpectedInstalledArtifact))
  THROW 53623,N'JSON lifecycle: typisiertes Assemblymarkertuple ist inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.assembly_modules m ON m.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
   WHERE s.Kind IN('FT','AF') AND (m.object_id IS NULL OR m.assembly_id<>@AssemblyId
    OR m.assembly_class IS NULL OR CONVERT(varbinary(max),m.assembly_class)<>CONVERT(varbinary(max),CASE s.Name
     WHEN N'FT_JsonEntryEvaluateInternal' THEN N'Toolbelt.JsonConstructors.JsonEntryEvaluateBridge'
     WHEN N'AGF_JsonArray' THEN N'Toolbelt.JsonConstructors.JsonArrayAggregate' ELSE N'Toolbelt.JsonConstructors.JsonObjectAggregate' END)
    OR (s.Kind='FT' AND (m.assembly_method IS NULL OR CONVERT(varbinary(max),m.assembly_method)<>CONVERT(varbinary(max),N'Evaluate')))
    OR (s.Kind='AF' AND m.assembly_method IS NOT NULL)))
  THROW 53623,N'JSON lifecycle: bekannte CLR-Bindings sind inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @Parameters e WHERE NOT EXISTS(SELECT 1 FROM sys.parameters p
  WHERE p.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(e.Slot)) AND p.parameter_id=e.Id
   AND CONVERT(varbinary(max),p.name)=CONVERT(varbinary(max),e.Name) AND p.system_type_id=e.TypeId
   AND p.user_type_id=p.system_type_id AND p.max_length=e.Length AND (p.parameter_id=0 OR p.is_output=0)))
  OR EXISTS(SELECT 1 FROM sys.parameters p JOIN @Slots s ON p.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
   WHERE s.Kind IN('FT','AF') AND NOT EXISTS(SELECT 1 FROM @Parameters e WHERE e.Slot=s.Name AND e.Id=p.parameter_id))
  THROW 53623,N'JSON lifecycle: CLR-Parametersignatur ist inkohärent.',1;
 IF EXISTS(SELECT 1 FROM @Columns e WHERE NOT EXISTS(SELECT 1 FROM sys.columns c
  WHERE c.object_id=OBJECT_ID(N'toolbelt_json.FT_JsonEntryEvaluateInternal') AND c.column_id=e.Id
   AND CONVERT(varbinary(max),c.name)=CONVERT(varbinary(max),e.Name) AND c.system_type_id=e.TypeId
   AND c.user_type_id=c.system_type_id AND c.max_length=e.Length AND c.is_nullable=1))
  OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'toolbelt_json.FT_JsonEntryEvaluateInternal'))<>8
  THROW 53623,N'JSON lifecycle: CLR-Bridgeresultschema ist inkohärent.',1;
END;
IF CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0')
 AND NOT EXISTS(SELECT 1 FROM sys.assembly_references WHERE assembly_id=@AssemblyId AND referenced_assembly_id=@JsonCoreId)
 THROW 53623,N'JSON lifecycle: bekannte1.3-Assembly referenziert den erforderlichen Core nicht.',1;
-- Vollständiger Verbrauchercheck; fremde direkte CLR-Slots und Assemblyreferenzen ebenfalls.
IF @AssemblyId IS NOT NULL AND (EXISTS(SELECT 1 FROM sys.assembly_modules m WHERE m.assembly_id=@AssemblyId
 AND NOT EXISTS(SELECT 1 FROM @Slots s WHERE OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))=m.object_id))
 OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@AssemblyId))
 THROW 53626,N'JSON lifecycle: fremder Assemblyverbraucher blockiert Lifecycle.',1;
IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d JOIN @Slots t ON d.referenced_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(t.Name))
 WHERE t.Id<=@KnownCount AND NOT EXISTS(SELECT 1 FROM @Slots s WHERE s.Id<=@KnownCount AND d.referencing_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))))
 THROW 53626,N'JSON lifecycle: fremder SQL-Verbraucher blockiert Lifecycle.',1;
IF @SchemaId IS NOT NULL
BEGIN
 SELECT @EffectiveOwner=MIN(COALESCE(o.principal_id,sc.principal_id))
  FROM @Slots s JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
  JOIN sys.schemas sc ON sc.schema_id=o.schema_id WHERE s.Id<=@KnownCount;
 IF @EffectiveOwner IS NULL SELECT @EffectiveOwner=principal_id FROM sys.schemas WHERE schema_id=@SchemaId;
 IF @EffectiveOwner IS NULL OR EXISTS(SELECT 1 FROM @Slots s JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
  JOIN sys.schemas sc ON sc.schema_id=o.schema_id WHERE s.Id<=@KnownCount AND COALESCE(o.principal_id,sc.principal_id)<>@EffectiveOwner)
  OR (@AssemblyId IS NOT NULL AND (@AssemblyOwner IS NULL OR @AssemblyOwner<>@EffectiveOwner))
  THROW 53623,N'JSON lifecycle: kohärente vorhandene Owner fehlen; keine Ownerreparatur.',1;
 -- Neue CLR-Objekte erben den Schemaowner. Ohne Owneränderung muss eine
 -- Migration bereits dazu kohärent sein; Repeat erhält explizite Owner.
 IF @CreatingSlots=1 AND @KnownCount<8 AND @KnownCount>0 AND @EffectiveOwner<>(SELECT principal_id FROM sys.schemas WHERE schema_id=@SchemaId)
  THROW 53623,N'JSON lifecycle: neue Slots würden inkohärente Owner erben.',1;
END;
IF (@CreatingSlots=1 OR CONVERT(varbinary(max),@Version)=CONVERT(varbinary(max),N'1.3.0'))
 AND (@JsonCoreOwner IS NULL OR @JsonCoreOwner<>COALESCE(@EffectiveOwner,USER_ID()))
 THROW 53623,N'JSON lifecycle: Core-/Constructorowner sind inkohärent; keine Ownerreparatur.',1;

  SELECT @CurrentClrTuple=CONVERT(varbinary(max),(SELECT s.Id,OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name)) ObjectId,
   o.principal_id ObjectOwner,sc.principal_id SchemaOwner,@AssemblyId AssemblyId,@AssemblyOwner AssemblyOwner,
   @JsonCoreId CoreId,@JsonCoreOwner CoreOwner
   FROM @Slots s LEFT JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_json.'+QUOTENAME(s.Name))
   LEFT JOIN sys.schemas sc ON sc.schema_id=o.schema_id ORDER BY s.Id FOR XML RAW,BINARY BASE64));
  IF @Pass=0 SET @InitialClrTuple=@CurrentClrTuple;
  ELSE IF @CurrentClrTuple<>@InitialClrTuple THROW 53627,N'JSON lifecycle: Objekt-/Assemblyidentität hat sich unter Lock verändert.',1;
  IF @AssemblyId IS NOT NULL AND COALESCE(HAS_PERMS_BY_NAME(N'Toolbelt_JsonConstructors',N'ASSEMBLY',N'ALTER'),0)<>1
   THROW 53622,N'JSON lifecycle: vorhandenes Assembly-ALTER-Recht fehlt.',1;
  IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d JOIN @Slots target ON target.ObjectId=d.referenced_id
   WHERE target.Id<=@Count AND NOT EXISTS(SELECT 1 FROM @Slots source WHERE source.Id<=@Count AND source.ObjectId=d.referencing_id))
   THROW 53626,N'JSON lifecycle: same-database Dependency blockiert Uninstall.',1;
  IF @Pass=0
  BEGIN
   SELECT @InitialVersion=CONVERT(varbinary(max),@Version),@InitialMode=CONVERT(varbinary(max),@Mode),@InitialSchemaId=@SchemaId;
   BEGIN TRANSACTION;
   EXEC @LockResult=sys.sp_getapplock @Resource=N'toolbelt.deploy.json.shared-core',@LockMode=N'Shared',
    @LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @LockResult IS NULL OR @LockResult<0 THROW 53627,N'JSON lifecycle: gemeinsame Core-AppLock ist nicht verfügbar.',1;
   EXEC @LockResult=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.json.constructors',@LockMode=N'Exclusive',
    @LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @LockResult IS NULL OR @LockResult<0 THROW 53627,N'JSON lifecycle: AppLock ist nicht verfügbar.',1;
  END;
  SET @Pass+=1;
 END;
 -- Zukunftsslots bei installiertem 1.0 gehören nicht zu diesem Dropplan.
 SET @Id=@Count;
 WHILE @Id>=1
 BEGIN
  SELECT @Name=Name,@DropKind=Kind FROM @Slots WHERE Id=@Id;
  SET @Sql=N'DROP '+CASE @DropKind WHEN 'P' THEN N'PROCEDURE' WHEN 'AF' THEN N'AGGREGATE' ELSE N'FUNCTION' END
   +N' [toolbelt_json].'+QUOTENAME(@Name)+N';';
  EXEC sys.sp_executesql @Sql;
  SET @Id-=1;
 END;
 IF @Count=8 DROP ASSEMBLY [Toolbelt_JsonConstructors] WITH NO DEPENDENTS;
 EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.json.constructors.Version';
 EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.json.constructors.DeploymentMode';
 -- Unmarkiertes oder nichtleeres fremdes Schema niemals entfernen.
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=@SchemaId AND minor_id=0
   AND name=N'Toolbelt.Managed' AND TRY_CONVERT(int,value)=1)
  AND EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=@SchemaId AND minor_id=0
   AND name=N'Toolbelt.SchemaCategory' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'json'))
  AND NOT EXISTS(SELECT 1 FROM sys.objects WHERE schema_id=@SchemaId)
  AND NOT EXISTS(SELECT 1 FROM sys.types WHERE schema_id=@SchemaId AND is_user_defined=1)
  AND NOT EXISTS(SELECT 1 FROM sys.xml_schema_collections WHERE schema_id=@SchemaId AND xml_collection_id>0)
  DROP SCHEMA [toolbelt_json];
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO

GO
:On Error exit
IF @@TRANCOUNT<>0
BEGIN
 RAISERROR(N'TBX_CSV_LIFECYCLE_CALLER_TRANSACTION: Ein eigener Transaktionsscope ist erforderlich.',16,1);
 RETURN;
END;
DECLARE @Install bit=0,@Bits varbinary(max)=NULL,@Mode nvarchar(max)=NULL,@Confirm bit=TRY_CONVERT(bit,N'1');
IF CONVERT(varbinary(max),N'1') NOT IN(CONVERT(varbinary(max),N'0'),CONVERT(varbinary(max),N'1'))
 THROW 55326,N'ConfirmNoExternalConsumers muss exakt 0 oder 1 sein.',2;
-- Gemeinsamer CSV-Lifecycle: read-only Preflight zweimal, dann eigene atomare DDL.
-- Nur Deploy/Uninstall setzen @Install, @Bits, @Mode und @Confirm.
IF @@TRANCOUNT<>0
BEGIN
 RAISERROR(N'TBX_CSV_LIFECYCLE_CALLER_TRANSACTION: Ein eigener Transaktionsscope ist erforderlich.',16,1);
 RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @Module nvarchar(128)=N'toolbelt.file.csv-memory',@Version nvarchar(max),
 @InstalledMode nvarchar(max),@AssemblyId int,@SchemaId int,@SchemaOwner int,
 @Installed bit,@Phase int=0,@OwnTransaction bit=0,@Hash varbinary(64)=HASHBYTES('SHA2_512',@Bits);
DECLARE @Slots TABLE(Name sysname COLLATE DATABASE_DEFAULT PRIMARY KEY,Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL,Method sysname NULL);
INSERT @Slots VALUES(N'USP_ParseCsv','P',NULL),(N'USP_WriteCsv','P',NULL),
 (N'TVF_InternalParseCsv','FT',N'Parse'),(N'SVF_InternalQuoteCsvCell','FS',N'QuoteCell'),(N'SVF_InternalMeasureCsvCell','FS',N'MeasureCell');
DECLARE @Own TABLE(Id int PRIMARY KEY);
-- CLR-Transportsignaturen sind Teil der technischen Releaseidentität.
DECLARE @Parameters TABLE(Name sysname,Ordinal int,ParameterName sysname,TypeId int,Length smallint);
INSERT @Parameters VALUES
 (N'TVF_InternalParseCsv',1,N'@Text',231,-1),(N'TVF_InternalParseCsv',2,N'@Separator',231,4),(N'TVF_InternalParseCsv',3,N'@HasHeader',104,1),(N'TVF_InternalParseCsv',4,N'@NullToken',231,256),
 (N'TVF_InternalParseCsv',5,N'@MaxRows',127,8),(N'TVF_InternalParseCsv',6,N'@MaxColumns',56,4),(N'TVF_InternalParseCsv',7,N'@MaxCells',127,8),(N'TVF_InternalParseCsv',8,N'@MaxInputBytes',127,8),
 (N'SVF_InternalMeasureCsvCell',0,N'',127,8),(N'SVF_InternalMeasureCsvCell',1,N'@Value',231,-1),(N'SVF_InternalMeasureCsvCell',2,N'@Separator',231,4),(N'SVF_InternalMeasureCsvCell',3,N'@NullToken',231,256),(N'SVF_InternalMeasureCsvCell',4,N'@IsHeader',104,1),
 (N'SVF_InternalQuoteCsvCell',0,N'',231,-1),(N'SVF_InternalQuoteCsvCell',1,N'@Value',231,-1),(N'SVF_InternalQuoteCsvCell',2,N'@Separator',231,4),(N'SVF_InternalQuoteCsvCell',3,N'@NullToken',231,256),(N'SVF_InternalQuoteCsvCell',4,N'@IsHeader',104,1),(N'SVF_InternalQuoteCsvCell',5,N'@MaxOutputBytes',127,8);
DECLARE @Columns TABLE(Ordinal int,Name sysname,TypeId int,Length smallint);
INSERT @Columns VALUES(1,N'RowKind',231,12),(2,N'RowOrdinal',127,8),(3,N'ColumnOrdinal',56,4),(4,N'Value',231,-1),(5,N'ErrorCode',56,4);
IF ISNULL(TRY_CONVERT(int,SERVERPROPERTY('ProductMajorVersion')),0) NOT IN(15,16,17)
 THROW 55320,N'CSV benötigt SQL Server 2019, 2022 oder 2025.',1;
IF NOT EXISTS(SELECT 1 FROM sys.databases WHERE database_id=DB_ID() AND compatibility_level IN(150,160,170)
 AND compatibility_level<=CASE TRY_CONVERT(int,SERVERPROPERTY('ProductMajorVersion')) WHEN 15 THEN 150 WHEN 16 THEN 160 WHEN 17 THEN 170 END)
 THROW 55320,N'CSV benötigt einen zur SQL-Version passenden CL150/160/170.',3;
IF @Install=1 AND (@Mode IS NULL OR CONVERT(varbinary(max),@Mode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central')))
 THROW 55320,N'DeploymentMode muss exakt local oder central sein.',2;
IF @Install=1 AND (@Bits IS NULL OR DATALENGTH(@Bits)<1024 OR @Hash IS NULL)
 THROW 55321,N'Vollständiges Releasebinary fehlt.',1;
IF @Install=0 AND (@Confirm IS NULL OR @Confirm NOT IN(0,1))
 THROW 55326,N'ConfirmNoExternalConsumers muss exakt 0 oder 1 sein.',2;
BEGIN TRY
 WHILE @Phase<2
 BEGIN
  IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
   OR ISNULL(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
   THROW 55325,N'Vollständige Sicht auf Lifecyclemetadaten und SQL-Abhängigkeiten fehlt.',1;
  IF @Install=1
  BEGIN
   IF NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr enabled' AND value_in_use=1)
    OR NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr strict security' AND value_in_use=1)
    OR NOT EXISTS(SELECT 1 FROM sys.trusted_assemblies WHERE hash=@Hash)
    THROW 55321,N'CLR, strict security und separat autorisierter exakter Zielhashtrust fehlen.',2;
   DECLARE @DependencyVersion nvarchar(max)=NULL,@DependencyObject int=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P');
   SELECT @DependencyVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
   DECLARE @Major int=TRY_CONVERT(int,PARSENAME(@DependencyVersion,3)),@Minor int=TRY_CONVERT(int,PARSENAME(@DependencyVersion,2)),@Patch int=TRY_CONVERT(int,PARSENAME(@DependencyVersion,1));
   IF @DependencyObject IS NULL OR @Major IS NULL OR @Major<1 OR @Minor IS NULL OR @Minor<0 OR @Patch IS NULL OR @Patch<0
    OR CONVERT(varbinary(max),@DependencyVersion)<>CONVERT(varbinary(max),CONCAT(@Major,N'.',@Minor,N'.',@Patch))
    OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@DependencyObject AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'toolbelt.core.result-table'))
    OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@DependencyObject AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@DependencyVersion))
    THROW 55322,N'Kanonische sameDB-ResultTable-Abhängigkeit >=1.0.0 fehlt.',1;
  END;
  SELECT @Version=NULL,@InstalledMode=NULL,@AssemblyId=NULL,@Installed=0,@SchemaOwner=NULL;
  SELECT @Version=TRY_CONVERT(nvarchar(max),value),@Installed=1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.csv-memory.Version';
  SELECT @InstalledMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.csv-memory.DeploymentMode';
  SELECT @AssemblyId=assembly_id FROM sys.assemblies WHERE name=N'Toolbelt_File_CsvMemory';
  SET @SchemaId=SCHEMA_ID(N'toolbelt_file');
  SELECT @SchemaOwner=principal_id FROM sys.schemas WHERE schema_id=@SchemaId;
  IF @SchemaId IS NOT NULL AND (NOT EXISTS(SELECT 1 FROM sys.schemas WHERE schema_id=@SchemaId AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'toolbelt_file'))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=@SchemaId AND minor_id=0 AND name=N'Toolbelt.Managed' AND TRY_CONVERT(bit,value)=1)
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=@SchemaId AND minor_id=0 AND name=N'Toolbelt.SchemaCategory' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'file')))
   THROW 55324,N'Vorhandenes Schema ist nicht kohärent zugeordnet.',1;
  IF @Installed=1 AND (@Version IS NULL OR CONVERT(varbinary(max),@Version)<>CONVERT(varbinary(max),N'1.0.0') OR @InstalledMode IS NULL OR CONVERT(varbinary(max),@InstalledMode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central')))
   THROW 55324,N'Unbekannter CSV-Release oder inkohärenter Modus.',2;
  IF @Installed=0 AND (EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.file.csv-memory.DeploymentMode') OR @AssemblyId IS NOT NULL OR EXISTS(SELECT 1 FROM @Slots WHERE OBJECT_ID(N'toolbelt_file.'+QUOTENAME(Name)) IS NOT NULL))
   THROW 55324,N'Fremde Zielslotbelegung oder unvollständiger Modulzustand.',3;
  IF @Installed=1 AND (@AssemblyId IS NULL OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@AssemblyId AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_File_CsvMemory') AND permission_set=1 AND is_user_defined=1 AND principal_id=@SchemaOwner)
   OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@AssemblyId)<>1
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.Managed' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'bit' AND TRY_CONVERT(bit,value)=1)
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Module))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'1.0.0')))
   THROW 55324,N'CSV-Assembly, Eigentümer oder Releasezuordnung ist inkohärent.',4;
  IF @Installed=1 AND EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(s.Name)) WHERE o.object_id IS NULL OR CONVERT(varbinary(max),o.name)<>CONVERT(varbinary(max),s.Name) OR CONVERT(varbinary(max),o.type)<>CONVERT(varbinary(max),s.Kind) OR COALESCE(o.principal_id,@SchemaOwner)<>@SchemaOwner
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.Managed' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'bit' AND TRY_CONVERT(bit,value)=1)
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@Module))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'1.0.0'))
   OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.Visibility' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),CASE WHEN s.Kind='P' THEN N'public' ELSE N'internal' END))
   OR(s.Method IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.assembly_modules m WHERE m.object_id=o.object_id AND m.assembly_id=@AssemblyId AND m.null_on_null_input=0 AND m.execute_as_principal_id IS NULL AND CONVERT(varbinary(max),m.assembly_class)=CONVERT(varbinary(max),N'Toolbelt.Csv.CsvEntryPoints') AND CONVERT(varbinary(max),m.assembly_method)=CONVERT(varbinary(max),s.Method))))
   THROW 55324,N'CSV-Slot, Binding, Typ oder Ownershipmarker ist inkohärent.',5;
  IF @Installed=1 AND (EXISTS(SELECT 1 FROM @Parameters e LEFT JOIN sys.parameters p ON p.object_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(e.Name)) AND p.parameter_id=e.Ordinal WHERE p.object_id IS NULL OR CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),e.ParameterName) OR p.system_type_id<>e.TypeId OR p.user_type_id<>p.system_type_id OR p.max_length<>e.Length OR (e.Ordinal>0 AND(p.is_output<>0 OR p.has_default_value<>0)))
   OR EXISTS(SELECT 1 FROM @Slots s WHERE s.Method IS NOT NULL AND (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID(N'toolbelt_file.'+QUOTENAME(s.Name)))<>(SELECT COUNT(*) FROM @Parameters WHERE Name=s.Name))
   OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'toolbelt_file.TVF_InternalParseCsv'))<>5
   OR EXISTS(SELECT 1 FROM @Columns e LEFT JOIN sys.columns c ON c.object_id=OBJECT_ID(N'toolbelt_file.TVF_InternalParseCsv') AND c.column_id=e.Ordinal WHERE c.object_id IS NULL OR CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),e.Name) OR c.system_type_id<>e.TypeId OR c.user_type_id<>c.system_type_id OR c.max_length<>e.Length OR c.is_nullable<>1))
   THROW 55324,N'Interne CLR-Parameter oder nullable Parserfelder sind inkohärent.',7;
  DELETE FROM @Own;
  INSERT @Own SELECT OBJECT_ID(N'toolbelt_file.'+QUOTENAME(Name)) FROM @Slots WHERE @Installed=1;
  IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@AssemblyId AND object_id NOT IN(SELECT Id FROM @Own)) OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@AssemblyId)
   THROW 55325,N'Fremder Assemblyconsumer blockiert CSV-Lifecycle.',2;
  IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d WHERE (d.referenced_id IN(SELECT Id FROM @Own)
   OR(d.referenced_id IS NULL AND (d.referenced_database_name IS NULL OR d.referenced_database_name COLLATE DATABASE_DEFAULT=DB_NAME()) AND d.referenced_schema_name COLLATE DATABASE_DEFAULT=N'toolbelt_file' AND EXISTS(SELECT 1 FROM @Slots WHERE Name COLLATE DATABASE_DEFAULT=d.referenced_entity_name COLLATE DATABASE_DEFAULT))) AND d.referencing_id NOT IN(SELECT Id FROM @Own))
   THROW 55325,N'Fremder SQL-Verbraucher blockiert CSV-Lifecycle.',3;
  IF @Install=0 AND @Installed=0
  BEGIN
   IF @Phase=0 RETURN;
   THROW 55324,N'CSV-Zustand änderte sich während des Preflights.',6;
  END;
  IF @Install=0 AND CONVERT(varbinary(max),@InstalledMode)=CONVERT(varbinary(max),N'central') AND @Confirm<>1
   THROW 55326,N'Zentraler Uninstall benötigt explizite Consumerbestätigung.',1;
  IF @Install=0 AND @Installed=1 AND (ISNULL(HAS_PERMS_BY_NAME(N'toolbelt_file',N'SCHEMA',N'ALTER'),0)<>1 OR ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'ALTER ANY ASSEMBLY'),0)<>1)
   THROW 55327,N'Schema-ALTER/ALTER ANY ASSEMBLY für Uninstall fehlt; keine Rechtevergabe.',7;
  IF @Install=1
  BEGIN
   IF @SchemaId IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE SCHEMA'),0)<>1 THROW 55327,N'CREATE SCHEMA fehlt; keine Rechtevergabe.',1;
   IF @SchemaId IS NOT NULL AND ISNULL(HAS_PERMS_BY_NAME(N'toolbelt_file',N'SCHEMA',N'ALTER'),0)<>1 THROW 55327,N'Schema-ALTER fehlt; keine Rechtevergabe.',2;
   IF @SchemaId IS NOT NULL AND @AssemblyId IS NULL AND @SchemaOwner<>USER_ID() THROW 55327,N'Neue Assembly benötigt denselben effektiven Eigentümer wie das Schema.',3;
   IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE FUNCTION'),0)<>1 OR ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE PROCEDURE'),0)<>1 THROW 55327,N'CREATE FUNCTION/PROCEDURE fehlt; keine Rechtevergabe.',4;
   IF @AssemblyId IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE ASSEMBLY'),0)<>1 THROW 55327,N'CREATE ASSEMBLY fehlt; keine Rechtevergabe.',5;
   IF @AssemblyId IS NOT NULL AND EXISTS(SELECT 1 FROM sys.assembly_files WHERE assembly_id=@AssemblyId AND file_id=1 AND HASHBYTES('SHA2_512',content)<>@Hash) AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'ALTER ANY ASSEMBLY'),0)<>1 THROW 55327,N'ALTER ANY ASSEMBLY fehlt; keine Rechtevergabe.',6;
  END;
  IF @Phase=0
  BEGIN
   BEGIN TRANSACTION;SET @OwnTransaction=1;
   DECLARE @Lock int;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.file.csv-memory',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock<0 THROW 55323,N'Paralleler CSV-Lifecycle aktiv.',1;
  END;
  SET @Phase+=1;
 END;
 IF @Install=1 AND @SchemaId IS NULL
 BEGIN
  EXEC(N'CREATE SCHEMA toolbelt_file');
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_file';
  EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'file',@level0type=N'SCHEMA',@level0name=N'toolbelt_file';
 END;
 IF @Installed=1
 BEGIN
  DROP PROCEDURE toolbelt_file.USP_ParseCsv;
  DROP PROCEDURE toolbelt_file.USP_WriteCsv;
  DROP FUNCTION toolbelt_file.TVF_InternalParseCsv;
  DROP FUNCTION toolbelt_file.SVF_InternalQuoteCsvCell;
  DROP FUNCTION toolbelt_file.SVF_InternalMeasureCsvCell;
 END;
 IF @Install=1
 BEGIN
  DECLARE @InstalledHash varbinary(64)=(SELECT HASHBYTES('SHA2_512',content) FROM sys.assembly_files WHERE assembly_id=@AssemblyId AND file_id=1);
  IF @InstalledHash IS NULL OR @InstalledHash<>@Hash
  BEGIN
   DECLARE @Ddl nvarchar(max)=CASE WHEN @AssemblyId IS NULL THEN N'CREATE' ELSE N'ALTER' END+N' ASSEMBLY [Toolbelt_File_CsvMemory] FROM '+CONVERT(nvarchar(max),@Bits,1)+N' WITH PERMISSION_SET=SAFE;';
   EXEC sys.sp_executesql @Ddl;
  END;
 END
 ELSE
 BEGIN
  DROP ASSEMBLY Toolbelt_File_CsvMemory;
  EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.file.csv-memory.Version';
  EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.file.csv-memory.DeploymentMode';
  -- Geteiltes Schema/Dependencies und instanzweiter Trust bleiben erhalten.
  COMMIT TRANSACTION;SET @OwnTransaction=0;
 END;
END TRY
BEGIN CATCH
 IF @OwnTransaction=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;

GO

GO
:On Error exit
-- RAISERROR statt THROW: Caller-Transaktionen bei XACT_ABORT ON nicht beschädigen.
IF @@TRANCOUNT<>0
BEGIN
    RAISERROR(N'TBX_ZIP_LIFECYCLE_CALLER_TRANSACTION: Uninstall benötigt einen eigenen Transaktionsscope.',16,1);
    RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @ConfirmNoExternalConsumers bit =
          TRY_CONVERT(bit, N'1')
    , @VersionProperty sysname =
          N'Toolbelt.Module.toolbelt.archive.zip-memory.Version'
    , @ModeProperty sysname =
          N'Toolbelt.Module.toolbelt.archive.zip-memory.DeploymentMode'
    , @DeploymentMode nvarchar(16)
    , @ExtractPublicObjectId int =
          OBJECT_ID(N'toolbelt_archive.USP_ExtractZipEntryFromBinary')
    , @ListPublicObjectId int =
          OBJECT_ID(N'toolbelt_archive.USP_ListZipEntriesFromBinary')
    , @ExtractInternalObjectId int =
          OBJECT_ID(N'toolbelt_archive.TVF_InternalExtractZipEntryClr')
    , @ListInternalObjectId int =
          OBJECT_ID(N'toolbelt_archive.TVF_InternalListZipEntriesClr')
    , @AssemblyId int =
          (
              SELECT assembly_id
              FROM sys.assemblies
              WHERE name = N'Toolbelt_Archive_ZipMemory'
          );

IF @ConfirmNoExternalConsumers IS NULL
    THROW 51336, N'ConfirmNoExternalConsumers muss 0 oder 1 sein.', 1;

IF NOT EXISTS
   (
       SELECT 1
       FROM sys.extended_properties
       WHERE class = 0
         AND major_id = 0
         AND minor_id = 0
         AND name = @VersionProperty
   )
    RETURN;

SELECT @DeploymentMode = TRY_CONVERT(nvarchar(16), value)
FROM sys.extended_properties
WHERE class = 0
  AND major_id = 0
  AND minor_id = 0
  AND name = @ModeProperty;

IF @DeploymentMode = N'central'
   AND @ConfirmNoExternalConsumers <> 1
    THROW 51336, N'Bei zentraler Installation ist ConfirmNoExternalConsumers=1 erforderlich.', 1;

DECLARE @InstalledVersion nvarchar(64)=(SELECT TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty);
DECLARE @OwnWriter bit=CASE WHEN @InstalledVersion IN(N'1.3.0',N'1.4.0') THEN 1 ELSE 0 END;
DECLARE @WriterPublicId int=CASE WHEN @OwnWriter=1 THEN OBJECT_ID(N'toolbelt_archive.USP_CreateZipFromEntries') END,
 @WriterNameId int=CASE WHEN @OwnWriter=1 THEN OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterName') END,
 @WriterArchiveId int=CASE WHEN @OwnWriter=1 THEN OBJECT_ID(N'toolbelt_archive.TVF_InternalZipWriterArchive') END;
IF @OwnWriter=1 AND EXISTS(SELECT 1 FROM sys.objects o WHERE o.object_id IN(@WriterPublicId,@WriterNameId,@WriterArchiveId)
 AND NOT EXISTS(SELECT 1 FROM sys.extended_properties e WHERE e.class=1 AND e.major_id=o.object_id AND e.minor_id=0 AND e.name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(128),e.value)=N'toolbelt.archive.zip-memory'))
 THROW 51338,N'Writerobjekt besitzt keine passende Modulzuordnung.',3;
IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies WHERE referenced_id IN(@WriterPublicId,@WriterNameId,@WriterArchiveId)
 AND referencing_id NOT IN(ISNULL(@WriterPublicId,-1),ISNULL(@WriterNameId,-1),ISNULL(@WriterArchiveId,-1)))
 THROW 51338,N'Der ZIP-Writer wird durch eine same-database Dependency verwendet.',2;

IF EXISTS
   (
       SELECT 1
       FROM sys.sql_expression_dependencies
       WHERE referenced_id IN
             (
                 ISNULL(@ExtractPublicObjectId, -1),
                 ISNULL(@ListPublicObjectId, -1),
                 ISNULL(@ExtractInternalObjectId, -1),
                 ISNULL(@ListInternalObjectId, -1)
             )
         AND referencing_id NOT IN
             (
                 ISNULL(@ExtractPublicObjectId, -1),
                 ISNULL(@ListPublicObjectId, -1),
                 ISNULL(@ExtractInternalObjectId, -1),
                 ISNULL(@ListInternalObjectId, -1)
             )
   )
    THROW 51338, N'Die Deinstallation wird durch eine same-database Dependency blockiert.', 1;

IF @AssemblyId IS NOT NULL
   AND EXISTS
       (
           SELECT 1
           FROM sys.assembly_modules
           WHERE assembly_id = @AssemblyId
             AND object_id NOT IN
                 (
                     ISNULL(@ExtractInternalObjectId, -1),
                     ISNULL(@ListInternalObjectId, -1),
                     ISNULL(@WriterNameId,-1), ISNULL(@WriterArchiveId,-1)
                 )
       )
    THROW 51338, N'Die CLR-ZIP-Assembly wird von einem fremden SQL-Objekt verwendet.', 1;

IF @AssemblyId IS NOT NULL
   AND EXISTS
       (
           SELECT 1
           FROM sys.assembly_references
           WHERE referenced_assembly_id = @AssemblyId
       )
    THROW 51338, N'Die CLR-ZIP-Assembly wird von einer anderen Assembly referenziert.', 1;

BEGIN TRY
    BEGIN TRANSACTION;
    IF @OwnWriter=1 BEGIN
      DROP PROCEDURE IF EXISTS [toolbelt_archive].[USP_CreateZipFromEntries];
      DROP FUNCTION IF EXISTS [toolbelt_archive].[TVF_InternalZipWriterName];
      DROP FUNCTION IF EXISTS [toolbelt_archive].[TVF_InternalZipWriterArchive];
    END;

    DROP PROCEDURE IF EXISTS
        [toolbelt_archive].[USP_ExtractZipEntryFromBinary];

    DROP PROCEDURE IF EXISTS
        [toolbelt_archive].[USP_ListZipEntriesFromBinary];

    DROP FUNCTION IF EXISTS
        [toolbelt_archive].[TVF_InternalExtractZipEntryClr];

    DROP FUNCTION IF EXISTS
        [toolbelt_archive].[TVF_InternalListZipEntriesClr];

    IF EXISTS
       (
           SELECT 1
           FROM sys.assemblies
           WHERE name = N'Toolbelt_Archive_ZipMemory'
       )
        DROP ASSEMBLY [Toolbelt_Archive_ZipMemory];

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0
             AND major_id = 0
             AND minor_id = 0
             AND name = @VersionProperty
       )
        EXEC sys.sp_dropextendedproperty
              @name = @VersionProperty;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0
             AND major_id = 0
             AND minor_id = 0
             AND name = @ModeProperty
       )
        EXEC sys.sp_dropextendedproperty
              @name = @ModeProperty;

    IF SCHEMA_ID(N'toolbelt_archive') IS NOT NULL
       AND NOT EXISTS
           (
               SELECT 1
               FROM sys.objects
               WHERE schema_id = SCHEMA_ID(N'toolbelt_archive')
           )
       AND EXISTS
           (
               SELECT 1
               FROM sys.extended_properties
               WHERE class = 3
                 AND major_id = SCHEMA_ID(N'toolbelt_archive')
                 AND name = N'Toolbelt.Managed'
                 AND TRY_CONVERT(bit, value) = 1
           )
        DROP SCHEMA [toolbelt_archive];

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/*
 * Der serverweite SHA2-512-Trust-Eintrag bleibt absichtlich bestehen. Seine
 * Entfernung ist ein separater administrativer Vorgang, weil derselbe Hash
 * außerhalb dieser Datenbank verwendet werden kann.
 */

GO
:On Error exit
-- RETURN beendet den gesamten ersten Batch; SQLCMD stoppt vor weiteren Batches.
IF @@TRANCOUNT <> 0
BEGIN
    RAISERROR(N'Der Regex-Lifecycle akzeptiert keine Caller-Transaktion.', 16, 1);
    RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @VersionProperty sysname = N'Toolbelt.Module.toolbelt.string.regex.Version',
        @ModeProperty sysname = N'Toolbelt.Module.toolbelt.string.regex.DeploymentMode',
        @InstalledVersion nvarchar(max), @InstalledMode nvarchar(max),
        @Release int, @AssemblyId int, @InstalledAssemblyHash varbinary(64),
        @Pass int = 1, @OwnTransaction bit = 0;
DECLARE @Slots TABLE (Name sysname COLLATE DATABASE_DEFAULT PRIMARY KEY, SinceRelease int NOT NULL,
                      Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL, ObjectId int NULL);
INSERT @Slots(Name, SinceRelease, Kind) VALUES
    (N'SVF_RegexIsMatch', 10, 'FS'),
    (N'SVF_RegexInstr', 10, 'FS'),
    (N'SVF_RegexCount', 10, 'FS'),
    (N'SVF_RegexReplace', 11, 'FN'),
    (N'SVF_RegexSubstring', 11, 'FN'),
    (N'SVF_RegexReplaceCore', 11, 'FS'),
    (N'SVF_RegexSubstringCore', 11, 'FS'),
    (N'TVF_RegexMatches', 12, 'IF'),
    (N'TVF_RegexSplit', 12, 'IF'),
    (N'TVF_RegexMatchesCore', 12, 'FT'),
    (N'TVF_RegexSplitCore', 12, 'FT'),
    (N'TVF_RegexCaptures', 13, 'IF'),
    (N'SVF_RegexReplaceGroups', 13, 'FN'),
    (N'TVF_RegexCapturesCore', 13, 'FT'),
    (N'SVF_RegexReplaceGroupsCore', 13, 'FS');
DECLARE @ConfirmNoExternalConsumers bit = TRY_CONVERT(bit, N'1');
IF @ConfirmNoExternalConsumers IS NULL OR N'1' NOT IN (N'0', N'1')
    THROW 52036, N'ConfirmNoExternalConsumers muss 0 oder 1 sein.', 1;
-- Explizite Offline-Erwartung; niemals aus dem aktuellen Katalog ableiten.
DECLARE @ExpectedInstalledAssemblyHashText nvarchar(max) = N'0xc353c0242a2854baca8996c6e2429b9efa755ee696b8e9497b288c5cdd8252f752b2504c4d84d5a35f419186247636afb3b9d6f73d2e4f93315793037341dcb8',
        @ExpectedInstalledAssemblyHash varbinary(64), @ExpectedAbsence bit = 0;
IF CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText) = CONVERT(varbinary(max), N'0x')
    SET @ExpectedAbsence = 1;
ELSE
BEGIN
    IF @ExpectedInstalledAssemblyHashText IS NULL
       OR DATALENGTH(@ExpectedInstalledAssemblyHashText) <> 260
       OR CONVERT(varbinary(max), LEFT(@ExpectedInstalledAssemblyHashText, 2)) <> CONVERT(varbinary(max), N'0x')
       OR SUBSTRING(@ExpectedInstalledAssemblyHashText, 3, 128) COLLATE Latin1_General_100_BIN2 LIKE N'%[^0-9A-Fa-f]%'
       OR TRY_CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText, 1) IS NULL
       OR DATALENGTH(TRY_CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText, 1)) <> 64
        THROW 52046, N'ExpectedInstalledAssemblyHash muss 0x oder exakt 128 Hexzeichen nach 0x enthalten.', 1;
    SET @ExpectedInstalledAssemblyHash = TRY_CONVERT(varbinary(64), @ExpectedInstalledAssemblyHashText, 1);
END;
BEGIN TRY
    WHILE @Pass <= 2
    BEGIN
        -- Beide Durchläufe lesen den aktuellen Katalog; der zweite läuft unter AppLock.
        SET @InstalledVersion = NULL;
        SET @InstalledMode = NULL;
        SET @AssemblyId = NULL;
        SET @InstalledAssemblyHash = NULL;
        SELECT @InstalledVersion = TRY_CONVERT(nvarchar(max), value)
        FROM sys.extended_properties
        WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @VersionProperty;
        SELECT @InstalledMode = TRY_CONVERT(nvarchar(max), value)
        FROM sys.extended_properties
        WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @ModeProperty;
        SET @Release = CASE CONVERT(varbinary(max), @InstalledVersion)
            WHEN CONVERT(varbinary(max), N'1.0.0') THEN 10
            WHEN CONVERT(varbinary(max), N'1.1.0') THEN 11
            WHEN CONVERT(varbinary(max), N'1.2.0') THEN 12
            WHEN CONVERT(varbinary(max), N'1.3.0') THEN 13 ELSE 0 END;
        IF @Release = 0 AND EXISTS (SELECT 1 FROM sys.extended_properties
            WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @VersionProperty)
            THROW 52032, N'Die installierte Modulversion ist nicht bekannt.', 1;
        SELECT @AssemblyId = a.assembly_id,
               @InstalledAssemblyHash = HASHBYTES(N'SHA2_512', f.content)
        FROM sys.assemblies a LEFT JOIN sys.assembly_files f
          ON f.assembly_id = a.assembly_id AND f.file_id = 1
        WHERE a.name = N'Toolbelt_String_Regex';
        UPDATE s SET ObjectId = o.object_id FROM @Slots s
        LEFT JOIN sys.objects o ON o.schema_id = SCHEMA_ID(N'toolbelt_string') AND o.name COLLATE DATABASE_DEFAULT = s.Name COLLATE DATABASE_DEFAULT;

        IF @Release = 0 AND (@AssemblyId IS NOT NULL OR @InstalledMode IS NOT NULL
            OR EXISTS (SELECT 1 FROM @Slots WHERE ObjectId IS NOT NULL))
            THROW 52033, N'Zielobjekte ohne bekannten Versionsmarker sind fremd belegt.', 7;
        IF @Release > 0 AND (@InstalledMode IS NULL OR
            CONVERT(varbinary(max), @InstalledMode) NOT IN
            (CONVERT(varbinary(max), N'local'), CONVERT(varbinary(max), N'central')))
            THROW 52033, N'Der installierte DeploymentMode ist nicht kohärent.', 1;
        IF SCHEMA_ID(N'toolbelt_string') IS NOT NULL AND
          (NOT EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 3
            AND major_id = SCHEMA_ID(N'toolbelt_string') AND minor_id = 0
            AND name = N'Toolbelt.Managed' AND TRY_CONVERT(int, value) = 1)
           OR NOT EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 3
            AND major_id = SCHEMA_ID(N'toolbelt_string') AND minor_id = 0
            AND name = N'Toolbelt.SchemaCategory'
            AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), value)) = CONVERT(varbinary(max), N'string')))
            THROW 52033, N'Das vorhandene Schema hat keine eigene Toolbelt-Zuordnung.', 2;
        IF @Release > 0 AND EXISTS
          (SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id = s.ObjectId
           WHERE s.SinceRelease <= @Release AND
           (o.object_id IS NULL OR o.type COLLATE DATABASE_DEFAULT <> s.Kind COLLATE DATABASE_DEFAULT
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.Managed'
              AND TRY_CONVERT(int, e.value) = 1)
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleId'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), N'toolbelt.string.regex'))
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleVersion'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), @InstalledVersion))))
            THROW 52033, N'Das installierte Release-Objektmanifest ist nicht kohärent.', 3;
        -- Historische Releasebytes werden explizit gebunden, nicht aus clr_name erschlossen.
        IF @Release = 0 AND @ExpectedAbsence = 0
           OR @Release > 0 AND @ExpectedAbsence = 1
            THROW 52046, N'Die erwartete Assembly-Anwesenheit passt nicht zum geprüften Modulzustand.', 2;
        IF @Release > 0 AND (@InstalledAssemblyHash IS NULL
            OR @InstalledAssemblyHash <> @ExpectedInstalledAssemblyHash)
            THROW 52047, N'Der installierte Assemblyhash entspricht nicht der expliziten Offline-Erwartung.', 1;
        IF @Release > 0 AND (@AssemblyId IS NULL OR @InstalledAssemblyHash IS NULL
          OR NOT EXISTS (SELECT 1 FROM sys.assemblies a WHERE a.assembly_id = @AssemblyId
              AND a.permission_set_desc = N'SAFE_ACCESS' AND a.is_user_defined = 1)
          OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.Managed' AND TRY_CONVERT(int, e.value) = 1)
          OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleId'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), N'toolbelt.string.regex'))
          OR (@Release = 13 AND NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleVersion'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), @InstalledVersion))))
            THROW 52033, N'Die installierte Assembly-Zuordnung ist nicht kohärent.', 4;
        IF EXISTS (SELECT 1 FROM sys.sql_expression_dependencies d
              JOIN @Slots s ON s.ObjectId = d.referenced_id AND s.SinceRelease <= @Release
              WHERE NOT EXISTS (SELECT 1 FROM @Slots own WHERE own.ObjectId = d.referencing_id AND own.SinceRelease <= @Release))
            THROW 52038, N'Eine fremde same-database Dependency blockiert den Lifecycle.', 1;
        IF EXISTS (SELECT 1 FROM sys.assembly_modules m WHERE m.assembly_id = @AssemblyId
              AND NOT EXISTS (SELECT 1 FROM @Slots s WHERE s.ObjectId = m.object_id AND s.SinceRelease <= @Release AND s.Kind IN ('FS', 'FT')))
           OR EXISTS (SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id = @AssemblyId)
            THROW 52038, N'Ein fremder Assembly-Verbraucher blockiert den Lifecycle.', 2;
        IF EXISTS (SELECT 1 FROM @Slots s JOIN sys.assembly_modules m ON m.object_id = s.ObjectId
              WHERE s.SinceRelease <= @Release AND s.Kind IN ('FS', 'FT') AND m.assembly_id <> @AssemblyId)
            THROW 52033, N'Ein CLR-Kern verweist auf eine andere Assembly.', 5;
        IF @Release = 0
        BEGIN
            IF @OwnTransaction = 1 COMMIT TRANSACTION;
            RETURN;
        END;
        IF @InstalledMode = N'central' AND @ConfirmNoExternalConsumers <> 1
            THROW 52036, N'Zentrale Installation benötigt ConfirmNoExternalConsumers=1.', 2;
        IF @Pass = 1
        BEGIN
            BEGIN TRANSACTION;
            SET @OwnTransaction = 1;
            DECLARE @LockResult int;
            EXEC @LockResult = sys.sp_getapplock
                  @Resource = N'toolbelt.deploy.toolbelt.string.regex',
                  @LockMode = N'Exclusive', @LockOwner = N'Transaction',
                  @LockTimeout = 0, @DbPrincipal = N'public';
            IF @LockResult < 0
                THROW 52035, N'Ein paralleler Regex-Lifecycle ist bereits aktiv.', 1;
        END;
        SET @Pass += 1;
    END;
    IF @Release >= 10 DROP FUNCTION [toolbelt_string].[SVF_RegexCount];
    IF @Release >= 10 DROP FUNCTION [toolbelt_string].[SVF_RegexInstr];
    IF @Release >= 10 DROP FUNCTION [toolbelt_string].[SVF_RegexIsMatch];
    IF @Release >= 11 DROP FUNCTION [toolbelt_string].[SVF_RegexReplace];
    IF @Release >= 13 DROP FUNCTION [toolbelt_string].[SVF_RegexReplaceGroups];
    IF @Release >= 11 DROP FUNCTION [toolbelt_string].[SVF_RegexSubstring];
    IF @Release >= 13 DROP FUNCTION [toolbelt_string].[TVF_RegexCaptures];
    IF @Release >= 12 DROP FUNCTION [toolbelt_string].[TVF_RegexMatches];
    IF @Release >= 12 DROP FUNCTION [toolbelt_string].[TVF_RegexSplit];
    IF @Release >= 11 DROP FUNCTION [toolbelt_string].[SVF_RegexReplaceCore];
    IF @Release >= 13 DROP FUNCTION [toolbelt_string].[SVF_RegexReplaceGroupsCore];
    IF @Release >= 11 DROP FUNCTION [toolbelt_string].[SVF_RegexSubstringCore];
    IF @Release >= 13 DROP FUNCTION [toolbelt_string].[TVF_RegexCapturesCore];
    IF @Release >= 12 DROP FUNCTION [toolbelt_string].[TVF_RegexMatchesCore];
    IF @Release >= 12 DROP FUNCTION [toolbelt_string].[TVF_RegexSplitCore];
    DROP ASSEMBLY [Toolbelt_String_Regex];
    EXEC sys.sp_dropextendedproperty @name = @VersionProperty;
    EXEC sys.sp_dropextendedproperty @name = @ModeProperty;
    -- Unbekannte zukünftige Slots und fremde Objekte bleiben erhalten.
    IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE schema_id = SCHEMA_ID(N'toolbelt_string'))
        DROP SCHEMA [toolbelt_string];
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @OwnTransaction = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/* Der serverweite Hash-Trust bleibt ein separater administrativer Lifecycle. */

GO
:On Error exit
DECLARE @Install bit=0,@AssemblyBits varbinary(max)=NULL,@DeploymentMode nvarchar(max)=NULL,
        @ConfirmNoExternalConsumers bit=TRY_CONVERT(bit,N'1');
IF @ConfirmNoExternalConsumers IS NULL OR CONVERT(varbinary(max),N'1') NOT IN(CONVERT(varbinary(max),N'0'),CONVERT(varbinary(max),N'1'))
    THROW 55267,N'ConfirmNoExternalConsumers muss 0 oder 1 sein.',2;
-- Gemeinsamer Lifecycle-Preflight, kein eigenständiger öffentlicher EntryPoint.
-- @Install, @AssemblyBits, @DeploymentMode und @ConfirmNoExternalConsumers
-- werden ausschließlich vom konkreten Deploy-/Uninstall-Adapter gesetzt.
IF @@TRANCOUNT <> 0
BEGIN
    RAISERROR(N'Der Phonetik-Lifecycle akzeptiert keine Caller-Transaktion.',16,1);
    RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
DECLARE @ModuleId nvarchar(128)=N'toolbelt.string.phonetic',
        @VersionProperty sysname=N'Toolbelt.Module.toolbelt.string.phonetic.Version',
        @ModeProperty sysname=N'Toolbelt.Module.toolbelt.string.phonetic.DeploymentMode',
        @InstalledVersion nvarchar(max),@InstalledMode nvarchar(max),
        @Release bit,@AssemblyId int,@InstalledHash varbinary(64),
        @TargetHash varbinary(64)=HASHBYTES(N'SHA2_512',@AssemblyBits),
        @ExpectedHash varbinary(64),@ExpectedAbsent bit=0,
        @ExpectedText nvarchar(max)=N'0xc1155aa10d9fce61ae33cf8e6f6c68528d219db4835d74b3a35e129f851f66e2fca47c99a6f8f74f3d38239f9be84968459366bbfbeb0125c077b61a8d1989e9',
        @Pass int=1,@OwnTransaction bit=0,@SchemaId int,@SchemaOwner int;
DECLARE @Slots TABLE(Name sysname COLLATE DATABASE_DEFAULT PRIMARY KEY,
    Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL,ObjectId int NULL,
    Method sysname NULL,CodeColumns int NOT NULL);
INSERT @Slots VALUES
 (N'TVF_ColognePhonetic','IF',NULL,NULL,1),
 (N'TVF_DoubleMetaphone','IF',NULL,NULL,2),
 (N'TVF_ColognePhoneticCore','FT',NULL,N'EvaluateCologne',1),
 (N'TVF_DoubleMetaphoneCore','FT',NULL,N'EvaluateDoubleMetaphone',2);
IF ISNULL(TRY_CONVERT(int,SERVERPROPERTY(N'ProductMajorVersion')),0) NOT IN(15,16,17)
    THROW 55260,N'Phonetik unterstützt SQL Server 2019,2022,2025.',1;
IF @Install=1 AND (@DeploymentMode IS NULL OR CONVERT(varbinary(max),@DeploymentMode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central')) OR DATALENGTH(@DeploymentMode) NOT IN(10,14))
    THROW 55261,N'DeploymentMode muss local oder central sein.',1;
IF CONVERT(varbinary(max),@ExpectedText)=CONVERT(varbinary(max),N'0x') SET @ExpectedAbsent=1;
ELSE
BEGIN
    IF @ExpectedText IS NULL OR DATALENGTH(@ExpectedText)<>260
       OR CONVERT(varbinary(max),LEFT(@ExpectedText,2))<>CONVERT(varbinary(max),N'0x')
       OR SUBSTRING(@ExpectedText,3,128) COLLATE Latin1_General_100_BIN2 LIKE N'%[^0-9A-Fa-f]%'
       OR DATALENGTH(TRY_CONVERT(varbinary(max),@ExpectedText,1))<>64
       OR TRY_CONVERT(varbinary(max),@ExpectedText,1) IS NULL
        THROW 55262,N'ExpectedInstalledAssemblyHash muss 0x oder ein vollständiger SHA2-512-Hexhash sein.',1;
    SET @ExpectedHash=CONVERT(varbinary(64),@ExpectedText,1);
END;
BEGIN TRY
 WHILE @Pass<=2
 BEGIN
    IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
       OR ISNULL(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies',N'OBJECT',N'SELECT'),0)<>1
        THROW 55263,N'Vollständige Lifecycle-Metadatensicht fehlt; keine Rechtevergabe.',1;
    SET @InstalledVersion=NULL;SET @InstalledMode=NULL;SET @AssemblyId=NULL;SET @InstalledHash=NULL;
    SELECT @InstalledVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty;
    SELECT @InstalledMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@ModeProperty;
    SET @Release=CASE WHEN CONVERT(varbinary(max),@InstalledVersion)=CONVERT(varbinary(max),N'1.0.0') THEN 1 ELSE 0 END;
    SELECT @AssemblyId=a.assembly_id,@InstalledHash=HASHBYTES(N'SHA2_512',f.content)
    FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
    WHERE a.name=N'Toolbelt_String_Phonetic';
    SET @SchemaId=SCHEMA_ID(N'toolbelt_string');
    SET @SchemaOwner=NULL;
    SELECT @SchemaOwner=principal_id FROM sys.schemas WHERE schema_id=@SchemaId;
    UPDATE s SET ObjectId=o.object_id FROM @Slots s LEFT JOIN sys.objects o
        ON o.schema_id=@SchemaId AND o.name COLLATE DATABASE_DEFAULT=s.Name;
    IF @SchemaId IS NOT NULL AND
       (NOT EXISTS(SELECT 1 FROM sys.schemas WHERE schema_id=@SchemaId AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'toolbelt_string'))
        OR @SchemaOwner IS NULL
        OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=@SchemaId AND minor_id=0 AND name=N'Toolbelt.Managed' AND TRY_CONVERT(int,value)=1)
        OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=3 AND major_id=@SchemaId AND minor_id=0 AND name=N'Toolbelt.SchemaCategory' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'string')))
        THROW 55264,N'Das vorhandene Schema ist nicht kohärent zugeordnet.',1;
    IF @Release=0 AND (EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name IN(@VersionProperty,@ModeProperty)) OR @AssemblyId IS NOT NULL OR EXISTS(SELECT 1 FROM @Slots WHERE ObjectId IS NOT NULL))
        THROW 55264,N'Unbekannter Modulzustand oder fremde Zielslotbelegung.',2;
    IF @Release=1 AND (@InstalledMode IS NULL OR CONVERT(varbinary(max),@InstalledMode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central')))
        THROW 55264,N'Der installierte Modus ist inkohärent.',3;
    IF (@Release=0 AND @ExpectedAbsent=0) OR (@Release=1 AND @ExpectedAbsent=1)
        THROW 55262,N'Die erwartete Assembly-Anwesenheit stimmt nicht.',2;
    IF @Release=1 AND (@InstalledHash IS NULL OR @InstalledHash<>@ExpectedHash)
        THROW 55265,N'Der installierte Hash stimmt nicht mit der Offline-Erwartung überein.',1;
    IF @Release=1 AND
      (NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@AssemblyId AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_String_Phonetic') AND permission_set=1 AND is_user_defined=1 AND principal_id=@SchemaOwner)
       OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@AssemblyId)<>1
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.Managed' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'bit' AND TRY_CONVERT(bit,value)=1)
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@ModuleId))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=5 AND major_id=@AssemblyId AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'1.0.0')))
        THROW 55264,N'Assemblytyp, Eigentümer oder Marker sind inkohärent.',4;
    IF @Release=1 AND EXISTS(SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id=s.ObjectId WHERE
       o.object_id IS NULL OR CONVERT(varbinary(max),o.name)<>CONVERT(varbinary(max),s.Name) OR CONVERT(varbinary(2),o.type)<>CONVERT(varbinary(2),s.Kind)
       OR COALESCE(o.principal_id,@SchemaOwner)<>@SchemaOwner
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.Managed' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'bit' AND TRY_CONVERT(bit,value)=1)
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),@ModuleId))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),N'1.0.0'))
       OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=o.object_id AND minor_id=0 AND name=N'Toolbelt.Visibility' AND SQL_VARIANT_PROPERTY(value,N'BaseType')=N'nvarchar' AND CONVERT(varbinary(max),CONVERT(nvarchar(max),value))=CONVERT(varbinary(max),CASE WHEN s.Kind='FT' THEN N'internal' ELSE N'public' END)))
        THROW 55264,N'Slottypen, Eigentümer oder Marker sind inkohärent.',5;
    IF @Release=1 AND EXISTS(SELECT 1 FROM @Slots s WHERE s.Kind='FT' AND NOT EXISTS
       (SELECT 1 FROM sys.assembly_modules m WHERE m.object_id=s.ObjectId AND m.assembly_id=@AssemblyId AND m.null_on_null_input=0 AND m.execute_as_principal_id IS NULL
        AND CONVERT(varbinary(max),m.assembly_class)=CONVERT(varbinary(max),N'Toolbelt.String.Phonetic.PhoneticBridge') AND CONVERT(varbinary(max),m.assembly_method)=CONVERT(varbinary(max),s.Method)))
        THROW 55264,N'Die CLR-EntryPoint-Bindung ist inkohärent.',6;
    IF @Release=1 AND EXISTS(SELECT 1 FROM @Slots s WHERE
       (SELECT COUNT(*) FROM sys.parameters WHERE object_id=s.ObjectId AND parameter_id>0)<>1
       OR NOT EXISTS(SELECT 1 FROM sys.parameters WHERE object_id=s.ObjectId AND parameter_id=1 AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'@Text') AND system_type_id=231 AND user_type_id=system_type_id AND max_length=-1 AND is_output=0 AND has_default_value=0)
       OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=s.ObjectId)<>s.CodeColumns+1
       OR EXISTS(SELECT 1 FROM sys.columns c WHERE c.object_id=s.ObjectId AND
          (c.user_type_id<>c.system_type_id OR
           (c.column_id<=s.CodeColumns AND (c.system_type_id<>CASE WHEN s.Kind='FT' THEN 231 ELSE 167 END OR c.max_length<>-1 OR c.is_nullable<>1 OR CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),CASE WHEN s.CodeColumns=1 THEN N'PhoneticCode' WHEN c.column_id=1 THEN N'PrimaryCode' ELSE N'AlternateCode' END)))
           OR(s.Kind='IF' AND c.column_id<=s.CodeColumns AND CONVERT(varbinary(max),c.collation_name)<>CONVERT(varbinary(max),N'Latin1_General_100_BIN2'))
           OR(c.column_id=s.CodeColumns+1 AND(c.system_type_id<>56 OR c.max_length<>4 OR CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'ErrorCode'))))))
        THROW 55264,N'Parameter oder Ergebnisfelder sind inkohärent.',7;
    IF EXISTS(SELECT 1 FROM sys.sql_expression_dependencies d WHERE
       (EXISTS(SELECT 1 FROM @Slots WHERE ObjectId=d.referenced_id)
        OR(d.referenced_id IS NULL AND (d.referenced_database_name IS NULL OR d.referenced_database_name COLLATE DATABASE_DEFAULT=DB_NAME()) AND d.referenced_schema_name COLLATE DATABASE_DEFAULT=N'toolbelt_string' AND EXISTS(SELECT 1 FROM @Slots WHERE Name=d.referenced_entity_name COLLATE DATABASE_DEFAULT)))
        AND NOT EXISTS(SELECT 1 FROM @Slots WHERE ObjectId=d.referencing_id))
        THROW 55266,N'Ein fremder SQL-Verbraucher blockiert den Lifecycle.',1;
    IF EXISTS(SELECT 1 FROM sys.assembly_modules m WHERE m.assembly_id=@AssemblyId AND NOT EXISTS(SELECT 1 FROM @Slots WHERE Kind='FT' AND ObjectId=m.object_id))
       OR EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@AssemblyId)
        THROW 55266,N'Ein fremder Assembly-Verbraucher blockiert den Lifecycle.',2;
    IF @Install=0 AND @Release=1 AND CONVERT(varbinary(max),@InstalledMode)=CONVERT(varbinary(max),N'central') AND @ConfirmNoExternalConsumers<>1
        THROW 55267,N'Central-Uninstall benötigt explizite Consumerbestätigung.',1;
    IF @Install=1
    BEGIN
       IF @AssemblyBits IS NULL OR DATALENGTH(@AssemblyBits)<1024 OR @TargetHash IS NULL THROW 55268,N'AssemblyBits enthält kein vollständiges Binary.',1;
       IF NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr enabled' AND value_in_use=1)
          OR NOT EXISTS(SELECT 1 FROM sys.configurations WHERE name=N'clr strict security' AND value_in_use=1)
          THROW 55268,N'CLR enabled und strict security müssen bereits wirksam sein.',2;
       IF NOT EXISTS(SELECT 1 FROM sys.trusted_assemblies WHERE hash=@TargetHash) THROW 55268,N'Der exakte Zielhash ist nicht separat autorisiert.',3;
       IF @AssemblyId IS NULL AND @SchemaId IS NOT NULL AND @SchemaOwner<>USER_ID() THROW 55269,N'Neue Assembly und vorhandenes Schema benötigen denselben effektiven Eigentümer.',1;
       IF @SchemaId IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE SCHEMA'),0)<>1 THROW 55269,N'CREATE SCHEMA fehlt.',2;
       IF @SchemaId IS NOT NULL AND ISNULL(HAS_PERMS_BY_NAME(N'toolbelt_string',N'SCHEMA',N'ALTER'),0)<>1 THROW 55269,N'Schema-ALTER fehlt.',3;
       IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE FUNCTION'),0)<>1 THROW 55269,N'CREATE FUNCTION fehlt.',4;
       IF @AssemblyId IS NULL AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE ASSEMBLY'),0)<>1 THROW 55269,N'CREATE ASSEMBLY fehlt.',5;
       IF @AssemblyId IS NOT NULL AND @InstalledHash<>@TargetHash AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'ALTER ANY ASSEMBLY'),0)<>1 THROW 55269,N'ALTER ANY ASSEMBLY fehlt.',6;
    END;
    IF @Pass=1
    BEGIN
       BEGIN TRANSACTION;SET @OwnTransaction=1;
       DECLARE @LockResult int;
       EXEC @LockResult=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.string.phonetic',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
       IF @LockResult<0 THROW 55270,N'Ein paralleler Phonetik-Lifecycle ist aktiv.',1;
    END;
    SET @Pass+=1;
 END;
 IF @Install=1 AND @SchemaId IS NULL
 BEGIN
    EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_string];';
    EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_string';
    EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'string',@level0type=N'SCHEMA',@level0name=N'toolbelt_string';
 END;
 IF @Release=1
 BEGIN
    DROP FUNCTION toolbelt_string.TVF_ColognePhonetic;
    DROP FUNCTION toolbelt_string.TVF_DoubleMetaphone;
    DROP FUNCTION toolbelt_string.TVF_ColognePhoneticCore;
    DROP FUNCTION toolbelt_string.TVF_DoubleMetaphoneCore;
 END;
 IF @Install=1
 BEGIN
    IF @AssemblyId IS NULL OR @InstalledHash<>@TargetHash
    BEGIN
       DECLARE @Ddl nvarchar(max)=CASE WHEN @AssemblyId IS NULL THEN N'CREATE' ELSE N'ALTER' END+N' ASSEMBLY [Toolbelt_String_Phonetic] FROM '+CONVERT(nvarchar(max),@AssemblyBits,1)+N' WITH PERMISSION_SET=SAFE;';
       EXEC sys.sp_executesql @Ddl;
    END;
 END
 ELSE
 BEGIN
    IF @Release=1
    BEGIN
       DROP ASSEMBLY Toolbelt_String_Phonetic;
       EXEC sys.sp_dropextendedproperty @name=@VersionProperty;
       EXEC sys.sp_dropextendedproperty @name=@ModeProperty;
       IF NOT EXISTS(SELECT 1 FROM sys.objects WHERE schema_id=@SchemaId) AND NOT EXISTS(SELECT 1 FROM sys.types WHERE schema_id=@SchemaId AND is_user_defined=1) AND NOT EXISTS(SELECT 1 FROM sys.xml_schema_collections WHERE schema_id=@SchemaId) DROP SCHEMA toolbelt_string;
    END;
    COMMIT TRANSACTION;SET @OwnTransaction=0;
 END;
END TRY
BEGIN CATCH
 IF @OwnTransaction=1 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;

GO
-- Serverweiter Assemblytrust bleibt unverändert.

GO
:On Error exit
-- RETURN beendet den gesamten ersten Batch; SQLCMD stoppt vor weiteren Batches.
IF @@TRANCOUNT <> 0
BEGIN
    RAISERROR(N'Der Editierdistanz-Lifecycle akzeptiert keine Caller-Transaktion.', 16, 1);
    RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @VersionProperty sysname = N'Toolbelt.Module.toolbelt.string.edit-distance.Version',
        @ModeProperty sysname = N'Toolbelt.Module.toolbelt.string.edit-distance.DeploymentMode',
        @InstalledVersion nvarchar(max), @InstalledMode nvarchar(max),
        @Release int, @AssemblyId int, @InstalledAssemblyHash varbinary(64),
        @Pass int = 1, @OwnTransaction bit = 0;
DECLARE @Slots TABLE (Name sysname COLLATE DATABASE_DEFAULT PRIMARY KEY, SinceRelease int NOT NULL,
                      Kind char(2) COLLATE DATABASE_DEFAULT NOT NULL, ObjectId int NULL);
INSERT @Slots(Name, SinceRelease, Kind) VALUES
    (N'TVF_LevenshteinDistance', 10, 'IF'),
    (N'TVF_OsaDistance', 10, 'IF'),
    (N'TVF_LevenshteinDistanceCore', 10, 'FT'),
    (N'TVF_OsaDistanceCore', 10, 'FT'),
    (N'TVF_JaroWinklerSimilarity', 11, 'IF'),
    (N'TVF_JaroWinklerSimilarityCore', 11, 'FT');
DECLARE @ConfirmNoExternalConsumers bit = TRY_CONVERT(bit, N'1');
IF @ConfirmNoExternalConsumers IS NULL OR CONVERT(varbinary(max), N'1') NOT IN (CONVERT(varbinary(max), N'0'), CONVERT(varbinary(max), N'1'))
    THROW 55036, N'ConfirmNoExternalConsumers muss 0 oder 1 sein.', 1;
-- Explizite Offline-Erwartung; niemals aus dem aktuellen Katalog ableiten.
DECLARE @ExpectedInstalledAssemblyHashText nvarchar(max) = N'0xc81e7a841dc0670b850f46d932337f55b6225d2a834d4480ae3d514875b84bf56261ff580df56155a59c0f8a56b6fe54e798d046329f4122e7228467cca90404',
        @ExpectedInstalledAssemblyHash varbinary(64), @ExpectedAbsence bit = 0;
IF CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText) = CONVERT(varbinary(max), N'0x')
    SET @ExpectedAbsence = 1;
ELSE
BEGIN
    IF @ExpectedInstalledAssemblyHashText IS NULL
       OR DATALENGTH(@ExpectedInstalledAssemblyHashText) <> 260
       OR CONVERT(varbinary(max), LEFT(@ExpectedInstalledAssemblyHashText, 2)) <> CONVERT(varbinary(max), N'0x')
       OR SUBSTRING(@ExpectedInstalledAssemblyHashText, 3, 128) COLLATE Latin1_General_100_BIN2 LIKE N'%[^0-9A-Fa-f]%'
       OR TRY_CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText, 1) IS NULL
       OR DATALENGTH(TRY_CONVERT(varbinary(max), @ExpectedInstalledAssemblyHashText, 1)) <> 64
        THROW 55046, N'ExpectedInstalledAssemblyHash muss 0x oder exakt 128 Hexzeichen nach 0x enthalten.', 1;
    SET @ExpectedInstalledAssemblyHash = TRY_CONVERT(varbinary(64), @ExpectedInstalledAssemblyHashText, 1);
END;
BEGIN TRY
    WHILE @Pass <= 2
    BEGIN
        -- Vollständige Metadatensicht wird auch unter dem AppLock neu geprüft.
        IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'VIEW DEFINITION'), 0) <> 1
         OR ISNULL(HAS_PERMS_BY_NAME(N'sys.sql_expression_dependencies', N'OBJECT', N'SELECT'), 0) <> 1
            THROW 55034, N'Vollständige Dependency-Metadatensicht fehlt; keine Rechtevergabe.', 6;
        -- Beide Durchläufe lesen den aktuellen Katalog; der zweite läuft unter AppLock.
        SET @InstalledVersion = NULL;
        SET @InstalledMode = NULL;
        SET @AssemblyId = NULL;
        SET @InstalledAssemblyHash = NULL;
        SELECT @InstalledVersion = TRY_CONVERT(nvarchar(max), value)
        FROM sys.extended_properties
        WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @VersionProperty;
        SELECT @InstalledMode = TRY_CONVERT(nvarchar(max), value)
        FROM sys.extended_properties
        WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @ModeProperty;
        SET @Release = CASE CONVERT(varbinary(max), @InstalledVersion)
            WHEN CONVERT(varbinary(max), N'1.0.0') THEN 10
            WHEN CONVERT(varbinary(max), N'1.1.0') THEN 11 ELSE 0 END;
        IF @Release = 0 AND EXISTS (SELECT 1 FROM sys.extended_properties
            WHERE class = 0 AND major_id = 0 AND minor_id = 0 AND name = @VersionProperty)
            THROW 55032, N'Die installierte Modulversion ist nicht bekannt.', 1;
        SELECT @AssemblyId = a.assembly_id,
               @InstalledAssemblyHash = HASHBYTES(N'SHA2_512', f.content)
        FROM sys.assemblies a LEFT JOIN sys.assembly_files f
          ON f.assembly_id = a.assembly_id AND f.file_id = 1
        WHERE a.name = N'Toolbelt_String_EditDistance';
        UPDATE s SET ObjectId = o.object_id FROM @Slots s
        LEFT JOIN sys.objects o ON o.schema_id = SCHEMA_ID(N'toolbelt_string') AND o.name COLLATE DATABASE_DEFAULT = s.Name COLLATE DATABASE_DEFAULT;

        IF @Release = 0 AND (@AssemblyId IS NOT NULL OR EXISTS (SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@ModeProperty)
            OR EXISTS (SELECT 1 FROM @Slots WHERE ObjectId IS NOT NULL))
            THROW 55033, N'Zielobjekte ohne bekannten Versionsmarker sind fremd belegt.', 7;
        IF @Release > 0 AND (@InstalledMode IS NULL OR
            CONVERT(varbinary(max), @InstalledMode) NOT IN
            (CONVERT(varbinary(max), N'local'), CONVERT(varbinary(max), N'central')))
            THROW 55033, N'Der installierte DeploymentMode ist nicht kohärent.', 1;
        IF SCHEMA_ID(N'toolbelt_string') IS NOT NULL AND
          (NOT EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 3
            AND major_id = SCHEMA_ID(N'toolbelt_string') AND minor_id = 0
            AND name = N'Toolbelt.Managed' AND TRY_CONVERT(int, value) = 1)
           OR NOT EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 3
            AND major_id = SCHEMA_ID(N'toolbelt_string') AND minor_id = 0
            AND name = N'Toolbelt.SchemaCategory'
            AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), value)) = CONVERT(varbinary(max), N'string')))
            THROW 55033, N'Das vorhandene Schema hat keine eigene Toolbelt-Zuordnung.', 2;
        IF @Release > 0 AND EXISTS
          (SELECT 1 FROM @Slots s LEFT JOIN sys.objects o ON o.object_id = s.ObjectId
           WHERE s.SinceRelease <= @Release AND
           (o.object_id IS NULL OR CONVERT(varbinary(max),o.name)<>CONVERT(varbinary(max),s.Name)
            OR o.type COLLATE DATABASE_DEFAULT <> s.Kind COLLATE DATABASE_DEFAULT
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.Managed'
              AND TRY_CONVERT(int, e.value) = 1)
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleId'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), N'toolbelt.string.edit-distance'))
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 1
              AND e.major_id = o.object_id AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleVersion'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), @InstalledVersion))
            OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class=1
              AND e.major_id=o.object_id AND e.minor_id=0 AND e.name=N'Toolbelt.Visibility'
              AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(max),e.value))=
                  CONVERT(varbinary(max),CASE WHEN s.Kind='FT' THEN N'internal' ELSE N'public' END))))
            THROW 55033, N'Das installierte Release-Objektmanifest ist nicht kohärent.', 3;
        -- Historische Releasebytes werden explizit gebunden, nicht aus clr_name erschlossen.
        IF @Release = 0 AND @ExpectedAbsence = 0
           OR @Release > 0 AND @ExpectedAbsence = 1
            THROW 55046, N'Die erwartete Assembly-Anwesenheit passt nicht zum geprüften Modulzustand.', 2;
        IF @Release > 0 AND (@InstalledAssemblyHash IS NULL
            OR @InstalledAssemblyHash <> @ExpectedInstalledAssemblyHash)
            THROW 55047, N'Der installierte Assemblyhash entspricht nicht der expliziten Offline-Erwartung.', 1;
        IF @Release > 0 AND EXISTS
          (SELECT 1 FROM @Slots s JOIN sys.assembly_modules m ON m.object_id=s.ObjectId
           WHERE s.SinceRelease<=@Release AND s.Kind='FT' AND (CONVERT(varbinary(max),m.assembly_class) <> CONVERT(varbinary(max),CASE WHEN s.Name=N'TVF_JaroWinklerSimilarityCore' THEN N'Toolbelt.String.EditDistance.JaroProvider' ELSE N'Toolbelt.String.EditDistance.DistanceProvider' END)
             OR CONVERT(varbinary(max),m.assembly_method) <> CONVERT(varbinary(max),CASE s.Name
                WHEN N'TVF_LevenshteinDistanceCore' THEN N'Levenshtein' WHEN N'TVF_JaroWinklerSimilarityCore' THEN N'Evaluate' ELSE N'Osa' END)
             OR m.null_on_null_input<>0))
            THROW 55033, N'Der CLR-Kern besitzt eine falsche EntryPoint- oder NULL-Bindung.', 8;
        IF @Release > 0 AND EXISTS
          (SELECT 1 FROM @Slots s WHERE s.SinceRelease<=@Release AND
            ((SELECT COUNT(*) FROM sys.parameters p WHERE p.object_id=s.ObjectId AND p.parameter_id>0)
                 <>CASE WHEN s.SinceRelease=11 THEN 3 ELSE 4 END
            OR (SELECT COUNT(*) FROM sys.columns c WHERE c.object_id=s.ObjectId)
                 <>CASE WHEN s.SinceRelease=11 THEN 2 ELSE 3 END
            OR EXISTS(SELECT 1 FROM sys.parameters p WHERE p.object_id=s.ObjectId AND
              (p.user_type_id<>p.system_type_id
               OR (p.parameter_id=1 AND(CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),N'@LeftText') OR TYPE_NAME(p.system_type_id)<>N'nvarchar' OR p.max_length<>-1))
               OR (p.parameter_id=2 AND(CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),N'@RightText') OR TYPE_NAME(p.system_type_id)<>N'nvarchar' OR p.max_length<>-1))
               OR (s.SinceRelease=10 AND p.parameter_id=3 AND(CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),N'@MaxDistance') OR TYPE_NAME(p.system_type_id)<>N'int' OR p.max_length<>4))
               OR (s.SinceRelease=10 AND p.parameter_id=4 AND(CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),N'@Profile') OR TYPE_NAME(p.system_type_id)<>N'nvarchar' OR p.max_length<>-1))
               OR (s.SinceRelease=11 AND p.parameter_id=3 AND(CONVERT(varbinary(max),p.name)<>CONVERT(varbinary(max),N'@Profile') OR TYPE_NAME(p.system_type_id)<>N'nvarchar' OR p.max_length<>-1))))
            OR EXISTS(SELECT 1 FROM sys.columns c WHERE c.object_id=s.ObjectId AND
              (c.user_type_id<>c.system_type_id
               OR (s.SinceRelease=10 AND ((c.column_id=1 AND(CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'Distance') OR TYPE_NAME(c.system_type_id)<>N'int' OR c.max_length<>4))
                 OR(c.column_id=2 AND(CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'ExceedsMaxDistance') OR TYPE_NAME(c.system_type_id)<>N'bit' OR c.max_length<>1))
                 OR(c.column_id=3 AND(CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'ErrorCode') OR TYPE_NAME(c.system_type_id)<>N'int' OR c.max_length<>4))))
               OR (s.SinceRelease=11 AND ((c.column_id=1 AND(CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'Similarity') OR TYPE_NAME(c.system_type_id)<>N'float' OR c.max_length<>8 OR c.precision<>53))
                 OR(c.column_id=2 AND(CONVERT(varbinary(max),c.name)<>CONVERT(varbinary(max),N'ErrorCode') OR TYPE_NAME(c.system_type_id)<>N'int' OR c.max_length<>4))))))))
            THROW 55033, N'Die Parameter-/Resultset-Metadaten des installierten Releases sind nicht kohärent.', 9;
        IF @Release > 0 AND (@AssemblyId IS NULL OR @InstalledAssemblyHash IS NULL
          OR NOT EXISTS (SELECT 1 FROM sys.assemblies a WHERE a.assembly_id = @AssemblyId
              AND a.permission_set_desc = N'SAFE_ACCESS' AND a.is_user_defined = 1)
          OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.Managed' AND TRY_CONVERT(int, e.value) = 1)
          OR NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleId'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), N'toolbelt.string.edit-distance'))
          OR (@Release IN (10,11) AND NOT EXISTS (SELECT 1 FROM sys.extended_properties e WHERE e.class = 5
              AND e.major_id = @AssemblyId AND e.minor_id = 0 AND e.name = N'Toolbelt.ModuleVersion'
              AND CONVERT(varbinary(max), TRY_CONVERT(nvarchar(max), e.value)) = CONVERT(varbinary(max), @InstalledVersion))))
            THROW 55033, N'Die installierte Assembly-Zuordnung ist nicht kohärent.', 4;
        IF EXISTS (SELECT 1 FROM sys.sql_expression_dependencies d
              JOIN @Slots s ON s.ObjectId = d.referenced_id AND s.SinceRelease <= @Release
              WHERE NOT EXISTS (SELECT 1 FROM @Slots own WHERE own.ObjectId = d.referencing_id AND own.SinceRelease <= @Release))
            THROW 55038, N'Eine fremde same-database Dependency blockiert den Lifecycle.', 1;
        IF EXISTS (SELECT 1 FROM sys.assembly_modules m WHERE m.assembly_id = @AssemblyId
              AND NOT EXISTS (SELECT 1 FROM @Slots s WHERE s.ObjectId = m.object_id AND s.SinceRelease <= @Release AND s.Kind IN ('FS', 'FT')))
           OR EXISTS (SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id = @AssemblyId)
            THROW 55038, N'Ein fremder Assembly-Verbraucher blockiert den Lifecycle.', 2;
        IF EXISTS (SELECT 1 FROM @Slots s JOIN sys.assembly_modules m ON m.object_id = s.ObjectId
              WHERE s.SinceRelease <= @Release AND s.Kind IN ('FS', 'FT') AND m.assembly_id <> @AssemblyId)
            THROW 55033, N'Ein CLR-Kern verweist auf eine andere Assembly.', 5;
        IF @Release = 0
        BEGIN
            IF @OwnTransaction = 1 COMMIT TRANSACTION;
            RETURN;
        END;
        IF @InstalledMode = N'central' AND @ConfirmNoExternalConsumers <> 1
            THROW 55036, N'Zentrale Installation benötigt ConfirmNoExternalConsumers=1.', 2;
        IF @Pass = 1
        BEGIN
            BEGIN TRANSACTION;
            SET @OwnTransaction = 1;
            DECLARE @LockResult int;
            EXEC @LockResult = sys.sp_getapplock
                  @Resource = N'toolbelt.deploy.toolbelt.string.edit-distance',
                  @LockMode = N'Exclusive', @LockOwner = N'Transaction',
                  @LockTimeout = 0, @DbPrincipal = N'public';
            IF @LockResult < 0
                THROW 55035, N'Ein paralleler Editierdistanz-Lifecycle ist bereits aktiv.', 1;
        END;
        SET @Pass += 1;
    END;
    IF @Release IN (10,11)
    BEGIN
        IF @Release=11
        BEGIN
            DROP FUNCTION [toolbelt_string].[TVF_JaroWinklerSimilarity];
            DROP FUNCTION [toolbelt_string].[TVF_JaroWinklerSimilarityCore];
        END;
        DROP FUNCTION [toolbelt_string].[TVF_LevenshteinDistance];
        DROP FUNCTION [toolbelt_string].[TVF_OsaDistance];
        DROP FUNCTION [toolbelt_string].[TVF_LevenshteinDistanceCore];
        DROP FUNCTION [toolbelt_string].[TVF_OsaDistanceCore];
    END;
    DROP ASSEMBLY [Toolbelt_String_EditDistance];
    EXEC sys.sp_dropextendedproperty @name = @VersionProperty;
    EXEC sys.sp_dropextendedproperty @name = @ModeProperty;
    -- Unbekannte zukünftige Slots und fremde Objekte bleiben erhalten.
    IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE schema_id = SCHEMA_ID(N'toolbelt_string'))
        DROP SCHEMA [toolbelt_string];
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @OwnTransaction = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/* Der serverweite Hash-Trust bleibt ein separater administrativer Lifecycle. */

GO
:On Error exit
IF @@TRANCOUNT>0
BEGIN
 RAISERROR(N'JSON_CORE_CALLER_TRANSACTION: aktive Callertransaktion ausgeschlossen.',16,1);
 RETURN;
END;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @Confirmation nvarchar(max)=N'1',@Pass int=0,@Lock int,@InitialId int,@InitialOwner int,@InitialMode varbinary(max);
-- Qualifizierte Offline-Corezeile; keine Trustfreigabe und keine Runtimeableitung.
DECLARE @JsonCoreKnownHash varbinary(64)=0x4680e9d34a0870924b5ca003cc5983882fc8ffb653e702bcc549e5f65dde11934c55ba7b356b519503ac5ce1e2478fe64876fea0295176ff13b5b4a6ab61b894,
 @JsonCoreArtifactId varchar(64)='975d4a84bb86e80b6e5844d6e86785ae0e98b13ee44c0f66c021507a23e0f888',
 @JsonCoreId int,@JsonCoreOwner int,@JsonCoreHash varbinary(64),
 @JsonCoreVersion nvarchar(max),@JsonCoreStoredMode nvarchar(max),
 @JsonCoreExpectedMode nvarchar(max),@JsonCoreRequired bit=1,@JsonCoreRemoving bit=0;
DECLARE @JsonCoreMarkers TABLE(Name sysname PRIMARY KEY,Value sql_variant NOT NULL);

IF CONVERT(varbinary(max),@Confirmation) NOT IN(CONVERT(varbinary(max),N'0'),CONVERT(varbinary(max),N'1'))
 THROW 55625,N'JSON Core: ungültige Consumer-Bestätigung.',1;
SELECT @JsonCoreRemoving=1,@JsonCoreRequired=0;
BEGIN TRY
 WHILE @Pass<2
 BEGIN
  IF COALESCE(TRY_CONVERT(int,SERVERPROPERTY(N'ProductMajorVersion')),0) NOT IN(15,16,17)
   OR COALESCE((SELECT compatibility_level FROM sys.databases WHERE database_id=DB_ID()),0)<150
   THROW 55620,N'JSON Core: SQL-Version oder Compatibility Level nicht unterstützt.',1;
  SELECT @JsonCoreExpectedMode=NULL;
  SELECT @JsonCoreExpectedMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
   WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode';
  IF @JsonCoreExpectedMode IS NOT NULL AND CONVERT(varbinary(max),@JsonCoreExpectedMode) NOT IN(CONVERT(varbinary(max),N'local'),CONVERT(varbinary(max),N'central'))
   THROW 55623,N'JSON Core: inkohärenter installierter Modus.',1;
-- Pure SQLCMD-Include: keine Helper-USP, Mutation, Trust- oder Ownerreparatur.
-- KnownArtifact.sql deklariert den Scope. Aufruf vor/unter der gemeinsamen Lock.
IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_files',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_modules',N'OBJECT',N'SELECT'),0)<>1
 OR COALESCE(HAS_PERMS_BY_NAME(N'sys.assembly_references',N'OBJECT',N'SELECT'),0)<>1
 THROW 55622,N'JSON Core: vollständige Assemblymetadatensicht fehlt.',1;
SELECT @JsonCoreId=NULL,@JsonCoreOwner=NULL,@JsonCoreHash=NULL,@JsonCoreVersion=NULL,@JsonCoreStoredMode=NULL;
SELECT @JsonCoreVersion=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.Version';
SELECT @JsonCoreStoredMode=TRY_CONVERT(nvarchar(max),value) FROM sys.extended_properties
 WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode';
SELECT @JsonCoreId=a.assembly_id,@JsonCoreOwner=a.principal_id,@JsonCoreHash=HASHBYTES(N'SHA2_512',f.content)
 FROM sys.assemblies a LEFT JOIN sys.assembly_files f ON f.assembly_id=a.assembly_id AND f.file_id=1
 WHERE a.name=N'Toolbelt_JsonCore';
IF @JsonCoreId IS NULL
BEGIN
 IF @JsonCoreRequired=1 OR EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0
  AND name IN(N'Toolbelt.Module.toolbelt.json.core.Version',N'Toolbelt.Module.toolbelt.json.core.DeploymentMode'))
  THROW 55623,N'JSON Core: erforderliche bekannte Dependency fehlt oder ist inkohärent.',1;
END
ELSE
BEGIN
 IF @JsonCoreVersion IS NULL OR CONVERT(varbinary(max),@JsonCoreVersion)<>CONVERT(varbinary(max),N'1.0.0')
  OR @JsonCoreStoredMode IS NULL OR CONVERT(varbinary(max),@JsonCoreStoredMode)<>CONVERT(varbinary(max),@JsonCoreExpectedMode)
  OR @JsonCoreHash IS NULL OR @JsonCoreHash<>@JsonCoreKnownHash
  OR NOT EXISTS(SELECT 1 FROM sys.assemblies WHERE assembly_id=@JsonCoreId AND is_user_defined=1 AND permission_set=1 AND is_visible=0
   AND CONVERT(varbinary(max),name)=CONVERT(varbinary(max),N'Toolbelt_JsonCore'))
  OR (SELECT COUNT(*) FROM sys.assembly_files WHERE assembly_id=@JsonCoreId)<>1
  THROW 55623,N'JSON Core: keine kohärente bekannte technische SAFE-Assembly.',1;
 DELETE FROM @JsonCoreMarkers;
 INSERT @JsonCoreMarkers VALUES
 (N'Toolbelt.Managed',CONVERT(sql_variant,CONVERT(int,1))),
 (N'Toolbelt.ModuleId',CONVERT(sql_variant,CONVERT(nvarchar(64),N'toolbelt.json.core'))),
 (N'Toolbelt.ModuleVersion',CONVERT(sql_variant,CONVERT(nvarchar(16),N'1.0.0'))),
 (N'Toolbelt.DeploymentMode',CONVERT(sql_variant,CONVERT(nvarchar(16),@JsonCoreExpectedMode))),
 (N'Toolbelt.AssemblySha512',CONVERT(sql_variant,@JsonCoreKnownHash)),
 (N'Toolbelt.ArtifactId',CONVERT(sql_variant,@JsonCoreArtifactId));
 IF EXISTS(SELECT 1 FROM @JsonCoreMarkers expected WHERE NOT EXISTS(SELECT 1 FROM sys.extended_properties e
  WHERE e.class=5 AND e.major_id=@JsonCoreId AND e.minor_id=0 AND e.name=expected.Name
   AND SQL_VARIANT_PROPERTY(e.value,N'BaseType')=SQL_VARIANT_PROPERTY(expected.Value,N'BaseType')
   AND SQL_VARIANT_PROPERTY(e.value,N'MaxLength')=SQL_VARIANT_PROPERTY(expected.Value,N'MaxLength')
   AND DATALENGTH(e.value)=DATALENGTH(expected.Value)
   AND CONVERT(varbinary(max),e.value)=CONVERT(varbinary(max),expected.Value)))
  THROW 55623,N'JSON Core: typisiertes bekanntes Markertuple ist inkohärent.',1;
 -- Die technische Dependency stellt keine eigenen oder fremden SQL-Slots bereit.
 IF EXISTS(SELECT 1 FROM sys.assembly_modules WHERE assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: direkter SQL-Verbraucher blockiert den technischen Corevertrag.',1;
 IF @JsonCoreRemoving=1 AND EXISTS(SELECT 1 FROM sys.assembly_references WHERE referenced_assembly_id=@JsonCoreId)
  THROW 55626,N'JSON Core: verbleibende Assemblyverbraucher blockieren den Abbau.',1;
END;

  IF @Pass=0 AND @JsonCoreId IS NULL RETURN;
  IF CONVERT(varbinary(max),@JsonCoreExpectedMode)=CONVERT(varbinary(max),N'central') AND @Confirmation=N'0'
   THROW 55625,N'JSON Core: zentrale Consumer-Bestätigung fehlt.',1;
  IF @Pass=1 AND (COALESCE(@JsonCoreId,-1)<>@InitialId OR COALESCE(@JsonCoreOwner,-1)<>@InitialOwner
   OR COALESCE(CONVERT(varbinary(max),@JsonCoreExpectedMode),0x)<>@InitialMode)
   THROW 55627,N'JSON Core: Assemblyidentität hat sich unter Lock verändert.',1;
  IF COALESCE(HAS_PERMS_BY_NAME(N'Toolbelt_JsonCore',N'ASSEMBLY',N'ALTER'),0)<>1
   THROW 55622,N'JSON Core: vorhandenes Assembly-ALTER-Recht fehlt.',1;
  IF @Pass=0
  BEGIN
   SELECT @InitialId=@JsonCoreId,@InitialOwner=@JsonCoreOwner,@InitialMode=CONVERT(varbinary(max),@JsonCoreExpectedMode);
   BEGIN TRANSACTION;
   EXEC @Lock=sys.sp_getapplock @Resource=N'toolbelt.deploy.json.shared-core',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
   IF @Lock IS NULL OR @Lock<0 THROW 55627,N'JSON Core: gemeinsame AppLock nicht verfügbar.',1;
  END;
  SET @Pass+=1;
 END;
 DROP ASSEMBLY [Toolbelt_JsonCore] WITH NO DEPENDENTS;
 EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.json.core.Version';
 EXEC sys.sp_dropextendedproperty @name=N'Toolbelt.Module.toolbelt.json.core.DeploymentMode';
 COMMIT;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
GO

GO
:On Error exit

-- ============================================================================
-- Zweck:     Kontrollierte Deinstallation von Result Table Infrastructure
-- Modul:     toolbelt.core.result-table
-- Modus:     SQLCMD
-- Hinweis:   Bei zentraler Installation muss ConfirmNoExternalConsumers=1
--            ausdrücklich bestätigen, dass keine externen Aufrufer verbleiben.
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @ConfirmNoExternalConsumers bit =
          TRY_CONVERT(bit, N'1')
    , @VersionPropertyName sysname =
          N'Toolbelt.Module.toolbelt.core.result-table.Version'
    , @ModePropertyName sysname =
          N'Toolbelt.Module.toolbelt.core.result-table.DeploymentMode'
    , @InstalledVersion nvarchar(64)
    , @DeploymentMode nvarchar(16)
    , @ProcedureId int
    , @ReferencingSchema sysname
    , @ReferencingObject sysname;

IF @ConfirmNoExternalConsumers IS NULL
BEGIN
    THROW 51035, N'Die SQLCMD-Variable ConfirmNoExternalConsumers muss 0 oder 1 sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

SELECT @DeploymentMode = TRY_CONVERT(nvarchar(16), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @ModePropertyName;

IF @InstalledVersion IS NULL
BEGIN
    PRINT N'toolbelt.core.result-table ist nicht als installiert registriert; keine Änderung erforderlich.';
    RETURN;
END;

IF @InstalledVersion COLLATE Latin1_General_100_BIN2 <> N'1.0.0'
BEGIN
    THROW 51033, N'Die installierte Modulversion ist diesem Uninstall-Skript nicht bekannt.', 1;
END;

IF @DeploymentMode NOT IN (N'local', N'central')
BEGIN
    THROW 51033, N'Der registrierte Deployment-Modus fehlt oder ist ungültig.', 1;
END;

IF @DeploymentMode = N'central' AND @ConfirmNoExternalConsumers <> 1
BEGIN
    THROW 51035, N'Bei zentraler Installation ist ConfirmNoExternalConsumers=1 als ausdrückliche Betreiberbestätigung erforderlich.', 1;
END;

SET @ProcedureId = OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable');

/*
 * SQL Server kann nur statische same-database Dependencies zuverlässig
 * ermitteln. Dynamische und externe dreiteilige Aufrufer erklären das
 * zusätzliche Confirm-Gate für zentrale Installationen.
 */
IF @ProcedureId IS NOT NULL
BEGIN
    SELECT TOP (1)
          @ReferencingSchema = OBJECT_SCHEMA_NAME(sed.referencing_id)
        , @ReferencingObject = OBJECT_NAME(sed.referencing_id)
    FROM sys.sql_expression_dependencies AS sed
    WHERE sed.referenced_id = @ProcedureId
      AND sed.referencing_id <> @ProcedureId
    ORDER BY
          OBJECT_SCHEMA_NAME(sed.referencing_id) COLLATE Latin1_General_100_BIN2
        , OBJECT_NAME(sed.referencing_id) COLLATE Latin1_General_100_BIN2;
END;

IF @ReferencingObject IS NOT NULL
BEGIN
    DECLARE @DependencyMessage nvarchar(2048) =
        N'Die Deinstallation wird durch same-database Dependency '
        + COALESCE(QUOTENAME(@ReferencingSchema), N'<ohne Schema>')
        + N'.'
        + COALESCE(QUOTENAME(@ReferencingObject), N'<unbekannt>')
        + N' blockiert.';
    SET @DependencyMessage = REPLACE(@DependencyMessage, N'%', N'%%');
    THROW 51036, @DependencyMessage, 1;
END;

/*
 * Der Preflight ist abgeschlossen. Das Release-Manifest von 1.0.0 enthält
 * genau toolbelt_core.USP_PrepareResultTable. Andere Objekte werden durch
 * dieses Skript nie ausgewählt.
 */
BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE @LockResult int;

    EXEC @LockResult = sys.sp_getapplock
          @Resource    = N'toolbelt.deploy.toolbelt.core.result-table'
        , @LockMode    = N'Exclusive'
        , @LockOwner   = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
    BEGIN
        THROW 51037, N'Ein paralleles Deployment von toolbelt.core.result-table ist bereits aktiv.', 1;
    END;

    DECLARE @CurrentInstalledVersion nvarchar(64);

    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
           <> @InstalledVersion COLLATE Latin1_General_100_BIN2
    BEGIN
        THROW 51037, N'Der installierte Modulstand hat sich seit dem Uninstall-Preflight verändert.', 1;
    END;

    SET @ProcedureId = OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable');

    IF @ProcedureId IS NOT NULL
    BEGIN
        DECLARE @ActualType char(2);

        SELECT @ActualType = o.type
        FROM sys.objects AS o
        WHERE o.object_id = @ProcedureId;

        IF @ActualType IN ('P', 'PC')
        BEGIN
            DROP PROCEDURE [toolbelt_core].[USP_PrepareResultTable];
        END;
        ELSE IF @ActualType = 'V'
        BEGIN
            DROP VIEW [toolbelt_core].[USP_PrepareResultTable];
        END;
        ELSE IF @ActualType IN ('FN', 'FS', 'FT', 'IF', 'TF')
        BEGIN
            DROP FUNCTION [toolbelt_core].[USP_PrepareResultTable];
        END;
        ELSE
        BEGIN
            THROW 51033, N'Das Release-Objekt besitzt einen nicht unterstützten lokal veränderten Objekttyp.', 1;
        END;
    END;

    EXEC sys.sp_dropextendedproperty @name = @VersionPropertyName;
    EXEC sys.sp_dropextendedproperty @name = @ModePropertyName;

    DECLARE
          @SchemaId int = SCHEMA_ID(N'toolbelt_core')
        , @SchemaManaged int
        , @SchemaCategory nvarchar(128);

    IF @SchemaId IS NOT NULL
    BEGIN
        SELECT
              @SchemaManaged = MAX
              (
                  CASE
                      WHEN ep.name = N'Toolbelt.Managed'
                          THEN TRY_CONVERT(int, ep.value)
                  END
              )
            , @SchemaCategory = MAX
              (
                  CASE
                      WHEN ep.name = N'Toolbelt.SchemaCategory'
                          THEN TRY_CONVERT(nvarchar(128), ep.value)
                  END
              )
        FROM sys.extended_properties AS ep
        WHERE ep.class = 3
          AND ep.major_id = @SchemaId
          AND ep.minor_id = 0;

        /*
         * Ein vor der Installation vorhandenes unmarkiertes Schema wird nicht
         * adoptiert und folglich niemals entfernt. Ein vom Toolbelt angelegtes
         * Schema darf nur in vollständig leerem Zustand verschwinden.
         */
        IF ISNULL(@SchemaManaged, 0) = 1
           AND ISNULL(@SchemaCategory, N'') COLLATE Latin1_General_100_BIN2 = N'core'
           AND NOT EXISTS
               (
                   SELECT 1
                   FROM sys.objects AS o
                   WHERE o.schema_id = @SchemaId
               )
           AND NOT EXISTS
               (
                   SELECT 1
                   FROM sys.types AS t
                   WHERE t.schema_id = @SchemaId
                     AND t.is_user_defined = 1
               )
           AND NOT EXISTS
               (
                   SELECT 1
                   FROM sys.xml_schema_collections AS xsc
                   WHERE xsc.schema_id = @SchemaId
                     AND xsc.xml_collection_id > 0
               )
        BEGIN
            DROP SCHEMA [toolbelt_core];
        END;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO

GO
