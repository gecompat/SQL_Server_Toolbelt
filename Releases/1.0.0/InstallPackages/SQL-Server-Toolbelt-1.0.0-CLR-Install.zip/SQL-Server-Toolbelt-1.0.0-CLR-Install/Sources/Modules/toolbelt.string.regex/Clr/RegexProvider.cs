using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.SqlServer.Server;
using DotNetRegex = System.Text.RegularExpressions.Regex;

namespace Toolbelt.String.Regex
{
    /// <summary>
    /// SAFE SQL CLR provider for the deliberately small Toolbelt regex dialect.
    /// The parser accepts only the documented grammar and translates ASCII
    /// shorthand classes before invoking the .NET Framework regex engine.
    /// </summary>
    public static partial class RegexProvider
    {
        private const int MaxInputCodeUnits = 1048576;
        private const int MaxPatternBytes = 8000;
        private const int MaxQuantifier = 1000;
        private static readonly TimeSpan MatchTimeout =
            TimeSpan.FromMilliseconds(250);

        public static SqlBoolean RegexIsMatch(
            SqlString input,
            SqlString pattern,
            SqlString flags)
        {
            if (input.IsNull || pattern.IsNull)
            {
                return SqlBoolean.Null;
            }

            string value = ValidateInput(input.Value);
            DotNetRegex regex = CreateRegex(pattern.Value, flags);
            try
            {
                return new SqlBoolean(regex.IsMatch(value));
            }
            catch (RegexMatchTimeoutException)
            {
                throw Error(
                    "TBX_REGEX_TIMEOUT",
                    "Die feste Ausführungsgrenze von 250 ms wurde überschritten.");
            }
        }

        public static SqlInt32 RegexInstr(
            SqlString input,
            SqlString pattern,
            SqlInt32 start,
            SqlInt32 occurrence,
            SqlInt32 returnOption,
            SqlString flags)
        {
            if (input.IsNull || pattern.IsNull)
            {
                return SqlInt32.Null;
            }
            if (start.IsNull || start.Value < 1)
            {
                throw Error(
                    "TBX_REGEX_INVALID_ARGUMENT",
                    "Start muss mindestens 1 sein.");
            }
            if (occurrence.IsNull || occurrence.Value < 1)
            {
                throw Error(
                    "TBX_REGEX_INVALID_ARGUMENT",
                    "Occurrence muss mindestens 1 sein.");
            }
            if (returnOption.IsNull ||
                (returnOption.Value != 0 && returnOption.Value != 1))
            {
                throw Error(
                    "TBX_REGEX_INVALID_ARGUMENT",
                    "ReturnOption muss 0 für Start oder 1 für Ende-exklusiv sein.");
            }

            string value = ValidateInput(input.Value);
            if (start.Value > value.Length + 1)
            {
                return new SqlInt32(0);
            }

            R1Traversal traversal = new R1Traversal(pattern.Value, flags);
            try
            {
                Match match = traversal.Search(value, start.Value - 1);
                int current = 1;
                while (match.Success && current < occurrence.Value)
                {
                    match = traversal.Next(value, match);
                    current++;
                }
                if (!match.Success)
                {
                    return new SqlInt32(0);
                }

                int position = returnOption.Value == 0
                    ? match.Index + 1
                    : match.Index + match.Length + 1;
                return new SqlInt32(position);
            }
            catch (RegexMatchTimeoutException)
            {
                throw Error(
                    "TBX_REGEX_TIMEOUT",
                    "Die feste Ausführungsgrenze von 250 ms wurde überschritten.");
            }
        }

        public static SqlInt32 RegexCount(
            SqlString input,
            SqlString pattern,
            SqlInt32 start,
            SqlString flags)
        {
            if (input.IsNull || pattern.IsNull)
            {
                return SqlInt32.Null;
            }
            if (start.IsNull || start.Value < 1)
            {
                throw Error(
                    "TBX_REGEX_INVALID_ARGUMENT",
                    "Start muss mindestens 1 sein.");
            }

            string value = ValidateInput(input.Value);
            if (start.Value > value.Length + 1)
            {
                return new SqlInt32(0);
            }

            R1Traversal traversal = new R1Traversal(pattern.Value, flags);
            try
            {
                int count = 0;
                Match match = traversal.Search(value, start.Value - 1);
                while (match.Success)
                {
                    checked
                    {
                        count++;
                    }
                    match = traversal.Next(value, match);
                }
                return new SqlInt32(count);
            }
            catch (RegexMatchTimeoutException)
            {
                throw Error(
                    "TBX_REGEX_TIMEOUT",
                    "Die feste Ausführungsgrenze von 250 ms wurde überschritten.");
            }
        }

        private sealed class R1Traversal
        {
            private readonly Stopwatch clock = Stopwatch.StartNew();
            private DotNetRegex regex;
            private int timeout = 250, successful;
            internal R1Traversal(string pattern, SqlString flags)
            { regex = CreateRegex(pattern, flags); Remaining(); }
            private int Remaining()
            {
                long left = 500 - clock.ElapsedMilliseconds;
                if (left <= 0) throw Error("TBX_REGEX_TIMEOUT", "Das Gesamtbudget von 500 ms wurde überschritten.");
                return (int)left;
            }
            internal Match Search(string value, int cursor)
            {
                while (timeout > Remaining())
                {
                    timeout = Math.Max(1, Remaining() / 2);
                    regex = new DotNetRegex(regex.ToString(), regex.Options, TimeSpan.FromMilliseconds(timeout));
                }
                Match match = regex.Match(value, cursor); Remaining();
                if (match.Success && ++successful > 100000)
                    throw Error("TBX_REGEX_MATCH_LIMIT", "Höchstens 100000 erfolgreiche Matchschritte sind erlaubt.");
                return match;
            }
            internal Match Next(string value, Match previous)
            {
                Remaining();
                int cursor = previous.Index + previous.Length + (previous.Length == 0 ? 1 : 0);
                return cursor > value.Length ? Match.Empty : Search(value, cursor);
            }
        }

        private static string ValidateInput(string input)
        {
            if (input.Length > MaxInputCodeUnits)
            {
                throw Error(
                    "TBX_REGEX_INPUT_TOO_LARGE",
                    "Input darf höchstens 2 MiB UTF-16-Daten enthalten.");
            }
            return input;
        }

        private static DotNetRegex CreateRegex(string pattern, SqlString flags)
        {
            if (checked(pattern.Length * 2) > MaxPatternBytes)
            {
                throw Error(
                    "TBX_REGEX_PATTERN_TOO_LARGE",
                    "Pattern darf höchstens 8000 UTF-16-Bytes enthalten.");
            }

            RegexOptions options = ParseOptions(flags);
            string translated = TranslatePattern(
                pattern,
                (options & RegexOptions.Multiline) != 0,
                (options & RegexOptions.IgnoreCase) != 0);
            try
            {
                return new DotNetRegex(translated, options, MatchTimeout);
            }
            catch (ArgumentException)
            {
                throw Error(
                    "TBX_REGEX_INVALID_PATTERN",
                    "Pattern ist im Toolbelt-Dialekt ungültig.");
            }
        }

        private static RegexOptions ParseOptions(SqlString flags)
        {
            if (flags.IsNull)
            {
                throw Error(
                    "TBX_REGEX_INVALID_FLAGS",
                    "Flags dürfen nicht NULL sein.");
            }

            bool caseSensitive = false;
            bool ignoreCase = false;
            bool multiline = false;
            bool singleline = false;
            foreach (char flag in flags.Value)
            {
                switch (flag)
                {
                    case 'c':
                        if (caseSensitive) throw DuplicateFlag();
                        caseSensitive = true;
                        break;
                    case 'i':
                        if (ignoreCase) throw DuplicateFlag();
                        ignoreCase = true;
                        break;
                    case 'm':
                        if (multiline) throw DuplicateFlag();
                        multiline = true;
                        break;
                    case 's':
                        if (singleline) throw DuplicateFlag();
                        singleline = true;
                        break;
                    default:
                        throw Error(
                            "TBX_REGEX_INVALID_FLAGS",
                            "Erlaubt sind ausschließlich c, i, m und s.");
                }
            }
            if (caseSensitive && ignoreCase)
            {
                throw Error(
                    "TBX_REGEX_INVALID_FLAGS",
                    "c und i schließen einander aus.");
            }

            RegexOptions options = RegexOptions.CultureInvariant;
            if (ignoreCase) options |= RegexOptions.IgnoreCase;
            if (multiline) options |= RegexOptions.Multiline;
            if (singleline) options |= RegexOptions.Singleline;
            return options;
        }

        private static InvalidOperationException DuplicateFlag()
        {
            return Error(
                "TBX_REGEX_INVALID_FLAGS",
                "Flags dürfen nicht doppelt vorkommen.");
        }

        private static string TranslatePattern(
            string pattern,
            bool multiline,
            bool ignoreCase)
        {
            return TranslatePattern(pattern, multiline, ignoreCase, null);
        }

        private static string TranslatePattern(string pattern, bool multiline,
            bool ignoreCase, CapturePlan captures)
        {
            var output = new StringBuilder(pattern.Length + 16);
            var frames = captures == null ? null : new Stack<CaptureFrame>();
            CaptureFrame frame = captures == null ? null : new CaptureFrame(captures);
            var parentBranches = new Stack<bool>();
            bool branchHasTerm = false;
            bool canQuantify = false;

            for (int index = 0; index < pattern.Length; index++)
            {
                char current = pattern[index];
                switch (current)
                {
                    case '\\':
                        AppendEscape(
                            pattern,
                            ref index,
                            output,
                            false,
                            ignoreCase);
                        if (frame != null) frame.Add(new CaptureSummary(1, 0));
                        branchHasTerm = true;
                        canQuantify = true;
                        break;
                    case '[':
                        AppendCharacterClass(
                            pattern,
                            ref index,
                            output,
                            ignoreCase);
                        if (frame != null) frame.Add(new CaptureSummary(1, 0));
                        branchHasTerm = true;
                        canQuantify = true;
                        break;
                    case '(':
                        parentBranches.Push(branchHasTerm);
                        if (captures == null) output.Append("(?:");
                        else
                        {
                            CaptureDeclaration declaration = captures.Declare(pattern, ref index);
                            output.Append("(?<").Append(declaration.EngineName).Append('>');
                            frames.Push(frame);
                            frame = new CaptureFrame(captures);
                        }
                        branchHasTerm = false;
                        canQuantify = false;
                        break;
                    case ')':
                        if (parentBranches.Count == 0 || !branchHasTerm)
                        {
                            throw InvalidPattern();
                        }
                        output.Append(')');
                        parentBranches.Pop();
                        if (frame != null)
                        {
                            CaptureSummary summary = frame.Finish();
                            summary.History = captures.HistoryAdd(summary.History, 1);
                            frame = frames.Pop();
                            frame.Add(summary);
                        }
                        branchHasTerm = true;
                        canQuantify = true;
                        break;
                    case '|':
                        if (!branchHasTerm)
                        {
                            throw InvalidPattern();
                        }
                        output.Append('|');
                        if (frame != null) frame.Alternate();
                        branchHasTerm = false;
                        canQuantify = false;
                        break;
                    case '?':
                    case '*':
                    case '+':
                        if (!canQuantify)
                        {
                            throw InvalidPattern();
                        }
                        output.Append(current);
                        if (frame != null) frame.Quantify(current == '+' ? 1 : 0, current == '?' ? 1 : -1);
                        canQuantify = false;
                        break;
                    case '{':
                        if (!canQuantify)
                        {
                            throw InvalidPattern();
                        }
                        int minimum, maximum;
                        AppendBoundedQuantifier(pattern, ref index, output, out minimum, out maximum);
                        if (frame != null) frame.Quantify(minimum, maximum);
                        canQuantify = false;
                        break;
                    case '^':
                        output.Append('^');
                        if (frame != null) frame.Add(new CaptureSummary(0, 0));
                        branchHasTerm = true;
                        canQuantify = false;
                        break;
                    case '$':
                        output.Append(multiline ? "$" : "\\z");
                        if (frame != null) frame.Add(new CaptureSummary(0, 0));
                        branchHasTerm = true;
                        canQuantify = false;
                        break;
                    case '.':
                        output.Append('.');
                        if (frame != null) frame.Add(new CaptureSummary(1, 0));
                        branchHasTerm = true;
                        canQuantify = true;
                        break;
                    case ']':
                    case '}':
                        throw InvalidPattern();
                    default:
                        output.Append(DotNetRegex.Escape(current.ToString()));
                        if (frame != null) frame.Add(new CaptureSummary(1, 0));
                        branchHasTerm = true;
                        canQuantify = true;
                        break;
                }
            }

            if (parentBranches.Count != 0 ||
                (pattern.Length != 0 && !branchHasTerm))
            {
                throw InvalidPattern();
            }
            if (frame != null) captures.ValidateHistory(frame.Finish());
            return output.ToString();
        }

        private static void AppendEscape(
            string pattern,
            ref int index,
            StringBuilder output,
            bool inClass,
            bool ignoreCase)
        {
            if (++index >= pattern.Length)
            {
                throw InvalidPattern();
            }
            char escaped = pattern[index];
            switch (escaped)
            {
                case 'd': output.Append(inClass ? "0-9" : "[0-9]"); return;
                case 's': output.Append(inClass ? "\\x09-\\x0D\\x20" : "[\\x09-\\x0D\\x20]"); return;
                case 'w':
                    if (inClass)
                    {
                        output.Append("A-Za-z0-9_");
                    }
                    else
                    {
                        output.Append(ignoreCase
                            ? "(?-i:[A-Za-z0-9_])"
                            : "[A-Za-z0-9_]");
                    }
                    return;
                case 'p':
                    if (index + 3 >= pattern.Length ||
                        pattern[index + 1] != '{' ||
                        pattern[index + 2] != 'L' ||
                        pattern[index + 3] != '}')
                    {
                        throw InvalidPattern();
                    }
                    output.Append("\\p{L}");
                    index += 3;
                    return;
                case 'n':
                case 'r':
                case 't':
                case 'f':
                    output.Append('\\').Append(escaped);
                    return;
                case '\\':
                case '.':
                case '^':
                case '$':
                case '|':
                case '?':
                case '*':
                case '+':
                case '(':
                case ')':
                case '[':
                case ']':
                case '{':
                case '}':
                case '-':
                    output.Append('\\').Append(escaped);
                    return;
                default:
                    throw InvalidPattern();
            }
        }

        private static void AppendCharacterClass(
            string pattern,
            ref int index,
            StringBuilder output,
            bool ignoreCase)
        {
            int cursor = index + 1;
            bool hasItem = false;
            bool negated = false;
            bool previousWasAsciiShortcut = false;
            var normalContent = new StringBuilder();
            var asciiContent = new StringBuilder();
            if (cursor < pattern.Length && pattern[cursor] == '^')
            {
                negated = true;
                cursor++;
            }

            for (; cursor < pattern.Length; cursor++)
            {
                char current = pattern[cursor];
                if (current == ']')
                {
                    if (!hasItem)
                    {
                        throw InvalidPattern();
                    }
                    AppendTranslatedClass(
                        output,
                        normalContent,
                        asciiContent,
                        negated,
                        ignoreCase);
                    index = cursor;
                    return;
                }
                if (current == '[' || current == '^' && hasItem)
                {
                    throw InvalidPattern();
                }
                if (current == '\\')
                {
                    if (cursor + 1 >= pattern.Length)
                    {
                        throw InvalidPattern();
                    }
                    char escaped = pattern[cursor + 1];
                    bool asciiShortcut =
                        escaped == 'd' || escaped == 's' || escaped == 'w';
                    if (asciiShortcut)
                    {
                        if (normalContent.Length > 0 &&
                            normalContent[normalContent.Length - 1] == '-' ||
                            cursor + 2 < pattern.Length &&
                            pattern[cursor + 2] == '-')
                        {
                            throw InvalidPattern();
                        }
                        AppendEscape(
                            pattern,
                            ref cursor,
                            asciiContent,
                            true,
                            ignoreCase);
                    }
                    else
                    {
                        AppendEscape(
                            pattern,
                            ref cursor,
                            normalContent,
                            true,
                            ignoreCase);
                    }
                    previousWasAsciiShortcut = asciiShortcut;
                }
                else
                {
                    if (current == '-' && previousWasAsciiShortcut)
                    {
                        throw InvalidPattern();
                    }
                    normalContent.Append(current);
                    previousWasAsciiShortcut = false;
                }
                hasItem = true;
            }
            throw InvalidPattern();
        }

        private static void AppendTranslatedClass(
            StringBuilder output,
            StringBuilder normalContent,
            StringBuilder asciiContent,
            bool negated,
            bool ignoreCase)
        {
            string normalBranch = normalContent.Length == 0
                ? null
                : "[" + normalContent + "]";
            string asciiBranch = asciiContent.Length == 0
                ? null
                : "[" + asciiContent + "]";

            if (!ignoreCase || asciiBranch == null)
            {
                output.Append('[');
                if (negated) output.Append('^');
                output.Append(normalContent).Append(asciiContent).Append(']');
                return;
            }

            string asciiExact = "(?-i:" + asciiBranch + ")";
            if (!negated)
            {
                if (normalBranch == null)
                {
                    output.Append(asciiExact);
                }
                else
                {
                    output.Append("(?:")
                        .Append(normalBranch)
                        .Append('|')
                        .Append(asciiExact)
                        .Append(')');
                }
                return;
            }

            output.Append("(?!(?:");
            if (normalBranch != null)
            {
                output.Append(normalBranch).Append('|');
            }
            output.Append(asciiExact).Append("))[\\s\\S]");
        }

        private static void AppendBoundedQuantifier(
            string pattern,
            ref int index,
            StringBuilder output)
        {
            int minimum, maximum;
            AppendBoundedQuantifier(pattern, ref index, output, out minimum, out maximum);
        }

        private static void AppendBoundedQuantifier(string pattern, ref int index,
            StringBuilder output, out int minimum, out int maximum)
        {
            int cursor = index + 1;
            minimum = ReadNumber(pattern, ref cursor);
            maximum = minimum;
            bool openMaximum = false;
            if (cursor < pattern.Length && pattern[cursor] == ',')
            {
                cursor++;
                if (cursor < pattern.Length && char.IsDigit(pattern[cursor]))
                {
                    maximum = ReadNumber(pattern, ref cursor);
                }
                else
                {
                    maximum = MaxQuantifier;
                    openMaximum = true;
                }
            }
            if (cursor >= pattern.Length || pattern[cursor] != '}' ||
                minimum > MaxQuantifier || maximum > MaxQuantifier ||
                maximum < minimum)
            {
                throw InvalidPattern();
            }

            output.Append('{').Append(minimum);
            if (maximum != minimum || openMaximum)
            {
                output.Append(',');
                if (!openMaximum)
                {
                    output.Append(maximum);
                }
            }
            output.Append('}');
            index = cursor;
            if (openMaximum) maximum = -1;
        }

        private static int ReadNumber(string pattern, ref int cursor)
        {
            if (cursor >= pattern.Length || !char.IsDigit(pattern[cursor]))
            {
                throw InvalidPattern();
            }
            int value = 0;
            while (cursor < pattern.Length && char.IsDigit(pattern[cursor]))
            {
                int digit = pattern[cursor] - '0';
                if (value > MaxQuantifier || value > (int.MaxValue - digit) / 10)
                {
                    throw InvalidPattern();
                }
                value = value * 10 + digit;
                cursor++;
            }
            return value;
        }

        private static InvalidOperationException InvalidPattern()
        {
            return Error(
                "TBX_REGEX_INVALID_PATTERN",
                "Pattern ist im Toolbelt-Dialekt ungültig.");
        }

        private static InvalidOperationException Error(
            string code,
            string message)
        {
            return new InvalidOperationException(code + ": " + message);
        }
    }
}
