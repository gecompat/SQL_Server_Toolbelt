-- Interner kanonischer Prüf-/Escapingkern. Kein SQL-Text aus Values wird ausgeführt.
-- Vollständiger privater Snapshot und begrenzte Fragmente vor ResultTable-Mutation.
CREATE OR ALTER PROCEDURE toolbelt_json.USP_JsonConstructInternal
 @ObjectMode bit=NULL,@EntriesTable sysname=NULL,@MaxEntries int=NULL,@MaxTotalValueBytes bigint=NULL,
 @MaxResultBytes bigint=NULL,@GroupMode bit=0,@ResultTable sysname=NULL,@KeepData bit=0,@Debug tinyint=0,@Hilfe bit=0
AS
BEGIN
 SET NOCOUNT ON;
 IF @Hilfe=1
 BEGIN
  DECLARE @Help TABLE(Section varchar(32) NOT NULL,Ordinal int NOT NULL,ItemName sysname NULL,SqlDataType varchar(256) NULL,IsRequired bit NULL,IsNullable bit NULL,DefaultValue nvarchar(4000) NULL,Description nvarchar(max) NOT NULL,ExampleSql nvarchar(max) NULL);
  INSERT @Help VALUES
  ('DESCRIPTION',1,NULL,NULL,NULL,NULL,NULL,N'Interner kanonischer JSON-Prüf-/Escaping-/Routingkern; kein zusätzlicher öffentlicher Konstruktor.',NULL),
  ('PARAMETER',1,N'@ObjectMode','bit',1,0,NULL,N'0 Array, 1 Object; ausschließlich technischer Modus.',NULL),
  ('PARAMETER',2,N'@EntriesTable','sysname',1,0,NULL,N'Caller-lokale Eingabetabelle.',NULL),
  ('PARAMETER',3,N'@MaxEntries','int',1,0,NULL,N'Positive Grenze bis 100000.',NULL),
  ('PARAMETER',4,N'@MaxTotalValueBytes','bigint',1,0,NULL,N'Positive Gesamtwertbytes bis 16777216.',NULL),
  ('PARAMETER',5,N'@MaxResultBytes','bigint',1,0,NULL,N'Positive Ergebnisbytes bis 16777216.',NULL),
  ('PARAMETER',6,N'@GroupMode','bit',0,0,N'0',N'0 ungruppiert, 1 gruppiert; ausschließlich technischer Modus.',NULL),
  ('PARAMETER',7,N'@ResultTable','sysname',0,1,NULL,N'SELECT oder lokale ResultTable.',NULL),
  ('PARAMETER',8,N'@KeepData','bit',1,0,NULL,N'Replace/Append vom Wrapper normalisiert.',NULL),
  ('PARAMETER',9,N'@Debug','tinyint',1,0,NULL,N'Nur Messages.',NULL),
  ('PARAMETER',10,N'@Hilfe','bit',0,1,N'0',N'Help ohne fachliche Prüfung oder Mutation.',NULL),
  ('RESULT_COLUMN',1,N'JsonValue','nvarchar(max)',1,0,NULL,N'GroupMode 0: einzige Spalte/eine Zeile; GroupMode 1: zweite Spalte/eine Zeile je vorhandener Gruppe.',NULL),
  ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Öffentliche Fassade bevorzugen.',N'EXEC toolbelt_json.USP_JsonArray @Hilfe=1;');
  IF @GroupMode=1
  BEGIN
   UPDATE @Help SET Ordinal=2 WHERE Section='RESULT_COLUMN';
   INSERT @Help VALUES('RESULT_COLUMN',1,N'GroupOrdinal','int',1,0,NULL,N'GroupMode 1: positive Gruppe, erste Spalte; GroupMode 0 besitzt nur JsonValue.',NULL);
  END;
  SELECT CAST('1.0' AS varchar(16)) HelpContractVersion,CAST(N'toolbelt_json' AS sysname) SchemaName,
  CAST(N'USP_JsonConstructInternal' AS sysname) ObjectName,Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql FROM @Help ORDER BY Section,Ordinal;
  RETURN;
 END;
 IF @ObjectMode IS NULL OR @GroupMode IS NULL OR @MaxEntries IS NULL OR @MaxEntries NOT BETWEEN 1 AND 100000
 OR @MaxTotalValueBytes IS NULL OR @MaxTotalValueBytes NOT BETWEEN 1 AND 16777216
 OR @MaxResultBytes IS NULL OR @MaxResultBytes NOT BETWEEN 1 AND 16777216
 THROW 53600,N'JSON: ungültiger Ressourcenparameter.',1;
 DECLARE @DependencyId int=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P'),@Version nvarchar(64),@Major int,@Minor int,@Patch int;
 SELECT @Version=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND name=N'Toolbelt.Module.toolbelt.core.result-table.Version';
 SELECT @Major=TRY_CONVERT(int,PARSENAME(@Version,3)),@Minor=TRY_CONVERT(int,PARSENAME(@Version,2)),@Patch=TRY_CONVERT(int,PARSENAME(@Version,1));
 IF @DependencyId IS NULL OR @Major IS NULL OR @Major<1 OR @Minor IS NULL OR @Minor<0 OR @Patch IS NULL OR @Patch<0
 OR CONVERT(varbinary(max),@Version)<>CONVERT(varbinary(max),CONCAT(@Major,N'.',@Minor,N'.',@Patch))
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@DependencyId AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND TRY_CONVERT(nvarchar(128),value)=N'toolbelt.core.result-table')
 OR NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=@DependencyId AND minor_id=0 AND name=N'Toolbelt.ModuleVersion' AND CONVERT(varbinary(max),TRY_CONVERT(nvarchar(64),value))=CONVERT(varbinary(max),@Version))
 THROW 53610,N'JSON: registrierte ResultTable-Dependency >=1.0.0 fehlt oder ist ungeeignet.',1;
 IF @EntriesTable IS NULL OR LEFT(@EntriesTable,1) COLLATE Latin1_General_100_BIN2<>N'#'
 OR LEFT(@EntriesTable,2) COLLATE Latin1_General_100_BIN2=N'##'
 OR LEFT(LOWER(@EntriesTable COLLATE Latin1_General_100_BIN2),5) COLLATE Latin1_General_100_BIN2=N'#tbx_'
 OR QUOTENAME(@EntriesTable) IS NULL
 THROW 53601,N'JSON: caller-lokale Eingabetabelle erforderlich.',1;
 DECLARE @InputId int=OBJECT_ID(N'tempdb..'+@EntriesTable,N'U');
 IF @InputId IS NULL THROW 53601,N'JSON: Eingabetabelle fehlt oder ist nicht sichtbar.',2;
 IF @ResultTable IS NOT NULL AND OBJECT_ID(N'tempdb..'+@ResultTable,N'U')=@InputId
 THROW 53601,N'JSON: Eingabe und Ausgabe dürfen nicht dieselbe Tabelle sein.',3;
 DECLARE @Required TABLE(Name sysname,TypeId int,MaxLength smallint);
 INSERT @Required VALUES(N'Ordinal',56,4),(N'ValueKind',231,-1),(N'Value',231,-1);
 IF @GroupMode=1 INSERT @Required VALUES(N'GroupOrdinal',56,4);
 IF @ObjectMode=1 INSERT @Required VALUES(N'Key',231,-1);
 IF EXISTS(SELECT 1 FROM @Required r WHERE NOT EXISTS
 (SELECT 1 FROM tempdb.sys.columns c WHERE c.object_id=@InputId
 AND CONVERT(varbinary(256),c.name)=CONVERT(varbinary(256),r.Name)
 AND c.system_type_id=r.TypeId AND c.user_type_id=c.system_type_id AND c.max_length=r.MaxLength AND c.is_computed=0))
 THROW 53601,N'JSON: erforderliche Spalten besitzen nicht den exakten Typvertrag.',4;
 DECLARE @Own bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,@Saved bit=0,@Savepoint varchar(32)=REPLACE(CONVERT(varchar(36),NEWID()),'-','');
 BEGIN TRY
  IF @Own=1 BEGIN TRANSACTION;
  ELSE BEGIN SAVE TRANSACTION @Savepoint; SET @Saved=1; END;
 -- Metadatenaggregate vor jeder privaten LOB-Kopie. Der caller-lokale Input
 -- bleibt per Tabellen-S-Lock/HOLDLOCK bis zum konsistenten Snapshot stabil;
 -- bei fremder Transaktion gilt deren reguläre Lock-Lebensdauer.
 DECLARE @SnapshotLimit int=@MaxEntries+1,@PreCount bigint,@PreValueBytes bigint,@PreKeyBytes bigint,
 @PreGroups bigint,@SyntaxBytes bigint,@BadGroup int,@BadOrdinal int,@BadKey int,@BadKindLength int,@DuplicateOrdinal bit,@Sql nvarchar(max);
 SET @Sql=N'SELECT @c=COUNT_BIG(*),@v=COALESCE(SUM(CONVERT(bigint,DATALENGTH([Value]))),0),'
 +N'@k='+CASE WHEN @ObjectMode=1 THEN N'COALESCE(SUM(CONVERT(bigint,DATALENGTH([Key]))),0)' ELSE N'0' END
 +N',@g='+CASE WHEN @GroupMode=1 THEN N'COUNT_BIG(DISTINCT GroupOrdinal)' ELSE N'CONVERT(bigint,1)' END
 +N',@badg='+CASE WHEN @GroupMode=1 THEN N'COALESCE(MAX(CASE WHEN GroupOrdinal IS NULL OR GroupOrdinal<=0 THEN 1 ELSE 0 END),0)' ELSE N'0' END
 +N',@o=COALESCE(MAX(CASE WHEN Ordinal IS NULL OR Ordinal<=0 THEN 1 ELSE 0 END),0),'
 +N'@b='+CASE WHEN @ObjectMode=1 THEN N'COALESCE(MAX(CASE WHEN [Key] IS NULL OR DATALENGTH([Key])=0 OR DATALENGTH([Key])>2048 THEN 1 ELSE 0 END),0)' ELSE N'0' END
 +N',@t=COALESCE(MAX(CASE WHEN ValueKind IS NULL OR DATALENGTH(ValueKind)>14 THEN 1 ELSE 0 END),0) '
 +N'FROM(SELECT TOP (@Limit) '+CASE WHEN @GroupMode=1 THEN N'GroupOrdinal,' ELSE N'' END+N'Ordinal,ValueKind,[Value]'+CASE WHEN @ObjectMode=1 THEN N',[Key]' ELSE N'' END
 +N' FROM '+QUOTENAME(@EntriesTable)+N' WITH(TABLOCK,HOLDLOCK)) bounded;';
 EXEC sys.sp_executesql @Sql,N'@Limit int,@c bigint OUTPUT,@v bigint OUTPUT,@k bigint OUTPUT,@g bigint OUTPUT,@badg int OUTPUT,@o int OUTPUT,@b int OUTPUT,@t int OUTPUT',
 @SnapshotLimit,@PreCount OUTPUT,@PreValueBytes OUTPUT,@PreKeyBytes OUTPUT,@PreGroups OUTPUT,@BadGroup OUTPUT,@BadOrdinal OUTPUT,@BadKey OUTPUT,@BadKindLength OUTPUT;
 IF @PreCount>@MaxEntries THROW 53609,N'JSON: Entrylimit überschritten.',1;
 SET @Sql=N'SELECT @d=CASE WHEN EXISTS(SELECT Ordinal FROM '+QUOTENAME(@EntriesTable)+N' WITH(TABLOCK,HOLDLOCK) GROUP BY '+CASE WHEN @GroupMode=1 THEN N'GroupOrdinal,' ELSE N'' END+N'Ordinal HAVING COUNT_BIG(*)>1) THEN 1 ELSE 0 END;';
 EXEC sys.sp_executesql @Sql,N'@d bit OUTPUT',@DuplicateOrdinal OUTPUT;
 IF @BadGroup=1 THROW 53602,N'JSON: GroupOrdinal muss positiv und nicht NULL sein.',2;
 IF @BadOrdinal=1 OR @DuplicateOrdinal=1 THROW 53602,N'JSON: Ordinals müssen positiv und eindeutig sein.',1;
 IF @BadKey=1 THROW 53603,N'JSON: Key ist NULL, leer oder länger als 1024 Codeeinheiten.',1;
 IF @BadKindLength=1 THROW 53605,N'JSON: ValueKind ist NULL oder überschreitet die maximale Kindlänge.',2;
 IF @PreValueBytes>@MaxTotalValueBytes THROW 53609,N'JSON: Gesamtwertbytes vor Snapshot überschritten.',2;
 SET @SyntaxBytes=CASE WHEN @PreCount=0 THEN CASE WHEN @GroupMode=1 THEN 0 ELSE 4 END ELSE 4*@PreGroups+2*(@PreCount-@PreGroups) END;
 IF @PreValueBytes+@PreKeyBytes+@SyntaxBytes
 +CASE WHEN @ObjectMode=1 THEN 6*@PreCount ELSE 0 END>@MaxResultBytes
 THROW 53609,N'JSON: minimale Ergebnisbytegrenze vor Snapshot überschritten.',4;
 CREATE TABLE #tbx_JsonConstructor_Input
 (GroupOrdinal int NULL,Ordinal int NULL,[Key] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
 ValueKind nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL,
 [Value] nvarchar(max) COLLATE Latin1_General_100_BIN2 NULL);
 SET @Sql=N'INSERT #tbx_JsonConstructor_Input(GroupOrdinal,Ordinal,[Key],ValueKind,[Value]) SELECT TOP (@Limit) '
 +CASE WHEN @GroupMode=1 THEN N'GroupOrdinal' ELSE N'CONVERT(int,1)' END+N',Ordinal,'
 +CASE WHEN @ObjectMode=1 THEN N'[Key]' ELSE N'CAST(NULL AS nvarchar(max))' END
 +N',ValueKind,[Value] FROM '+QUOTENAME(@EntriesTable)+N' WITH(TABLOCK,HOLDLOCK);';
 -- Ein Statement liefert den Snapshot; eine überzählige Zeile genügt zum Limitfehler.
 EXEC sys.sp_executesql @Sql,N'@Limit int',@SnapshotLimit;
 IF (SELECT COUNT_BIG(*) FROM #tbx_JsonConstructor_Input)>@MaxEntries THROW 53609,N'JSON: Entrylimit überschritten.',1;
 IF EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input WHERE GroupOrdinal IS NULL OR GroupOrdinal<=0)
 THROW 53602,N'JSON: GroupOrdinal muss positiv und nicht NULL sein.',2;
 IF EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input WHERE Ordinal IS NULL OR Ordinal<=0)
 OR EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input GROUP BY GroupOrdinal,Ordinal HAVING COUNT(*)>1)
 THROW 53602,N'JSON: Ordinals müssen positiv und eindeutig sein.',1;
 IF @ObjectMode=1 AND EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input WHERE [Key] IS NULL OR DATALENGTH([Key])=0 OR DATALENGTH([Key])>2048)
 THROW 53603,N'JSON: Key ist NULL, leer oder länger als 1024 Codeeinheiten.',1;
 -- BIN2 allein folgt SQL-Padding. Die zusätzliche Bytelänge unterscheidet 'a'/'a '.
 IF @ObjectMode=1 AND EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input GROUP BY GroupOrdinal,CONVERT(varbinary(2048),[Key]),DATALENGTH([Key]) HAVING COUNT(*)>1)
 THROW 53604,N'JSON: doppelte binär identische Keys.',1;
 IF EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input WHERE ValueKind IS NULL OR
 CONVERT(varbinary(max),ValueKind) NOT IN(0x73007400720069006E006700,0x6E0075006D00620065007200,0x62006F006F006C00650061006E00,0x6E0075006C006C00,0x6A0073006F006E00))
 THROW 53605,N'JSON: ValueKind muss exakt string/number/boolean/null/json sein.',1;
 IF EXISTS(SELECT 1 FROM #tbx_JsonConstructor_Input WHERE (ValueKind=N'null' AND [Value] IS NOT NULL) OR(ValueKind<>N'null' AND [Value] IS NULL))
 THROW 53606,N'JSON: SQL-NULL ist ausschließlich für Kind null erforderlich.',1;
 IF (SELECT COALESCE(SUM(CONVERT(bigint,DATALENGTH([Value]))),0) FROM #tbx_JsonConstructor_Input)>@MaxTotalValueBytes
 THROW 53609,N'JSON: Gesamtwertbytes überschritten.',2;
 -- Untere Ergebnisgrenze vor Escaping/Fragmentkopien; die Keysumme ist
 -- durch das Resultbudget begrenzt, nicht nur die einzelne Keylänge.
 DECLARE @MinimumBytes bigint,@InputCount bigint=(SELECT COUNT_BIG(*) FROM #tbx_JsonConstructor_Input);
 SELECT @PreGroups=COUNT_BIG(DISTINCT GroupOrdinal) FROM #tbx_JsonConstructor_Input;
 SET @SyntaxBytes=CASE WHEN @InputCount=0 THEN CASE WHEN @GroupMode=1 THEN 0 ELSE 4 END ELSE 4*@PreGroups+2*(@InputCount-@PreGroups) END;
 SELECT @MinimumBytes=COALESCE(SUM(CONVERT(bigint,CASE WHEN ValueKind=N'null' THEN 8 ELSE DATALENGTH([Value]) END)
 +CASE WHEN ValueKind=N'string' THEN 4 ELSE 0 END
 +CASE WHEN @ObjectMode=1 THEN CONVERT(bigint,DATALENGTH([Key]))+6 ELSE 0 END),0)
 +@SyntaxBytes FROM #tbx_JsonConstructor_Input;
 IF @MinimumBytes>@MaxResultBytes THROW 53609,N'JSON: minimale Ergebnisbytegrenze überschritten.',4;
 CREATE TABLE #tbx_JsonConstructor_Fragments(GroupOrdinal int NOT NULL,Ordinal int NOT NULL,Fragment nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL);
 DECLARE @GroupOrdinal int,@Ordinal int,@Key nvarchar(max),@Kind nvarchar(max),@Value nvarchar(max),
 @Stage tinyint,@BridgeCode int,@BridgeState int,@BridgePhase tinyint,@ExpectedRaw bigint,@ExpectedKey bigint,@ExpectedStrong bigint;
 DECLARE @Entry TABLE(Fragment nvarchar(max) NULL,ErrorNumber int NULL,ErrorState int NULL,FaultPhase tinyint NULL,
 RawValueBytes bigint NULL,KeyBytes bigint NULL,StrongMinimumBytes bigint NULL,FragmentBytes bigint NULL);
 -- Kostenpass verwendet denselben bekannten CLR-Kern in kleinen Stringspans.
 -- Er erzeugt keine vollständigen expandierten Fragmente. Alle fachlichen
 -- Fehler werden in ursprünglicher Reihenfolge vor dem globalen Budget geprüft.
 DECLARE @CostPass tinyint=0,@ExactTotal bigint=0,@StringCost bigint,
 @FullString nvarchar(max),@Chunk nvarchar(1024),@ChunkStart int,@ChunkUnits int,@FullUnits int;
 DECLARE @ChunkCost TABLE(Fragment nvarchar(max) NULL,ErrorNumber int NULL,FragmentBytes bigint NULL);
 DECLARE Entries CURSOR LOCAL FAST_FORWARD FOR SELECT GroupOrdinal,Ordinal,[Key],ValueKind,[Value] FROM #tbx_JsonConstructor_Input ORDER BY GroupOrdinal,Ordinal;
 WHILE @CostPass<=1
 BEGIN
 OPEN Entries;
 FETCH NEXT FROM Entries INTO @GroupOrdinal,@Ordinal,@Key,@Kind,@Value;
 WHILE @@FETCH_STATUS=0
 BEGIN
  -- Der einzige fachliche Entrykern ist die bekannte CLR-Bridge. Globale
  -- Snapshot-/Budget-/Priorityregeln bleiben vor diesen begrenzten Kopien.
  SELECT @Stage=0,@ExpectedRaw=COALESCE(CONVERT(bigint,DATALENGTH(@Value)),0),
   @ExpectedKey=CASE WHEN @ObjectMode=1 THEN CONVERT(bigint,DATALENGTH(@Key)) ELSE 0 END;
  SET @ExpectedStrong=CASE WHEN @Kind=N'null' THEN 8 ELSE @ExpectedRaw END
   +CASE WHEN @Kind=N'string' THEN 4 ELSE 0 END+CASE WHEN @ObjectMode=1 THEN @ExpectedKey+6 ELSE 0 END;
  WHILE @Stage<=1
  BEGIN
   DELETE FROM @Entry;
   IF @CostPass=0 AND @Stage=1 AND @Kind=N'string'
   BEGIN
    SET @FullString=@Value; SET @Value=N''; SET @ExpectedRaw=0;
    SET @ExpectedStrong=4+CASE WHEN @ObjectMode=1 THEN @ExpectedKey+6 ELSE 0 END;
   END;
   INSERT @Entry SELECT Fragment,ErrorNumber,ErrorState,FaultPhase,RawValueBytes,KeyBytes,StrongMinimumBytes,FragmentBytes
    FROM toolbelt_json.FT_JsonEntryEvaluateInternal(@ObjectMode,@Key,@Kind,@Value,@Stage,CONVERT(tinyint,1));
   IF (SELECT COUNT_BIG(*) FROM @Entry)<>1
    THROW 53611,N'JSON: interner Bridgevertrag ist inkohärent.',1;
   IF EXISTS(SELECT 1 FROM @Entry WHERE ErrorNumber IS NULL OR ErrorState IS NULL OR FaultPhase IS NULL
    OR RawValueBytes IS NULL OR KeyBytes IS NULL OR StrongMinimumBytes IS NULL OR FragmentBytes IS NULL
    OR RawValueBytes<>@ExpectedRaw OR KeyBytes<>@ExpectedKey OR StrongMinimumBytes<>@ExpectedStrong
    OR FragmentBytes<0 OR FragmentBytes%2<>0
    OR (@Stage=0 AND (Fragment IS NOT NULL OR FragmentBytes<>0))
    OR (ErrorNumber=0 AND (ErrorState<>0 OR FaultPhase<>0
      OR (@Stage=1 AND (Fragment IS NULL OR FragmentBytes<>DATALENGTH(Fragment)))))
    OR (ErrorNumber<>0 AND (Fragment IS NOT NULL OR FragmentBytes<>0))
    OR NOT((ErrorNumber=0 AND ErrorState=0 AND FaultPhase=0)
     OR (ErrorNumber=53607 AND ErrorState=1 AND (FaultPhase=2 OR (FaultPhase=1 AND @ObjectMode=1)))
     OR (@Stage=1 AND ErrorNumber=53607 AND ErrorState BETWEEN 2 AND 4 AND FaultPhase=4 AND @Kind=N'json')
     OR (@Stage=1 AND ErrorNumber=53608 AND ErrorState=1 AND FaultPhase=3 AND @Kind=N'boolean')
     OR (@Stage=1 AND ErrorNumber=53608 AND ErrorState BETWEEN 3 AND 6 AND FaultPhase=3 AND @Kind=N'number')))
    THROW 53611,N'JSON: interner Bridgevertrag ist inkohärent.',1;
   SELECT @BridgeCode=ErrorNumber,@BridgeState=ErrorState,@BridgePhase=FaultPhase FROM @Entry;
   IF @BridgeCode=53607 AND @BridgeState=1 THROW 53607,N'JSON: ungültige Unicode-Surrogatfolge.',1;
   IF @BridgeCode=53607 AND @BridgeState=2 THROW 53607,N'JSON: decodierte Unicode-Surrogatfolge ungültig.',2;
   IF @BridgeCode=53607 AND @BridgeState=3 THROW 53607,N'JSON: decodierte Unicode-Surrogatfolge ungültig.',3;
   IF @BridgeCode=53607 AND @BridgeState=4 THROW 53607,N'JSON: decodierte Unicode-Surrogatfolge ungültig.',4;
   IF @BridgeCode=53608 AND @BridgeState=1 THROW 53608,N'JSON: Booleanliteral ungültig.',1;
   IF @BridgeCode=53608 AND @BridgeState=3 THROW 53608,N'JSON: Zahlenliteral ungültig.',3;
   IF @BridgeCode=53608 AND @BridgeState=4 THROW 53608,N'JSON: Zahlenliteral ungültig.',4;
   IF @BridgeCode=53608 AND @BridgeState=5 THROW 53608,N'JSON: Zahlenliteral ungültig.',5;
   IF @BridgeCode=53608 AND @BridgeState=6 THROW 53608,N'JSON: Zahlenliteral ungültig.',6;
   IF @Stage=0 AND @Kind=N'json'
   BEGIN
    IF ISJSON(@Value)<>1 THROW 53608,N'JSON: Fragment muss vollständiges Objekt oder Array sein.',2;
   END;
   SET @Stage+=1;
  END;
  IF @CostPass=0
  BEGIN
   SELECT @StringCost=FragmentBytes FROM @Entry;
   IF @Kind=N'string'
   BEGIN
    SET @FullUnits=CONVERT(int,DATALENGTH(@FullString)/2); SET @ChunkStart=1;
    WHILE @ChunkStart<=@FullUnits
    BEGIN
     SET @ChunkUnits=CASE WHEN @FullUnits-@ChunkStart+1>1024 THEN 1024 ELSE @FullUnits-@ChunkStart+1 END;
     -- Ein Surrogatpaar darf keine Span-Grenze kreuzen; Raw-UTF16 wurde bereits geprüft.
     IF UNICODE(SUBSTRING(@FullString COLLATE Latin1_General_100_BIN2,@ChunkStart+@ChunkUnits-1,1)) BETWEEN 55296 AND 56319
      SET @ChunkUnits-=1;
     IF @ChunkUnits<=0 THROW 53611,N'JSON: Stringkostenspan ist inkohärent.',2;
     SET @Chunk=SUBSTRING(@FullString COLLATE Latin1_General_100_BIN2,@ChunkStart,@ChunkUnits);
     DELETE @ChunkCost;
     INSERT @ChunkCost SELECT Fragment,ErrorNumber,FragmentBytes
      FROM toolbelt_json.FT_JsonEntryEvaluateInternal(CONVERT(bit,0),NULL,N'string',@Chunk,CONVERT(tinyint,1),CONVERT(tinyint,1));
     IF (SELECT COUNT_BIG(*) FROM @ChunkCost)<>1 OR EXISTS(SELECT 1 FROM @ChunkCost WHERE
      ErrorNumber IS NULL OR ErrorNumber<>0 OR Fragment IS NULL OR FragmentBytes IS NULL
      OR FragmentBytes<>DATALENGTH(Fragment) OR FragmentBytes<4)
      THROW 53611,N'JSON: Stringkostenbridge ist inkohärent.',2;
     SELECT @StringCost+=FragmentBytes-4 FROM @ChunkCost;
     SET @ChunkStart+=@ChunkUnits;
    END;
   END;
   SET @ExactTotal+=@StringCost;
  END
  ELSE INSERT #tbx_JsonConstructor_Fragments SELECT @GroupOrdinal,@Ordinal,Fragment FROM @Entry;
  FETCH NEXT FROM Entries INTO @GroupOrdinal,@Ordinal,@Key,@Kind,@Value;
 END;
 CLOSE Entries;
 IF @CostPass=0 AND @ExactTotal+@SyntaxBytes>@MaxResultBytes
  THROW 53609,N'JSON: Ergebnisbytegrenze überschritten.',3;
 SET @CostPass+=1;
 END;
 DEALLOCATE Entries;
 DECLARE @Count bigint=(SELECT COUNT_BIG(*) FROM #tbx_JsonConstructor_Fragments),@Bytes bigint;
 SELECT @Bytes=COALESCE(SUM(CONVERT(bigint,DATALENGTH(Fragment))),0)+@SyntaxBytes FROM #tbx_JsonConstructor_Fragments;
 IF @Bytes>@MaxResultBytes THROW 53609,N'JSON: Ergebnisbytegrenze überschritten.',3;
 CREATE TABLE #tbx_JsonConstructor_Result(JsonValue nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL);
 CREATE TABLE #tbx_JsonConstructor_GroupResult(GroupOrdinal int NOT NULL,JsonValue nvarchar(max) COLLATE Latin1_General_100_BIN2 NOT NULL);
 -- Ein globaler Preflight vor jeder Aggregation und vor dem einzigen Routing.
 -- Feste unterschiedliche Referenzschemas bewahren die alte Einspaltenausgabe.
 IF @GroupMode=1
 INSERT #tbx_JsonConstructor_GroupResult SELECT GroupOrdinal,
 CASE WHEN @ObjectMode=1 THEN N'{' ELSE N'[' END
 +STRING_AGG(Fragment,N',') WITHIN GROUP(ORDER BY Ordinal)
 +CASE WHEN @ObjectMode=1 THEN N'}' ELSE N']' END
 FROM #tbx_JsonConstructor_Fragments GROUP BY GroupOrdinal;
 ELSE
 INSERT #tbx_JsonConstructor_Result SELECT CASE WHEN @ObjectMode=1 THEN N'{' ELSE N'[' END
 +COALESCE(STRING_AGG(Fragment,N',') WITHIN GROUP(ORDER BY Ordinal),N'')
 +CASE WHEN @ObjectMode=1 THEN N'}' ELSE N']' END FROM #tbx_JsonConstructor_Fragments;
 IF @Debug>0 RAISERROR(N'JSON: vollständig validiertes Ergebnis bereit.',10,1) WITH NOWAIT;
 IF @ResultTable IS NULL
 BEGIN
  IF @Own=1 COMMIT;
  IF @GroupMode=1 SELECT GroupOrdinal,JsonValue FROM #tbx_JsonConstructor_GroupResult ORDER BY GroupOrdinal;
  ELSE SELECT JsonValue FROM #tbx_JsonConstructor_Result;
  RETURN;
 END;
  IF @GroupMode=1
  BEGIN
   EXEC toolbelt_core.USP_PrepareResultTable @ResultTableToAlter=@ResultTable,@LikeTable=N'#tbx_JsonConstructor_GroupResult',@KeepData=@KeepData,@Debug=@Debug;
   SET @Sql=N'INSERT '+QUOTENAME(@ResultTable)+N'(GroupOrdinal,JsonValue) SELECT GroupOrdinal,JsonValue FROM #tbx_JsonConstructor_GroupResult;';
  END
  ELSE
  BEGIN
   EXEC toolbelt_core.USP_PrepareResultTable @ResultTableToAlter=@ResultTable,@LikeTable=N'#tbx_JsonConstructor_Result',@KeepData=@KeepData,@Debug=@Debug;
   SET @Sql=N'INSERT '+QUOTENAME(@ResultTable)+N'(JsonValue) SELECT JsonValue FROM #tbx_JsonConstructor_Result;';
  END;
  EXEC sys.sp_executesql @Sql;
  IF @Own=1 COMMIT;
 END TRY
 BEGIN CATCH
  IF @Own=1 AND XACT_STATE()<>0 ROLLBACK;
  ELSE IF @Saved=1 AND XACT_STATE()=1 ROLLBACK TRANSACTION @Savepoint;
  THROW;
 END CATCH;
END;
GO
