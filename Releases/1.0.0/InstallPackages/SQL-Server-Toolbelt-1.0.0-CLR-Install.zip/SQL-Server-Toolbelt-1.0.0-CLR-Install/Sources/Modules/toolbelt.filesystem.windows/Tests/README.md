# Test-Evidence

## Befüllter FileSystemRoot-Repeat 2026-10-20

**Begrenzter Abschluss nach zusätzlicher Benutzerfreigabe:** Der vierte
vollständige Adapterlauf bestand auf Windows SQL Server2025/CL170 lokal:
zwei befüllte Repeats, beide inversen Kontrollen und zwölf Daten-/
Katalogkategorien mit allen zehn Spalten. Exit0, vollständige Captures und
leeres Stderr; eigener Cleanup und frischer lesender DB-/Trust-/Inputpinaudit
bestanden. Produktquellen und Release-Binary bleiben unverändert. Dieser
Nachweis umfasst keine weiteren Windowsversionen/CLs, nichtleeren Grants,
Minimalrechte, Datei-I/O, authentifizierte TLS-Verbindung oder Release.

Der [Labadapter](Invoke-RootRepeatLab.ps1) verwendet ausschließlich explizit
ausgewählte schema-valide Windowsziele und ein zweimal reproduzierbar
gebautes, exakt gebundenes Release-Binary. Er installiert den vorhandenen
ResultTable-Kern und das unveränderte lokale Filesystemmodul in einer
eigenen Datenbank. Die [Fixture](Runtime/FileSystemRoot.Repeat.sql) enthält
vier synthetische Rootzeilen mit allen zehn aktuellen Spalten einschließlich
`AllowServiceAccount`, NULL-/Leerstring-/Unicode-/Padding- und Flagvarianten.
Dateisystem-APIs werden nicht aufgerufen; die Pfade bleiben Katalogwerte.

Geprüft wurden zwei tatsächliche Repeats derselben expandierten Produktbytes
in frischen ungepoolten Sitzungen. Zwölf Daten-/Katalogkategorien vergleichen
Zeilen, Tabelle, Spalten, Indizes, Indexspalten, Constraints, typisierte
Extended Properties, vorhandene Permissions, ServiceAccount-Rolle, Assembly,
CLR-Bindings und Versionsmarker. Zwei inverse Kontrollen müssen NULL versus
Leerstring und signifikantes Padding erkennen und danach den exakten
Ausgangssnapshot wiederherstellen. Dies erteilt keine Rechte und qualifiziert
weder Datei-I/O noch eine zentrale Installation; das Modul ist local-only.

Die folgenden Fehler- und Warteangaben beschreiben den Vorbereitungsstand
vor der zusätzlichen ausdrücklichen Benutzerfreigabe für höchstens zwei
weitere vollständige Läufe und einen gezielten Abschlussreview.
Die ersten beiden begrenzten nativen Versuche auf Windows SQL2025/CL170
bleiben **FAILED**. Versuch1 wies vor dem Setup den zusammengesetzten
Sessionguard mit SQL52970/State1 ab. Eine getrennte rein lesende Probe
bestätigte die Abweisung dieses Ausdrucks und den Erfolg derselben drei
Prädikate als einzelne Statements; die Fixture erhält alle Prädikate.
Versuch2 scheiterte im Fixtureabschnitt an einem noch nicht klassifizierten
lokalen Adapterfehler, SQL0/0. Kein Repeat oder inverser Kontrollfall ist
dadurch nachgewiesen. Beide Prozesse endeten mit Exit1, vollständigen
Captures und leerem Stderr. Eigener DB-/Trustcleanup und jeweils eine
frische lesende Abwesenheitsprüfung bestanden. Die zwei vollständigen
Versuche der ersten Wellenbegrenzung sind verbraucht; keine stille
Wiederholung oder Statusaufwertung. Journale, Hashes und Rohausgaben bleiben
privat. Der unabhängige Review und die aktuelle Head-CI sind getrennte Gates.

Der Quellenreview beanstandete die verlorene lokale Diagnose und die
unbelegte Ursachenzuordnung im Guardkommentar. Der korrigierte Adapter
erhält privat Exceptiontypkette, geschlossen gefilterte ErrorId und Quellzeile
sowie getrennte Setup-/Capture-/Controlphasen. Die ursprüngliche Fehlerphase
wird nach erfolgreichem Cleanup nicht als Cleanupfehler umgedeutet. Dies
ist Diagnosevorbereitung und erklärt den zweiten Fehlversuch noch nicht.
Die vorhandenen `Framework/Test-WitnessControls.ps1` führen zusätzlich 30
rein synthetische Kontrollen der tatsächlichen Diagnosefunktion aus:
zwei freie Meldungen einschließlich eines falschen `FS_REPEAT_`-Präfixes
werden redigiert; alle 28 definierten Fehlercodes bleiben erkennbar.
Typ-/Quellzeilen- und Primärphasenerhalt werden ohne SQL geprüft.

Versuch3 bleibt ebenfalls **FAILED**: Die neue private Diagnose lokalisierte
einen lokalen InvalidCast im ersten Capture bei der Bytearraykonvertierung;
beide Repeatzähler blieben null. Eigener Cleanup und frischer Abwesenheitsaudit
bestanden. Eine neue rein lesende synthetische Probe bestätigte:
`CONVERT(varbinary(max), <leeres FOR XML ... TYPE>)` liefert SQL NULL und der
Client `DBNull`; ein nichtleeres XML liefert Bytes. Das erklärt den
Konvertierungsmechanismus, ohne nachträglich eine nicht erfasste Kategorie
des früheren Laufs als gemessen auszugeben.

Der korrigierte Capture akzeptiert SQL NULL ausschließlich in der ausdrücklich
leeren Permissionskategorie. Er unterscheidet dies von leeren Binarybytes und
verwirft falsche Kategorien/Typen sowie NULL in allen Pflichtkategorien.
Fünf zusätzliche synthetische Payloadkontrollen bestanden. Versuch4 bestand
anschließend mit genau dieser Korrektur den oben abgegrenzten Gesamtscope.
Alle drei fehlgeschlagenen Läufe bleiben FAILED; daraus wird keine allgemeine
Filesystem-, Rechte-, Plattform- oder Releasequalifikation abgeleitet.

Reproduzierbarer Aufruf nach eigener Freigabe eines endlichen Runsets:

```powershell
$dll = '<reproduzierbar gebautes Release-Binary>'
$provider = 'Modules/toolbelt.filesystem.windows/Clr/WindowsFilesystemProvider.cs'
./Modules/toolbelt.filesystem.windows/Tests/Invoke-RootRepeatLab.ps1 `
    -Version 2025 -Patch base -CompatibilityLevel 170 `
    -AssemblyPath $dll `
    -ExpectedAssemblySHA512 (Get-FileHash $dll -Algorithm SHA512).Hash `
    -ExpectedProviderSHA256 (Get-FileHash $provider -Algorithm SHA256).Hash `
    -JournalPath '<neue private Journaldatei außerhalb des Repositorys>'
```

Der Caller benötigt einen eigenen äußeren Prozesswatchdog; die inneren
Grenzen betragen 300 Sekunden Arbeit und insgesamt 360 Sekunden einschließlich
Cleanup. `Functional` übernimmt den ausdrücklichen Lab-Trustwert bei
erforderlicher Verschlüsselung. Ein vorhandener Assemblytrust bleibt
unverändert; ein eigener exakter Hash wird nur ohne Verbraucher und bei
unveränderter Identität entfernt. Unklare Zustände werden erhalten.

## Begrenzte Delete-Grenzkorrektur 2026-10-07

Der bestehende [Framework-Harness](Framework/README.md) enthält zwölf kleine
Fälle am tatsächlichen privaten Löschhelper: Nonrecursive, Tiefe0/1, eine
überschrittene Directory-Tiefe und exakte beziehungsweise überschrittene
Eintragsgrenzen. Er verlangt vollständigen Zielerhalt bei Preflightabweisung,
korrekte Löschung bei gültigem Plan und eigene nichtrekursive Bereinigung.
Native SQL-, Identitäts-, Reparse-/Race- und vollständige NTFS-Nachweise sind
damit nicht ausgeführt. Lokale Compiler-/Filesystem-Proben bleiben wegen
der aktuellen Hostgrenze ausgesetzt; exakte Head-CI ist ein separater Nachweis.

Die Manuelle Windows-CLR-Preflight-Validierung vom 2026-08-04 war auf SQL Server 2025 unter Windows erfolgreich. Sie umfasste .NET-Framework-4.8-CLR-Build, SHA2-512-Trust, lokales Deployment, alle Help-Verträge und die kontrollierte SQL-Authentication-Ablehnung im `Caller`-Modus ohne I/O-Spuren. Der Lauf `Ergänzender Windows-CLR-Preflight-Lauf` vom 2026-08-05 bestätigte kontrolliertes ServiceAccount-Verzeichnis- und Textschreiben mit konfiguriertem `WorkPath`.

Die vollständige Windows-Authentication-/NTFS-ACL-/I/O-Matrix bleibt offen; die historische Zwei-Fall-Auth-Probe und der aktuelle ausgewählte Caller-/NTFS-Lauf sind unten getrennt belegt. Reale Pfade, Benutzer, NTFS-ACLs, Runtime-Ausgaben und Inhalte bleiben außerhalb des Repositorys.

Ein begrenzter nativer Windows-/SQL-Server-2025-Test vom 2026-10-03 bestätigte Installation und Wiederholung, scheiterte aber am Help-Metadatenvertrag: `IsRequired` war `int` statt `bit`. Der SQL-Fix typisiert die fünf Parameterzeilen ausdrücklich als `bit`, damit auch `IsNullable` seinen vertraglichen Typ behält. Der korrigierte Stand bestand anschließend die Prüfung der zwölf CLR-Spaltentypen, sieben Help-Zeilen und zulässigen NULL-Werte für `USP_WriteBinaryFile @Hilfe=1`. Dies ist ein begrenzter Help-Nachweis, kein vollständiger Modulnachweis.

Der nachfolgende Caller-Dateischreibaufruf scheiterte mit `51540/1`; seine konkrete Providerursache wurde für diesen damaligen Stand getrennt untersucht. Alle eigenen Testressourcen wurden bereinigt; jeweils eine separate frische Prüfung bestätigte dies. Für diesen damaligen Stand waren Caller-/NTFS-/I/O-Nachweise noch offen. Die fehlgeschlagenen Gesamtläufe werden nicht als Erfolg gewertet.

Der .NET-Framework-4.8-Build und der statische Vertrag waren im Wartungslauf https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30692267356 erfolgreich. Dies ist kein Windows-SQL-Server-/NTFS-Runtime-Nachweis.

## Aktuelle Validierungsevidenz

<!-- BEGIN GENERATED:MODULE_EVIDENCE -->
- Datum: `2026-10-20`
- Nachweis: `Modules/toolbelt.filesystem.windows/Tests/Invoke-RootRepeatLab.ps1`
- Scope: Windows SQL Server2025 CL170 lokal; vier synthetische FileSystemRoot-Zeilen mit allen zehn Spalten, zwei befüllte Repeats derselben Produktbytes in frischen Sitzungen, zwölf Daten-/Katalogkategorien und zwei inverse NULL-/Paddingkontrollen bestanden. Reproduzierbarer Releasebuild, Exit0, vollständige Kanäle, leeres Stderr, eigene DB-/Trustbereinigung und frischer lesender Input-/Abwesenheitsaudit bestanden. Drei historische Fehlversuche bleiben FAILED. Keine Konfigurations-/Rechte-/Dateisystemänderungen; weitere Ziele/CLs, nichtleere Grants, Minimalrechte, I/O, authentifizierte TLS-Abnahme und Release bleiben offen.
- Ergebnis: `success`
<!-- END GENERATED:MODULE_EVIDENCE -->

## NoOverwrite: begrenzter Offline-Nachweis 2026-10-03

Der NoOverwrite-Providerstand vor der Streaming-Identitätskorrektur bestand den .NET-Framework-4.8-Projektbuild und die kanonische Releaseartefakt-Erzeugung. Die historische private Helperqualifikation besteht neun synthetische Fälle mit 254 Assertions: vorhandenes und während des Schreibens erzeugtes Ziel bei NoOverwrite, leere Ausgabe, Overwrite=true und eigene Staging-Bereinigung bei Writefehler. Dies belegt weder SQL-Caller-Impersonation noch NTFS-ACLs oder Power-Loss-Verhalten.

Der neue [Fixed-only-Test](./Framework/README.md) kompiliert ausschließlich den aktuellen Provider und Harness aus gebundenen Sourcebytes. Seine Ausführung vor der Streaming-Identitätskorrektur bestand am 2026-10-03 neun Fälle/254 Assertions; der vollständige Witness, tatsächlicher Exit0, eigene Bereinigung und abschließende Pins wurden geprüft. Vier tatsächliche private Prozesskontrollen bestanden Nonzero, Timeout, Capturegrenze und Postpin-Drift einschließlich beendeter/disposierter eigener Children und fester Fehlercodes. Die elf synthetischen Witness-Kontrollen bleiben ein getrenntes Parser-Prädikat, keine Prozessausführung. Aktuelle CI wird separat am exakten PR-Head nachgewiesen. Neue Binary-/Caller-/NTFS-Runtimequalifikation bleibt offen. Historische Evidenz oben bleibt erhalten.

## Streaming-Identitätskorrektur — begrenzte Offline-Qualifikation

Der neue Sourcestand liest gestreamte SQL-Inhalte außerhalb der Caller-Impersonation und verwendet dieselbe erfasste Identität für sämtliche Dateioperationen einschließlich eigener Bereinigung. Der [Framework-Harness](./Framework/README.md) enthält zusätzlich sieben begrenzte Sequenz-/Fehlerfälle. Ein privater, begrenzter C#-Sourcebuild und der sourcegebundene Frameworklauf dieses Stands bestanden am 2026-10-03. Der Frameworklauf bestätigte neun NoOverwrite-Fälle und sieben zusätzliche Copy-/Staging-Sequenzfälle mit synthetischem Executor. Er führt keine tatsächliche Windows-Identität aus und qualifiziert daher weder Enter/Undo/Poison noch SQL-gestreamte Inhalte oder NTFS. Ein aktueller vollständiger Projektbuild samt kanonischem Releaseartefakt und native Windows-Caller-/NTFS-Regression bleiben offen. Die vorherigen erfolgreichen Offline- und Help-Nachweise sowie fehlgeschlagenen Gesamtläufe bleiben getrennte historische Evidenz.
## Requestbezogene Caller-Authentifizierung — Sourcekorrektur

Alle neun CLR-Einstiegspunkte verwenden im Caller-Pfad dieselbe Authentifizierungspruefung. Eine Contextconnection liest vor Impersonation `CONNECTIONPROPERTY('auth_scheme')`; Connection und Command sind vor der Identity-Erfassung vollstaendig disposed. Nur die exakt ordinalen Windows-Modi `NTLM`, `KERBEROS`, `DIGEST`, `BASIC` und `NEGOTIATE` zusammen mit einer nichtleeren Windows-Identity werden akzeptiert. SQL-Authentifizierung, NULL und unbekannte Werte werden mit dem bestehenden `CallerWindowsAuthenticationRequired` abgewiesen. `ServiceAccount` bleibt ausdruecklicher Opt-in; es gibt keinen Fallback, keine DMV-/Sichtrechte-Abhaengigkeit und keine neue API.

[Microsofts CONNECTIONPROPERTY-Vertrag](https://learn.microsoft.com/en-us/sql/t-sql/functions/connectionproperty-transact-sql?view=sql-server-ver17) beschreibt diese requestbezogenen Modi. Der vorbereitete Frameworktest ruft nur das echte reine Auth-Praedikat mit fuenf erlaubten und zehn abgewiesenen synthetischen Werten auf. Die neun NoOverwrite- und sieben Streaming-Faelle bleiben erhalten. Die vorherige Sourcevorbereitung und ihre damaligen Nachweisgrenzen bleiben historisch. Der aktuelle Guard bestand anschließend eine private native Zwei-Fall-Authentifizierungsprüfung auf SQL Server 2025/CU8 unter Windows: Windows-Authentifizierung (NTLM) schrieb über `USP_WriteBinaryFile` im Caller-Modus genau drei synthetische Bytes; SQL-Authentifizierung wurde mit `51540/1` und `CallerWindowsAuthenticationRequired` vor Datei- oder Staging-I/O abgewiesen. Eigene DB-, Root- und Trustbereinigung sowie eine separate frische Prüfung bestanden; Konfiguration, Rechte und Owner blieben unverändert. Dies ist ausschließlich der begrenzte Auth-Probe-Nachweis. Vollständige direkte CLR-/RunAs- und alle neun EntryPoint-Nachweise, NTFS-ACL-Matrix, ServiceAccount-Regression, Races und weitere Zielsysteme bleiben offen; der Modulstatus und die unveröffentlichte Version ändern sich nicht.

## Aktueller begrenzter Nachweis 2026-10-04

Der Providerstand vom 2026-10-04 bestand einen privaten begrenzten produktiven C#-Sourcebuild und den sourcegebundenen Frameworklauf: neun NoOverwrite-Fälle/270 Assertions sowie sieben Streaming-Fälle/188 Assertions; darin enthalten ist die reine Caller-Policyprüfung mit fünf erlaubten und zehn abgewiesenen Werten. Vollständige Captures, Exit0, eigene Bereinigung und abschließende Sourcepins wurden geprüft. Die synthetischen Sequenzfälle beweisen keine echte Impersonation.

Die private native Zwei-Fall-Authentifizierungsprüfung auf SQL Server 2025/CU8 unter Windows bestand: Windows-Caller (NTLM) schrieb drei synthetische Bytes über `USP_WriteBinaryFile`; SQL-Authentifizierung wurde mit `51540/1` und `CallerWindowsAuthenticationRequired` vor Datei-/Staging-I/O abgewiesen. Eigene DB-, Root- und Trustbereinigung und eine separate frische Prüfung bestanden, ohne Konfigurations-, Rechte- oder Owneränderungen. Dieser begrenzte Probe-Scope ist kein vollständiger Produkttest.

Aktueller kanonischer Projektbuild/Releaseartefakt, direkte CLR-/RunAs-Qualifikation aller neun Einstiegspunkte, vollständige NTFS-/Caller-/ServiceAccount-Matrix, Races, weitere Ziele und aktuelle Head-CI bleiben separate offene Gates. Status `partially validated`, Version1.0.0 und `unreleased` bleiben erhalten; frühere Nachweise sind historisch.

## Ausgewählter Caller-/NTFS-Lauf 2026-10-04

Der Providerstand vom 2026-10-04 bestand auf SQL Server 2025/CU8 unter Windows 16 Pflichtfälle. Der Lauf verwendete alle neun öffentlichen Prozeduren und bestätigte Binary-Chunks, UTF-8 mit BOM, Transcoding nach UTF-16 LE, List/Create/Remove, die Ablehnung von SQL-Authentifizierung im Caller-Modus, Caller- und ServiceAccount-NTFS-Verweigerungen, NoOverwrite/Overwrite sowie Zielerhalt und Staging-Bereinigung nach Schreib- und Encodingfehlern. Die Caller-Identität wurde mit der authentifizierten SQL-Sitzung abgeglichen; die Caller-Verweigerungen wurden mit demselben Windows-Token gegengeprüft. Für ServiceAccount sind Produktaufrufe und Rückkehr zum unveränderten Zugriffszustand belegt, kein separater Service-Token-Test.

Der zusätzliche Race-Fall blieb `NOT_OBSERVED` und liefert keinen Race-Nachweis. Eigene Testdatenbank, Root und Trust wurden bereinigt; drei ausschließlich eigene Fixture-ACLs und ein Readonly-Attribut wurden zurückgesetzt. Eine separate frische Prüfung bestätigte die Ressourcenabsenz und Trust-Wiederherstellung. Die unabhängige Prüfung bestätigte vollständige Prozesskanäle, Exit0, beendete/disposierte Children, unveränderte Sourcepins und das exakt gebundene Journal. Es wurden keine Konfiguration, SQL-Rechte oder Owner geändert. Private Journale, Identitäten, Pfade und Runtimeausgaben bleiben außerhalb des Repositorys.

Dies qualifiziert ausschließlich den ausgewählten Lauf. Direkte CLR-/RunAs-Aufrufe, weitere Codepages und Limits, Reparse-/rekursive Delete-Fälle, Race-Beobachtung, weitere Ziele und die separate ZIP-Dateizugriffswelle bleiben offen. `partially validated` und `unreleased` bleiben erhalten.
