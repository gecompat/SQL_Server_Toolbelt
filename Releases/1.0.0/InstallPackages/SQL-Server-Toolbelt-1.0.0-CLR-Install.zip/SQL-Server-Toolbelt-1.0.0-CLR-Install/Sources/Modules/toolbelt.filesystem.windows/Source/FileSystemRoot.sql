IF DATABASE_PRINCIPAL_ID(N'toolbelt_filesystem_service_account') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.database_principals WHERE name=N'toolbelt_filesystem_service_account' AND type='R' AND owning_principal_id=1)
    THROW 51537,N'Die ServiceAccount-Rolle muss eine von dbo kontrollierte Datenbankrolle sein; kein Ownertransfer.',1;
IF OBJECT_ID(N'toolbelt_filesystem.FileSystemRoot', N'U') IS NULL
BEGIN
CREATE TABLE [toolbelt_filesystem].[FileSystemRoot]
(
      RootAlias            sysname         NOT NULL
    , RootPath             nvarchar(4000)  NOT NULL
    , WorkPath             nvarchar(4000)  NULL
    , AllowRead            bit             NOT NULL CONSTRAINT [DF_FileSystemRoot_AllowRead] DEFAULT (1)
    , AllowWrite           bit             NOT NULL CONSTRAINT [DF_FileSystemRoot_AllowWrite] DEFAULT (0)
    , AllowList            bit             NOT NULL CONSTRAINT [DF_FileSystemRoot_AllowList] DEFAULT (1)
    , AllowDelete          bit             NOT NULL CONSTRAINT [DF_FileSystemRoot_AllowDelete] DEFAULT (0)
    , AllowCreateDirectory bit             NOT NULL CONSTRAINT [DF_FileSystemRoot_AllowCreateDirectory] DEFAULT (0)
    , IsActive             bit             NOT NULL CONSTRAINT [DF_FileSystemRoot_IsActive] DEFAULT (1)
    , CONSTRAINT [PK_FileSystemRoot] PRIMARY KEY CLUSTERED (RootAlias)
    , CONSTRAINT [CK_FileSystemRoot_RootAlias] CHECK (RootAlias NOT LIKE N'%[^A-Za-z0-9_-]%')
    , CONSTRAINT [CK_FileSystemRoot_WorkPathRelative] CHECK (WorkPath IS NULL OR (WorkPath NOT LIKE N'%:%' AND WorkPath NOT LIKE N'/%' AND WorkPath NOT LIKE N'\\%'))
);
END;
GO

-- Bestehende Roots werden bewusst nicht für Dienstidentität freigegeben.
IF COL_LENGTH(N'toolbelt_filesystem.FileSystemRoot',N'AllowServiceAccount') IS NULL
    ALTER TABLE toolbelt_filesystem.FileSystemRoot ADD AllowServiceAccount bit NOT NULL
        CONSTRAINT DF_FileSystemRoot_AllowServiceAccount DEFAULT(0) WITH VALUES;
GO
IF DATABASE_PRINCIPAL_ID(N'toolbelt_filesystem_service_account') IS NULL
    CREATE ROLE toolbelt_filesystem_service_account AUTHORIZATION dbo;
GO
