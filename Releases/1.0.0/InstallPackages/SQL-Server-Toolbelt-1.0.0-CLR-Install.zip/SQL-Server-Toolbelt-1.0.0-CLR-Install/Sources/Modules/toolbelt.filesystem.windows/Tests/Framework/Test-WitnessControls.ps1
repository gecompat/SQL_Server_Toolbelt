# Synthetische Kontrollen des tatsächlichen Witness-Parsers; kein Compiler/Provideraufruf.
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$path=Join-Path $PSScriptRoot 'Invoke-NoOverwrite.ps1';$bytes=[IO.File]::ReadAllBytes($path)
$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseInput([Text.UTF8Encoding]::new($false,$true).GetString($bytes),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'FS_TEST_CONTROL_AST'}
$functions=@($ast.FindAll({param($node)$node-is[Management.Automation.Language.FunctionDefinitionAst]-and$node.Name-ceq'Test-NoOverwriteWitness'},$true))
if($functions.Count-ne1){throw 'FS_TEST_CONTROL_FUNCTION'}
. ([scriptblock]::Create($functions[0].Extent.Text))
$good="PASS FIXED_HELPER CASES=9 STAGING_CREATE_ACTIONS=9 SENTINEL_CREATE_ACTIONS=5 DISTINCT_OWN_PATHS=10 MAX_SIMULTANEOUS_OWN_FILES=2 ASSERTIONS=254 STREAMING_CASES=7 STREAMING_ASSERTIONS=100 DELETE_CASES=12 DELETE_ASSERTIONS=500 CLEANUP_VERIFIED=1 OFFLINE_ONLY`n"
$n=0;foreach($text in @($good,$good.Replace("`n","`r`n"))){$r=Test-NoOverwriteWitness $text;if($r.Cases-ne9-or$r.Assertions-ne254-or$r.StreamingCases-ne7-or$r.StreamingAssertions-ne100-or$r.DeleteCases-ne12-or$r.DeleteAssertions-ne500){throw 'FS_TEST_CONTROL_VALID'};$n++}
$bad=@(($good+'extra'),$good.Replace('CASES=9','CASES=8'),$good.Replace('STAGING_CREATE_ACTIONS=9','STAGING_CREATE_ACTIONS=8'),$good.Replace('SENTINEL_CREATE_ACTIONS=5','SENTINEL_CREATE_ACTIONS=4'),$good.Replace('DISTINCT_OWN_PATHS=10','DISTINCT_OWN_PATHS=11'),$good.Replace('MAX_SIMULTANEOUS_OWN_FILES=2','MAX_SIMULTANEOUS_OWN_FILES=3'),$good.Replace('ASSERTIONS=254','ASSERTIONS=0'),$good.Replace('CLEANUP_VERIFIED=1','CLEANUP_VERIFIED=0'),$good.Replace('ASSERTIONS=254','ASSERTIONS=999999999999999999999'),$good.Replace('STREAMING_CASES=7','STREAMING_CASES=6'),$good.Replace('STREAMING_ASSERTIONS=100','STREAMING_ASSERTIONS=0'),$good.Replace('STREAMING_ASSERTIONS=100','STREAMING_ASSERTIONS=4097'))
$bad+=@(
 $good.Replace('DELETE_CASES=12','DELETE_CASES=11'),
 $good.Replace('DELETE_CASES=12','DELETE_CASES=0'),
 $good.Replace('DELETE_ASSERTIONS=500','DELETE_ASSERTIONS=0'),
 $good.Replace('DELETE_ASSERTIONS=500','DELETE_ASSERTIONS=4097'),
 $good.Replace('DELETE_ASSERTIONS=500','DELETE_ASSERTIONS=999999999999999999999'),
 $good.Replace(' DELETE_CASES=12 DELETE_ASSERTIONS=500',''),
 $good.Replace('DELETE_CASES=12','DELETE_CASES=12 DELETE_CASES=12'),
 $good.Replace('DELETE_ASSERTIONS=500','DELETE_ASSERTIONS=500 DELETE_ASSERTIONS=500'),
 $good.Replace('DELETE_CASES=12','delete_cases=12'),
 $good.Replace('DELETE_CASES=12','DELETE_CASES=-12'),
 $good.Replace('DELETE_CASES=12','DELETE_CASES='+[char]0x0661+[char]0x0662),
 $good.TrimEnd("`n")
)
foreach($text in $bad){$rejected=$false;try{[void](Test-NoOverwriteWitness $text)}catch{$rejected=$true};if(-not$rejected){throw 'FS_TEST_CONTROL_FALSE_ACCEPT'};$n++}
if((Get-FileHash -LiteralPath $path).Hash-cne$hash){throw 'FS_TEST_CONTROL_SOURCE_DRIFT'}
if($n-ne26){throw 'FS_TEST_CONTROL_COUNT'}
'PASS NO_OVERWRITE_WITNESS_CONTROLS CHECKS='+$n+' SYNTHETIC_ONLY'

# Tatsächliche Repeatdiagnose isoliert laden: keine Labdiscovery oder SQL-Verbindung.
$repeatPath=Join-Path $PSScriptRoot '../Invoke-RootRepeatLab.ps1'
$repeatText=[IO.File]::ReadAllText($repeatPath);$repeatErrors=$null
$repeatAst=[Management.Automation.Language.Parser]::ParseInput($repeatText,[ref]$null,[ref]$repeatErrors)
if($repeatErrors.Count){throw 'FS_REPEAT_DIAG_AST'}
$diagnostics=@($repeatAst.FindAll({param($node)$node-is[Management.Automation.Language.FunctionDefinitionAst]-and$node.Name-ceq'Get-Failure'},$true))
if($diagnostics.Count-ne1){throw 'FS_REPEAT_DIAG_FUNCTION'}
. ([scriptblock]::Create($diagnostics[0].Extent.Text))
$stage='CONTROL_CAPTURE';$diagnosticCount=0
foreach($message in @('SYNTHETIC_SENSITIVE_VALUE','FS_REPEAT_SYNTHETIC_SECRET_MARKER')){
    try{throw [InvalidOperationException]::new($message)}catch{$diagnostic=Get-Failure $_}
    if($diagnostic.Reason-cne'UNCLASSIFIED'-or$diagnostic.ErrorId-cne'REDACTED_UNCLASSIFIED_ERROR_ID'-or
       ($diagnostic|ConvertTo-Json -Depth 4).Contains($message)-or$diagnostic.ExceptionTypes.Count-lt1-or
       $diagnostic.SourceLine-lt1){throw 'FS_REPEAT_DIAG_FREE_TEXT'}
    $diagnosticCount++
}
$stage='CLEANUP'
if($diagnostic.Stage-cne'CONTROL_CAPTURE'){throw 'FS_REPEAT_DIAG_PRIMARY_STAGE'}
$throwCodes=@([regex]::Matches($repeatText,"throw '(FS_REPEAT_[A-Z0-9_]+)'")|ForEach-Object{$_.Groups[1].Value}|Sort-Object -Unique)
if($throwCodes.Count-ne28){throw 'FS_REPEAT_DIAG_CODE_INVENTORY'}
foreach($code in $throwCodes){
    $errorRecord=[Management.Automation.ErrorRecord]::new([InvalidOperationException]::new($code),'SyntheticUnknownId',[Management.Automation.ErrorCategory]::InvalidData,$null)
    if((Get-Failure $errorRecord).Reason-cne$code){throw 'FS_REPEAT_DIAG_KNOWN_CODE'}
    $diagnosticCount++
}
'PASS ROOT_REPEAT_DIAGNOSIS_CONTROLS CHECKS='+$diagnosticCount+' SYNTHETIC_ONLY'

# Die tatsächliche Payloadkonvertierung muss SQL NULL und leere Bytes trennen.
$payloadFunctions=@($repeatAst.FindAll({param($node)$node-is[Management.Automation.Language.FunctionDefinitionAst]-and$node.Name-ceq'Get-CapturePayload'},$true))
if($payloadFunctions.Count-ne1){throw 'FS_REPEAT_PAYLOAD_FUNCTION'}
. ([scriptblock]::Create($payloadFunctions[0].Extent.Text))
if((Get-CapturePayload 'permissions' ([DBNull]::Value))-cne'SQL_NULL'){throw 'FS_REPEAT_PAYLOAD_NULL'}
if((Get-CapturePayload 'permissions' ([byte[]]@()))-cne'BINARY:'){throw 'FS_REPEAT_PAYLOAD_EMPTY'}
if((Get-CapturePayload 'rows' ([byte[]]@(0,1,255)))-cne'BINARY:0001FF'){throw 'FS_REPEAT_PAYLOAD_BYTES'}
foreach($invalid in @(@{Category='rows';Value=[DBNull]::Value},@{Category='permissions';Value='not binary'})){
    $rejected=$false;try{[void](Get-CapturePayload $invalid.Category $invalid.Value)}catch{$rejected=$_.Exception.Message-ceq'FS_REPEAT_CAPTURE_SHAPE'}
    if(-not$rejected){throw 'FS_REPEAT_PAYLOAD_FALSE_ACCEPT'}
}
'PASS ROOT_REPEAT_CAPTURE_CONTROLS CHECKS=5 SYNTHETIC_ONLY'
