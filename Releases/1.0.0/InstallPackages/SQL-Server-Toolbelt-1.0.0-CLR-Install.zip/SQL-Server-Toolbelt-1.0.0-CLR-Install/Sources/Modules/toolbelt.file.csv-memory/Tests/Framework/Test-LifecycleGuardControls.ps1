# Offline-Negativkontrollen für Abweisungs-/Abschlussorakel; kein SQL/Labzugriff.
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../Runtime/OwnershipGuards.Tests.ps1')
. (Join-Path $PSScriptRoot '../Runtime/ForeignGuards.Tests.ps1')
. (Join-Path $PSScriptRoot '../Runtime/MarkerAbsence.Tests.ps1')
. (Join-Path $PSScriptRoot '../Runtime/ForeignKinds.Tests.ps1')
. (Join-Path $PSScriptRoot '../Runtime/BindingDrift.Tests.ps1')
. (Join-Path $PSScriptRoot '../Runtime/NamedConsumers.Tests.ps1')
$checks=0
function Check([bool]$Condition){if(-not $Condition){throw 'CSV_GUARD_CONTROL_FAILED'};$script:checks++}
# Nur den tatsächlichen Parameter-AST ausführen, niemals den Labadapterkörper.
$driver=Join-Path $PSScriptRoot '../../../../Tests/CI/run-csv-memory-lab.ps1'
$parseErrors=$null
$driverTree=[Management.Automation.Language.Parser]::ParseFile($driver,[ref]$null,[ref]$parseErrors)
if($parseErrors.Count){throw 'CSV_GUARD_PARAMETER_PARSE'}
$parameters=@($driverTree.ParamBlock.Parameters|Where-Object {$_.Name.VariablePath.UserPath -ceq 'TestScope'})
if($parameters.Count -ne 1){throw 'CSV_GUARD_PARAMETER_IDENTITY'}
$validateScope=[scriptblock]::Create('param('+$parameters[0].Extent.Text+') $TestScope')
foreach($value in @('default','ownership-markers','foreign-slots','marker-absence','foreign-kinds','foreign-aliases','foreign-table-functions','binding-drift','binding-defaults','named-consumers','schema-values','marker-values','binding-execution','binding-return-lengths','shape-ceilings','shape-ceilings-and-default','cell-ceilings','text-ceilings','quote-expansion','crlf-ceilings','null-token-ceilings','header-text-ceilings','unicode-text-ceilings','control-text-ceilings','keepdata-ceilings','budget-parameter-preservation','select-output-ceilings','select-unicode-null','caller-transaction-preservation','schema-target-preservation','late-parser-syntax','late-parser-rectangular','writer-cell-preservation','target-constraint-preservation','null-representation-preservation','source-metadata-preservation','parser-argument-preservation','writer-argument-preservation','writer-header-preservation','empty-result-preservation','reserved-temp-namespace-preservation','writer-local-source-name-preservation','reserved-temp-prefix-preservation','header-only-preservation','null-token-value-preservation','trailing-empty-field-preservation','quoted-temp-name-preservation','source-target-alias-preservation','lower-value-budget-preservation','lower-output-budget-preservation','header-row-budget-preservation','alternate-separator-preservation','lower-input-budget-preservation','header-cell-budget-preservation')){Check ((& $validateScope -TestScope $value) -ceq $value)}
foreach($value in @('DEFAULT','OWNERSHIP-MARKERS','FOREIGN-SLOTS','MARKER-ABSENCE','FOREIGN-KINDS','FOREIGN-ALIASES','FOREIGN-TABLE-FUNCTIONS','BINDING-DRIFT','BINDING-DEFAULTS','NAMED-CONSUMERS','SCHEMA-VALUES','MARKER-VALUES','BINDING-EXECUTION','BINDING-RETURN-LENGTHS','SHAPE-CEILINGS','SHAPE-CEILINGS-AND-DEFAULT','CELL-CEILINGS','TEXT-CEILINGS','QUOTE-EXPANSION','CRLF-CEILINGS','NULL-TOKEN-CEILINGS','HEADER-TEXT-CEILINGS','UNICODE-TEXT-CEILINGS','CONTROL-TEXT-CEILINGS','KEEPDATA-CEILINGS','BUDGET-PARAMETER-PRESERVATION','SELECT-OUTPUT-CEILINGS','SELECT-UNICODE-NULL','CALLER-TRANSACTION-PRESERVATION','SCHEMA-TARGET-PRESERVATION','LATE-PARSER-SYNTAX','LATE-PARSER-RECTANGULAR','WRITER-CELL-PRESERVATION','TARGET-CONSTRAINT-PRESERVATION','NULL-REPRESENTATION-PRESERVATION','SOURCE-METADATA-PRESERVATION','PARSER-ARGUMENT-PRESERVATION','WRITER-ARGUMENT-PRESERVATION','WRITER-HEADER-PRESERVATION','EMPTY-RESULT-PRESERVATION','RESERVED-TEMP-NAMESPACE-PRESERVATION','WRITER-LOCAL-SOURCE-NAME-PRESERVATION','RESERVED-TEMP-PREFIX-PRESERVATION','HEADER-ONLY-PRESERVATION','NULL-TOKEN-VALUE-PRESERVATION','TRAILING-EMPTY-FIELD-PRESERVATION','QUOTED-TEMP-NAME-PRESERVATION','SOURCE-TARGET-ALIAS-PRESERVATION','LOWER-VALUE-BUDGET-PRESERVATION','LOWER-OUTPUT-BUDGET-PRESERVATION','HEADER-ROW-BUDGET-PRESERVATION','ALTERNATE-SEPARATOR-PRESERVATION','LOWER-INPUT-BUDGET-PRESERVATION','HEADER-CELL-BUDGET-PRESERVATION')){
 $caught=$false;try{& $validateScope -TestScope $value|Out-Null}catch{$caught=$true};Check $caught
}
$modeParameters=@($driverTree.ParamBlock.Parameters|Where-Object {$_.Name.VariablePath.UserPath -ceq 'DeploymentModes'})
if($modeParameters.Count -ne 1){throw 'CSV_GUARD_MODE_PARAMETER_IDENTITY'}
$validateModes=[scriptblock]::Create('param('+$modeParameters[0].Extent.Text+') $DeploymentModes -join '',''')
Check ((& $validateModes -DeploymentModes @('local')) -ceq 'local')
Check ((& $validateModes -DeploymentModes @('central')) -ceq 'central')
Check ((& $validateModes -DeploymentModes @('local','central')) -ceq 'local,central')
$caught=$false;try{& $validateModes -DeploymentModes @()|Out-Null}catch{$caught=$true};Check $caught
$caught=$false;try{& $validateModes -DeploymentModes $null|Out-Null}catch{$caught=$true};Check $caught
$caught=$false;try{& $validateModes -DeploymentModes @('local','central','local')|Out-Null}catch{$caught=$true};Check $caught
$caught=$false;try{& $validateModes -DeploymentModes @('unknown')|Out-Null}catch{$caught=$true};Check $caught
# Abschlusswitness aus dem tatsächlichen Adapter, ohne dessen Labkörper zu starten.
$shapeFunctions=@($driverTree.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Get-CsvShapeCeilingCount'},$true))
if($shapeFunctions.Count -ne 1){throw 'CSV_SHAPE_HELPER_IDENTITY'}
. ([scriptblock]::Create($shapeFunctions[0].Extent.Text))
$shapeRow=[pscustomobject]@{Fixture='CSV_SHAPE_CEILINGS';CasesPassed=[int]8}
Check ((Get-CsvShapeCeilingCount @($shapeRow)) -eq 8)
$cellRow=[pscustomobject]@{Fixture='CSV_CELL_CEILINGS';CasesPassed=[int]8}
Check ((Get-CsvShapeCeilingCount @($cellRow) -ExpectedFixture 'CSV_CELL_CEILINGS') -eq 8)
foreach($bad in @(
 @{Rows=@($cellRow)},@{Rows=@($shapeRow);ExpectedFixture='CSV_CELL_CEILINGS'},
 @{Rows=@([pscustomobject]@{Fixture='CSV_CELL_CEILINGS';CasesPassed=[int]7});ExpectedFixture='CSV_CELL_CEILINGS'},
 @{Rows=@([pscustomobject]@{Fixture='CSV_CELL_CEILINGS';CasesPassed=[int]9});ExpectedFixture='CSV_CELL_CEILINGS'},
 @{Rows=@($cellRow);ExpectedFixture='csv_cell_ceilings'},@{Rows=@($cellRow);ExpectedFixture='UNKNOWN'}
)){
 $caught=$false;try{Get-CsvShapeCeilingCount @bad|Out-Null}catch{$caught=$true};Check $caught
}
foreach($bad in @(
 @{Rows=@()},@{Rows=@($null)},@{Rows=@($shapeRow,$shapeRow)},
 @{Rows=@([pscustomobject]@{Fixture='CSV_SHAPE_CEILINGS';CasesPassed=[int]7})},
 @{Rows=@([pscustomobject]@{Fixture='CSV_SHAPE_CEILINGS';CasesPassed=[int]9})},
 @{Rows=@([pscustomobject]@{Fixture='CSV_SHAPE_CEILINGS';CasesPassed='8'})},
 @{Rows=@([pscustomobject]@{Fixture='csv_shape_ceilings';CasesPassed=[int]8})},
 @{Rows=@([pscustomobject]@{Fixture='CSV_SHAPE_CEILINGS ';CasesPassed=[int]8})},
 @{Rows=@([pscustomobject]@{Fixture='CSV_SHAPE_CEILINGS';CasesPassed=[DBNull]::Value})},
 @{Rows=@([pscustomobject]@{Fixture='CSV_SHAPE_CEILINGS'})},
 @{Rows=@([pscustomobject]@{Fixture='CSV_SHAPE_CEILINGS';CasesPassed=[int]8;Unexpected=1})}
)){
 $caught=$false;try{Get-CsvShapeCeilingCount @bad|Out-Null}catch{$caught=$true};Check $caught
}
# Längere Grenzphasen behalten Default, Gesamtdeadline und Cleanupreserve bei.
$timeoutFunctions=@($driverTree.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Get-CsvCommandTimeout'},$true))
if($timeoutFunctions.Count -ne 1){throw 'CSV_TIMEOUT_HELPER_IDENTITY'}
. ([scriptblock]::Create($timeoutFunctions[0].Extent.Text))
$script:scopeClock=[pscustomobject]@{ElapsedMilliseconds=0L}
$script:workMilliseconds=960000L;$script:totalMilliseconds=1200000L;$script:cleanupPhase=$false
Check ((Get-CsvCommandTimeout) -eq 60)
Check ((Get-CsvCommandTimeout 120) -eq 120)
Check ((Get-CsvCommandTimeout 300) -eq 300)
$caught=$false;try{Get-CsvCommandTimeout 301|Out-Null}catch{$caught=$true};Check $caught
$script:scopeClock.ElapsedMilliseconds=959000L;Check ((Get-CsvCommandTimeout 300) -eq 1)
$script:scopeClock.ElapsedMilliseconds=959001L
$caught=$false;try{Get-CsvCommandTimeout 300|Out-Null}catch{$caught=$true};Check $caught
$script:cleanupPhase=$true;$script:scopeClock.ElapsedMilliseconds=1199000L;Check ((Get-CsvCommandTimeout 300) -eq 1)
$script:scopeClock.ElapsedMilliseconds=1199001L
$caught=$false;try{Get-CsvCommandTimeout 300|Out-Null}catch{$caught=$true};Check $caught
$completionNodes=@($driverTree.FindAll({param($n)$n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.StartsWith("if(`$TestScope -cin @('shape-ceilings','shape-ceilings-and-default'))") -and $n.Extent.Text.Contains('CSV_SHAPE_COMPLETENESS_REQUIRED')},$true))
if($completionNodes.Count -ne 1){throw 'CSV_SHAPE_COMPLETENESS_IDENTITY'}
$checkCompletion=[scriptblock]::Create($completionNodes[0].Extent.Text)
foreach($TestScope in @('shape-ceilings','shape-ceilings-and-default')){
 foreach($selection in @(@{Modes=@('local')},@{Modes=@('central')},@{Modes=@('local','central')})){
  $DeploymentModes=$selection.Modes
  $expected=if($TestScope -ceq 'shape-ceilings-and-default'){14*$DeploymentModes.Count+[int]('central' -cin $DeploymentModes)}else{0}
  $baseline=[pscustomobject]@{ShapeCeilingCasesPassed=8*$DeploymentModes.Count;GuardCasesPassed=0;LifecycleCasesPassed=$expected}
  $ledger=$baseline.PSObject.Copy();$caught=$false;try{& $checkCompletion}catch{$caught=$true};Check (-not $caught)
  foreach($field in @('ShapeCeilingCasesPassed','GuardCasesPassed','LifecycleCasesPassed')){
   $ledger=$baseline.PSObject.Copy();$ledger.$field++
   $caught=$false;try{& $checkCompletion}catch{$caught=$true};Check $caught
  }
 }
}
$cellCompletionNodes=@($driverTree.FindAll({param($n)$n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.StartsWith("if(`$TestScope -ceq 'cell-ceilings')") -and $n.Extent.Text.Contains('CSV_CELL_COMPLETENESS_REQUIRED')},$true))
if($cellCompletionNodes.Count -ne 1){throw 'CSV_CELL_COMPLETENESS_IDENTITY'}
$checkCellCompletion=[scriptblock]::Create($cellCompletionNodes[0].Extent.Text)
$TestScope='cell-ceilings'
foreach($selection in @(@{Modes=@('local')},@{Modes=@('central')},@{Modes=@('local','central')})){
 $DeploymentModes=$selection.Modes
 $baseline=[pscustomobject]@{CellCeilingCasesPassed=8*$DeploymentModes.Count;ShapeCeilingCasesPassed=0;GuardCasesPassed=0;LifecycleCasesPassed=0}
 $ledger=$baseline.PSObject.Copy();$caught=$false;try{& $checkCellCompletion}catch{$caught=$true};Check (-not $caught)
 foreach($field in @('CellCeilingCasesPassed','ShapeCeilingCasesPassed','GuardCasesPassed','LifecycleCasesPassed')){
  $ledger=$baseline.PSObject.Copy();$ledger.$field++
  $caught=$false;try{& $checkCellCompletion}catch{$caught=$true};Check $caught
 }
}
$textRow=[pscustomobject]@{Fixture='CSV_TEXT_CEILINGS';CasesPassed=[int]8}
Check ((Get-CsvShapeCeilingCount @($textRow) -ExpectedFixture 'CSV_TEXT_CEILINGS') -eq 8)
foreach($bad in @(
 @{Rows=@($textRow)},@{Rows=@($textRow);ExpectedFixture='CSV_CELL_CEILINGS'},
 @{Rows=@($shapeRow);ExpectedFixture='CSV_TEXT_CEILINGS'},@{Rows=@($cellRow);ExpectedFixture='CSV_TEXT_CEILINGS'},
 @{Rows=@([pscustomobject]@{Fixture='CSV_TEXT_CEILINGS';CasesPassed=[int]7});ExpectedFixture='CSV_TEXT_CEILINGS'},
 @{Rows=@([pscustomobject]@{Fixture='CSV_TEXT_CEILINGS';CasesPassed=[int]9});ExpectedFixture='CSV_TEXT_CEILINGS'},
 @{Rows=@([pscustomobject]@{Fixture='CSV_TEXT_CEILINGS';CasesPassed='8'});ExpectedFixture='CSV_TEXT_CEILINGS'},
 @{Rows=@([pscustomobject]@{Fixture='csv_text_ceilings';CasesPassed=[int]8});ExpectedFixture='CSV_TEXT_CEILINGS'},
 @{Rows=@([pscustomobject]@{Fixture='CSV_TEXT_CEILINGS ';CasesPassed=[int]8});ExpectedFixture='CSV_TEXT_CEILINGS'},
 @{Rows=@([pscustomobject]@{Fixture='CSV_TEXT_CEILINGS'});ExpectedFixture='CSV_TEXT_CEILINGS'},
 @{Rows=@([pscustomobject]@{Fixture='CSV_TEXT_CEILINGS';CasesPassed=[int]8;Unexpected=1});ExpectedFixture='CSV_TEXT_CEILINGS'}
)){
 $caught=$false;try{Get-CsvShapeCeilingCount @bad|Out-Null}catch{$caught=$true};Check $caught
}
$textCompletionNodes=@($driverTree.FindAll({param($n)$n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.StartsWith("if(`$TestScope -ceq 'text-ceilings')") -and $n.Extent.Text.Contains('CSV_TEXT_COMPLETENESS_REQUIRED')},$true))
if($textCompletionNodes.Count -ne 1){throw 'CSV_TEXT_COMPLETENESS_IDENTITY'}
$checkTextCompletion=[scriptblock]::Create($textCompletionNodes[0].Extent.Text)
$TestScope='text-ceilings'
foreach($selection in @(@{Modes=@('local')},@{Modes=@('central')},@{Modes=@('local','central')})){
 $DeploymentModes=$selection.Modes
 $baseline=[pscustomobject]@{TextCeilingCasesPassed=8*$DeploymentModes.Count;CellCeilingCasesPassed=0;ShapeCeilingCasesPassed=0;GuardCasesPassed=0;LifecycleCasesPassed=0}
 $ledger=$baseline.PSObject.Copy();$caught=$false;try{& $checkTextCompletion}catch{$caught=$true};Check (-not $caught)
 foreach($field in @('TextCeilingCasesPassed','CellCeilingCasesPassed','ShapeCeilingCasesPassed','GuardCasesPassed','LifecycleCasesPassed')){
  $ledger=$baseline.PSObject.Copy();$ledger.$field++
  $caught=$false;try{& $checkTextCompletion}catch{$caught=$true};Check $caught
 }
}
$expansionFunctions=@($driverTree.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Get-CsvExpansionFixture'},$true))
if($expansionFunctions.Count -ne 1){throw 'CSV_EXPANSION_HELPER_IDENTITY'}
. ([scriptblock]::Create($expansionFunctions[0].Extent.Text))
foreach($expansionScope in @('quote-expansion','crlf-ceilings','null-token-ceilings','header-text-ceilings','unicode-text-ceilings','control-text-ceilings','keepdata-ceilings','budget-parameter-preservation','select-output-ceilings','select-unicode-null','caller-transaction-preservation','schema-target-preservation','late-parser-syntax','late-parser-rectangular','writer-cell-preservation','target-constraint-preservation','null-representation-preservation','source-metadata-preservation','parser-argument-preservation','writer-argument-preservation','writer-header-preservation','empty-result-preservation','reserved-temp-namespace-preservation','writer-local-source-name-preservation','reserved-temp-prefix-preservation','header-only-preservation','null-token-value-preservation','trailing-empty-field-preservation','quoted-temp-name-preservation','source-target-alias-preservation','lower-value-budget-preservation','lower-output-budget-preservation','header-row-budget-preservation','alternate-separator-preservation','lower-input-budget-preservation','header-cell-budget-preservation')){
$expansionFixture=Get-CsvExpansionFixture $expansionScope
$expansionRow=[pscustomobject]@{Fixture=$expansionFixture.Fixture;CasesPassed=[int]8}
Check ((Get-CsvShapeCeilingCount @($expansionRow) -ExpectedFixture $expansionFixture.Fixture) -eq 8)
foreach($badScope in @($expansionScope.ToUpperInvariant(),'unknown','default','text-ceilings')){
 $caught=$false;try{Get-CsvExpansionFixture $badScope|Out-Null}catch{$caught=$true};Check $caught
}
foreach($bad in @(
 @{Rows=@($expansionRow)},@{Rows=@($expansionRow);ExpectedFixture='CSV_TEXT_CEILINGS'},
 @{Rows=@($textRow);ExpectedFixture=$expansionFixture.Fixture},@{Rows=@($cellRow);ExpectedFixture=$expansionFixture.Fixture},
 @{Rows=@([pscustomobject]@{Fixture=$expansionFixture.Fixture;CasesPassed=[int]7});ExpectedFixture=$expansionFixture.Fixture},
 @{Rows=@([pscustomobject]@{Fixture=$expansionFixture.Fixture;CasesPassed=[int]9});ExpectedFixture=$expansionFixture.Fixture},
 @{Rows=@([pscustomobject]@{Fixture=$expansionFixture.Fixture;CasesPassed='8'});ExpectedFixture=$expansionFixture.Fixture},
 @{Rows=@([pscustomobject]@{Fixture=$expansionFixture.Fixture.ToLowerInvariant();CasesPassed=[int]8});ExpectedFixture=$expansionFixture.Fixture},
 @{Rows=@([pscustomobject]@{Fixture=$expansionFixture.Fixture+' ';CasesPassed=[int]8});ExpectedFixture=$expansionFixture.Fixture},
 @{Rows=@([pscustomobject]@{Fixture=$expansionFixture.Fixture});ExpectedFixture=$expansionFixture.Fixture},
 @{Rows=@([pscustomobject]@{Fixture=$expansionFixture.Fixture;CasesPassed=[int]8;Unexpected=1});ExpectedFixture=$expansionFixture.Fixture}
)){
 $caught=$false;try{Get-CsvShapeCeilingCount @bad|Out-Null}catch{$caught=$true};Check $caught
}
$expansionCompletionNodes=@($driverTree.FindAll({param($n)$n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.StartsWith("if(`$TestScope -cin @('quote-expansion'") -and $n.Extent.Text.Contains('CSV_EXPANSION_COMPLETENESS_REQUIRED')},$true))
if($expansionCompletionNodes.Count -ne 1){throw 'CSV_EXPANSION_COMPLETENESS_IDENTITY'}
$checkExpansionCompletion=[scriptblock]::Create($expansionCompletionNodes[0].Extent.Text)
$TestScope=$expansionScope
foreach($selection in @(@{Modes=@('local')},@{Modes=@('central')},@{Modes=@('local','central')})){
 $DeploymentModes=$selection.Modes
 $baseline=[pscustomobject]@{ExpansionCasesPassed=8*$DeploymentModes.Count;TextCeilingCasesPassed=0;CellCeilingCasesPassed=0;ShapeCeilingCasesPassed=0;GuardCasesPassed=0;LifecycleCasesPassed=0}
 $ledger=$baseline.PSObject.Copy();$caught=$false;try{& $checkExpansionCompletion}catch{$caught=$true};Check (-not $caught)
 foreach($field in @('ExpansionCasesPassed','TextCeilingCasesPassed','CellCeilingCasesPassed','ShapeCeilingCasesPassed','GuardCasesPassed','LifecycleCasesPassed')){
  $ledger=$baseline.PSObject.Copy();$ledger.$field++
  $caught=$false;try{& $checkExpansionCompletion}catch{$caught=$true};Check $caught
 }
}
}
$slots=@(Get-CsvForeignSlotNames)
$kindCases=@(Get-CsvForeignKindCases)
$aliasCases=@(Get-CsvForeignKindCases 'synonym-function')
$tableCases=@(Get-CsvForeignKindCases 'table-functions')
Check ($tableCases.Count -eq 10)
Check (@($tableCases|ForEach-Object {$_.Name+'|'+$_.Kind}|Sort-Object -Unique).Count -eq 10)
Check (@($tableCases|Where-Object Kind -CEQ 'IF').Count -eq 5)
Check (@($tableCases|Where-Object Kind -CEQ 'TF').Count -eq 5)
foreach($case in $tableCases){$caught=$false;try{Assert-CsvForeignKindCase $case}catch{$caught=$true};Check (-not $caught)}
$caught=$false;try{Get-CsvForeignKindCases 'TABLE-FUNCTIONS'|Out-Null}catch{$caught=$true};Check $caught
foreach($original in $tableCases[0..1]){
 foreach($field in @('Name','Type','Kind','Sql','Read')){
  $case=$original.PSObject.Copy();$case.$field='invalid'
  $caught=$false;try{Assert-CsvForeignKindCase $case}catch{$caught=$true};Check $caught
 }
}
Check ($aliasCases.Count -eq 10)
Check (@($aliasCases|ForEach-Object {$_.Name+'|'+$_.Type}|Sort-Object -Unique).Count -eq 10)
foreach($case in @($aliasCases)+@((Get-CsvAliasTargetCase))){$caught=$false;try{Assert-CsvForeignKindCase $case}catch{$caught=$true};Check (-not $caught)}
$caught=$false;try{Get-CsvForeignKindCases 'SYNONYM-FUNCTION'|Out-Null}catch{$caught=$true};Check $caught
foreach($field in @('Name','Type','Kind','Sql','Read')){
 $case=$aliasCases[0].PSObject.Copy();$case.$field='invalid'
 $caught=$false;try{Assert-CsvForeignKindCase $case}catch{$caught=$true};Check $caught
}
$targetBytes=[Text.Encoding]::Unicode.GetBytes('[toolbelt_file].[CsvGuardAliasTarget]')
Check (Test-CsvAliasTarget @([pscustomobject]@{TargetBytes=$targetBytes}))
Check (-not (Test-CsvAliasTarget @()))
Check (-not (Test-CsvAliasTarget @([pscustomobject]@{TargetBytes=$targetBytes},[pscustomobject]@{TargetBytes=$targetBytes})))
Check (-not (Test-CsvAliasTarget @([pscustomobject]@{TargetBytes=[Text.Encoding]::Unicode.GetBytes('toolbelt_file.Other')})))
Check (-not (Test-CsvAliasTarget @([pscustomobject]@{TargetBytes=[Text.Encoding]::Unicode.GetBytes('toolbelt_file.CsvGuardAliasTarget')})))
Check (-not (Test-CsvAliasTarget @([pscustomobject]@{TargetBytes=[Text.Encoding]::Unicode.GetBytes('toolbelt_file.CsvGuardAliasTarget ')})))
Check (-not (Test-CsvAliasTarget @([pscustomobject]@{TargetBytes=[Convert]::ToHexString($targetBytes)})))
Check (-not (Test-CsvAliasTarget @([pscustomobject]@{TargetBytes=[DBNull]::Value})))
Check (-not (Test-CsvAliasTarget @([pscustomobject]@{TargetBytes=$targetBytes;Extra=1})))
Check ($kindCases.Count -eq 10)
Check (@($kindCases|ForEach-Object {$_.Name+'|'+$_.Type}|Sort-Object -Unique).Count -eq 10)
foreach($case in $kindCases){$caught=$false;try{Assert-CsvForeignKindCase $case}catch{$caught=$true};Check (-not $caught)}
foreach($field in @('Name','Type','Kind','Sql','Read')){
 $case=$kindCases[0].PSObject.Copy();$case.$field='invalid'
 $caught=$false;try{Assert-CsvForeignKindCase $case}catch{$caught=$true};Check $caught
}
$good=[pscustomobject][ordered]@{Marker=[int]73;Payload='guard '}
Check (Test-CsvForeignKindResult @($good))
Check (-not (Test-CsvForeignKindResult @()))
Check (-not (Test-CsvForeignKindResult @($good,$good)))
Check (-not (Test-CsvForeignKindResult @([pscustomobject]@{Marker=73;Payload='guard ';Extra=1})))
Check (-not (Test-CsvForeignKindResult @([pscustomobject]@{Marker='73';Payload='guard '})))
Check (-not (Test-CsvForeignKindResult @([pscustomobject]@{Marker=73;Payload='guard'})))
Check (-not (Test-CsvForeignKindResult @([pscustomobject]@{Marker=73;Payload='GUARD '})))
Check (-not (Test-CsvForeignKindResult @([pscustomobject]@{Marker=73;Payload=[DBNull]::Value})))
Check (-not (Test-CsvForeignKindResult @([pscustomobject]@{Marker=73})))
Check (-not (Test-CsvForeignKindResult @([pscustomobject][ordered]@{Payload='guard ';Marker=73})))
Check (-not (Test-CsvForeignKindResult @([pscustomobject]@{Marker=74;Payload='guard '})))
Check (-not (Test-CsvForeignKindResult @($null)))
Check (-not (Test-CsvForeignKindResult $null))
foreach($mode in @('local','central')){
 $absenceCases=@(Get-CsvMarkerAbsenceCases $mode)
 Check ($absenceCases.Count -eq 27)
 Check (@($absenceCases|ForEach-Object {$_.Scope+'|'+$_.Object+'|'+$_.Property}|Sort-Object -Unique).Count -eq 27)
 foreach($case in $absenceCases){$caught=$false;try{$location=Get-CsvMarkerAbsenceLocation $case}catch{$caught=$true};Check (-not $caught)}
}
foreach($field in @('Scope','Object','Property','Original','State')){
 $case=(Get-CsvMarkerAbsenceCases 'local'|Select-Object -First 1).PSObject.Copy()
 $case.$field=if($field -ceq 'State'){9}else{'invalid'}
 $caught=$false;try{Get-CsvMarkerAbsenceLocation $case|Out-Null}catch{$caught=$true};Check $caught
}
Check ($slots.Count -eq 5)
Check (@($slots|Sort-Object -Unique).Count -eq 5)
foreach($case in @(@('TABLE','USP_ParseCsv'),@('PROCEDURE','USP_CsvGuardSqlConsumer'),@('FUNCTION','SVF_CsvGuardClrConsumer'))){
 $caught=$false;try{Assert-CsvGuardFixtureName $case[0] $case[1]}catch{$caught=$true};Check (-not $caught)
}
foreach($case in @(@('TABLE','Unknown'),@('PROCEDURE','USP_ParseCsv'),@('FUNCTION','USP_CsvGuardSqlConsumer'))){
 $caught=$false;try{Assert-CsvGuardFixtureName $case[0] $case[1]}catch{$caught=$true};Check $caught
}
$hash='A'*64
Check (Test-CsvForeignWitness $hash $hash)
Check (-not (Test-CsvForeignWitness $hash ('B'*64)))
Check (-not (Test-CsvForeignWitness $hash ('a'*64)))
Check (-not (Test-CsvForeignWitness '' ''))
Check (-not (Test-CsvForeignWitness ('-'*64) ('-'*64)))
Check (-not (Test-CsvForeignWitness $null $hash))
$expected=[pscustomobject]@{Number=55324;State=5}
Check (Test-CsvGuardErrorIdentities @($expected) 55324 5)
Check (-not (Test-CsvGuardErrorIdentities @() 55324 5))
Check (-not (Test-CsvGuardErrorIdentities @($expected,$expected) 55324 5))
Check (-not (Test-CsvGuardErrorIdentities @([pscustomobject]@{Number=55325;State=5}) 55324 5))
Check (-not (Test-CsvGuardErrorIdentities @([pscustomobject]@{Number=55324;State=4}) 55324 5))
Check (-not (Test-CsvGuardErrorIdentities @([pscustomobject]@{Number='55324';State=5}) 55324 5))
Check (-not (Test-CsvGuardErrorIdentities @([pscustomobject]@{Number=55324;State='5'}) 55324 5))
foreach($mode in @('local','central')){
 $cases=@(Get-CsvMarkerGuardCases $mode)
 Check ($cases.Count -eq 10)
 Check (@($cases|Where-Object {$_.Original -ceq $_.Mutated}).Count -eq 0)
 $valueCases=@(Get-CsvMarkerGuardCases $mode 'values')
 Check ($valueCases.Count -eq 25 -and @($valueCases|ForEach-Object {$_.Scope+'|'+$_.Object+'|'+$_.Property}|Sort-Object -Unique).Count -eq 25)
 foreach($case in $valueCases){$caught=$false;try{Assert-CsvMarkerGuardCase $case}catch{$caught=$true};Check (-not $caught)}
 $schemaCases=@(Get-CsvMarkerGuardCases $mode 'schema-values')
 Check ($schemaCases.Count -eq 4 -and @($schemaCases|ForEach-Object {$_.Property+'|'+$_.Mutated}|Sort-Object -Unique).Count -eq 4)
 Check (@($schemaCases|Where-Object {$_.Scope -cne 'SCHEMA' -or $_.Object -cne 'toolbelt_file' -or $_.State -ne 1}).Count -eq 0)
 foreach($case in $schemaCases){$caught=$false;try{Assert-CsvMarkerGuardCase $case}catch{$caught=$true};Check (-not $caught)}
}
$caught=$false;try{Get-CsvMarkerGuardCases 'local' 'SCHEMA-VALUES'|Out-Null}catch{$caught=$true};Check $caught
foreach($field in @('Scope','Object','Property','Original','Mutated','State')){
 $case=$schemaCases[0].PSObject.Copy();$case.$field=if($field -ceq 'State'){'1'}else{'invalid'}
 $caught=$false;try{Assert-CsvMarkerGuardCase $case}catch{$caught=$true};Check $caught
}
$caught=$false;try{Get-CsvMarkerGuardCases 'local' 'VALUES'|Out-Null}catch{$caught=$true};Check $caught
foreach($field in @('Scope','Object','Property','Original','Mutated','State')){
 $case=$valueCases[0].PSObject.Copy();$case.$field=if($field -ceq 'State'){'5'}else{'invalid'}
 $caught=$false;try{Assert-CsvMarkerGuardCase $case}catch{$caught=$true};Check $caught
}
function Invoke-CsvSql($Connection,$Sql,$Parameters){$script:markerTransitionSql++}
$script:markerTransitionSql=0;$case=$valueCases[0]
Set-CsvGuardMarker $null $case $case.Original $case.Mutated
Set-CsvGuardMarker $null $case $case.Mutated $case.Original
Check ($script:markerTransitionSql -eq 2)
foreach($transition in @(@($case.Original,$case.Original),@('invalid',$case.Mutated),@($case.Original,'invalid'))){
 $caught=$false;try{Set-CsvGuardMarker $null $case $transition[0] $transition[1]}catch{$caught=$true};Check ($caught -and $script:markerTransitionSql -eq 2)
}
foreach($case in $schemaCases){
 Set-CsvGuardMarker $null $case $case.Original $case.Mutated
 Set-CsvGuardMarker $null $case $case.Mutated $case.Original
}
Check ($script:markerTransitionSql -eq 10)
$bindingCases=@(Get-CsvBindingDriftCases)
$defaultCases=@(Get-CsvBindingDriftCases 'defaults')
$executionCases=@(Get-CsvBindingDriftCases 'execution')
$returnCases=@(Get-CsvBindingDriftCases 'return-lengths')
$moduleRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
Check ($bindingCases.Count -eq 8 -and @($bindingCases.Id|Sort-Object -Unique).Count -eq 8)
Check ($defaultCases.Count -eq 5 -and @($defaultCases.Id|Sort-Object -Unique).Count -eq 5)
$caught=$false;try{Get-CsvBindingDriftCases 'DEFAULTS'|Out-Null}catch{$caught=$true};Check $caught
Check ($executionCases.Count -eq 3 -and @($executionCases.Id|Sort-Object -Unique).Count -eq 3)
Check ($returnCases.Count -eq 2 -and @($returnCases.Id|Sort-Object -Unique).Count -eq 2)
$caught=$false;try{Get-CsvBindingDriftCases 'RETURN-LENGTHS'|Out-Null}catch{$caught=$true};Check $caught
$caught=$false;try{Get-CsvBindingDriftCases 'EXECUTION'|Out-Null}catch{$caught=$true};Check $caught
foreach($case in @($bindingCases)+@($defaultCases)+@($executionCases)+@($returnCases)){
 $source=[IO.File]::ReadAllText((Join-Path $moduleRoot ('Source/'+$case.Name+'.sql')))
 $mutate=New-CsvBindingDriftSql $source $case
 $restore=New-CsvBindingDriftSql $source $case -Restore
 Check ($mutate -cne $restore -and $mutate.StartsWith('ALTER FUNCTION ') -and $restore.StartsWith('ALTER FUNCTION '))
}
foreach($field in @('Id','Name','Method','Kind','Needle','Replacement','State','Probe')){
 foreach($original in @($bindingCases[0],$defaultCases[0],$executionCases[0],$returnCases[0],$returnCases[1])){
  $case=$original.PSObject.Copy();$case.$field=if($field -ceq 'State'){9}else{'invalid'}
  $caught=$false;try{New-CsvBindingDriftSql 'synthetic' $case|Out-Null}catch{$caught=$_.Exception.Message -ceq 'CSV_BINDING_CASE_INVALID'};Check $caught
 }
}
$case=$bindingCases[0]
$source=[IO.File]::ReadAllText((Join-Path $moduleRoot ('Source/'+$case.Name+'.sql')))
foreach($invalidSource in @($source.Replace($case.Needle,'invalid'),($source+$source),$source.Replace($case.Name,'Unknown'))){
 $caught=$false;try{New-CsvBindingDriftSql $invalidSource $case|Out-Null}catch{$caught=$true};Check $caught
}
$witness=[pscustomobject]@{Witness=[int]1}
Check (Test-CsvBindingDriftWitness @($witness))
foreach($rows in @(@(),@($witness,$witness),@([pscustomobject]@{Other=1}),@([pscustomobject]@{Witness=1;Extra=1}),@([pscustomobject]@{Witness='1'}),@([pscustomobject]@{Witness=0}),@([pscustomobject]@{Witness=[DBNull]::Value}),@($null))){Check (-not (Test-CsvBindingDriftWitness $rows))}
Check (-not (Test-CsvBindingDriftWitness $null))
$namedCases=@(Get-CsvNamedConsumerCases);$namedDatabase='Toolbelt_CsvTypes_'+('a'*32)
Check ($namedCases.Count -eq 5 -and @($namedCases.Name|Sort-Object -Unique).Count -eq 5)
foreach($case in $namedCases){Check ((New-CsvNamedConsumerSql $namedDatabase $case).StartsWith('CREATE PROCEDURE toolbelt_file.USP_CsvGuardSqlConsumer AS '))}
foreach($field in @('Name','Reference')){
 $case=$namedCases[0].PSObject.Copy();$case.$field='invalid';$caught=$false
 try{New-CsvNamedConsumerSql $namedDatabase $case|Out-Null}catch{$caught=$_.Exception.Message -ceq 'CSV_NAMED_CASE_INVALID'};Check $caught
}
foreach($database in @('AdventureWorks',($namedDatabase+' '),($namedDatabase+'];DROP TABLE x;--'),$namedDatabase.ToUpperInvariant())){
 $caught=$false;try{New-CsvNamedConsumerSql $database $namedCases[0]|Out-Null}catch{$caught=$true};Check $caught
}
Check (Test-CsvNamedWitness @([pscustomobject]@{Witness=[int]1}))
foreach($rows in @(@(),@($witness,$witness),@([pscustomobject]@{Other=1}),@([pscustomobject]@{Witness=1;Extra=1}),@([pscustomobject]@{Witness='1'}),@([pscustomobject]@{Witness=0}),@([pscustomobject]@{Witness=[DBNull]::Value}),@($null))){Check (-not (Test-CsvNamedWitness $rows))}
Check (-not (Test-CsvNamedWitness $null))
$namedEntry=[pscustomobject]@{Name=$namedDatabase;State='OWNED';Marker=$true;Id=[int]73;Creation=('A'*18)}
$namedConnection=[pscustomobject]@{Database=$namedDatabase}
$script:ledger=[pscustomobject]@{RunId=('a'*32);Databases=@($namedEntry)}
Check ((Get-CsvNamedDatabaseEntry $namedConnection $namedDatabase).Id -eq 73)
foreach($field in @('State','Marker','Id','Creation')){
 $entry=$namedEntry.PSObject.Copy();$entry.$field=if($field -ceq 'Marker'){'true'}else{'invalid'}
 $script:ledger.Databases=@($entry);$caught=$false
 try{Get-CsvNamedDatabaseEntry $namedConnection $namedDatabase|Out-Null}catch{$caught=$true};Check $caught
}
foreach($entries in @(@(),@($namedEntry,$namedEntry))){
 $script:ledger.Databases=$entries;$caught=$false;try{Get-CsvNamedDatabaseEntry $namedConnection $namedDatabase|Out-Null}catch{$caught=$true};Check $caught
}
$script:ledger.Databases=@($namedEntry);$caught=$false
try{Get-CsvNamedDatabaseEntry ([pscustomobject]@{Database='AdventureWorks'}) $namedDatabase|Out-Null}catch{$caught=$true};Check $caught
# Adapterfunktionen werden für sechs Fehlerwege durch synthetische Doubles ersetzt.
function Get-CsvSnapshot($Connection){$script:snapshots++;if($script:scenario -eq 'metadata' -and $script:snapshots -gt 1){return 'changed'};return 'baseline'}
function Get-CsvGuardErrorIdentities($Exception){if($script:scenario -eq 'wrong-error'){return [pscustomobject]@{Number=55324;State=4}};return [pscustomobject]@{Number=55324;State=5}}
function Invoke-CsvBatches($Connection,$Sql){if($script:scenario -ne 'no-error'){throw 'SYNTHETIC_REJECTION'}}
function Invoke-CsvSql($Connection,$Sql,[switch]$Rows){
 if($Sql -ceq 'SET NOCOUNT ON;SET XACT_ABORT ON;'){return}
 $script:states++
 if($script:scenario -eq 'transaction' -and $script:states -gt 1){throw 'SYNTHETIC_NONNEUTRAL_SESSION'}
 [pscustomobject]@{Options=$(if($script:scenario -eq 'options' -and $script:states -gt 1){2}else{1})}
}
foreach($scenario in @('pass','no-error','wrong-error','metadata','transaction','options')){
 $script:scenario=$scenario;$script:snapshots=0;$script:states=0;$caught=$false
 try{Assert-CsvGuardRejected $null 'synthetic' 55324 5 'baseline'}catch{$caught=$true}
 Check ($caught -eq ($scenario -ne 'pass'))
}
# Restaurierung darf fremde Drift nicht überschreiben; unveränderte eigene
# Mutationen müssen dagegen exakt auf die Baseline zurückkehren.
function Set-CsvGuardMarker($Connection,$Case,$Expected,$Value){$script:markerSets++}
function Assert-CsvGuardRejected($Connection,$Sql,$Number,$State,$Snapshot){$script:rejections++}
function Get-CsvSnapshot($Connection){
 $script:snapshots++
 $step=($script:snapshots-1)%4
 if($script:scenario -eq 'restore-drift' -and $step -eq 2){return 'foreign'}
 if($script:scenario -eq 'restore-mismatch' -and $step -eq 3){return 'different'}
 if($script:scenario -eq 'unobserved'){return 'baseline'}
 if($step -in @(0,3)){return 'baseline'};return 'mutated'
}
foreach($scenario in @('pass','restore-drift','restore-mismatch','unobserved')){
 $script:scenario=$scenario;$script:snapshots=0;$script:markerSets=0;$script:rejections=0;$caught=$false;$count=0
 try{$count=Invoke-CsvMarkerGuards $null 'synthetic-deploy' 'synthetic-uninstall' 'local'}catch{$caught=$true}
 Check ($caught -eq ($scenario -ne 'pass'))
 if($scenario -eq 'pass'){Check ($count -eq 20 -and $script:markerSets -eq 20 -and $script:rejections -eq 20)}
 if($scenario -eq 'restore-drift'){Check ($script:markerSets -eq 1)}
}
$script:scenario='pass';$script:snapshots=0;$script:markerSets=0;$script:rejections=0
$count=Invoke-CsvMarkerGuards $null 'synthetic-deploy' 'synthetic-uninstall' 'local' -Family 'values'
Check ($count -eq 50 -and $script:markerSets -eq 50 -and $script:rejections -eq 50)
foreach($scenario in @('pass','restore-drift','restore-mismatch','unobserved')){
 $script:scenario=$scenario;$script:snapshots=0;$script:markerSets=0;$script:rejections=0;$caught=$false;$count=0
 try{$count=Invoke-CsvMarkerGuards $null 'synthetic-deploy' 'synthetic-uninstall' 'local' -Family 'schema-values'}catch{$caught=$true}
 Check ($caught -eq ($scenario -cne 'pass'))
 if($scenario -ceq 'pass'){Check ($count -eq 8 -and $script:markerSets -eq 8 -and $script:rejections -eq 8)}
 if($scenario -ceq 'restore-drift'){Check ($script:markerSets -eq 1)}
}
function Set-CsvMarkerPresence($Connection,$Case,$Action){$script:presenceSets++}
foreach($scenario in @('pass','restore-drift','restore-mismatch','unobserved')){
 $script:scenario=$scenario;$script:snapshots=0;$script:presenceSets=0;$script:rejections=0;$caught=$false;$count=0
 try{$count=Invoke-CsvMarkerAbsenceGuards $null 'synthetic-deploy' 'synthetic-uninstall' 'local'}catch{$caught=$true}
 Check ($caught -eq ($scenario -ne 'pass'))
 if($scenario -eq 'pass'){Check ($count -eq 54 -and $script:presenceSets -eq 54 -and $script:rejections -eq 54)}
 if($scenario -eq 'restore-drift'){Check ($script:presenceSets -eq 1)}
}
# Echte Dropfunktion: Identitätsdrift muss vor jedem SQL-Batch abbrechen.
function Invoke-CsvSql($Connection,$Sql){$script:kindSql++}
function Get-CsvForeignKindIdentity($Connection,$Case){[pscustomobject]@{Id=20;Created=('A'*18)}}
foreach($identity in @([pscustomobject]@{Id=19;Created=('A'*18)},[pscustomobject]@{Id=20;Created=('B'*18)})){
 $script:kindSql=0;$caught=$false
 try{Remove-CsvForeignKind $null $kindCases[0] $identity}catch{$caught=$true}
 Check ($caught -and $script:kindSql -eq 0)
}
function Invoke-CsvBatches($Connection,$Sql){}
function Add-CsvForeignKindOwner($Connection,$Case){[pscustomobject]@{Id=20;Created=('A'*18)}}
function Remove-CsvForeignKind($Connection,$Case,$Identity){$script:kindDrops++}
function Assert-CsvForeignKindWitness($Connection,$Case){
 $script:kindWitnesses++
 if($script:scenario -ceq 'witness-drift' -and $script:kindWitnesses -gt 1){throw 'SYNTHETIC_KIND_WITNESS_CHANGED'}
 if($script:scenario -ceq 'before-second' -and $script:kindWitnesses -ge 4){throw 'SYNTHETIC_KIND_PRE_SECOND_CHANGED'}
}
function Get-CsvSnapshot($Connection){
 $script:snapshots++
 if($script:snapshots -eq 1){return 'clean'}
 $step=($script:snapshots-2)%4
 if($script:scenario -ceq 'drop-drift' -and $step -eq 2){return 'foreign'}
 if($script:scenario -ceq 'restore-mismatch' -and $step -eq 3){return 'different'}
 if($script:scenario -ceq 'unobserved' -and $step -eq 1){return 'clean'}
 if($step -in @(0,3)){return 'clean'};return 'mutated'
}
foreach($family in @('view-procedure','table-functions')){
foreach($scenario in @('pass','drop-drift','restore-mismatch','unobserved','witness-drift','before-second')){
 $script:scenario=$scenario;$script:snapshots=0;$script:kindDrops=0;$script:kindWitnesses=0;$script:rejections=0;$caught=$false;$count=0
 try{$count=Invoke-CsvForeignKindGuards $null 'synthetic-deploy' 'synthetic-uninstall' 'local' -Family $family}catch{$caught=$true}
 Check ($caught -eq ($scenario -cne 'pass'))
 if($scenario -ceq 'pass'){Check ($count -eq 20 -and $script:kindDrops -eq 10 -and $script:rejections -eq 20 -and $script:kindWitnesses -eq 60)}
 if($scenario -cin @('drop-drift','witness-drift')){Check ($script:kindDrops -eq 0)}
 if($scenario -ceq 'before-second'){Check ($script:rejections -eq 1 -and $script:kindDrops -eq 0)}
}
}
# Ein gescheiterter Alias-Witness muss seine Diagnose bis zum OwnDB-Cleanup
# behalten; ein weiterer Target-Cleanup würde hier gezielt anders scheitern.
function Get-CsvSnapshot($Connection){
 $script:aliasSnapshots++
 switch($script:aliasSnapshots){1{'outer'};2{'clean-target'};3{'clean-target'};4{'fixture'};5{'fixture'};default{throw 'SYNTHETIC_ALIAS_MASKED'}}
}
function Assert-CsvForeignKindWitness($Connection,$Case){if($Case.Name -cne 'CsvGuardAliasTarget'){throw 'SYNTHETIC_ALIAS_ORIGINAL'}}
$script:aliasSnapshots=0;$script:kindDrops=0;$caught=$false
try{Invoke-CsvForeignKindGuards $null 'synthetic-deploy' 'synthetic-uninstall' 'local' -Family 'synonym-function'|Out-Null}catch{$caught=$_.Exception.Message -ceq 'SYNTHETIC_ALIAS_ORIGINAL'}
Check ($caught -and $script:kindDrops -eq 0 -and $script:aliasSnapshots -eq 5)
# Tatsächliche Restaurierungssteuerung mit synthetischen SQL-/Kataloggrenzen.
# Fremde Snapshots und ausgetauschte Objektidentitäten erlauben kein ALTER.
function Invoke-CsvSql($Connection,$Sql){$script:bindingSql++}
function Get-CsvBindingDriftIdentity($Connection,$Case){
 $script:bindingIdentities++
 [pscustomobject]@{Id=$(if($script:scenario -ceq 'identity-drift' -and $script:bindingIdentities -gt 1){74}else{73});Created=('A'*18)}
}
function Assert-CsvBindingDriftWitness($Connection,$Case){
 $script:bindingWitnesses++
 if($script:scenario -ceq 'witness-drift' -and $script:bindingWitnesses -gt 1){throw 'SYNTHETIC_BINDING_WITNESS_DRIFT'}
 if($script:scenario -ceq 'binding-pre-second-drift' -and $script:bindingWitnesses -ge 4){throw 'SYNTHETIC_BINDING_PRE_SECOND_DRIFT'}
}
function Get-CsvSnapshot($Connection){
 $script:snapshots++;$step=($script:snapshots-1)%4
 if($script:scenario -ceq 'restore-drift' -and $step -eq 2){return 'foreign'}
 if($script:scenario -ceq 'restore-mismatch' -and $step -eq 3){return 'different'}
 if($script:scenario -ceq 'unobserved'){return 'baseline'}
 if($step -in @(0,3)){return 'baseline'};return 'mutated'
}
foreach($scenario in @('pass','restore-drift','restore-mismatch','unobserved','identity-drift','witness-drift')){
 $script:scenario=$scenario;$script:snapshots=0;$script:bindingSql=0;$script:bindingIdentities=0;$script:bindingWitnesses=0;$script:rejections=0;$caught=$false;$count=0
 try{$count=Invoke-CsvBindingDriftGuards $null 'synthetic-deploy' 'synthetic-uninstall' $moduleRoot 'local'}catch{$caught=$true}
 Check ($caught -eq ($scenario -cne 'pass'))
 if($scenario -ceq 'pass'){Check ($count -eq 16 -and $script:bindingSql -eq 16 -and $script:rejections -eq 16 -and $script:bindingWitnesses -eq 48)}
 if($scenario -cin @('restore-drift','unobserved','identity-drift','witness-drift')){Check ($script:bindingSql -eq 1)}
}
$script:scenario='pass';$script:snapshots=0;$script:bindingSql=0;$script:bindingIdentities=0;$script:bindingWitnesses=0;$script:rejections=0
$count=Invoke-CsvBindingDriftGuards $null 'synthetic-deploy' 'synthetic-uninstall' $moduleRoot 'local' -Family 'defaults'
Check ($count -eq 10 -and $script:bindingSql -eq 10 -and $script:rejections -eq 10 -and $script:bindingWitnesses -eq 30)
$script:scenario='pass';$script:snapshots=0;$script:bindingSql=0;$script:bindingIdentities=0;$script:bindingWitnesses=0;$script:rejections=0
$count=Invoke-CsvBindingDriftGuards $null 'synthetic-deploy' 'synthetic-uninstall' $moduleRoot 'local' -Family 'execution'
Check ($count -eq 6 -and $script:bindingSql -eq 6 -and $script:rejections -eq 6 -and $script:bindingWitnesses -eq 18)
foreach($scenario in @('pass','restore-drift','restore-mismatch','unobserved','identity-drift','witness-drift','binding-pre-second-drift')){
 $script:scenario=$scenario;$script:snapshots=0;$script:bindingSql=0;$script:bindingIdentities=0;$script:bindingWitnesses=0;$script:rejections=0;$caught=$false;$count=0
 try{$count=Invoke-CsvBindingDriftGuards $null 'synthetic-deploy' 'synthetic-uninstall' $moduleRoot 'local' -Family 'return-lengths'}catch{$caught=$true}
 Check ($caught -eq ($scenario -cne 'pass'))
 if($scenario -ceq 'pass'){Check ($count -eq 4 -and $script:bindingSql -eq 4 -and $script:rejections -eq 4 -and $script:bindingWitnesses -eq 12)}
 if($scenario -cin @('restore-drift','unobserved','identity-drift','witness-drift','binding-pre-second-drift')){Check ($script:bindingSql -eq 1)}
 if($scenario -ceq 'binding-pre-second-drift'){Check ($script:rejections -eq 1)}
}
$script:scenario='binding-pre-second-drift';$script:snapshots=0;$script:bindingSql=0;$script:bindingIdentities=0;$script:bindingWitnesses=0;$script:rejections=0;$caught=$false
try{Invoke-CsvBindingDriftGuards $null 'synthetic-deploy' 'synthetic-uninstall' $moduleRoot 'local' -Family 'defaults'|Out-Null}catch{$caught=$true}
Check ($caught -and $script:rejections -eq 1 -and $script:bindingSql -eq 1)
# Der tatsächliche Dependency- und Dropablauf muss bei Katalog-/Identitätsdrift
# abbrechen. Die SQL-Grenze liefert ausschließlich synthetische Resultate.
function Assert-CsvNamedDatabase($Connection,$Database){}
function Get-CsvGuardFixtureIdentity($Connection,$Type,$Name){
 $script:namedIdentities++
 [pscustomobject]@{Id=$(if($script:scenario -ceq 'named-identity-drift' -and $script:namedIdentities -gt 1){21}else{20});Created=('A'*18)}
}
function Add-CsvGuardFixtureOwner($Connection,$Type,$Name){[pscustomobject]@{Id=20;Created=('A'*18)}}
function Invoke-CsvSql($Connection,$Sql,$Parameters,[switch]$Rows){
 if($Sql -ceq (Get-CsvNamedDependencyWitnessSql)){
  $script:namedWitnesses++
  if($script:scenario -ceq 'named-dependency-drift' -and $script:namedWitnesses -gt 1){return [pscustomobject]@{Witness=('B'*64)}}
  if($script:scenario -ceq 'named-pre-second-drift' -and $script:namedWitnesses -ge 4){return [pscustomobject]@{Witness=('B'*64)}}
  return [pscustomobject]@{Witness=('A'*64)}
 }
 if($Sql.StartsWith('CREATE PROCEDURE ')){$script:namedCreates++}
 if($Sql.Contains('DROP PROCEDURE toolbelt_file.[')){$script:namedDrops++}
}
function Get-CsvSnapshot($Connection){
 $script:snapshots++;if($script:snapshots -eq 1){return 'baseline'}
 $step=($script:snapshots-2)%4
 if($script:scenario -ceq 'named-drop-drift' -and $step -eq 2){return 'foreign'}
 if($script:scenario -ceq 'named-restore-mismatch' -and $step -eq 3){return 'different'}
 if($script:scenario -ceq 'named-unobserved'){return 'baseline'}
 if($step -in @(0,3)){return 'baseline'};return 'mutated'
}
foreach($scenario in @('pass','named-drop-drift','named-restore-mismatch','named-unobserved','named-dependency-drift','named-identity-drift','named-pre-second-drift')){
 $script:scenario=$scenario;$script:snapshots=0;$script:namedIdentities=0;$script:namedWitnesses=0;$script:namedCreates=0;$script:namedDrops=0;$script:rejections=0;$caught=$false;$count=0
 try{$count=Invoke-CsvNamedConsumerGuards $namedConnection 'synthetic-deploy' 'synthetic-uninstall' $namedDatabase 'local'}catch{$caught=$true}
 Check ($caught -eq ($scenario -cne 'pass'))
 if($scenario -ceq 'pass'){Check ($count -eq 10 -and $script:rejections -eq 10 -and $script:namedCreates -eq 5 -and $script:namedDrops -eq 5 -and $script:namedWitnesses -eq 30)}
 if($scenario -cin @('named-drop-drift','named-unobserved','named-dependency-drift','named-identity-drift','named-pre-second-drift')){Check ($script:namedDrops -eq 0)}
 if($scenario -ceq 'named-pre-second-drift'){Check ($script:rejections -eq 1)}
}
. (Join-Path $PSScriptRoot 'CsvDirectSelect.Helpers.ps1')
$directBaseline=Get-CsvDirectSelectCase 0
Check ($directBaseline.Rows[0].Values[3].Length -eq 8388606)
$directBaseline.Rows[0].Values[3]='synthetic'
function Copy-DirectControl {
 [pscustomobject]@{Schema=@($directBaseline.Schema|ForEach-Object {$_.PSObject.Copy()});Rows=@([pscustomobject]@{Values=$directBaseline.Rows[0].Values.Clone()})}
}
$directActual=Copy-DirectControl
$caught=$false;try{Assert-CsvDirectSelectRows $directActual.Schema $directActual.Rows $directBaseline}catch{$caught=$true};Check (-not $caught)
foreach($mutation in @('missing-column','extra-column','reordered-column','name-case','sql-type','clr-type','missing-row','extra-row','width','rowkind','rowordinal-type','columnordinal-type','value','null','prefix-only')){
 $directActual=Copy-DirectControl
 switch -CaseSensitive ($mutation){
  'missing-column'{$directActual.Schema=$directActual.Schema[0..2]}
  'extra-column'{$directActual.Schema+=@($directActual.Schema[0])}
  'reordered-column'{$directActual.Schema=$directActual.Schema[1,0,2,3]}
  'name-case'{$directActual.Schema[0].Name='rowkind'}
  'sql-type'{$directActual.Schema[3].SqlType='varchar'}
  'clr-type'{$directActual.Schema[1].ClrType='System.Int32'}
  'missing-row'{$directActual.Rows=@()}
  'extra-row'{$directActual.Rows+=@($directActual.Rows[0])}
  'width'{$directActual.Rows[0].Values=$directActual.Rows[0].Values[0..2]}
  'rowkind'{$directActual.Rows[0].Values[0]='data'}
  'rowordinal-type'{$directActual.Rows[0].Values[1]=[int]1}
  'columnordinal-type'{$directActual.Rows[0].Values[2]=[long]1}
  'value'{$directActual.Rows[0].Values[3]='synthetiC'}
  'null'{$directActual.Rows[0].Values[3]=[DBNull]::Value}
  'prefix-only'{$directActual.Rows[0].Values[3]='syntheti'}
 }
 $caught=$false;try{Assert-CsvDirectSelectRows $directActual.Schema $directActual.Rows $directBaseline}catch{$caught=$true};Check $caught
}
$directBaseline.Rows[0].Values[3]=[DBNull]::Value
$directActual=Copy-DirectControl
$caught=$false;try{Assert-CsvDirectSelectRows $directActual.Schema $directActual.Rows $directBaseline}catch{$caught=$true};Check (-not $caught)
foreach($replacement in @('','NULL',$null)){
 $directActual=Copy-DirectControl;$directActual.Rows[0].Values[3]=$replacement
 $caught=$false;try{Assert-CsvDirectSelectRows $directActual.Schema $directActual.Rows $directBaseline}catch{$caught=$true};Check $caught
}
foreach($phase in @(1,4,5)){
 $directCase=Get-CsvDirectSelectCase $phase
 if($phase -eq 4){Check ($directCase.Rows[0].Values[3].Length -eq 8388604 -and $directCase.Rows[0].Values[3][0] -ceq ',')}
 else{Check ($directCase.Rows[0].Values[0].Length -eq 8388608 -and $directCase.Rows[0].Values[0].EndsWith(([string][char]13+[char]10),[StringComparison]::Ordinal))}
}
foreach($phase in @(2,3,6,7)){
 $directCase=Get-CsvDirectSelectCase $phase
 Check ($directCase.ErrorNumber -eq 55303 -and $directCase.ErrorState -eq 1 -and $directCase.Schema.Count -eq 0 -and $directCase.Rows.Count -eq 0)
}
foreach($phase in @(-1,8)){$caught=$false;try{Get-CsvDirectSelectCase $phase|Out-Null}catch{$caught=$true};Check $caught}
# Tatsächliche Pin-/Deadlinefunktionen verwenden, niemals den Adapterkörper.
foreach($name in @('Add-CsvDirectSelectPin','Assert-CsvPins','Assert-CsvReadBudget')){
 $definitions=@($driverTree.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq $name},$true))
 if($definitions.Count -ne 1){throw 'CSV_SELECT_CONTROL_FUNCTION_IDENTITY'}
 . ([scriptblock]::Create($definitions[0].Extent.Text))
}
$directControlRoot=Join-Path ([IO.Path]::GetTempPath()) ('ToolbeltCsvSynthetic_'+[guid]::NewGuid().ToString('N'))
$directControlFolder=Join-Path $directControlRoot 'Tests/Framework'
$directControlFile=Join-Path $directControlFolder 'CsvDirectSelect.Helpers.ps1'
[void][IO.Directory]::CreateDirectory($directControlFolder)
try{
 [IO.File]::WriteAllText($directControlFile,'synthetic before')
 $script:freeze=@{};$directBound=Add-CsvDirectSelectPin $directControlRoot
 Check ($directBound -ceq $directControlFile -and $script:freeze.ContainsKey($directControlFile))
 $caught=$false;try{Assert-CsvPins}catch{$caught=$true};Check (-not $caught)
 [IO.File]::WriteAllText($directControlFile,'synthetic after')
 $TestScope='select-output-ceilings';$isDirectSelect=$true
 foreach($marker in @('$passed=Invoke-CsvDirectSelectPhase','$rows=@([pscustomobject]@{Fixture=$expansion.Fixture;CasesPassed=[int]$directCases})')){
  $nodes=@($driverTree.FindAll({param($n)$n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.StartsWith("if(`$isDirectSelect){") -and $n.Extent.Text.Contains($marker)},$true))
  if($nodes.Count -ne 1){throw 'CSV_SELECT_PIN_CONTROL_IDENTITY'}
  $caught=$false;try{& ([scriptblock]::Create($nodes[0].Extent.Text))}catch{$caught=$_.Exception.Message -ceq 'CSV_SOURCE_PIN_CHANGED'};Check $caught
 }
}finally{
 Remove-Item -LiteralPath $directControlFile
 Remove-Item -LiteralPath $directControlFolder
 Remove-Item -LiteralPath (Join-Path $directControlRoot 'Tests')
 Remove-Item -LiteralPath $directControlRoot
}
$directConnectionFake=[pscustomobject]@{}
$directConnectionFake|Add-Member ScriptMethod CreateCommand {$script:directCreates++;return $script:directCommandFake}
$script:directReaderFake=[pscustomobject]@{FieldCount=0}
$script:directReaderFake|Add-Member ScriptMethod Read {if($script:directScenario -ceq 'read-timeout'){$script:scopeClock.ElapsedMilliseconds=959001L;return $true};return $false}
$script:directReaderFake|Add-Member ScriptMethod NextResult {return $false}
$script:directReaderFake|Add-Member ScriptMethod Dispose {$script:directReaderDisposes++;if($script:directScenario -ceq 'reader-dispose'){throw 'CSV_SYNTHETIC_READER_DISPOSE'}}
$script:directCommandFake=[pscustomobject]@{CommandTimeout=0;CommandText=''}
$script:directCommandFake|Add-Member ScriptMethod ExecuteReader {return $script:directReaderFake}
$script:directCommandFake|Add-Member ScriptMethod Cancel {$script:directCancels++}
$script:directCommandFake|Add-Member ScriptMethod Dispose {$script:directCommandDisposes++}
foreach($directScenario in @('initial-timeout','reader-dispose','read-timeout')){
 $script:directScenario=$directScenario;$script:directCreates=0;$script:directReaderDisposes=0;$script:directCommandDisposes=0;$script:directCancels=0
 $script:cleanupPhase=$false;$script:scopeClock.ElapsedMilliseconds=if($directScenario -ceq 'initial-timeout'){959001L}else{0L}
 $caught=$false;try{Invoke-CsvDirectSelectPhase $directConnectionFake 'synthetic only' 0|Out-Null}catch{$caught=$true};Check $caught
 if($directScenario -ceq 'initial-timeout'){Check ($script:directCreates -eq 0 -and $script:directCommandDisposes -eq 0)}
 else{Check ($script:directCreates -eq 1 -and $script:directReaderDisposes -eq 1 -and $script:directCommandDisposes -eq 1)}
 if($directScenario -ceq 'read-timeout'){Check ($script:directCancels -eq 1)}
}
$unicodeCase=Get-CsvDirectSelectCase 0 -Scope select-unicode-null
Check ($unicodeCase.Rows.Count -eq 1 -and $unicodeCase.Rows[0].Values[3].Length -eq 8388606)
Check ([int]$unicodeCase.Rows[0].Values[3][0] -eq 0xD83D -and [int]$unicodeCase.Rows[0].Values[3][-1] -eq 0xDE00)
foreach($phase in @(1,5)){
 $unicodeCase=Get-CsvDirectSelectCase $phase -Scope select-unicode-null
 Check ($unicodeCase.Rows[0].Values[0].Length -eq 8388608 -and $unicodeCase.Rows[0].Values[1] -is [long])
}
$unicodeCase=Get-CsvDirectSelectCase 4 -Scope select-unicode-null
Check ($unicodeCase.Rows.Count -eq 3 -and $unicodeCase.Rows[0].Values[3] -is [DBNull] -and $unicodeCase.Rows[1].Values[3] -ceq 'NULL')
Check ($unicodeCase.Rows[2].Values[3].Length -eq 8388594 -and [int]$unicodeCase.Rows[2].Values[3][0] -eq 0x4E2D)
$unicodeCase.Rows[2].Values[3]='synthetic Unicode'
function Copy-UnicodeDirectControl {
 [pscustomobject]@{Schema=@($unicodeCase.Schema|ForEach-Object {$_.PSObject.Copy()});Rows=@($unicodeCase.Rows|ForEach-Object {[pscustomobject]@{Values=$_.Values.Clone()}})}
}
$unicodeActual=Copy-UnicodeDirectControl
$caught=$false;try{Assert-CsvDirectSelectRows $unicodeActual.Schema $unicodeActual.Rows $unicodeCase}catch{$caught=$true};Check (-not $caught)
foreach($mutation in @('null-as-token','literal-as-null','missing-row','reordered-row','truncated-value')){
 $unicodeActual=Copy-UnicodeDirectControl
 switch -CaseSensitive ($mutation){
  'null-as-token'{$unicodeActual.Rows[0].Values[3]='NULL'}
  'literal-as-null'{$unicodeActual.Rows[1].Values[3]=[DBNull]::Value}
  'missing-row'{$unicodeActual.Rows=$unicodeActual.Rows[1,2]}
  'reordered-row'{$unicodeActual.Rows=$unicodeActual.Rows[1,0,2]}
  'truncated-value'{$unicodeActual.Rows[2].Values[3]='synthetic'}
 }
 $caught=$false;try{Assert-CsvDirectSelectRows $unicodeActual.Schema $unicodeActual.Rows $unicodeCase}catch{$caught=$true};Check $caught
}
foreach($scope in @('SELECT-UNICODE-NULL','unknown')){$caught=$false;try{Get-CsvDirectSelectCase 0 -Scope $scope|Out-Null}catch{$caught=$true};Check $caught}
# Den tatsaechlichen Abschlusszweig auswerten; alle bisherigen Scopeaussagen erhalten.
$summaryNodes=@($driverTree.FindAll({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left.Extent.Text -ceq '$completionSummary'},$true))
if($summaryNodes.Count -ne 1){throw 'CSV_COMPLETION_SUMMARY_IDENTITY'}
$summarize=[scriptblock]::Create($summaryNodes[0].Extent.Text+'; $completionSummary')
foreach($TestScope in @('quote-expansion','crlf-ceilings','null-token-ceilings','header-text-ceilings','unicode-text-ceilings','control-text-ceilings','keepdata-ceilings','budget-parameter-preservation','select-output-ceilings','select-unicode-null','caller-transaction-preservation','schema-target-preservation','late-parser-syntax','late-parser-rectangular','writer-cell-preservation','target-constraint-preservation','null-representation-preservation','source-metadata-preservation','parser-argument-preservation','writer-argument-preservation','writer-header-preservation','empty-result-preservation','reserved-temp-namespace-preservation','writer-local-source-name-preservation','reserved-temp-prefix-preservation','header-only-preservation','null-token-value-preservation','trailing-empty-field-preservation','quoted-temp-name-preservation','source-target-alias-preservation','lower-value-budget-preservation','lower-output-budget-preservation','header-row-budget-preservation','alternate-separator-preservation','lower-input-budget-preservation','header-cell-budget-preservation')){
 $isDirectSelect=$TestScope -cin @('select-output-ceilings','select-unicode-null')
 $expected=if($isDirectSelect){'direct-SELECT/TDS/types/full-UTF16-text/exact-16MiB/plus-two/no-partial-result/source-preservation/repeat/uninstall'}elseif($TestScope -ceq 'budget-parameter-preservation'){'eight-invalid-upper-budgets-per-mode/full-16MiB-caller-targets/source-target-preservation/repeat/uninstall'}elseif($TestScope -ceq 'schema-target-preservation'){'eight-KeepData1-schema-rejections-SQL51025-state1-per-mode/full-16MiB-caller-targets/source-target-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'late-parser-syntax'){'eight-late-parser-syntax-rejections-SQL55301-state1-per-mode/exact-16MiB-input/KeepData0-1/full-16MiB-target-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'late-parser-rectangular'){'eight-late-parser-width-rejections-SQL55302-state1-per-mode/exact-16MiB-input/KeepData0-1/full-16MiB-target-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'writer-cell-preservation'){'eight-writer-cell-rejections-SQL55306-state1-per-mode/KeepData0-1/full-16MiB-target/full-source-target-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'target-constraint-preservation'){'eight-target-constraint-rejections-SQL547-per-mode/KeepData0-1/standalone-caller-transactions/full-16MiB-target-source-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'null-representation-preservation'){'eight-null-representation-rejections-SQL55307-state1-per-mode/KeepData0-1/full-source/full-16MiB-target-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'source-metadata-preservation'){'eight-source-metadata-rejections-SQL55305-state1-per-mode/KeepData0-1/full-source-schema/full-16MiB-target-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'parser-argument-preservation'){'eight-parser-argument-rejections-SQL55300-state1-per-mode/KeepData0-1/full-16MiB-target-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'writer-argument-preservation'){'eight-writer-argument-rejections-SQL55300-state1-per-mode/KeepData0-1/full-source/full-16MiB-target-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'writer-header-preservation'){'eight-writer-header-rejections-SQL55306-state1-per-mode/KeepData0-1/full-source/full-16MiB-target-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'empty-result-preservation'){'eight-positive-empty-results-per-mode/KeepData0-1/full-prior-target-contract/source-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'reserved-temp-namespace-preservation'){'eight-reserved-writer-temp-rejections-SQL55304-state1-per-mode/KeepData0-1/full-source/16MiB-target-probe-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'writer-local-source-name-preservation'){'eight-writer-local-source-name-rejections-SQL55304-state1-per-mode/KeepData0-1/full-independent-caller-source/16MiB-target-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'reserved-temp-prefix-preservation'){'eight-reserved-prefix-rejections-SQL55304-state1-per-mode/KeepData0-1/full-source/16MiB-target-schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'header-only-preservation'){'eight-positive-header-only-results-per-mode/KeepData0-1/full-source/16MiB-prior-target-contract/schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'null-token-value-preservation'){'eight-positive-null-token-value-results-per-mode/KeepData0-1/exact-NULL-text-distinction/full-source/16MiB-prior-target-contract/schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'trailing-empty-field-preservation'){'eight-positive-trailing-empty-results-per-mode/KeepData0-1/EOF-record-boundary/full-source/16MiB-prior-target-contract/schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'quoted-temp-name-preservation'){'eight-positive-quoted-temp-name-results-per-mode/KeepData0-1/full-source/16MiB-prior-target-contract/schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'source-target-alias-preservation'){'eight-source-target-alias-rejections-SQL55308-state1-per-mode/KeepData0-1/full-16MiB-shared-caller-object/schema-preservation/repeat/uninstall'}elseif($TestScope -ceq 'lower-value-budget-preservation'){'eight-lowered-value-budget-cases-per-mode/exact-1MiB-plus-two/four-SQL55303-state1/KeepData0-1/full-source/16MiB-prior-target-contract/repeat/uninstall'}elseif($TestScope -ceq 'lower-output-budget-preservation'){'eight-lowered-output-budget-cases-per-mode/exact-1MiB-plus-two/four-SQL55303-state1/KeepData0-1/full-source/16MiB-prior-target-contract/repeat/uninstall'}elseif($TestScope -ceq 'header-row-budget-preservation'){'eight-header-row-budget-cases-per-mode/HEADER-exempt-DATA-limit1/four-SQL55303-state1/KeepData0-1/full-source/16MiB-prior-target-contract/repeat/uninstall'}elseif($TestScope -ceq 'alternate-separator-preservation'){'eight-positive-alternate-separator-cases-per-mode/semicolon-tab/KeepData0-1/full-source/16MiB-prior-target-contract/repeat/uninstall'}elseif($TestScope -ceq 'lower-input-budget-preservation'){'eight-lowered-parser-input-budget-cases-per-mode/exact-1MiB-plus-two/quotes-header-CRLF/four-SQL55303-state1/KeepData0-1/full-source/16MiB-prior-target-contract/repeat/uninstall'}elseif($TestScope -ceq 'header-cell-budget-preservation'){'eight-header-cell-budget-cases-per-mode/HEADER-included-global-cell-limit2/four-SQL55303-state1/KeepData0-1/full-source/16MiB-prior-target-contract/repeat/uninstall'}else{'exact-16MiB/plus-two-UTF16-bytes/input/output/source/target-preservation/repeat/uninstall'}
 Check ((& $summarize) -ceq $expected)
}
Write-Output ('PASS CSV_GUARD_ORACLE_CONTROLS CHECKS='+$checks+' SYNTHETIC_ONLY')
