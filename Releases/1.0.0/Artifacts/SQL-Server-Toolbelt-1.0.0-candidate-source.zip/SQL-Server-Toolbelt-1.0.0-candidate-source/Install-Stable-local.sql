-- SQL Server Toolbelt: aus aktuellen Modulskripten erzeugtes Deployment.
-- SQLCMD-Modus und Fehlerabbruch erforderlich (sqlcmd -b -f 65001).
-- In frischer exklusiver Verbindung in der gewählten Zieldatenbank ausführen.
-- Keine Gesamttransaktion; frühere erfolgreiche Module bleiben bei Fehlern installiert.
-- Bestehende Versions-/Dependency-/Trust-/Migrationsgates bleiben wirksam.
-- DeploymentMode: local
:ON ERROR EXIT
GO
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.binary.bit-operations
:On Error exit
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @VersionProperty sysname =
          N'Toolbelt.Module.toolbelt.binary.bit-operations.Version'
    , @ModeProperty sysname =
          N'Toolbelt.Module.toolbelt.binary.bit-operations.DeploymentMode'
    , @DeploymentMode nvarchar(16) = LOWER(N'local')
    , @InstalledVersion nvarchar(64)
    , @ProductMajorVersion int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'));

DECLARE @ReleaseObjects TABLE
(
      ObjectName sysname NOT NULL PRIMARY KEY
    , ObjectType char(2) NOT NULL
);

INSERT INTO @ReleaseObjects (ObjectName, ObjectType)
VALUES
      (N'TVF_LeftShiftBigInt', 'IF')
    , (N'TVF_RightShiftBigInt', 'IF')
    , (N'TVF_BitCountBigInt', 'IF')
    , (N'TVF_GetBitBigInt', 'IF')
    , (N'TVF_SetBitBigInt', 'IF');

IF @ProductMajorVersion NOT IN (15, 16, 17)
    THROW 51250, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 51251, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), value)
FROM sys.extended_properties
WHERE class = 0 AND major_id = 0 AND minor_id = 0
  AND name = @VersionProperty;

IF @InstalledVersion IS NOT NULL AND @InstalledVersion <> N'1.0.0'
    THROW 51253, N'Die installierte Modulversion ist diesem Deployment nicht bekannt.', 1;

IF @InstalledVersion IS NULL
   AND EXISTS
       (
           SELECT 1
           FROM @ReleaseObjects AS release_objects
           WHERE OBJECT_ID
                 (
                     N'toolbelt_binary.' + release_objects.ObjectName
                 ) IS NOT NULL
       )
    THROW 51254, N'Ein Zielobjekt stammt nicht aus einem bekannten Toolbelt-Release.', 1;

IF SCHEMA_ID(N'toolbelt_binary') IS NULL
   AND HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    THROW 51252, N'In der Installationsdatenbank fehlt CREATE SCHEMA.', 1;
IF SCHEMA_ID(N'toolbelt_binary') IS NOT NULL
   AND HAS_PERMS_BY_NAME(N'toolbelt_binary', N'SCHEMA', N'ALTER') <> 1
    THROW 51252, N'Für toolbelt_binary fehlt ALTER.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
    THROW 51252, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;

BEGIN TRANSACTION;
DECLARE @LockResult int;
EXEC @LockResult = sys.sp_getapplock
      @Resource = N'toolbelt.deploy.toolbelt.binary.bit-operations'
    , @LockMode = N'Exclusive'
    , @LockOwner = N'Transaction'
    , @LockTimeout = 0
    , @DbPrincipal = N'public';
IF @LockResult < 0
    THROW 51257, N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.', 1;

IF SCHEMA_ID(N'toolbelt_binary') IS NULL
BEGIN
    EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_binary];';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.Managed', @value = 1
        , @level0type = N'SCHEMA', @level0name = N'toolbelt_binary';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.SchemaCategory', @value = N'binary'
        , @level0type = N'SCHEMA', @level0name = N'toolbelt_binary';
END;
GO
-- ============================================================================
-- Objekt:          toolbelt_binary.TVF_LeftShiftBigInt
-- Zweck:           Logischer 64-Bit-Left-Shift für bigint.
-- Parameter:       @Value bigint, @ShiftAmount bigint
-- Resultset:       Value bigint
-- Dependencies:    keine Toolbelt-Module
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF; decimal(38,0)-Arithmetik ohne Loop
-- Einschränkungen: Ausschließlich bigint; Binary-Typen sind nicht Teil V1.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_binary].[TVF_LeftShiftBigInt]
(
      @Value       bigint
    , @ShiftAmount bigint
)
RETURNS TABLE
AS
RETURN
(
    WITH Parameters AS
    (
        SELECT
              UnsignedValue =
                  CONVERT(decimal(38,0), @Value)
                  + CASE
                        WHEN @Value < 0
                            THEN CONVERT(decimal(38,0), 18446744073709551616)
                        ELSE CONVERT(decimal(38,0), 0)
                    END
            , EffectiveAmount = CONVERT
              (
                  int,
                  CASE
                      WHEN @ShiftAmount BETWEEN 0 AND 63 THEN @ShiftAmount
                      WHEN @ShiftAmount BETWEEN -63 AND -1
                          THEN -@ShiftAmount
                      ELSE 0
                  END
              )
            , IsLeft = CONVERT(bit, CASE WHEN @ShiftAmount >= 0 THEN 1 ELSE 0 END)
    ),
    Shifted AS
    (
        SELECT ShiftedUnsigned =
            CONVERT
            (
                decimal(38,0),
                CASE
                    WHEN @Value IS NULL OR @ShiftAmount IS NULL THEN NULL
                    WHEN @ShiftAmount NOT BETWEEN -63 AND 63 THEN 0
                    WHEN parameters.IsLeft = 1
                        THEN
                            (
                                parameters.UnsignedValue
                                % POWER
                                  (
                                      CONVERT(decimal(38,0), 2),
                                      64 - parameters.EffectiveAmount
                                  )
                            )
                            * POWER
                              (
                                  CONVERT(decimal(38,0), 2),
                                  parameters.EffectiveAmount
                              )
                    ELSE FLOOR
                         (
                             parameters.UnsignedValue
                             / POWER
                               (
                                   CONVERT(decimal(38,0), 2),
                                   parameters.EffectiveAmount
                               )
                         )
                END
            )
        FROM Parameters AS parameters
    )
    SELECT Value = CONVERT
    (
        bigint,
        CASE
            WHEN shifted.ShiftedUnsigned >=
                 CONVERT(decimal(38,0), 9223372036854775808)
                THEN shifted.ShiftedUnsigned
                     - CONVERT(decimal(38,0), 18446744073709551616)
            ELSE shifted.ShiftedUnsigned
        END
    )
    FROM Shifted AS shifted
);
GO
-- ============================================================================
-- Objekt:          toolbelt_binary.TVF_RightShiftBigInt
-- Zweck:           Logischer 64-Bit-Right-Shift für bigint.
-- Parameter:       @Value bigint, @ShiftAmount bigint
-- Resultset:       Value bigint
-- Dependencies:    TVF_LeftShiftBigInt im selben Modul
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF; relationale Wiederverwendung des Shift-Kerns
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_binary].[TVF_RightShiftBigInt]
(
      @Value       bigint
    , @ShiftAmount bigint
)
RETURNS TABLE
AS
RETURN
(
    SELECT shifted.Value
    FROM toolbelt_binary.TVF_LeftShiftBigInt
         (
               @Value
             , CASE
                   WHEN @ShiftAmount = CONVERT(bigint, -9223372036854775808)
                       THEN CONVERT(bigint, 64)
                   ELSE -@ShiftAmount
               END
         ) AS shifted
);
GO
-- ============================================================================
-- Objekt:          toolbelt_binary.TVF_BitCountBigInt
-- Zweck:           Zählt gesetzte Bits im vollständigen bigint-Bitmuster.
-- Parameter:       @Value bigint
-- Resultset:       Value bigint
-- Dependencies:    keine Toolbelt-Module
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF; acht Bytes werden set-basiert ausgewertet.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_binary].[TVF_BitCountBigInt]
(
    @Value bigint
)
RETURNS TABLE
AS
RETURN
(
    WITH Bytes AS
    (
        SELECT ByteValue = CONVERT
        (
            int,
            SUBSTRING(CONVERT(binary(8), @Value), positions.BytePosition, 1)
        )
        FROM
        (
            VALUES (1), (2), (3), (4), (5), (6), (7), (8)
        ) AS positions(BytePosition)
    )
    SELECT Value = CONVERT
    (
        bigint,
        CASE
            WHEN @Value IS NULL THEN NULL
            ELSE SUM
                 (
                       (bytes.ByteValue & 1)
                     + ((bytes.ByteValue & 2) / 2)
                     + ((bytes.ByteValue & 4) / 4)
                     + ((bytes.ByteValue & 8) / 8)
                     + ((bytes.ByteValue & 16) / 16)
                     + ((bytes.ByteValue & 32) / 32)
                     + ((bytes.ByteValue & 64) / 64)
                     + ((bytes.ByteValue & 128) / 128)
                 )
        END
    )
    FROM Bytes AS bytes
);
GO
-- ============================================================================
-- Objekt:          toolbelt_binary.TVF_GetBitBigInt
-- Zweck:           Liest ein Bit aus einem bigint-Bitmuster.
-- Parameter:       @Value bigint, @BitOffset bigint
-- Resultset:       Value bit, IsValid bit, ValidationCode tinyint
-- Dependencies:    keine Toolbelt-Module
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF; konstante decimal(38,0)-Arithmetik
-- Einschränkungen: Offset 0 bezeichnet das Least Significant Bit.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_binary].[TVF_GetBitBigInt]
(
      @Value     bigint
    , @BitOffset bigint
)
RETURNS TABLE
AS
RETURN
(
    WITH Parameters AS
    (
        SELECT
              UnsignedValue =
                  CONVERT(decimal(38,0), @Value)
                  + CASE
                        WHEN @Value < 0
                            THEN CONVERT(decimal(38,0), 18446744073709551616)
                        ELSE CONVERT(decimal(38,0), 0)
                    END
            , SafeOffset = CONVERT
              (
                  int,
                  CASE
                      WHEN @BitOffset BETWEEN 0 AND 63 THEN @BitOffset
                      ELSE 0
                  END
              )
    )
    SELECT
          Value = CONVERT
          (
              bit,
              CASE
                  WHEN @Value IS NULL OR @BitOffset IS NULL
                    OR @BitOffset NOT BETWEEN 0 AND 63
                      THEN NULL
                  ELSE FLOOR
                       (
                           parameters.UnsignedValue
                           / POWER
                             (
                                 CONVERT(decimal(38,0), 2),
                                 parameters.SafeOffset
                             )
                       ) % 2
              END
          )
        , IsValid = CONVERT
          (
              bit,
              CASE
                  WHEN @Value IS NULL OR @BitOffset IS NULL THEN NULL
                  WHEN @BitOffset NOT BETWEEN 0 AND 63 THEN 0
                  ELSE 1
              END
          )
        , ValidationCode = CONVERT
          (
              tinyint,
              CASE
                  WHEN @Value IS NULL OR @BitOffset IS NULL THEN NULL
                  WHEN @BitOffset NOT BETWEEN 0 AND 63 THEN 10
                  ELSE 0
              END
          )
    FROM Parameters AS parameters
);
GO
-- ============================================================================
-- Objekt:          toolbelt_binary.TVF_SetBitBigInt
-- Zweck:           Setzt oder löscht ein Bit in einem bigint-Bitmuster.
-- Parameter:       @Value bigint, @BitOffset bigint, @BitValue int = 1
-- Resultset:       Value bigint, IsValid bit, ValidationCode tinyint
-- Dependencies:    keine Toolbelt-Module
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF; konstante decimal(38,0)-Arithmetik
-- Einschränkungen: Offset 0 bezeichnet das Least Significant Bit.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_binary].[TVF_SetBitBigInt]
(
      @Value     bigint
    , @BitOffset bigint
    , @BitValue  int = 1
)
RETURNS TABLE
AS
RETURN
(
    WITH Parameters AS
    (
        SELECT
              UnsignedValue =
                  CONVERT(decimal(38,0), @Value)
                  + CASE
                        WHEN @Value < 0
                            THEN CONVERT(decimal(38,0), 18446744073709551616)
                        ELSE CONVERT(decimal(38,0), 0)
                    END
            , BitPower = POWER
              (
                  CONVERT(decimal(38,0), 2),
                  CONVERT
                  (
                      int,
                      CASE
                          WHEN @BitOffset BETWEEN 0 AND 63 THEN @BitOffset
                          ELSE 0
                      END
                  )
              )
    ),
    Resolved AS
    (
        SELECT ResultUnsigned =
            parameters.UnsignedValue
            + (
                  CONVERT(decimal(38,0), @BitValue)
                  - FLOOR(parameters.UnsignedValue / parameters.BitPower) % 2
              ) * parameters.BitPower
        FROM Parameters AS parameters
    )
    SELECT
          Value = CONVERT
          (
              bigint,
              CASE
                  WHEN @Value IS NULL
                    OR @BitOffset IS NULL
                    OR @BitValue IS NULL
                    OR @BitOffset NOT BETWEEN 0 AND 63
                    OR @BitValue NOT IN (0, 1)
                      THEN NULL
                  WHEN resolved.ResultUnsigned >=
                       CONVERT(decimal(38,0), 9223372036854775808)
                      THEN resolved.ResultUnsigned
                           - CONVERT
                             (
                                 decimal(38,0),
                                 18446744073709551616
                             )
                  ELSE resolved.ResultUnsigned
              END
          )
        , IsValid = CONVERT
          (
              bit,
              CASE
                  WHEN @Value IS NULL
                    OR @BitOffset IS NULL
                    OR @BitValue IS NULL
                      THEN NULL
                  WHEN @BitOffset NOT BETWEEN 0 AND 63
                    OR @BitValue NOT IN (0, 1)
                      THEN 0
                  ELSE 1
              END
          )
        , ValidationCode = CONVERT
          (
              tinyint,
              CASE
                  WHEN @Value IS NULL
                    OR @BitOffset IS NULL
                    OR @BitValue IS NULL
                      THEN NULL
                  WHEN @BitOffset NOT BETWEEN 0 AND 63 THEN 10
                  WHEN @BitValue NOT IN (0, 1) THEN 11
                  ELSE 0
              END
          )
    FROM Resolved AS resolved
);
GO
SET NOCOUNT ON;
BEGIN TRY
    DECLARE
          @VersionProperty sysname =
              N'Toolbelt.Module.toolbelt.binary.bit-operations.Version'
        , @ModeProperty sysname =
              N'Toolbelt.Module.toolbelt.binary.bit-operations.DeploymentMode';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties
           WHERE class = 0 AND major_id = 0 AND minor_id = 0
             AND name = @VersionProperty
       )
        EXEC sys.sp_updateextendedproperty
             @name = @VersionProperty, @value = N'1.0.0';
    ELSE
        EXEC sys.sp_addextendedproperty
             @name = @VersionProperty, @value = N'1.0.0';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties
           WHERE class = 0 AND major_id = 0 AND minor_id = 0
             AND name = @ModeProperty
       )
        EXEC sys.sp_updateextendedproperty
             @name = @ModeProperty, @value = N'local';
    ELSE
        EXEC sys.sp_addextendedproperty
             @name = @ModeProperty, @value = N'local';

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.binary.bit-operations
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.conversion.base64
:On Error exit

-- ============================================================================
-- Zweck:     Erst-, Upgrade- und Wiederholungsdeployment
-- Modul:     toolbelt.conversion.base64 v1.1.0
-- Schema:    toolbelt_conversion
-- Erfordert: SQL Server 2019, 2022 oder 2025
-- Modus:     SQLCMD; Ausführung aus diesem Deployment-Verzeichnis
-- Parameter: DeploymentMode=local|central
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'tempdb..#tbx_Base64ReleaseObjects', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_Base64ReleaseObjects;
END;

IF OBJECT_ID(N'tempdb..#tbx_Base64DeployState', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_Base64DeployState;
END;

CREATE TABLE #tbx_Base64ReleaseObjects
(
      ReleaseVersion nvarchar(64) NOT NULL
    , SchemaName     sysname      NOT NULL
    , ObjectName     sysname      NOT NULL
    , ObjectType     char(2)      NOT NULL
    , CONSTRAINT PK_tbx_Base64ReleaseObjects
          PRIMARY KEY (ReleaseVersion, SchemaName, ObjectName)
);

INSERT INTO #tbx_Base64ReleaseObjects
(
      ReleaseVersion
    , SchemaName
    , ObjectName
    , ObjectType
)
VALUES
      (N'1.0.0', N'toolbelt_conversion', N'SVF_Base64Encode', 'FN')
    , (N'1.0.0', N'toolbelt_conversion', N'SVF_Base64Decode', 'FN')
    , (N'1.1.0', N'toolbelt_conversion', N'TVF_Base64Encode', 'IF')
    , (N'1.1.0', N'toolbelt_conversion', N'TVF_Base64Decode', 'IF')
    , (N'1.1.0', N'toolbelt_conversion', N'SVF_Base64Encode', 'FN')
    , (N'1.1.0', N'toolbelt_conversion', N'SVF_Base64Decode', 'FN')
    , (N'1.1.0', N'toolbelt_conversion', N'TVF_Base64EncodeStatus', 'TF')
    , (N'1.1.0', N'toolbelt_conversion', N'TVF_Base64DecodeStatus', 'TF');

CREATE TABLE #tbx_Base64DeployState
(
      TargetVersion    nvarchar(64) NOT NULL
    , InstalledVersion nvarchar(64) NULL
    , DeploymentMode   nvarchar(16) NOT NULL
    , SchemaCreated     bit          NOT NULL
);

DECLARE
      @TargetVersion        nvarchar(64) = N'1.1.0'
    , @DeploymentMode       nvarchar(16) = LOWER(N'local')
    , @InstalledVersion     nvarchar(64)
    , @VersionPropertyName  sysname =
          N'Toolbelt.Module.toolbelt.conversion.base64.Version'
    , @ProductMajorVersion  int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @SchemaId             int = SCHEMA_ID(N'toolbelt_conversion')
    , @CollisionSchema      sysname
    , @CollisionObject      sysname
    , @LockResult           int
    , @DropSql              nvarchar(max)
    , @SchemaCreated        bit = 0;

IF @ProductMajorVersion NOT IN (15, 16, 17)
BEGIN
    THROW 51040, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
END;

IF @DeploymentMode NOT IN (N'local', N'central')
BEGIN
    THROW 51041, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

IF @InstalledVersion IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM #tbx_Base64ReleaseObjects AS ro
           WHERE ro.ReleaseVersion COLLATE Latin1_General_100_BIN2
                     = @InstalledVersion COLLATE Latin1_General_100_BIN2
       )
BEGIN
    THROW 51043, N'Die installierte Modulversion ist diesem Deployment nicht als unterstütztes Vorgängerrelease bekannt.', 1;
END;

IF @SchemaId IS NULL
BEGIN
    IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    BEGIN
        THROW 51042, N'Zum Anlegen von toolbelt_conversion fehlt CREATE SCHEMA in der Installationsdatenbank.', 1;
    END;
END;
ELSE IF HAS_PERMS_BY_NAME(N'toolbelt_conversion', N'SCHEMA', N'ALTER') <> 1
BEGIN
    THROW 51042, N'Für das vorhandene Schema toolbelt_conversion fehlt ALTER.', 1;
END;

IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
BEGIN
    THROW 51042, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;
END;

/*
 * Neue Zielnamen dürfen kein frameworkfremdes Objekt überschreiben. Ein Name
 * gilt nur dann als Framework-Bestand, wenn er im bekannten installierten
 * Release enthalten ist.
 */
SELECT TOP (1)
      @CollisionSchema = target.SchemaName
    , @CollisionObject = target.ObjectName
FROM #tbx_Base64ReleaseObjects AS target
INNER JOIN sys.schemas AS schemas
    ON schemas.name COLLATE Latin1_General_100_BIN2
          = target.SchemaName COLLATE Latin1_General_100_BIN2
INNER JOIN sys.objects AS objects
    ON objects.schema_id = schemas.schema_id
   AND objects.name COLLATE Latin1_General_100_BIN2
          = target.ObjectName COLLATE Latin1_General_100_BIN2
WHERE target.ReleaseVersion = @TargetVersion
  AND
  (
      @InstalledVersion IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM #tbx_Base64ReleaseObjects AS previous
             WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                       = @InstalledVersion COLLATE Latin1_General_100_BIN2
               AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                       = target.SchemaName COLLATE Latin1_General_100_BIN2
               AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                       = target.ObjectName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY target.ObjectName COLLATE Latin1_General_100_BIN2;

IF @CollisionObject IS NOT NULL
BEGIN
    DECLARE @CollisionMessage nvarchar(2048) =
        N'Das neue Framework-Objekt '
        + QUOTENAME(@CollisionSchema)
        + N'.'
        + QUOTENAME(@CollisionObject)
        + N' ist bereits vorhanden, stammt aber nicht aus dem bekannten installierten Release.';
    SET @CollisionMessage = REPLACE(@CollisionMessage, N'%', N'%%');
    THROW 51044, @CollisionMessage, 1;
END;

INSERT INTO #tbx_Base64DeployState
(
      TargetVersion
    , InstalledVersion
    , DeploymentMode
    , SchemaCreated
)
VALUES
(
      @TargetVersion
    , @InstalledVersion
    , @DeploymentMode
    , 0
);

BEGIN TRY
    IF OBJECT_ID(N'toolbelt_conversion.TVF_Base64EncodeStatus') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_conversion.TVF_Base64EncodeStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(256),value)=N'toolbelt.conversion.base64') THROW 51044,N'Neuer Security-Zielname ist frameworkfremd belegt.',1;
IF OBJECT_ID(N'toolbelt_conversion.TVF_Base64DecodeStatus') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_conversion.TVF_Base64DecodeStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(256),value)=N'toolbelt.conversion.base64') THROW 51044,N'Neuer Security-Zielname ist frameworkfremd belegt.',1;
BEGIN TRANSACTION;

    EXEC @LockResult = sys.sp_getapplock
          @Resource    = N'toolbelt.deploy.toolbelt.conversion.base64'
        , @LockMode    = N'Exclusive'
        , @LockOwner   = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
    BEGIN
        THROW 51047, N'Ein paralleles Deployment von toolbelt.conversion.base64 ist bereits aktiv.', 1;
    END;

    DECLARE @CurrentInstalledVersion nvarchar(64);

    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
           <> ISNULL(@InstalledVersion, N'') COLLATE Latin1_General_100_BIN2
    BEGIN
        THROW 51047, N'Der installierte Modulstand hat sich seit dem Preflight verändert.', 1;
    END;

    SET @CollisionSchema = NULL;
    SET @CollisionObject = NULL;

    SELECT TOP (1)
          @CollisionSchema = target.SchemaName
        , @CollisionObject = target.ObjectName
    FROM #tbx_Base64ReleaseObjects AS target
    INNER JOIN sys.schemas AS schemas
        ON schemas.name COLLATE Latin1_General_100_BIN2
              = target.SchemaName COLLATE Latin1_General_100_BIN2
    INNER JOIN sys.objects AS objects
        ON objects.schema_id = schemas.schema_id
       AND objects.name COLLATE Latin1_General_100_BIN2
              = target.ObjectName COLLATE Latin1_General_100_BIN2
    WHERE target.ReleaseVersion = @TargetVersion
      AND
      (
          @InstalledVersion IS NULL
          OR NOT EXISTS
             (
                 SELECT 1
                 FROM #tbx_Base64ReleaseObjects AS previous
                 WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                           = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                           = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                           = target.ObjectName COLLATE Latin1_General_100_BIN2
             )
      );

    IF @CollisionObject IS NOT NULL
    BEGIN
        THROW 51047, N'Ein Zielobjekt hat sich seit dem Preflight verändert oder ist neu hinzugekommen.', 1;
    END;

    IF SCHEMA_ID(N'toolbelt_conversion') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_conversion];';
        SET @SchemaCreated = 1;

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.Managed'
            , @value      = 1
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_conversion';

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.SchemaCategory'
            , @value      = N'conversion'
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_conversion';
    END;

    UPDATE #tbx_Base64DeployState
    SET SchemaCreated = @SchemaCreated;

    /*
     * Ein lokal verändertes Release-Objekt mit falschem Typ wird anhand des
     * bekannten Vorgänger-Manifests entfernt. Fremde Namen bleiben unberührt.
     */
    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN objects.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN objects.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN objects.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(schemas.name)
                    + N'.'
                    + QUOTENAME(objects.name)
                    + N';'
                FROM #tbx_Base64ReleaseObjects AS target
                INNER JOIN #tbx_Base64ReleaseObjects AS previous
                    ON previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.schemas AS schemas
                    ON schemas.name COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS objects
                    ON objects.schema_id = schemas.schema_id
                   AND objects.name COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE target.ReleaseVersion = @TargetVersion
                  AND objects.type COLLATE Latin1_General_100_BIN2
                        <> target.ObjectType COLLATE Latin1_General_100_BIN2
                  AND objects.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY objects.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO

-- ============================================================================
-- Objekt:          toolbelt_conversion.TVF_Base64EncodeStatus
-- Zweck:           Begrenzter kanonischer Statuskern; Legacy-Wertfassade unten.
-- Parameter:       @Value varbinary(max), @UrlSafe bit = 0
-- Resultset:       EncodedValue varchar(max), Status varchar(16)
-- Vertrag:         Documentation/TVF_Base64EncodeStatus.md
-- Versionen:       SQL Server 2019/2022/2025; Windows/Linux
-- Rechte:          SELECT/REFERENCES; keine zusätzlichen Rechte oder Grants.
-- Performance:     MSTVF mit Vorabgrenzen; keine Inline-/Parallelitätszusage.
-- Grenzen:         Freigegebener Vertrag SECURITY_HARDENING_2026_10.md.
-- ============================================================================
CREATE OR ALTER FUNCTION [toolbelt_conversion].[TVF_Base64EncodeStatus]
(@Value varbinary(max),@UrlSafe bit=0)
RETURNS @Result TABLE(EncodedValue varchar(max) NULL,Status varchar(16) NOT NULL)
WITH SCHEMABINDING
AS
BEGIN
    IF @Value IS NULL BEGIN INSERT @Result VALUES(NULL,'SQL_NULL'); RETURN; END;
    IF DATALENGTH(@Value)>16777216 BEGIN INSERT @Result VALUES(NULL,'LIMIT'); RETURN; END;
    DECLARE @Encoded varchar(max);
    WITH Encoded AS
    (
        SELECT EncodedValue =
            CASE
                WHEN @Value IS NULL
                    THEN CONVERT(varchar(max), NULL)
                ELSE
                    CAST(N'' AS xml).value
                    (
                          N'xs:base64Binary(sql:variable("@Value"))'
                        , N'varchar(max)'
                    )
            END
    ),
    UrlSafe AS
    (
        SELECT
              EncodedValue
            , TransformedValue =
                  REPLACE(REPLACE(EncodedValue, '+', '-'), '/', '_')
        FROM Encoded
    )
    SELECT @Encoded =
        CONVERT
        (
              varchar(max)
            , CASE
                  WHEN ISNULL(@UrlSafe, 0) <> 1 OR EncodedValue IS NULL
                      THEN EncodedValue
                  ELSE LEFT
                       (
                             TransformedValue
                           , DATALENGTH(TransformedValue)
                             - CASE
                                   WHEN RIGHT(TransformedValue, 2) = '=='
                                       THEN 2
                                   WHEN RIGHT(TransformedValue, 1) = '='
                                       THEN 1
                                   ELSE 0
                               END
                       )
              END
        )
    FROM UrlSafe;
    INSERT @Result VALUES(@Encoded,'OK'); RETURN;
END;
GO
-- Legacy-Wertfassade: gleicher Inputvertrag; Limitabbildung siehe Objektseite.
-- Vertrag: Documentation/TVF_Base64Encode.md
CREATE OR ALTER FUNCTION [toolbelt_conversion].[TVF_Base64Encode]
(@Value varbinary(max),@UrlSafe bit=0)
RETURNS TABLE AS RETURN
(SELECT EncodedValue FROM toolbelt_conversion.TVF_Base64EncodeStatus(@Value,@UrlSafe));
GO
-- ============================================================================
-- Objekt:          toolbelt_conversion.TVF_Base64DecodeStatus
-- Zweck:           Begrenzter kanonischer Statuskern; Legacy-Wertfassade unten.
-- Parameter:       @Value varchar(max)
-- Resultset:       DecodedValue varbinary(max), Status varchar(16)
-- Vertrag:         Documentation/TVF_Base64DecodeStatus.md
-- Versionen:       SQL Server 2019/2022/2025; Windows/Linux
-- Rechte:          SELECT/REFERENCES; keine zusätzlichen Rechte oder Grants.
-- Performance:     MSTVF mit Vorabgrenzen; keine Inline-/Parallelitätszusage.
-- Grenzen:         Freigegebener Vertrag SECURITY_HARDENING_2026_10.md.
-- ============================================================================
CREATE OR ALTER FUNCTION [toolbelt_conversion].[TVF_Base64DecodeStatus]
(@Value varchar(max))
RETURNS @Result TABLE(DecodedValue varbinary(max) NULL,Status varchar(16) NOT NULL)
WITH SCHEMABINDING
AS
BEGIN
    IF @Value IS NULL BEGIN INSERT @Result VALUES(NULL,'SQL_NULL'); RETURN; END;
    IF DATALENGTH(@Value)>25165824 BEGIN INSERT @Result VALUES(NULL,'LIMIT'); RETURN; END;
    DECLARE @Canonical varchar(max),@InvalidFormat bit=0,@Expected bigint,@Decoded varbinary(max),
        @Normalized varchar(max),@Length bigint,@FirstPadding bigint,@PaddingCount bigint,@LengthRemainder bigint;
    -- Normalisierung einmal materialisieren; CTE-Expansion scannte große
    -- gültige Inputs mehrfach. Die binäre ASCII-Prüfung nutzt denselben Stand.
    SET @Normalized=REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@Value,'-','+'),'_','/'),CHAR(32),''),CHAR(9),''),CHAR(13),''),CHAR(10),'');
    SET @Length=DATALENGTH(@Normalized);
    SET @FirstPadding=NULLIF(CHARINDEX('=',@Normalized COLLATE Latin1_General_100_BIN2),0);
    SET @PaddingCount=CASE WHEN @FirstPadding IS NULL THEN 0 ELSE @Length-@FirstPadding+1 END;
    SET @LengthRemainder=COALESCE(@FirstPadding-1,@Length)%4;
    IF @Normalized COLLATE Latin1_General_100_BIN2 LIKE '%[^A-Za-z0-9+/=]%'
        SET @InvalidFormat=1;
    IF (@FirstPadding IS NULL AND @LengthRemainder=1)
       OR (@FirstPadding IS NOT NULL AND (@PaddingCount NOT IN(1,2)
           OR DATALENGTH(REPLACE(SUBSTRING(@Normalized,@FirstPadding,@PaddingCount),'=',''))<>0
           OR @Length%4<>0 OR (@PaddingCount=1 AND @LengthRemainder<>3) OR (@PaddingCount=2 AND @LengthRemainder<>2)))
        SET @InvalidFormat=1;
    SET @Canonical=CASE WHEN @FirstPadding IS NULL AND @LengthRemainder=2 THEN @Normalized+'=='
                        WHEN @FirstPadding IS NULL AND @LengthRemainder=3 THEN @Normalized+'=' ELSE @Normalized END;
    IF @InvalidFormat=1 BEGIN INSERT @Result VALUES(NULL,'INVALID'); RETURN; END;
    SET @Expected=(DATALENGTH(@Canonical)/4)*CONVERT(bigint,3)
        -CASE WHEN RIGHT(@Canonical,2)='==' THEN 2 WHEN RIGHT(@Canonical,1)='=' THEN 1 ELSE 0 END;
    IF @Expected>16777216 BEGIN INSERT @Result VALUES(NULL,'LIMIT'); RETURN; END;
    IF DATALENGTH(@Canonical)=0 SET @Decoded=0x;
    ELSE SET @Decoded=CAST(N'' AS xml).value(N'xs:base64Binary(sql:variable("@Canonical"))',N'varbinary(max)');
    INSERT @Result VALUES(@Decoded,'OK'); RETURN;
END;
GO
-- Legacy-Wertfassade: gleicher Inputvertrag; Limitabbildung siehe Objektseite.
-- Vertrag: Documentation/TVF_Base64Decode.md
CREATE OR ALTER FUNCTION [toolbelt_conversion].[TVF_Base64Decode](@Value varchar(max))
RETURNS TABLE AS RETURN
(SELECT DecodedValue=CASE WHEN Status='INVALID'
    THEN CONVERT(varbinary(max),CONVERT(int,LEFT('toolbelt.invalid.base64'+ISNULL(@Value,''),23)))
    ELSE DecodedValue END FROM toolbelt_conversion.TVF_Base64DecodeStatus(@Value));
GO
-- ============================================================================
-- Objekt:          toolbelt_conversion.SVF_Base64Encode
-- Zweck:           Binärdaten als Base64 oder Base64URL codieren
-- Parameter:       @Value varbinary(max), @UrlSafe bit = 0
-- Rückgabewert:    varchar(max); NULL bleibt NULL
-- Dependencies:    keine Toolbelt-Module; T-SQL/XML-Provider
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Convenience-Wrapper; für Mengen TVF_Base64Encode verwenden
-- Collation:       Rückgabewert verwendet die Datenbank-Default-Collation
-- Einschränkungen: Base64URL wird ohne Padding ausgegeben
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_conversion].[SVF_Base64Encode]
(
      @Value   varbinary(max)
    , @UrlSafe bit = 0
)
RETURNS varchar(max)
AS
BEGIN
    DECLARE @EncodedValue varchar(max);

    SELECT @EncodedValue = encoded.EncodedValue
    FROM toolbelt_conversion.TVF_Base64Encode(@Value, @UrlSafe) AS encoded;

    RETURN @EncodedValue;
END;
GO
-- ============================================================================
-- Objekt:          toolbelt_conversion.SVF_Base64Decode
-- Zweck:           Base64 oder Base64URL in Binärdaten decodieren
-- Parameter:       @Value varchar(max)
-- Rückgabewert:    varbinary(max); NULL bleibt NULL
-- Dependencies:    keine Toolbelt-Module; T-SQL/XML-Provider
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Convenience-Wrapper; für Mengen TVF_Base64Decode verwenden
-- Collation:       ASCII-Vertrag; Vergleiche sind nicht sprachabhängig
-- Einschränkungen: ignoriert nur Space, Tab, CR und LF
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_conversion].[SVF_Base64Decode]
(
    @Value varchar(max)
)
RETURNS varbinary(max)
AS
BEGIN
    DECLARE @DecodedValue varbinary(max);

    SELECT @DecodedValue = decoded.DecodedValue
    FROM toolbelt_conversion.TVF_Base64Decode(@Value) AS decoded;

    RETURN @DecodedValue;
END;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    DECLARE
          @DeploymentMode      nvarchar(16)
        , @TargetVersion       nvarchar(64)
        , @VersionPropertyName sysname =
              N'Toolbelt.Module.toolbelt.conversion.base64.Version'
        , @ModePropertyName    sysname =
              N'Toolbelt.Module.toolbelt.conversion.base64.DeploymentMode';

    SELECT
          @DeploymentMode = DeploymentMode
        , @TargetVersion = TargetVersion
    FROM #tbx_Base64DeployState;

    IF XACT_STATE() <> 1
       OR OBJECT_ID(N'toolbelt_conversion.TVF_Base64Encode', N'IF') IS NULL
       OR OBJECT_ID(N'toolbelt_conversion.TVF_Base64Decode', N'IF') IS NULL
       OR OBJECT_ID(N'toolbelt_conversion.SVF_Base64Encode', N'FN') IS NULL
       OR OBJECT_ID(N'toolbelt_conversion.SVF_Base64Decode', N'FN') IS NULL
    BEGIN
        THROW 51048, N'Die Framework-Funktionen wurden nicht vollständig innerhalb der Deployment-Transaktion angelegt.', 1;
    END;

    DECLARE @Objects TABLE
    (
          ObjectOrdinal int IDENTITY(1, 1) NOT NULL
        , ObjectName    sysname            NOT NULL
    );

    INSERT INTO @Objects (ObjectName)
    VALUES
          (N'TVF_Base64Encode')
        , (N'TVF_Base64Decode')
        , (N'SVF_Base64Encode')
        , (N'SVF_Base64Decode'), (N'TVF_Base64EncodeStatus'), (N'TVF_Base64DecodeStatus');

    DECLARE
          @ObjectOrdinal int = 1
        , @ObjectCount   int = (SELECT COUNT(*) FROM @Objects)
        , @ObjectName    sysname
        , @ObjectId      int
        , @SourceHash    varchar(64)
        , @PropertyOrdinal int
        , @PropertyCount   int
        , @PropertyName    sysname
        , @PropertyValue   nvarchar(4000);

    DECLARE @Properties TABLE
    (
          PropertyOrdinal int            NOT NULL PRIMARY KEY
        , PropertyName    sysname        NOT NULL
        , PropertyValue   nvarchar(4000) NOT NULL
    );

    WHILE @ObjectOrdinal <= @ObjectCount
    BEGIN
        SELECT @ObjectName = ObjectName
        FROM @Objects
        WHERE ObjectOrdinal = @ObjectOrdinal;

        SET @ObjectId = OBJECT_ID
        (
            QUOTENAME(N'toolbelt_conversion') + N'.' + QUOTENAME(@ObjectName)
        );
        SET @SourceHash = CONVERT
        (
              varchar(64)
            , HASHBYTES
              (
                  N'SHA2_256'
                , CONVERT(varbinary(max), OBJECT_DEFINITION(@ObjectId))
              )
            , 2
        );

        INSERT INTO @Properties
        (
              PropertyOrdinal
            , PropertyName
            , PropertyValue
        )
        VALUES
              (1, N'Toolbelt.ModuleId', N'toolbelt.conversion.base64')
            , (2, N'Toolbelt.ModuleVersion', @TargetVersion)
            , (3, N'Toolbelt.ContractVersion', N'1.0')
            , (4, N'Toolbelt.DeploymentMode', @DeploymentMode)
            , (5, N'Toolbelt.SourceHash', CONVERT(nvarchar(4000), @SourceHash));

        SET @PropertyOrdinal = 1;
        SET @PropertyCount = (SELECT COUNT(*) FROM @Properties);

        WHILE @PropertyOrdinal <= @PropertyCount
        BEGIN
            SELECT
                  @PropertyName = PropertyName
                , @PropertyValue = PropertyValue
            FROM @Properties
            WHERE PropertyOrdinal = @PropertyOrdinal;

            IF EXISTS
               (
                   SELECT 1
                   FROM sys.extended_properties AS ep
                   WHERE ep.class = 1
                     AND ep.major_id = @ObjectId
                     AND ep.minor_id = 0
                     AND ep.name = @PropertyName
               )
            BEGIN
                EXEC sys.sp_updateextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_conversion'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;
            ELSE
            BEGIN
                EXEC sys.sp_addextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_conversion'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;

            SET @PropertyOrdinal += 1;
        END;

        DELETE FROM @Properties;
        SET @ObjectOrdinal += 1;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @VersionPropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @ModePropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.conversion.base64
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.conversion.integer-base
:On Error exit

-- ============================================================================
-- Zweck:     Erst-, Upgrade- und Wiederholungsdeployment
-- Modul:     toolbelt.conversion.integer-base v1.1.0
-- Schema:    toolbelt_conversion
-- Erfordert: SQL Server 2019, 2022 oder 2025
-- Modus:     SQLCMD; Ausführung aus diesem Deployment-Verzeichnis
-- Parameter: DeploymentMode=local|central
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'tempdb..#tbx_IntegerBaseReleaseObjects', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_IntegerBaseReleaseObjects;
END;

IF OBJECT_ID(N'tempdb..#tbx_IntegerBaseDeployState', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_IntegerBaseDeployState;
END;

CREATE TABLE #tbx_IntegerBaseReleaseObjects
(
      ReleaseVersion nvarchar(64) NOT NULL
    , SchemaName     sysname      NOT NULL
    , ObjectName     sysname      NOT NULL
    , ObjectType     char(2)      NOT NULL
    , CONSTRAINT PK_tbx_IntegerBaseReleaseObjects
          PRIMARY KEY (ReleaseVersion, SchemaName, ObjectName)
);

INSERT INTO #tbx_IntegerBaseReleaseObjects
(
      ReleaseVersion
    , SchemaName
    , ObjectName
    , ObjectType
)
VALUES
      (N'1.0.0', N'toolbelt_conversion', N'SVF_IntegerToBase', 'FN')
    , (N'1.0.0', N'toolbelt_conversion', N'SVF_TryBaseToInteger', 'FN')
    , (N'1.1.0', N'toolbelt_conversion', N'TVF_IntegerToBase', 'IF')
    , (N'1.1.0', N'toolbelt_conversion', N'TVF_TryBaseToInteger', 'IF')
    , (N'1.1.0', N'toolbelt_conversion', N'SVF_IntegerToBase', 'FN')
    , (N'1.1.0', N'toolbelt_conversion', N'SVF_TryBaseToInteger', 'FN');

CREATE TABLE #tbx_IntegerBaseDeployState
(
      TargetVersion    nvarchar(64) NOT NULL
    , InstalledVersion nvarchar(64) NULL
    , DeploymentMode   nvarchar(16) NOT NULL
    , SchemaCreated     bit          NOT NULL
);

DECLARE
      @TargetVersion        nvarchar(64) = N'1.1.0'
    , @DeploymentMode       nvarchar(16) = LOWER(N'local')
    , @InstalledVersion     nvarchar(64)
    , @VersionPropertyName  sysname =
          N'Toolbelt.Module.toolbelt.conversion.integer-base.Version'
    , @ProductMajorVersion  int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @SchemaId             int = SCHEMA_ID(N'toolbelt_conversion')
    , @CollisionSchema      sysname
    , @CollisionObject      sysname
    , @LockResult           int
    , @DropSql              nvarchar(max)
    , @SchemaCreated        bit = 0;

IF @ProductMajorVersion NOT IN (15, 16, 17)
BEGIN
    THROW 51090, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
END;

IF @DeploymentMode NOT IN (N'local', N'central')
BEGIN
    THROW 51091, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

IF @InstalledVersion IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM #tbx_IntegerBaseReleaseObjects AS ro
           WHERE ro.ReleaseVersion COLLATE Latin1_General_100_BIN2
                     = @InstalledVersion COLLATE Latin1_General_100_BIN2
       )
BEGIN
    THROW 51093, N'Die installierte Modulversion ist diesem Deployment nicht als unterstütztes Vorgängerrelease bekannt.', 1;
END;

IF @SchemaId IS NULL
BEGIN
    IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    BEGIN
        THROW 51092, N'Zum Anlegen von toolbelt_conversion fehlt CREATE SCHEMA in der Installationsdatenbank.', 1;
    END;
END;
ELSE IF HAS_PERMS_BY_NAME(N'toolbelt_conversion', N'SCHEMA', N'ALTER') <> 1
BEGIN
    THROW 51092, N'Für das vorhandene Schema toolbelt_conversion fehlt ALTER.', 1;
END;

IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
BEGIN
    THROW 51092, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;
END;

/*
 * Neue Zielnamen dürfen kein frameworkfremdes Objekt überschreiben. Ein Name
 * gilt nur dann als Framework-Bestand, wenn er im bekannten installierten
 * Release enthalten ist.
 */
SELECT TOP (1)
      @CollisionSchema = target.SchemaName
    , @CollisionObject = target.ObjectName
FROM #tbx_IntegerBaseReleaseObjects AS target
INNER JOIN sys.schemas AS schemas
    ON schemas.name COLLATE Latin1_General_100_BIN2
          = target.SchemaName COLLATE Latin1_General_100_BIN2
INNER JOIN sys.objects AS objects
    ON objects.schema_id = schemas.schema_id
   AND objects.name COLLATE Latin1_General_100_BIN2
          = target.ObjectName COLLATE Latin1_General_100_BIN2
WHERE target.ReleaseVersion = @TargetVersion
  AND
  (
      @InstalledVersion IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM #tbx_IntegerBaseReleaseObjects AS previous
             WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                       = @InstalledVersion COLLATE Latin1_General_100_BIN2
               AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                       = target.SchemaName COLLATE Latin1_General_100_BIN2
               AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                       = target.ObjectName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY target.ObjectName COLLATE Latin1_General_100_BIN2;

IF @CollisionObject IS NOT NULL
BEGIN
    DECLARE @CollisionMessage nvarchar(2048) =
        N'Das neue Framework-Objekt '
        + QUOTENAME(@CollisionSchema)
        + N'.'
        + QUOTENAME(@CollisionObject)
        + N' ist bereits vorhanden, stammt aber nicht aus dem bekannten installierten Release.';
    SET @CollisionMessage = REPLACE(@CollisionMessage, N'%', N'%%');
    THROW 51094, @CollisionMessage, 1;
END;

INSERT INTO #tbx_IntegerBaseDeployState
(
      TargetVersion
    , InstalledVersion
    , DeploymentMode
    , SchemaCreated
)
VALUES
(
      @TargetVersion
    , @InstalledVersion
    , @DeploymentMode
    , 0
);

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC @LockResult = sys.sp_getapplock
          @Resource    = N'toolbelt.deploy.toolbelt.conversion.integer-base'
        , @LockMode    = N'Exclusive'
        , @LockOwner   = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
    BEGIN
        THROW 51097, N'Ein paralleles Deployment von toolbelt.conversion.integer-base ist bereits aktiv.', 1;
    END;

    DECLARE @CurrentInstalledVersion nvarchar(64);

    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
           <> ISNULL(@InstalledVersion, N'') COLLATE Latin1_General_100_BIN2
    BEGIN
        THROW 51097, N'Der installierte Modulstand hat sich seit dem Preflight verändert.', 1;
    END;

    SET @CollisionSchema = NULL;
    SET @CollisionObject = NULL;

    SELECT TOP (1)
          @CollisionSchema = target.SchemaName
        , @CollisionObject = target.ObjectName
    FROM #tbx_IntegerBaseReleaseObjects AS target
    INNER JOIN sys.schemas AS schemas
        ON schemas.name COLLATE Latin1_General_100_BIN2
              = target.SchemaName COLLATE Latin1_General_100_BIN2
    INNER JOIN sys.objects AS objects
        ON objects.schema_id = schemas.schema_id
       AND objects.name COLLATE Latin1_General_100_BIN2
              = target.ObjectName COLLATE Latin1_General_100_BIN2
    WHERE target.ReleaseVersion = @TargetVersion
      AND
      (
          @InstalledVersion IS NULL
          OR NOT EXISTS
             (
                 SELECT 1
                 FROM #tbx_IntegerBaseReleaseObjects AS previous
                 WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                           = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                           = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                           = target.ObjectName COLLATE Latin1_General_100_BIN2
             )
      );

    IF @CollisionObject IS NOT NULL
    BEGIN
        THROW 51097, N'Ein Zielobjekt hat sich seit dem Preflight verändert oder ist neu hinzugekommen.', 1;
    END;

    IF SCHEMA_ID(N'toolbelt_conversion') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_conversion];';
        SET @SchemaCreated = 1;

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.Managed'
            , @value      = 1
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_conversion';

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.SchemaCategory'
            , @value      = N'conversion'
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_conversion';
    END;

    UPDATE #tbx_IntegerBaseDeployState
    SET SchemaCreated = @SchemaCreated;

    /*
     * Ein lokal verändertes Release-Objekt mit falschem Typ wird anhand des
     * bekannten Vorgänger-Manifests entfernt. Fremde Namen bleiben unberührt.
     */
    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN objects.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN objects.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN objects.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(schemas.name)
                    + N'.'
                    + QUOTENAME(objects.name)
                    + N';'
                FROM #tbx_IntegerBaseReleaseObjects AS target
                INNER JOIN #tbx_IntegerBaseReleaseObjects AS previous
                    ON previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.schemas AS schemas
                    ON schemas.name COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS objects
                    ON objects.schema_id = schemas.schema_id
                   AND objects.name COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE target.ReleaseVersion = @TargetVersion
                  AND objects.type COLLATE Latin1_General_100_BIN2
                        <> target.ObjectType COLLATE Latin1_General_100_BIN2
                  AND objects.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY objects.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO

-- SQL Server Toolbelt
-- Objekt: toolbelt_conversion.TVF_IntegerToBase
-- Vertrag: Kanonischer relationaler Kern für die bigint-Codierung.

CREATE OR ALTER FUNCTION [toolbelt_conversion].[TVF_IntegerToBase]
(
      @Value bigint
    , @Alphabet varchar(93)
)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
(
    WITH
    Digits (Digit) AS
    (
        SELECT Digit
        FROM
        (
            VALUES
                  (0), (1), (2), (3), (4)
                , (5), (6), (7), (8), (9)
        ) AS values_0_to_9(Digit)
    ),
    Positions (Position) AS
    (
        SELECT tens.Digit * 10 + ones.Digit + 1
        FROM Digits AS tens
        CROSS JOIN Digits AS ones
        WHERE tens.Digit * 10 + ones.Digit + 1 <= 93
    ),
    Input AS
    (
        SELECT
              Base = DATALENGTH(@Alphabet)
            , Magnitude =
                  CONVERT
                  (
                        decimal(38, 0)
                      , CASE
                            WHEN @Value < 0
                                THEN -CONVERT(decimal(38, 0), @Value)
                            ELSE CONVERT(decimal(38, 0), @Value)
                        END
                  )
    ),
    Validated AS
    (
        SELECT
              input.Base
            , input.Magnitude
            , IsValid =
                  CONVERT
                  (
                        bit
                      , CASE
                            WHEN @Value IS NULL
                              OR @Alphabet IS NULL
                              OR input.Base < 2
                              OR input.Base > 93
                              OR EXISTS
                                 (
                                     SELECT 1
                                     FROM Positions
                                     WHERE Position <= input.Base
                                       AND
                                       (
                                           DATALENGTH
                                           (
                                               SUBSTRING
                                               (
                                                     @Alphabet
                                                   , Position
                                                   , 1
                                               )
                                           ) <> 1
                                           OR ASCII
                                           (
                                               SUBSTRING
                                               (
                                                     @Alphabet
                                                   , Position
                                                   , 1
                                               )
                                           ) NOT BETWEEN 33 AND 126
                                           OR SUBSTRING
                                              (
                                                    @Alphabet
                                                  , Position
                                                  , 1
                                              ) = '-'
                                           OR CHARINDEX
                                              (
                                                  SUBSTRING
                                                  (
                                                        @Alphabet
                                                      , Position
                                                      , 1
                                                  ) COLLATE Latin1_General_100_BIN2
                                                , LEFT
                                                  (
                                                        @Alphabet
                                                      , Position - 1
                                                  ) COLLATE Latin1_General_100_BIN2
                                              ) > 0
                                       )
                                 )
                                THEN 0
                            ELSE 1
                        END
                  )
        FROM Input AS input
    ),
    Encoding AS
    (
        SELECT
              Step = CONVERT(int, 0)
            , validated.Base
            , validated.IsValid
            , Magnitude =
                  CONVERT
                  (
                        decimal(38, 0)
                      , CASE
                            WHEN validated.IsValid = 1
                                THEN validated.Magnitude
                            ELSE 0
                        END
                  )
            , EncodedValue = CONVERT(varchar(65), '')
        FROM Validated AS validated

        UNION ALL

        SELECT
              encoding.Step + 1
            , encoding.Base
            , encoding.IsValid
            , CONVERT
              (
                    decimal(38, 0)
                  , FLOOR(encoding.Magnitude / encoding.Base)
              )
            , CONVERT
              (
                    varchar(65)
                  , SUBSTRING
                    (
                          @Alphabet
                        , CONVERT(int, encoding.Magnitude % encoding.Base) + 1
                        , 1
                    )
                    + encoding.EncodedValue
              )
        FROM Encoding AS encoding
        WHERE encoding.IsValid = 1
          AND encoding.Magnitude > 0
    ),
    Completed AS
    (
        SELECT TOP (1)
            encoding.EncodedValue
        FROM Encoding AS encoding
        WHERE encoding.Magnitude = 0
        ORDER BY encoding.Step DESC
    )
    SELECT EncodedValue =
        CONVERT
        (
              varchar(65)
            , CASE
                  WHEN validated.IsValid = 0
                      THEN NULL
                  WHEN @Value = 0
                      THEN SUBSTRING(@Alphabet, 1, 1)
                  WHEN @Value < 0
                      THEN '-' + completed.EncodedValue
                  ELSE completed.EncodedValue
              END
        )
    FROM Validated AS validated
    CROSS JOIN Completed AS completed
);
GO
-- SQL Server Toolbelt
-- Objekt: toolbelt_conversion.TVF_TryBaseToInteger
-- Vertrag: Relationaler Kern für die strikt kanonische bigint-Decodierung.

CREATE OR ALTER FUNCTION [toolbelt_conversion].[TVF_TryBaseToInteger]
(
      @EncodedValue varchar(65)
    , @Alphabet varchar(93)
)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
(
    WITH
    Digits (Digit) AS
    (
        SELECT Digit
        FROM
        (
            VALUES
                  (0), (1), (2), (3), (4)
                , (5), (6), (7), (8), (9)
        ) AS values_0_to_9(Digit)
    ),
    Positions (Position) AS
    (
        SELECT tens.Digit * 10 + ones.Digit + 1
        FROM Digits AS tens
        CROSS JOIN Digits AS ones
        WHERE tens.Digit * 10 + ones.Digit + 1 <= 93
    ),
    Input AS
    (
        SELECT
              Base = DATALENGTH(@Alphabet)
            , InputLength = DATALENGTH(@EncodedValue)
            , IsNegative =
                  CONVERT
                  (
                        bit
                      , CASE WHEN LEFT(@EncodedValue, 1) = '-' THEN 1 ELSE 0 END
                  )
            , StartPosition =
                  CASE WHEN LEFT(@EncodedValue, 1) = '-' THEN 2 ELSE 1 END
    ),
    Validated AS
    (
        SELECT
              input.Base
            , input.InputLength
            , input.IsNegative
            , input.StartPosition
            , MagnitudeLimit =
                  CONVERT
                  (
                        decimal(38, 0)
                      , CASE
                            WHEN input.IsNegative = 1
                                THEN 9223372036854775808
                            ELSE 9223372036854775807
                        END
                  )
            , IsValid =
                  CONVERT
                  (
                        bit
                      , CASE
                            WHEN @EncodedValue IS NULL
                              OR @Alphabet IS NULL
                              OR input.Base < 2
                              OR input.Base > 93
                              OR input.InputLength = 0
                              OR
                                 (
                                     input.IsNegative = 1
                                     AND input.InputLength = 1
                                 )
                              OR
                                 (
                                     input.InputLength - input.StartPosition + 1 > 1
                                     AND SUBSTRING
                                         (
                                               @EncodedValue
                                             , input.StartPosition
                                             , 1
                                         ) COLLATE Latin1_General_100_BIN2
                                         = SUBSTRING(@Alphabet, 1, 1)
                                             COLLATE Latin1_General_100_BIN2
                                 )
                              OR
                                 (
                                     input.IsNegative = 1
                                     AND input.InputLength
                                           - input.StartPosition + 1 = 1
                                     AND SUBSTRING
                                         (
                                               @EncodedValue
                                             , input.StartPosition
                                             , 1
                                         ) COLLATE Latin1_General_100_BIN2
                                         = SUBSTRING(@Alphabet, 1, 1)
                                             COLLATE Latin1_General_100_BIN2
                                 )
                              OR EXISTS
                                 (
                                     SELECT 1
                                     FROM Positions
                                     WHERE Position <= input.Base
                                       AND
                                       (
                                           DATALENGTH
                                           (
                                               SUBSTRING
                                               (
                                                     @Alphabet
                                                   , Position
                                                   , 1
                                               )
                                           ) <> 1
                                           OR ASCII
                                           (
                                               SUBSTRING
                                               (
                                                     @Alphabet
                                                   , Position
                                                   , 1
                                               )
                                           ) NOT BETWEEN 33 AND 126
                                           OR SUBSTRING
                                              (
                                                    @Alphabet
                                                  , Position
                                                  , 1
                                              ) = '-'
                                           OR CHARINDEX
                                              (
                                                  SUBSTRING
                                                  (
                                                        @Alphabet
                                                      , Position
                                                      , 1
                                                  ) COLLATE Latin1_General_100_BIN2
                                                , LEFT
                                                  (
                                                        @Alphabet
                                                      , Position - 1
                                                  ) COLLATE Latin1_General_100_BIN2
                                              ) > 0
                                       )
                                 )
                                THEN 0
                            ELSE 1
                        END
                  )
        FROM Input AS input
    ),
    Decoding AS
    (
        SELECT
              Position = CONVERT(int, validated.StartPosition)
            , validated.Base
            , validated.InputLength
            , validated.IsNegative
            , validated.MagnitudeLimit
            , IsValid = CONVERT(bit, validated.IsValid)
            , Accumulated = CONVERT(decimal(38, 0), 0)
        FROM Validated AS validated

        UNION ALL

        SELECT
              decoding.Position + 1
            , decoding.Base
            , decoding.InputLength
            , decoding.IsNegative
            , decoding.MagnitudeLimit
            , CONVERT
              (
                    bit
                  , CASE
                        WHEN digit.AlphabetPosition = 0
                          OR decoding.Accumulated
                             > FLOOR
                               (
                                   (
                                       decoding.MagnitudeLimit
                                       - digit.DigitValue
                                   ) / decoding.Base
                               )
                            THEN 0
                        ELSE 1
                    END
              )
            , CONVERT
              (
                    decimal(38, 0)
                  , CASE
                        WHEN digit.AlphabetPosition = 0
                          OR decoding.Accumulated
                             > FLOOR
                               (
                                   (
                                       decoding.MagnitudeLimit
                                       - digit.DigitValue
                                   ) / decoding.Base
                               )
                            THEN decoding.Accumulated
                        ELSE decoding.Accumulated * decoding.Base
                             + digit.DigitValue
                    END
              )
        FROM Decoding AS decoding
        CROSS APPLY
        (
            SELECT AlphabetPosition =
                CHARINDEX
                (
                    SUBSTRING(@EncodedValue, decoding.Position, 1)
                        COLLATE Latin1_General_100_BIN2
                  , @Alphabet COLLATE Latin1_General_100_BIN2
                )
        ) AS alphabet
        CROSS APPLY
        (
            SELECT
                  alphabet.AlphabetPosition
                , DigitValue =
                      CASE
                          WHEN alphabet.AlphabetPosition = 0 THEN 0
                          ELSE alphabet.AlphabetPosition - 1
                      END
        ) AS digit
        WHERE decoding.IsValid = 1
          AND decoding.Position <= decoding.InputLength
    ),
    Completed AS
    (
        SELECT TOP (1)
              decoding.Position
            , decoding.InputLength
            , decoding.IsNegative
            , decoding.IsValid
            , decoding.Accumulated
        FROM Decoding AS decoding
        WHERE decoding.IsValid = 0
           OR decoding.Position > decoding.InputLength
        ORDER BY decoding.Position DESC
    )
    SELECT DecodedValue =
        CONVERT
        (
              bigint
            , CASE
                  WHEN completed.IsValid = 0
                    OR completed.Position <= completed.InputLength
                      THEN NULL
                  WHEN completed.IsNegative = 1
                      THEN -completed.Accumulated
                  ELSE completed.Accumulated
              END
        )
    FROM Completed AS completed
);
GO
-- SQL Server Toolbelt
-- Objekt: toolbelt_conversion.SVF_IntegerToBase
-- Vertrag: Convenience-API zum relationalen Kern TVF_IntegerToBase.

CREATE OR ALTER FUNCTION [toolbelt_conversion].[SVF_IntegerToBase]
(
      @Value bigint
    , @Alphabet varchar(93)
)
RETURNS varchar(65)
AS
BEGIN
    DECLARE @EncodedValue varchar(65);

    SELECT @EncodedValue = encoded.EncodedValue
    FROM toolbelt_conversion.TVF_IntegerToBase(@Value, @Alphabet) AS encoded;

    RETURN @EncodedValue;
END;
GO
-- SQL Server Toolbelt
-- Objekt: toolbelt_conversion.SVF_TryBaseToInteger
-- Vertrag: Convenience-API zum relationalen Kern TVF_TryBaseToInteger.

CREATE OR ALTER FUNCTION [toolbelt_conversion].[SVF_TryBaseToInteger]
(
      @EncodedValue varchar(65)
    , @Alphabet varchar(93)
)
RETURNS bigint
AS
BEGIN
    DECLARE @DecodedValue bigint;

    SELECT @DecodedValue = decoded.DecodedValue
    FROM toolbelt_conversion.TVF_TryBaseToInteger
         (
               @EncodedValue
             , @Alphabet
         ) AS decoded;

    RETURN @DecodedValue;
END;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    DECLARE
          @DeploymentMode      nvarchar(16)
        , @TargetVersion       nvarchar(64)
        , @VersionPropertyName sysname =
              N'Toolbelt.Module.toolbelt.conversion.integer-base.Version'
        , @ModePropertyName    sysname =
              N'Toolbelt.Module.toolbelt.conversion.integer-base.DeploymentMode';

    SELECT
          @DeploymentMode = DeploymentMode
        , @TargetVersion = TargetVersion
    FROM #tbx_IntegerBaseDeployState;

    IF XACT_STATE() <> 1
       OR OBJECT_ID(N'toolbelt_conversion.TVF_IntegerToBase', N'IF') IS NULL
       OR OBJECT_ID(N'toolbelt_conversion.TVF_TryBaseToInteger', N'IF') IS NULL
       OR OBJECT_ID(N'toolbelt_conversion.SVF_IntegerToBase', N'FN') IS NULL
       OR OBJECT_ID(N'toolbelt_conversion.SVF_TryBaseToInteger', N'FN') IS NULL
    BEGIN
        THROW 51098, N'Die Framework-Funktionen wurden nicht vollständig innerhalb der Deployment-Transaktion angelegt.', 1;
    END;

    DECLARE @Objects TABLE
    (
          ObjectOrdinal int IDENTITY(1, 1) NOT NULL
        , ObjectName    sysname            NOT NULL
    );

    INSERT INTO @Objects (ObjectName)
    VALUES
          (N'TVF_IntegerToBase')
        , (N'TVF_TryBaseToInteger')
        , (N'SVF_IntegerToBase')
        , (N'SVF_TryBaseToInteger');

    DECLARE
          @ObjectOrdinal int = 1
        , @ObjectCount   int = (SELECT COUNT(*) FROM @Objects)
        , @ObjectName    sysname
        , @ObjectId      int
        , @SourceHash    varchar(64)
        , @PropertyOrdinal int
        , @PropertyCount   int
        , @PropertyName    sysname
        , @PropertyValue   nvarchar(4000);

    DECLARE @Properties TABLE
    (
          PropertyOrdinal int            NOT NULL PRIMARY KEY
        , PropertyName    sysname        NOT NULL
        , PropertyValue   nvarchar(4000) NOT NULL
    );

    WHILE @ObjectOrdinal <= @ObjectCount
    BEGIN
        SELECT @ObjectName = ObjectName
        FROM @Objects
        WHERE ObjectOrdinal = @ObjectOrdinal;

        SET @ObjectId = OBJECT_ID
        (
            QUOTENAME(N'toolbelt_conversion') + N'.' + QUOTENAME(@ObjectName)
        );
        SET @SourceHash = CONVERT
        (
              varchar(64)
            , HASHBYTES
              (
                  N'SHA2_256'
                , CONVERT(varbinary(max), OBJECT_DEFINITION(@ObjectId))
              )
            , 2
        );

        INSERT INTO @Properties
        (
              PropertyOrdinal
            , PropertyName
            , PropertyValue
        )
        VALUES
              (1, N'Toolbelt.ModuleId', N'toolbelt.conversion.integer-base')
            , (2, N'Toolbelt.ModuleVersion', @TargetVersion)
            , (3, N'Toolbelt.ContractVersion', N'1.0')
            , (4, N'Toolbelt.DeploymentMode', @DeploymentMode)
            , (5, N'Toolbelt.SourceHash', CONVERT(nvarchar(4000), @SourceHash));

        SET @PropertyOrdinal = 1;
        SET @PropertyCount = (SELECT COUNT(*) FROM @Properties);

        WHILE @PropertyOrdinal <= @PropertyCount
        BEGIN
            SELECT
                  @PropertyName = PropertyName
                , @PropertyValue = PropertyValue
            FROM @Properties
            WHERE PropertyOrdinal = @PropertyOrdinal;

            IF EXISTS
               (
                   SELECT 1
                   FROM sys.extended_properties AS ep
                   WHERE ep.class = 1
                     AND ep.major_id = @ObjectId
                     AND ep.minor_id = 0
                     AND ep.name = @PropertyName
               )
            BEGIN
                EXEC sys.sp_updateextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_conversion'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;
            ELSE
            BEGIN
                EXEC sys.sp_addextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_conversion'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;

            SET @PropertyOrdinal += 1;
        END;

        DELETE FROM @Properties;
        SET @ObjectOrdinal += 1;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @VersionPropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @ModePropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.conversion.integer-base
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.core.console-message
:On Error exit
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @VersionProperty sysname =
          N'Toolbelt.Module.toolbelt.core.console-message.Version'
    , @ModeProperty sysname =
          N'Toolbelt.Module.toolbelt.core.console-message.DeploymentMode'
    , @DeploymentMode nvarchar(16) = LOWER(N'local')
    , @InstalledVersion nvarchar(64)
    , @ProductMajorVersion int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'));

IF @ProductMajorVersion NOT IN (15, 16, 17)
    THROW 51270, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 51271, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), value)
FROM sys.extended_properties
WHERE class = 0 AND major_id = 0 AND minor_id = 0
  AND name = @VersionProperty;

IF @InstalledVersion IS NOT NULL AND @InstalledVersion <> N'1.0.0'
    THROW 51273, N'Die installierte Modulversion ist diesem Deployment nicht bekannt.', 1;

IF @InstalledVersion IS NULL
   AND OBJECT_ID(N'toolbelt_core.USP_WriteConsoleMessage') IS NOT NULL
    THROW 51274, N'Das Zielobjekt stammt nicht aus einem bekannten Toolbelt-Release.', 1;

IF SCHEMA_ID(N'toolbelt_core') IS NULL
   AND HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    THROW 51272, N'In der Installationsdatenbank fehlt CREATE SCHEMA.', 1;
IF SCHEMA_ID(N'toolbelt_core') IS NOT NULL
   AND HAS_PERMS_BY_NAME(N'toolbelt_core', N'SCHEMA', N'ALTER') <> 1
    THROW 51272, N'Für toolbelt_core fehlt ALTER.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE PROCEDURE') <> 1
    THROW 51272, N'In der Installationsdatenbank fehlt CREATE PROCEDURE.', 1;

BEGIN TRANSACTION;
DECLARE @LockResult int;
EXEC @LockResult = sys.sp_getapplock
      @Resource = N'toolbelt.deploy.toolbelt.core.console-message'
    , @LockMode = N'Exclusive'
    , @LockOwner = N'Transaction'
    , @LockTimeout = 0
    , @DbPrincipal = N'public';
IF @LockResult < 0
    THROW 51277, N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.', 1;

IF SCHEMA_ID(N'toolbelt_core') IS NULL
BEGIN
    EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_core];';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.Managed', @value = 1
        , @level0type = N'SCHEMA', @level0name = N'toolbelt_core';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.SchemaCategory', @value = N'core'
        , @level0type = N'SCHEMA', @level0name = N'toolbelt_core';
END;
GO
-- ============================================================================
-- Objekt:          toolbelt_core.USP_WriteConsoleMessage
-- Typ:             Stored Procedure
-- Zweck:           Gibt lange Unicode-Texte vollständig und optional sofort
--                  im Messages-Kanal des Clients aus.
-- Vertrag:         Documentation/Architecture/CONSOLE_MESSAGE_MODULE_DESIGN.md
-- Parameter:       @Message nvarchar(max) = NULL
--                  @Immediate bit = 0
--                  @Debug tinyint = 0
--                  @Hilfe bit = 0
-- Resultset:       Kein fachliches Resultset; bei @Hilfe = 1 genau ein
--                  standardisiertes Help-Resultset.
-- Dependencies:    Keine weiteren Toolbelt-Module.
-- Rechte:          EXECUTE auf der Procedure.
-- Versionen:       SQL Server 2019, 2022 und 2025.
-- Plattformen:     Windows und Linux; Clientdarstellung separat bewerten.
-- Fehlerverhalten: Keine fachlichen Fehler. Engine- und Clientfehler werden
--                  nicht abgefangen oder umklassifiziert.
-- Performance:     Lineare Message-Ausgabe; nicht für Hot Paths bestimmt.
-- Einschränkungen: Client und Treiber bestimmen Pufferung und Darstellung der
--                  einzelnen Message-Frames. Keine Präfixe oder Zeitstempel.
-- ============================================================================

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_core].[USP_WriteConsoleMessage]
(
      @Message   nvarchar(max) = NULL
    , @Immediate bit           = 0
    , @Debug     tinyint       = 0
    , @Hilfe     bit           = 0
)
AS
BEGIN
    SET NOCOUNT ON;

    SET @Immediate = ISNULL(@Immediate, 0);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    /*
     * Der Help-Pfad steht vor der fachlichen Ausgabe. Dadurch ignoriert ein
     * Hilfeaufruf Message, Immediate und Debug vollständig.
     */
    IF @Hilfe = 1
    BEGIN
        DECLARE @Help TABLE
        (
              HelpContractVersion varchar(16)    NOT NULL
            , SchemaName          sysname        NOT NULL
            , ObjectName          sysname        NOT NULL
            , Section             varchar(32)    NOT NULL
            , Ordinal             int            NOT NULL
            , ItemName            sysname        NULL
            , SqlDataType         varchar(256)   NULL
            , IsRequired          bit            NULL
            , IsNullable          bit            NULL
            , DefaultValue        nvarchar(4000) NULL
            , Description         nvarchar(max)  NOT NULL
            , ExampleSql          nvarchar(max)  NULL
        );

        INSERT INTO @Help
        (
              HelpContractVersion
            , SchemaName
            , ObjectName
            , Section
            , Ordinal
            , ItemName
            , SqlDataType
            , IsRequired
            , IsNullable
            , DefaultValue
            , Description
            , ExampleSql
        )
        VALUES
          ( '1.0', N'toolbelt_core', N'USP_WriteConsoleMessage', 'DESCRIPTION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Gibt bis zu 1 MiB UTF-16 in höchstens 512 Frames vollständig im Messages-Kanal aus. Gepufferte Ausgabe verwendet PRINT; unmittelbare Ausgabe verwendet RAISERROR mit Severity 0 und NOWAIT.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_WriteConsoleMessage', 'PARAMETER', 1
          , N'@Message', 'nvarchar(max)', 0, 1, N'NULL'
          , N'Auszugebender Text. NULL und Leertext erzeugen keine Ausgabe. Vorhandene Zeilenumbrüche bleiben innerhalb der Message-Frames erhalten.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_WriteConsoleMessage', 'PARAMETER', 2
          , N'@Immediate', 'bit', 0, 1, N'0'
          , N'0 verwendet PRINT in Chunks bis 4.000 UTF-16-Codeunits. 1 verwendet RAISERROR mit Severity 0, konservativen 2.000-Codeunit-Chunks und WITH NOWAIT.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_WriteConsoleMessage', 'PARAMETER', 3
          , N'@Debug', 'tinyint', 0, 1, N'0'
          , N'Standardparameter des USP-Vertrags. Version 1 erzeugt bewusst keine zusätzlichen Debug-Messages, damit der Payload unverändert bleibt.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_WriteConsoleMessage', 'PARAMETER', 4
          , N'@Hilfe', 'bit', 0, 1, N'0'
          , N'1 gibt ausschließlich dieses Help-Resultset aus und ignoriert alle anderen Parameter.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_WriteConsoleMessage', 'RESULT_COLUMN', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Die Procedure besitzt kein fachliches Resultset. Text wird ausschließlich als Messages ausgegeben.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_WriteConsoleMessage', 'ERROR', 1
          , N'52801-52802', NULL, NULL, NULL, NULL
          , N'52801: über 1 MiB UTF-16; 52802: über 512 Frames. Ablehnung vor erster Ausgabe, keine Kürzung.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_WriteConsoleMessage', 'PERMISSION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Erforderlich ist EXECUTE auf toolbelt_core.USP_WriteConsoleMessage. Die Procedure erweitert keine Rechte.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_WriteConsoleMessage', 'LIMITATION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Client und Treiber bestimmen Pufferung, Präfixe und Darstellung von Message-Frame-Grenzen. Die Procedure garantiert Reihenfolge und vollständige Payload-Chunks, aber keine byteidentische Clientformatierung.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_WriteConsoleMessage', 'EXAMPLE', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Gibt einen synthetischen Fortschrittstext sofort aus.'
          , N'EXEC toolbelt_core.USP_WriteConsoleMessage
      @Message = N''Schritt 1 abgeschlossen.''
    , @Immediate = 1;' );

        SELECT
              HelpContractVersion
            , SchemaName
            , ObjectName
            , Section
            , Ordinal
            , ItemName
            , SqlDataType
            , IsRequired
            , IsNullable
            , DefaultValue
            , Description
            , ExampleSql
        FROM @Help
        ORDER BY
              CASE Section
                  WHEN 'DESCRIPTION'   THEN 1
                  WHEN 'PARAMETER'     THEN 2
                  WHEN 'RESULT_COLUMN' THEN 3
                  WHEN 'ERROR'         THEN 4
                  WHEN 'PERMISSION'    THEN 5
                  WHEN 'LIMITATION'    THEN 6
                  WHEN 'EXAMPLE'       THEN 7
                  ELSE 8
              END
            , Ordinal;

        RETURN 0;
    END;

    IF @Message IS NULL OR DATALENGTH(@Message) = 0
        RETURN 0;

    IF DATALENGTH(@Message)>1048576
        THROW 52801,N'Console-Nachrichten dürfen höchstens 1 MiB UTF-16 umfassen.',1;

    DECLARE
          @Position      bigint = 1
        , @CodeUnitCount bigint
        , @ChunkSize     int
        , @ChunkLength   int
        , @Chunk         nvarchar(4000);

    /*
     * LEN ignoriert normalerweise nachgestellte Leerzeichen. Das angehängte
     * Nicht-Leerzeichen macht sie zählbar. Die explizite Nicht-SC-Collation
     * zählt UTF-16-Codeunits; damit stimmt die Positionsrechnung mit den
     * nvarchar- und Message-Grenzen überein.
     */
    SET @CodeUnitCount =
        LEN((@Message + NCHAR(1)) COLLATE Latin1_General_100_BIN2) - 1;
    SET @ChunkSize = CASE WHEN @Immediate = 1 THEN 2000 ELSE 4000 END;

    -- Höchstens ein Surrogate-Paar verschiebt eine Chunkgrenze um eine Einheit.
    -- Diese obere Framezahl wird vor der ersten Ausgabe geprüft.
    IF (@CodeUnitCount+@ChunkSize-2)/(@ChunkSize-1)>512
        THROW 52802,N'Console-Nachrichten dürfen höchstens 512 Frames erzeugen.',1;

    WHILE @Position <= @CodeUnitCount
    BEGIN
        SET @ChunkLength = CONVERT
        (
            int,
            CASE
                WHEN @CodeUnitCount - @Position + 1 < @ChunkSize
                THEN @CodeUnitCount - @Position + 1
                ELSE @ChunkSize
            END
        );

        SET @Chunk = SUBSTRING
        (
              @Message COLLATE Latin1_General_100_BIN2
            , @Position
            , @ChunkLength
        );

        /*
         * BIN2 zählt die beiden UTF-16-Codeunits eines Supplementary
         * Characters getrennt. Endet ein noch nicht letzter Chunk mit einem
         * High Surrogate und beginnt der nächste mit dem zugehörigen Low
         * Surrogate, bleibt das Paar vollständig im nächsten Chunk.
         */
        IF @Position + @ChunkLength - 1 < @CodeUnitCount
           AND UNICODE
               (
                   RIGHT(@Chunk COLLATE Latin1_General_100_BIN2, 1)
               ) BETWEEN 55296 AND 56319
           AND UNICODE
               (
                   SUBSTRING
                   (
                         @Message COLLATE Latin1_General_100_BIN2
                       , @Position + @ChunkLength
                       , 1
                   )
               ) BETWEEN 56320 AND 57343
        BEGIN
            SET @ChunkLength -= 1;
            SET @Chunk = SUBSTRING
            (
                  @Message COLLATE Latin1_General_100_BIN2
                , @Position
                , @ChunkLength
            );
        END;

        IF @Immediate = 1
        BEGIN
            /*
             * Das feste Format verhindert, dass Prozentzeichen des Payloads
             * als Format-Spezifikationen interpretiert werden. 2.000 Zeichen
             * lassen Reserve unterhalb des RAISERROR-Limits von 2.047.
             */
            RAISERROR (N'%s', 0, 1, @Chunk) WITH NOWAIT;
        END;
        ELSE
        BEGIN
            PRINT @Chunk;
        END;

        SET @Position += @ChunkLength;
    END;

    RETURN 0;
END;
GO
SET NOCOUNT ON;
BEGIN TRY
    DECLARE
          @VersionProperty sysname =
              N'Toolbelt.Module.toolbelt.core.console-message.Version'
        , @ModeProperty sysname =
              N'Toolbelt.Module.toolbelt.core.console-message.DeploymentMode';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties
           WHERE class = 0 AND major_id = 0 AND minor_id = 0
             AND name = @VersionProperty
       )
        EXEC sys.sp_updateextendedproperty
             @name = @VersionProperty, @value = N'1.0.0';
    ELSE
        EXEC sys.sp_addextendedproperty
             @name = @VersionProperty, @value = N'1.0.0';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties
           WHERE class = 0 AND major_id = 0 AND minor_id = 0
             AND name = @ModeProperty
       )
        EXEC sys.sp_updateextendedproperty
             @name = @ModeProperty, @value = N'local';
    ELSE
        EXEC sys.sp_addextendedproperty
             @name = @ModeProperty, @value = N'local';

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.core.console-message
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.core.execution-context
-- Deployment für toolbelt.core.execution-context
:on error exit

SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

DECLARE @DeploymentMode nvarchar(16) = LOWER(N'local');
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 51441, N'DeploymentMode muss local oder central sein.', 1;

IF SCHEMA_ID(N'toolbelt_core') IS NULL
    EXEC(N'CREATE SCHEMA [toolbelt_core] AUTHORIZATION [dbo];');


IF OBJECT_ID(N'toolbelt_core.TVF_CurrentExecutionContext', N'IF') IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 1
             AND ep.major_id = OBJECT_ID(N'toolbelt_core.TVF_CurrentExecutionContext')
             AND ep.minor_id = 0
             AND ep.name = N'Toolbelt.ModuleId'
             AND CONVERT(nvarchar(256), ep.value) = N'toolbelt.core.execution-context'
       )
BEGIN
    THROW 51440, N'Der Zielname toolbelt_core.TVF_CurrentExecutionContext ist bereits durch ein frameworkfremdes Objekt belegt.', 1;
END;
IF OBJECT_ID(N'toolbelt_core.SVF_CurrentExecutionId', N'FN') IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 1
             AND ep.major_id = OBJECT_ID(N'toolbelt_core.SVF_CurrentExecutionId')
             AND ep.minor_id = 0
             AND ep.name = N'Toolbelt.ModuleId'
             AND CONVERT(nvarchar(256), ep.value) = N'toolbelt.core.execution-context'
       )
BEGIN
    THROW 51440, N'Der Zielname toolbelt_core.SVF_CurrentExecutionId ist bereits durch ein frameworkfremdes Objekt belegt.', 1;
END;
IF OBJECT_ID(N'toolbelt_core.USP_BeginExecution', N'P') IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 1
             AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_BeginExecution')
             AND ep.minor_id = 0
             AND ep.name = N'Toolbelt.ModuleId'
             AND CONVERT(nvarchar(256), ep.value) = N'toolbelt.core.execution-context'
       )
BEGIN
    THROW 51440, N'Der Zielname toolbelt_core.USP_BeginExecution ist bereits durch ein frameworkfremdes Objekt belegt.', 1;
END;
IF OBJECT_ID(N'toolbelt_core.USP_SetExecutionContext', N'P') IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 1
             AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_SetExecutionContext')
             AND ep.minor_id = 0
             AND ep.name = N'Toolbelt.ModuleId'
             AND CONVERT(nvarchar(256), ep.value) = N'toolbelt.core.execution-context'
       )
BEGIN
    THROW 51440, N'Der Zielname toolbelt_core.USP_SetExecutionContext ist bereits durch ein frameworkfremdes Objekt belegt.', 1;
END;
IF OBJECT_ID(N'toolbelt_core.USP_EndExecution', N'P') IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 1
             AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_EndExecution')
             AND ep.minor_id = 0
             AND ep.name = N'Toolbelt.ModuleId'
             AND CONVERT(nvarchar(256), ep.value) = N'toolbelt.core.execution-context'
       )
BEGIN
    THROW 51440, N'Der Zielname toolbelt_core.USP_EndExecution ist bereits durch ein frameworkfremdes Objekt belegt.', 1;
END;
GO

BEGIN TRANSACTION;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER FUNCTION [toolbelt_core].[TVF_CurrentExecutionContext]()
RETURNS TABLE
AS
RETURN
(
    SELECT
          TRY_CONVERT(uniqueidentifier, SESSION_CONTEXT(N'toolbelt.execution.id')) AS ExecutionId
        , TRY_CONVERT(uniqueidentifier, SESSION_CONTEXT(N'toolbelt.execution.correlation_id')) AS CorrelationId
        , CONVERT(nvarchar(256), SESSION_CONTEXT(N'toolbelt.execution.actor')) AS Actor
        , CONVERT(nvarchar(256), SESSION_CONTEXT(N'toolbelt.execution.tenant')) AS Tenant
        , TRY_CONVERT(datetime2(7), CONVERT(nvarchar(33), SESSION_CONTEXT(N'toolbelt.execution.started_at_utc')), 126) AS StartedAtUtc
        , TRY_CONVERT(int, SESSION_CONTEXT(N'toolbelt.execution.depth')) AS ScopeDepth
    WHERE TRY_CONVERT(uniqueidentifier, SESSION_CONTEXT(N'toolbelt.execution.id')) IS NOT NULL
);
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER FUNCTION [toolbelt_core].[SVF_CurrentExecutionId]()
RETURNS uniqueidentifier
AS
BEGIN
    DECLARE @ExecutionId uniqueidentifier;
    SELECT @ExecutionId = c.ExecutionId
    FROM toolbelt_core.TVF_CurrentExecutionContext() AS c;
    RETURN @ExecutionId;
END;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_core].[USP_BeginExecution]
(
      @ExecutionId   uniqueidentifier = NULL OUTPUT
    , @CorrelationId uniqueidentifier = NULL
    , @Actor         nvarchar(256)    = NULL
    , @Tenant        nvarchar(256)    = NULL
    , @AllowNested   bit              = 1
    , @Debug         tinyint          = 0
    , @Hilfe         bit              = 0
)
AS
BEGIN
    SET NOCOUNT ON;
    SET @AllowNested = ISNULL(@AllowNested, 1);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    IF @Hilfe = 1
    BEGIN
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
               CAST(N'toolbelt_core' AS sysname) AS SchemaName,
               CAST(N'USP_BeginExecution' AS sysname) AS ObjectName,
               CAST('DESCRIPTION' AS varchar(32)) AS Section,
               1 AS Ordinal,
               CAST(NULL AS sysname) AS ItemName,
               CAST(NULL AS varchar(256)) AS SqlDataType,
               CAST(NULL AS bit) AS IsRequired,
               CAST(NULL AS bit) AS IsNullable,
               CAST(NULL AS nvarchar(4000)) AS DefaultValue,
               CAST(N'Beginnt einen sessiongebundenen Toolbelt Execution Context oder erhöht bei erlaubter Verschachtelung dessen ScopeDepth. Die Execution-ID wird als OUTPUT zurückgegeben.' AS nvarchar(max)) AS Description,
               CAST(N'DECLARE @Id uniqueidentifier; EXEC toolbelt_core.USP_BeginExecution @ExecutionId=@Id OUTPUT;' AS nvarchar(max)) AS ExampleSql;
        RETURN 0;
    END;

    DECLARE @CurrentExecutionId uniqueidentifier = TRY_CONVERT(uniqueidentifier, SESSION_CONTEXT(N'toolbelt.execution.id'));
    DECLARE @CurrentCorrelationId uniqueidentifier = TRY_CONVERT(uniqueidentifier, SESSION_CONTEXT(N'toolbelt.execution.correlation_id'));
    DECLARE @CurrentDepth int = TRY_CONVERT(int, SESSION_CONTEXT(N'toolbelt.execution.depth'));
    DECLARE @CurrentActor nvarchar(256) = CONVERT(nvarchar(256), SESSION_CONTEXT(N'toolbelt.execution.actor'));
    DECLARE @CurrentTenant nvarchar(256) = CONVERT(nvarchar(256), SESSION_CONTEXT(N'toolbelt.execution.tenant'));

    IF @CurrentExecutionId IS NULL
    BEGIN
        SET @ExecutionId = ISNULL(@ExecutionId, NEWID());
        SET @CorrelationId = ISNULL(@CorrelationId, @ExecutionId);
        DECLARE @StartedAtUtc nvarchar(33) = CONVERT(nvarchar(33), SYSUTCDATETIME(), 126);
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.id', @value=@ExecutionId;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.correlation_id', @value=@CorrelationId;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.actor', @value=@Actor;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.tenant', @value=@Tenant;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.started_at_utc', @value=@StartedAtUtc;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.depth', @value=1;
    END
    ELSE
    BEGIN
        IF @AllowNested = 0
            THROW 51420, N'In dieser Session ist bereits ein Execution Context aktiv.', 1;
        IF @CurrentDepth IS NULL OR @CurrentDepth < 1 OR @CurrentDepth >= 32767
            THROW 51421, N'Der vorhandene Execution Context besitzt einen ungültigen ScopeDepth.', 1;
        IF @ExecutionId IS NOT NULL AND @ExecutionId <> @CurrentExecutionId
            THROW 51422, N'Die angeforderte Execution-ID stimmt nicht mit dem aktiven Context überein.', 1;
        IF @CorrelationId IS NOT NULL AND @CorrelationId <> @CurrentCorrelationId
            THROW 51423, N'Die angeforderte Correlation-ID stimmt nicht mit dem aktiven Context überein.', 1;
        IF @Actor IS NOT NULL AND ISNULL(@CurrentActor, N'') <> @Actor
            THROW 51424, N'Ein verschachtelter Begin-Aufruf darf Actor nicht ändern.', 1;
        IF @Tenant IS NOT NULL AND ISNULL(@CurrentTenant, N'') <> @Tenant
            THROW 51425, N'Ein verschachtelter Begin-Aufruf darf Tenant nicht ändern.', 1;
        SET @ExecutionId = @CurrentExecutionId;
        DECLARE @NewDepth int = @CurrentDepth + 1;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.depth', @value=@NewDepth;
    END;

    IF @Debug > 0
        RAISERROR(N'USP_BeginExecution: Execution Context ist aktiv.', 10, 1) WITH NOWAIT;
    RETURN 0;
END;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_core].[USP_SetExecutionContext]
(
      @ExpectedExecutionId uniqueidentifier
    , @CorrelationId       uniqueidentifier = NULL
    , @Actor               nvarchar(256)    = NULL
    , @Tenant              nvarchar(256)    = NULL
    , @ClearActor          bit              = 0
    , @ClearTenant         bit              = 0
    , @Debug               tinyint          = 0
    , @Hilfe               bit              = 0
)
AS
BEGIN
    SET NOCOUNT ON;
    SET @ClearActor = ISNULL(@ClearActor, 0);
    SET @ClearTenant = ISNULL(@ClearTenant, 0);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    IF @Hilfe = 1
    BEGIN
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
               CAST(N'toolbelt_core' AS sysname) AS SchemaName,
               CAST(N'USP_SetExecutionContext' AS sysname) AS ObjectName,
               CAST('DESCRIPTION' AS varchar(32)) AS Section,
               1 AS Ordinal,
               CAST(NULL AS sysname) AS ItemName,
               CAST(NULL AS varchar(256)) AS SqlDataType,
               CAST(NULL AS bit) AS IsRequired,
               CAST(NULL AS bit) AS IsNullable,
               CAST(NULL AS nvarchar(4000)) AS DefaultValue,
               CAST(N'Ändert Correlation-ID, Actor oder Tenant eines aktiven Contexts. Die erwartete Execution-ID verhindert Änderungen an einem fremden oder veralteten Sessionzustand.' AS nvarchar(max)) AS Description,
               CAST(NULL AS nvarchar(max)) AS ExampleSql;
        RETURN 0;
    END;

    DECLARE @CurrentExecutionId uniqueidentifier = TRY_CONVERT(uniqueidentifier, SESSION_CONTEXT(N'toolbelt.execution.id'));
    IF @CurrentExecutionId IS NULL
        THROW 51426, N'In dieser Session ist kein Execution Context aktiv.', 1;
    IF @ExpectedExecutionId IS NULL OR @ExpectedExecutionId <> @CurrentExecutionId
        THROW 51427, N'@ExpectedExecutionId stimmt nicht mit dem aktiven Context überein.', 1;
    IF @ClearActor = 1 AND @Actor IS NOT NULL
        THROW 51428, N'@Actor und @ClearActor dürfen nicht gleichzeitig gesetzt sein.', 1;
    IF @ClearTenant = 1 AND @Tenant IS NOT NULL
        THROW 51429, N'@Tenant und @ClearTenant dürfen nicht gleichzeitig gesetzt sein.', 1;

    IF @CorrelationId IS NOT NULL
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.correlation_id', @value=@CorrelationId;
    IF @ClearActor = 1
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.actor', @value=NULL;
    ELSE IF @Actor IS NOT NULL
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.actor', @value=@Actor;
    IF @ClearTenant = 1
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.tenant', @value=NULL;
    ELSE IF @Tenant IS NOT NULL
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.tenant', @value=@Tenant;

    IF @Debug > 0
        RAISERROR(N'USP_SetExecutionContext: Execution Context wurde aktualisiert.', 10, 1) WITH NOWAIT;
    RETURN 0;
END;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_core].[USP_EndExecution]
(
      @ExpectedExecutionId uniqueidentifier
    , @Debug               tinyint = 0
    , @Hilfe               bit = 0
)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    IF @Hilfe = 1
    BEGIN
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
               CAST(N'toolbelt_core' AS sysname) AS SchemaName,
               CAST(N'USP_EndExecution' AS sysname) AS ObjectName,
               CAST('DESCRIPTION' AS varchar(32)) AS Section,
               1 AS Ordinal,
               CAST(NULL AS sysname) AS ItemName,
               CAST(NULL AS varchar(256)) AS SqlDataType,
               CAST(NULL AS bit) AS IsRequired,
               CAST(NULL AS bit) AS IsNullable,
               CAST(NULL AS nvarchar(4000)) AS DefaultValue,
               CAST(N'Verringert den ScopeDepth eines aktiven Contexts und löscht bei Tiefe 1 alle Toolbelt-Sessionwerte.' AS nvarchar(max)) AS Description,
               CAST(NULL AS nvarchar(max)) AS ExampleSql;
        RETURN 0;
    END;

    DECLARE @CurrentExecutionId uniqueidentifier = TRY_CONVERT(uniqueidentifier, SESSION_CONTEXT(N'toolbelt.execution.id'));
    DECLARE @CurrentDepth int = TRY_CONVERT(int, SESSION_CONTEXT(N'toolbelt.execution.depth'));
    IF @CurrentExecutionId IS NULL
        THROW 51430, N'In dieser Session ist kein Execution Context aktiv.', 1;
    IF @ExpectedExecutionId IS NULL OR @ExpectedExecutionId <> @CurrentExecutionId
        THROW 51431, N'@ExpectedExecutionId stimmt nicht mit dem aktiven Context überein.', 1;
    IF @CurrentDepth IS NULL OR @CurrentDepth < 1
        THROW 51432, N'Der aktive Context besitzt einen ungültigen ScopeDepth.', 1;

    IF @CurrentDepth > 1
    BEGIN
        DECLARE @NewDepth int = @CurrentDepth - 1;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.depth', @value=@NewDepth;
    END
    ELSE
    BEGIN
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.id', @value=NULL;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.correlation_id', @value=NULL;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.actor', @value=NULL;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.tenant', @value=NULL;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.started_at_utc', @value=NULL;
        EXEC sys.sp_set_session_context @key=N'toolbelt.execution.depth', @value=NULL;
    END;

    IF @Debug > 0
        RAISERROR(N'USP_EndExecution: Execution Scope wurde beendet.', 10, 1) WITH NOWAIT;
    RETURN 0;
END;
GO
GO

DECLARE @DeploymentMode nvarchar(16) = LOWER(N'local');

IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.TVF_CurrentExecutionContext')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleId'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.execution-context'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'FUNCTION'
        , @level1name = N'TVF_CurrentExecutionContext';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.execution-context'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'FUNCTION'
        , @level1name = N'TVF_CurrentExecutionContext';
END;

IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.TVF_CurrentExecutionContext')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleVersion'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'FUNCTION'
        , @level1name = N'TVF_CurrentExecutionContext';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'FUNCTION'
        , @level1name = N'TVF_CurrentExecutionContext';
END;
IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.SVF_CurrentExecutionId')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleId'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.execution-context'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'FUNCTION'
        , @level1name = N'SVF_CurrentExecutionId';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.execution-context'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'FUNCTION'
        , @level1name = N'SVF_CurrentExecutionId';
END;

IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.SVF_CurrentExecutionId')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleVersion'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'FUNCTION'
        , @level1name = N'SVF_CurrentExecutionId';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'FUNCTION'
        , @level1name = N'SVF_CurrentExecutionId';
END;
IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_BeginExecution')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleId'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.execution-context'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_BeginExecution';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.execution-context'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_BeginExecution';
END;

IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_BeginExecution')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleVersion'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_BeginExecution';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_BeginExecution';
END;
IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_SetExecutionContext')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleId'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.execution-context'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_SetExecutionContext';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.execution-context'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_SetExecutionContext';
END;

IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_SetExecutionContext')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleVersion'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_SetExecutionContext';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_SetExecutionContext';
END;
IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_EndExecution')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleId'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.execution-context'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_EndExecution';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.execution-context'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_EndExecution';
END;

IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_EndExecution')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleVersion'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_EndExecution';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_EndExecution';
END;

DECLARE @VersionProperty sysname = N'Toolbelt.Module.toolbelt.core.execution-context.Version';
DECLARE @ModeProperty sysname = N'Toolbelt.Module.toolbelt.core.execution-context.DeploymentMode';
IF EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 0 AND name = @VersionProperty)
    EXEC sys.sp_updateextendedproperty @name = @VersionProperty, @value = N'1.0.0';
ELSE
    EXEC sys.sp_addextendedproperty @name = @VersionProperty, @value = N'1.0.0';

IF EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 0 AND name = @ModeProperty)
    EXEC sys.sp_updateextendedproperty @name = @ModeProperty, @value = @DeploymentMode;
ELSE
    EXEC sys.sp_addextendedproperty @name = @ModeProperty, @value = @DeploymentMode;

COMMIT TRANSACTION;
GO
GO
-- END MODULE toolbelt.core.execution-context
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.core.generate-series
:On Error exit

-- ============================================================================
-- Zweck:     Erst-, Upgrade- und Wiederholungsdeployment
-- Modul:     toolbelt.core.generate-series v1.0.0
-- Schema:    toolbelt_core
-- Erfordert: SQL Server 2019, 2022 oder 2025
-- Modus:     SQLCMD; Ausführung aus diesem Deployment-Verzeichnis
-- Parameter: DeploymentMode=local|central
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'tempdb..#tbx_GenerateSeriesReleaseObjects', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_GenerateSeriesReleaseObjects;
END;

IF OBJECT_ID(N'tempdb..#tbx_GenerateSeriesDeployState', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_GenerateSeriesDeployState;
END;

CREATE TABLE #tbx_GenerateSeriesReleaseObjects
(
      ReleaseVersion nvarchar(64) NOT NULL
    , SchemaName     sysname      NOT NULL
    , ObjectName     sysname      NOT NULL
    , ObjectType     char(2)      NOT NULL
    , CONSTRAINT PK_tbx_GenerateSeriesReleaseObjects
          PRIMARY KEY (ReleaseVersion, SchemaName, ObjectName)
);

INSERT INTO #tbx_GenerateSeriesReleaseObjects
(
      ReleaseVersion
    , SchemaName
    , ObjectName
    , ObjectType
)
VALUES
      (N'1.0.0', N'toolbelt_core', N'TVF_GenerateSeriesBigInt', 'IF')
    , (N'1.0.0', N'toolbelt_core', N'TVF_GenerateSeriesInt', 'IF')
    , (N'1.0.0', N'toolbelt_core', N'TVF_GenerateSeriesBigIntStatus', 'TF');

CREATE TABLE #tbx_GenerateSeriesDeployState
(
      TargetVersion    nvarchar(64) NOT NULL
    , InstalledVersion nvarchar(64) NULL
    , DeploymentMode   nvarchar(16) NOT NULL
    , SchemaCreated     bit          NOT NULL
);

DECLARE
      @TargetVersion        nvarchar(64) = N'1.0.0'
    , @DeploymentMode       nvarchar(16) = LOWER(N'local')
    , @InstalledVersion     nvarchar(64)
    , @VersionPropertyName  sysname =
          N'Toolbelt.Module.toolbelt.core.generate-series.Version'
    , @ProductMajorVersion  int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @SchemaId             int = SCHEMA_ID(N'toolbelt_core')
    , @CollisionSchema      sysname
    , @CollisionObject      sysname
    , @LockResult           int
    , @DropSql              nvarchar(max)
    , @SchemaCreated        bit = 0;

IF @ProductMajorVersion NOT IN (15, 16, 17)
BEGIN
    THROW 51050, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
END;

IF @DeploymentMode NOT IN (N'local', N'central')
BEGIN
    THROW 51051, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

IF @InstalledVersion IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM #tbx_GenerateSeriesReleaseObjects AS ro
           WHERE ro.ReleaseVersion COLLATE Latin1_General_100_BIN2
                     = @InstalledVersion COLLATE Latin1_General_100_BIN2
       )
BEGIN
    THROW 51053, N'Die installierte Modulversion ist diesem Deployment nicht als unterstütztes Vorgängerrelease bekannt.', 1;
END;

IF @SchemaId IS NULL
BEGIN
    IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    BEGIN
        THROW 51052, N'Zum Anlegen von toolbelt_core fehlt CREATE SCHEMA in der Installationsdatenbank.', 1;
    END;
END;
ELSE IF HAS_PERMS_BY_NAME(N'toolbelt_core', N'SCHEMA', N'ALTER') <> 1
BEGIN
    THROW 51052, N'Für das vorhandene Schema toolbelt_core fehlt ALTER.', 1;
END;

IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
BEGIN
    THROW 51052, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;
END;

/*
 * Neue Zielnamen dürfen kein frameworkfremdes Objekt überschreiben. Ein Name
 * gilt nur dann als Framework-Bestand, wenn er im bekannten installierten
 * Release enthalten ist.
 */
SELECT TOP (1)
      @CollisionSchema = target.SchemaName
    , @CollisionObject = target.ObjectName
FROM #tbx_GenerateSeriesReleaseObjects AS target
INNER JOIN sys.schemas AS schemas
    ON schemas.name COLLATE Latin1_General_100_BIN2
          = target.SchemaName COLLATE Latin1_General_100_BIN2
INNER JOIN sys.objects AS objects
    ON objects.schema_id = schemas.schema_id
   AND objects.name COLLATE Latin1_General_100_BIN2
          = target.ObjectName COLLATE Latin1_General_100_BIN2
WHERE target.ReleaseVersion = @TargetVersion
  AND
  (
      @InstalledVersion IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM #tbx_GenerateSeriesReleaseObjects AS previous
             WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                       = @InstalledVersion COLLATE Latin1_General_100_BIN2
               AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                       = target.SchemaName COLLATE Latin1_General_100_BIN2
               AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                       = target.ObjectName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY target.ObjectName COLLATE Latin1_General_100_BIN2;

IF @CollisionObject IS NOT NULL
BEGIN
    DECLARE @CollisionMessage nvarchar(2048) =
        N'Das neue Framework-Objekt '
        + QUOTENAME(@CollisionSchema)
        + N'.'
        + QUOTENAME(@CollisionObject)
        + N' ist bereits vorhanden, stammt aber nicht aus dem bekannten installierten Release.';
    SET @CollisionMessage = REPLACE(@CollisionMessage, N'%', N'%%');
    THROW 51054, @CollisionMessage, 1;
END;

INSERT INTO #tbx_GenerateSeriesDeployState
(
      TargetVersion
    , InstalledVersion
    , DeploymentMode
    , SchemaCreated
)
VALUES
(
      @TargetVersion
    , @InstalledVersion
    , @DeploymentMode
    , 0
);

BEGIN TRY
    IF OBJECT_ID(N'toolbelt_core.TVF_GenerateSeriesBigIntStatus') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_core.TVF_GenerateSeriesBigIntStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(256),value)=N'toolbelt.core.generate-series') THROW 51054,N'Neuer Security-Zielname ist frameworkfremd belegt.',1;
BEGIN TRANSACTION;

    EXEC @LockResult = sys.sp_getapplock
          @Resource    = N'toolbelt.deploy.toolbelt.core.generate-series'
        , @LockMode    = N'Exclusive'
        , @LockOwner   = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
    BEGIN
        THROW 51057, N'Ein paralleles Deployment von toolbelt.core.generate-series ist bereits aktiv.', 1;
    END;

    DECLARE @CurrentInstalledVersion nvarchar(64);

    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
           <> ISNULL(@InstalledVersion, N'') COLLATE Latin1_General_100_BIN2
    BEGIN
        THROW 51057, N'Der installierte Modulstand hat sich seit dem Preflight verändert.', 1;
    END;

    SET @CollisionSchema = NULL;
    SET @CollisionObject = NULL;

    SELECT TOP (1)
          @CollisionSchema = target.SchemaName
        , @CollisionObject = target.ObjectName
    FROM #tbx_GenerateSeriesReleaseObjects AS target
    INNER JOIN sys.schemas AS schemas
        ON schemas.name COLLATE Latin1_General_100_BIN2
              = target.SchemaName COLLATE Latin1_General_100_BIN2
    INNER JOIN sys.objects AS objects
        ON objects.schema_id = schemas.schema_id
       AND objects.name COLLATE Latin1_General_100_BIN2
              = target.ObjectName COLLATE Latin1_General_100_BIN2
    WHERE target.ReleaseVersion = @TargetVersion
      AND
      (
          @InstalledVersion IS NULL
          OR NOT EXISTS
             (
                 SELECT 1
                 FROM #tbx_GenerateSeriesReleaseObjects AS previous
                 WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                           = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                           = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                           = target.ObjectName COLLATE Latin1_General_100_BIN2
             )
      );

    IF @CollisionObject IS NOT NULL
    BEGIN
        THROW 51057, N'Ein Zielobjekt hat sich seit dem Preflight verändert oder ist neu hinzugekommen.', 1;
    END;

    IF SCHEMA_ID(N'toolbelt_core') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_core];';
        SET @SchemaCreated = 1;

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.Managed'
            , @value      = 1
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_core';

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.SchemaCategory'
            , @value      = N'core'
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_core';
    END;

    UPDATE #tbx_GenerateSeriesDeployState
    SET SchemaCreated = @SchemaCreated;

    /*
     * Ein lokal verändertes Release-Objekt mit falschem Typ wird anhand des
     * bekannten Vorgänger-Manifests entfernt. Fremde Namen bleiben unberührt.
     */
    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN objects.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN objects.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN objects.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(schemas.name)
                    + N'.'
                    + QUOTENAME(objects.name)
                    + N';'
                FROM #tbx_GenerateSeriesReleaseObjects AS target
                INNER JOIN #tbx_GenerateSeriesReleaseObjects AS previous
                    ON previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.schemas AS schemas
                    ON schemas.name COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS objects
                    ON objects.schema_id = schemas.schema_id
                   AND objects.name COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE target.ReleaseVersion = @TargetVersion
                  AND objects.type COLLATE Latin1_General_100_BIN2
                        <> target.ObjectType COLLATE Latin1_General_100_BIN2
                  AND objects.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY objects.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO

-- ============================================================================
-- Objekt:          toolbelt_core.TVF_GenerateSeriesBigInt
-- Zweck:           Portable bigint-Zahlenreihe einschließlich Startwert
-- Parameter:       @Start bigint, @Stop bigint, @Step bigint = NULL
-- Resultset:       Value bigint
-- Dependencies:    keine Toolbelt-Module
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF; konstante Rowsets und zeilenzahlgesteuerter TOP
-- Collation:       nicht anwendbar
-- Einschränkungen: keine garantierte Reihenfolge; Row Count muss bigint-fähig sein
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_core].[TVF_GenerateSeriesBigInt]
(
      @Start bigint
    , @Stop  bigint
    , @Step  bigint = NULL
)
RETURNS TABLE
AS
RETURN
(
    /*
     * Die binäre Stapelung stellt 2^64 logische Quellzeilen bereit. TOP
     * begrenzt die tatsächlich angeforderte Menge durch einen Row Goal; die
     * Zwischenmenge wird nicht materialisiert. decimal(38,0) verhindert
     * Überläufe bei Differenz, Betrag und Wertberechnung an bigint-Grenzen.
     */
    WITH
    ResolvedParameters AS
    (
        SELECT
              StartValue = @Start
            , StopValue  = @Stop
            , StepValue  = COALESCE
              (
                  @Step
                , CASE WHEN @Start <= @Stop
                       THEN CONVERT(bigint, 1)
                       ELSE CONVERT(bigint, -1)
                  END
              )
    ),
    CountedParameters AS
    (
        SELECT
              parameters.StartValue
            , parameters.StepValue
            , RequestedRows = CASE
                  /*
                   * Eine Schrittweite 0 bleibt ein unveränderter Enginefehler.
                   * Die Division wird nur für diesen ungültigen Fall gewählt.
                   */
                  WHEN parameters.StepValue = 0
                      THEN CONVERT(bigint, 1 / parameters.StepValue)
                  WHEN parameters.StartValue IS NULL
                    OR parameters.StopValue IS NULL
                      THEN CONVERT(bigint, 0)
                  WHEN parameters.StepValue > 0
                   AND parameters.StartValue <= parameters.StopValue
                      THEN CONVERT
                           (
                               bigint
                             , (
                                   CONVERT(decimal(38, 0), parameters.StopValue)
                                   - CONVERT(decimal(38, 0), parameters.StartValue)
                               )
                               / CONVERT(decimal(38, 0), parameters.StepValue)
                               + 1
                           )
                  WHEN parameters.StepValue < 0
                   AND parameters.StartValue >= parameters.StopValue
                      THEN CONVERT
                           (
                               bigint
                             , (
                                   CONVERT(decimal(38, 0), parameters.StartValue)
                                   - CONVERT(decimal(38, 0), parameters.StopValue)
                               )
                               / -CONVERT(decimal(38, 0), parameters.StepValue)
                               + 1
                           )
                  ELSE CONVERT(bigint, 0)
              END
        FROM ResolvedParameters AS parameters
    ),
    E1(N) AS
    (
        SELECT source.N
        FROM (VALUES (0), (0)) AS source(N)
    ),
    E2(N) AS
    (
        SELECT 0 FROM E1 AS a CROSS JOIN E1 AS b
    ),
    E4(N) AS
    (
        SELECT 0 FROM E2 AS a CROSS JOIN E2 AS b
    ),
    E8(N) AS
    (
        SELECT 0 FROM E4 AS a CROSS JOIN E4 AS b
    ),
    E16(N) AS
    (
        SELECT 0 FROM E8 AS a CROSS JOIN E8 AS b
    ),
    E32(N) AS
    (
        SELECT 0 FROM E16 AS a CROSS JOIN E16 AS b
    ),
    E64(N) AS
    (
        SELECT 0 FROM E32 AS a CROSS JOIN E32 AS b
    ),
    Ordinals AS
    (
        SELECT TOP
        (
            COALESCE
            (
                (SELECT counted.RequestedRows FROM CountedParameters AS counted)
              , CONVERT(bigint, 0)
            )
        )
            Ordinal = ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1
        FROM E64
    )
    SELECT
        Value = CONVERT
        (
            bigint
          , CONVERT(decimal(38, 0), parameters.StartValue)
            + CONVERT(decimal(38, 0), ordinals.Ordinal)
              * CONVERT(decimal(38, 0), parameters.StepValue)
        )
    FROM CountedParameters AS parameters
    CROSS JOIN Ordinals AS ordinals
);
GO

-- Begrenzte Oberfläche für untrusted Aufrufe. Die mathematische Altfassade
-- bleibt unter der ausdrücklichen Betreiberpolicy für vertrauenswürdige Principals.
CREATE OR ALTER FUNCTION [toolbelt_core].[TVF_GenerateSeriesBigIntStatus]
(@Start bigint,@Stop bigint,@Step bigint=NULL)
RETURNS @Result TABLE(Value bigint NULL,Status varchar(16) NOT NULL,RequestedRows decimal(38,0) NULL)
AS
BEGIN
    IF @Start IS NULL OR @Stop IS NULL
    BEGIN INSERT @Result VALUES(NULL,'SQL_NULL',NULL); RETURN; END;
    SET @Step=COALESCE(@Step,CASE WHEN @Start<=@Stop THEN CONVERT(bigint,1) ELSE CONVERT(bigint,-1) END);
    IF @Step=0 BEGIN INSERT @Result VALUES(NULL,'INVALID',NULL); RETURN; END;
    IF (@Step>0 AND @Start>@Stop) OR (@Step<0 AND @Start<@Stop)
    BEGIN INSERT @Result VALUES(NULL,'EMPTY',0); RETURN; END;
    DECLARE @Distance decimal(38,0)=ABS(CONVERT(decimal(38,0),@Stop)-CONVERT(decimal(38,0),@Start)),
            @Magnitude decimal(38,0)=ABS(CONVERT(decimal(38,0),@Step)),@Rows decimal(38,0);
    SET @Rows=(@Distance-(@Distance%@Magnitude))/@Magnitude+1;
    IF @Rows>1000000 BEGIN INSERT @Result VALUES(NULL,'LIMIT',@Rows); RETURN; END;
    INSERT @Result SELECT Value,'OK',@Rows FROM toolbelt_core.TVF_GenerateSeriesBigInt(@Start,@Stop,@Step);
    RETURN;
END;
GO
-- ============================================================================
-- Objekt:          toolbelt_core.TVF_GenerateSeriesInt
-- Zweck:           Typstabile int-Zahlenreihe einschließlich Startwert
-- Parameter:       @Start int, @Stop int, @Step int = NULL
-- Resultset:       Value int
-- Dependencies:    TVF_GenerateSeriesBigInt im selben Modul
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     dünne Inline-TVF über dem gemeinsamen bigint-Kern
-- Collation:       nicht anwendbar
-- Einschränkungen: keine garantierte Reihenfolge
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_core].[TVF_GenerateSeriesInt]
(
      @Start int
    , @Stop  int
    , @Step  int = NULL
)
RETURNS TABLE
AS
RETURN
(
    /*
     * Die gesamte Reihenlogik liegt im bigint-Kern. Die Rückkonvertierung
     * erhält einen int-typisierten Join- und APPLY-Vertrag ohne zweite
     * Fachimplementierung.
     */
    SELECT Value = CONVERT(int, series.Value)
    FROM [toolbelt_core].[TVF_GenerateSeriesBigInt]
    (
          CONVERT(bigint, @Start)
        , CONVERT(bigint, @Stop)
        , CONVERT(bigint, @Step)
    ) AS series
);
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    DECLARE
          @DeploymentMode      nvarchar(16)
        , @TargetVersion       nvarchar(64)
        , @VersionPropertyName sysname =
              N'Toolbelt.Module.toolbelt.core.generate-series.Version'
        , @ModePropertyName    sysname =
              N'Toolbelt.Module.toolbelt.core.generate-series.DeploymentMode';

    SELECT
          @DeploymentMode = DeploymentMode
        , @TargetVersion = TargetVersion
    FROM #tbx_GenerateSeriesDeployState;

    IF XACT_STATE() <> 1
       OR OBJECT_ID(N'toolbelt_core.TVF_GenerateSeriesBigInt', N'IF') IS NULL
       OR OBJECT_ID(N'toolbelt_core.TVF_GenerateSeriesInt', N'IF') IS NULL
    BEGIN
        THROW 51058, N'Die Framework-Funktionen wurden nicht vollständig innerhalb der Deployment-Transaktion angelegt.', 1;
    END;

    DECLARE @Objects TABLE
    (
          ObjectOrdinal int IDENTITY(1, 1) NOT NULL
        , ObjectName    sysname            NOT NULL
    );

    INSERT INTO @Objects (ObjectName)
    VALUES (N'TVF_GenerateSeriesBigInt'), (N'TVF_GenerateSeriesInt'), (N'TVF_GenerateSeriesBigIntStatus');

    DECLARE
          @ObjectOrdinal int = 1
        , @ObjectCount   int = (SELECT COUNT(*) FROM @Objects)
        , @ObjectName    sysname
        , @ObjectId      int
        , @SourceHash    varchar(64)
        , @PropertyOrdinal int
        , @PropertyCount   int
        , @PropertyName    sysname
        , @PropertyValue   nvarchar(4000);

    DECLARE @Properties TABLE
    (
          PropertyOrdinal int            NOT NULL PRIMARY KEY
        , PropertyName    sysname        NOT NULL
        , PropertyValue   nvarchar(4000) NOT NULL
    );

    WHILE @ObjectOrdinal <= @ObjectCount
    BEGIN
        SELECT @ObjectName = ObjectName
        FROM @Objects
        WHERE ObjectOrdinal = @ObjectOrdinal;

        SET @ObjectId = OBJECT_ID
        (
            QUOTENAME(N'toolbelt_core') + N'.' + QUOTENAME(@ObjectName)
        );
        SET @SourceHash = CONVERT
        (
              varchar(64)
            , HASHBYTES
              (
                  N'SHA2_256'
                , CONVERT(varbinary(max), OBJECT_DEFINITION(@ObjectId))
              )
            , 2
        );

        INSERT INTO @Properties
        (
              PropertyOrdinal
            , PropertyName
            , PropertyValue
        )
        VALUES
              (1, N'Toolbelt.ModuleId', N'toolbelt.core.generate-series')
            , (2, N'Toolbelt.ModuleVersion', @TargetVersion)
            , (3, N'Toolbelt.ContractVersion', N'1.0')
            , (4, N'Toolbelt.DeploymentMode', @DeploymentMode)
            , (5, N'Toolbelt.SourceHash', CONVERT(nvarchar(4000), @SourceHash));

        SET @PropertyOrdinal = 1;
        SET @PropertyCount = (SELECT COUNT(*) FROM @Properties);

        WHILE @PropertyOrdinal <= @PropertyCount
        BEGIN
            SELECT
                  @PropertyName = PropertyName
                , @PropertyValue = PropertyValue
            FROM @Properties
            WHERE PropertyOrdinal = @PropertyOrdinal;

            IF EXISTS
               (
                   SELECT 1
                   FROM sys.extended_properties AS ep
                   WHERE ep.class = 1
                     AND ep.major_id = @ObjectId
                     AND ep.minor_id = 0
                     AND ep.name = @PropertyName
               )
            BEGIN
                EXEC sys.sp_updateextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_core'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;
            ELSE
            BEGIN
                EXEC sys.sp_addextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_core'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;

            SET @PropertyOrdinal += 1;
        END;

        DELETE FROM @Properties;
        SET @ObjectOrdinal += 1;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @VersionPropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @ModePropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.core.generate-series
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.core.result-table
:On Error exit

-- ============================================================================
-- Zweck:     Erst-, Upgrade- und Wiederholungsdeployment
-- Modul:     toolbelt.core.result-table v1.0.0
-- Schema:    toolbelt_core
-- Erfordert: SQL Server 2019, 2022 oder 2025
-- Modus:     SQLCMD; Ausführung aus diesem Deployment-Verzeichnis
-- Parameter: DeploymentMode=local|central
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'tempdb..#tbx_ResultTableReleaseObjects', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_ResultTableReleaseObjects;
END;

IF OBJECT_ID(N'tempdb..#tbx_ResultTableDeployState', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_ResultTableDeployState;
END;

/*
 * Dieses Manifest enthält jedes bekannte Release. Bei einem neuen Release
 * bleiben die Zeilen der unterstützten Vorgänger erhalten. Dadurch kann das
 * Deployment objektgenau unterscheiden zwischen:
 * - bereits zum Framework gehörenden Objekten,
 * - im Zielrelease neu hinzukommenden Namen,
 * - im Zielrelease weggefallenen Framework-Objekten.
 */
CREATE TABLE #tbx_ResultTableReleaseObjects
(
      ReleaseVersion nvarchar(64) NOT NULL
    , SchemaName     sysname      NOT NULL
    , ObjectName     sysname      NOT NULL
    , ObjectType     char(2)      NOT NULL
    , CONSTRAINT PK_tbx_ResultTableReleaseObjects
          PRIMARY KEY (ReleaseVersion, SchemaName, ObjectName)
);

INSERT INTO #tbx_ResultTableReleaseObjects
(
      ReleaseVersion
    , SchemaName
    , ObjectName
    , ObjectType
)
VALUES
(
      N'1.0.0'
    , N'toolbelt_core'
    , N'USP_PrepareResultTable'
    , 'P'
);

CREATE TABLE #tbx_ResultTableDeployState
(
      TargetVersion    nvarchar(64) NOT NULL
    , InstalledVersion nvarchar(64) NULL
    , DeploymentMode   nvarchar(16) NOT NULL
    , SchemaCreated     bit          NOT NULL
);

DECLARE
      @TargetVersion        nvarchar(64)  = N'1.0.0'
    , @DeploymentMode       nvarchar(16)  = LOWER(N'local')
    , @InstalledVersion     nvarchar(64)
    , @VersionPropertyName  sysname =
          N'Toolbelt.Module.toolbelt.core.result-table.Version'
    , @ProductMajorVersion  int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @SchemaId             int = SCHEMA_ID(N'toolbelt_core')
    , @CollisionSchema      sysname
    , @CollisionObject      sysname
    , @LockResult           int
    , @DropSql              nvarchar(max)
    , @SchemaCreated        bit = 0;

IF @ProductMajorVersion NOT IN (15, 16, 17)
BEGIN
    THROW 51030, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
END;

IF @DeploymentMode NOT IN (N'local', N'central')
BEGIN
    THROW 51031, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

IF @InstalledVersion IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM #tbx_ResultTableReleaseObjects AS ro
           WHERE ro.ReleaseVersion COLLATE Latin1_General_100_BIN2
                     = @InstalledVersion COLLATE Latin1_General_100_BIN2
       )
BEGIN
    THROW 51033, N'Die installierte Modulversion ist diesem Deployment nicht als unterstütztes Vorgängerrelease bekannt.', 1;
END;

-- SQLCMD-Preflightfragment, keine dauerhafte Mutation und kein Batchseparator.
-- Nur dbo sowie explizit vertrauenswürdige DBowner-/Installerrollen dürfen
-- das gemeinsame Schema kontrollieren. Fehlende Metadatensicht ist kein PASS.
IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'VIEW DEFINITION'),0)<>1
    THROW 51032,N'Für die Schematrustprüfung fehlt vollständige Datenbank-Metadatensicht.',2;
IF SCHEMA_ID(N'toolbelt_core') IS NOT NULL
   AND (SELECT principal_id FROM sys.schemas WHERE name=N'toolbelt_core')<>1
    THROW 51032,N'Der Owner von toolbelt_core muss dbo sein; kein automatischer Ownertransfer.',2;

DECLARE @tbx_TrustedSchemaPrincipals TABLE(PrincipalId int PRIMARY KEY);
;WITH Trusted AS
(
    SELECT principal_id FROM sys.database_principals
    WHERE principal_id=1 OR (type='R' AND name IN(N'db_owner',N'toolbelt_core_installer'))
    UNION ALL
    SELECT m.member_principal_id FROM sys.database_role_members m JOIN Trusted t ON t.principal_id=m.role_principal_id
)
INSERT @tbx_TrustedSchemaPrincipals SELECT DISTINCT principal_id FROM Trusted OPTION(MAXRECURSION 32);

-- Eine vertrauenswürdige Rolle darf nicht durch einen untrusted Rollenowner
-- verwaltet werden; Rollenname allein ist keine Autorität.
IF EXISTS(SELECT 1 FROM sys.database_principals r
    JOIN @tbx_TrustedSchemaPrincipals t ON t.PrincipalId=r.principal_id
    WHERE r.type='R' AND NOT EXISTS(SELECT 1 FROM @tbx_TrustedSchemaPrincipals owner
        WHERE owner.PrincipalId=r.owning_principal_id))
    THROW 51032,N'Eine vertrauenswürdige Rolle hat einen nicht freigegebenen Owner.',2;

IF EXISTS
(
    SELECT 1 FROM sys.database_permissions p
    WHERE p.state IN('G','W')
      AND NOT EXISTS(SELECT 1 FROM @tbx_TrustedSchemaPrincipals t WHERE t.PrincipalId=p.grantee_principal_id)
      AND
      (
        (p.class=3 AND p.major_id=SCHEMA_ID(N'toolbelt_core') AND p.permission_name IN(N'ALTER',N'CONTROL',N'TAKE OWNERSHIP'))
        OR (p.class=0 AND p.permission_name IN(N'CONTROL',N'ALTER ANY SCHEMA',N'ALTER ANY ROLE',N'IMPERSONATE ANY USER'))
        OR (p.class=4 AND p.permission_name IN(N'CONTROL',N'IMPERSONATE') AND EXISTS
            (SELECT 1 FROM @tbx_TrustedSchemaPrincipals t WHERE t.PrincipalId=p.major_id))
        OR (p.class=1 AND p.major_id=OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable') AND p.permission_name IN(N'ALTER',N'CONTROL',N'TAKE OWNERSHIP'))
      )
)
    THROW 51032,N'Nicht freigegebene Principals besitzen Schema- oder Helperkontrollrechte.',2;

-- Feste Rollenrechte stehen nicht vollständig in sys.database_permissions.
IF EXISTS
(
    SELECT 1 FROM sys.database_role_members m JOIN sys.database_principals r ON r.principal_id=m.role_principal_id
    WHERE r.name IN(N'db_ddladmin',N'db_securityadmin')
      AND NOT EXISTS(SELECT 1 FROM @tbx_TrustedSchemaPrincipals t WHERE t.PrincipalId=m.member_principal_id)
)
    THROW 51032,N'Nicht freigegebene DDL-Administrationsmitgliedschaft verhindert die Schematrustfreigabe.',2;

IF @SchemaId IS NULL
BEGIN
    IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    BEGIN
        THROW 51032, N'Zum Anlegen von toolbelt_core fehlt CREATE SCHEMA in der Installationsdatenbank.', 1;
    END;
END;
ELSE IF HAS_PERMS_BY_NAME(N'toolbelt_core', N'SCHEMA', N'ALTER') <> 1
BEGIN
    THROW 51032, N'Für das vorhandene Schema toolbelt_core fehlt ALTER.', 1;
END;

IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE PROCEDURE') <> 1
BEGIN
    THROW 51032, N'In der Installationsdatenbank fehlt CREATE PROCEDURE.', 1;
END;

/*
 * Ein vorhandener Zielname ist nur dann Framework-Bestand, wenn genau dieser
 * Name im bekannten installierten Release enthalten war. Bei einer
 * Erstinstallation oder einem im Zielrelease neuen Namen wird niemals ein
 * bereits vorhandenes fremdes Objekt überschrieben.
 */
SELECT TOP (1)
      @CollisionSchema = t.SchemaName
    , @CollisionObject = t.ObjectName
FROM #tbx_ResultTableReleaseObjects AS t
INNER JOIN sys.schemas AS s
    ON s.name COLLATE Latin1_General_100_BIN2
          = t.SchemaName COLLATE Latin1_General_100_BIN2
INNER JOIN sys.objects AS o
    ON o.schema_id = s.schema_id
   AND o.name COLLATE Latin1_General_100_BIN2
          = t.ObjectName COLLATE Latin1_General_100_BIN2
WHERE t.ReleaseVersion = @TargetVersion
  AND
  (
      @InstalledVersion IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM #tbx_ResultTableReleaseObjects AS p
             WHERE p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                       = @InstalledVersion COLLATE Latin1_General_100_BIN2
               AND p.SchemaName COLLATE Latin1_General_100_BIN2
                       = t.SchemaName COLLATE Latin1_General_100_BIN2
               AND p.ObjectName COLLATE Latin1_General_100_BIN2
                       = t.ObjectName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY
      t.SchemaName COLLATE Latin1_General_100_BIN2
    , t.ObjectName COLLATE Latin1_General_100_BIN2;

IF @CollisionObject IS NOT NULL
BEGIN
    DECLARE @CollisionMessage nvarchar(2048) =
        N'Das neue Framework-Objekt '
        + QUOTENAME(@CollisionSchema)
        + N'.'
        + QUOTENAME(@CollisionObject)
        + N' ist bereits vorhanden, stammt aber nicht aus dem bekannten installierten Release.';
    SET @CollisionMessage = REPLACE(@CollisionMessage, N'%', N'%%');
    THROW 51034, @CollisionMessage, 1;
END;

INSERT INTO #tbx_ResultTableDeployState
(
      TargetVersion
    , InstalledVersion
    , DeploymentMode
    , SchemaCreated
)
VALUES
(
      @TargetVersion
    , @InstalledVersion
    , @DeploymentMode
    , 0
);

/*
 * Der vollständige Preflight ist abgeschlossen. Erst jetzt beginnt die kurze
 * Mutationstransaktion. Eine Transaction-owned Application Lock serialisiert
 * Deployments dieses Moduls innerhalb der Zieldatenbank.
 */
BEGIN TRY
    BEGIN TRANSACTION;

    EXEC @LockResult = sys.sp_getapplock
          @Resource    = N'toolbelt.deploy.toolbelt.core.result-table'
        , @LockMode    = N'Exclusive'
        , @LockOwner   = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
    BEGIN
        THROW 51037, N'Ein paralleles Deployment von toolbelt.core.result-table ist bereits aktiv.', 1;
    END;

    DECLARE @CurrentInstalledVersion nvarchar(64);

    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
           <> ISNULL(@InstalledVersion, N'') COLLATE Latin1_General_100_BIN2
    BEGIN
        THROW 51037, N'Der installierte Modulstand hat sich seit dem Preflight verändert.', 1;
    END;

    SET @CollisionSchema = NULL;
    SET @CollisionObject = NULL;

    SELECT TOP (1)
          @CollisionSchema = t.SchemaName
        , @CollisionObject = t.ObjectName
    FROM #tbx_ResultTableReleaseObjects AS t
    INNER JOIN sys.schemas AS s
        ON s.name COLLATE Latin1_General_100_BIN2
              = t.SchemaName COLLATE Latin1_General_100_BIN2
    INNER JOIN sys.objects AS o
        ON o.schema_id = s.schema_id
       AND o.name COLLATE Latin1_General_100_BIN2
              = t.ObjectName COLLATE Latin1_General_100_BIN2
    WHERE t.ReleaseVersion = @TargetVersion
      AND
      (
          @InstalledVersion IS NULL
          OR NOT EXISTS
             (
                 SELECT 1
                 FROM #tbx_ResultTableReleaseObjects AS p
                 WHERE p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                           = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND p.SchemaName COLLATE Latin1_General_100_BIN2
                           = t.SchemaName COLLATE Latin1_General_100_BIN2
                   AND p.ObjectName COLLATE Latin1_General_100_BIN2
                           = t.ObjectName COLLATE Latin1_General_100_BIN2
             )
      );

    IF @CollisionObject IS NOT NULL
    BEGIN
        THROW 51037, N'Ein Zielobjekt hat sich seit dem Preflight verändert oder ist neu hinzugekommen.', 1;
    END;

    SET @SchemaId = SCHEMA_ID(N'toolbelt_core');

    IF @SchemaId IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_core] AUTHORIZATION [dbo];';
        SET @SchemaCreated = 1;
        SET @SchemaId = SCHEMA_ID(N'toolbelt_core');

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.Managed'
            , @value      = 1
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_core';

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.SchemaCategory'
            , @value      = N'core'
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_core';
    END;

    UPDATE #tbx_ResultTableDeployState
    SET SchemaCreated = @SchemaCreated;

    /*
     * Ein Objekt verschwindet nur dann, wenn es im bekannten installierten
     * Release enthalten war und im Zielrelease fehlt. Andere Objekte werden
     * durch diesen Block weder ausgewählt noch verändert.
     */
    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN o.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN o.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN o.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(s.name)
                    + N'.'
                    + QUOTENAME(o.name)
                    + N';'
                FROM #tbx_ResultTableReleaseObjects AS p
                INNER JOIN sys.schemas AS s
                    ON s.name COLLATE Latin1_General_100_BIN2
                          = p.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS o
                    ON o.schema_id = s.schema_id
                   AND o.name COLLATE Latin1_General_100_BIN2
                          = p.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                  AND NOT EXISTS
                      (
                          SELECT 1
                          FROM #tbx_ResultTableReleaseObjects AS t
                          WHERE t.ReleaseVersion = @TargetVersion
                            AND t.SchemaName COLLATE Latin1_General_100_BIN2
                                  = p.SchemaName COLLATE Latin1_General_100_BIN2
                            AND t.ObjectName COLLATE Latin1_General_100_BIN2
                                  = p.ObjectName COLLATE Latin1_General_100_BIN2
                      )
                  AND o.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY
                      s.name COLLATE Latin1_General_100_BIN2
                    , o.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;

    /*
     * Wurde ein Framework-Objekt lokal in einen anderen unterstützten
     * Objekttyp umgebaut, bleibt seine Herkunft aus dem Vorgängerrelease
     * maßgeblich. Der falsche Typ wird entfernt, damit die kanonische Source
     * den Zieltyp neu anlegen kann.
     */
    SET @DropSql = NULL;

    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN o.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN o.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN o.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(s.name)
                    + N'.'
                    + QUOTENAME(o.name)
                    + N';'
                FROM #tbx_ResultTableReleaseObjects AS t
                INNER JOIN #tbx_ResultTableReleaseObjects AS p
                    ON p.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND p.SchemaName COLLATE Latin1_General_100_BIN2
                          = t.SchemaName COLLATE Latin1_General_100_BIN2
                   AND p.ObjectName COLLATE Latin1_General_100_BIN2
                          = t.ObjectName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.schemas AS s
                    ON s.name COLLATE Latin1_General_100_BIN2
                          = t.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS o
                    ON o.schema_id = s.schema_id
                   AND o.name COLLATE Latin1_General_100_BIN2
                          = t.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE t.ReleaseVersion = @TargetVersion
                  AND o.type COLLATE Latin1_General_100_BIN2
                        <> t.ObjectType COLLATE Latin1_General_100_BIN2
                  AND o.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY
                      s.name COLLATE Latin1_General_100_BIN2
                    , o.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO

/*
 * Die kanonische Source liegt exakt einmal im Repository. CREATE OR ALTER
 * überschreibt bei Erst-, Upgrade- und Wiederholungsdeployment die
 * Framework-Procedure innerhalb der bereits geöffneten Transaktion.
 */
-- ============================================================================
-- Objekt:          toolbelt_core.USP_PrepareResultTable
-- Typ:             Stored Procedure
-- Zweck:           Bereitet eine vorhandene lokale Temp-Tabelle anhand des
--                  Spaltenschemas einer Referenztabelle als ResultTable vor.
-- Vertrag:         Documentation/Architecture/RESULT_TABLE_MODULE_DESIGN.md
-- Parameter:       @ResultTableToAlter sysname = NULL
--                  @LikeTable nvarchar(776) = NULL
--                  @KeepData bit = 0
--                  @Debug tinyint = 0
--                  @Hilfe bit = 0
-- Resultset:       Kein fachliches Resultset; bei @Hilfe = 1 genau ein
--                  standardisiertes Help-Resultset.
-- Dependencies:    Keine weiteren Toolbelt-Module.
-- Rechte:          EXECUTE auf der Procedure und Metadatensichtbarkeit auf
--                  reguläre Referenztabellen. Keine Rechteausweitung.
-- Versionen:       SQL Server 2019, 2022 und 2025.
-- Plattformen:     Windows und Linux; Runtime-Validierung separat auszuweisen.
-- Fehlerverhalten: Vertragsfehler 51020 bis 51029; Engine-Fehler werden nach
--                  transaktionsgerechtem Cleanup unverändert weitergegeben.
-- Performance:     Ein read-only Metadaten-Preflight. DDL nur bei abweichendem
--                  Schema; bei passendem Schema optional TRUNCATE.
-- Einschränkungen: Nur lokale Ziel-Temp-Tabellen und Tabellen als Schemaquelle.
--                  Keine gleichzeitige DDL-Manipulation derselben Zieltable.
-- ============================================================================

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_core].[USP_PrepareResultTable]
(
      @ResultTableToAlter sysname       = NULL
    , @LikeTable          nvarchar(776) = NULL
    , @KeepData           bit           = 0
    , @Debug              tinyint       = 0
    , @Hilfe              bit           = 0
)
AS
BEGIN
    SET NOCOUNT ON;

    -- Explizit übergebenes NULL verwendet denselben technischen Default wie
    -- ein ausgelassener optionaler Steuerparameter.
    SET @KeepData = ISNULL(@KeepData, 0);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    /*
     * Der Help-Pfad steht absichtlich vor jeder fachlichen Validierung. Dadurch
     * bleibt ein reiner Hilfeaufruf ohne Zieltable, Referenztabelle oder Rechte
     * auf fremde Metadaten möglich und garantiert keinerlei Mutation.
     */
    IF @Hilfe = 1
    BEGIN
        DECLARE @Help TABLE
        (
              HelpContractVersion varchar(16)    NOT NULL
            , SchemaName          sysname        NOT NULL
            , ObjectName          sysname        NOT NULL
            , Section             varchar(32)    NOT NULL
            , Ordinal             int            NOT NULL
            , ItemName            sysname        NULL
            , SqlDataType         varchar(256)   NULL
            , IsRequired          bit            NULL
            , IsNullable          bit            NULL
            , DefaultValue        nvarchar(4000) NULL
            , Description         nvarchar(max)  NOT NULL
            , ExampleSql          nvarchar(max)  NULL
        );

        INSERT INTO @Help
        (
              HelpContractVersion
            , SchemaName
            , ObjectName
            , Section
            , Ordinal
            , ItemName
            , SqlDataType
            , IsRequired
            , IsNullable
            , DefaultValue
            , Description
            , ExampleSql
        )
        VALUES
          ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'DESCRIPTION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Bereitet eine vorhandene lokale Temp-Tabelle anhand des Spaltenschemas einer vorhandenen Referenztabelle vor. Die Procedure fügt keine fachlichen Resultzeilen ein.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PARAMETER', 1
          , N'@ResultTableToAlter', 'sysname', 1, 0, N'NULL'
          , N'Vorhandene lokale Ziel-Temp-Tabelle. Der Name beginnt mit genau einem #, ist höchstens 116 Zeichen lang und verwendet nicht den reservierten Präfix #tbx_.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PARAMETER', 2
          , N'@LikeTable', 'nvarchar(776)', 1, 0, N'NULL'
          , N'Referenztabelle in der Form #LocalTemplate, Schema.Table oder Database.Schema.Table. Ziel- und Referenztabelle dürfen nicht identisch sein. Views, Synonyme, globale Temp-Tabellen und vierteilige Namen sind nicht unterstützt.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PARAMETER', 3
          , N'@KeepData', 'bit', 0, 1, N'0'
          , N'0 verwendet Replace-Semantik. 1 erhält vorhandene Daten nur bei bereits passendem Schema; andernfalls wird vor jeder Mutation mit Fehler 51025 abgebrochen.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PARAMETER', 4
          , N'@Debug', 'tinyint', 0, 1, N'0'
          , N'Steuert Debug-Messages. Die Stufen 1 bis 3 liefern zunehmend Details; 255 ist der maximale interne Trace. Debug erzeugt kein Resultset.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PARAMETER', 5
          , N'@Hilfe', 'bit', 0, 1, N'0'
          , N'1 gibt ausschließlich dieses Help-Resultset aus und ignoriert alle anderen Parameter.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'RESULT_COLUMN', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Diese Infrastruktur-USP besitzt kein fachliches Resultset. Erfolg wird mit RETURN 0, ein Fehler mit THROW signalisiert.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 1
          , N'51020', NULL, NULL, NULL, NULL
          , N'@ResultTableToAlter fehlt oder ist kein zulässiger lokaler Temp-Tabellenname.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 2
          , N'51021', NULL, NULL, NULL, NULL
          , N'Die Zieltable ist im aktuellen Session-Scope nicht sichtbar.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 3
          , N'51022', NULL, NULL, NULL, NULL
          , N'@LikeTable fehlt, ist mehrdeutig, verwendet eine nicht unterstützte Namensform oder bezeichnet dieselbe Temp-Tabelle wie das Ziel.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 4
          , N'51023', NULL, NULL, NULL, NULL
          , N'Die Referenztabelle ist nicht sichtbar oder kein unterstützter Tabellentyp.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 5
          , N'51024', NULL, NULL, NULL, NULL
          , N'Das Referenzschema enthält eine nicht unterstützte oder nicht einfügbare Spaltenform.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 6
          , N'51025', NULL, NULL, NULL, NULL
          , N'@KeepData = 1 verhindert den erforderlichen Schemaumbau.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 7
          , N'51026', NULL, NULL, NULL, NULL
          , N'Ein Index, Constraint oder anderes abhängiges Objekt verhindert den Schemaumbau.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 8
          , N'51027', NULL, NULL, NULL, NULL
          , N'Eine Collation oder ein Datentyp kann nicht sicher in DDL überführt werden.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 9
          , N'51028', NULL, NULL, NULL, NULL
          , N'Der aktuelle Transaktionszustand erlaubt kein kontrolliertes Rollback.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'ERROR', 10
          , N'51029', NULL, NULL, NULL, NULL
          , N'Intern erzeugtes DDL überschreitet einen unterstützten Grenzwert oder ist unvollständig.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'PERMISSION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Erforderlich sind EXECUTE auf der Procedure sowie ausreichende Metadatensichtbarkeit auf eine reguläre Referenztabelle. Die Procedure verwendet kein EXECUTE AS und gewährt keine Rechte.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'LIMITATION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Permanente oder globale Zieltabellen, Tabellenvariablen, identische Ziel- und Referenztabellen, Views, Synonyme, Linked Server, frei geliefertes DDL und parallele DDL-Manipulation derselben Zieltable sind nicht unterstützt.'
          , NULL )
        , ( '1.0', N'toolbelt_core', N'USP_PrepareResultTable', 'EXAMPLE', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Bereitet eine synthetische lokale ResultTable anhand einer lokalen Helper-Tabelle vor.'
          , N'CREATE TABLE #Result (Dummy int NULL);
CREATE TABLE #ResultShape (ItemOrdinal bigint NOT NULL, ItemValue varchar(100) NULL);

EXEC toolbelt_core.USP_PrepareResultTable
      @ResultTableToAlter = N''#Result''
    , @LikeTable          = N''#ResultShape''
    , @KeepData           = 0;' );

        SELECT
              HelpContractVersion
            , SchemaName
            , ObjectName
            , Section
            , Ordinal
            , ItemName
            , SqlDataType
            , IsRequired
            , IsNullable
            , DefaultValue
            , Description
            , ExampleSql
        FROM @Help
        ORDER BY
              CASE Section
                  WHEN 'DESCRIPTION'   THEN 1
                  WHEN 'PARAMETER'     THEN 2
                  WHEN 'RESULT_COLUMN' THEN 3
                  WHEN 'ERROR'         THEN 4
                  WHEN 'PERMISSION'    THEN 5
                  WHEN 'LIMITATION'    THEN 6
                  WHEN 'EXAMPLE'       THEN 7
                  ELSE 8
              END
            , Ordinal;

        RETURN 0;
    END;

    DECLARE
          @TargetObjectId          int
        , @TargetQuotedName        nvarchar(258)
        , @SourceObjectId          int
        , @SourceDatabaseName      sysname
        , @SourceDatabaseQuoted    nvarchar(258)
        , @SourceSchemaName        sysname
        , @SourceObjectName        sysname
        , @SourceServerName        sysname
        , @SourceIsLocal           bit = 0
        , @Sql                     nvarchar(max)
        , @ErrorMessage            nvarchar(2048)
        , @DebugMessage            nvarchar(max)
        , @DebugChunk              nvarchar(1800);

    /*
     * Der logische Zielname wird als ein einzelner Identifier behandelt. Ein
     * Punkt oder eine schließende Klammer darf daher Bestandteil des Namens
     * sein; QUOTENAME verhindert, dass daraus ein mehrteiliger Name oder DDL
     * wird. Die physische TempDB-Suffixbildung wird SQL Server überlassen.
     */
    IF @ResultTableToAlter IS NULL
       OR DATALENGTH(@ResultTableToAlter) < 4
       OR DATALENGTH(@ResultTableToAlter) > 232
       OR LEFT(@ResultTableToAlter, 1) COLLATE Latin1_General_100_BIN2 <> N'#'
       OR LEFT(@ResultTableToAlter, 2) COLLATE Latin1_General_100_BIN2 = N'##'
       OR LOWER(LEFT(@ResultTableToAlter, 5) COLLATE Latin1_General_100_BIN2) = N'#tbx_'
       OR QUOTENAME(@ResultTableToAlter) IS NULL
    BEGIN
        THROW 51020, N'@ResultTableToAlter muss eine vorhandene lokale Temp-Tabelle mit genau einem führenden #, höchstens 116 Zeichen und ohne reservierten Präfix #tbx_ bezeichnen.', 1;
    END;

    SET @TargetQuotedName = QUOTENAME(@ResultTableToAlter);
    SET @TargetObjectId = OBJECT_ID(N'tempdb..' + @TargetQuotedName, N'U');

    IF @TargetObjectId IS NULL
    BEGIN
        SET @ErrorMessage = N'Die lokale Zieltable '
            + @TargetQuotedName
            + N' ist im aktuellen Session-Scope nicht sichtbar.';
        SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
        THROW 51021, @ErrorMessage, 1;
    END;

    IF @LikeTable IS NULL OR DATALENGTH(@LikeTable) = 0
    BEGIN
        THROW 51022, N'@LikeTable muss #LocalTemplate, Schema.Table oder Database.Schema.Table bezeichnen.', 1;
    END;

    /*
     * Lokale Referenztabellen werden wie die Zieltable genau einmal aufgelöst.
     * Globale Temp-Tabellen sind eine erkennbare, aber nicht unterstützte
     * Tabellenart und erhalten deshalb den Objektfehler 51023.
     */
    IF (LEFT(@LikeTable, 1) COLLATE Latin1_General_100_BIN2) = N'#'
    BEGIN
        IF (LEFT(@LikeTable, 2) COLLATE Latin1_General_100_BIN2) = N'##'
        BEGIN
            THROW 51023, N'Globale Temp-Tabellen sind als @LikeTable nicht unterstützt.', 1;
        END;

        IF DATALENGTH(@LikeTable) < 4
           OR DATALENGTH(@LikeTable) > 232
           OR QUOTENAME(CONVERT(sysname, @LikeTable)) IS NULL
        BEGIN
            THROW 51022, N'Der lokale Name in @LikeTable ist kein zulässiger Temp-Tabellenname.', 1;
        END;

        SET @SourceIsLocal = 1;
        SET @SourceDatabaseName = N'tempdb';
        SET @SourceDatabaseQuoted = QUOTENAME(@SourceDatabaseName);
        SET @SourceObjectName = CONVERT(sysname, @LikeTable);
        SET @SourceObjectId = OBJECT_ID(
              N'tempdb..' + QUOTENAME(@SourceObjectName)
            , N'U'
        );

        IF @SourceObjectId IS NULL
        BEGIN
            SET @ErrorMessage = N'Die lokale Referenztabelle '
                + QUOTENAME(@SourceObjectName)
                + N' ist im aktuellen Session-Scope nicht sichtbar.';
            SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
            THROW 51023, @ErrorMessage, 1;
        END;
    END;
    ELSE
    BEGIN
        /*
         * PARSENAME zerlegt ausschließlich Objektnamen. Die ermittelten Teile
         * werden nie als Originaltext ausgeführt, sondern als sysname geprüft,
         * mit QUOTENAME neu aufgebaut und Werte in Catalog-Abfragen
         * parametrisiert. Ein Serverteil ist vertraglich ausgeschlossen.
         */
        SET @SourceObjectName = PARSENAME(@LikeTable, 1);
        SET @SourceSchemaName = PARSENAME(@LikeTable, 2);
        SET @SourceDatabaseName = PARSENAME(@LikeTable, 3);
        SET @SourceServerName = PARSENAME(@LikeTable, 4);

        IF @SourceObjectName IS NULL
           OR @SourceSchemaName IS NULL
           OR @SourceServerName IS NOT NULL
           OR QUOTENAME(@SourceObjectName) IS NULL
           OR QUOTENAME(@SourceSchemaName) IS NULL
        BEGIN
            THROW 51022, N'@LikeTable muss als Schema.Table oder Database.Schema.Table ohne Serverteil angegeben werden.', 1;
        END;

        IF @SourceDatabaseName IS NULL
        BEGIN
            SET @SourceDatabaseName = DB_NAME();
        END;

        IF DB_ID(@SourceDatabaseName) IS NULL
           OR QUOTENAME(@SourceDatabaseName) IS NULL
        BEGIN
            THROW 51023, N'Die Datenbank der Referenztabelle ist nicht sichtbar oder nicht vorhanden.', 1;
        END;

        SET @SourceDatabaseQuoted = QUOTENAME(@SourceDatabaseName);
        SET @Sql = N'
SELECT @ResolvedObjectId = t.object_id
FROM ' + @SourceDatabaseQuoted + N'.sys.tables AS t
INNER JOIN ' + @SourceDatabaseQuoted + N'.sys.schemas AS s
    ON s.schema_id = t.schema_id
WHERE s.name COLLATE Latin1_General_100_BIN2
          = @SchemaName COLLATE Latin1_General_100_BIN2
  AND t.name COLLATE Latin1_General_100_BIN2
          = @ObjectName COLLATE Latin1_General_100_BIN2;';

        BEGIN TRY
            EXEC sys.sp_executesql
                  @Sql
                , N'@SchemaName sysname, @ObjectName sysname, @ResolvedObjectId int OUTPUT'
                , @SchemaName      = @SourceSchemaName
                , @ObjectName      = @SourceObjectName
                , @ResolvedObjectId = @SourceObjectId OUTPUT;
        END TRY
        BEGIN CATCH
            /*
             * Ein tatsächlich aufgetretener Engine-Fehler darf nicht als
             * Toolbelt-Validierungsfehler erscheinen. Nur eine erfolgreich
             * ausgeführte Suche ohne unterstütztes Objekt ergibt 51023.
             */
            THROW;
        END CATCH;

        IF @SourceObjectId IS NULL
        BEGIN
            THROW 51023, N'Die reguläre Referenztabelle ist nicht sichtbar, nicht vorhanden oder kein User Table.', 1;
        END;
    END;

    IF @SourceIsLocal = 1 AND @SourceObjectId = @TargetObjectId
    BEGIN
        THROW 51022, N'@ResultTableToAlter und @LikeTable dürfen nicht dieselbe lokale Temp-Tabelle bezeichnen.', 1;
    END;

    IF @Debug >= 1
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: Ziel- und Referenztabelle wurden aufgelöst; read-only Preflight beginnt.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    DECLARE
          @SourceColumnCount       int
        , @TargetColumnCount       int
        , @UnsupportedColumnName   sysname
        , @UnsupportedReason       nvarchar(4000)
        , @InvalidCollationDetected bit
        , @InvalidCollationName    sysname
        , @SchemaMatches           bit
        , @AddColumnsList          nvarchar(max)
        , @AddColumnAfterAnchor     nvarchar(4000)
        , @DropColumnsList         nvarchar(max)
        , @DropColumnBeforeAnchor   nvarchar(258)
        , @SourceMetadataDebug     nvarchar(max);

    /*
     * Die Quelldatenbank ist der einzige dynamische Catalog-Teil. Sie stammt
     * entweder aus DB_NAME/PARSENAME oder ist tempdb und wird mit QUOTENAME
     * begrenzt. Objekt-IDs werden als Werte parametrisiert.
     *
     * Alias Types werden auf den zugrunde liegenden Systemtyp normalisiert.
     * Typisiertes XML und Sparse werden bewusst als untypisiertes XML
     * beziehungsweise normale Spalte abgebildet. Unbekannte neue Typen bleiben
     * durch die Whitelist gesperrt, bis ihr Vertrag versioniert erweitert wird.
     */
    SET @Sql = N'
DECLARE @SourceColumns TABLE
(
      ColumnOrdinal             int            NOT NULL
    , ColumnName                sysname        NOT NULL
    , TypeName                  sysname        NULL
    , MaxLength                 smallint       NOT NULL
    , PrecisionValue            tinyint        NOT NULL
    , ScaleValue                tinyint        NOT NULL
    , IsNullable                bit            NOT NULL
    , CollationName             sysname        NULL
    , IsIdentity                bit            NOT NULL
    , IsComputed                bit            NOT NULL
    , GeneratedAlwaysType       tinyint        NOT NULL
    , IsHidden                  bit            NOT NULL
    , IsColumnSet               bit            NOT NULL
    , IsSparse                  bit            NOT NULL
    , EncryptionType            int            NULL
    , IsAssemblyType            bit            NOT NULL
    , IsUserDefined             bit            NOT NULL
    , XmlCollectionId           int            NOT NULL
    , UnsupportedReason         nvarchar(4000) NULL
    , NormalizedTypeDeclaration nvarchar(4000) NULL
);

;WITH RawSourceColumns AS
(
    SELECT
          ROW_NUMBER() OVER (ORDER BY c.column_id) AS ColumnOrdinal
        , c.name AS ColumnName
        , CASE
              WHEN st.name = N''sysname'' AND c.system_type_id = 231
                  THEN N''nvarchar''
              WHEN st.is_user_defined = 1 AND st.is_assembly_type = 0
                  THEN bt.name
              ELSE st.name
          END AS TypeName
        , c.system_type_id AS SystemTypeId
        , c.max_length AS MaxLength
        , c.precision AS PrecisionValue
        , c.scale AS ScaleValue
        , c.is_nullable AS IsNullable
        , c.collation_name AS CollationName
        , c.is_identity AS IsIdentity
        , c.is_computed AS IsComputed
        , c.generated_always_type AS GeneratedAlwaysType
        , c.is_hidden AS IsHidden
        , c.is_column_set AS IsColumnSet
        , c.is_sparse AS IsSparse
        , c.encryption_type AS EncryptionType
        , ISNULL(st.is_assembly_type, 0) AS IsAssemblyType
        , ISNULL(st.is_user_defined, 0) AS IsUserDefined
        , c.xml_collection_id AS XmlCollectionId
    FROM ' + @SourceDatabaseQuoted + N'.sys.columns AS c
    LEFT JOIN ' + @SourceDatabaseQuoted + N'.sys.types AS st
        ON st.user_type_id = c.user_type_id
    LEFT JOIN ' + @SourceDatabaseQuoted + N'.sys.types AS bt
        ON bt.system_type_id = c.system_type_id
       AND bt.user_type_id = bt.system_type_id
    WHERE c.object_id = @SourceObjectId
)
INSERT INTO @SourceColumns
(
      ColumnOrdinal
    , ColumnName
    , TypeName
    , MaxLength
    , PrecisionValue
    , ScaleValue
    , IsNullable
    , CollationName
    , IsIdentity
    , IsComputed
    , GeneratedAlwaysType
    , IsHidden
    , IsColumnSet
    , IsSparse
    , EncryptionType
    , IsAssemblyType
    , IsUserDefined
    , XmlCollectionId
    , UnsupportedReason
    , NormalizedTypeDeclaration
)
SELECT
      r.ColumnOrdinal
    , r.ColumnName
    , r.TypeName
    , r.MaxLength
    , r.PrecisionValue
    , r.ScaleValue
    , r.IsNullable
    , r.CollationName
    , r.IsIdentity
    , r.IsComputed
    , r.GeneratedAlwaysType
    , r.IsHidden
    , r.IsColumnSet
    , r.IsSparse
    , r.EncryptionType
    , r.IsAssemblyType
    , r.IsUserDefined
    , r.XmlCollectionId
    , CASE
          WHEN r.IsIdentity = 1
              THEN N''Identity-Spalten sind nicht als Resultset-Shape unterstützt.''
          WHEN r.IsComputed = 1
              THEN N''Computed Columns sind nicht als Resultset-Shape unterstützt.''
          WHEN r.GeneratedAlwaysType <> 0
              THEN N''Generated-always-Spalten sind nicht als Resultset-Shape unterstützt.''
          WHEN r.IsHidden = 1
              THEN N''Hidden Columns sind nicht als Resultset-Shape unterstützt.''
          WHEN r.IsColumnSet = 1
              THEN N''XML Column Sets sind nicht als Resultset-Shape unterstützt.''
          WHEN r.EncryptionType IS NOT NULL
              THEN N''Verschlüsselte Spalten sind nicht als Resultset-Shape unterstützt.''
          WHEN r.SystemTypeId = 189
              THEN N''rowversion/timestamp ist nicht explizit einfügbar.''
          WHEN r.TypeName IN (N''text'', N''ntext'', N''image'')
              THEN N''Legacy-LOB-Typen text, ntext und image sind nicht unterstützt.''
          WHEN r.IsAssemblyType = 1
               AND (r.IsUserDefined = 1
                    OR r.TypeName NOT IN (N''hierarchyid'', N''geometry'', N''geography''))
              THEN N''Benutzerdefinierte oder unbekannte CLR Types sind nicht unterstützt.''
          WHEN r.TypeName IS NULL
               OR r.TypeName NOT IN
                  (
                        N''bigint'', N''binary'', N''bit'', N''char''
                      , N''date'', N''datetime'', N''datetime2'', N''datetimeoffset''
                      , N''decimal'', N''float'', N''geography'', N''geometry''
                      , N''hierarchyid'', N''int'', N''money'', N''nchar''
                      , N''numeric'', N''nvarchar'', N''real'', N''smalldatetime''
                      , N''smallint'', N''smallmoney'', N''sql_variant'', N''time''
                      , N''tinyint'', N''uniqueidentifier'', N''varbinary''
                      , N''varchar'', N''xml''
                  )
              THEN N''Der Datentyp ist in Contract-Version 1.0 nicht freigegeben.''
          ELSE NULL
      END AS UnsupportedReason
    , CASE
          WHEN r.TypeName IN (N''char'', N''varchar'', N''binary'', N''varbinary'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CASE
                         WHEN r.MaxLength = -1 THEN N''max''
                         ELSE CONVERT(nvarchar(10), r.MaxLength)
                     END
                   + N'')''
          WHEN r.TypeName IN (N''nchar'', N''nvarchar'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CASE
                         WHEN r.MaxLength = -1 THEN N''max''
                         ELSE CONVERT(nvarchar(10), r.MaxLength / 2)
                     END
                   + N'')''
          WHEN r.TypeName IN (N''decimal'', N''numeric'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CONVERT(nvarchar(10), r.PrecisionValue)
                   + N'',''
                   + CONVERT(nvarchar(10), r.ScaleValue)
                   + N'')''
          WHEN r.TypeName = N''float''
              THEN N''[float](''
                   + CONVERT(nvarchar(10), r.PrecisionValue)
                   + N'')''
          WHEN r.TypeName IN (N''time'', N''datetime2'', N''datetimeoffset'')
              THEN QUOTENAME(r.TypeName)
                   + N''(''
                   + CONVERT(nvarchar(10), r.ScaleValue)
                   + N'')''
          WHEN r.TypeName IN
               (
                     N''bigint'', N''bit'', N''date'', N''datetime''
                   , N''geography'', N''geometry'', N''hierarchyid'', N''int''
                   , N''money'', N''real'', N''smalldatetime'', N''smallint''
                   , N''smallmoney'', N''sql_variant'', N''tinyint''
                   , N''uniqueidentifier'', N''xml''
               )
              THEN QUOTENAME(r.TypeName)
          ELSE NULL
      END AS NormalizedTypeDeclaration
FROM RawSourceColumns AS r;

DECLARE @TargetColumns TABLE
(
      ColumnOrdinal   int      NOT NULL
    , ColumnName      sysname  NOT NULL
    , TypeName        sysname  NULL
    , MaxLength       smallint NOT NULL
    , PrecisionValue  tinyint  NOT NULL
    , ScaleValue      tinyint  NOT NULL
    , IsNullable      bit      NOT NULL
    , CollationName   sysname  NULL
    , IsInsertable    bit      NOT NULL
);

INSERT INTO @TargetColumns
(
      ColumnOrdinal
    , ColumnName
    , TypeName
    , MaxLength
    , PrecisionValue
    , ScaleValue
    , IsNullable
    , CollationName
    , IsInsertable
)
SELECT
      ROW_NUMBER() OVER (ORDER BY c.column_id)
    , c.name
    , CASE
          WHEN st.name = N''sysname'' AND c.system_type_id = 231
              THEN N''nvarchar''
          WHEN st.is_user_defined = 1 AND st.is_assembly_type = 0
              THEN bt.name
          ELSE st.name
      END
    , c.max_length
    , c.precision
    , c.scale
    , c.is_nullable
    , c.collation_name
    , CONVERT
      (
          bit,
          CASE
              WHEN c.is_identity = 0
               AND c.is_computed = 0
               AND c.generated_always_type = 0
               AND c.is_hidden = 0
               AND c.is_column_set = 0
               AND c.is_sparse = 0
               AND c.encryption_type IS NULL
               AND c.xml_collection_id = 0
               AND c.system_type_id <> 189
               AND NOT
                   (
                       st.is_assembly_type = 1
                       AND (st.is_user_defined = 1
                            OR st.name NOT IN (N''hierarchyid'', N''geometry'', N''geography''))
                   )
                  THEN 1
              ELSE 0
          END
      )
FROM tempdb.sys.columns AS c
LEFT JOIN tempdb.sys.types AS st
    ON st.user_type_id = c.user_type_id
LEFT JOIN tempdb.sys.types AS bt
    ON bt.system_type_id = c.system_type_id
   AND bt.user_type_id = bt.system_type_id
WHERE c.object_id = @TargetObjectId;

SELECT @SourceColumnCount = COUNT(*)
FROM @SourceColumns;

SELECT @TargetColumnCount = COUNT(*)
FROM @TargetColumns;

SELECT TOP (1)
      @UnsupportedColumnName = ColumnName
    , @UnsupportedReason = UnsupportedReason
FROM @SourceColumns
WHERE UnsupportedReason IS NOT NULL
   OR NormalizedTypeDeclaration IS NULL
ORDER BY ColumnOrdinal;

SELECT TOP (1)
      @InvalidCollationDetected = 1
    , @InvalidCollationName = CollationName
FROM @SourceColumns AS c
WHERE c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
  AND
  (
      c.CollationName IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM sys.fn_helpcollations() AS hc
             WHERE hc.name COLLATE Latin1_General_100_BIN2
                       = c.CollationName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY ColumnOrdinal;

SELECT @SchemaMatches =
    CONVERT
    (
        bit,
        CASE
            WHEN EXISTS
                 (
                     SELECT 1
                     FROM @SourceColumns AS s
                     FULL OUTER JOIN @TargetColumns AS t
                         ON t.ColumnOrdinal = s.ColumnOrdinal
                     WHERE s.ColumnOrdinal IS NULL
                        OR t.ColumnOrdinal IS NULL
                        OR s.ColumnName COLLATE Latin1_General_100_BIN2
                               <> t.ColumnName COLLATE Latin1_General_100_BIN2
                        OR ISNULL(s.TypeName, N'''') COLLATE Latin1_General_100_BIN2
                               <> ISNULL(t.TypeName, N'''') COLLATE Latin1_General_100_BIN2
                        OR s.MaxLength <> t.MaxLength
                        OR s.PrecisionValue <> t.PrecisionValue
                        OR s.ScaleValue <> t.ScaleValue
                        OR s.IsNullable <> t.IsNullable
                        OR ISNULL(s.CollationName, N'''') COLLATE Latin1_General_100_BIN2
                               <> ISNULL(t.CollationName, N'''') COLLATE Latin1_General_100_BIN2
                        OR t.IsInsertable <> 1
                 )
                THEN 0
            ELSE 1
        END
    );

SELECT @AddColumnsList =
    STUFF
    (
        (
            SELECT
                  N'', ''
                + QUOTENAME(c.ColumnName)
                + N'' ''
                + c.NormalizedTypeDeclaration
                + CASE
                      WHEN c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
                          THEN N'' COLLATE '' + c.CollationName
                      ELSE N''''
                  END
                + CASE WHEN c.IsNullable = 1 THEN N'' NULL'' ELSE N'' NOT NULL'' END
            FROM @SourceColumns AS c
            WHERE c.ColumnOrdinal < 1024
               OR @SourceColumnCount < 1024
            ORDER BY c.ColumnOrdinal
            FOR XML PATH(N''''), TYPE
        ).value(N''.'', N''nvarchar(max)'')
      , 1
      , 2
      , N''''
    );

SELECT @AddColumnAfterAnchor =
      QUOTENAME(c.ColumnName)
    + N'' ''
    + c.NormalizedTypeDeclaration
    + CASE
          WHEN c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
              THEN N'' COLLATE '' + c.CollationName
          ELSE N''''
      END
    + CASE WHEN c.IsNullable = 1 THEN N'' NULL'' ELSE N'' NOT NULL'' END
FROM @SourceColumns AS c
WHERE @SourceColumnCount = 1024
  AND c.ColumnOrdinal = 1024;

SELECT @DropColumnsList =
    STUFF
    (
        (
            SELECT N'', '' + QUOTENAME(c.ColumnName)
            FROM @TargetColumns AS c
            WHERE c.ColumnOrdinal < 1024
               OR @TargetColumnCount < 1024
            ORDER BY c.ColumnOrdinal
            FOR XML PATH(N''''), TYPE
        ).value(N''.'', N''nvarchar(max)'')
      , 1
      , 2
      , N''''
    );

SELECT @DropColumnBeforeAnchor = QUOTENAME(c.ColumnName)
FROM @TargetColumns AS c
WHERE @TargetColumnCount = 1024
  AND c.ColumnOrdinal = 1024;

SELECT @SourceMetadataDebug =
    STUFF
    (
        (
            SELECT
                  NCHAR(10)
                + CONVERT(nvarchar(10), c.ColumnOrdinal)
                + N'': ''
                + QUOTENAME(c.ColumnName)
                + N'' ''
                + ISNULL(c.NormalizedTypeDeclaration, N''<unsupported>'')
                + CASE
                      WHEN c.TypeName IN (N''char'', N''varchar'', N''nchar'', N''nvarchar'')
                          THEN N'' COLLATE '' + ISNULL(c.CollationName, N''<NULL>'')
                      ELSE N''''
                  END
                + CASE WHEN c.IsNullable = 1 THEN N'' NULL'' ELSE N'' NOT NULL'' END
            FROM @SourceColumns AS c
            ORDER BY c.ColumnOrdinal
            FOR XML PATH(N''''), TYPE
        ).value(N''.'', N''nvarchar(max)'')
      , 1
      , 1
      , N''''
    );';

    BEGIN TRY
        EXEC sys.sp_executesql
              @Sql
            , N'@SourceObjectId int,
                @TargetObjectId int,
                @SourceColumnCount int OUTPUT,
                @TargetColumnCount int OUTPUT,
                @UnsupportedColumnName sysname OUTPUT,
                @UnsupportedReason nvarchar(4000) OUTPUT,
                @InvalidCollationDetected bit OUTPUT,
                @InvalidCollationName sysname OUTPUT,
                @SchemaMatches bit OUTPUT,
                @AddColumnsList nvarchar(max) OUTPUT,
                @AddColumnAfterAnchor nvarchar(4000) OUTPUT,
                @DropColumnsList nvarchar(max) OUTPUT,
                @DropColumnBeforeAnchor nvarchar(258) OUTPUT,
                @SourceMetadataDebug nvarchar(max) OUTPUT'
            , @SourceObjectId        = @SourceObjectId
            , @TargetObjectId        = @TargetObjectId
            , @SourceColumnCount     = @SourceColumnCount OUTPUT
            , @TargetColumnCount     = @TargetColumnCount OUTPUT
            , @UnsupportedColumnName = @UnsupportedColumnName OUTPUT
            , @UnsupportedReason     = @UnsupportedReason OUTPUT
            , @InvalidCollationDetected = @InvalidCollationDetected OUTPUT
            , @InvalidCollationName  = @InvalidCollationName OUTPUT
            , @SchemaMatches         = @SchemaMatches OUTPUT
            , @AddColumnsList        = @AddColumnsList OUTPUT
            , @AddColumnAfterAnchor  = @AddColumnAfterAnchor OUTPUT
            , @DropColumnsList       = @DropColumnsList OUTPUT
            , @DropColumnBeforeAnchor = @DropColumnBeforeAnchor OUTPUT
            , @SourceMetadataDebug   = @SourceMetadataDebug OUTPUT;
    END TRY
    BEGIN CATCH
        /*
         * Catalog- und Engine-Fehler werden nicht in einen scheinbar
         * erfolgreichen Validierungsstatus übersetzt. Die ursprüngliche
         * Fehlernummer bleibt durch THROW für den Aufrufer erhalten.
         */
        THROW;
    END CATCH;

    IF @SourceColumnCount IS NULL OR @SourceColumnCount = 0
    BEGIN
        THROW 51023, N'Die Referenztabelle besitzt keine sichtbaren Spalten oder ihre Metadaten sind nicht ausreichend sichtbar.', 1;
    END;

    IF @SourceColumnCount > 1024
    BEGIN
        THROW 51029, N'Das Referenzschema überschreitet das unterstützte Limit von 1024 ResultTable-Spalten.', 1;
    END;

    IF @TargetColumnCount > 1024
    BEGIN
        THROW 51029, N'Die Zieltable überschreitet das unterstützte Limit von 1024 ResultTable-Spalten.', 1;
    END;

    IF @UnsupportedColumnName IS NOT NULL
    BEGIN
        SET @ErrorMessage = N'Die Referenzspalte '
            + QUOTENAME(@UnsupportedColumnName)
            + N' ist nicht unterstützt. '
            + ISNULL(@UnsupportedReason, N'Es konnte keine sichere Typdeklaration erzeugt werden.');
        SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
        THROW 51024, @ErrorMessage, 1;
    END;

    IF @InvalidCollationDetected = 1
    BEGIN
        SET @ErrorMessage = N'Die Collation '
            + COALESCE(QUOTENAME(@InvalidCollationName), N'<NULL>')
            + N' kann nicht sicher für die ResultTable verwendet werden.';
        SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
        THROW 51027, @ErrorMessage, 1;
    END;

    IF @AddColumnsList IS NULL
       OR @DropColumnsList IS NULL
       OR (@SourceColumnCount = 1024 AND @AddColumnAfterAnchor IS NULL)
       OR (@TargetColumnCount = 1024 AND @DropColumnBeforeAnchor IS NULL)
       OR DATALENGTH(@AddColumnsList) > 2000000
       OR DATALENGTH(@DropColumnsList) > 2000000
       OR DATALENGTH(ISNULL(@AddColumnAfterAnchor, N'')) > 8000
    BEGIN
        THROW 51029, N'Das intern erzeugte DDL ist unvollständig oder überschreitet 1.000.000 Unicode-Zeichen je Spaltenliste.', 1;
    END;

    DECLARE @TargetHasRows bit;
    SET @Sql = N'SELECT @HasRows = CONVERT(bit, CASE WHEN EXISTS (SELECT 1 FROM '
        + @TargetQuotedName
        + N') THEN 1 ELSE 0 END);';

    EXEC sys.sp_executesql
          @Sql
        , N'@HasRows bit OUTPUT'
        , @HasRows = @TargetHasRows OUTPUT;

    IF @Debug >= 2
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: TargetObjectId='
            + CONVERT(nvarchar(20), @TargetObjectId)
            + N', SourceObjectId='
            + CONVERT(nvarchar(20), @SourceObjectId)
            + N', SourceIsLocal='
            + CONVERT(nvarchar(1), @SourceIsLocal)
            + N', TargetHasRows='
            + CONVERT(nvarchar(1), @TargetHasRows)
            + N', SchemaMatches='
            + CONVERT(nvarchar(1), @SchemaMatches)
            + N'.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    IF @Debug >= 3 AND @SourceMetadataDebug IS NOT NULL
    BEGIN
        SET @DebugMessage = N'USP_PrepareResultTable: normalisierte Referenzmetadaten:'
            + NCHAR(10)
            + @SourceMetadataDebug;

        WHILE DATALENGTH(@DebugMessage) > 0
        BEGIN
            SET @DebugChunk = LEFT(@DebugMessage, 1800);
            RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
            SET @DebugMessage = SUBSTRING(@DebugMessage, 1801, 2147483647);
        END;
    END;

    /*
     * @KeepData = 1 darf bei abweichendem Schema niemals einen Teilumbau
     * auslösen. Der Fehler erfolgt deshalb vor Dependency-Prüfung, Datenlöschung
     * und Transaktionsbeginn und lässt die Zieltable vollständig unverändert.
     */
    IF @SchemaMatches = 0 AND @TargetHasRows = 1 AND @KeepData = 1
    BEGIN
        THROW 51025, N'@KeepData = 1 kann vorhandene Daten bei abweichendem Ziel- und Referenzschema nicht sicher erhalten.', 1;
    END;

    DECLARE
          @BlockerType sysname
        , @BlockerName sysname;

    IF @SchemaMatches = 0
    BEGIN
        /*
         * Der in-place-Algorithmus ersetzt alle alten Spalten. Daher blockiert
         * jedes Objekt, das an einer dieser Spalten hängt. Es wird bewusst
         * nichts automatisch gedroppt oder nachgebaut.
         */
        SELECT TOP (1)
              @BlockerType = d.BlockerType
            , @BlockerName = d.BlockerName
        FROM
        (
            SELECT
                  10 AS PriorityValue
                , CONVERT(sysname, N'INDEX') AS BlockerType
                , i.name AS BlockerName
            FROM tempdb.sys.indexes AS i
            WHERE i.object_id = @TargetObjectId
              AND i.index_id > 0
              AND i.is_hypothetical = 0

            UNION ALL

            SELECT
                  20
                , CONVERT(sysname, N'DEFAULT_CONSTRAINT')
                , dc.name
            FROM tempdb.sys.default_constraints AS dc
            WHERE dc.parent_object_id = @TargetObjectId

            UNION ALL

            SELECT
                  30
                , CONVERT(sysname, N'CHECK_CONSTRAINT')
                , cc.name
            FROM tempdb.sys.check_constraints AS cc
            WHERE cc.parent_object_id = @TargetObjectId

            UNION ALL

            SELECT
                  40
                , CONVERT(sysname, N'FOREIGN_KEY')
                , fk.name
            FROM tempdb.sys.foreign_keys AS fk
            WHERE fk.parent_object_id = @TargetObjectId
               OR fk.referenced_object_id = @TargetObjectId

            UNION ALL

            SELECT
                  50
                , CONVERT(sysname, N'COMPUTED_COLUMN')
                , c.name
            FROM tempdb.sys.columns AS c
            WHERE c.object_id = @TargetObjectId
              AND c.is_computed = 1

            UNION ALL

            SELECT
                  60
                , CONVERT(sysname, N'BOUND_DEFAULT_OR_RULE')
                , c.name
            FROM tempdb.sys.columns AS c
            WHERE c.object_id = @TargetObjectId
              AND (c.default_object_id <> 0 OR c.rule_object_id <> 0)

            UNION ALL

            SELECT
                  70
                , CONVERT(sysname, N'TRIGGER')
                , tr.name
            FROM tempdb.sys.triggers AS tr
            WHERE tr.parent_id = @TargetObjectId

            UNION ALL

            SELECT
                  80
                , CONVERT(sysname, N'USER_STATISTICS')
                , st.name
            FROM tempdb.sys.stats AS st
            WHERE st.object_id = @TargetObjectId
              AND st.user_created = 1
        ) AS d
        ORDER BY
              d.PriorityValue
            , d.BlockerName COLLATE Latin1_General_100_BIN2;

        IF @BlockerType IS NOT NULL
        BEGIN
            SET @ErrorMessage = N'Der Schemaumbau von '
                + @TargetQuotedName
                + N' wird durch '
                + @BlockerType
                + N' '
                + COALESCE(QUOTENAME(@BlockerName), N'<unbenannt>')
                + N' blockiert. Das abhängige Objekt muss der Aufrufer vor dem erneuten Aufruf kontrolliert entfernen.';
            SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
            THROW 51026, @ErrorMessage, 1;
        END;
    END;

    DECLARE @MutationRequired bit =
        CONVERT
        (
            bit,
            CASE
                WHEN @SchemaMatches = 0 THEN 1
                WHEN @TargetHasRows = 1 AND @KeepData = 0 THEN 1
                ELSE 0
            END
        );

    IF @MutationRequired = 0
    BEGIN
        IF @Debug >= 1
        BEGIN
            SET @DebugChunk = N'USP_PrepareResultTable: Schema und Datenzustand erfordern keine Mutation.';
            RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
        END;

        RETURN 0;
    END;

    IF XACT_STATE() = -1
    BEGIN
        THROW 51028, N'Der aktuelle uncommittable Transaktionszustand erlaubt keine kontrollierte ResultTable-Mutation.', 1;
    END;

    DECLARE
          @InvocationToken       varchar(32) = REPLACE(CONVERT(varchar(36), NEWID()), '-', '')
        , @AnchorColumnName      sysname
        , @SavepointName         varchar(32)
        , @StartedTransaction    bit = 0
        , @ClearMethod           varchar(16)
        , @DropBeforeAnchorSql   nvarchar(max)
        , @AddAnchorSql          nvarchar(max)
        , @DropOldColumnsSql     nvarchar(max)
        , @AddNewColumnsSql      nvarchar(max)
        , @DropAnchorSql         nvarchar(max)
        , @AddAfterAnchorSql     nvarchar(max)
        , @TruncateSql           nvarchar(max);

    SET @AnchorColumnName = CONVERT(sysname, N'tbx_anchor_' + @InvocationToken);

    WHILE EXISTS
    (
        SELECT 1
        FROM tempdb.sys.columns AS c
        WHERE c.object_id = @TargetObjectId
          AND c.name COLLATE Latin1_General_100_BIN2
                  = @AnchorColumnName COLLATE Latin1_General_100_BIN2
    )
    BEGIN
        SET @InvocationToken = REPLACE(CONVERT(varchar(36), NEWID()), '-', '');
        SET @AnchorColumnName = CONVERT(sysname, N'tbx_anchor_' + @InvocationToken);
    END;

    SET @SavepointName = CONVERT(varchar(32), 'tbx_rtbl_' + LEFT(@InvocationToken, 23));
    IF @DropColumnBeforeAnchor IS NOT NULL
    BEGIN
        SET @DropBeforeAnchorSql = N'ALTER TABLE '
            + @TargetQuotedName
            + N' DROP COLUMN '
            + @DropColumnBeforeAnchor
            + N';';
    END;

    SET @AddAnchorSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' ADD '
        + QUOTENAME(@AnchorColumnName)
        + N' bit NULL;';
    SET @DropOldColumnsSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' DROP COLUMN '
        + @DropColumnsList
        + N';';
    SET @AddNewColumnsSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' ADD '
        + @AddColumnsList
        + N';';
    SET @DropAnchorSql = N'ALTER TABLE '
        + @TargetQuotedName
        + N' DROP COLUMN '
        + QUOTENAME(@AnchorColumnName)
        + N';';
    IF @AddColumnAfterAnchor IS NOT NULL
    BEGIN
        SET @AddAfterAnchorSql = N'ALTER TABLE '
            + @TargetQuotedName
            + N' ADD '
            + @AddColumnAfterAnchor
            + N';';
    END;

    SET @TruncateSql = N'TRUNCATE TABLE ' + @TargetQuotedName + N';';

    IF @Debug >= 3
    BEGIN
        SET @DebugMessage = N'USP_PrepareResultTable: geplantes DDL:'
            + NCHAR(10)
            + CASE
                  WHEN @SchemaMatches = 0
                      THEN COALESCE(@DropBeforeAnchorSql + NCHAR(10), N'')
                           + @AddAnchorSql + NCHAR(10)
                           + @DropOldColumnsSql + NCHAR(10)
                           + @AddNewColumnsSql + NCHAR(10)
                           + @DropAnchorSql
                           + COALESCE(NCHAR(10) + @AddAfterAnchorSql, N'')
                  WHEN @TargetHasRows = 1 AND @KeepData = 0
                      THEN @TruncateSql
                  ELSE N'<keine Mutation>'
              END;

        WHILE DATALENGTH(@DebugMessage) > 0
        BEGIN
            SET @DebugChunk = LEFT(@DebugMessage, 1800);
            RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
            SET @DebugMessage = SUBSTRING(@DebugMessage, 1801, 2147483647);
        END;
    END;

    /*
     * Erst ab hier beginnt die Mutation. Eine vorhandene Caller-Transaktion
     * erhält ausschließlich einen Invocation-spezifischen Savepoint. Die
     * Procedure committed oder rollt niemals die vollständige Caller-
     * Transaktion zurück.
     */
    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @StartedTransaction = 1;
        END;
        ELSE
        BEGIN
            SAVE TRANSACTION @SavepointName;
        END;

        IF @TargetHasRows = 1 AND @KeepData = 0
        BEGIN
            /*
             * Eine lokale ResultTable muss truncatable sein. Verhindert die
             * Engine TRUNCATE dennoch, liegt ein nicht unterstützter Zustand
             * vor. Der Originalfehler wird nach dem Rollback unverändert
             * weitergegeben; ein DELETE-Fallback ist ausdrücklich unzulässig.
             */
            EXEC sys.sp_executesql @TruncateSql;
            SET @ClearMethod = 'TRUNCATE';
        END;

        IF @SchemaMatches = 0
        BEGIN
            /*
             * Bei exakt 1024 Ziel- oder Quellspalten wird der Umbau geteilt:
             * eine alte Spalte weicht vor der Anchor-Spalte beziehungsweise
             * die letzte neue Spalte folgt erst nach deren Entfernung. Dadurch
             * entstehen zu keinem Zeitpunkt mehr als 1024 Spalten.
             */
            IF @DropBeforeAnchorSql IS NOT NULL
            BEGIN
                EXEC sys.sp_executesql @DropBeforeAnchorSql;
            END;

            EXEC sys.sp_executesql @AddAnchorSql;
            EXEC sys.sp_executesql @DropOldColumnsSql;
            EXEC sys.sp_executesql @AddNewColumnsSql;
            EXEC sys.sp_executesql @DropAnchorSql;

            IF @AddAfterAnchorSql IS NOT NULL
            BEGIN
                EXEC sys.sp_executesql @AddAfterAnchorSql;
            END;
        END;

        IF @StartedTransaction = 1
        BEGIN
            COMMIT TRANSACTION;
        END;
    END TRY
    BEGIN CATCH
        DECLARE
              @OriginalErrorNumber  int = ERROR_NUMBER()
            , @OriginalErrorMessage nvarchar(2048) = ERROR_MESSAGE();

        IF @StartedTransaction = 1 AND XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;
        ELSE IF @StartedTransaction = 0 AND XACT_STATE() = 1
        BEGIN
            BEGIN TRY
                ROLLBACK TRANSACTION @SavepointName;
            END TRY
            BEGIN CATCH
                SET @ErrorMessage = N'Der ResultTable-Fehler '
                    + CONVERT(nvarchar(20), @OriginalErrorNumber)
                    + N' konnte wegen Rollback-Fehler '
                    + CONVERT(nvarchar(20), ERROR_NUMBER())
                    + N' nicht kontrolliert zum Savepoint zurückgerollt werden. Ursprüngliche Meldung: '
                    + LEFT(@OriginalErrorMessage, 1200);
                SET @ErrorMessage = REPLACE(@ErrorMessage, N'%', N'%%');
                THROW 51028, @ErrorMessage, 1;
            END CATCH;
        END;

        /*
         * Bei XACT_STATE() = -1 wird kein unzulässiger Savepoint-Rollback
         * versucht. THROW ohne Argumente erhält den ursprünglichen Engine-
         * oder Modulfehler samt Nummer, State und Procedure-Kontext.
         */
        THROW;
    END CATCH;

    IF @Debug >= 2 AND @ClearMethod IS NOT NULL
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: vorhandene Daten wurden mit '
            + @ClearMethod
            + N' entfernt.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    IF @Debug >= 1
    BEGIN
        SET @DebugChunk = N'USP_PrepareResultTable: Vorbereitung erfolgreich abgeschlossen.';
        RAISERROR(N'%s', 10, 1, @DebugChunk) WITH NOWAIT;
    END;

    RETURN 0;
END;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    DECLARE
          @ProcedureId          int =
              OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable', N'P')
        , @DeploymentMode       nvarchar(16)
        , @TargetVersion        nvarchar(64)
        , @SourceHash           varchar(64)
        , @VersionPropertyName  sysname =
              N'Toolbelt.Module.toolbelt.core.result-table.Version'
        , @ModePropertyName     sysname =
              N'Toolbelt.Module.toolbelt.core.result-table.DeploymentMode';

    SELECT
          @DeploymentMode = DeploymentMode
        , @TargetVersion = TargetVersion
    FROM #tbx_ResultTableDeployState;

    IF XACT_STATE() <> 1 OR @ProcedureId IS NULL
    BEGIN
        THROW 51038, N'Die Framework-Procedure wurde nicht vollständig innerhalb der Deployment-Transaktion angelegt.', 1;
    END;

    SET @SourceHash = CONVERT
    (
          varchar(64)
        , HASHBYTES
          (
              N'SHA2_256'
            , CONVERT(varbinary(max), OBJECT_DEFINITION(@ProcedureId))
          )
        , 2
    );

    DECLARE @ObjectProperties TABLE
    (
          PropertyOrdinal int IDENTITY(1, 1) NOT NULL
        , PropertyName    sysname            NOT NULL
        , PropertyValue   nvarchar(4000)     NOT NULL
    );

    INSERT INTO @ObjectProperties (PropertyName, PropertyValue)
    VALUES
          (N'Toolbelt.ModuleId', N'toolbelt.core.result-table')
        , (N'Toolbelt.ModuleVersion', @TargetVersion)
        , (N'Toolbelt.ContractVersion', N'1.0')
        , (N'Toolbelt.DeploymentMode', @DeploymentMode)
        , (N'Toolbelt.SourceHash', CONVERT(nvarchar(4000), @SourceHash));

    DECLARE
          @PropertyOrdinal int = 1
        , @PropertyCount   int = (SELECT COUNT(*) FROM @ObjectProperties)
        , @PropertyName    sysname
        , @PropertyValue   nvarchar(4000);

    WHILE @PropertyOrdinal <= @PropertyCount
    BEGIN
        SELECT
              @PropertyName = PropertyName
            , @PropertyValue = PropertyValue
        FROM @ObjectProperties
        WHERE PropertyOrdinal = @PropertyOrdinal;

        IF EXISTS
           (
               SELECT 1
               FROM sys.extended_properties AS ep
               WHERE ep.class = 1
                 AND ep.major_id = @ProcedureId
                 AND ep.minor_id = 0
                 AND ep.name = @PropertyName
           )
        BEGIN
            EXEC sys.sp_updateextendedproperty
                  @name       = @PropertyName
                , @value      = @PropertyValue
                , @level0type = N'SCHEMA'
                , @level0name = N'toolbelt_core'
                , @level1type = N'PROCEDURE'
                , @level1name = N'USP_PrepareResultTable';
        END;
        ELSE
        BEGIN
            EXEC sys.sp_addextendedproperty
                  @name       = @PropertyName
                , @value      = @PropertyValue
                , @level0type = N'SCHEMA'
                , @level0name = N'toolbelt_core'
                , @level1type = N'PROCEDURE'
                , @level1name = N'USP_PrepareResultTable';
        END;

        SET @PropertyOrdinal += 1;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 0
             AND ep.major_id = 0
             AND ep.minor_id = 0
             AND ep.name = @VersionPropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 0
             AND ep.major_id = 0
             AND ep.minor_id = 0
             AND ep.name = @ModePropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.core.result-table
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.datetime.bucket
:On Error exit
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @VersionProperty sysname =
          N'Toolbelt.Module.toolbelt.datetime.bucket.Version'
    , @ModeProperty sysname =
          N'Toolbelt.Module.toolbelt.datetime.bucket.DeploymentMode'
    , @DeploymentMode nvarchar(16) = LOWER(N'local')
    , @InstalledVersion nvarchar(64)
    , @ProductMajorVersion int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'));

DECLARE @ReleaseObjects TABLE
(
      ObjectName sysname NOT NULL PRIMARY KEY
    , ObjectType char(2) NOT NULL
);

INSERT INTO @ReleaseObjects (ObjectName, ObjectType)
VALUES
      (N'TVF_DateBucketCore', 'TF')
    , (N'TVF_DateBucketDateTimeOffset', 'IF')
    , (N'TVF_DateBucketDateTime2', 'IF')
    , (N'TVF_DateBucketDate', 'IF');

IF @ProductMajorVersion NOT IN (15, 16, 17)
    THROW 51240, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 51241, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), value)
FROM sys.extended_properties
WHERE class = 0 AND major_id = 0 AND minor_id = 0
  AND name = @VersionProperty;

IF @InstalledVersion IS NOT NULL AND @InstalledVersion <> N'1.0.0'
    THROW 51243, N'Die installierte Modulversion ist diesem Deployment nicht bekannt.', 1;

IF @InstalledVersion IS NULL
   AND EXISTS
       (
           SELECT 1
           FROM @ReleaseObjects AS release_objects
           WHERE OBJECT_ID
                 (
                     N'toolbelt_datetime.' + release_objects.ObjectName
                 ) IS NOT NULL
       )
    THROW 51244, N'Ein Zielobjekt stammt nicht aus einem bekannten Toolbelt-Release.', 1;

IF SCHEMA_ID(N'toolbelt_datetime') IS NULL
   AND HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    THROW 51242, N'In der Installationsdatenbank fehlt CREATE SCHEMA.', 1;
IF SCHEMA_ID(N'toolbelt_datetime') IS NOT NULL
   AND HAS_PERMS_BY_NAME(N'toolbelt_datetime', N'SCHEMA', N'ALTER') <> 1
    THROW 51242, N'Für toolbelt_datetime fehlt ALTER.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
    THROW 51242, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;

BEGIN TRANSACTION;
DECLARE @LockResult int;
EXEC @LockResult = sys.sp_getapplock
      @Resource = N'toolbelt.deploy.toolbelt.datetime.bucket'
    , @LockMode = N'Exclusive'
    , @LockOwner = N'Transaction'
    , @LockTimeout = 0
    , @DbPrincipal = N'public';
IF @LockResult < 0
    THROW 51247, N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.', 1;

IF SCHEMA_ID(N'toolbelt_datetime') IS NULL
BEGIN
    EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_datetime];';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.Managed', @value = 1
        , @level0type = N'SCHEMA', @level0name = N'toolbelt_datetime';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.SchemaCategory', @value = N'datetime'
        , @level0type = N'SCHEMA', @level0name = N'toolbelt_datetime';
END;
GO
-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_DateBucketCore
-- Zweck:           Interner prozeduraler Bucket-Kern für datetimeoffset(7).
-- Parameter:       @DatePart varchar(16), @Width int,
--                  @Value datetimeoffset(7), @Origin datetimeoffset(7)
-- Resultset:       Value datetimeoffset(7), IsValid bit,
--                  ValidationCode tinyint
-- Dependencies:    keine Toolbelt-Module
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Sichtbarkeit:    intern; öffentliche Aufrufe verwenden die Inline-TVFs
-- Performance:     Einzeilige MSTVF als bewusste Optimizer-Grenze gegen 8632
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_DateBucketCore]
(
      @DatePart varchar(16)
    , @Width    int
    , @Value    datetimeoffset(7)
    , @Origin   datetimeoffset(7)
)
RETURNS @Result TABLE
(
      Value          datetimeoffset(7) NULL
    , IsValid       bit               NULL
    , ValidationCode tinyint          NULL
)
AS
BEGIN
    IF @DatePart IS NULL
       OR @Width IS NULL
       OR @Value IS NULL
       OR @Origin IS NULL
    BEGIN
        INSERT INTO @Result (Value, IsValid, ValidationCode)
        VALUES (NULL, NULL, NULL);
        RETURN;
    END;

    DECLARE @CanonicalDatePart varchar(16) =
        CASE
            WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                 IN ('year', 'yy', 'yyyy') THEN 'year'
            WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                 IN ('quarter', 'qq', 'q') THEN 'quarter'
            WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                 IN ('month', 'mm', 'm') THEN 'month'
            WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                 IN ('week', 'wk', 'ww') THEN 'week'
            WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                 IN
                 (
                     'dayofyear', 'dy', 'y',
                     'day', 'dd', 'd',
                     'weekday', 'dw', 'w'
                 ) THEN 'day'
            WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                 IN ('hour', 'hh') THEN 'hour'
            WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                 IN ('minute', 'mi', 'n') THEN 'minute'
            WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                 IN ('second', 'ss', 's') THEN 'second'
            WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                 IN ('millisecond', 'ms') THEN 'millisecond'
        END;

    IF @CanonicalDatePart IS NULL
    BEGIN
        INSERT INTO @Result (Value, IsValid, ValidationCode)
        VALUES (NULL, 0, 10);
        RETURN;
    END;

    IF @Width <= 0
    BEGIN
        INSERT INTO @Result (Value, IsValid, ValidationCode)
        VALUES (NULL, 0, 11);
        RETURN;
    END;

    DECLARE @Distance bigint =
        CASE @CanonicalDatePart
            WHEN 'year' THEN DATEDIFF_BIG(year, @Origin, @Value)
            WHEN 'quarter' THEN DATEDIFF_BIG(quarter, @Origin, @Value)
            WHEN 'month' THEN DATEDIFF_BIG(month, @Origin, @Value)
            WHEN 'week' THEN DATEDIFF_BIG(week, @Origin, @Value)
            WHEN 'day' THEN DATEDIFF_BIG(day, @Origin, @Value)
            WHEN 'hour' THEN DATEDIFF_BIG(hour, @Origin, @Value)
            WHEN 'minute' THEN DATEDIFF_BIG(minute, @Origin, @Value)
            WHEN 'second' THEN DATEDIFF_BIG(second, @Origin, @Value)
            WHEN 'millisecond'
                THEN DATEDIFF_BIG(millisecond, @Origin, @Value)
        END;
    DECLARE @BucketIndex bigint = @Distance / CONVERT(bigint, @Width);

    IF @Distance < 0 AND @Distance % @Width <> 0
        SET @BucketIndex -= 1;

    DECLARE
          @UnitOffset bigint = @BucketIndex * CONVERT(bigint, @Width)
        , @DayOffset int = 0
        , @Remainder int = 0
        , @Candidate datetimeoffset(7);

    IF @CanonicalDatePart = 'hour'
    BEGIN
        SET @DayOffset = CONVERT
        (
            int,
            @UnitOffset / 24
            - CASE
                  WHEN @UnitOffset < 0 AND @UnitOffset % 24 <> 0 THEN 1
                  ELSE 0
              END
        );
        SET @Remainder =
            CONVERT(int, @UnitOffset - CONVERT(bigint, @DayOffset) * 24);
        SET @Candidate =
            DATEADD(hour, @Remainder, DATEADD(day, @DayOffset, @Origin));
    END;
    ELSE IF @CanonicalDatePart = 'minute'
    BEGIN
        SET @DayOffset = CONVERT
        (
            int,
            @UnitOffset / 1440
            - CASE
                  WHEN @UnitOffset < 0 AND @UnitOffset % 1440 <> 0 THEN 1
                  ELSE 0
              END
        );
        SET @Remainder =
            CONVERT(int, @UnitOffset - CONVERT(bigint, @DayOffset) * 1440);
        SET @Candidate =
            DATEADD(minute, @Remainder, DATEADD(day, @DayOffset, @Origin));
    END;
    ELSE IF @CanonicalDatePart = 'second'
    BEGIN
        SET @DayOffset = CONVERT
        (
            int,
            @UnitOffset / 86400
            - CASE
                  WHEN @UnitOffset < 0 AND @UnitOffset % 86400 <> 0 THEN 1
                  ELSE 0
              END
        );
        SET @Remainder =
            CONVERT(int, @UnitOffset - CONVERT(bigint, @DayOffset) * 86400);
        SET @Candidate =
            DATEADD(second, @Remainder, DATEADD(day, @DayOffset, @Origin));
    END;
    ELSE IF @CanonicalDatePart = 'millisecond'
    BEGIN
        SET @DayOffset = CONVERT
        (
            int,
            @UnitOffset / 86400000
            - CASE
                  WHEN @UnitOffset < 0
                   AND @UnitOffset % 86400000 <> 0 THEN 1
                  ELSE 0
              END
        );
        SET @Remainder = CONVERT
        (
            int,
            @UnitOffset - CONVERT(bigint, @DayOffset) * 86400000
        );
        SET @Candidate =
            DATEADD(millisecond, @Remainder, DATEADD(day, @DayOffset, @Origin));
    END;
    ELSE
        SET @Candidate =
            CASE @CanonicalDatePart
                WHEN 'year'
                    THEN DATEADD(year, CONVERT(int, @UnitOffset), @Origin)
                WHEN 'quarter'
                    THEN DATEADD(quarter, CONVERT(int, @UnitOffset), @Origin)
                WHEN 'month'
                    THEN DATEADD(month, CONVERT(int, @UnitOffset), @Origin)
                WHEN 'week'
                    THEN DATEADD(week, CONVERT(int, @UnitOffset), @Origin)
                WHEN 'day'
                    THEN DATEADD(day, CONVERT(int, @UnitOffset), @Origin)
            END;

    IF @Candidate > @Value
        SET @Candidate =
            CASE @CanonicalDatePart
                WHEN 'year' THEN DATEADD(year, -@Width, @Candidate)
                WHEN 'quarter' THEN DATEADD(quarter, -@Width, @Candidate)
                WHEN 'month' THEN DATEADD(month, -@Width, @Candidate)
                WHEN 'week' THEN DATEADD(week, -@Width, @Candidate)
                WHEN 'day' THEN DATEADD(day, -@Width, @Candidate)
                WHEN 'hour' THEN DATEADD(hour, -@Width, @Candidate)
                WHEN 'minute' THEN DATEADD(minute, -@Width, @Candidate)
                WHEN 'second' THEN DATEADD(second, -@Width, @Candidate)
                WHEN 'millisecond'
                    THEN DATEADD(millisecond, -@Width, @Candidate)
            END;

    INSERT INTO @Result (Value, IsValid, ValidationCode)
    VALUES (@Candidate, 1, 0);
    RETURN;
END;
GO
-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_DateBucketDateTimeOffset
-- Zweck:           Portabler DATE_BUCKET-Vertrag für datetimeoffset(7).
-- Parameter:       @DatePart varchar(16), @Width int,
--                  @Value datetimeoffset(7),
--                  @Origin datetimeoffset(7) = 1900-01-01 +00:00
-- Resultset:       Value datetimeoffset(7), IsValid bit,
--                  ValidationCode tinyint
-- Dependencies:    interne TVF_DateBucketCore im selben Modul
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF vor einer einzeiligen internen Optimizer-Grenze
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_DateBucketDateTimeOffset]
(
      @DatePart varchar(16)
    , @Width    int
    , @Value    datetimeoffset(7)
    , @Origin   datetimeoffset(7) = '1900-01-01 00:00:00 +00:00'
)
RETURNS TABLE
AS
RETURN
(
    SELECT bucket.Value, bucket.IsValid, bucket.ValidationCode
    FROM toolbelt_datetime.TVF_DateBucketCore
         (@DatePart, @Width, @Value, @Origin) AS bucket
);
GO
-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_DateBucketDateTime2
-- Zweck:           Portabler DATE_BUCKET-Vertrag für datetime2(7).
-- Parameter:       @DatePart varchar(16), @Width int,
--                  @Value datetime2(7), @Origin datetime2(7) = 1900-01-01
-- Resultset:       Value datetime2(7), IsValid bit, ValidationCode tinyint
-- Dependencies:    interne TVF_DateBucketCore im selben Modul
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF vor einer einzeiligen internen Optimizer-Grenze
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_DateBucketDateTime2]
(
      @DatePart varchar(16)
    , @Width    int
    , @Value    datetime2(7)
    , @Origin   datetime2(7) = '19000101'
)
RETURNS TABLE
AS
RETURN
(
    SELECT
          Value = CONVERT(datetime2(7), bucket.Value)
        , bucket.IsValid
        , bucket.ValidationCode
    FROM toolbelt_datetime.TVF_DateBucketCore
         (
               @DatePart
             , @Width
             , CONVERT(datetimeoffset(7), @Value)
             , CONVERT(datetimeoffset(7), @Origin)
         ) AS bucket
);
GO
-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_DateBucketDate
-- Zweck:           Portabler DATE_BUCKET-Vertrag für date.
-- Parameter:       @DatePart varchar(16), @Width int,
--                  @Value date, @Origin date = 1900-01-01
-- Resultset:       Value date, IsValid bit, ValidationCode tinyint
-- Dependencies:    keine Toolbelt-Module
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF; eigener schlanker date-Ausdrucksbaum
-- Einschränkungen: Zeit-Dateparts sind für date ungültig.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_DateBucketDate]
(
      @DatePart varchar(16)
    , @Width    int
    , @Value    date
    , @Origin   date = '19000101'
)
RETURNS TABLE
AS
RETURN
(
    WITH Normalized AS
    (
        SELECT
              CanonicalDatePart =
                CASE
                    WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                         IN ('year', 'yy', 'yyyy') THEN 'year'
                    WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                         IN ('quarter', 'qq', 'q') THEN 'quarter'
                    WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                         IN ('month', 'mm', 'm') THEN 'month'
                    WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                         IN ('week', 'wk', 'ww') THEN 'week'
                    WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                         IN
                         (
                             'dayofyear', 'dy', 'y',
                             'day', 'dd', 'd',
                             'weekday', 'dw', 'w'
                         ) THEN 'day'
                END
            , IsTimeDatePart = CONVERT
              (
                  bit,
                  CASE
                      WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                           IN
                           (
                               'hour', 'hh',
                               'minute', 'mi', 'n',
                               'second', 'ss', 's',
                               'millisecond', 'ms'
                           )
                          THEN 1
                      ELSE 0
                  END
              )
    ),
    Distances AS
    (
        SELECT
              normalized.CanonicalDatePart
            , normalized.IsTimeDatePart
            , Distance = CONVERT
              (
                  bigint,
                  CASE normalized.CanonicalDatePart
                      WHEN 'year' THEN DATEDIFF_BIG(year, @Origin, @Value)
                      WHEN 'quarter'
                          THEN DATEDIFF_BIG(quarter, @Origin, @Value)
                      WHEN 'month' THEN DATEDIFF_BIG(month, @Origin, @Value)
                      WHEN 'week' THEN DATEDIFF_BIG(week, @Origin, @Value)
                      WHEN 'day' THEN DATEDIFF_BIG(day, @Origin, @Value)
                  END
              )
        FROM Normalized AS normalized
    ),
    BucketIndexes AS
    (
        SELECT
              distances.CanonicalDatePart
            , distances.IsTimeDatePart
            , BucketIndex =
                CASE
                    WHEN @Width > 0
                     AND distances.Distance < 0
                     AND distances.Distance % @Width <> 0
                        THEN distances.Distance / @Width - 1
                    WHEN @Width > 0 THEN distances.Distance / @Width
                END
        FROM Distances AS distances
    ),
    Candidates AS
    (
        SELECT
              indexes.CanonicalDatePart
            , indexes.IsTimeDatePart
            , Value = CONVERT
              (
                  date,
                  CASE indexes.CanonicalDatePart
                      WHEN 'year'
                          THEN DATEADD
                               (
                                   year,
                                   CONVERT(int, indexes.BucketIndex * @Width),
                                   @Origin
                               )
                      WHEN 'quarter'
                          THEN DATEADD
                               (
                                   quarter,
                                   CONVERT(int, indexes.BucketIndex * @Width),
                                   @Origin
                               )
                      WHEN 'month'
                          THEN DATEADD
                               (
                                   month,
                                   CONVERT(int, indexes.BucketIndex * @Width),
                                   @Origin
                               )
                      WHEN 'week'
                          THEN DATEADD
                               (
                                   week,
                                   CONVERT(int, indexes.BucketIndex * @Width),
                                   @Origin
                               )
                      WHEN 'day'
                          THEN DATEADD
                               (
                                   day,
                                   CONVERT(int, indexes.BucketIndex * @Width),
                                   @Origin
                               )
                  END
              )
        FROM BucketIndexes AS indexes
    ),
    Adjusted AS
    (
        SELECT
              candidates.CanonicalDatePart
            , candidates.IsTimeDatePart
            , Value = CONVERT
              (
                  date,
                  CASE
                      WHEN candidates.Value <= @Value THEN candidates.Value
                      WHEN candidates.CanonicalDatePart = 'year'
                          THEN DATEADD
                               (
                                   year,
                                   -CASE WHEN @Width > 0 THEN @Width ELSE 1 END,
                                   candidates.Value
                               )
                      WHEN candidates.CanonicalDatePart = 'quarter'
                          THEN DATEADD
                               (
                                   quarter,
                                   -CASE WHEN @Width > 0 THEN @Width ELSE 1 END,
                                   candidates.Value
                               )
                      WHEN candidates.CanonicalDatePart = 'month'
                          THEN DATEADD
                               (
                                   month,
                                   -CASE WHEN @Width > 0 THEN @Width ELSE 1 END,
                                   candidates.Value
                               )
                      WHEN candidates.CanonicalDatePart = 'week'
                          THEN DATEADD
                               (
                                   week,
                                   -CASE WHEN @Width > 0 THEN @Width ELSE 1 END,
                                   candidates.Value
                               )
                      WHEN candidates.CanonicalDatePart = 'day'
                          THEN DATEADD
                               (
                                   day,
                                   -CASE WHEN @Width > 0 THEN @Width ELSE 1 END,
                                   candidates.Value
                               )
                  END
              )
        FROM Candidates AS candidates
    )
    SELECT
          Value = CONVERT
          (
              date,
              CASE
                  WHEN @DatePart IS NULL
                    OR @Width IS NULL
                    OR @Value IS NULL
                    OR @Origin IS NULL
                    OR adjusted.CanonicalDatePart IS NULL
                    OR @Width <= 0
                      THEN NULL
                  ELSE adjusted.Value
              END
          )
        , IsValid = CONVERT
          (
              bit,
              CASE
                  WHEN @DatePart IS NULL
                    OR @Width IS NULL
                    OR @Value IS NULL
                    OR @Origin IS NULL
                      THEN NULL
                  WHEN adjusted.CanonicalDatePart IS NULL OR @Width <= 0 THEN 0
                  ELSE 1
              END
          )
        , ValidationCode = CONVERT
          (
              tinyint,
              CASE
                  WHEN @DatePart IS NULL
                    OR @Width IS NULL
                    OR @Value IS NULL
                    OR @Origin IS NULL
                      THEN NULL
                  WHEN adjusted.IsTimeDatePart = 1 THEN 12
                  WHEN adjusted.CanonicalDatePart IS NULL THEN 10
                  WHEN @Width <= 0 THEN 11
                  ELSE 0
              END
          )
    FROM Adjusted AS adjusted
);
GO
SET NOCOUNT ON;
BEGIN TRY
    DECLARE
          @VersionProperty sysname =
              N'Toolbelt.Module.toolbelt.datetime.bucket.Version'
        , @ModeProperty sysname =
              N'Toolbelt.Module.toolbelt.datetime.bucket.DeploymentMode';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties
           WHERE class = 0 AND major_id = 0 AND minor_id = 0
             AND name = @VersionProperty
       )
        EXEC sys.sp_updateextendedproperty
             @name = @VersionProperty, @value = N'1.0.0';
    ELSE
        EXEC sys.sp_addextendedproperty
             @name = @VersionProperty, @value = N'1.0.0';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties
           WHERE class = 0 AND major_id = 0 AND minor_id = 0
             AND name = @ModeProperty
       )
        EXEC sys.sp_updateextendedproperty
             @name = @ModeProperty, @value = N'local';
    ELSE
        EXEC sys.sp_addextendedproperty
             @name = @ModeProperty, @value = N'local';

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.datetime.bucket
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.datetime.calendar-difference
:On Error exit
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE
      @VersionProperty sysname = N'Toolbelt.Module.toolbelt.datetime.calendar-difference.Version'
    , @ModeProperty sysname = N'Toolbelt.Module.toolbelt.datetime.calendar-difference.DeploymentMode'
    , @DeploymentMode nvarchar(16) = LOWER(N'local')
    , @InstalledVersion nvarchar(64)
    , @ProductMajorVersion int = TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'));
IF @ProductMajorVersion NOT IN (15,16,17) THROW 51200, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
IF @DeploymentMode NOT IN (N'local',N'central') THROW 51201, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;
SELECT @InstalledVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty;
IF @InstalledVersion IS NOT NULL AND @InstalledVersion<>N'1.0.0' THROW 51203, N'Die installierte Modulversion ist diesem Deployment nicht bekannt.', 1;
IF @InstalledVersion IS NULL AND OBJECT_ID(N'toolbelt_datetime.TVF_CalendarDifference') IS NOT NULL THROW 51204, N'Das Zielobjekt stammt nicht aus einem bekannten Toolbelt-Release.', 1;
IF SCHEMA_ID(N'toolbelt_datetime') IS NOT NULL AND HAS_PERMS_BY_NAME(N'toolbelt_datetime',N'SCHEMA',N'ALTER')<>1 THROW 51202, N'Für toolbelt_datetime fehlt ALTER.', 1;
IF SCHEMA_ID(N'toolbelt_datetime') IS NULL AND HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE SCHEMA')<>1 THROW 51202, N'In der Installationsdatenbank fehlt CREATE SCHEMA.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE FUNCTION')<>1 THROW 51202, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;
BEGIN TRANSACTION;
DECLARE @LockResult int;
EXEC @LockResult=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.datetime.calendar-difference',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
IF @LockResult<0 THROW 51207, N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.', 1;
IF SCHEMA_ID(N'toolbelt_datetime') IS NULL
BEGIN
 EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_datetime];';
 EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_datetime';
 EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'datetime',@level0type=N'SCHEMA',@level0name=N'toolbelt_datetime';
END;
GO
-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_CalendarDifference
-- Zweck:           Zerlegt einen Datumsabstand in vollständige Kalenderjahre,
--                  -monate und Resttage.
-- Parameter:       @StartDate date, @EndDate date
-- Resultset:       Sign smallint, Years int, Months int, Days int
-- Dependencies:    keine Toolbelt-Module
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF; geeignet für CROSS APPLY
-- Collation:       nicht anwendbar
-- Einschränkungen: Anniversary-Regel klammert nicht vorhandene Monatstage an
--                  den letzten Tag des Zielmonats.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_CalendarDifference]
(
      @StartDate date
    , @EndDate   date
)
RETURNS TABLE
AS
RETURN
(
    /* DATEADD klammert nicht vorhandene Monatstage an das Monatsende. */
    WITH OrderedDates AS
    (
        SELECT
              Sign = CONVERT(smallint, CASE
                  WHEN @StartDate IS NULL OR @EndDate IS NULL THEN NULL
                  WHEN @StartDate < @EndDate THEN 1
                  WHEN @StartDate > @EndDate THEN -1 ELSE 0 END)
            , EarlierDate = CASE WHEN @StartDate <= @EndDate THEN @StartDate ELSE @EndDate END
            , LaterDate = CASE WHEN @StartDate <= @EndDate THEN @EndDate ELSE @StartDate END
    ),
    Years AS
    (
        SELECT
              ordered.Sign, ordered.EarlierDate, ordered.LaterDate
            , Years = CASE
                WHEN DATEADD(year, DATEDIFF(year, ordered.EarlierDate, ordered.LaterDate), ordered.EarlierDate) > ordered.LaterDate
                    THEN DATEDIFF(year, ordered.EarlierDate, ordered.LaterDate) - 1
                ELSE DATEDIFF(year, ordered.EarlierDate, ordered.LaterDate) END
        FROM OrderedDates AS ordered
    ),
    Months AS
    (
        SELECT
              years.Sign, years.Years, years.LaterDate
            , YearAnchor = DATEADD(year, years.Years, years.EarlierDate)
        FROM Years AS years
    ),
    Resolved AS
    (
        SELECT
              months.Sign, months.Years, months.YearAnchor, months.LaterDate
            , Months = CASE
                WHEN DATEADD(month, DATEDIFF(month, months.YearAnchor, months.LaterDate), months.YearAnchor) > months.LaterDate
                    THEN DATEDIFF(month, months.YearAnchor, months.LaterDate) - 1
                ELSE DATEDIFF(month, months.YearAnchor, months.LaterDate) END
        FROM Months AS months
    )
    SELECT
          resolved.Sign, resolved.Years, resolved.Months
        , Days = DATEDIFF(day, DATEADD(month, resolved.Months, resolved.YearAnchor), resolved.LaterDate)
    FROM Resolved AS resolved
);
GO
SET NOCOUNT ON;
BEGIN TRY
 DECLARE @VersionProperty sysname=N'Toolbelt.Module.toolbelt.datetime.calendar-difference.Version',@ModeProperty sysname=N'Toolbelt.Module.toolbelt.datetime.calendar-difference.DeploymentMode';
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty) EXEC sys.sp_updateextendedproperty @name=@VersionProperty,@value=N'1.0.0'; ELSE EXEC sys.sp_addextendedproperty @name=@VersionProperty,@value=N'1.0.0';
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@ModeProperty) EXEC sys.sp_updateextendedproperty @name=@ModeProperty,@value=N'local'; ELSE EXEC sys.sp_addextendedproperty @name=@ModeProperty,@value=N'local';
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.datetime.calendar-difference
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.datetime.truncate
:On Error exit
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @VersionProperty sysname =
          N'Toolbelt.Module.toolbelt.datetime.truncate.Version'
    , @ModeProperty sysname =
          N'Toolbelt.Module.toolbelt.datetime.truncate.DeploymentMode'
    , @DeploymentMode nvarchar(16) = LOWER(N'local')
    , @InstalledVersion nvarchar(64)
    , @ProductMajorVersion int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'));

DECLARE @ReleaseObjects TABLE
(
      ObjectName sysname NOT NULL PRIMARY KEY
    , ObjectType char(2) NOT NULL
);

INSERT INTO @ReleaseObjects (ObjectName, ObjectType)
VALUES
      (N'TVF_TruncateDateTimeOffset', 'IF')
    , (N'TVF_TruncateDateTime2', 'IF')
    , (N'TVF_TruncateDate', 'IF');

IF @ProductMajorVersion NOT IN (15, 16, 17)
    THROW 51230, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 51231, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), value)
FROM sys.extended_properties
WHERE class = 0 AND major_id = 0 AND minor_id = 0
  AND name = @VersionProperty;

IF @InstalledVersion IS NOT NULL AND @InstalledVersion <> N'1.0.0'
    THROW 51233, N'Die installierte Modulversion ist diesem Deployment nicht bekannt.', 1;

IF @InstalledVersion IS NULL
   AND EXISTS
       (
           SELECT 1
           FROM @ReleaseObjects AS release_objects
           WHERE OBJECT_ID
                 (
                     N'toolbelt_datetime.' + release_objects.ObjectName
                 ) IS NOT NULL
       )
    THROW 51234, N'Ein Zielobjekt stammt nicht aus einem bekannten Toolbelt-Release.', 1;

IF SCHEMA_ID(N'toolbelt_datetime') IS NULL
   AND HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    THROW 51232, N'In der Installationsdatenbank fehlt CREATE SCHEMA.', 1;
IF SCHEMA_ID(N'toolbelt_datetime') IS NOT NULL
   AND HAS_PERMS_BY_NAME(N'toolbelt_datetime', N'SCHEMA', N'ALTER') <> 1
    THROW 51232, N'Für toolbelt_datetime fehlt ALTER.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
    THROW 51232, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;

BEGIN TRANSACTION;
DECLARE @LockResult int;
EXEC @LockResult = sys.sp_getapplock
      @Resource = N'toolbelt.deploy.toolbelt.datetime.truncate'
    , @LockMode = N'Exclusive'
    , @LockOwner = N'Transaction'
    , @LockTimeout = 0
    , @DbPrincipal = N'public';
IF @LockResult < 0
    THROW 51237, N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.', 1;

IF SCHEMA_ID(N'toolbelt_datetime') IS NULL
BEGIN
    EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_datetime];';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.Managed', @value = 1
        , @level0type = N'SCHEMA', @level0name = N'toolbelt_datetime';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.SchemaCategory', @value = N'datetime'
        , @level0type = N'SCHEMA', @level0name = N'toolbelt_datetime';
END;
GO
-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_TruncateDateTimeOffset
-- Zweck:           Portabler DATETRUNC-Kern für datetimeoffset(7).
-- Parameter:       @DatePart varchar(16), @Value datetimeoffset(7)
-- Resultset:       Value datetimeoffset(7), IsValid bit,
--                  ValidationCode tinyint
-- Dependencies:    keine Toolbelt-Module
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF; geeignet für CROSS APPLY und OUTER APPLY
-- Collation:       Datepart wird als ASCII-Schlüssel binär verglichen.
-- Einschränkungen: Fester Rückgabetyp datetimeoffset(7); ungültige
--                  Parameter werden relational statt per THROW ausgewiesen.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_TruncateDateTimeOffset]
(
      @DatePart varchar(16)
    , @Value    datetimeoffset(7)
)
RETURNS TABLE
AS
RETURN
(
    WITH Normalized AS
    (
        SELECT CanonicalDatePart =
            CASE
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                     IN ('year', 'yy', 'yyyy') THEN 'year'
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                     IN ('quarter', 'qq', 'q') THEN 'quarter'
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                     IN ('month', 'mm', 'm') THEN 'month'
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                     IN ('dayofyear', 'dy', 'y', 'day', 'dd', 'd') THEN 'day'
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                     IN ('week', 'wk', 'ww') THEN 'week'
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                     IN ('iso_week', 'isowk', 'isoww') THEN 'iso_week'
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                     IN ('hour', 'hh') THEN 'hour'
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                     IN ('minute', 'mi', 'n') THEN 'minute'
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                     IN ('second', 'ss', 's') THEN 'second'
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                     IN ('millisecond', 'ms') THEN 'millisecond'
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2
                     IN ('microsecond', 'mcs') THEN 'microsecond'
            END
    ),
    Parts AS
    (
        SELECT
              normalized.CanonicalDatePart
            , LocalDate = CONVERT(date, @Value)
            , OffsetMinutes = DATEPART(tzoffset, @Value)
            , WeekOffset = DATEPART(weekday, CONVERT(date, @Value)) - 1
            , IsoWeekOffset =
                (
                    (
                        DATEDIFF
                        (
                              day
                            , CONVERT(date, '19000101', 112)
                            , CONVERT(date, @Value)
                        ) % 7
                    ) + 7
                ) % 7
        FROM Normalized AS normalized
    ),
    Validated AS
    (
        SELECT
              parts.*
            , HasWeekUnderflow = CONVERT
              (
                  bit,
                  CASE
                      WHEN parts.CanonicalDatePart = 'week'
                       AND parts.WeekOffset >
                           DATEDIFF
                           (
                                 day
                               , CONVERT(date, '00010101', 112)
                               , parts.LocalDate
                           )
                          THEN 1
                      ELSE 0
                  END
              )
        FROM Parts AS parts
    ),
    TruncatedParts AS
    (
        SELECT
              validated.CanonicalDatePart
            , validated.HasWeekUnderflow
            , TruncatedDate =
                CASE validated.CanonicalDatePart
                    WHEN 'year'
                        THEN DATEFROMPARTS(YEAR(validated.LocalDate), 1, 1)
                    WHEN 'quarter'
                        THEN DATEFROMPARTS
                             (
                                   YEAR(validated.LocalDate)
                                 , ((MONTH(validated.LocalDate) - 1) / 3) * 3 + 1
                                 , 1
                             )
                    WHEN 'month'
                        THEN DATEFROMPARTS
                             (
                                   YEAR(validated.LocalDate)
                                 , MONTH(validated.LocalDate)
                                 , 1
                             )
                    WHEN 'week'
                        THEN DATEADD
                             (
                                   day
                                 , -CASE
                                       WHEN validated.HasWeekUnderflow = 1
                                           THEN 0
                                       ELSE validated.WeekOffset
                                    END
                                 , validated.LocalDate
                             )
                    WHEN 'iso_week'
                        THEN DATEADD
                             (
                                   day
                                 , -validated.IsoWeekOffset
                                 , validated.LocalDate
                             )
                    ELSE validated.LocalDate
                  END
            , TruncatedHour =
                CASE
                    WHEN validated.CanonicalDatePart IN
                         (
                             'hour', 'minute', 'second',
                             'millisecond', 'microsecond'
                         )
                        THEN DATEPART(hour, @Value)
                    ELSE 0
                END
            , TruncatedMinute =
                CASE
                    WHEN validated.CanonicalDatePart IN
                         ('minute', 'second', 'millisecond', 'microsecond')
                        THEN DATEPART(minute, @Value)
                    ELSE 0
                END
            , TruncatedSecond =
                CASE
                    WHEN validated.CanonicalDatePart IN
                         ('second', 'millisecond', 'microsecond')
                        THEN DATEPART(second, @Value)
                    ELSE 0
                END
            , TruncatedFraction =
                CASE validated.CanonicalDatePart
                    WHEN 'millisecond'
                        THEN (DATEPART(nanosecond, @Value) / 1000000) * 10000
                    WHEN 'microsecond'
                        THEN (DATEPART(nanosecond, @Value) / 1000) * 10
                    ELSE 0
                END
            , OffsetHour = validated.OffsetMinutes / 60
            , OffsetMinute = validated.OffsetMinutes % 60
        FROM Validated AS validated
    )
    SELECT
          Value = CONVERT
          (
              datetimeoffset(7),
              CASE
                  WHEN @Value IS NULL
                    OR @DatePart IS NULL
                    OR truncated.CanonicalDatePart IS NULL
                    OR truncated.HasWeekUnderflow = 1
                      THEN NULL
                  ELSE DATETIMEOFFSETFROMPARTS
                       (
                             YEAR(truncated.TruncatedDate)
                           , MONTH(truncated.TruncatedDate)
                           , DAY(truncated.TruncatedDate)
                           , truncated.TruncatedHour
                           , truncated.TruncatedMinute
                           , truncated.TruncatedSecond
                           , truncated.TruncatedFraction
                           , truncated.OffsetHour
                           , truncated.OffsetMinute
                           , 7
                       )
              END
          )
        , IsValid = CONVERT
          (
              bit,
              CASE
                  WHEN @Value IS NULL OR @DatePart IS NULL THEN NULL
                  WHEN truncated.CanonicalDatePart IS NULL
                    OR truncated.HasWeekUnderflow = 1 THEN 0
                  ELSE 1
              END
          )
        , ValidationCode = CONVERT
          (
              tinyint,
              CASE
                  WHEN @Value IS NULL OR @DatePart IS NULL THEN NULL
                  WHEN truncated.CanonicalDatePart IS NULL THEN 10
                  WHEN truncated.HasWeekUnderflow = 1 THEN 12
                  ELSE 0
              END
          )
    FROM TruncatedParts AS truncated
);
GO
-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_TruncateDateTime2
-- Zweck:           Portabler DATETRUNC-Vertrag für datetime2(7).
-- Parameter:       @DatePart varchar(16), @Value datetime2(7)
-- Resultset:       Value datetime2(7), IsValid bit, ValidationCode tinyint
-- Dependencies:    TVF_TruncateDateTimeOffset im selben Modul
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF; dünner relationaler Typ-Wrapper
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_TruncateDateTime2]
(
      @DatePart varchar(16)
    , @Value    datetime2(7)
)
RETURNS TABLE
AS
RETURN
(
    SELECT
          Value = CONVERT(datetime2(7), truncated.Value)
        , truncated.IsValid
        , truncated.ValidationCode
    FROM toolbelt_datetime.TVF_TruncateDateTimeOffset
         (
               @DatePart
             , CONVERT(datetimeoffset(7), @Value)
         ) AS truncated
);
GO
-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_TruncateDate
-- Zweck:           Portabler DATETRUNC-Vertrag für date.
-- Parameter:       @DatePart varchar(16), @Value date
-- Resultset:       Value date, IsValid bit, ValidationCode tinyint
-- Dependencies:    TVF_TruncateDateTime2 im selben Modul
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Performance:     Inline TVF; dünner relationaler Typ-Wrapper
-- Einschränkungen: Zeit-Dateparts sind für date ungültig.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_TruncateDate]
(
      @DatePart varchar(16)
    , @Value    date
)
RETURNS TABLE
AS
RETURN
(
    WITH InputContract AS
    (
        SELECT IsDatePartSupported = CONVERT
        (
            bit,
            CASE
                WHEN LOWER(@DatePart) COLLATE Latin1_General_100_BIN2 IN
                     (
                         'year', 'yy', 'yyyy',
                         'quarter', 'qq', 'q',
                         'month', 'mm', 'm',
                         'dayofyear', 'dy', 'y',
                         'day', 'dd', 'd',
                         'week', 'wk', 'ww',
                         'iso_week', 'isowk', 'isoww'
                     )
                    THEN 1
                ELSE 0
            END
        )
    )
    SELECT
          Value = CONVERT
          (
              date,
              CASE
                  WHEN @Value IS NULL OR @DatePart IS NULL
                    OR input.IsDatePartSupported = 0
                      THEN NULL
                  ELSE truncated.Value
              END
          )
        , IsValid = CONVERT
          (
              bit,
              CASE
                  WHEN @Value IS NULL OR @DatePart IS NULL THEN NULL
                  WHEN input.IsDatePartSupported = 0 THEN 0
                  ELSE truncated.IsValid
              END
          )
        , ValidationCode = CONVERT
          (
              tinyint,
              CASE
                  WHEN @Value IS NULL OR @DatePart IS NULL THEN NULL
                  WHEN truncated.ValidationCode = 10 THEN 10
                  WHEN input.IsDatePartSupported = 0 THEN 11
                  ELSE truncated.ValidationCode
              END
          )
    FROM InputContract AS input
    CROSS APPLY toolbelt_datetime.TVF_TruncateDateTime2
                (
                      @DatePart
                    , CONVERT(datetime2(7), @Value)
                ) AS truncated
);
GO
SET NOCOUNT ON;
BEGIN TRY
    DECLARE
          @VersionProperty sysname =
              N'Toolbelt.Module.toolbelt.datetime.truncate.Version'
        , @ModeProperty sysname =
              N'Toolbelt.Module.toolbelt.datetime.truncate.DeploymentMode';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties
           WHERE class = 0 AND major_id = 0 AND minor_id = 0
             AND name = @VersionProperty
       )
        EXEC sys.sp_updateextendedproperty
             @name = @VersionProperty, @value = N'1.0.0';
    ELSE
        EXEC sys.sp_addextendedproperty
             @name = @VersionProperty, @value = N'1.0.0';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties
           WHERE class = 0 AND major_id = 0 AND minor_id = 0
             AND name = @ModeProperty
       )
        EXEC sys.sp_updateextendedproperty
             @name = @ModeProperty, @value = N'local';
    ELSE
        EXEC sys.sp_addextendedproperty
             @name = @ModeProperty, @value = N'local';

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.datetime.truncate
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.json.path-exists
:On Error exit
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @VersionProperty sysname =
          N'Toolbelt.Module.toolbelt.json.path-exists.Version'
    , @ModeProperty sysname =
          N'Toolbelt.Module.toolbelt.json.path-exists.DeploymentMode'
    , @DeploymentMode nvarchar(16) = LOWER(N'local')
    , @InstalledVersion nvarchar(64)
    , @ProductMajorVersion int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'));

IF @ProductMajorVersion NOT IN (15, 16, 17)
    THROW 51260,
          N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.',
          1;
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 51261,
          N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.',
          1;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), value)
FROM sys.extended_properties
WHERE class = 0
  AND major_id = 0
  AND minor_id = 0
  AND name = @VersionProperty;

IF @InstalledVersion IS NOT NULL AND @InstalledVersion <> N'1.0.0'
    THROW 51263,
          N'Die installierte Modulversion ist diesem Deployment nicht bekannt.',
          1;
IF @InstalledVersion IS NULL
   AND OBJECT_ID(N'toolbelt_json.TVF_JsonPathExists') IS NOT NULL
    THROW 51264,
          N'Ein Zielobjekt stammt nicht aus einem bekannten Toolbelt-Release.',
          1;
IF SCHEMA_ID(N'toolbelt_json') IS NOT NULL
   AND HAS_PERMS_BY_NAME(N'toolbelt_json', N'SCHEMA', N'ALTER') <> 1
    THROW 51262, N'Für toolbelt_json fehlt ALTER.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
    THROW 51262,
          N'In der Installationsdatenbank fehlt CREATE FUNCTION.',
          1;

IF OBJECT_ID(N'toolbelt_json.TVF_JsonPathExistsStatus') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_json.TVF_JsonPathExistsStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(256),value)=N'toolbelt.json.path-exists') THROW 51224,N'Neuer Security-Zielname ist frameworkfremd belegt.',1;
BEGIN TRANSACTION;

DECLARE @LockResult int;
EXEC @LockResult = sys.sp_getapplock
      @Resource = N'toolbelt.deploy.toolbelt.json.path-exists'
    , @LockMode = N'Exclusive'
    , @LockOwner = N'Transaction'
    , @LockTimeout = 0
    , @DbPrincipal = N'public';

IF @LockResult < 0
    THROW 51267,
          N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.',
          1;

IF SCHEMA_ID(N'toolbelt_json') IS NULL
BEGIN
    EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_json];';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.Managed'
        , @value = 1
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_json';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.SchemaCategory'
        , @value = N'json'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_json';
END;
GO

-- ============================================================================
-- Objekt:          toolbelt_json.TVF_JsonPathExistsStatus
-- Zweck:           Begrenzter kanonischer Statuskern; Legacy-Wertfassade unten.
-- Parameter:       @Json nvarchar(max), @Path nvarchar(max)
-- Resultset:       PathExists int, Status varchar(16)
-- Vertrag:         Documentation/TVF_JsonPathExistsStatus.md
-- Versionen:       SQL Server 2019/2022/2025; Windows/Linux
-- Rechte:          SELECT/REFERENCES; keine zusätzlichen Rechte oder Grants.
-- Performance:     MSTVF mit Vorabgrenzen; keine Inline-/Parallelitätszusage.
-- Grenzen:         Freigegebener Vertrag SECURITY_HARDENING_2026_10.md.
-- ============================================================================
CREATE OR ALTER FUNCTION [toolbelt_json].[TVF_JsonPathExistsStatus]
(
      @Json nvarchar(max)
    , @Path nvarchar(max)
)
RETURNS @Result TABLE
(
    PathExists int NULL, Status varchar(16) NOT NULL
)
AS
BEGIN
    IF @Json IS NULL OR @Path IS NULL
    BEGIN
        INSERT @Result (PathExists,Status) VALUES (NULL,'SQL_NULL');
        RETURN;
    END;

    IF DATALENGTH(@Json)>16777216
    BEGIN INSERT @Result VALUES(NULL,'LIMIT'); RETURN; END;
    DECLARE @WorkBytes bigint=0,@Charge bigint,@RawPosition int=1,
        @RawLength int=CONVERT(int,DATALENGTH(@Json)/2),@RawDepth int=0,
        @RawQuoted bit=0,@RawEscaped bit=0,@RawUnit nchar(1),@RootUnit nchar(1),
        @RawChunk nvarchar(4000),@RawChunkStart int=-4000;
    -- Vor nativer JSON-Prüfung lexikalische Tiefe samt Quoting/Escapes begrenzen.
    -- Chunkweises SUBSTRING vermeidet wiederholtes vollständiges LOB-Scanning.
    WHILE @RawPosition<=@RawLength
    BEGIN
        IF @RawPosition>@RawChunkStart+4000
        BEGIN SET @RawChunkStart=@RawPosition-1; SET @RawChunk=SUBSTRING(@Json COLLATE Latin1_General_100_BIN2,@RawPosition,4000); END;
        SET @RawUnit=SUBSTRING(@RawChunk COLLATE Latin1_General_100_BIN2,@RawPosition-@RawChunkStart,1);
        IF @RootUnit IS NULL AND UNICODE(@RawUnit) NOT IN(9,10,13,32) SET @RootUnit=@RawUnit;
        IF @RawQuoted=1
        BEGIN
            IF @RawEscaped=1 SET @RawEscaped=0;
            ELSE IF @RawUnit=N'\' SET @RawEscaped=1;
            ELSE IF @RawUnit=N'"' SET @RawQuoted=0;
        END
        ELSE IF @RawUnit=N'"' SET @RawQuoted=1;
        ELSE IF @RawUnit IN(N'[',N'{')
        BEGIN
            SET @RawDepth+=1;
            IF @RawDepth>128 BEGIN INSERT @Result VALUES(NULL,'LIMIT'); RETURN; END;
        END
        ELSE IF @RawUnit IN(N']',N'}') SET @RawDepth-=1;
        SET @RawPosition+=1;
    END;
    -- Der V1-Vertrag begrenzt den Pfad bewusst. Dadurch bleiben alle
    -- Parserpositionen int-basiert und der pro Aufruf materialisierte Zustand
    -- kontrollierbar.
    IF DATALENGTH(@Path) > 8000
    BEGIN
        INSERT @Result (PathExists,Status) VALUES (0,'INVALID');
        RETURN;
    END;

    DECLARE
          @PathText nvarchar(max) = LTRIM(RTRIM(@Path))
        , @PathLength int
        , @Position int = 1
        , @Start int
        , @Scan int
        , @Escaped bit
        , @Invalid bit = 0
        , @Token nvarchar(max)
        , @Literal nvarchar(max)
        , @Envelope nvarchar(max)
        , @SegmentType char(1)
        , @SegmentOrdinal int = 1
        , @SegmentCount int;

    -- lax und strict werden angenommen, beeinflussen den fehlerfreien
    -- Existenzvertrag aber nicht. JSON_PATH_EXISTS wirft selbst in strict
    -- mode keinen Fehler.
    IF LEFT(@PathText, 4) COLLATE Latin1_General_100_CI_AS = N'lax '
        SET @PathText = LTRIM(SUBSTRING(@PathText, 5, 4000));
    ELSE IF LEFT(@PathText, 7) COLLATE Latin1_General_100_CI_AS = N'strict '
        SET @PathText = LTRIM(SUBSTRING(@PathText, 8, 4000));

    SET @PathLength = CONVERT(int, LEN(@PathText));

    IF @PathLength = 0 OR SUBSTRING(@PathText, 1, 1) <> N'$'
        SET @Invalid = 1;
    ELSE
        SET @Position = 2;

    DECLARE @Segments TABLE
    (
          Ordinal int NOT NULL PRIMARY KEY
        , SegmentType char(1) NOT NULL
        , SegmentValue nvarchar(max) NULL
    );

    WHILE @Invalid = 0 AND @Position <= @PathLength
    BEGIN
        IF @SegmentOrdinal>128 BEGIN INSERT @Result VALUES(NULL,'LIMIT'); RETURN; END;
        IF SUBSTRING(@PathText, @Position, 1) = N'.'
        BEGIN
            SET @Position += 1;

            IF @Position > @PathLength
            BEGIN
                SET @Invalid = 1;
                BREAK;
            END;

            IF SUBSTRING(@PathText, @Position, 1) = N'"'
            BEGIN
                SET @Start = @Position;
                SET @Scan = @Position + 1;
                SET @Escaped = 0;

                WHILE @Scan <= @PathLength
                BEGIN
                    IF @Escaped = 1
                        SET @Escaped = 0;
                    ELSE IF SUBSTRING(@PathText, @Scan, 1) = N'\'
                        SET @Escaped = 1;
                    ELSE IF SUBSTRING(@PathText, @Scan, 1) = N'"'
                        BREAK;

                    SET @Scan += 1;
                END;

                IF @Scan > @PathLength
                BEGIN
                    SET @Invalid = 1;
                    BREAK;
                END;

                SET @Literal =
                    SUBSTRING(@PathText, @Start, @Scan - @Start + 1);
                SET @Envelope = N'[' + @Literal + N']';

                -- ISJSON schützt OPENJSON vor einem Providerfehler und prüft
                -- zugleich Escapes einschließlich \uXXXX.
                IF ISJSON(@Envelope) <> 1
                BEGIN
                    SET @Invalid = 1;
                    BREAK;
                END;

                SET @Charge=DATALENGTH(@Envelope);
                IF @Charge>67108864-@WorkBytes BEGIN INSERT @Result VALUES(NULL,'LIMIT'); RETURN; END;
                SET @WorkBytes+=@Charge;
                SELECT @Token = json_value.[value]
                FROM OPENJSON(@Envelope) AS json_value
                WHERE json_value.[key] = N'0'
                  AND json_value.[type] = 1;

                IF @Token IS NULL
                BEGIN
                    SET @Invalid = 1;
                    BREAK;
                END;

                INSERT @Segments (Ordinal, SegmentType, SegmentValue)
                VALUES (@SegmentOrdinal, 'P', @Token);

                SET @SegmentOrdinal += 1;
                SET @Position = @Scan + 1;
            END;
            ELSE
            BEGIN
                SET @Start = @Position;

                WHILE @Position <= @PathLength
                  AND SUBSTRING(@PathText, @Position, 1) NOT IN (N'.', N'[')
                    SET @Position += 1;

                SET @Token =
                    SUBSTRING(@PathText, @Start, @Position - @Start);

                -- Nicht quotierte V1-Schlüssel folgen der dokumentierten
                -- alphanumerischen SQL/JSON-Kurzform; weitere Zeichen und
                -- Unicode-Schlüssel werden in doppelten Anführungszeichen
                -- geschrieben.
                IF @Token = N''
                   OR PATINDEX
                      (
                          N'%[^0-9A-Za-z_]%',
                          @Token COLLATE Latin1_General_100_BIN2
                      ) > 0
                BEGIN
                    SET @Invalid = 1;
                    BREAK;
                END;

                INSERT @Segments (Ordinal, SegmentType, SegmentValue)
                VALUES (@SegmentOrdinal, 'P', @Token);

                SET @SegmentOrdinal += 1;
            END;
        END;
        ELSE IF SUBSTRING(@PathText, @Position, 1) = N'['
        BEGIN
            SET @Start = @Position + 1;
            SET @Scan = CHARINDEX(N']', @PathText, @Start);

            IF @Scan = 0
            BEGIN
                SET @Invalid = 1;
                BREAK;
            END;

            SET @Token = SUBSTRING(@PathText, @Start, @Scan - @Start);

            IF @Token = N'*'
                SET @SegmentType = 'W';
            ELSE IF @Token <> N''
                 AND PATINDEX
                     (
                         N'%[^0-9]%',
                         @Token COLLATE Latin1_General_100_BIN2
                     ) = 0
                 AND
                     (
                         @Token = N'0'
                         OR LEFT(@Token, 1) <> N'0'
                     )
                SET @SegmentType = 'I';
            ELSE
            BEGIN
                SET @Invalid = 1;
                BREAK;
            END;

            INSERT @Segments (Ordinal, SegmentType, SegmentValue)
            VALUES
            (
                  @SegmentOrdinal
                , @SegmentType
                , CASE WHEN @SegmentType = 'I' THEN @Token END
            );

            SET @SegmentOrdinal += 1;
            SET @Position = @Scan + 1;
        END;
        ELSE
        BEGIN
            SET @Invalid = 1;
            BREAK;
        END;
    END;

    IF @Invalid = 1
    BEGIN
        INSERT @Result (PathExists,Status) VALUES (0,'INVALID');
        RETURN;
    END;

    IF @RootUnit IN(N'[',N'{')
    BEGIN
        IF ISJSON(@Json)<>1 BEGIN INSERT @Result VALUES(0,'INVALID'); RETURN; END;
    END
    ELSE
    BEGIN
        SET @Envelope=CAST(N'[' AS nvarchar(max))+@Json+N']';
        IF ISJSON(@Envelope)<>1 BEGIN INSERT @Result VALUES(0,'INVALID'); RETURN; END;
    END;

    DECLARE @Frontier TABLE
    (
          JsonValue nvarchar(max) NULL
        , JsonType int NOT NULL
    );
    DECLARE @NextFrontier TABLE
    (
          JsonValue nvarchar(max) NULL
        , JsonType int NOT NULL
    );

    IF @RootUnit IN(N'[',N'{')
        INSERT @Frontier VALUES(@Json,CASE @RootUnit WHEN N'[' THEN 4 ELSE 5 END);
    ELSE
    BEGIN
        SET @Charge=DATALENGTH(@Envelope);
        IF @Charge>67108864-@WorkBytes BEGIN INSERT @Result VALUES(NULL,'LIMIT'); RETURN; END;
        SET @WorkBytes+=@Charge;
        INSERT @Frontier (JsonValue,JsonType)
        SELECT [value],[type] FROM OPENJSON(@Envelope);
    END;

    IF (SELECT COUNT_BIG(*) FROM @Frontier) <> 1
    BEGIN
        INSERT @Result (PathExists,Status) VALUES (0,'INVALID');
        RETURN;
    END;

    SET @SegmentCount = @SegmentOrdinal - 1;
    SET @SegmentOrdinal = 1;

    WHILE @SegmentOrdinal <= @SegmentCount
    BEGIN
        SELECT
              @SegmentType = segment.SegmentType
            , @Token = segment.SegmentValue
        FROM @Segments AS segment
        WHERE segment.Ordinal = @SegmentOrdinal;

        DELETE @NextFrontier;

        SELECT @Charge=COALESCE(SUM(CONVERT(bigint,CASE WHEN JsonType IN(4,5) THEN DATALENGTH(JsonValue) ELSE 4 END)),0) FROM @Frontier;
        IF @Charge>67108864-@WorkBytes BEGIN INSERT @Result VALUES(NULL,'LIMIT'); RETURN; END;
        SET @WorkBytes+=@Charge;
        INSERT @NextFrontier (JsonValue, JsonType)
        SELECT TOP (10001) child.[value], child.[type]
        FROM @Frontier AS parent
        CROSS APPLY OPENJSON
        (
            CASE
                WHEN parent.JsonType IN (4, 5) THEN parent.JsonValue
                ELSE N'{}'
            END
        ) AS child
        WHERE
            (
                @SegmentType = 'P'
                AND parent.JsonType = 5
                AND child.[key] COLLATE Latin1_General_100_BIN2 =
                    @Token COLLATE Latin1_General_100_BIN2
            )
            OR
            (
                @SegmentType = 'I'
                AND parent.JsonType = 4
                AND child.[key] COLLATE Latin1_General_100_BIN2 =
                    @Token COLLATE Latin1_General_100_BIN2
            )
            OR
            (
                @SegmentType = 'W'
                AND parent.JsonType = 4
            );

        IF (SELECT COUNT_BIG(*) FROM @NextFrontier)>10000
        BEGIN INSERT @Result VALUES(NULL,'LIMIT'); RETURN; END;
        DELETE @Frontier;

        INSERT @Frontier (JsonValue, JsonType)
        SELECT next_value.JsonValue, next_value.JsonType
        FROM @NextFrontier AS next_value;

        IF NOT EXISTS (SELECT 1 FROM @Frontier)
            BREAK;

        SET @SegmentOrdinal += 1;
    END;

    INSERT @Result (PathExists,Status)
    SELECT CASE WHEN EXISTS (SELECT 1 FROM @Frontier) THEN 1 ELSE 0 END,
           CASE WHEN EXISTS (SELECT 1 FROM @Frontier) THEN 'FOUND' ELSE 'MISSING' END;

    RETURN;
END;
GO

-- Legacy-Wertfassade: gleicher Inputvertrag; Limitabbildung siehe Objektseite.
-- Vertrag: Documentation/TVF_JsonPathExists.md
CREATE OR ALTER FUNCTION [toolbelt_json].[TVF_JsonPathExists](@Json nvarchar(max),@Path nvarchar(max))
RETURNS @Result TABLE(PathExists int NULL)
AS
BEGIN
    INSERT @Result SELECT PathExists FROM toolbelt_json.TVF_JsonPathExistsStatus(@Json,@Path);
    RETURN;
END;
GO

SET NOCOUNT ON;

BEGIN TRY
    DECLARE
          @VersionProperty sysname =
              N'Toolbelt.Module.toolbelt.json.path-exists.Version'
        , @ModeProperty sysname =
              N'Toolbelt.Module.toolbelt.json.path-exists.DeploymentMode';

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0
             AND major_id = 0
             AND minor_id = 0
             AND name = @VersionProperty
       )
        EXEC sys.sp_updateextendedproperty
              @name = @VersionProperty
            , @value = N'1.0.0';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = @VersionProperty
            , @value = N'1.0.0';

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0
             AND major_id = 0
             AND minor_id = 0
             AND name = @ModeProperty
       )
        EXEC sys.sp_updateextendedproperty
              @name = @ModeProperty
            , @value = N'local';
    ELSE
        EXEC sys.sp_addextendedproperty
              @name = @ModeProperty
            , @value = N'local';

   IF NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_json.TVF_JsonPathExistsStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId') EXEC sys.sp_addextendedproperty @name=N'Toolbelt.ModuleId',@value=N'toolbelt.json.path-exists',@level0type=N'SCHEMA',@level0name=N'toolbelt_json',@level1type=N'FUNCTION',@level1name=N'TVF_JsonPathExistsStatus';
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.json.path-exists
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.metadata.capability-catalog
:On Error exit
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE
      @VersionProperty sysname =
          N'Toolbelt.Module.toolbelt.metadata.capability-catalog.Version'
    , @ModeProperty sysname =
          N'Toolbelt.Module.toolbelt.metadata.capability-catalog.DeploymentMode'
    , @DeploymentMode nvarchar(16) = LOWER(N'local')
    , @InstalledVersion nvarchar(64)
    , @ProductMajorVersion int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'));

IF @ProductMajorVersion NOT IN (15, 16, 17)
    THROW 51280, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 51281, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), value)
FROM sys.extended_properties
WHERE class = 0 AND major_id = 0 AND minor_id = 0
  AND name = @VersionProperty;

IF @InstalledVersion IS NOT NULL AND @InstalledVersion <> N'1.0.0'
    THROW 51283, N'Die installierte Modulversion ist diesem Deployment nicht bekannt.', 1;

IF @InstalledVersion IS NULL
   AND OBJECT_ID(N'toolbelt_metadata.VW_ModuleCapabilities') IS NOT NULL
    THROW 51284, N'Das Zielobjekt stammt nicht aus einem bekannten Toolbelt-Release.', 1;

IF SCHEMA_ID(N'toolbelt_metadata') IS NULL
   AND HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    THROW 51282, N'In der Installationsdatenbank fehlt CREATE SCHEMA.', 1;
IF SCHEMA_ID(N'toolbelt_metadata') IS NOT NULL
   AND HAS_PERMS_BY_NAME(N'toolbelt_metadata', N'SCHEMA', N'ALTER') <> 1
    THROW 51282, N'Für toolbelt_metadata fehlt ALTER.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE VIEW') <> 1
    THROW 51282, N'In der Installationsdatenbank fehlt CREATE VIEW.', 1;

BEGIN TRANSACTION;
DECLARE @LockResult int;
EXEC @LockResult = sys.sp_getapplock
      @Resource = N'toolbelt.deploy.toolbelt.metadata.capability-catalog'
    , @LockMode = N'Exclusive'
    , @LockOwner = N'Transaction'
    , @LockTimeout = 0
    , @DbPrincipal = N'public';
IF @LockResult < 0
    THROW 51287, N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.', 1;

IF SCHEMA_ID(N'toolbelt_metadata') IS NULL
BEGIN
    EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_metadata];';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.Managed', @value = 1
        , @level0type = N'SCHEMA', @level0name = N'toolbelt_metadata';
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.SchemaCategory', @value = N'metadata'
        , @level0type = N'SCHEMA', @level0name = N'toolbelt_metadata';
END;
GO
-- ============================================================================
-- Objekt:          toolbelt_metadata.VW_ModuleCapabilities
-- Typ:             View
-- Zweck:           Projiziert installierte Toolbelt-Module und den Zustand
--                  ihrer Database-level Extended-Property-Marker.
-- Vertrag:         Documentation/Architecture/CAPABILITY_CATALOG_MODULE_DESIGN.md
-- Parameter:       Keine.
-- Resultset:       ModuleId, ModuleVersion, DeploymentMode, MetadataStatus.
-- Dependencies:    sys.extended_properties der aktuellen Datenbank.
-- Rechte:          SELECT auf der View; Metadata Visibility gilt unverändert.
-- Versionen:       SQL Server 2019, 2022 und 2025.
-- Plattformen:     Windows und Linux.
-- Fehlerverhalten: Read-only; Konvertierungsfehler werden als invalid sichtbar.
-- Performance:     Ein Scan der Database-level Extended Properties.
-- Einschränkungen: Keine Objektinventur, keine module.yaml-Projektion und keine
--                  persistente Registry. Nur stabile Release-Versionen.
-- ============================================================================

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER VIEW [toolbelt_metadata].[VW_ModuleCapabilities]
AS
WITH MarkerRows AS
(
    SELECT
          ModuleId = CONVERT
          (
              sysname,
              SUBSTRING
              (
                    ep.name
                  , LEN(N'Toolbelt.Module.') + 1
                  , LEN(ep.name)
                    - LEN(N'Toolbelt.Module.')
                    - CASE marker.MarkerKind
                          WHEN N'Version' THEN LEN(N'.Version')
                          ELSE LEN(N'.DeploymentMode')
                      END
              )
          )
        , marker.MarkerKind
        , MarkerValue = TRY_CONVERT(nvarchar(4000), ep.value)
        , MarkerBaseType =
              TRY_CONVERT(sysname, SQL_VARIANT_PROPERTY(ep.value, 'BaseType'))
        , MarkerNameIsCanonical = CONVERT
          (
              bit,
              CASE
                  WHEN LEFT(ep.name, LEN(N'Toolbelt.Module.'))
                           COLLATE Latin1_General_100_BIN2
                           = N'Toolbelt.Module.'
                   AND
                   (
                       (marker.MarkerKind = N'Version'
                        AND RIGHT(ep.name, LEN(N'.Version'))
                                COLLATE Latin1_General_100_BIN2 = N'.Version')
                       OR
                       (marker.MarkerKind = N'DeploymentMode'
                        AND RIGHT(ep.name, LEN(N'.DeploymentMode'))
                                COLLATE Latin1_General_100_BIN2
                                = N'.DeploymentMode')
                   )
                  THEN 1
                  ELSE 0
              END
          )
    FROM sys.extended_properties AS ep
    CROSS APPLY
    (
        VALUES
        (
            CASE
                WHEN RIGHT(ep.name, LEN(N'.Version'))
                         COLLATE Latin1_General_100_CI_AS = N'.Version'
                THEN N'Version'
                WHEN RIGHT(ep.name, LEN(N'.DeploymentMode'))
                         COLLATE Latin1_General_100_CI_AS
                         = N'.DeploymentMode'
                THEN N'DeploymentMode'
            END
        )
    ) AS marker (MarkerKind)
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND LEFT(ep.name, LEN(N'Toolbelt.Module.'))
              COLLATE Latin1_General_100_CI_AS = N'Toolbelt.Module.'
      AND marker.MarkerKind IS NOT NULL
),
AggregatedMarkers AS
(
    SELECT
          marker_rows.ModuleId
        , ModuleVersion = MAX
          (
              CASE marker_rows.MarkerKind
                  WHEN N'Version' THEN marker_rows.MarkerValue
              END
          )
        , DeploymentMode = MAX
          (
              CASE marker_rows.MarkerKind
                  WHEN N'DeploymentMode' THEN marker_rows.MarkerValue
              END
          )
        , VersionMarkerCount = SUM
          (
              CASE marker_rows.MarkerKind WHEN N'Version' THEN 1 ELSE 0 END
          )
        , ModeMarkerCount = SUM
          (
              CASE marker_rows.MarkerKind
                  WHEN N'DeploymentMode' THEN 1
                  ELSE 0
              END
          )
        , MarkerNamesAreCanonical =
              MIN(CONVERT(tinyint, marker_rows.MarkerNameIsCanonical))
        , VersionTypeIsText = MIN
          (
              CASE
                  WHEN marker_rows.MarkerKind <> N'Version' THEN 1
                  WHEN marker_rows.MarkerBaseType IN
                       (N'char', N'nchar', N'varchar', N'nvarchar') THEN 1
                  ELSE 0
              END
          )
        , ModeTypeIsText = MIN
          (
              CASE
                  WHEN marker_rows.MarkerKind <> N'DeploymentMode' THEN 1
                  WHEN marker_rows.MarkerBaseType IN
                       (N'char', N'nchar', N'varchar', N'nvarchar') THEN 1
                  ELSE 0
              END
          )
    FROM MarkerRows AS marker_rows
    GROUP BY marker_rows.ModuleId
),
ParsedVersions AS
(
    SELECT
          aggregated.ModuleId
        , aggregated.ModuleVersion
        , aggregated.DeploymentMode
        , aggregated.VersionMarkerCount
        , aggregated.ModeMarkerCount
        , aggregated.MarkerNamesAreCanonical
        , aggregated.VersionTypeIsText
        , aggregated.ModeTypeIsText
        , VersionMajor = PARSENAME(aggregated.ModuleVersion, 3)
        , VersionMinor = PARSENAME(aggregated.ModuleVersion, 2)
        , VersionPatch = PARSENAME(aggregated.ModuleVersion, 1)
        , VersionDotCount =
              LEN(aggregated.ModuleVersion)
              - LEN(REPLACE(aggregated.ModuleVersion, N'.', N''))
    FROM AggregatedMarkers AS aggregated
)
SELECT
      parsed.ModuleId
    , parsed.ModuleVersion
    , parsed.DeploymentMode
    , MetadataStatus = CONVERT
      (
          varchar(16),
          CASE
              WHEN parsed.VersionMarkerCount > 1
                OR parsed.ModeMarkerCount > 1
                OR parsed.MarkerNamesAreCanonical <> 1
                OR parsed.VersionTypeIsText <> 1
                OR parsed.ModeTypeIsText <> 1
                OR parsed.ModuleId IS NULL
                OR parsed.ModuleId COLLATE Latin1_General_100_BIN2
                       NOT LIKE N'toolbelt.%'
                OR REPLACE(parsed.ModuleId, N'-', N'')
                       COLLATE Latin1_General_100_BIN2
                       LIKE N'%[^a-z0-9.]%'
                OR parsed.ModuleId LIKE N'%..%'
                OR RIGHT(parsed.ModuleId, 1) IN (N'.', N'-')
                OR
                   (
                       parsed.VersionMarkerCount = 1
                       AND
                       (
                           parsed.ModuleVersion IS NULL
                           OR DATALENGTH(parsed.ModuleVersion) = 0
                           OR DATALENGTH(parsed.ModuleVersion) > 128
                           OR parsed.VersionDotCount <> 2
                           OR parsed.VersionMajor IS NULL
                           OR parsed.VersionMinor IS NULL
                           OR parsed.VersionPatch IS NULL
                           OR parsed.VersionMajor
                                  COLLATE Latin1_General_100_BIN2
                                  LIKE N'%[^0-9]%'
                           OR parsed.VersionMinor
                                  COLLATE Latin1_General_100_BIN2
                                  LIKE N'%[^0-9]%'
                           OR parsed.VersionPatch
                                  COLLATE Latin1_General_100_BIN2
                                  LIKE N'%[^0-9]%'
                           OR (LEN(parsed.VersionMajor) > 1
                               AND LEFT(parsed.VersionMajor, 1) = N'0')
                           OR (LEN(parsed.VersionMinor) > 1
                               AND LEFT(parsed.VersionMinor, 1) = N'0')
                           OR (LEN(parsed.VersionPatch) > 1
                               AND LEFT(parsed.VersionPatch, 1) = N'0')
                       )
                   )
                OR
                   (
                       parsed.ModeMarkerCount = 1
                       AND
                       (
                           parsed.DeploymentMode IS NULL
                           OR parsed.DeploymentMode
                                  COLLATE Latin1_General_100_BIN2
                                  NOT IN (N'local', N'central')
                       )
                   )
              THEN 'invalid'
              WHEN parsed.VersionMarkerCount = 0
                OR parsed.ModeMarkerCount = 0
              THEN 'incomplete'
              ELSE 'valid'
          END
      )
FROM ParsedVersions AS parsed;
GO
SET NOCOUNT ON;
BEGIN TRY
    DECLARE
          @VersionProperty sysname =
              N'Toolbelt.Module.toolbelt.metadata.capability-catalog.Version'
        , @ModeProperty sysname =
              N'Toolbelt.Module.toolbelt.metadata.capability-catalog.DeploymentMode';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties
           WHERE class = 0 AND major_id = 0 AND minor_id = 0
             AND name = @VersionProperty
       )
        EXEC sys.sp_updateextendedproperty
             @name = @VersionProperty, @value = N'1.0.0';
    ELSE
        EXEC sys.sp_addextendedproperty
             @name = @VersionProperty, @value = N'1.0.0';

    IF EXISTS
       (
           SELECT 1 FROM sys.extended_properties
           WHERE class = 0 AND major_id = 0 AND minor_id = 0
             AND name = @ModeProperty
       )
        EXEC sys.sp_updateextendedproperty
             @name = @ModeProperty, @value = N'local';
    ELSE
        EXEC sys.sp_addextendedproperty
             @name = @ModeProperty, @value = N'local';

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.metadata.capability-catalog
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.metadata.identifier
:On Error exit

-- ============================================================================
-- Zweck:     Erst-, Upgrade- und Wiederholungsdeployment
-- Modul:     toolbelt.metadata.identifier v1.0.0
-- Schema:    toolbelt_metadata
-- Erfordert: SQL Server 2019, 2022 oder 2025
-- Modus:     SQLCMD; Ausführung aus diesem Deployment-Verzeichnis
-- Parameter: DeploymentMode=local|central
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'tempdb..#tbx_IdentifierReleaseObjects', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_IdentifierReleaseObjects;
END;

IF OBJECT_ID(N'tempdb..#tbx_IdentifierDeployState', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_IdentifierDeployState;
END;

CREATE TABLE #tbx_IdentifierReleaseObjects
(
      ReleaseVersion nvarchar(64) NOT NULL
    , SchemaName     sysname      NOT NULL
    , ObjectName     sysname      NOT NULL
    , ObjectType     char(2)      NOT NULL
    , CONSTRAINT PK_tbx_IdentifierReleaseObjects
          PRIMARY KEY (ReleaseVersion, SchemaName, ObjectName)
);

INSERT INTO #tbx_IdentifierReleaseObjects
(
      ReleaseVersion
    , SchemaName
    , ObjectName
    , ObjectType
)
VALUES
      (N'1.0.0', N'toolbelt_metadata', N'TVF_ParseMultipartName', 'TF')
    , (N'1.0.0', N'toolbelt_metadata', N'SVF_QuoteMultipartName', 'FN');

CREATE TABLE #tbx_IdentifierDeployState
(
      TargetVersion    nvarchar(64) NOT NULL
    , InstalledVersion nvarchar(64) NULL
    , DeploymentMode   nvarchar(16) NOT NULL
    , SchemaCreated     bit          NOT NULL
);

DECLARE
      @TargetVersion        nvarchar(64) = N'1.0.0'
    , @DeploymentMode       nvarchar(16) = LOWER(N'local')
    , @InstalledVersion     nvarchar(64)
    , @VersionPropertyName  sysname =
          N'Toolbelt.Module.toolbelt.metadata.identifier.Version'
    , @ProductMajorVersion  int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @SchemaId             int = SCHEMA_ID(N'toolbelt_metadata')
    , @CollisionSchema      sysname
    , @CollisionObject      sysname
    , @LockResult           int
    , @DropSql              nvarchar(max)
    , @SchemaCreated        bit = 0;

IF @ProductMajorVersion NOT IN (15, 16, 17)
BEGIN
    THROW 51060, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
END;

IF @DeploymentMode NOT IN (N'local', N'central')
BEGIN
    THROW 51061, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

IF @InstalledVersion IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM #tbx_IdentifierReleaseObjects AS ro
           WHERE ro.ReleaseVersion COLLATE Latin1_General_100_BIN2
                     = @InstalledVersion COLLATE Latin1_General_100_BIN2
       )
BEGIN
    THROW 51063, N'Die installierte Modulversion ist diesem Deployment nicht als unterstütztes Vorgängerrelease bekannt.', 1;
END;

IF @SchemaId IS NULL
BEGIN
    IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    BEGIN
        THROW 51062, N'Zum Anlegen von toolbelt_metadata fehlt CREATE SCHEMA in der Installationsdatenbank.', 1;
    END;
END;
ELSE IF HAS_PERMS_BY_NAME(N'toolbelt_metadata', N'SCHEMA', N'ALTER') <> 1
BEGIN
    THROW 51062, N'Für das vorhandene Schema toolbelt_metadata fehlt ALTER.', 1;
END;

IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
BEGIN
    THROW 51062, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;
END;

/*
 * Neue Zielnamen dürfen kein frameworkfremdes Objekt überschreiben. Ein Name
 * gilt nur dann als Framework-Bestand, wenn er im bekannten installierten
 * Release enthalten ist.
 */
SELECT TOP (1)
      @CollisionSchema = target.SchemaName
    , @CollisionObject = target.ObjectName
FROM #tbx_IdentifierReleaseObjects AS target
INNER JOIN sys.schemas AS schemas
    ON schemas.name COLLATE Latin1_General_100_BIN2
          = target.SchemaName COLLATE Latin1_General_100_BIN2
INNER JOIN sys.objects AS objects
    ON objects.schema_id = schemas.schema_id
   AND objects.name COLLATE Latin1_General_100_BIN2
          = target.ObjectName COLLATE Latin1_General_100_BIN2
WHERE target.ReleaseVersion = @TargetVersion
  AND
  (
      @InstalledVersion IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM #tbx_IdentifierReleaseObjects AS previous
             WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                       = @InstalledVersion COLLATE Latin1_General_100_BIN2
               AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                       = target.SchemaName COLLATE Latin1_General_100_BIN2
               AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                       = target.ObjectName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY target.ObjectName COLLATE Latin1_General_100_BIN2;

IF @CollisionObject IS NOT NULL
BEGIN
    DECLARE @CollisionMessage nvarchar(2048) =
        N'Das neue Framework-Objekt '
        + QUOTENAME(@CollisionSchema)
        + N'.'
        + QUOTENAME(@CollisionObject)
        + N' ist bereits vorhanden, stammt aber nicht aus dem bekannten installierten Release.';
    SET @CollisionMessage = REPLACE(@CollisionMessage, N'%', N'%%');
    THROW 51064, @CollisionMessage, 1;
END;

INSERT INTO #tbx_IdentifierDeployState
(
      TargetVersion
    , InstalledVersion
    , DeploymentMode
    , SchemaCreated
)
VALUES
(
      @TargetVersion
    , @InstalledVersion
    , @DeploymentMode
    , 0
);

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC @LockResult = sys.sp_getapplock
          @Resource    = N'toolbelt.deploy.toolbelt.metadata.identifier'
        , @LockMode    = N'Exclusive'
        , @LockOwner   = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
    BEGIN
        THROW 51067, N'Ein paralleles Deployment von toolbelt.metadata.identifier ist bereits aktiv.', 1;
    END;

    DECLARE @CurrentInstalledVersion nvarchar(64);

    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
           <> ISNULL(@InstalledVersion, N'') COLLATE Latin1_General_100_BIN2
    BEGIN
        THROW 51067, N'Der installierte Modulstand hat sich seit dem Preflight verändert.', 1;
    END;

    SET @CollisionSchema = NULL;
    SET @CollisionObject = NULL;

    SELECT TOP (1)
          @CollisionSchema = target.SchemaName
        , @CollisionObject = target.ObjectName
    FROM #tbx_IdentifierReleaseObjects AS target
    INNER JOIN sys.schemas AS schemas
        ON schemas.name COLLATE Latin1_General_100_BIN2
              = target.SchemaName COLLATE Latin1_General_100_BIN2
    INNER JOIN sys.objects AS objects
        ON objects.schema_id = schemas.schema_id
       AND objects.name COLLATE Latin1_General_100_BIN2
              = target.ObjectName COLLATE Latin1_General_100_BIN2
    WHERE target.ReleaseVersion = @TargetVersion
      AND
      (
          @InstalledVersion IS NULL
          OR NOT EXISTS
             (
                 SELECT 1
                 FROM #tbx_IdentifierReleaseObjects AS previous
                 WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                           = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                           = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                           = target.ObjectName COLLATE Latin1_General_100_BIN2
             )
      );

    IF @CollisionObject IS NOT NULL
    BEGIN
        THROW 51067, N'Ein Zielobjekt hat sich seit dem Preflight verändert oder ist neu hinzugekommen.', 1;
    END;

    IF SCHEMA_ID(N'toolbelt_metadata') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_metadata];';
        SET @SchemaCreated = 1;

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.Managed'
            , @value      = 1
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_metadata';

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.SchemaCategory'
            , @value      = N'core'
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_metadata';
    END;

    UPDATE #tbx_IdentifierDeployState
    SET SchemaCreated = @SchemaCreated;

    /*
     * Ein lokal verändertes Release-Objekt mit falschem Typ wird anhand des
     * bekannten Vorgänger-Manifests entfernt. Fremde Namen bleiben unberührt.
     */
    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN objects.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN objects.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN objects.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(schemas.name)
                    + N'.'
                    + QUOTENAME(objects.name)
                    + N';'
                FROM #tbx_IdentifierReleaseObjects AS target
                INNER JOIN #tbx_IdentifierReleaseObjects AS previous
                    ON previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.schemas AS schemas
                    ON schemas.name COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS objects
                    ON objects.schema_id = schemas.schema_id
                   AND objects.name COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE target.ReleaseVersion = @TargetVersion
                  AND objects.type COLLATE Latin1_General_100_BIN2
                        <> target.ObjectType COLLATE Latin1_General_100_BIN2
                  AND objects.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY objects.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

-- ============================================================================
-- Objekt:          toolbelt_metadata.TVF_ParseMultipartName
-- Typ:             Multi-statement Table-valued Function
-- Zweck:           Zerlegt und validiert ein- bis vierteilige SQL-Namen.
-- Vertrag:         Documentation/TVF_ParseMultipartName.md
-- Parameter:       @MultipartName nvarchar(1035)
-- Resultset:       Eine Zeile mit Status, Teilen und sicher begrenztem Namen.
-- Dependencies:    Keine Modulabhängigkeit.
-- Rechte:          SELECT oder REFERENCES
-- Versionen:       SQL Server 2019/2022/2025
-- Plattformen:     Windows/Linux
-- Fehlerverhalten: Ungültige Eingaben werden als ValidationCode zurückgegeben.
-- Performance:     Zustandsautomat mit linearer Laufzeit und maximal 1035 Zeichen.
-- Einschränkungen: Doppelte Anführungszeichen sind keine Identifier-Delimiter.
-- ============================================================================
CREATE OR ALTER FUNCTION [toolbelt_metadata].[TVF_ParseMultipartName]
(
    @MultipartName nvarchar(1035)
)
RETURNS @Result TABLE
(
      IsValid        bit            NOT NULL
    , ValidationCode varchar(32)     NOT NULL
    , PartCount      tinyint         NULL
    , ServerName     sysname         NULL
    , DatabaseName   sysname         NULL
    , SchemaName     sysname         NULL
    , ObjectName     sysname         NULL
    , QuotedName     nvarchar(1035)  NULL
)
AS
BEGIN
    DECLARE
          @IsValid          bit = 1
        , @ValidationCode   varchar(32) = 'VALID'
        , @InputLength      int
        , @Position         int = 1
        , @PartOrdinal      tinyint = 1
        , @CurrentPart      nvarchar(1035) = N''
        , @Character        nchar(1)
        , @NextCharacter    nchar(1)
        , @InsideDelimited  bit = 0
        , @AfterDelimited   bit = 0
        , @PartIsDelimited  bit = 0;

    DECLARE @Parts TABLE
    (
          PartOrdinal tinyint         NOT NULL PRIMARY KEY
        , PartValue   nvarchar(1035)  NULL
        , IsDelimited bit             NOT NULL
        , IsOmitted   bit             NOT NULL
    );

    IF @MultipartName IS NULL
    BEGIN
        SET @IsValid = 0;
        SET @ValidationCode = 'NULL_INPUT';
    END;
    ELSE
    BEGIN
        /*
         * Das angehängte Zeichen verhindert, dass LEN nachgestellte
         * Leerzeichen aus der Eingabelänge entfernt.
         */
        SET @InputLength = LEN(@MultipartName + N'#') - 1;

        IF @InputLength = 0
        BEGIN
            SET @IsValid = 0;
            SET @ValidationCode = 'EMPTY_INPUT';
        END;
    END;

    WHILE @IsValid = 1 AND @Position <= @InputLength
    BEGIN
        SET @Character = SUBSTRING(@MultipartName, @Position, 1);
        SET @NextCharacter =
            CASE
                WHEN @Position < @InputLength
                    THEN SUBSTRING(@MultipartName, @Position + 1, 1)
                ELSE NULL
            END;

        IF UNICODE(@Character) < 32 OR UNICODE(@Character) = 127
        BEGIN
            SET @IsValid = 0;
            SET @ValidationCode = 'CONTROL_CHARACTER';
        END;
        ELSE IF @InsideDelimited = 1
        BEGIN
            IF @Character = N']'
            BEGIN
                IF @NextCharacter = N']'
                BEGIN
                    SET @CurrentPart += N']';
                    SET @Position += 2;
                END;
                ELSE
                BEGIN
                    SET @InsideDelimited = 0;
                    SET @AfterDelimited = 1;
                    SET @Position += 1;
                END;
            END;
            ELSE
            BEGIN
                SET @CurrentPart += @Character;
                SET @Position += 1;
            END;
        END;
        ELSE IF @AfterDelimited = 1
        BEGIN
            IF @Character <> N'.'
            BEGIN
                SET @IsValid = 0;
                SET @ValidationCode = 'TEXT_AFTER_DELIMITER';
            END;
            ELSE
            BEGIN
                INSERT INTO @Parts
                (
                      PartOrdinal
                    , PartValue
                    , IsDelimited
                    , IsOmitted
                )
                VALUES
                (
                      @PartOrdinal
                    , @CurrentPart
                    , 1
                    , 0
                );

                SET @PartOrdinal += 1;
                SET @CurrentPart = N'';
                SET @InsideDelimited = 0;
                SET @AfterDelimited = 0;
                SET @PartIsDelimited = 0;
                SET @Position += 1;
            END;
        END;
        ELSE IF @Character = N'.'
        BEGIN
            INSERT INTO @Parts
            (
                  PartOrdinal
                , PartValue
                , IsDelimited
                , IsOmitted
            )
            VALUES
            (
                  @PartOrdinal
                , NULLIF(@CurrentPart, N'')
                , @PartIsDelimited
                , CASE WHEN @CurrentPart = N'' THEN 1 ELSE 0 END
            );

            SET @PartOrdinal += 1;
            SET @CurrentPart = N'';
            SET @PartIsDelimited = 0;
            SET @Position += 1;
        END;
        ELSE IF @Character = N'['
        BEGIN
            IF @CurrentPart <> N''
            BEGIN
                SET @IsValid = 0;
                SET @ValidationCode = 'BRACKET_SYNTAX';
            END;
            ELSE
            BEGIN
                SET @InsideDelimited = 1;
                SET @PartIsDelimited = 1;
                SET @Position += 1;
            END;
        END;
        ELSE IF @Character = N']'
        BEGIN
            SET @IsValid = 0;
            SET @ValidationCode = 'BRACKET_SYNTAX';
        END;
        ELSE
        BEGIN
            /*
             * Ausdrucks- und Wildcard-Metazeichen sind in der unquoted Form
             * nicht Teil dieses Vertrags. Innerhalb von [...] bleiben sie
             * normale Identifierzeichen.
             */
            IF CHARINDEX
               (
                   @Character COLLATE Latin1_General_100_BIN2,
                   N'*%''";(),=+-/\:?!{}|&<>'
                       COLLATE Latin1_General_100_BIN2
               ) > 0
            BEGIN
                SET @IsValid = 0;
                SET @ValidationCode = 'UNQUOTED_META_CHARACTER';
            END;
            ELSE
            BEGIN
                SET @CurrentPart += @Character;
                SET @Position += 1;
            END;
        END;

        IF LEN(@CurrentPart + N'#') - 1 > 128
        BEGIN
            SET @IsValid = 0;
            SET @ValidationCode = 'PART_TOO_LONG';
        END;

        IF @PartOrdinal > 4
        BEGIN
            SET @IsValid = 0;
            SET @ValidationCode = 'TOO_MANY_PARTS';
        END;
    END;

    IF @IsValid = 1 AND @InsideDelimited = 1
    BEGIN
        SET @IsValid = 0;
        SET @ValidationCode = 'UNCLOSED_DELIMITER';
    END;

    IF @IsValid = 1
    BEGIN
        INSERT INTO @Parts
        (
              PartOrdinal
            , PartValue
            , IsDelimited
            , IsOmitted
        )
        VALUES
        (
              @PartOrdinal
            , CASE
                  WHEN @AfterDelimited = 1 THEN @CurrentPart
                  ELSE NULLIF(@CurrentPart, N'')
              END
            , @PartIsDelimited
            , CASE
                  WHEN @AfterDelimited = 0 AND @CurrentPart = N'' THEN 1
                  ELSE 0
              END
        );
    END;

    DECLARE @PartCount tinyint =
        CASE
            WHEN @IsValid = 1 THEN (SELECT COUNT(*) FROM @Parts)
            ELSE @PartOrdinal
        END;

    IF @IsValid = 1 AND @PartCount > 4
    BEGIN
        SET @IsValid = 0;
        SET @ValidationCode = 'TOO_MANY_PARTS';
    END;

    IF @IsValid = 1
       AND EXISTS
           (
               SELECT 1
               FROM @Parts
               WHERE IsDelimited = 1
                 AND ISNULL(PartValue, N'') = N''
           )
    BEGIN
        SET @IsValid = 0;
        SET @ValidationCode = 'EMPTY_IDENTIFIER';
    END;

    IF @IsValid = 1
       AND EXISTS
           (
               SELECT 1
               FROM @Parts
               WHERE IsDelimited = 0
                 AND PartValue IS NOT NULL
                 AND
                 (
                     LEFT(PartValue, 1) = N' '
                     OR RIGHT(PartValue, 1) = N' '
                 )
           )
    BEGIN
        SET @IsValid = 0;
        SET @ValidationCode = 'OUTER_WHITESPACE';
    END;

    IF @IsValid = 1
       AND
       (
           EXISTS
           (
               SELECT 1
               FROM @Parts
               WHERE PartOrdinal IN (1, @PartCount)
                 AND IsOmitted = 1
           )
           OR EXISTS
              (
                  SELECT 1
                  FROM @Parts
                  WHERE IsOmitted = 1
                    AND
                    (
                        @PartCount < 3
                        OR PartOrdinal NOT BETWEEN 2 AND @PartCount - 1
                    )
              )
       )
    BEGIN
        SET @IsValid = 0;
        SET @ValidationCode = 'INVALID_OMISSION';
    END;

    DECLARE
          @Part1 sysname
        , @Part2 sysname
        , @Part3 sysname
        , @Part4 sysname
        , @ServerName sysname
        , @DatabaseName sysname
        , @SchemaName sysname
        , @ObjectName sysname
        , @QuotedName nvarchar(1035);

    IF @IsValid = 1
    BEGIN
        SELECT
              @Part1 = MAX(CASE WHEN PartOrdinal = 1 THEN PartValue END)
            , @Part2 = MAX(CASE WHEN PartOrdinal = 2 THEN PartValue END)
            , @Part3 = MAX(CASE WHEN PartOrdinal = 3 THEN PartValue END)
            , @Part4 = MAX(CASE WHEN PartOrdinal = 4 THEN PartValue END)
        FROM @Parts;

        SELECT
              @ServerName =
                  CASE WHEN @PartCount = 4 THEN @Part1 END
            , @DatabaseName =
                  CASE
                      WHEN @PartCount = 4 THEN @Part2
                      WHEN @PartCount = 3 THEN @Part1
                  END
            , @SchemaName =
                  CASE
                      WHEN @PartCount = 4 THEN @Part3
                      WHEN @PartCount = 3 THEN @Part2
                      WHEN @PartCount = 2 THEN @Part1
                  END
            , @ObjectName =
                  CASE @PartCount
                      WHEN 4 THEN @Part4
                      WHEN 3 THEN @Part3
                      WHEN 2 THEN @Part2
                      WHEN 1 THEN @Part1
                  END;

        SET @QuotedName =
            CASE @PartCount
                WHEN 1
                    THEN QUOTENAME(@Part1)
                WHEN 2
                    THEN QUOTENAME(@Part1) + N'.' + QUOTENAME(@Part2)
                WHEN 3
                    THEN QUOTENAME(@Part1) + N'.'
                       + COALESCE(QUOTENAME(@Part2), N'') + N'.'
                       + QUOTENAME(@Part3)
                WHEN 4
                    THEN QUOTENAME(@Part1) + N'.'
                       + COALESCE(QUOTENAME(@Part2), N'') + N'.'
                       + COALESCE(QUOTENAME(@Part3), N'') + N'.'
                       + QUOTENAME(@Part4)
            END;

        IF @QuotedName IS NULL OR @ObjectName IS NULL
        BEGIN
            SET @IsValid = 0;
            SET @ValidationCode = 'INVALID_IDENTIFIER';
            SET @ServerName = NULL;
            SET @DatabaseName = NULL;
            SET @SchemaName = NULL;
            SET @ObjectName = NULL;
            SET @QuotedName = NULL;
        END;
    END;

    INSERT INTO @Result
    (
          IsValid
        , ValidationCode
        , PartCount
        , ServerName
        , DatabaseName
        , SchemaName
        , ObjectName
        , QuotedName
    )
    VALUES
    (
          @IsValid
        , @ValidationCode
        , @PartCount
        , CASE WHEN @IsValid = 1 THEN @ServerName END
        , CASE WHEN @IsValid = 1 THEN @DatabaseName END
        , CASE WHEN @IsValid = 1 THEN @SchemaName END
        , CASE WHEN @IsValid = 1 THEN @ObjectName END
        , CASE WHEN @IsValid = 1 THEN @QuotedName END
    );

    RETURN;
END;
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

-- ============================================================================
-- Objekt:          toolbelt_metadata.SVF_QuoteMultipartName
-- Typ:             Scalar-valued Function
-- Zweck:           Begrenzt einen gültigen Multipart-Namen sicher mit [].
-- Vertrag:         Documentation/SVF_QuoteMultipartName.md
-- Parameter:       @MultipartName nvarchar(1035)
-- Rückgabewert:    nvarchar(1035), bei ungültiger Eingabe NULL
-- Dependencies:    toolbelt_metadata.TVF_ParseMultipartName
-- Rechte:          SELECT oder REFERENCES
-- Versionen:       SQL Server 2019/2022/2025
-- Plattformen:     Windows/Linux
-- Fehlerverhalten: Ungültige Eingaben liefern NULL.
-- Performance:     Verwendet den kanonischen linearen Parser genau einmal.
-- Einschränkungen: Führt keine Objekt- oder Berechtigungsauflösung aus.
-- ============================================================================
CREATE OR ALTER FUNCTION [toolbelt_metadata].[SVF_QuoteMultipartName]
(
    @MultipartName nvarchar(1035)
)
RETURNS nvarchar(1035)
AS
BEGIN
    DECLARE @QuotedName nvarchar(1035);

    SELECT @QuotedName = parsed.QuotedName
    FROM [toolbelt_metadata].[TVF_ParseMultipartName](@MultipartName) AS parsed
    WHERE parsed.IsValid = 1;

    RETURN @QuotedName;
END;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    DECLARE
          @DeploymentMode      nvarchar(16)
        , @TargetVersion       nvarchar(64)
        , @VersionPropertyName sysname =
              N'Toolbelt.Module.toolbelt.metadata.identifier.Version'
        , @ModePropertyName    sysname =
              N'Toolbelt.Module.toolbelt.metadata.identifier.DeploymentMode';

    SELECT
          @DeploymentMode = DeploymentMode
        , @TargetVersion = TargetVersion
    FROM #tbx_IdentifierDeployState;

    IF XACT_STATE() <> 1
       OR OBJECT_ID(N'toolbelt_metadata.TVF_ParseMultipartName', N'TF') IS NULL
       OR OBJECT_ID(N'toolbelt_metadata.SVF_QuoteMultipartName', N'FN') IS NULL
    BEGIN
        THROW 51068, N'Die Framework-Funktionen wurden nicht vollständig innerhalb der Deployment-Transaktion angelegt.', 1;
    END;

    DECLARE @Objects TABLE
    (
          ObjectOrdinal int IDENTITY(1, 1) NOT NULL
        , ObjectName    sysname            NOT NULL
    );

    INSERT INTO @Objects (ObjectName)
    VALUES (N'TVF_ParseMultipartName'), (N'SVF_QuoteMultipartName');

    DECLARE
          @ObjectOrdinal int = 1
        , @ObjectCount   int = (SELECT COUNT(*) FROM @Objects)
        , @ObjectName    sysname
        , @ObjectId      int
        , @SourceHash    varchar(64)
        , @PropertyOrdinal int
        , @PropertyCount   int
        , @PropertyName    sysname
        , @PropertyValue   nvarchar(4000);

    DECLARE @Properties TABLE
    (
          PropertyOrdinal int            NOT NULL PRIMARY KEY
        , PropertyName    sysname        NOT NULL
        , PropertyValue   nvarchar(4000) NOT NULL
    );

    WHILE @ObjectOrdinal <= @ObjectCount
    BEGIN
        SELECT @ObjectName = ObjectName
        FROM @Objects
        WHERE ObjectOrdinal = @ObjectOrdinal;

        SET @ObjectId = OBJECT_ID
        (
            QUOTENAME(N'toolbelt_metadata') + N'.' + QUOTENAME(@ObjectName)
        );
        SET @SourceHash = CONVERT
        (
              varchar(64)
            , HASHBYTES
              (
                  N'SHA2_256'
                , CONVERT(varbinary(max), OBJECT_DEFINITION(@ObjectId))
              )
            , 2
        );

        INSERT INTO @Properties
        (
              PropertyOrdinal
            , PropertyName
            , PropertyValue
        )
        VALUES
              (1, N'Toolbelt.ModuleId', N'toolbelt.metadata.identifier')
            , (2, N'Toolbelt.ModuleVersion', @TargetVersion)
            , (3, N'Toolbelt.ContractVersion', N'1.0')
            , (4, N'Toolbelt.DeploymentMode', @DeploymentMode)
            , (5, N'Toolbelt.SourceHash', CONVERT(nvarchar(4000), @SourceHash));

        SET @PropertyOrdinal = 1;
        SET @PropertyCount = (SELECT COUNT(*) FROM @Properties);

        WHILE @PropertyOrdinal <= @PropertyCount
        BEGIN
            SELECT
                  @PropertyName = PropertyName
                , @PropertyValue = PropertyValue
            FROM @Properties
            WHERE PropertyOrdinal = @PropertyOrdinal;

            IF EXISTS
               (
                   SELECT 1
                   FROM sys.extended_properties AS ep
                   WHERE ep.class = 1
                     AND ep.major_id = @ObjectId
                     AND ep.minor_id = 0
                     AND ep.name = @PropertyName
               )
            BEGIN
                EXEC sys.sp_updateextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_metadata'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;
            ELSE
            BEGIN
                EXEC sys.sp_addextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_metadata'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;

            SET @PropertyOrdinal += 1;
        END;

        DELETE FROM @Properties;
        SET @ObjectOrdinal += 1;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @VersionPropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @ModePropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.metadata.identifier
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.validation.semantic-version
:On Error exit

-- ============================================================================
-- Zweck:     Erst-, Upgrade- und Wiederholungsdeployment
-- Modul:     toolbelt.validation.semantic-version v1.1.0
-- Schema:    toolbelt_validation
-- Erfordert: SQL Server 2019, 2022 oder 2025
-- Modus:     SQLCMD; Ausführung aus diesem Deployment-Verzeichnis
-- Parameter: DeploymentMode=local|central
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'tempdb..#tbx_SemanticVersionReleaseObjects', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_SemanticVersionReleaseObjects;
END;

IF OBJECT_ID(N'tempdb..#tbx_SemanticVersionDeployState', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_SemanticVersionDeployState;
END;

CREATE TABLE #tbx_SemanticVersionReleaseObjects
(
      ReleaseVersion nvarchar(64) NOT NULL
    , SchemaName     sysname      NOT NULL
    , ObjectName     sysname      NOT NULL
    , ObjectType     char(2)      NOT NULL
    , CONSTRAINT PK_tbx_SemanticVersionReleaseObjects
          PRIMARY KEY (ReleaseVersion, SchemaName, ObjectName)
);

INSERT INTO #tbx_SemanticVersionReleaseObjects
(
      ReleaseVersion
    , SchemaName
    , ObjectName
    , ObjectType
)
VALUES
      (N'1.0.0', N'toolbelt_validation', N'TVF_ParseSemanticVersion', 'TF')
    , (N'1.0.0', N'toolbelt_validation', N'SVF_CompareSemanticVersion', 'FN')
    , (N'1.0.0', N'toolbelt_validation', N'SVF_SemanticVersionSortKey', 'FN')
    , (N'1.1.0', N'toolbelt_validation', N'TVF_ParseSemanticVersion', 'TF')
    , (N'1.1.0', N'toolbelt_validation', N'TVF_CompareSemanticVersion', 'IF')
    , (N'1.1.0', N'toolbelt_validation', N'TVF_SemanticVersionSortKey', 'IF')
    , (N'1.1.0', N'toolbelt_validation', N'SVF_CompareSemanticVersion', 'FN')
    , (N'1.1.0', N'toolbelt_validation', N'SVF_SemanticVersionSortKey', 'FN');

CREATE TABLE #tbx_SemanticVersionDeployState
(
      TargetVersion    nvarchar(64) NOT NULL
    , InstalledVersion nvarchar(64) NULL
    , DeploymentMode   nvarchar(16) NOT NULL
    , SchemaCreated     bit          NOT NULL
);

DECLARE
      @TargetVersion        nvarchar(64) = N'1.1.0'
    , @DeploymentMode       nvarchar(16) = LOWER(N'local')
    , @InstalledVersion     nvarchar(64)
    , @VersionPropertyName  sysname =
          N'Toolbelt.Module.toolbelt.validation.semantic-version.Version'
    , @ProductMajorVersion  int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @SchemaId             int = SCHEMA_ID(N'toolbelt_validation')
    , @CollisionSchema      sysname
    , @CollisionObject      sysname
    , @LockResult           int
    , @DropSql              nvarchar(max)
    , @SchemaCreated        bit = 0;

IF @ProductMajorVersion NOT IN (15, 16, 17)
BEGIN
    THROW 51080, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
END;

IF @DeploymentMode NOT IN (N'local', N'central')
BEGIN
    THROW 51081, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

IF @InstalledVersion IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM #tbx_SemanticVersionReleaseObjects AS ro
           WHERE ro.ReleaseVersion COLLATE Latin1_General_100_BIN2
                     = @InstalledVersion COLLATE Latin1_General_100_BIN2
       )
BEGIN
    THROW 51083, N'Die installierte Modulversion ist diesem Deployment nicht als unterstütztes Vorgängerrelease bekannt.', 1;
END;

IF @SchemaId IS NULL
BEGIN
    IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    BEGIN
        THROW 51082, N'Zum Anlegen von toolbelt_validation fehlt CREATE SCHEMA in der Installationsdatenbank.', 1;
    END;
END;
ELSE IF HAS_PERMS_BY_NAME(N'toolbelt_validation', N'SCHEMA', N'ALTER') <> 1
BEGIN
    THROW 51082, N'Für das vorhandene Schema toolbelt_validation fehlt ALTER.', 1;
END;

IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
BEGIN
    THROW 51082, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;
END;

/*
 * Neue Zielnamen dürfen kein frameworkfremdes Objekt überschreiben. Ein Name
 * gilt nur dann als Framework-Bestand, wenn er im bekannten installierten
 * Release enthalten ist.
 */
SELECT TOP (1)
      @CollisionSchema = target.SchemaName
    , @CollisionObject = target.ObjectName
FROM #tbx_SemanticVersionReleaseObjects AS target
INNER JOIN sys.schemas AS schemas
    ON schemas.name COLLATE Latin1_General_100_BIN2
          = target.SchemaName COLLATE Latin1_General_100_BIN2
INNER JOIN sys.objects AS objects
    ON objects.schema_id = schemas.schema_id
   AND objects.name COLLATE Latin1_General_100_BIN2
          = target.ObjectName COLLATE Latin1_General_100_BIN2
WHERE target.ReleaseVersion = @TargetVersion
  AND
  (
      @InstalledVersion IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM #tbx_SemanticVersionReleaseObjects AS previous
             WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                       = @InstalledVersion COLLATE Latin1_General_100_BIN2
               AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                       = target.SchemaName COLLATE Latin1_General_100_BIN2
               AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                       = target.ObjectName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY target.ObjectName COLLATE Latin1_General_100_BIN2;

IF @CollisionObject IS NOT NULL
BEGIN
    DECLARE @CollisionMessage nvarchar(2048) =
        N'Das neue Framework-Objekt '
        + QUOTENAME(@CollisionSchema)
        + N'.'
        + QUOTENAME(@CollisionObject)
        + N' ist bereits vorhanden, stammt aber nicht aus dem bekannten installierten Release.';
    SET @CollisionMessage = REPLACE(@CollisionMessage, N'%', N'%%');
    THROW 51084, @CollisionMessage, 1;
END;

INSERT INTO #tbx_SemanticVersionDeployState
(
      TargetVersion
    , InstalledVersion
    , DeploymentMode
    , SchemaCreated
)
VALUES
(
      @TargetVersion
    , @InstalledVersion
    , @DeploymentMode
    , 0
);

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC @LockResult = sys.sp_getapplock
          @Resource    = N'toolbelt.deploy.toolbelt.validation.semantic-version'
        , @LockMode    = N'Exclusive'
        , @LockOwner   = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
    BEGIN
        THROW 51087, N'Ein paralleles Deployment von toolbelt.validation.semantic-version ist bereits aktiv.', 1;
    END;

    DECLARE @CurrentInstalledVersion nvarchar(64);

    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
           <> ISNULL(@InstalledVersion, N'') COLLATE Latin1_General_100_BIN2
    BEGIN
        THROW 51087, N'Der installierte Modulstand hat sich seit dem Preflight verändert.', 1;
    END;

    SET @CollisionSchema = NULL;
    SET @CollisionObject = NULL;

    SELECT TOP (1)
          @CollisionSchema = target.SchemaName
        , @CollisionObject = target.ObjectName
    FROM #tbx_SemanticVersionReleaseObjects AS target
    INNER JOIN sys.schemas AS schemas
        ON schemas.name COLLATE Latin1_General_100_BIN2
              = target.SchemaName COLLATE Latin1_General_100_BIN2
    INNER JOIN sys.objects AS objects
        ON objects.schema_id = schemas.schema_id
       AND objects.name COLLATE Latin1_General_100_BIN2
              = target.ObjectName COLLATE Latin1_General_100_BIN2
    WHERE target.ReleaseVersion = @TargetVersion
      AND
      (
          @InstalledVersion IS NULL
          OR NOT EXISTS
             (
                 SELECT 1
                 FROM #tbx_SemanticVersionReleaseObjects AS previous
                 WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                           = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                           = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                           = target.ObjectName COLLATE Latin1_General_100_BIN2
             )
      );

    IF @CollisionObject IS NOT NULL
    BEGIN
        THROW 51087, N'Ein Zielobjekt hat sich seit dem Preflight verändert oder ist neu hinzugekommen.', 1;
    END;

    IF SCHEMA_ID(N'toolbelt_validation') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_validation];';
        SET @SchemaCreated = 1;

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.Managed'
            , @value      = 1
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_validation';

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.SchemaCategory'
            , @value      = N'validation'
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_validation';
    END;

    UPDATE #tbx_SemanticVersionDeployState
    SET SchemaCreated = @SchemaCreated;

    /*
     * Ein lokal verändertes Release-Objekt mit falschem Typ wird anhand des
     * bekannten Vorgänger-Manifests entfernt. Fremde Namen bleiben unberührt.
     */
    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN objects.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN objects.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN objects.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(schemas.name)
                    + N'.'
                    + QUOTENAME(objects.name)
                    + N';'
                FROM #tbx_SemanticVersionReleaseObjects AS target
                INNER JOIN #tbx_SemanticVersionReleaseObjects AS previous
                    ON previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.schemas AS schemas
                    ON schemas.name COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS objects
                    ON objects.schema_id = schemas.schema_id
                   AND objects.name COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE target.ReleaseVersion = @TargetVersion
                  AND objects.type COLLATE Latin1_General_100_BIN2
                        <> target.ObjectType COLLATE Latin1_General_100_BIN2
                  AND objects.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY objects.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO

CREATE OR ALTER FUNCTION [toolbelt_validation].[TVF_ParseSemanticVersion]
(
    @Version varchar(8000)
)
RETURNS @Result TABLE
(
      IsValid          bit           NOT NULL
    , ValidationCode   varchar(32)   NOT NULL
    , Major            varchar(8000) NULL
    , Minor            varchar(8000) NULL
    , Patch            varchar(8000) NULL
    , PreRelease       varchar(8000) NULL
    , BuildMetadata    varchar(8000) NULL
    , CanonicalVersion varchar(8000) NULL
)
AS
BEGIN
    DECLARE
          @Code       varchar(32) = 'VALID'
        , @InputLength int = DATALENGTH(@Version)
        , @PlusPos      int
        , @DashPos      int
        , @Dot1         int
        , @Dot2         int
        , @Precedence   varchar(8000)
        , @Major        varchar(8000)
        , @Minor        varchar(8000)
        , @Patch        varchar(8000)
        , @PreRelease   varchar(8000)
        , @Build        varchar(8000)
        , @Position     int
        , @NextDot      int
        , @Identifier   varchar(8000);

    IF @Version IS NULL
        SET @Code = 'NULL_INPUT';
    ELSE IF @InputLength = 0
        SET @Code = 'EMPTY_INPUT';
    ELSE IF @Version COLLATE Latin1_General_100_BIN2
                 LIKE '%[^0-9A-Za-z.+-]%' COLLATE Latin1_General_100_BIN2
        SET @Code = 'INVALID_CHARACTER';

    IF @Code = 'VALID'
    BEGIN
        SET @PlusPos = CHARINDEX('+', @Version COLLATE Latin1_General_100_BIN2);

        IF @PlusPos > 0
           AND CHARINDEX
               (
                   '+',
                   @Version COLLATE Latin1_General_100_BIN2,
                   @PlusPos + 1
               ) > 0
            SET @Code = 'BUILD_FORMAT';
        ELSE
        BEGIN
            SET @Precedence =
                CASE WHEN @PlusPos = 0
                    THEN @Version
                    ELSE LEFT(@Version, @PlusPos - 1)
                END;
            SET @Build =
                CASE WHEN @PlusPos = 0
                    THEN NULL
                    ELSE SUBSTRING
                         (
                             @Version,
                             @PlusPos + 1,
                             @InputLength - @PlusPos
                         )
                END;

            IF @PlusPos > 0 AND DATALENGTH(@Build) = 0
                SET @Code = 'EMPTY_BUILD';
        END;
    END;

    IF @Code = 'VALID'
    BEGIN
        SET @DashPos =
            CHARINDEX('-', @Precedence COLLATE Latin1_General_100_BIN2);
        SET @PreRelease =
            CASE WHEN @DashPos = 0
                THEN NULL
                ELSE SUBSTRING
                     (
                         @Precedence,
                         @DashPos + 1,
                         DATALENGTH(@Precedence) - @DashPos
                     )
            END;
        SET @Precedence =
            CASE WHEN @DashPos = 0
                THEN @Precedence
                ELSE LEFT(@Precedence, @DashPos - 1)
            END;

        IF @DashPos > 0 AND DATALENGTH(@PreRelease) = 0
            SET @Code = 'EMPTY_PRERELEASE';
    END;

    IF @Code = 'VALID'
    BEGIN
        SET @Dot1 = CHARINDEX('.', @Precedence COLLATE Latin1_General_100_BIN2);
        SET @Dot2 =
            CASE WHEN @Dot1 = 0 THEN 0
                 ELSE CHARINDEX
                      (
                          '.',
                          @Precedence COLLATE Latin1_General_100_BIN2,
                          @Dot1 + 1
                      )
            END;

        IF @Dot1 = 0
           OR @Dot2 = 0
           OR CHARINDEX
              (
                  '.',
                  @Precedence COLLATE Latin1_General_100_BIN2,
                  @Dot2 + 1
              ) > 0
            SET @Code = 'CORE_FORMAT';
        ELSE
        BEGIN
            SET @Major = LEFT(@Precedence, @Dot1 - 1);
            SET @Minor = SUBSTRING(@Precedence, @Dot1 + 1, @Dot2 - @Dot1 - 1);
            SET @Patch = SUBSTRING
            (
                @Precedence,
                @Dot2 + 1,
                DATALENGTH(@Precedence) - @Dot2
            );

            IF DATALENGTH(@Major) = 0
               OR DATALENGTH(@Minor) = 0
               OR DATALENGTH(@Patch) = 0
               OR @Major COLLATE Latin1_General_100_BIN2
                      LIKE '%[^0-9]%' COLLATE Latin1_General_100_BIN2
               OR @Minor COLLATE Latin1_General_100_BIN2
                      LIKE '%[^0-9]%' COLLATE Latin1_General_100_BIN2
               OR @Patch COLLATE Latin1_General_100_BIN2
                      LIKE '%[^0-9]%' COLLATE Latin1_General_100_BIN2
                SET @Code = 'CORE_FORMAT';
            ELSE IF (DATALENGTH(@Major) > 1 AND LEFT(@Major, 1) = '0')
                 OR (DATALENGTH(@Minor) > 1 AND LEFT(@Minor, 1) = '0')
                 OR (DATALENGTH(@Patch) > 1 AND LEFT(@Patch, 1) = '0')
                SET @Code = 'CORE_LEADING_ZERO';
        END;
    END;

    IF @Code = 'VALID' AND @PreRelease IS NOT NULL
    BEGIN
        IF RIGHT(@PreRelease, 1) = '.'
            SET @Code = 'PRERELEASE_FORMAT';
        SET @Position = 1;
        WHILE @Position <= DATALENGTH(@PreRelease) AND @Code = 'VALID'
        BEGIN
            SET @NextDot = CHARINDEX
            (
                '.',
                @PreRelease COLLATE Latin1_General_100_BIN2,
                @Position
            );
            SET @Identifier =
                CASE WHEN @NextDot = 0
                    THEN SUBSTRING
                         (
                             @PreRelease,
                             @Position,
                             DATALENGTH(@PreRelease) - @Position + 1
                         )
                    ELSE SUBSTRING
                         (
                             @PreRelease,
                             @Position,
                             @NextDot - @Position
                         )
                END;

            IF DATALENGTH(@Identifier) = 0
               OR @Identifier COLLATE Latin1_General_100_BIN2
                      LIKE '%[^0-9A-Za-z-]%' COLLATE Latin1_General_100_BIN2
                SET @Code = 'PRERELEASE_FORMAT';
            ELSE IF @Identifier COLLATE Latin1_General_100_BIN2
                          NOT LIKE '%[^0-9]%' COLLATE Latin1_General_100_BIN2
                    AND DATALENGTH(@Identifier) > 1
                    AND LEFT(@Identifier, 1) = '0'
                SET @Code = 'PRERELEASE_LEADING_ZERO';

            SET @Position =
                CASE WHEN @NextDot = 0
                    THEN DATALENGTH(@PreRelease) + 1
                    ELSE @NextDot + 1
                END;
        END;
    END;

    IF @Code = 'VALID' AND @Build IS NOT NULL
    BEGIN
        IF RIGHT(@Build, 1) = '.'
            SET @Code = 'BUILD_FORMAT';
        SET @Position = 1;
        WHILE @Position <= DATALENGTH(@Build) AND @Code = 'VALID'
        BEGIN
            SET @NextDot = CHARINDEX
            (
                '.',
                @Build COLLATE Latin1_General_100_BIN2,
                @Position
            );
            SET @Identifier =
                CASE WHEN @NextDot = 0
                    THEN SUBSTRING
                         (
                             @Build,
                             @Position,
                             DATALENGTH(@Build) - @Position + 1
                         )
                    ELSE SUBSTRING
                         (
                             @Build,
                             @Position,
                             @NextDot - @Position
                         )
                END;

            IF DATALENGTH(@Identifier) = 0
               OR @Identifier COLLATE Latin1_General_100_BIN2
                      LIKE '%[^0-9A-Za-z-]%' COLLATE Latin1_General_100_BIN2
                SET @Code = 'BUILD_FORMAT';

            SET @Position =
                CASE WHEN @NextDot = 0
                    THEN DATALENGTH(@Build) + 1
                    ELSE @NextDot + 1
                END;
        END;
    END;

    INSERT INTO @Result
    (
          IsValid
        , ValidationCode
        , Major
        , Minor
        , Patch
        , PreRelease
        , BuildMetadata
        , CanonicalVersion
    )
    VALUES
    (
          CASE WHEN @Code = 'VALID' THEN 1 ELSE 0 END
        , @Code
        , CASE WHEN @Code = 'VALID' THEN @Major END
        , CASE WHEN @Code = 'VALID' THEN @Minor END
        , CASE WHEN @Code = 'VALID' THEN @Patch END
        , CASE WHEN @Code = 'VALID' THEN @PreRelease END
        , CASE WHEN @Code = 'VALID' THEN @Build END
        , CASE WHEN @Code = 'VALID' THEN @Version END
    );

    RETURN;
END;
GO
-- ============================================================================
-- Objekt:       toolbelt_validation.TVF_CompareSemanticVersion
-- Zweck:        Zwei strikte Semantic-Version-2.0.0-Werte vergleichen
-- Resultset:    genau eine Zeile; ComparisonResult smallint
-- Fehlerwert:   NULL, wenn mindestens eine Eingabe ungültig ist
-- Performance:  kanonischer relationaler Kern für APPLY
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_validation].[TVF_CompareSemanticVersion]
(
      @LeftVersion  varchar(8000)
    , @RightVersion varchar(8000)
)
RETURNS TABLE
AS
RETURN
(
    WITH
    Digits (Digit) AS
    (
        SELECT Digit
        FROM
        (
            VALUES
                  (0), (1), (2), (3), (4)
                , (5), (6), (7), (8), (9)
        ) AS values_0_to_9(Digit)
    ),
    Positions (Position) AS
    (
        SELECT
            thousands.Digit * 1000
            + hundreds.Digit * 100
            + tens.Digit * 10
            + ones.Digit
            + 1
        FROM Digits AS thousands
        CROSS JOIN Digits AS hundreds
        CROSS JOIN Digits AS tens
        CROSS JOIN Digits AS ones
        WHERE thousands.Digit * 1000
              + hundreds.Digit * 100
              + tens.Digit * 10
              + ones.Digit < 8000
    ),
    LeftParsed AS
    (
        SELECT *
        FROM toolbelt_validation.TVF_ParseSemanticVersion(@LeftVersion)
    ),
    RightParsed AS
    (
        SELECT *
        FROM toolbelt_validation.TVF_ParseSemanticVersion(@RightVersion)
    ),
    Parsed AS
    (
        SELECT
              LeftIsValid = left_version.IsValid
            , LeftMajor = left_version.Major
            , LeftMinor = left_version.Minor
            , LeftPatch = left_version.Patch
            , LeftPreRelease = left_version.PreRelease
            , RightIsValid = right_version.IsValid
            , RightMajor = right_version.Major
            , RightMinor = right_version.Minor
            , RightPatch = right_version.Patch
            , RightPreRelease = right_version.PreRelease
        FROM LeftParsed AS left_version
        CROSS JOIN RightParsed AS right_version
    ),
    CoreComparison AS
    (
        SELECT
              parsed.*
            , CoreResult =
                  CONVERT
                  (
                        smallint
                      , CASE
                            WHEN DATALENGTH(LeftMajor)
                                   < DATALENGTH(RightMajor) THEN -1
                            WHEN DATALENGTH(LeftMajor)
                                   > DATALENGTH(RightMajor) THEN 1
                            WHEN LeftMajor COLLATE Latin1_General_100_BIN2
                                   < RightMajor COLLATE Latin1_General_100_BIN2
                                THEN -1
                            WHEN LeftMajor COLLATE Latin1_General_100_BIN2
                                   > RightMajor COLLATE Latin1_General_100_BIN2
                                THEN 1
                            WHEN DATALENGTH(LeftMinor)
                                   < DATALENGTH(RightMinor) THEN -1
                            WHEN DATALENGTH(LeftMinor)
                                   > DATALENGTH(RightMinor) THEN 1
                            WHEN LeftMinor COLLATE Latin1_General_100_BIN2
                                   < RightMinor COLLATE Latin1_General_100_BIN2
                                THEN -1
                            WHEN LeftMinor COLLATE Latin1_General_100_BIN2
                                   > RightMinor COLLATE Latin1_General_100_BIN2
                                THEN 1
                            WHEN DATALENGTH(LeftPatch)
                                   < DATALENGTH(RightPatch) THEN -1
                            WHEN DATALENGTH(LeftPatch)
                                   > DATALENGTH(RightPatch) THEN 1
                            WHEN LeftPatch COLLATE Latin1_General_100_BIN2
                                   < RightPatch COLLATE Latin1_General_100_BIN2
                                THEN -1
                            WHEN LeftPatch COLLATE Latin1_General_100_BIN2
                                   > RightPatch COLLATE Latin1_General_100_BIN2
                                THEN 1
                            ELSE 0
                        END
                  )
        FROM Parsed AS parsed
    ),
    LeftTokens AS
    (
        SELECT
              Ordinal = ROW_NUMBER() OVER (ORDER BY positions.Position)
            , Identifier = token.Identifier
            , IsNumeric =
                  CONVERT
                  (
                        bit
                      , CASE
                            WHEN token.Identifier
                                     COLLATE Latin1_General_100_BIN2
                                     NOT LIKE '%[^0-9]%'
                                     COLLATE Latin1_General_100_BIN2
                                THEN 1
                            ELSE 0
                        END
                  )
        FROM CoreComparison AS compared
        CROSS JOIN Positions AS positions
        CROSS APPLY
        (
            SELECT NextDot = CHARINDEX
            (
                  '.'
                , compared.LeftPreRelease
                      COLLATE Latin1_General_100_BIN2
                , positions.Position
            )
        ) AS boundary
        CROSS APPLY
        (
            SELECT Identifier =
                CASE
                    WHEN boundary.NextDot = 0
                        THEN SUBSTRING
                             (
                                   compared.LeftPreRelease
                                 , positions.Position
                                 , DATALENGTH(compared.LeftPreRelease)
                                   - positions.Position + 1
                             )
                    ELSE SUBSTRING
                         (
                               compared.LeftPreRelease
                             , positions.Position
                             , boundary.NextDot - positions.Position
                         )
                END
        ) AS token
        WHERE compared.LeftPreRelease IS NOT NULL
          AND positions.Position <= DATALENGTH(compared.LeftPreRelease)
          AND
          (
              positions.Position = 1
              OR SUBSTRING
                 (
                       compared.LeftPreRelease
                     , positions.Position - 1
                     , 1
                 ) = '.'
          )
    ),
    RightTokens AS
    (
        SELECT
              Ordinal = ROW_NUMBER() OVER (ORDER BY positions.Position)
            , Identifier = token.Identifier
            , IsNumeric =
                  CONVERT
                  (
                        bit
                      , CASE
                            WHEN token.Identifier
                                     COLLATE Latin1_General_100_BIN2
                                     NOT LIKE '%[^0-9]%'
                                     COLLATE Latin1_General_100_BIN2
                                THEN 1
                            ELSE 0
                        END
                  )
        FROM CoreComparison AS compared
        CROSS JOIN Positions AS positions
        CROSS APPLY
        (
            SELECT NextDot = CHARINDEX
            (
                  '.'
                , compared.RightPreRelease
                      COLLATE Latin1_General_100_BIN2
                , positions.Position
            )
        ) AS boundary
        CROSS APPLY
        (
            SELECT Identifier =
                CASE
                    WHEN boundary.NextDot = 0
                        THEN SUBSTRING
                             (
                                   compared.RightPreRelease
                                 , positions.Position
                                 , DATALENGTH(compared.RightPreRelease)
                                   - positions.Position + 1
                             )
                    ELSE SUBSTRING
                         (
                               compared.RightPreRelease
                             , positions.Position
                             , boundary.NextDot - positions.Position
                         )
                END
        ) AS token
        WHERE compared.RightPreRelease IS NOT NULL
          AND positions.Position <= DATALENGTH(compared.RightPreRelease)
          AND
          (
              positions.Position = 1
              OR SUBSTRING
                 (
                       compared.RightPreRelease
                     , positions.Position - 1
                     , 1
                 ) = '.'
          )
    ),
    TokenPairs AS
    (
        SELECT
              Ordinal = COALESCE(left_token.Ordinal, right_token.Ordinal)
            , TokenResult =
                  CONVERT
                  (
                        smallint
                      , CASE
                            WHEN left_token.Ordinal IS NULL THEN -1
                            WHEN right_token.Ordinal IS NULL THEN 1
                            WHEN left_token.IsNumeric = 1
                             AND right_token.IsNumeric = 0 THEN -1
                            WHEN left_token.IsNumeric = 0
                             AND right_token.IsNumeric = 1 THEN 1
                            WHEN left_token.IsNumeric = 1
                             AND DATALENGTH(left_token.Identifier)
                                   < DATALENGTH(right_token.Identifier) THEN -1
                            WHEN left_token.IsNumeric = 1
                             AND DATALENGTH(left_token.Identifier)
                                   > DATALENGTH(right_token.Identifier) THEN 1
                            WHEN left_token.Identifier
                                     COLLATE Latin1_General_100_BIN2
                                   < right_token.Identifier
                                     COLLATE Latin1_General_100_BIN2 THEN -1
                            WHEN left_token.Identifier
                                     COLLATE Latin1_General_100_BIN2
                                   > right_token.Identifier
                                     COLLATE Latin1_General_100_BIN2 THEN 1
                            ELSE 0
                        END
                  )
        FROM LeftTokens AS left_token
        FULL OUTER JOIN RightTokens AS right_token
            ON right_token.Ordinal = left_token.Ordinal
    ),
    FirstTokenDifference AS
    (
        SELECT TOP (1) TokenResult
        FROM TokenPairs
        WHERE TokenResult <> 0
        ORDER BY Ordinal
    )
    SELECT ComparisonResult =
        CONVERT
        (
              smallint
            , CASE
                  WHEN compared.LeftIsValid = 0
                    OR compared.RightIsValid = 0
                      THEN NULL
                  WHEN compared.CoreResult <> 0
                      THEN compared.CoreResult
                  WHEN compared.LeftPreRelease IS NULL
                   AND compared.RightPreRelease IS NULL
                      THEN 0
                  WHEN compared.LeftPreRelease IS NULL
                      THEN 1
                  WHEN compared.RightPreRelease IS NULL
                      THEN -1
                  ELSE COALESCE(difference.TokenResult, 0)
              END
        )
    FROM CoreComparison AS compared
    OUTER APPLY
    (
        SELECT TokenResult
        FROM FirstTokenDifference
    ) AS difference
);
GO
-- ============================================================================
-- Objekt:       toolbelt_validation.TVF_SemanticVersionSortKey
-- Zweck:        Binären Sort Key für Semantic-Version-2.0.0 erzeugen
-- Resultset:    genau eine Zeile; SortKey varbinary(max)
-- Fehlerwert:   NULL bei ungültiger Eingabe
-- Performance:  kanonischer relationaler Kern für APPLY
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_validation].[TVF_SemanticVersionSortKey]
(
    @Version varchar(8000)
)
RETURNS TABLE
AS
RETURN
(
    WITH
    Digits (Digit) AS
    (
        SELECT Digit
        FROM
        (
            VALUES
                  (0), (1), (2), (3), (4)
                , (5), (6), (7), (8), (9)
        ) AS values_0_to_9(Digit)
    ),
    Positions (Position) AS
    (
        SELECT
            thousands.Digit * 1000
            + hundreds.Digit * 100
            + tens.Digit * 10
            + ones.Digit
            + 1
        FROM Digits AS thousands
        CROSS JOIN Digits AS hundreds
        CROSS JOIN Digits AS tens
        CROSS JOIN Digits AS ones
        WHERE thousands.Digit * 1000
              + hundreds.Digit * 100
              + tens.Digit * 10
              + ones.Digit < 8000
    ),
    Parsed AS
    (
        SELECT *
        FROM toolbelt_validation.TVF_ParseSemanticVersion(@Version)
    ),
    Tokens AS
    (
        SELECT
              Ordinal = ROW_NUMBER() OVER (ORDER BY positions.Position)
            , FragmentHex =
                  CONVERT
                  (
                        varchar(max)
                      , CASE
                            WHEN token.Identifier
                                     COLLATE Latin1_General_100_BIN2
                                     NOT LIKE '%[^0-9]%'
                                     COLLATE Latin1_General_100_BIN2
                                THEN
                                    '01'
                                    + CONVERT
                                      (
                                            varchar(4)
                                          , CONVERT
                                            (
                                                  binary(2)
                                                , CONVERT
                                                  (
                                                        smallint
                                                      , DATALENGTH
                                                        (
                                                            token.Identifier
                                                        )
                                                  )
                                            )
                                          , 2
                                      )
                                    + CONVERT
                                      (
                                            varchar(max)
                                          , CONVERT
                                            (
                                                  varbinary(max)
                                                , token.Identifier
                                            )
                                          , 2
                                      )
                                    + '00'
                            ELSE
                                '02'
                                + CONVERT
                                  (
                                        varchar(max)
                                      , CONVERT
                                        (
                                              varbinary(max)
                                            , token.Identifier
                                        )
                                      , 2
                                  )
                                + '00'
                        END
                  )
        FROM Parsed AS parsed
        CROSS JOIN Positions AS positions
        CROSS APPLY
        (
            SELECT NextDot = CHARINDEX
            (
                  '.'
                , parsed.PreRelease COLLATE Latin1_General_100_BIN2
                , positions.Position
            )
        ) AS boundary
        CROSS APPLY
        (
            SELECT Identifier =
                CASE
                    WHEN boundary.NextDot = 0
                        THEN SUBSTRING
                             (
                                   parsed.PreRelease
                                 , positions.Position
                                 , DATALENGTH(parsed.PreRelease)
                                   - positions.Position + 1
                             )
                    ELSE SUBSTRING
                         (
                               parsed.PreRelease
                             , positions.Position
                             , boundary.NextDot - positions.Position
                         )
                END
        ) AS token
        WHERE parsed.IsValid = 1
          AND parsed.PreRelease IS NOT NULL
          AND positions.Position <= DATALENGTH(parsed.PreRelease)
          AND
          (
              positions.Position = 1
              OR SUBSTRING
                 (
                       parsed.PreRelease
                     , positions.Position - 1
                     , 1
                 ) = '.'
          )
    ),
    TokenAggregate AS
    (
        SELECT TokenHex =
            STRING_AGG
            (
                  CONVERT(varchar(max), FragmentHex)
                , ''
            ) WITHIN GROUP (ORDER BY Ordinal)
        FROM Tokens
    ),
    KeyText AS
    (
        SELECT
              parsed.IsValid
            , KeyHex =
                  CONVERT
                  (
                        varchar(max)
                      , '01'
                        + CONVERT
                          (
                                varchar(4)
                              , CONVERT
                                (
                                      binary(2)
                                    , CONVERT
                                      (
                                            smallint
                                          , DATALENGTH(parsed.Major)
                                      )
                                )
                              , 2
                          )
                        + CONVERT
                          (
                                varchar(max)
                              , CONVERT(varbinary(max), parsed.Major)
                              , 2
                          )
                        + '00'
                        + '01'
                        + CONVERT
                          (
                                varchar(4)
                              , CONVERT
                                (
                                      binary(2)
                                    , CONVERT
                                      (
                                            smallint
                                          , DATALENGTH(parsed.Minor)
                                      )
                                )
                              , 2
                          )
                        + CONVERT
                          (
                                varchar(max)
                              , CONVERT(varbinary(max), parsed.Minor)
                              , 2
                          )
                        + '00'
                        + '01'
                        + CONVERT
                          (
                                varchar(4)
                              , CONVERT
                                (
                                      binary(2)
                                    , CONVERT
                                      (
                                            smallint
                                          , DATALENGTH(parsed.Patch)
                                      )
                                )
                              , 2
                          )
                        + CONVERT
                          (
                                varchar(max)
                              , CONVERT(varbinary(max), parsed.Patch)
                              , 2
                          )
                        + '00'
                        + CASE
                              WHEN parsed.PreRelease IS NULL
                                  THEN '02'
                              ELSE '01'
                                   + COALESCE(aggregate.TokenHex, '')
                                   + '00'
                          END
                  )
        FROM Parsed AS parsed
        CROSS JOIN TokenAggregate AS aggregate
    )
    SELECT SortKey =
        CASE
            WHEN IsValid = 0
                THEN CONVERT(varbinary(max), NULL)
            ELSE CONVERT(varbinary(max), KeyHex, 2)
        END
    FROM KeyText
);
GO
CREATE OR ALTER FUNCTION [toolbelt_validation].[SVF_CompareSemanticVersion]
(
      @LeftVersion  varchar(8000)
    , @RightVersion varchar(8000)
)
RETURNS smallint
AS
BEGIN
    DECLARE @ComparisonResult smallint;

    SELECT @ComparisonResult = compared.ComparisonResult
    FROM toolbelt_validation.TVF_CompareSemanticVersion
         (
               @LeftVersion
             , @RightVersion
         ) AS compared;

    RETURN @ComparisonResult;
END;
GO
CREATE OR ALTER FUNCTION [toolbelt_validation].[SVF_SemanticVersionSortKey]
(
    @Version varchar(8000)
)
RETURNS varbinary(max)
AS
BEGIN
    DECLARE @SortKey varbinary(max);

    SELECT @SortKey = sort_key.SortKey
    FROM toolbelt_validation.TVF_SemanticVersionSortKey(@Version) AS sort_key;

    RETURN @SortKey;
END;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    DECLARE
          @DeploymentMode      nvarchar(16)
        , @TargetVersion       nvarchar(64)
        , @VersionPropertyName sysname =
              N'Toolbelt.Module.toolbelt.validation.semantic-version.Version'
        , @ModePropertyName    sysname =
              N'Toolbelt.Module.toolbelt.validation.semantic-version.DeploymentMode';

    SELECT
          @DeploymentMode = DeploymentMode
        , @TargetVersion = TargetVersion
    FROM #tbx_SemanticVersionDeployState;

    IF XACT_STATE() <> 1
       OR OBJECT_ID(N'toolbelt_validation.TVF_ParseSemanticVersion', N'TF') IS NULL
       OR OBJECT_ID(N'toolbelt_validation.TVF_CompareSemanticVersion', N'IF') IS NULL
       OR OBJECT_ID(N'toolbelt_validation.TVF_SemanticVersionSortKey', N'IF') IS NULL
       OR OBJECT_ID(N'toolbelt_validation.SVF_CompareSemanticVersion', N'FN') IS NULL
       OR OBJECT_ID(N'toolbelt_validation.SVF_SemanticVersionSortKey', N'FN') IS NULL
    BEGIN
        THROW 51088, N'Die Framework-Funktionen wurden nicht vollständig innerhalb der Deployment-Transaktion angelegt.', 1;
    END;

    DECLARE @Objects TABLE
    (
          ObjectOrdinal int IDENTITY(1, 1) NOT NULL
        , ObjectName    sysname            NOT NULL
    );

    INSERT INTO @Objects (ObjectName)
    VALUES
          (N'TVF_ParseSemanticVersion')
        , (N'TVF_CompareSemanticVersion')
        , (N'TVF_SemanticVersionSortKey')
        , (N'SVF_CompareSemanticVersion')
        , (N'SVF_SemanticVersionSortKey');

    DECLARE
          @ObjectOrdinal int = 1
        , @ObjectCount   int = (SELECT COUNT(*) FROM @Objects)
        , @ObjectName    sysname
        , @ObjectId      int
        , @SourceHash    varchar(64)
        , @PropertyOrdinal int
        , @PropertyCount   int
        , @PropertyName    sysname
        , @PropertyValue   nvarchar(4000);

    DECLARE @Properties TABLE
    (
          PropertyOrdinal int            NOT NULL PRIMARY KEY
        , PropertyName    sysname        NOT NULL
        , PropertyValue   nvarchar(4000) NOT NULL
    );

    WHILE @ObjectOrdinal <= @ObjectCount
    BEGIN
        SELECT @ObjectName = ObjectName
        FROM @Objects
        WHERE ObjectOrdinal = @ObjectOrdinal;

        SET @ObjectId = OBJECT_ID
        (
            QUOTENAME(N'toolbelt_validation') + N'.' + QUOTENAME(@ObjectName)
        );
        SET @SourceHash = CONVERT
        (
              varchar(64)
            , HASHBYTES
              (
                  N'SHA2_256'
                , CONVERT(varbinary(max), OBJECT_DEFINITION(@ObjectId))
              )
            , 2
        );

        INSERT INTO @Properties
        (
              PropertyOrdinal
            , PropertyName
            , PropertyValue
        )
        VALUES
              (1, N'Toolbelt.ModuleId', N'toolbelt.validation.semantic-version')
            , (2, N'Toolbelt.ModuleVersion', @TargetVersion)
            , (3, N'Toolbelt.ContractVersion', N'1.0')
            , (4, N'Toolbelt.DeploymentMode', @DeploymentMode)
            , (5, N'Toolbelt.SourceHash', CONVERT(nvarchar(4000), @SourceHash));

        SET @PropertyOrdinal = 1;
        SET @PropertyCount = (SELECT COUNT(*) FROM @Properties);

        WHILE @PropertyOrdinal <= @PropertyCount
        BEGIN
            SELECT
                  @PropertyName = PropertyName
                , @PropertyValue = PropertyValue
            FROM @Properties
            WHERE PropertyOrdinal = @PropertyOrdinal;

            IF EXISTS
               (
                   SELECT 1
                   FROM sys.extended_properties AS ep
                   WHERE ep.class = 1
                     AND ep.major_id = @ObjectId
                     AND ep.minor_id = 0
                     AND ep.name = @PropertyName
               )
            BEGIN
                EXEC sys.sp_updateextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_validation'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;
            ELSE
            BEGIN
                EXEC sys.sp_addextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_validation'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;

            SET @PropertyOrdinal += 1;
        END;

        DELETE FROM @Properties;
        SET @ObjectOrdinal += 1;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @VersionPropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @ModePropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.validation.semantic-version
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.conversion.uri-component
:On Error exit
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @VersionProperty sysname=N'Toolbelt.Module.toolbelt.conversion.uri-component.Version',@ModeProperty sysname=N'Toolbelt.Module.toolbelt.conversion.uri-component.DeploymentMode',@DeploymentMode nvarchar(16)=LOWER(N'local'),@InstalledVersion nvarchar(64),@DependencyVersion nvarchar(64),@ProductMajorVersion int=TRY_CONVERT(int,SERVERPROPERTY(N'ProductMajorVersion'));
IF @ProductMajorVersion NOT IN(15,16,17) THROW 51220,N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.',1;
IF @DeploymentMode NOT IN(N'local',N'central') THROW 51221,N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.',1;
SELECT @DependencyVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=N'Toolbelt.Module.toolbelt.core.generate-series.Version';
IF @DependencyVersion<>N'1.0.0' OR OBJECT_ID(N'toolbelt_core.TVF_GenerateSeriesBigInt',N'IF') IS NULL THROW 51229,N'toolbelt.core.generate-series Version 1.0.0 muss vor diesem Modul in derselben Datenbank installiert sein.',1;
SELECT @InstalledVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty;
IF @InstalledVersion IS NOT NULL AND @InstalledVersion<>N'1.0.0' THROW 51223,N'Die installierte Modulversion ist diesem Deployment nicht bekannt.',1;
IF @InstalledVersion IS NULL AND EXISTS(SELECT 1 FROM sys.objects WHERE object_id IN(OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentEncode'),OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentDecode'),OBJECT_ID(N'toolbelt_conversion.SVF_UriComponentEncode'),OBJECT_ID(N'toolbelt_conversion.SVF_UriComponentDecode'))) THROW 51224,N'Ein Zielobjekt stammt nicht aus einem bekannten Toolbelt-Release.',1;
IF SCHEMA_ID(N'toolbelt_conversion') IS NOT NULL AND HAS_PERMS_BY_NAME(N'toolbelt_conversion',N'SCHEMA',N'ALTER')<>1 THROW 51222,N'Für toolbelt_conversion fehlt ALTER.',1;
IF HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE FUNCTION')<>1 THROW 51222,N'In der Installationsdatenbank fehlt CREATE FUNCTION.',1;
IF OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentEncodeStatus') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentEncodeStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(256),value)=N'toolbelt.conversion.uri-component') THROW 51224,N'Neuer Security-Zielname ist frameworkfremd belegt.',1;
IF OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentDecodeStatus') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentDecodeStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(256),value)=N'toolbelt.conversion.uri-component') THROW 51224,N'Neuer Security-Zielname ist frameworkfremd belegt.',1;
BEGIN TRANSACTION;
DECLARE @LockResult int;
EXEC @LockResult=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.conversion.uri-component',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
IF @LockResult<0 THROW 51227,N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.',1;
IF SCHEMA_ID(N'toolbelt_conversion') IS NULL
BEGIN
 EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_conversion];';
 EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_conversion';
 EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'conversion',@level0type=N'SCHEMA',@level0name=N'toolbelt_conversion';
END;
GO
-- ============================================================================
-- Objekt:          toolbelt_conversion.TVF_UriComponentEncodeStatus
-- Zweck:           Begrenzter kanonischer Statuskern; Legacy-Wertfassade unten.
-- Parameter:       @Value nvarchar(max)
-- Resultset:       EncodedValue nvarchar(max), Status varchar(16)
-- Vertrag:         Documentation/TVF_UriComponentEncodeStatus.md
-- Versionen:       SQL Server 2019/2022/2025; Windows/Linux
-- Rechte:          SELECT/REFERENCES; keine zusätzlichen Rechte oder Grants.
-- Performance:     MSTVF mit Vorabgrenzen; keine Inline-/Parallelitätszusage.
-- Grenzen:         Freigegebener Vertrag SECURITY_HARDENING_2026_10.md.
-- ============================================================================
CREATE OR ALTER FUNCTION [toolbelt_conversion].[TVF_UriComponentEncodeStatus](@Value nvarchar(max))
RETURNS @Result TABLE(EncodedValue nvarchar(max) NULL,Status varchar(16) NOT NULL) AS
BEGIN
    IF @Value IS NULL BEGIN INSERT @Result VALUES(NULL,'SQL_NULL'); RETURN; END;
    IF DATALENGTH(@Value)>65536 BEGIN INSERT @Result VALUES(NULL,'LIMIT'); RETURN; END;
    DECLARE @Output nvarchar(max);
    WITH Utf8 AS
    (
        SELECT Bytes = CONVERT
        (
            varbinary(max),
            CONVERT
            (
                varchar(max),
                @Value COLLATE Latin1_General_100_BIN2_UTF8
            )
        )
    ),
    Encoded AS
    (
        SELECT EncodedValue = STRING_AGG(CONVERT(varchar(max), CASE
            WHEN SUBSTRING(utf8.Bytes, positions.Value, 1) BETWEEN 0x41 AND 0x5A
              OR SUBSTRING(utf8.Bytes, positions.Value, 1) BETWEEN 0x61 AND 0x7A
              OR SUBSTRING(utf8.Bytes, positions.Value, 1) BETWEEN 0x30 AND 0x39
              OR SUBSTRING(utf8.Bytes, positions.Value, 1) IN (0x2D,0x2E,0x5F,0x7E)
                THEN CONVERT(varchar(1), SUBSTRING(utf8.Bytes, positions.Value, 1)) COLLATE Latin1_General_100_BIN2
            ELSE '%' + UPPER(SUBSTRING(master.dbo.fn_varbintohexstr(SUBSTRING(utf8.Bytes, positions.Value, 1)), 3, 2)) END), '') WITHIN GROUP (ORDER BY positions.Value)
        FROM Utf8 AS utf8
        CROSS APPLY toolbelt_core.TVF_GenerateSeriesBigInt(1, CONVERT(bigint, DATALENGTH(utf8.Bytes)), 1) AS positions
    )
    SELECT @Output = CASE WHEN @Value IS NULL THEN CONVERT(nvarchar(max),NULL) ELSE CONVERT(nvarchar(max),COALESCE(encoded.EncodedValue,'')) END
    FROM Encoded AS encoded;
    IF DATALENGTH(@Output)>1048576 INSERT @Result VALUES(NULL,'LIMIT'); ELSE INSERT @Result VALUES(@Output,'OK');
    RETURN;
END;
GO
-- Legacy-Wertfassade: gleicher Inputvertrag; Limitabbildung siehe Objektseite.
-- Vertrag: Documentation/TVF_UriComponentEncode.md
CREATE OR ALTER FUNCTION [toolbelt_conversion].[TVF_UriComponentEncode](@Value nvarchar(max))
RETURNS TABLE AS RETURN
(SELECT EncodedValue FROM toolbelt_conversion.TVF_UriComponentEncodeStatus(@Value));
GO
-- ============================================================================
-- Objekt:          toolbelt_conversion.TVF_UriComponentDecodeStatus
-- Zweck:           Begrenzter kanonischer Statuskern; Legacy-Wertfassade unten.
-- Parameter:       @Value nvarchar(max)
-- Resultset:       DecodedValue nvarchar(max), IsValid bit, ValidationCode tinyint, Status varchar(16)
-- Vertrag:         Documentation/TVF_UriComponentDecodeStatus.md
-- Versionen:       SQL Server 2019/2022/2025; Windows/Linux
-- Rechte:          SELECT/REFERENCES; keine zusätzlichen Rechte oder Grants.
-- Performance:     MSTVF mit Vorabgrenzen; keine Inline-/Parallelitätszusage.
-- Grenzen:         Freigegebener Vertrag SECURITY_HARDENING_2026_10.md.
-- ============================================================================
CREATE OR ALTER FUNCTION [toolbelt_conversion].[TVF_UriComponentDecodeStatus](@Value nvarchar(max))
RETURNS @Result TABLE(DecodedValue nvarchar(max) NULL,IsValid bit NULL,ValidationCode tinyint NULL,Status varchar(16) NOT NULL) AS
BEGIN
    IF @Value IS NULL BEGIN INSERT @Result VALUES(NULL,NULL,NULL,'SQL_NULL'); RETURN; END;
    IF DATALENGTH(@Value)>65536 BEGIN INSERT @Result VALUES(NULL,0,14,'LIMIT'); RETURN; END;
    DECLARE @Output nvarchar(max),@Valid bit,@Code tinyint;
    WITH Parameters AS
    (
        SELECT InputLength = CONVERT(bigint,DATALENGTH(@Value)/2)
    ),
    Positions AS
    (
        SELECT positions.Value
        FROM Parameters AS parameters
        CROSS APPLY toolbelt_core.TVF_GenerateSeriesBigInt(1,parameters.InputLength,1) AS positions
    ),
    Validation AS
    (
        SELECT
              HasNonAscii=CONVERT(bit,MAX(CASE WHEN UNICODE(SUBSTRING(@Value COLLATE Latin1_General_100_BIN2,positions.Value,1))>127 THEN 1 ELSE 0 END))
            , HasInvalidPercent=CONVERT(bit,MAX(CASE WHEN SUBSTRING(@Value,positions.Value,1)=N'%' AND (positions.Value+2>parameters.InputLength OR SUBSTRING(@Value,positions.Value+1,1) COLLATE Latin1_General_100_BIN2 NOT LIKE N'[0-9A-Fa-f]' OR SUBSTRING(@Value,positions.Value+2,1) COLLATE Latin1_General_100_BIN2 NOT LIKE N'[0-9A-Fa-f]') THEN 1 ELSE 0 END))
        FROM Parameters AS parameters LEFT JOIN Positions AS positions ON 1=1
    ),
    Bytes AS
    (
        SELECT HexValue=STRING_AGG(CONVERT(varchar(max),CASE
          WHEN SUBSTRING(@Value,positions.Value,1)=N'%'
           AND positions.Value+2<=parameters.InputLength
           AND SUBSTRING(@Value,positions.Value+1,1) COLLATE Latin1_General_100_BIN2 LIKE N'[0-9A-Fa-f]'
           AND SUBSTRING(@Value,positions.Value+2,1) COLLATE Latin1_General_100_BIN2 LIKE N'[0-9A-Fa-f]'
              THEN CONVERT(varchar(2),SUBSTRING(@Value,positions.Value+1,2))
          WHEN SUBSTRING(@Value,positions.Value,1)=N'%' THEN '00'
          ELSE SUBSTRING('0123456789ABCDEF',UNICODE(SUBSTRING(@Value,positions.Value,1))/16+1,1)+SUBSTRING('0123456789ABCDEF',UNICODE(SUBSTRING(@Value,positions.Value,1))%16+1,1) END),'') WITHIN GROUP(ORDER BY positions.Value)
        FROM Parameters AS parameters CROSS APPLY Positions AS positions
        WHERE NOT (positions.Value>1 AND SUBSTRING(@Value,positions.Value-1,1)=N'%' AND positions.Value+1<=parameters.InputLength AND SUBSTRING(@Value,positions.Value,1) COLLATE Latin1_General_100_BIN2 LIKE N'[0-9A-Fa-f]' AND SUBSTRING(@Value,positions.Value+1,1) COLLATE Latin1_General_100_BIN2 LIKE N'[0-9A-Fa-f]')
          AND NOT (positions.Value>2 AND SUBSTRING(@Value,positions.Value-2,1)=N'%' AND SUBSTRING(@Value,positions.Value-1,1) COLLATE Latin1_General_100_BIN2 LIKE N'[0-9A-Fa-f]' AND SUBSTRING(@Value,positions.Value,1) COLLATE Latin1_General_100_BIN2 LIKE N'[0-9A-Fa-f]')
    ),
    BinaryData AS
    (
        SELECT
              BinaryValue=CONVERT(varbinary(max),CONCAT('0x',COALESCE(bytes.HexValue,'')),1)
            , ByteLength=CONVERT(bigint,DATALENGTH(CONVERT(varbinary(max),CONCAT('0x',COALESCE(bytes.HexValue,'')),1)))
        FROM Bytes AS bytes
    ),
    Octets AS
    (
        SELECT
              Position=positions.Value
            , data.ByteLength
            , FirstByte=CONVERT(int,SUBSTRING(data.BinaryValue,positions.Value,1))
            , SecondByte=CONVERT(int,SUBSTRING(data.BinaryValue,positions.Value+1,1))
            , ThirdByte=CONVERT(int,SUBSTRING(data.BinaryValue,positions.Value+2,1))
            , FourthByte=CONVERT(int,SUBSTRING(data.BinaryValue,positions.Value+3,1))
        FROM BinaryData AS data
        CROSS APPLY toolbelt_core.TVF_GenerateSeriesBigInt(1,data.ByteLength,1) AS positions
    ),
    ValidSequences AS
    (
        SELECT
              StartPosition=octets.Position
            , SequenceLength=CONVERT(tinyint,CASE
                WHEN octets.FirstByte<=127 THEN 1
                WHEN octets.FirstByte<=223 THEN 2
                WHEN octets.FirstByte<=239 THEN 3
                ELSE 4 END)
            , CodePoint=CONVERT(int,CASE
                WHEN octets.FirstByte<=127 THEN octets.FirstByte
                WHEN octets.FirstByte<=223 THEN
                    (octets.FirstByte-192)*64+(octets.SecondByte-128)
                WHEN octets.FirstByte<=239 THEN
                    (octets.FirstByte-224)*4096
                    +(octets.SecondByte-128)*64
                    +(octets.ThirdByte-128)
                ELSE
                    (octets.FirstByte-240)*262144
                    +(octets.SecondByte-128)*4096
                    +(octets.ThirdByte-128)*64
                    +(octets.FourthByte-128) END)
        FROM Octets AS octets
        WHERE octets.FirstByte<=127
           OR
              (
                  octets.FirstByte BETWEEN 194 AND 223
                  AND octets.Position+1<=octets.ByteLength
                  AND octets.SecondByte BETWEEN 128 AND 191
              )
           OR
              (
                  octets.FirstByte BETWEEN 224 AND 239
                  AND octets.Position+2<=octets.ByteLength
                  AND octets.ThirdByte BETWEEN 128 AND 191
                  AND
                  (
                      (octets.FirstByte=224 AND octets.SecondByte BETWEEN 160 AND 191)
                      OR (octets.FirstByte BETWEEN 225 AND 236 AND octets.SecondByte BETWEEN 128 AND 191)
                      OR (octets.FirstByte=237 AND octets.SecondByte BETWEEN 128 AND 159)
                      OR (octets.FirstByte BETWEEN 238 AND 239 AND octets.SecondByte BETWEEN 128 AND 191)
                  )
              )
           OR
              (
                  octets.FirstByte BETWEEN 240 AND 244
                  AND octets.Position+3<=octets.ByteLength
                  AND octets.ThirdByte BETWEEN 128 AND 191
                  AND octets.FourthByte BETWEEN 128 AND 191
                  AND
                  (
                      (octets.FirstByte=240 AND octets.SecondByte BETWEEN 144 AND 191)
                      OR (octets.FirstByte BETWEEN 241 AND 243 AND octets.SecondByte BETWEEN 128 AND 191)
                      OR (octets.FirstByte=244 AND octets.SecondByte BETWEEN 128 AND 143)
                  )
              )
    ),
    Decoded AS
    (
        SELECT
              TextValue=CONVERT(nvarchar(max),COALESCE
              (
                  STRING_AGG
                  (
                      CASE
                          WHEN sequences.CodePoint<=65535
                              THEN CONVERT(nvarchar(max),NCHAR(sequences.CodePoint))
                          ELSE
                              CONVERT(nvarchar(max),NCHAR(55296+(sequences.CodePoint-65536)/1024))
                              +CONVERT(nvarchar(max),NCHAR(56320+(sequences.CodePoint-65536)%1024))
                      END,
                      N''
                  ) WITHIN GROUP(ORDER BY sequences.StartPosition),
                  N''
              ))
            , IsUtf8=CONVERT(bit,CASE
                WHEN COALESCE(SUM(CONVERT(bigint,sequences.SequenceLength)),0)=data.ByteLength
                    THEN 1 ELSE 0 END)
            , HasNul=CONVERT(bit,COALESCE(MAX(CASE WHEN sequences.CodePoint=0 THEN 1 ELSE 0 END),0))
        FROM BinaryData AS data
        LEFT JOIN ValidSequences AS sequences ON 1=1
        GROUP BY data.ByteLength
    )
    SELECT
          @Output=CONVERT(nvarchar(max),CASE WHEN @Value IS NULL OR validation.HasNonAscii=1 OR validation.HasInvalidPercent=1 OR decoded.IsUtf8=0 OR decoded.HasNul=1 THEN NULL ELSE decoded.TextValue END)
        , @Valid=CONVERT(bit,CASE WHEN @Value IS NULL THEN NULL WHEN validation.HasNonAscii=1 OR validation.HasInvalidPercent=1 OR decoded.IsUtf8=0 OR decoded.HasNul=1 THEN 0 ELSE 1 END)
        , @Code=CONVERT(tinyint,CASE WHEN @Value IS NULL THEN NULL WHEN validation.HasNonAscii=1 THEN 10 WHEN validation.HasInvalidPercent=1 THEN 11 WHEN decoded.IsUtf8=0 THEN 12 WHEN decoded.HasNul=1 THEN 13 ELSE 0 END)
    FROM Validation AS validation CROSS JOIN Decoded AS decoded;
    IF DATALENGTH(@Output)>1048576 INSERT @Result VALUES(NULL,0,14,'LIMIT'); ELSE INSERT @Result VALUES(@Output,@Valid,@Code,CASE WHEN @Valid=1 THEN 'OK' ELSE 'INVALID' END);
    RETURN;
END;
GO
-- Legacy-Wertfassade: gleicher Inputvertrag; Limitabbildung siehe Objektseite.
-- Vertrag: Documentation/TVF_UriComponentDecode.md
CREATE OR ALTER FUNCTION [toolbelt_conversion].[TVF_UriComponentDecode](@Value nvarchar(max))
RETURNS TABLE AS RETURN
(SELECT DecodedValue,IsValid,ValidationCode FROM toolbelt_conversion.TVF_UriComponentDecodeStatus(@Value));
GO
CREATE OR ALTER FUNCTION [toolbelt_conversion].[SVF_UriComponentEncode](@Value nvarchar(max))
RETURNS nvarchar(max)
AS
BEGIN
 DECLARE @Result nvarchar(max);
 SELECT @Result=encoded.EncodedValue FROM toolbelt_conversion.TVF_UriComponentEncode(@Value) AS encoded;
 RETURN @Result;
END;
GO
CREATE OR ALTER FUNCTION [toolbelt_conversion].[SVF_UriComponentDecode](@Value nvarchar(max))
RETURNS nvarchar(max)
AS
BEGIN
 DECLARE @Result nvarchar(max);
 SELECT @Result=decoded.DecodedValue FROM toolbelt_conversion.TVF_UriComponentDecode(@Value) AS decoded;
 RETURN @Result;
END;
GO
SET NOCOUNT ON;
BEGIN TRY
 DECLARE @VersionProperty sysname=N'Toolbelt.Module.toolbelt.conversion.uri-component.Version',@ModeProperty sysname=N'Toolbelt.Module.toolbelt.conversion.uri-component.DeploymentMode';
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty) EXEC sys.sp_updateextendedproperty @name=@VersionProperty,@value=N'1.0.0'; ELSE EXEC sys.sp_addextendedproperty @name=@VersionProperty,@value=N'1.0.0';
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@ModeProperty) EXEC sys.sp_updateextendedproperty @name=@ModeProperty,@value=N'local'; ELSE EXEC sys.sp_addextendedproperty @name=@ModeProperty,@value=N'local';
IF NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentEncodeStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId') EXEC sys.sp_addextendedproperty @name=N'Toolbelt.ModuleId',@value=N'toolbelt.conversion.uri-component',@level0type=N'SCHEMA',@level0name=N'toolbelt_conversion',@level1type=N'FUNCTION',@level1name=N'TVF_UriComponentEncodeStatus';
IF NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentDecodeStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId') EXEC sys.sp_addextendedproperty @name=N'Toolbelt.ModuleId',@value=N'toolbelt.conversion.uri-component',@level0type=N'SCHEMA',@level0name=N'toolbelt_conversion',@level1type=N'FUNCTION',@level1name=N'TVF_UriComponentDecodeStatus';
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.conversion.uri-component
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.core.error-envelope
-- Deployment für toolbelt.core.error-envelope
:on error exit

SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

DECLARE @DeploymentMode nvarchar(16) = LOWER(N'local');
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 51411, N'DeploymentMode muss local oder central sein.', 1;

IF SCHEMA_ID(N'toolbelt_core') IS NULL
    EXEC(N'CREATE SCHEMA [toolbelt_core] AUTHORIZATION [dbo];');


IF OBJECT_ID(N'toolbelt_core.USP_CaptureErrorEnvelope', N'P') IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM sys.extended_properties AS ep
           WHERE ep.class = 1
             AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_CaptureErrorEnvelope')
             AND ep.minor_id = 0
             AND ep.name = N'Toolbelt.ModuleId'
             AND CONVERT(nvarchar(256), ep.value) = N'toolbelt.core.error-envelope'
       )
BEGIN
    THROW 51410, N'Der Zielname toolbelt_core.USP_CaptureErrorEnvelope ist bereits durch ein frameworkfremdes Objekt belegt.', 1;
END;
GO

BEGIN TRANSACTION;
GO
-- ============================================================================
-- Objekt: toolbelt_core.USP_CaptureErrorEnvelope
-- Zweck: Standardisiert explizit aus einem CATCH übergebene Fehlerdaten.
-- ============================================================================
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_core].[USP_CaptureErrorEnvelope]
(
      @ErrorNumber       int             = NULL
    , @ErrorSeverity     int             = NULL
    , @ErrorState        int             = NULL
    , @ErrorProcedure    nvarchar(776)   = NULL
    , @ErrorLine         int             = NULL
    , @ErrorMessage      nvarchar(4000)  = NULL
    , @ExecutionId       uniqueidentifier = NULL
    , @AdditionalContext nvarchar(4000)  = NULL
    , @ResultTable       sysname         = NULL
    , @KeepData          bit             = 0
    , @Debug             tinyint         = 0
    , @Hilfe             bit             = 0
)
AS
BEGIN
    SET NOCOUNT ON;

    SET @KeepData = ISNULL(@KeepData, 0);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    IF @Hilfe = 1
    BEGIN
        SELECT
              CAST('1.0' AS varchar(16)) AS HelpContractVersion
            , CAST(N'toolbelt_core' AS sysname) AS SchemaName
            , CAST(N'USP_CaptureErrorEnvelope' AS sysname) AS ObjectName
            , v.Section
            , v.Ordinal
            , v.ItemName
            , v.SqlDataType
            , v.IsRequired
            , v.IsNullable
            , v.DefaultValue
            , v.Description
            , v.ExampleSql
        FROM
        (
            VALUES
              (CAST('DESCRIPTION' AS varchar(32)), 1, CAST(NULL AS sysname), CAST(NULL AS varchar(256)), CAST(NULL AS bit), CAST(NULL AS bit), CAST(NULL AS nvarchar(4000)), CAST(N'Erzeugt aus explizit im aufrufenden CATCH gelesenen ERROR_*-Werten genau eine standardisierte Fehlerzeile. Die Procedure führt keinen Rethrow aus; der Aufrufer verwendet anschließend THROW; im ursprünglichen CATCH.' AS nvarchar(max)), CAST(NULL AS nvarchar(max)))
            , ('PARAMETER', 1, N'@ErrorNumber', 'int', 1, 0, NULL, N'ERROR_NUMBER() aus dem aufrufenden CATCH.', NULL)
            , ('PARAMETER', 2, N'@ErrorSeverity', 'int', 1, 0, NULL, N'ERROR_SEVERITY() aus dem aufrufenden CATCH.', NULL)
            , ('PARAMETER', 3, N'@ErrorState', 'int', 1, 0, NULL, N'ERROR_STATE() aus dem aufrufenden CATCH.', NULL)
            , ('PARAMETER', 4, N'@ErrorProcedure', 'nvarchar(776)', 0, 1, NULL, N'ERROR_PROCEDURE() aus dem aufrufenden CATCH.', NULL)
            , ('PARAMETER', 5, N'@ErrorLine', 'int', 0, 1, NULL, N'ERROR_LINE() aus dem aufrufenden CATCH.', NULL)
            , ('PARAMETER', 6, N'@ErrorMessage', 'nvarchar(4000)', 1, 0, NULL, N'ERROR_MESSAGE() aus dem aufrufenden CATCH.', NULL)
            , ('PARAMETER', 7, N'@ExecutionId', 'uniqueidentifier', 0, 1, NULL, N'Optionale Execution-ID; NULL liest den aktiven Toolbelt Execution Context.', NULL)
            , ('PARAMETER', 8, N'@AdditionalContext', 'nvarchar(4000)', 0, 1, NULL, N'Optionale synthetische oder bereits bereinigte Zusatzinformation.', NULL)
            , ('PARAMETER', 9, N'@ResultTable', 'sysname', 0, 1, NULL, N'Optionale lokale Temp-Tabelle für das Ergebnis.', NULL)
            , ('PARAMETER', 10, N'@KeepData', 'bit', 0, 1, N'0', N'Steuert die ResultTable-Vorbereitung.', NULL)
            , ('PARAMETER', 11, N'@Debug', 'tinyint', 0, 1, N'0', N'Erzeugt bei Werten größer 0 eine abstrakte Informationsmeldung.', NULL)
            , ('PARAMETER', 12, N'@Hilfe', 'bit', 0, 1, N'0', N'1 gibt ausschließlich dieses Help-Resultset aus.', NULL)
            , ('RESULT_COLUMN', 1, N'CapturedAtUtc', 'datetime2(7)', 0, 0, NULL, N'UTC-Zeitpunkt der Erfassung.', NULL)
            , ('RESULT_COLUMN', 2, N'ExecutionId', 'uniqueidentifier', 0, 1, NULL, N'Explizite oder aus SESSION_CONTEXT gelesene Execution-ID.', NULL)
            , ('RESULT_COLUMN', 3, N'ErrorClass', 'varchar(16)', 0, 0, NULL, N'ENGINE, TOOLBELT oder USER.', NULL)
            , ('ERROR', 1, N'51400-51405', NULL, NULL, NULL, NULL, N'Validierungs- und Dependencyfehler des Moduls.', NULL)
            , ('ERROR', 2, N'51406', NULL, NULL, NULL, NULL, N'ResultTable-Ausgabe bei XACT_STATE()=-1 wird vor jeder Schreiboperation abgewiesen. Direkte Ausgabe bleibt lesend möglich.', NULL)
            , ('EXAMPLE', 1, NULL, NULL, NULL, NULL, NULL, N'Aufruf innerhalb eines CATCH mit anschließendem unverändertem THROW.', N'BEGIN CATCH EXEC toolbelt_core.USP_CaptureErrorEnvelope @ErrorNumber=ERROR_NUMBER(), @ErrorSeverity=ERROR_SEVERITY(), @ErrorState=ERROR_STATE(), @ErrorProcedure=ERROR_PROCEDURE(), @ErrorLine=ERROR_LINE(), @ErrorMessage=ERROR_MESSAGE(); THROW; END CATCH;')
        ) AS v(Section, Ordinal, ItemName, SqlDataType, IsRequired, IsNullable, DefaultValue, Description, ExampleSql)
        ORDER BY CASE v.Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2 WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 ELSE 5 END, v.Ordinal;
        RETURN 0;
    END;

    IF @ErrorNumber IS NULL OR @ErrorNumber <= 0
        THROW 51400, N'@ErrorNumber muss eine positive Fehlernummer enthalten.', 1;
    IF @ErrorSeverity IS NULL OR @ErrorSeverity NOT BETWEEN 0 AND 25
        THROW 51401, N'@ErrorSeverity muss zwischen 0 und 25 liegen.', 1;
    IF @ErrorState IS NULL OR @ErrorState NOT BETWEEN 0 AND 255
        THROW 51402, N'@ErrorState muss zwischen 0 und 255 liegen.', 1;
    IF @ErrorLine IS NOT NULL AND @ErrorLine <= 0
        THROW 51403, N'@ErrorLine muss NULL oder positiv sein.', 1;
    IF NULLIF(@ErrorMessage, N'') IS NULL
        THROW 51404, N'@ErrorMessage darf nicht leer sein.', 1;

    IF @ExecutionId IS NULL
        SET @ExecutionId = TRY_CONVERT(uniqueidentifier, SESSION_CONTEXT(N'toolbelt.execution.id'));

    -- Ein doomed Caller darf für die direkte Fehlerausgabe weder Temp-DDL
    -- noch INSERT ausführen. Typen/Nullability entsprechen dem bisherigen Schema.
    IF @ResultTable IS NULL
    BEGIN
        IF @Debug > 0
            RAISERROR(N'USP_CaptureErrorEnvelope: eine standardisierte Fehlerzeile wurde erzeugt.', 10, 1) WITH NOWAIT;
        SELECT ISNULL(CONVERT(datetime2(7),SYSUTCDATETIME()),CONVERT(datetime2(7),'20000101')) AS CapturedAtUtc,
            @ExecutionId AS ExecutionId,
            ISNULL(CONVERT(varchar(16),CASE WHEN @ErrorNumber BETWEEN 51000 AND 51999 THEN 'TOOLBELT' WHEN @ErrorNumber<50000 THEN 'ENGINE' ELSE 'USER' END),'USER') AS ErrorClass,
            ISNULL(@ErrorNumber,0) AS ErrorNumber, ISNULL(@ErrorSeverity,0) AS ErrorSeverity,
            ISNULL(@ErrorState,0) AS ErrorState, @ErrorProcedure AS ErrorProcedure,
            @ErrorLine AS ErrorLine, ISNULL(@ErrorMessage,N'') AS ErrorMessage,
            ISNULL(CONVERT(smallint,XACT_STATE()),CONVERT(smallint,0)) AS XactState, ISNULL(@@TRANCOUNT,0) AS TransactionCount,
            ISNULL(DB_NAME(),CONVERT(sysname,N'')) AS DatabaseName, ISNULL(CONVERT(int,@@SPID),0) AS SessionId,
            @AdditionalContext AS AdditionalContext;
        RETURN 0;
    END;
    IF XACT_STATE()=-1
        THROW 51406,N'ResultTable-Ausgabe erfordert zuerst den Rollback des uncommittable Callers.',1;

    CREATE TABLE #tbx_ErrorEnvelopeShape
    (
          CapturedAtUtc    datetime2(7)    NOT NULL
        , ExecutionId      uniqueidentifier NULL
        , ErrorClass       varchar(16)     NOT NULL
        , ErrorNumber      int             NOT NULL
        , ErrorSeverity    int             NOT NULL
        , ErrorState       int             NOT NULL
        , ErrorProcedure   nvarchar(776)   NULL
        , ErrorLine        int             NULL
        , ErrorMessage     nvarchar(4000)  NOT NULL
        , XactState        smallint        NOT NULL
        , TransactionCount int             NOT NULL
        , DatabaseName     sysname         NOT NULL
        , SessionId        int             NOT NULL
        , AdditionalContext nvarchar(4000) NULL
    );

    CREATE TABLE #tbx_ErrorEnvelopeResult
    (
          CapturedAtUtc    datetime2(7)    NOT NULL
        , ExecutionId      uniqueidentifier NULL
        , ErrorClass       varchar(16)     NOT NULL
        , ErrorNumber      int             NOT NULL
        , ErrorSeverity    int             NOT NULL
        , ErrorState       int             NOT NULL
        , ErrorProcedure   nvarchar(776)   NULL
        , ErrorLine        int             NULL
        , ErrorMessage     nvarchar(4000)  NOT NULL
        , XactState        smallint        NOT NULL
        , TransactionCount int             NOT NULL
        , DatabaseName     sysname         NOT NULL
        , SessionId        int             NOT NULL
        , AdditionalContext nvarchar(4000) NULL
    );

    INSERT INTO #tbx_ErrorEnvelopeResult
    (
          CapturedAtUtc, ExecutionId, ErrorClass, ErrorNumber, ErrorSeverity
        , ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, XactState
        , TransactionCount, DatabaseName, SessionId, AdditionalContext
    )
    VALUES
    (
          SYSUTCDATETIME()
        , @ExecutionId
        , CASE WHEN @ErrorNumber BETWEEN 51000 AND 51999 THEN 'TOOLBELT'
               WHEN @ErrorNumber < 50000 THEN 'ENGINE'
               ELSE 'USER' END
        , @ErrorNumber, @ErrorSeverity, @ErrorState, @ErrorProcedure
        , @ErrorLine, @ErrorMessage, CONVERT(smallint, XACT_STATE())
        , @@TRANCOUNT, DB_NAME(), @@SPID, @AdditionalContext
    );

    IF @Debug > 0
        RAISERROR(N'USP_CaptureErrorEnvelope: eine standardisierte Fehlerzeile wurde erzeugt.', 10, 1) WITH NOWAIT;

    IF OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable', N'P') IS NULL
        THROW 51405, N'Für @ResultTable fehlt toolbelt.core.result-table.', 1;

    EXEC toolbelt_core.USP_PrepareResultTable
          @ResultTableToAlter = @ResultTable
        , @LikeTable = N'#tbx_ErrorEnvelopeShape'
        , @KeepData = @KeepData;

    DECLARE @InsertSql nvarchar(max) =
        N'INSERT INTO ' + QUOTENAME(@ResultTable)
        + N' (CapturedAtUtc, ExecutionId, ErrorClass, ErrorNumber, ErrorSeverity, ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, XactState, TransactionCount, DatabaseName, SessionId, AdditionalContext)'
        + N' SELECT CapturedAtUtc, ExecutionId, ErrorClass, ErrorNumber, ErrorSeverity, ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, XactState, TransactionCount, DatabaseName, SessionId, AdditionalContext FROM #tbx_ErrorEnvelopeResult;';
    EXEC sys.sp_executesql @InsertSql;
    RETURN 0;
END;
GO
GO

DECLARE @DeploymentMode nvarchar(16) = LOWER(N'local');

IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_CaptureErrorEnvelope')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleId'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.error-envelope'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_CaptureErrorEnvelope';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleId'
        , @value = N'toolbelt.core.error-envelope'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_CaptureErrorEnvelope';
END;

IF EXISTS
   (
       SELECT 1
       FROM sys.extended_properties AS ep
       WHERE ep.class = 1
         AND ep.major_id = OBJECT_ID(N'toolbelt_core.USP_CaptureErrorEnvelope')
         AND ep.minor_id = 0
         AND ep.name = N'Toolbelt.ModuleVersion'
   )
BEGIN
    EXEC sys.sp_updateextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_CaptureErrorEnvelope';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty
          @name = N'Toolbelt.ModuleVersion'
        , @value = N'1.0.0'
        , @level0type = N'SCHEMA'
        , @level0name = N'toolbelt_core'
        , @level1type = N'PROCEDURE'
        , @level1name = N'USP_CaptureErrorEnvelope';
END;

DECLARE @VersionProperty sysname = N'Toolbelt.Module.toolbelt.core.error-envelope.Version';
DECLARE @ModeProperty sysname = N'Toolbelt.Module.toolbelt.core.error-envelope.DeploymentMode';
IF EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 0 AND name = @VersionProperty)
    EXEC sys.sp_updateextendedproperty @name = @VersionProperty, @value = N'1.0.0';
ELSE
    EXEC sys.sp_addextendedproperty @name = @VersionProperty, @value = N'1.0.0';

IF EXISTS (SELECT 1 FROM sys.extended_properties WHERE class = 0 AND name = @ModeProperty)
    EXEC sys.sp_updateextendedproperty @name = @ModeProperty, @value = @DeploymentMode;
ELSE
    EXEC sys.sp_addextendedproperty @name = @ModeProperty, @value = @DeploymentMode;

COMMIT TRANSACTION;
GO
GO
-- END MODULE toolbelt.core.error-envelope
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.datetime.date-spine
:On Error exit

-- ============================================================================
-- Zweck:     Erst- und Wiederholungsdeployment
-- Modul:     toolbelt.datetime.date-spine v1.0.0
-- Schema:    toolbelt_datetime
-- Erfordert: SQL Server 2019, 2022 oder 2025; Generate Series 1.0.0;
--            Datetime Truncate 1.0.0
-- Modus:     SQLCMD; Ausführung aus diesem Deployment-Verzeichnis
-- Parameter: DeploymentMode=local|central
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'tempdb..#tbx_DateSpineReleaseObjects', N'U') IS NOT NULL
    DROP TABLE #tbx_DateSpineReleaseObjects;
IF OBJECT_ID(N'tempdb..#tbx_DateSpineDeployState', N'U') IS NOT NULL
    DROP TABLE #tbx_DateSpineDeployState;

CREATE TABLE #tbx_DateSpineReleaseObjects
(
      ReleaseVersion nvarchar(64) NOT NULL
    , SchemaName     sysname      NOT NULL
    , ObjectName     sysname      NOT NULL
    , ObjectType     char(2)      NOT NULL
    , CONSTRAINT PK_tbx_DateSpineReleaseObjects
          PRIMARY KEY (ReleaseVersion, SchemaName, ObjectName)
);

INSERT INTO #tbx_DateSpineReleaseObjects
    (ReleaseVersion, SchemaName, ObjectName, ObjectType)
VALUES
      (N'1.0.0', N'toolbelt_datetime', N'TVF_DateSpineCore', 'IF')
    , (N'1.0.0', N'toolbelt_datetime', N'TVF_DateSpineDay', 'IF')
    , (N'1.0.0', N'toolbelt_datetime', N'TVF_DateSpineIsoWeek', 'IF')
    , (N'1.0.0', N'toolbelt_datetime', N'TVF_DateSpineMonth', 'IF');

CREATE TABLE #tbx_DateSpineDeployState
(
      TargetVersion    nvarchar(64) NOT NULL
    , InstalledVersion nvarchar(64) NULL
    , DeploymentMode   nvarchar(16) NOT NULL
);

DECLARE
      @TargetVersion          nvarchar(64) = N'1.0.0'
    , @DeploymentMode         nvarchar(16) = LOWER(N'local')
    , @InstalledVersion       nvarchar(64)
    , @GenerateSeriesVersion  nvarchar(64)
    , @TruncateVersion        nvarchar(64)
    , @VersionPropertyName    sysname =
          N'Toolbelt.Module.toolbelt.datetime.date-spine.Version'
    , @ProductMajorVersion    int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @CollisionSchema        sysname
    , @CollisionObject        sysname
    , @LockResult             int
    , @DropSql                nvarchar(max);

IF @ProductMajorVersion NOT IN (15, 16, 17)
    THROW 51800, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
IF @DeploymentMode NOT IN (N'local', N'central')
    THROW 51801, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;

SELECT @GenerateSeriesVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0 AND ep.major_id = 0 AND ep.minor_id = 0
  AND ep.name = N'Toolbelt.Module.toolbelt.core.generate-series.Version';

SELECT @TruncateVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0 AND ep.major_id = 0 AND ep.minor_id = 0
  AND ep.name = N'Toolbelt.Module.toolbelt.datetime.truncate.Version';

IF ISNULL(@GenerateSeriesVersion, N'') COLLATE Latin1_General_100_BIN2
       <> N'1.0.0'
   OR OBJECT_ID(N'toolbelt_core.TVF_GenerateSeriesInt', N'IF') IS NULL
   OR ISNULL(@TruncateVersion, N'') COLLATE Latin1_General_100_BIN2
       <> N'1.0.0'
   OR OBJECT_ID(N'toolbelt_datetime.TVF_TruncateDate', N'IF') IS NULL
BEGIN
    THROW 51809, N'toolbelt.core.generate-series 1.0.0 und toolbelt.datetime.truncate 1.0.0 müssen vor diesem Modul in derselben Datenbank installiert sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0 AND ep.major_id = 0 AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

IF @InstalledVersion IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM #tbx_DateSpineReleaseObjects AS release_objects
           WHERE release_objects.ReleaseVersion COLLATE Latin1_General_100_BIN2
                 = @InstalledVersion COLLATE Latin1_General_100_BIN2
       )
    THROW 51803, N'Die installierte Modulversion ist diesem Deployment nicht als unterstütztes Vorgängerrelease bekannt.', 1;

IF SCHEMA_ID(N'toolbelt_datetime') IS NULL
   AND HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    THROW 51802, N'In der Installationsdatenbank fehlt CREATE SCHEMA.', 1;
IF SCHEMA_ID(N'toolbelt_datetime') IS NOT NULL
   AND HAS_PERMS_BY_NAME(N'toolbelt_datetime', N'SCHEMA', N'ALTER') <> 1
    THROW 51802, N'Für toolbelt_datetime fehlt ALTER.', 1;
IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
    THROW 51802, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;

SELECT TOP (1)
      @CollisionSchema = target.SchemaName
    , @CollisionObject = target.ObjectName
FROM #tbx_DateSpineReleaseObjects AS target
JOIN sys.schemas AS schemas
  ON schemas.name COLLATE Latin1_General_100_BIN2
     = target.SchemaName COLLATE Latin1_General_100_BIN2
JOIN sys.objects AS objects
  ON objects.schema_id = schemas.schema_id
 AND objects.name COLLATE Latin1_General_100_BIN2
     = target.ObjectName COLLATE Latin1_General_100_BIN2
WHERE target.ReleaseVersion = @TargetVersion
  AND
  (
      @InstalledVersion IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM #tbx_DateSpineReleaseObjects AS previous
             WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                   = @InstalledVersion COLLATE Latin1_General_100_BIN2
               AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                   = target.SchemaName COLLATE Latin1_General_100_BIN2
               AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                   = target.ObjectName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY target.ObjectName COLLATE Latin1_General_100_BIN2;

IF @CollisionObject IS NOT NULL
BEGIN
    DECLARE @CollisionMessage nvarchar(2048) =
        N'Das neue Framework-Objekt ' + QUOTENAME(@CollisionSchema) + N'.'
        + QUOTENAME(@CollisionObject)
        + N' ist bereits vorhanden, stammt aber nicht aus einem bekannten Release.';
    THROW 51804, @CollisionMessage, 1;
END;

INSERT INTO #tbx_DateSpineDeployState
    (TargetVersion, InstalledVersion, DeploymentMode)
VALUES (@TargetVersion, @InstalledVersion, @DeploymentMode);

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC @LockResult = sys.sp_getapplock
          @Resource = N'toolbelt.deploy.toolbelt.datetime.date-spine'
        , @LockMode = N'Exclusive'
        , @LockOwner = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';
    IF @LockResult < 0
        THROW 51807, N'Ein paralleles Deployment von toolbelt.datetime.date-spine ist bereits aktiv.', 1;

    DECLARE @CurrentInstalledVersion nvarchar(64);
    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0 AND ep.major_id = 0 AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
       <> ISNULL(@InstalledVersion, N'') COLLATE Latin1_General_100_BIN2
        THROW 51807, N'Der installierte Modulstand hat sich seit dem Preflight verändert.', 1;

    IF SCHEMA_ID(N'toolbelt_datetime') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_datetime];';
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.Managed', @value = 1
            , @level0type = N'SCHEMA', @level0name = N'toolbelt_datetime';
        EXEC sys.sp_addextendedproperty
              @name = N'Toolbelt.SchemaCategory', @value = N'datetime'
            , @level0type = N'SCHEMA', @level0name = N'toolbelt_datetime';
    END;

    /*
     * Ein Objekt mit falschem Typ darf nur ersetzt werden, wenn der Name im
     * bekannten installierten Release enthalten war.
     */
    SELECT @DropSql = STUFF
    (
        (
            SELECT NCHAR(10)
                 + CASE
                       WHEN objects.type IN ('P', 'PC') THEN N'DROP PROCEDURE '
                       WHEN objects.type = 'V' THEN N'DROP VIEW '
                       WHEN objects.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                           THEN N'DROP FUNCTION '
                       ELSE N''
                   END
                 + QUOTENAME(schemas.name) + N'.' + QUOTENAME(objects.name) + N';'
            FROM #tbx_DateSpineReleaseObjects AS target
            JOIN #tbx_DateSpineReleaseObjects AS previous
              ON previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                 = @InstalledVersion COLLATE Latin1_General_100_BIN2
             AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                 = target.SchemaName COLLATE Latin1_General_100_BIN2
             AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                 = target.ObjectName COLLATE Latin1_General_100_BIN2
            JOIN sys.schemas AS schemas
              ON schemas.name COLLATE Latin1_General_100_BIN2
                 = target.SchemaName COLLATE Latin1_General_100_BIN2
            JOIN sys.objects AS objects
              ON objects.schema_id = schemas.schema_id
             AND objects.name COLLATE Latin1_General_100_BIN2
                 = target.ObjectName COLLATE Latin1_General_100_BIN2
            WHERE target.ReleaseVersion = @TargetVersion
              AND objects.type COLLATE Latin1_General_100_BIN2
                  <> target.ObjectType COLLATE Latin1_General_100_BIN2
              AND objects.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
            ORDER BY objects.name COLLATE Latin1_General_100_BIN2
            FOR XML PATH(N''), TYPE
        ).value(N'.', N'nvarchar(max)'), 1, 1, N''
    );
    IF NULLIF(@DropSql, N'') IS NOT NULL
        EXEC sys.sp_executesql @DropSql;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_DateSpineCore
-- Typ:             Inline Table-valued Function (intern)
-- Zweck:           Gemeinsamer relationaler Kern für periodische Date Spines
-- Vertrag:         Documentation/Architecture/DATE_SPINE_MODULE_DESIGN.md
-- Parameter:       @RangeStart date, @RangeEndExclusive date,
--                  @Grain varchar(16)
-- Resultset:       Ordinal int, PeriodStart date
-- Dependencies:    toolbelt.core.generate-series 1.0.0;
--                  toolbelt.datetime.truncate 1.0.0
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Plattformen:     Windows und Linux
-- Fehlerverhalten: Ungültiger Grain sowie NULL-, leere und umgekehrte
--                  Bereiche liefern keine Zeilen.
-- Performance:     Inline TVF; Aufwand und Ergebnisgröße wachsen linear mit
--                  der Zahl der geschnittenen Perioden.
-- Einschränkungen: Internes Objekt; keine garantierte Reihenfolge.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_DateSpineCore]
(
      @RangeStart        date
    , @RangeEndExclusive date
    , @Grain             varchar(16)
)
RETURNS TABLE
AS
RETURN
(
    /*
     * Der Ersatzwert schützt DATEADD bei einer ungültigen minimalen
     * Exklusivgrenze. Die ValidRange-CTE entfernt diesen Pfad vollständig aus
     * dem Ergebnis; sie vermeidet zugleich eine optimizerabhängige
     * Kurzschlussannahme für den date-Unterlauf.
     */
    WITH InputContract AS
    (
        SELECT
              IsValidRange = CONVERT
              (
                  bit,
                  CASE
                      WHEN @RangeStart IS NOT NULL
                       AND @RangeEndExclusive IS NOT NULL
                       AND @RangeStart < @RangeEndExclusive
                       AND @Grain COLLATE Latin1_General_100_BIN2
                           IN ('day', 'iso_week', 'month')
                          THEN 1
                      ELSE 0
                  END
              )
            , LastIncludedDate = DATEADD
              (
                  day,
                  -1,
                  CASE
                      WHEN @RangeStart IS NOT NULL
                       AND @RangeEndExclusive IS NOT NULL
                       AND @RangeStart < @RangeEndExclusive
                          THEN @RangeEndExclusive
                      ELSE CONVERT(date, '00010102', 112)
                  END
              )
    ),
    Boundaries AS
    (
        SELECT
              FirstPeriodStart = CONVERT
              (
                  date,
                  CASE @Grain COLLATE Latin1_General_100_BIN2
                      WHEN 'day' THEN @RangeStart
                      WHEN 'iso_week' THEN first_iso_week.Value
                      WHEN 'month' THEN first_month.Value
                  END
              )
            , LastPeriodStart = CONVERT
              (
                  date,
                  CASE @Grain COLLATE Latin1_General_100_BIN2
                      WHEN 'day' THEN input.LastIncludedDate
                      WHEN 'iso_week' THEN last_iso_week.Value
                      WHEN 'month' THEN last_month.Value
                  END
              )
        FROM InputContract AS input
        CROSS APPLY toolbelt_datetime.TVF_TruncateDate
                    ('iso_week', @RangeStart) AS first_iso_week
        CROSS APPLY toolbelt_datetime.TVF_TruncateDate
                    ('month', @RangeStart) AS first_month
        CROSS APPLY toolbelt_datetime.TVF_TruncateDate
                    ('iso_week', input.LastIncludedDate) AS last_iso_week
        CROSS APPLY toolbelt_datetime.TVF_TruncateDate
                    ('month', input.LastIncludedDate) AS last_month
        WHERE input.IsValidRange = 1
    ),
    CountedBoundaries AS
    (
        SELECT
              boundaries.FirstPeriodStart
            , LastOrdinal = CONVERT
              (
                  int,
                  CASE @Grain COLLATE Latin1_General_100_BIN2
                      WHEN 'day' THEN DATEDIFF
                           (day, boundaries.FirstPeriodStart,
                            boundaries.LastPeriodStart)
                      WHEN 'iso_week' THEN DATEDIFF
                           (day, boundaries.FirstPeriodStart,
                            boundaries.LastPeriodStart) / 7
                      WHEN 'month' THEN DATEDIFF
                           (month, boundaries.FirstPeriodStart,
                            boundaries.LastPeriodStart)
                  END
              )
        FROM Boundaries AS boundaries
    )
    SELECT
          Ordinal = series.Value
        , PeriodStart = CONVERT
          (
              date,
              CASE @Grain COLLATE Latin1_General_100_BIN2
                  WHEN 'day' THEN DATEADD
                       (day, series.Value, counted.FirstPeriodStart)
                  WHEN 'iso_week' THEN DATEADD
                       (day, series.Value * 7, counted.FirstPeriodStart)
                  WHEN 'month' THEN DATEADD
                       (month, series.Value, counted.FirstPeriodStart)
              END
          )
    FROM CountedBoundaries AS counted
    CROSS APPLY toolbelt_core.TVF_GenerateSeriesInt
                (0, counted.LastOrdinal, 1) AS series
);
GO
-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_DateSpineDay
-- Typ:             Inline Table-valued Function
-- Zweck:           Tagesperioden erzeugen, die einen halboffenen Bereich schneiden
-- Vertrag:         Documentation/TVF_DateSpineDay.md
-- Parameter:       @RangeStart date, @RangeEndExclusive date
-- Resultset:       Ordinal int, PeriodStart date
-- Dependencies:    toolbelt_datetime.TVF_DateSpineCore
-- Rechte:          SELECT oder REFERENCES auf der Funktion
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Plattformen:     Windows und Linux
-- Fehlerverhalten: NULL-, leere und umgekehrte Bereiche liefern keine Zeilen.
-- Performance:     Inline TVF; linear zur Ergebnisgröße.
-- Einschränkungen: Keine garantierte Reihenfolge.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_DateSpineDay]
(
      @RangeStart        date
    , @RangeEndExclusive date
)
RETURNS TABLE
AS
RETURN
(
    SELECT spine.Ordinal, spine.PeriodStart
    FROM toolbelt_datetime.TVF_DateSpineCore
         (@RangeStart, @RangeEndExclusive, 'day') AS spine
);
GO
-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_DateSpineIsoWeek
-- Typ:             Inline Table-valued Function
-- Zweck:           ISO-Wochen erzeugen, die einen halboffenen Bereich schneiden
-- Vertrag:         Documentation/TVF_DateSpineIsoWeek.md
-- Parameter:       @RangeStart date, @RangeEndExclusive date
-- Resultset:       Ordinal int, PeriodStart date (Montag)
-- Dependencies:    toolbelt_datetime.TVF_DateSpineCore
-- Rechte:          SELECT oder REFERENCES auf der Funktion
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Plattformen:     Windows und Linux
-- Fehlerverhalten: NULL-, leere und umgekehrte Bereiche liefern keine Zeilen.
-- Performance:     Inline TVF; linear zur Ergebnisgröße.
-- Einschränkungen: Keine garantierte Reihenfolge; DATEFIRST-unabhängig.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_DateSpineIsoWeek]
(
      @RangeStart        date
    , @RangeEndExclusive date
)
RETURNS TABLE
AS
RETURN
(
    SELECT spine.Ordinal, spine.PeriodStart
    FROM toolbelt_datetime.TVF_DateSpineCore
         (@RangeStart, @RangeEndExclusive, 'iso_week') AS spine
);
GO
-- ============================================================================
-- Objekt:          toolbelt_datetime.TVF_DateSpineMonth
-- Typ:             Inline Table-valued Function
-- Zweck:           Kalendermonate erzeugen, die einen halboffenen Bereich schneiden
-- Vertrag:         Documentation/TVF_DateSpineMonth.md
-- Parameter:       @RangeStart date, @RangeEndExclusive date
-- Resultset:       Ordinal int, PeriodStart date
-- Dependencies:    toolbelt_datetime.TVF_DateSpineCore
-- Rechte:          SELECT oder REFERENCES auf der Funktion
-- Versionen:       SQL Server 2019, 2022 und 2025
-- Plattformen:     Windows und Linux
-- Fehlerverhalten: NULL-, leere und umgekehrte Bereiche liefern keine Zeilen.
-- Performance:     Inline TVF; linear zur Ergebnisgröße.
-- Einschränkungen: Keine garantierte Reihenfolge.
-- ============================================================================

CREATE OR ALTER FUNCTION [toolbelt_datetime].[TVF_DateSpineMonth]
(
      @RangeStart        date
    , @RangeEndExclusive date
)
RETURNS TABLE
AS
RETURN
(
    SELECT spine.Ordinal, spine.PeriodStart
    FROM toolbelt_datetime.TVF_DateSpineCore
         (@RangeStart, @RangeEndExclusive, 'month') AS spine
);
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    DECLARE
          @DeploymentMode      nvarchar(16)
        , @TargetVersion       nvarchar(64)
        , @VersionPropertyName sysname =
              N'Toolbelt.Module.toolbelt.datetime.date-spine.Version'
        , @ModePropertyName    sysname =
              N'Toolbelt.Module.toolbelt.datetime.date-spine.DeploymentMode';

    SELECT
          @DeploymentMode = DeploymentMode
        , @TargetVersion = TargetVersion
    FROM #tbx_DateSpineDeployState;

    IF XACT_STATE() <> 1
       OR OBJECT_ID(N'toolbelt_datetime.TVF_DateSpineCore', N'IF') IS NULL
       OR OBJECT_ID(N'toolbelt_datetime.TVF_DateSpineDay', N'IF') IS NULL
       OR OBJECT_ID(N'toolbelt_datetime.TVF_DateSpineIsoWeek', N'IF') IS NULL
       OR OBJECT_ID(N'toolbelt_datetime.TVF_DateSpineMonth', N'IF') IS NULL
        THROW 51808, N'Die Date-Spine-Funktionen wurden nicht vollständig innerhalb der Deployment-Transaktion angelegt.', 1;

    DECLARE @Objects TABLE
    (
          ObjectOrdinal int IDENTITY(1, 1) NOT NULL
        , ObjectName sysname NOT NULL
    );
    INSERT INTO @Objects (ObjectName)
    VALUES
          (N'TVF_DateSpineCore')
        , (N'TVF_DateSpineDay')
        , (N'TVF_DateSpineIsoWeek')
        , (N'TVF_DateSpineMonth');

    DECLARE
          @ObjectOrdinal int = 1
        , @ObjectCount int = (SELECT COUNT(*) FROM @Objects)
        , @ObjectName sysname
        , @ObjectId int
        , @SourceHash varchar(64)
        , @PropertyOrdinal int
        , @PropertyName sysname
        , @PropertyValue nvarchar(4000);

    DECLARE @Properties TABLE
    (
          PropertyOrdinal int NOT NULL PRIMARY KEY
        , PropertyName sysname NOT NULL
        , PropertyValue nvarchar(4000) NOT NULL
    );

    WHILE @ObjectOrdinal <= @ObjectCount
    BEGIN
        SELECT @ObjectName = ObjectName
        FROM @Objects WHERE ObjectOrdinal = @ObjectOrdinal;
        SET @ObjectId = OBJECT_ID
            (QUOTENAME(N'toolbelt_datetime') + N'.' + QUOTENAME(@ObjectName));
        SET @SourceHash = CONVERT
        (
            varchar(64),
            HASHBYTES(N'SHA2_256', CONVERT(varbinary(max), OBJECT_DEFINITION(@ObjectId))),
            2
        );

        INSERT INTO @Properties VALUES
              (1, N'Toolbelt.ModuleId', N'toolbelt.datetime.date-spine')
            , (2, N'Toolbelt.ModuleVersion', @TargetVersion)
            , (3, N'Toolbelt.ContractVersion', N'1.0')
            , (4, N'Toolbelt.DeploymentMode', @DeploymentMode)
            , (5, N'Toolbelt.SourceHash', CONVERT(nvarchar(4000), @SourceHash));

        SET @PropertyOrdinal = 1;
        WHILE @PropertyOrdinal <= 5
        BEGIN
            SELECT @PropertyName = PropertyName, @PropertyValue = PropertyValue
            FROM @Properties WHERE PropertyOrdinal = @PropertyOrdinal;
            IF EXISTS
               (
                   SELECT 1 FROM sys.extended_properties
                   WHERE class = 1 AND major_id = @ObjectId AND minor_id = 0
                     AND name = @PropertyName
               )
                EXEC sys.sp_updateextendedproperty
                      @name = @PropertyName, @value = @PropertyValue
                    , @level0type = N'SCHEMA', @level0name = N'toolbelt_datetime'
                    , @level1type = N'FUNCTION', @level1name = @ObjectName;
            ELSE
                EXEC sys.sp_addextendedproperty
                      @name = @PropertyName, @value = @PropertyValue
                    , @level0type = N'SCHEMA', @level0name = N'toolbelt_datetime'
                    , @level1type = N'FUNCTION', @level1name = @ObjectName;
            SET @PropertyOrdinal += 1;
        END;
        DELETE FROM @Properties;
        SET @ObjectOrdinal += 1;
    END;

    IF EXISTS
       (SELECT 1 FROM sys.extended_properties WHERE class = 0 AND name = @VersionPropertyName)
        EXEC sys.sp_updateextendedproperty @name = @VersionPropertyName, @value = @TargetVersion;
    ELSE
        EXEC sys.sp_addextendedproperty @name = @VersionPropertyName, @value = @TargetVersion;

    IF EXISTS
       (SELECT 1 FROM sys.extended_properties WHERE class = 0 AND name = @ModePropertyName)
        EXEC sys.sp_updateextendedproperty @name = @ModePropertyName, @value = @DeploymentMode;
    ELSE
        EXEC sys.sp_addextendedproperty @name = @ModePropertyName, @value = @DeploymentMode;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.datetime.date-spine
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.string.directional-trim
:On Error exit
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @VersionProperty sysname=N'Toolbelt.Module.toolbelt.string.directional-trim.Version',@ModeProperty sysname=N'Toolbelt.Module.toolbelt.string.directional-trim.DeploymentMode',@DeploymentMode nvarchar(16)=LOWER(N'local'),@InstalledVersion nvarchar(64),@DependencyVersion nvarchar(64),@ProductMajorVersion int=TRY_CONVERT(int,SERVERPROPERTY(N'ProductMajorVersion'));
IF @ProductMajorVersion NOT IN(15,16,17) THROW 51210,N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.',1;
IF @DeploymentMode NOT IN(N'local',N'central') THROW 51211,N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.',1;
SELECT @DependencyVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=N'Toolbelt.Module.toolbelt.core.generate-series.Version';
IF @DependencyVersion<>N'1.0.0' OR OBJECT_ID(N'toolbelt_core.TVF_GenerateSeriesBigInt',N'IF') IS NULL THROW 51219,N'toolbelt.core.generate-series Version 1.0.0 muss vor diesem Modul in derselben Datenbank installiert sein.',1;
SELECT @InstalledVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty;
IF @InstalledVersion IS NOT NULL AND @InstalledVersion<>N'1.0.0' THROW 51213,N'Die installierte Modulversion ist diesem Deployment nicht bekannt.',1;
IF @InstalledVersion IS NULL AND (OBJECT_ID(N'toolbelt_string.TVF_TrimDirectionalNvarchar') IS NOT NULL OR OBJECT_ID(N'toolbelt_string.TVF_TrimDirectionalVarchar') IS NOT NULL) THROW 51214,N'Ein Zielobjekt stammt nicht aus einem bekannten Toolbelt-Release.',1;
IF SCHEMA_ID(N'toolbelt_string') IS NOT NULL AND HAS_PERMS_BY_NAME(N'toolbelt_string',N'SCHEMA',N'ALTER')<>1 THROW 51212,N'Für toolbelt_string fehlt ALTER.',1;
IF HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE FUNCTION')<>1 THROW 51212,N'In der Installationsdatenbank fehlt CREATE FUNCTION.',1;
BEGIN TRANSACTION;
DECLARE @LockResult int;
EXEC @LockResult=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.string.directional-trim',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
IF @LockResult<0 THROW 51217,N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.',1;
IF SCHEMA_ID(N'toolbelt_string') IS NULL
BEGIN
 EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_string];';
 EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_string';
 EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'string',@level0type=N'SCHEMA',@level0name=N'toolbelt_string';
END;
GO
-- ============================================================================
-- Objekt: toolbelt_string.TVF_TrimDirectionalNvarchar
-- Zweck:  LEADING-, TRAILING- und BOTH-Trim für Unicode-Text.
-- ============================================================================
CREATE OR ALTER FUNCTION [toolbelt_string].[TVF_TrimDirectionalNvarchar]
(
      @Value      nvarchar(max)
    , @Characters nvarchar(4000) = N' '
    , @Direction  varchar(8) = 'BOTH'
)
RETURNS TABLE
AS
RETURN
(
    WITH Parameters AS
    (
        SELECT
              InputLength = CONVERT(bigint, DATALENGTH(@Value) / 2)
            , Direction = UPPER(@Direction) COLLATE Latin1_General_100_BIN2
            , IsValid = CONVERT(bit, CASE WHEN UPPER(@Direction) COLLATE Latin1_General_100_BIN2 IN ('LEADING','TRAILING','BOTH') THEN 1 ELSE 0 END)
    ),
    NonTrimmed AS
    (
        SELECT positions.Value
        FROM Parameters AS parameters
        CROSS APPLY toolbelt_core.TVF_GenerateSeriesBigInt(1, parameters.InputLength, 1) AS positions
        WHERE CASE
            WHEN UNICODE(SUBSTRING(@Value COLLATE Latin1_General_100_BIN2, positions.Value, 1)) = 0 THEN 0
            ELSE CHARINDEX(SUBSTRING(@Value, positions.Value, 1), @Characters) END = 0
    ),
    Bounds AS
    (
        SELECT FirstValue = MIN(Value), LastValue = MAX(Value) FROM NonTrimmed
    )
    SELECT Value = CONVERT(nvarchar(max), CASE
        WHEN @Value IS NULL OR @Characters IS NULL THEN NULL
        WHEN parameters.IsValid = 0 THEN CONVERT(nvarchar(max), 1 / 0)
        WHEN parameters.InputLength = 0 THEN N''
        WHEN bounds.FirstValue IS NULL THEN N''
        WHEN parameters.Direction = 'LEADING' THEN SUBSTRING(@Value, bounds.FirstValue, parameters.InputLength - bounds.FirstValue + 1)
        WHEN parameters.Direction = 'TRAILING' THEN SUBSTRING(@Value, 1, bounds.LastValue)
        ELSE SUBSTRING(@Value, bounds.FirstValue, bounds.LastValue - bounds.FirstValue + 1) END)
    FROM Parameters AS parameters CROSS JOIN Bounds AS bounds
);
GO
-- ============================================================================
-- Objekt: toolbelt_string.TVF_TrimDirectionalVarchar
-- Zweck:  LEADING-, TRAILING- und BOTH-Trim für varchar-Text.
-- ============================================================================
CREATE OR ALTER FUNCTION [toolbelt_string].[TVF_TrimDirectionalVarchar]
(
      @Value      varchar(max)
    , @Characters varchar(8000) = ' '
    , @Direction  varchar(8) = 'BOTH'
)
RETURNS TABLE
AS
RETURN
(
    WITH Parameters AS
    (
        SELECT
              InputLength = CONVERT(bigint, DATALENGTH(@Value))
            , Direction = UPPER(@Direction) COLLATE Latin1_General_100_BIN2
            , IsValid = CONVERT(bit, CASE WHEN UPPER(@Direction) COLLATE Latin1_General_100_BIN2 IN ('LEADING','TRAILING','BOTH') THEN 1 ELSE 0 END)
    ),
    NonTrimmed AS
    (
        SELECT positions.Value
        FROM Parameters AS parameters
        CROSS APPLY toolbelt_core.TVF_GenerateSeriesBigInt(1, parameters.InputLength, 1) AS positions
        WHERE CASE
            WHEN ASCII(SUBSTRING(@Value COLLATE Latin1_General_100_BIN2, positions.Value, 1)) = 0 THEN 0
            ELSE CHARINDEX(SUBSTRING(@Value, positions.Value, 1), @Characters) END = 0
    ),
    Bounds AS
    (
        SELECT FirstValue = MIN(Value), LastValue = MAX(Value) FROM NonTrimmed
    )
    SELECT Value = CONVERT(varchar(max), CASE
        WHEN @Value IS NULL OR @Characters IS NULL THEN NULL
        WHEN parameters.IsValid = 0 THEN CONVERT(varchar(max), 1 / 0)
        WHEN parameters.InputLength = 0 THEN ''
        WHEN bounds.FirstValue IS NULL THEN ''
        WHEN parameters.Direction = 'LEADING' THEN SUBSTRING(@Value, bounds.FirstValue, parameters.InputLength - bounds.FirstValue + 1)
        WHEN parameters.Direction = 'TRAILING' THEN SUBSTRING(@Value, 1, bounds.LastValue)
        ELSE SUBSTRING(@Value, bounds.FirstValue, bounds.LastValue - bounds.FirstValue + 1) END)
    FROM Parameters AS parameters CROSS JOIN Bounds AS bounds
);
GO
SET NOCOUNT ON;
BEGIN TRY
 DECLARE @VersionProperty sysname=N'Toolbelt.Module.toolbelt.string.directional-trim.Version',@ModeProperty sysname=N'Toolbelt.Module.toolbelt.string.directional-trim.DeploymentMode';
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty) EXEC sys.sp_updateextendedproperty @name=@VersionProperty,@value=N'1.0.0'; ELSE EXEC sys.sp_addextendedproperty @name=@VersionProperty,@value=N'1.0.0';
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@ModeProperty) EXEC sys.sp_updateextendedproperty @name=@ModeProperty,@value=N'local'; ELSE EXEC sys.sp_addextendedproperty @name=@ModeProperty,@value=N'local';
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.string.directional-trim
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
-- BEGIN MODULE toolbelt.string.split-characters
:On Error exit

-- ============================================================================
-- Zweck:     Erst-, Upgrade- und Wiederholungsdeployment
-- Modul:     toolbelt.string.split-characters v1.0.0
-- Schema:    toolbelt_string
-- Erfordert: SQL Server 2019, 2022 oder 2025
-- Modus:     SQLCMD; Ausführung aus diesem Deployment-Verzeichnis
-- Parameter: DeploymentMode=local|central
-- ============================================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'tempdb..#tbx_SplitCharactersReleaseObjects', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_SplitCharactersReleaseObjects;
END;

IF OBJECT_ID(N'tempdb..#tbx_SplitCharactersDeployState', N'U') IS NOT NULL
BEGIN
    DROP TABLE #tbx_SplitCharactersDeployState;
END;

CREATE TABLE #tbx_SplitCharactersReleaseObjects
(
      ReleaseVersion nvarchar(64) NOT NULL
    , SchemaName     sysname      NOT NULL
    , ObjectName     sysname      NOT NULL
    , ObjectType     char(2)      NOT NULL
    , CONSTRAINT PK_tbx_SplitCharactersReleaseObjects
          PRIMARY KEY (ReleaseVersion, SchemaName, ObjectName)
);

INSERT INTO #tbx_SplitCharactersReleaseObjects
(
      ReleaseVersion
    , SchemaName
    , ObjectName
    , ObjectType
)
VALUES
      (N'1.0.0', N'toolbelt_string', N'TVF_SplitByCharacters', 'IF')
    , (N'1.0.0', N'toolbelt_string', N'TVF_SplitByCharactersStatus', 'TF');

CREATE TABLE #tbx_SplitCharactersDeployState
(
      TargetVersion    nvarchar(64) NOT NULL
    , InstalledVersion nvarchar(64) NULL
    , DeploymentMode   nvarchar(16) NOT NULL
    , SchemaCreated     bit          NOT NULL
);

DECLARE
      @TargetVersion        nvarchar(64) = N'1.0.0'
    , @DeploymentMode       nvarchar(16) = LOWER(N'local')
    , @InstalledVersion     nvarchar(64)
    , @DependencyVersion    nvarchar(64)
    , @VersionPropertyName  sysname =
          N'Toolbelt.Module.toolbelt.string.split-characters.Version'
    , @ProductMajorVersion  int =
          TRY_CONVERT(int, SERVERPROPERTY(N'ProductMajorVersion'))
    , @SchemaId             int = SCHEMA_ID(N'toolbelt_string')
    , @CollisionSchema      sysname
    , @CollisionObject      sysname
    , @LockResult           int
    , @DropSql              nvarchar(max)
    , @SchemaCreated        bit = 0;

IF @ProductMajorVersion NOT IN (15, 16, 17)
BEGIN
    THROW 51070, N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.', 1;
END;

IF @DeploymentMode NOT IN (N'local', N'central')
BEGIN
    THROW 51071, N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.', 1;
END;

SELECT @DependencyVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = N'Toolbelt.Module.toolbelt.core.generate-series.Version';

IF ISNULL(@DependencyVersion, N'')
       COLLATE Latin1_General_100_BIN2 <> N'1.0.0'
   OR OBJECT_ID(N'toolbelt_core.TVF_GenerateSeriesBigInt', N'IF') IS NULL
BEGIN
    THROW 51079, N'toolbelt.core.generate-series Version 1.0.0 muss vor diesem Modul in derselben Datenbank installiert sein.', 1;
END;

SELECT @InstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
FROM sys.extended_properties AS ep
WHERE ep.class = 0
  AND ep.major_id = 0
  AND ep.minor_id = 0
  AND ep.name = @VersionPropertyName;

IF @InstalledVersion IS NOT NULL
   AND NOT EXISTS
       (
           SELECT 1
           FROM #tbx_SplitCharactersReleaseObjects AS ro
           WHERE ro.ReleaseVersion COLLATE Latin1_General_100_BIN2
                     = @InstalledVersion COLLATE Latin1_General_100_BIN2
       )
BEGIN
    THROW 51073, N'Die installierte Modulversion ist diesem Deployment nicht als unterstütztes Vorgängerrelease bekannt.', 1;
END;

IF @SchemaId IS NULL
BEGIN
    IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE SCHEMA') <> 1
    BEGIN
        THROW 51072, N'Zum Anlegen von toolbelt_string fehlt CREATE SCHEMA in der Installationsdatenbank.', 1;
    END;
END;
ELSE IF HAS_PERMS_BY_NAME(N'toolbelt_string', N'SCHEMA', N'ALTER') <> 1
BEGIN
    THROW 51072, N'Für das vorhandene Schema toolbelt_string fehlt ALTER.', 1;
END;

IF HAS_PERMS_BY_NAME(DB_NAME(), N'DATABASE', N'CREATE FUNCTION') <> 1
BEGIN
    THROW 51072, N'In der Installationsdatenbank fehlt CREATE FUNCTION.', 1;
END;

/*
 * Neue Zielnamen dürfen kein frameworkfremdes Objekt überschreiben. Ein Name
 * gilt nur dann als Framework-Bestand, wenn er im bekannten installierten
 * Release enthalten ist.
 */
SELECT TOP (1)
      @CollisionSchema = target.SchemaName
    , @CollisionObject = target.ObjectName
FROM #tbx_SplitCharactersReleaseObjects AS target
INNER JOIN sys.schemas AS schemas
    ON schemas.name COLLATE Latin1_General_100_BIN2
          = target.SchemaName COLLATE Latin1_General_100_BIN2
INNER JOIN sys.objects AS objects
    ON objects.schema_id = schemas.schema_id
   AND objects.name COLLATE Latin1_General_100_BIN2
          = target.ObjectName COLLATE Latin1_General_100_BIN2
WHERE target.ReleaseVersion = @TargetVersion
  AND
  (
      @InstalledVersion IS NULL
      OR NOT EXISTS
         (
             SELECT 1
             FROM #tbx_SplitCharactersReleaseObjects AS previous
             WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                       = @InstalledVersion COLLATE Latin1_General_100_BIN2
               AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                       = target.SchemaName COLLATE Latin1_General_100_BIN2
               AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                       = target.ObjectName COLLATE Latin1_General_100_BIN2
         )
  )
ORDER BY target.ObjectName COLLATE Latin1_General_100_BIN2;

IF @CollisionObject IS NOT NULL
BEGIN
    DECLARE @CollisionMessage nvarchar(2048) =
        N'Das neue Framework-Objekt '
        + QUOTENAME(@CollisionSchema)
        + N'.'
        + QUOTENAME(@CollisionObject)
        + N' ist bereits vorhanden, stammt aber nicht aus dem bekannten installierten Release.';
    SET @CollisionMessage = REPLACE(@CollisionMessage, N'%', N'%%');
    THROW 51074, @CollisionMessage, 1;
END;

INSERT INTO #tbx_SplitCharactersDeployState
(
      TargetVersion
    , InstalledVersion
    , DeploymentMode
    , SchemaCreated
)
VALUES
(
      @TargetVersion
    , @InstalledVersion
    , @DeploymentMode
    , 0
);

BEGIN TRY
    IF OBJECT_ID(N'toolbelt_string.TVF_SplitByCharactersStatus') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_string.TVF_SplitByCharactersStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(256),value)=N'toolbelt.string.split-characters') THROW 51074,N'Neuer Security-Zielname ist frameworkfremd belegt.',1;
BEGIN TRANSACTION;

    EXEC @LockResult = sys.sp_getapplock
          @Resource    = N'toolbelt.deploy.toolbelt.string.split-characters'
        , @LockMode    = N'Exclusive'
        , @LockOwner   = N'Transaction'
        , @LockTimeout = 0
        , @DbPrincipal = N'public';

    IF @LockResult < 0
    BEGIN
        THROW 51077, N'Ein paralleles Deployment von toolbelt.string.split-characters ist bereits aktiv.', 1;
    END;

    DECLARE @CurrentInstalledVersion nvarchar(64);

    SELECT @CurrentInstalledVersion = TRY_CONVERT(nvarchar(64), ep.value)
    FROM sys.extended_properties AS ep
    WHERE ep.class = 0
      AND ep.major_id = 0
      AND ep.minor_id = 0
      AND ep.name = @VersionPropertyName;

    IF ISNULL(@CurrentInstalledVersion, N'') COLLATE Latin1_General_100_BIN2
           <> ISNULL(@InstalledVersion, N'') COLLATE Latin1_General_100_BIN2
    BEGIN
        THROW 51077, N'Der installierte Modulstand hat sich seit dem Preflight verändert.', 1;
    END;

    SET @CollisionSchema = NULL;
    SET @CollisionObject = NULL;

    SELECT TOP (1)
          @CollisionSchema = target.SchemaName
        , @CollisionObject = target.ObjectName
    FROM #tbx_SplitCharactersReleaseObjects AS target
    INNER JOIN sys.schemas AS schemas
        ON schemas.name COLLATE Latin1_General_100_BIN2
              = target.SchemaName COLLATE Latin1_General_100_BIN2
    INNER JOIN sys.objects AS objects
        ON objects.schema_id = schemas.schema_id
       AND objects.name COLLATE Latin1_General_100_BIN2
              = target.ObjectName COLLATE Latin1_General_100_BIN2
    WHERE target.ReleaseVersion = @TargetVersion
      AND
      (
          @InstalledVersion IS NULL
          OR NOT EXISTS
             (
                 SELECT 1
                 FROM #tbx_SplitCharactersReleaseObjects AS previous
                 WHERE previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                           = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                           = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                           = target.ObjectName COLLATE Latin1_General_100_BIN2
             )
      );

    IF @CollisionObject IS NOT NULL
    BEGIN
        THROW 51077, N'Ein Zielobjekt hat sich seit dem Preflight verändert oder ist neu hinzugekommen.', 1;
    END;

    IF SCHEMA_ID(N'toolbelt_string') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_string];';
        SET @SchemaCreated = 1;

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.Managed'
            , @value      = 1
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_string';

        EXEC sys.sp_addextendedproperty
              @name       = N'Toolbelt.SchemaCategory'
            , @value      = N'string'
            , @level0type = N'SCHEMA'
            , @level0name = N'toolbelt_string';
    END;

    UPDATE #tbx_SplitCharactersDeployState
    SET SchemaCreated = @SchemaCreated;

    /*
     * Ein lokal verändertes Release-Objekt mit falschem Typ wird anhand des
     * bekannten Vorgänger-Manifests entfernt. Fremde Namen bleiben unberührt.
     */
    SELECT @DropSql =
        STUFF
        (
            (
                SELECT
                      NCHAR(10)
                    + CASE
                          WHEN objects.type IN ('P', 'PC')
                              THEN N'DROP PROCEDURE '
                          WHEN objects.type = 'V'
                              THEN N'DROP VIEW '
                          WHEN objects.type IN ('FN', 'FS', 'FT', 'IF', 'TF')
                              THEN N'DROP FUNCTION '
                          ELSE N''
                      END
                    + QUOTENAME(schemas.name)
                    + N'.'
                    + QUOTENAME(objects.name)
                    + N';'
                FROM #tbx_SplitCharactersReleaseObjects AS target
                INNER JOIN #tbx_SplitCharactersReleaseObjects AS previous
                    ON previous.ReleaseVersion COLLATE Latin1_General_100_BIN2
                          = @InstalledVersion COLLATE Latin1_General_100_BIN2
                   AND previous.SchemaName COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                   AND previous.ObjectName COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.schemas AS schemas
                    ON schemas.name COLLATE Latin1_General_100_BIN2
                          = target.SchemaName COLLATE Latin1_General_100_BIN2
                INNER JOIN sys.objects AS objects
                    ON objects.schema_id = schemas.schema_id
                   AND objects.name COLLATE Latin1_General_100_BIN2
                          = target.ObjectName COLLATE Latin1_General_100_BIN2
                WHERE target.ReleaseVersion = @TargetVersion
                  AND objects.type COLLATE Latin1_General_100_BIN2
                        <> target.ObjectType COLLATE Latin1_General_100_BIN2
                  AND objects.type IN ('P', 'PC', 'V', 'FN', 'FS', 'FT', 'IF', 'TF')
                ORDER BY objects.name COLLATE Latin1_General_100_BIN2
                FOR XML PATH(N''), TYPE
            ).value(N'.', N'nvarchar(max)')
          , 1
          , 1
          , N''
        );

    IF NULLIF(@DropSql, N'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql @DropSql;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO

-- ============================================================================
-- Objekt:          toolbelt_string.TVF_SplitByCharactersStatus
-- Zweck:           Begrenzter kanonischer Statuskern; Legacy-Wertfassade unten.
-- Parameter:       @Input nvarchar(max), @Separators nvarchar(4000), @KeepEmpty bit = 1
-- Resultset:       Value nvarchar(max), Ordinal bigint, Status varchar(16)
-- Vertrag:         Documentation/TVF_SplitByCharactersStatus.md
-- Versionen:       SQL Server 2019/2022/2025; Windows/Linux
-- Rechte:          SELECT/REFERENCES; keine zusätzlichen Rechte oder Grants.
-- Performance:     MSTVF mit Vorabgrenzen; keine Inline-/Parallelitätszusage.
-- Grenzen:         Freigegebener Vertrag SECURITY_HARDENING_2026_10.md.
-- ============================================================================
CREATE OR ALTER FUNCTION [toolbelt_string].[TVF_SplitByCharactersStatus]
(@Input nvarchar(max),@Separators nvarchar(4000),@KeepEmpty bit=1)
RETURNS @Result TABLE(Value nvarchar(max) NULL,Ordinal bigint NULL,Status varchar(16) NOT NULL)
AS
BEGIN
    IF @Input IS NULL OR @Separators IS NULL
    BEGIN INSERT @Result VALUES(NULL,NULL,'SQL_NULL'); RETURN; END;
    IF DATALENGTH(@Input)>65536
    BEGIN INSERT @Result VALUES(NULL,NULL,'LIMIT'); RETURN; END;
    DECLARE @SeparatorCodes TABLE(Code int NOT NULL PRIMARY KEY);
    DECLARE @Position int=1,@Length int=CONVERT(int,DATALENGTH(@Input)/2),
            @SeparatorLength int=CONVERT(int,DATALENGTH(@Separators)/2),@Code int,
            @Start int=1,@Count int=0;
    -- Höchstens 65 unterschiedliche Codes aufnehmen; der zusätzliche Code
    -- ist nur ein Limitwächter. Die feste 4000er-Separatorlänge begrenzt den Scan.
    INSERT @SeparatorCodes(Code)
    SELECT DISTINCT TOP(65) UNICODE(SUBSTRING(@Separators COLLATE Latin1_General_100_BIN2,positions.Value,1))
    FROM toolbelt_core.TVF_GenerateSeriesBigInt(1,@SeparatorLength,1) positions;
    IF EXISTS(SELECT 1 FROM @SeparatorCodes WHERE Code=0)
    BEGIN INSERT @Result VALUES(NULL,NULL,'INVALID'); RETURN; END;
    IF (SELECT COUNT(*) FROM @SeparatorCodes)>64
    BEGIN INSERT @Result VALUES(NULL,NULL,'LIMIT'); RETURN; END;
    DECLARE @Spans TABLE(Ordinal int NOT NULL PRIMARY KEY,StartPosition int NOT NULL,SpanLength int NOT NULL);
    SET @Position=1;
    WHILE @Position<=@Length+1
    BEGIN
        IF @Position=@Length+1 OR EXISTS(SELECT 1 FROM @SeparatorCodes
            WHERE Code=UNICODE(SUBSTRING(@Input COLLATE Latin1_General_100_BIN2,@Position,1)))
        BEGIN
            IF COALESCE(@KeepEmpty,1)=1 OR @Position>@Start
            BEGIN
                IF @Count>=10000 BEGIN INSERT @Result VALUES(NULL,NULL,'LIMIT'); RETURN; END;
                SET @Count+=1;
                INSERT @Spans VALUES(@Count,@Start,@Position-@Start);
            END;
            SET @Start=@Position+1;
        END;
        SET @Position+=1;
    END;
    IF @Count=0 INSERT @Result VALUES(NULL,NULL,'EMPTY');
    ELSE INSERT @Result SELECT SUBSTRING(@Input COLLATE Latin1_General_100_BIN2,StartPosition,SpanLength),Ordinal,'OK' FROM @Spans;
    RETURN;
END;
GO
-- Legacy-Wertfassade: gleicher Inputvertrag; Limitabbildung siehe Objektseite.
-- Vertrag: Documentation/TVF_SplitByCharacters.md
CREATE OR ALTER FUNCTION [toolbelt_string].[TVF_SplitByCharacters]
(@Input nvarchar(max),@Separators nvarchar(4000),@KeepEmpty bit=1)
RETURNS TABLE AS RETURN
(SELECT Value,Ordinal FROM toolbelt_string.TVF_SplitByCharactersStatus(@Input,@Separators,@KeepEmpty) WHERE Status='OK');
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    DECLARE
          @DeploymentMode      nvarchar(16)
        , @TargetVersion       nvarchar(64)
        , @VersionPropertyName sysname =
              N'Toolbelt.Module.toolbelt.string.split-characters.Version'
        , @ModePropertyName    sysname =
              N'Toolbelt.Module.toolbelt.string.split-characters.DeploymentMode';

    SELECT
          @DeploymentMode = DeploymentMode
        , @TargetVersion = TargetVersion
    FROM #tbx_SplitCharactersDeployState;

    IF XACT_STATE() <> 1
       OR OBJECT_ID(N'toolbelt_string.TVF_SplitByCharacters', N'IF') IS NULL
    BEGIN
        THROW 51078, N'Die Framework-Funktionen wurden nicht vollständig innerhalb der Deployment-Transaktion angelegt.', 1;
    END;

    DECLARE @Objects TABLE
    (
          ObjectOrdinal int IDENTITY(1, 1) NOT NULL
        , ObjectName    sysname            NOT NULL
    );

    INSERT INTO @Objects (ObjectName)
    VALUES (N'TVF_SplitByCharacters'), (N'TVF_SplitByCharactersStatus');

    DECLARE
          @ObjectOrdinal int = 1
        , @ObjectCount   int = (SELECT COUNT(*) FROM @Objects)
        , @ObjectName    sysname
        , @ObjectId      int
        , @SourceHash    varchar(64)
        , @PropertyOrdinal int
        , @PropertyCount   int
        , @PropertyName    sysname
        , @PropertyValue   nvarchar(4000);

    DECLARE @Properties TABLE
    (
          PropertyOrdinal int            NOT NULL PRIMARY KEY
        , PropertyName    sysname        NOT NULL
        , PropertyValue   nvarchar(4000) NOT NULL
    );

    WHILE @ObjectOrdinal <= @ObjectCount
    BEGIN
        SELECT @ObjectName = ObjectName
        FROM @Objects
        WHERE ObjectOrdinal = @ObjectOrdinal;

        SET @ObjectId = OBJECT_ID
        (
            QUOTENAME(N'toolbelt_string') + N'.' + QUOTENAME(@ObjectName)
        );
        SET @SourceHash = CONVERT
        (
              varchar(64)
            , HASHBYTES
              (
                  N'SHA2_256'
                , CONVERT(varbinary(max), OBJECT_DEFINITION(@ObjectId))
              )
            , 2
        );

        INSERT INTO @Properties
        (
              PropertyOrdinal
            , PropertyName
            , PropertyValue
        )
        VALUES
              (1, N'Toolbelt.ModuleId', N'toolbelt.string.split-characters')
            , (2, N'Toolbelt.ModuleVersion', @TargetVersion)
            , (3, N'Toolbelt.ContractVersion', N'1.0')
            , (4, N'Toolbelt.DeploymentMode', @DeploymentMode)
            , (5, N'Toolbelt.SourceHash', CONVERT(nvarchar(4000), @SourceHash));

        SET @PropertyOrdinal = 1;
        SET @PropertyCount = (SELECT COUNT(*) FROM @Properties);

        WHILE @PropertyOrdinal <= @PropertyCount
        BEGIN
            SELECT
                  @PropertyName = PropertyName
                , @PropertyValue = PropertyValue
            FROM @Properties
            WHERE PropertyOrdinal = @PropertyOrdinal;

            IF EXISTS
               (
                   SELECT 1
                   FROM sys.extended_properties AS ep
                   WHERE ep.class = 1
                     AND ep.major_id = @ObjectId
                     AND ep.minor_id = 0
                     AND ep.name = @PropertyName
               )
            BEGIN
                EXEC sys.sp_updateextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_string'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;
            ELSE
            BEGIN
                EXEC sys.sp_addextendedproperty
                      @name       = @PropertyName
                    , @value      = @PropertyValue
                    , @level0type = N'SCHEMA'
                    , @level0name = N'toolbelt_string'
                    , @level1type = N'FUNCTION'
                    , @level1name = @ObjectName;
            END;

            SET @PropertyOrdinal += 1;
        END;

        DELETE FROM @Properties;
        SET @ObjectOrdinal += 1;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @VersionPropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @VersionPropertyName
            , @value = @TargetVersion;
    END;

    IF EXISTS
       (
           SELECT 1
           FROM sys.extended_properties
           WHERE class = 0 AND name = @ModePropertyName
       )
    BEGIN
        EXEC sys.sp_updateextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;
    ELSE
    BEGIN
        EXEC sys.sp_addextendedproperty
              @name = @ModePropertyName
            , @value = @DeploymentMode;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO
GO
-- END MODULE toolbelt.string.split-characters
IF @@TRANCOUNT <> 0 OR (2 & @@OPTIONS) <> 0
    THROW 50000, N'Toolbelt SQL-Export benötigt eine frische Sitzung ohne laufende oder implizite Transaktion.', 1;
GO
