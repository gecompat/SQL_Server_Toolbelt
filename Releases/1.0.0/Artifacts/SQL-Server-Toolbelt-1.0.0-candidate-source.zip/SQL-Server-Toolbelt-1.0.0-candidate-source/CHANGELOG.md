# CHANGELOG

## 2026-10-22 – Stabile Paketexports nativ geprüft

Der [Gatebericht zur v1.0.0-Vorbereitung](Releases/1.0.0/RELEASE-GATES.md)
belegt zwölf Windows-/Linux-/SQL-/CL-Paketfälle mit Erstinstallation,
Wiederholung, zentralem Consumer, Uninstall und unabhängigen Cleanupaudits.
Alle zwölf CLR-Projekte bestehen zwei bytegleiche isolierte Builds mit
PE-/Buildpfadprüfung. Die SQL-Payloads und Adapter bleiben an die tatsächliche
Evidenz gebunden; neue Binaryhashes werden nicht als nativ qualifiziert oder
ausgeliefert dargestellt. Modulstatus und Veröffentlichung bleiben unverändert.
Die [Installationsanleitung](INSTALL.md) führt ohne eigenen Build durch den
SSMS-Einstieg und ersten Test. Historische Modulnotizen bleiben getrennt
erhalten; README, Dokumentationsübersicht und ZIP-Einstieg verlinken den Weg.

## 2026-10-22 – Gesamtpaket v1.0.0 vorbereitet, nicht veröffentlicht

Die [Releasevorbereitung](Releases/1.0.0/README.md) enthält alle 45 Module
mit unveränderten Versionen und einer dependencygebundenen Freigabematrix:
19 stabile und 26 Preview-Kandidaten. Der eingefrorene Quellpaketbau erzeugt
zusätzlich lokale/zentrale SQL-Exports der stabilen Kandidaten. Vorhandene
SSIS-Binaries sind als separater Installationssatz enthalten; weitere CLR-
Binaryinputs und die konkrete Veröffentlichungsabnahme bleiben sichtbar offen.
Alle Modulmanifeste bleiben `unreleased`; kein Tag oder Release angelegt.

## 2026-10-19 – JSON-Pointer-Matrix im Lab nachqualifiziert

Zwölf vollständige Adapter bestanden auf Windows/Linux SQL2019 CL150,
SQL2022 CL150/160 und SQL2025 CL150/160/170 mit local/central/Consumer,
festen API-/Safetyorakeln, Clientmetadaten und je 42 Lifecyclefällen.
Frische Audits bestätigten Inputbindung, Fixturewiederherstellung und die
Abwesenheit aller 36 eigenen Datenbanken. Der kanonische Vertrag und die
Objektdokumentation führen das bereits freigegebene SC-006-Parserbudget nach;
keine Produkt-/Harnessänderung oder Statusaufwertung.
Minimalrechte, Heap/Parallelität, harte Host-Recovery und Release bleiben offen.
[Bericht](Modules/toolbelt.json.pointer/Tests/QUALIFICATION_2026-10-19.md).

## 2026-10-19 – Pflicht-Lastfälle und optionale Zeitmessungen

Auf ausdrücklichen Benutzerauftrag ersetzt DEC-2026-036 den bisherigen
Performance-Abnahmevertrag: große Lastfälle mit Ergebnisprüfung bleiben Pflicht,
Laufzeitmessungen werden optional. Drei neue automatisch ausgeführte
`Load.Contract.sql` bestanden mit den vollständigen Moduladaptern auf
SQL Server 2025 Linux/latest CL170 einschließlich eigenem Cleanup. ResultTable,
Base64 und Generate Series sind damit validiert; alle 16 Kohortenmodule
bleiben unveröffentlicht. Frühere datierte Einschränkungen gelten historisch.
Details: [Gatebericht](Tests/V0C_RELEASE_GATE_STATUS.md).

## 2026-10-19 – Fachqualifikation der ersten Releasekohorte

Alle 16 V0c-Module bestehen die vollständige aktuelle Windows-/Linux-Matrix
auf SQL Server 2019/2022/2025. Zusätzliche ADO.NET-Client-, Minimalrechte- und
zentrale Statusprüfungen schließen die autonom ausführbaren Rest-Gates.
Der Base64-Performancevergleich weist unerwartetes NULL nun ausdrücklich ab.
Der statische Split-Characters-Vertrag akzeptiert auch quotiertes `validated`.
13 Kohortenmodule sind validiert; drei kontrollierte Performance-Nachweise
und die tatsächliche Veröffentlichungsentscheidung bleiben offen.
Details: [V0c-Gatebericht](Tests/V0C_RELEASE_GATE_STATUS.md).

## 2026-10-18 – SSIS-Debug als vollständiges ZIP-Installationspaket

Ein versionierter Testartefaktsatz enthält die drei passenden Assemblies,
ResultTable, Deploy-/Trustskripte, Installationsanleitung und SSMS-Beispiel
einschließlich synthetischer DTSX-Fixture. Der Parserbuild erzeugt keine
PDB-Debugdaten und verwendet synthetische Quellpfade. Die exakten Parserpins
von SSIS-Debug und Table Clone sind neu gebunden. Ein gezielter Offlinecheck
prüft ZIP-Inhalt, Prüfsummen, Dependencybindung und pfadfreie Toolbelt-Binaries.
Der Modul-/Releasestatus wird dadurch nicht angehoben.
Details: [Installationspaket](Modules/toolbelt.tsql.ssis-debug/InstallPackages/README.md).

## 2026-10-18 – Installationsanleitung für das SSIS-Debug-Beispiel

Das Modul enthält die lokale Installationsanleitung mit SQL-Server-Vorbereitung,
PowerShell-Installation und Kontrolle für ResultTable, Parser und SSIS-Debug.
Vorhandene Lifecycle-/Trustskripte werden mit exakten Artefakthashes verwendet;
ein Offline-Prüfmodus öffnet keine SQL-Verbindung. Herkunft der Buildartefakte,
exakter Parserpin, Ausführungsreihenfolge und Transportwahl sind dokumentiert.
Details: [Installation](Modules/toolbelt.tsql.ssis-debug/Examples/Installation/README.md).

## 2026-10-18 – Vollständiges SSMS-Beispiel für SSIS-Debug

Das Modul enthält einen dauerhaft verlinkten Walkthrough mit synthetischer
DTSX-Fixture: Import der Originalbytes, JSON-Vorlage und Werteänderung,
einzeln angeforderte CTE-Stufen, direkte DECLARE-Änderung und Cache-Cleanup.
Der bestehende Syntaxrunner prüft das Beispiel zusätzlich mit SQL150/160/170;
öffentliche API, Provider und Deployment bleiben unverändert.
Details: [SSMS-Beispiel](Modules/toolbelt.tsql.ssis-debug/Examples/README.md).

## 2026-10-17 – SSIS-V1-Fachmatrix und native Korrekturen

Die freigegebenen Fachtests übernehmen den expliziten Trustwert des
schema-validierten Labvertrags bei erforderlicher Verschlüsselung.
Windows SQL Server 2019/2022/2025 bestehen jeweils lokal und zentral
181 Kern-, 61 API- und 15 Lifecycleassertionen: insgesamt 1.542. Einzeln
ausgeführte CTE-Stufen, DECLARE-/Cacheinvalidierung, Parallelzugriffe,
Cross-DB/Minimalrechte und echte Parser-/Table-Clone-Upgrades sind enthalten.
WHERE-Erhalt, reine TVF ohne Alias, doomed Callertransaktion, lokale
Computed-Spaltenkanten und COLLATE-Rendering korrigiert. Reproduzierbarer
Build, Full21, Syntax12, Deployment/Repeat/Uninstall/Repeat und frische
Cleanup-Audits bestanden. Alle Fachläufe verwendeten explizit
`TrustServerCertificate=True`; authentifizierte TLS-Abnahme bleibt separat
`not executed`. Head-/Integrations-CI und Release bleiben offen.
Details: [Prüfmatrix](Modules/toolbelt.tsql.ssis-debug/Tests/README.md).

## 2026-10-16 – SSIS-Debug-V1 und begrenzte Dependency-Patches

Nach ausdrücklicher Funktionsfreigabe: neue Windows-/UNSAFE-Assembly mit
`USP_ExplainSsisDataFlow`, JSON-Eingabevorlage, bearbeitbaren DECLAREs und
eigenständig ausführbaren CTE-Stufen. Composite-Lookups werden dedupliziert
und sitzungslokal wiederverwendet; unterstützte Lesereferenzen erhalten NOLOCK.
Parser 2.0.1 teilt seinen Vorfilter bei unveränderten öffentlichen Grenzen;
Table Clone 4.1.1 bindet den neuen exakten Parserpin. Frameworkqualifikation
bestanden; native SQL-/Upgrade-/Lifecycle-Gates sind wegen des TLS-Preflights
offen. Kein neuer SQL-Einstieg geladen, kein Merge oder Release.
Details: [V1-Vertrag](Documentation/Architecture/SSIS_DTSX_DEBUG_SELECT_V1_CONTRACT.md).

## 2026-10-15 – 25 freigegebene Security-Härtungen

Work-Type-Autorität, ServiceAccount-Rolle/Root, Schema-Vertrauen und
Transaktionsgrenzen ergänzt. Foundation- und native Windows-Dateizugriffe
binden Handles; Windows benötigt nun ausdrücklich UNSAFE. Textdateien werden
aus einem Byte-Snapshot dekodiert. ZIP-/Regex-/Listinggrenzen, JSON-Parserbudgets,
Statusvarianten für Reihen/Base64/Split/URI/JSON Path, Cancellationquoten,
RecordedAtUtc-Retention und Consolelimits implementiert und gezielt geprüft.
Lab-TLS verlangt gültige CA-/Hostnameprüfung; der aktuelle externe Labvertrag
wird vor Verbindungsaufbau abgewiesen. Zertifikatsbereitstellung bleibt extern.
Verträge, Migration und genaue Nachweisgrenzen:
[Security-Härtung](Documentation/Architecture/SECURITY_HARDENING_2026_10.md).
Integration, aktuelle Head-CI und Cloudabschluss werden getrennt geführt.

## 2026-10-14 – 13 freigegebene Security-Korrekturen

Explizite HTTP-Autorität, begrenzte Labmappings und Evidence-Schreibpfade,
JSON-Escapingvorprüfung, begrenzte Regex-CLR-Einstiege, ZIP-Pfadklassifikation,
gesperrte Legacyclaim-Prüfung und doomed Error-Envelope-Ausgabe korrigiert.
Exakte Dezimalbudgets, Barrier-Negativorakel, Git-Logpfade, MSTVF-Audit und
SQLCMD-Betreibervariablen ergänzt. Gezielte Offline-/CLR-/SQL-Nachweise und
verbleibende Qualifikationsgrenzen: [Security-Korrekturen](Documentation/Architecture/SECURITY_CORRECTIONS_2026_10.md).
Keine neue Releasefreigabe oder Cloudschließung.

## 2026-10-09 – Leere kanonische Base64-Zeichenfolge decodieren

Quellenkorrektur im bestehenden TVF-Decoder: Nicht-NULL-Eingaben mit leerer
kanonischer Zeichenfolge sollen `0x` ergeben; `NULL` bleibt `NULL`. Der bestehende
SVF-Wrapper folgt dem TVF-Kern, ohne API-, Normalisierungs- oder Fehlervertrags-
Änderung. Der erste PR311-Headlauf scheiterte mit Fehlerkategorie `52303`; konkrete
Eingabe und Laufzeitursache bleiben ungemessen. Quellenstand **SOURCE_ONLY**,
neue Runtimequalifikation offen. Frühere Quellenstände und Matrixnachweise
bleiben historisch; Version `1.1.0`, Modulstatus und Releasezustand unverändert.

## 2026-10-09 – Bestehende Base64-RFC-Testorakel schließen

Quellenkandidat für die sieben vorhandenen RFC-4648-Vektoren: unerwartetes NULL
sowie fehlende oder mehrfache direkte TVF-Ergebniszeilen ausdrücklich abweisen.
Eingaben, Sollwerte und übrige Orakel bleiben unverändert; belegt ist eine
Testorakellücke, kein gemessener Produktfehler. Quellenstand SOURCE_ONLY, neue
Orakel **NOT_EXECUTED** und noch nicht qualifiziert. Historische Matrixnachweise,
Produkt, API, Workflow, Modulversion `1.1.0` und Status bleiben unverändert.

## 2026-10-09 – Command-Setup der Safe-Cast-Metadatenprobe schützen

Der bestehende SqlClient-Testhelper besitzt seinen Command bis zur erfolgreichen
Rückgabe und disponiert ihn bei einem Setupfehler davor. Beide Parameter-Setups
liegen im bestehenden Command-try des Callers. Die geliehene Connection,
SQL-Texte, Timeouts, ReadBudget und Orakel bleiben unverändert.
Quellenstand SOURCE_ONLY; neue Ausnahmezweig-Qualifikation **NOT_EXECUTED**.
Ein Disposefehler kann weiterhin den primären Fehler ersetzen. Historische
Nachweise bleiben erhalten; kein gemessener Leak oder neuer API-/Runtimevertrag.

## 2026-10-09 – Bestehende SemVer-Testorakel schließen

Die bestehenden Contractfälle weisen unerwartetes NULL sowie fehlende oder
mehrfache TVF-Ergebniszeilen ausdrücklich ab. Parser-, Präzedenz-,
Build-Metadata-, Größen-, ASCII-, Sort-Key- und Paritätsorakel behalten ihre
Inputs und Sollwerte; keine neue Negativsuite oder Produktkorrektur.
Quellenstand SOURCE_ONLY, neue verschärfte Tests **NOT_EXECUTED**.
Historische validierte Matrix, Modulversion `1.1.0`, Manifest, API und Workflow
bleiben unverändert; keine neue Matrix- oder Releasezusage.

## 2026-10-09 – Integer-Base-Plusziffer konsistent decodieren

Der bestehende Alphabetvertrag erlaubt `+` als reguläre Ziffer und reserviert
nur `-` als Vorzeichen. Der Decoder interpretiert kein zusätzliches positives
Vorzeichen; mit dem Dezimalalphabet bleibt `+1` ungültig. NULL-sichere positive
Orakel schützen die gezielten Plus-, Roundtrip- und SVF-/TVF-Fälle.
Quellenstand SOURCE_ONLY, neue Runtimequalifikation NOT_EXECUTED; bisherige
datierte Nachweise bleiben historisch. Modulversion `1.1.0` bleibt
unveröffentlicht und teilweise validiert, ohne neue Matrix- oder Releasezusage.


## 2026-10-09 – Eigene Commands der Split-Metadatenprobe schützen

Der Lab-only SqlClient-Testadapter schützt eigene Commands bereits vor Property- und Reader-Aufnahme. Ein Reader wird nur nach erfolgreicher Aufnahme disponiert; verschachtelte finally-Blöcke erreichen Command.Dispose auch bei einem Reader.Dispose-Fehler. SQL-Texte, Timeouts und Metadaten-/Resultsetorakel bleiben unverändert. Quellenstand SOURCE_ONLY; neue lokale/native Qualifikation NOT_EXECUTED. Hosted CI führt diesen Clienthelper nicht aus; kein gemessener Ressourcenverlust oder neuer öffentlicher Vertrag.

## 2026-10-09 – Eigenes Ausgabeziel des XLSX-Anzeige-Testadapters schützen

Der historische Offline-Anzeigeadapter schreibt seine abschließende Evidenz nur nach erfolgreicher eigener Verzeichnisanlage. Ein bereits vorhandenes Ausgabeziel bleibt nach der Frischeabweisung ohne neue Evidenzdatei; Verzeichnisanlage verwendet keinen Force-Modus. Compiler-, Kultur-, Transportorakel und Prozessgrenzen bleiben unverändert. Der geänderte Kontrollfluss ist quellengeprüft; keine neue lokale Framework-, SQL-, SAFE- oder Releasequalifikation.

## 2026-10-09 – Cologne-C-Kontextfälle im Differentialcorpus ergänzen

Vier synthetische Fälle `HCL`, `ACL`, `-CR` und `ACR` ergänzen den Offline-Corpus auf 36 Fälle. Der einmalige lokale Vergleich unter Windows/.NET Framework 4.8, ausgewähltem JDK27 und unverändertem Apache Commons Codec 1.18.0 bestand mit vollständigen Codes und AJ-Endblank; die vier quellenabgeleiteten Sollcodes `45`, `085`, `47` und `087` stimmen tatsächlich. Die Assembly mit nachgewiesener Herkunft aus den fünf unveränderten aktuellen C#-Quellen wurde wiederverwendet, ohne neuen Produktbuild für diesen Lauf.

Der frühere 32-Fälle-PASS und die historische Evidenz behalten ihren Umfang. stderr ist nur als leerer decodierter Rückgabetext belegt; Dateien bleiben erhalten, kein Datei-Cleanup-PASS. Produktcode, API, Workflow, Referenzmanifest, teilweise validierter/unveröffentlichter Modulstatus und offene SQL-/SAFE-, Scanner-/Matrix-, Minimalrechte- und Releasequalifikation bleiben unverändert.

## 2026-10-08 – ZIP-Writer-Framework-Testintake binden

Der bestehende Testadapter bindet SHA512 aus dem Release-Trustmanifest und die
exakte DLL-Länge, begrenzt die einmalige Aufnahme auf 4 MiB und lädt/referenziert
dieselbe eigene `CreateNew`-Kopie. Workflow-Caller, statische Kopplungschecks und
Testanleitung folgen diesem Vertrag; die eingebettete C#-Suite bleibt unverändert.
Dateien und Assembly werden behalten, nur eigene Handles geschlossen.
Neue Intake-/Frameworkqualifikation **NOT_EXECUTED**; kein Produkt-, API-,
Release- oder Validierungsstatuswechsel, keine zusätzliche SQL-/Matrixevidenz.

## 2026-10-08 – Begrenzten tatsächlichen Phonetik-Differentialnachweis ergänzen

Ein einmaliger lokaler Offlinevergleich unter Windows/.NET Framework 4.8 mit
ausdrücklich gewähltem JDK27 gegen unverändertes Apache Commons Codec 1.18.0
bestand am aktuellen Quellstand mit frisch gebauter Assembly: 32 synthetische
Fälle (16 Cologne/16 Double Metaphone), vollständige bytegleiche Codes und
AJ-Endblank. Unabhängige Read-only-Prüfung der erhaltenen Receipts/Pins und
Rohoutputs bestätigt diesen endlichen Vergleich; kein Rerun. SQL-/SAFE-,
Scanner-/Plattformmatrix-, Minimalrechte- und Releasequalifikation bleiben
offen; weiterhin teilweise validiert und unveröffentlicht. Produktcode, API
und Workflow unverändert, private Dateien behalten, kein Datei-Cleanup-PASS.
Die folgende PR301-Quellennotiz bleibt als damaliger NOT_EXECUTED-Stand erhalten.

## 2026-10-08 – Phonetik-Differential-Testadapter als Quellen ergänzen

Sechs gekoppelte Offline-Testquellen binden 32 synthetische Fälle, vollständige
Codes einschließlich AJ-Endblank und elf unveränderte externe Apache-Dateien
über ein portables Manifest. Runner, Modulmanifest, Testmatrix und Herkunfts-
dokumentation nennen explizite Inputs und begrenzte Prozess-/Transportverträge.
Kein neues SQL-Objekt oder Produktprovider; keine automatische Beschaffung.
Differentiallauf NOT_EXECUTED, Modul weiterhin teilweise validiert und unveröffentlicht.


## 2026-10-08 – Dateirepeat nach genuine Queue1.1-Migration ergänzen

- Unter der bestehenden Deploymentwartungsfreigabe vom 2026-10-07 folgt im
  vorhandenen `Queue11Upgrade`-Fall je local/central genau ein Repeat derselben
  Neun-Modul-Exportdatei nach dem unveränderten unmittelbaren Upgradevergleich.
  Neuer parameterloser Snapshot: 14 Tabellen/156 Felder einschließlich aller
  Rowversions, CountWitness auch für fünf leere Tabellen und 17 Katalogdomänen;
  vollständiger Vergleich ohne Migrationsnormalisierung oder Firstskip.
  Keine weitere persistente DML, Consumer-, Produkt-, API-, Ziel-, Rechte- oder Timeoutänderung.
- Vorausgehender [PR298](https://github.com/gecompat/SQL_Server_Toolbelt/pull/298)
  ist auf Main `b329b71d321ebbef78d19d6e6a2d4329b2d4f249` abgeschlossen:
  begrenzte Head-/Main-CI und eigene Bereinigung bestanden
  ([Worker](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37811779553),
  [Dokumentation](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37811779647));
  private Retention und eigene Refbereinigung abgeschlossen. Bestehende
  Fehler-/Vorbereitungshistorien bleiben erhalten, keine Ursachenclosure.
- Neue Sourceimplementierung vorhanden; native Repeatfolge und eigener Cleanup
  **NOT_EXECUTED**, exakte Head-/Merge-/Mainqualifikation **PENDING**.
  Kein zusätzlicher Windows-, Minimalrechte-, Matrix- oder Releasebeleg.

## 2026-10-08 – Genuine Queue1.1 im bestehenden Exporttest ergänzen

- Queue1.1-Testfixture: `#ExpectedChecks.ConstraintName` erhält explizites NULL für den absichtlich anonymen SchedulerCHECK-Witness; nur der zentrale Caller-Assertpin folgt. Die fachlichen CHECK-/Definition-/State- und Produkt-/API-/Cleanupverträge bleiben erhalten. Neunter Head26dc: Worker-CI FAILED, Dokumentations-CI PASS, `local-upgrade / UNCLASSIFIED / SQL515/2`; konkrete Tabelle/Spalte/Ursache und AFTER-Reachability sind nicht belegt. Drei bisherige Exportbereinigungen und Containercleanup bestanden, neue Exportbereinigung DEFERRED/RETAINED_UNPROVEN. Neue Head-CI, befüllte Migration, Merge/Main und Abschluss bleiben offen; alle historischen Fehlerstände bleiben erhalten.

- Queue1.1-Definitionsorakel: sechzehn ganze UTF16LE-Erwartungen werden aus gepinnten Original1.1-/aktuellen Quellen und festen objektspezifischen Command-/Stored-Headerabbildungen berechnet. Zwei einmalige lokale SQL2019-/Linux-Metadatenproben bestätigten private Erfassung und eigene DBbereinigung; keine Fixture-Seed-, Claim-, Worker- oder Repeatqualifikation. Strict-IF, fünf Flagprädikate, States und Verbatimdiagnosen bleiben unverändert; kein allgemeiner Normalizer, Runtimehashkopieren, alternativer Akzeptanzhash oder Produkt-/APIwechsel. Die bisherigen Golden-unverändert-Aussagen bleiben historische Diagnose-Quellenstände. Achter Head f2a6 bleibt FAILED/SQL55012/100, neue Dateibereinigung DEFERRED/RETAINED_UNPROVEN; alle acht Fehlerhistorien bleiben erhalten. Befüllte Migration, neue Head-/Main-CI, zentraler Modus, Windows, Rechte-/Matrix-/Releasequalifikation und vollständiger Abschluss bleiben offen.

- Queue1.1: erster verletzter ursprünglicher Definitionsleaf wird ausschließlich im fehlgeschlagenen BEFORE-Zweig nach unverändertem State19 und vor State6 über feste Komponente/Sourceordinal0..7 lokalisiert; SQL55012 mit festem Quelltoken `EXPORT_QUEUE11_BEFORE_DEFINITION_LEAF`, State20 beziehungsweise endliche Klassen30..117, weiterhin FAILED. Strict-IF, sechzehn Goldenhashes, State19/6, AFTER und Akzeptanz bleiben erhalten; genau ein zentraler Caller-Dateipin ändert sich. Siebter Head a318 FAILED/Docs PASS, State19 nicht beobachtet, Ursache ungemessen; neue native Qualifikation und Main bleiben offen. Die unmittelbar folgende State19-only-Notiz ist historischer a318-Quellenkontext.
- Queue1.1-Definitionenprüfung: zusätzliche FAIL-only-BEFORE-Klassifikation nur bei gemeinsamem Match aller acht festen Verbatim-Commandhashes und unveränderten Modulflags; weiterhin SQL55012, fester Quelltoken `EXPORT_QUEUE11_BEFORE_VERBATIM_DEFINITIONS`/State19, sonst State6. Ursprüngliches Strictgate, sechzehn Goldenhashes und AFTER-Prüfung bleiben unverändert; Caller ändert nur einen zentralen Assert-Dateipin. Sechster Head FAILED, tatsächliche Ursache und neue native Qualifikation offen.
- Testinterner Queue1.1-Quellenbezug liest den vorgesehenen versteckten Git-Store gezielt mit `Get-Item -Force`; der Caller erhält geschlossene, phasengebundene Codes für die vorhandenen zwanzig Acquisition- und sieben OwnedProcess-Fehler. Keine freien Laufzeittexte, neue Fallbacks oder gelockerten Ownership-/Budgetgates; neue native Qualifikation bleibt offen, historische Ursachen ungeklärt.
- Managed-Release-Test wartet gemeinsam auf den aktuellen eigenen Queuecommit
  und das separat gespeicherte Slotende; ursprüngliche Assertion und Budget bleiben
  erhalten. Vierter Head scheiterte vor allen Exportfällen; neue native Prüfung offen.

- Queue1.1 bindet ausdrücklich die erste vorhandene Application mit
  `Get-Command -TotalCount 1`; Datei-/Hash-/Ownershipgates bleiben erhalten.
  Dritter Fehlhead betrifft die Toolbindung, Ursache weiterhin ungemessen;
  neue native Prüfung und vollständiger Cleanupnachweis bleiben offen.

- Queue1.1: zweiter Head verwirft die Parent-Zeitgleichheit; Ursache bleibt
  ungemessen, Migration unqualifiziert und eigener Dateicleanup DEFERRED.
- Parent-/Root-Objektbindung im bestehenden Linux-CI-Fall verwendet private
  Geräte-/Inode-/Mode-Tupel über einen begrenzten, gepinnten vorhandenen Prozess.
  Neue native Prüfung steht aus; bestehende Datei-/Journal-/Cleanupgates bleiben.

- Erster Queue1.1-Headlauf ist im Root-Preflight fehlgeschlagen; Migration
  nicht qualifiziert, Dateicleanup DEFERRED, Containercleanup bestätigt.
- Dreizehn vorhandene Root-Prädikate erhalten getrennte feste Diagnosecodes;
  alle Bedingungen bleiben erhalten. Fehlgeschlagener Operand und Ursache
  bleiben unbekannt; neue native Diagnosequalifikation steht aus.

- Neuer begrenzter Testfall `Queue11Upgrade`: originale1.1-Installation, drei
  synthetische WorkItems und genau ein aktueller Neun-Modul-Export je local/central.
- Quellenbezug nur im eigenen normalen Linux-CI-Checkout, einmaliger fester
  Commitbezug und vollständige Elf-Blob-/Expansionsbindung vor DB-Anlage.
- Legacydaten, erwartete WorkItem-RowVersion-Wechsel und neue Sourceformen
  erhalten getrennte Orakel; unveränderte Repeat-/Queue20-/Parameterfälle bleiben.
- Native neue Migration und Cleanup **NOT_EXECUTED**, exakte Head-/Mainprüfung
  **PENDING**. Grenzen und vorausgehender PR297-Abschluss stehen in den
  [Deploymenttests](Deployment/Tests/README.md). Keine neue öffentliche SQL-API.

Weitere Statusfortschreibung 2026-10-08: Auch der zweite native Headlauf
`6abf635a26c314744fa3bba27d2eb289e9f4445d` ist **FAILED**
([Worker-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37729131172));
[Dokumentations-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37729131184)
bestand. Vier tatsächliche Checkouts sind über ihren Tree an diesen Head gebunden.
Die geschlossene lokale Upgrade-Diagnose SQL54998/State90 lokalisiert
`PARENT_COLUMN`, Sourceindex0: Das bisherige Prädikat
`c.parent_column_id <> 0` war wahr. Konkrete ID, Spaltenname, Mirrorzustand
und Ursache sind dadurch **UNMEASURED**. Der ursprüngliche 109-Feldervergleich
wurde davor erreicht; neue Completion, vollständiger Nach-Completion-Snapshot
und identischer Dateirepeat bleiben **NOT_EXECUTED**, die Folge **NOT_QUALIFIED**.
DefaultRepeat bestand, Parameterexport wurde übersprungen. Containercleanup
bestand separat; der einzelne Exportcleanup-Erfolgsmarker gehört zum
DefaultRepeat und belegt keinen eigenen Migrationcleanup.

Die neue Testassertion vergleicht zunächst die
Table-/Columnklassifikation mit dem Compiler-Mirror. Positive Columnbindungen
werden je eigenem Parentobjekt anhand acht fester Source-Spaltennamen und ihrer
Typform geprüft; der mehrspaltige Limits-CHECK verlangt beide Tablebindings0.
Absolute ColumnIDs werden nicht objektübergreifend gleichgesetzt. Derselbe
Invalid-Term gilt im Gesamtgate und in der endlichen State90-Diagnose;
Count-, Namen-, Definitionbytes-, Trust-/Flaggates und State12-Fallback bleiben.
Genau ein neuer vollständiger SQL150-Input/ein Batch bestand die reine
Offline-Grammatikprüfung. Ein unabhängiger Source-/Inverse-/Privacyreview
bestand ohne Blocker; er führte weder Parser noch SQL aus. Root hat den
Sourceentwurf vollständig gelesen. Diese Fortschreibung begleitet die
Übernahme der Testassertion. Native Parent-/Compilerqualifikation, neue
exakte Head-/Merge-/Mainqualifikation und eigener Cleanup bleiben **PENDING**.
Keine native Parent-/Compilerqualifikation oder Ursachenbehebung wird behauptet.

Statusfortschreibung 2026-10-08: Der erste native Lauf dieser Upgrade→Repeat-Welle
in [PR297](https://github.com/gecompat/SQL_Server_Toolbelt/pull/297) am Head
`913a3d6c42f4962a22c11656977bdf458d1bd15c` ist **FAILED**
([Worker-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37726736364));
[Dokumentations-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37726736429)
bestand. Die kombinierte Neun-CHECK-Assertion weist im lokalen Upgrade mit
SQL54998/State12 ab. Welche Unterbedingung und Sourcebindung verletzt ist,
bleibt **UNMEASURED**; ein Produktfehler oder eine Ursachenbehebung ist nicht belegt.
Der bisherige Immediatevergleich wurde davor erreicht. Die neue Completion
und der anschließende identische Dateirepeat sind **NOT_EXECUTED**, die neue
Folge ist **NOT_QUALIFIED**. Der separate DefaultRepeat bestand; der
Parameterexport wurde übersprungen. Containercleanup bestand separat;
der beobachtete eigene Exportcleanup-Erfolgsmarker gehört zum DefaultRepeat,
kein eigener Migrationcleanup-PASS wird daraus abgeleitet.

Die im Branch übernommene Diagnose ergänzt nur den bereits fehlgeschlagenen CHECK-
Zweig: höchstens drei lesende Queries, feste Komponenten und Sourceordinal0..8,
numerische States höchstens108 sowie der unveränderte State12-Fallback.
Originalgate und Erfolgsweg bleiben erhalten; keine tatsächlichen Katalognamen,
Definitionen oder Werte werden veröffentlicht. Ein neuer SQL150-Input/ein Batch
bestand die Offline-Syntaxprüfung. Native Diagnose, CHECK-Engineäquivalenz,
vollständige neue Folge und eigener Cleanup bleiben offen; neue exakte
Head-/Merge-/Mainqualifikation **PENDING**.
Bisherige Vorbereitungsangaben und alle Parentnachweise bleiben historische
Evidenz ihrer Quellenstände; keine Guards, Timeouts, Produkte, APIs oder Rechte ändern sich.

## 2026-10-08 – Repeat nach genuine Exportmigration im Branch ergänzen

- Die übernommene Testwartung ergänzt ausschließlich den bestehenden
  Queue20Upgrade-Fall: unveränderter acht-Tabellen-/109-Felder-Immediatevergleich,
  ein eigener Abschluss über die bestehende USP, begrenztes Vierfelderdelta,
  anschließend ein Repeat derselben Exportdatei gegen alle 14 Tabellen/156
  Felder mit fünf Leerzeugen und positivem Constraintinventar.
- Source, Deploy, API, Control-/Queuegates, Timeouts, Ownership und Cleanup
  bleiben erhalten; keine neue Scenariooption, DB, Exportdatei oder Rechte.
- Autor-Syntaxnachweis: fünf neue SQL150-Inputs/35 Batches und Adapter-AST
  fehlerfrei; kein Engine- oder Runtime-Nachweis. CHECK-Engineäquivalenz,
  native Folge und eigener Cleanup **NOT_EXECUTED**;
  eigene Head-/Merge-/Mainqualifikation **PENDING**. Unabhängiger Source-/
  Client-/Privacyreview der eingefrorenen Payloads bestanden.
  Keine historische Fehlerursache wird damit als behoben ausgewiesen.

View-Mainvoraussetzung erfüllt, Stand 2026-10-08: [PR296](https://github.com/gecompat/SQL_Server_Toolbelt/pull/296)
ist nach `main` `c1dc014d94f6ce827bd52ef542722faea5bb267b` gemergt.
[Main-Worker-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37723945915)
und [Main-Dokumentations-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37723945917): **PASS**.
Der Nachweis ist auf Linux SQL Server 2019/CL150 local/central und den bisherigen
View-Spalten-/Exportscope begrenzt; er qualifiziert diese neue Upgrade→Repeat-Folge nicht.

## 2026-10-08 – View-Spaltenannotation im bestehenden Exportrepeat prüfen

- Zwei eigene class-1-Properties auf `VW_WorkQueue.RowVersion`:
  Unicode-/Paddingbeschreibung und `varbinary(5)`, gebunden an tatsächliche column_id.
- Setup und Assert ergänzen Count2 und beide vollständigen typisierten EXCEPT-
  Vergleiche; Capture, Adapter, Workflow und öffentliche Verträge bleiben erhalten.
- Native View-Spaltenprüfung und eigener Cleanup: **NOT_EXECUTED**; eigene exakte
  Head-CI sowie Merge-/Mainqualifikation einschließlich Cleanup: **PENDING**.

Class1-Voraussetzung erfüllt: PR295, Main `a585803de0d1d94be595dbf7b3153e582fbff9d2` (2026-10-08).
[Main-Worker-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37721226636) und [Main-Dokumentations-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37721226645): **PASS**.
Der begrenzte Nachweis gilt für Linux SQL2019/CL150 local/central; sechs Objektzeugen, drei eigene Exportbereinigungen und Containercleanup sind belegt. Er qualifiziert keine neuen View-Spaltenzeugen und erklärt keine historische Fehlerursache.

## 2026-10-08 – Objektannotation im bestehenden Exportrepeat prüfen

- Setup und Assert erhalten sechs kollisionsgeprüfte class-1/minor0-Zeugen
  auf einer bestehenden Prozedur, Scalarfunktion und View; Count6 und beide
  EXCEPT-Richtungen vergleichen den vollständigen typisierten Werttupel.
- Capture, Definitionserfassung, Adapter, Workflow und öffentliche Verträge bleiben erhalten.
- Native class1-Prüfung und eigener Cleanup: **NOT_EXECUTED**; exakte Head-/Main-CI **PENDING**.

Class3-Voraussetzung erfüllt: PR294, Main `91e13af689334407527fddfdc8d22285933f4225` (2026-10-08).
[Worker-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37717103755) und [Dokumentations-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37717103790): **PASS**.

## 2026-10-08 – Schemaannotation im vorhandenen Exportrepeat prüfen

- Drei bestehende DefaultRepeat-Fixtures erhalten fünf kollisionsgeprüfte class-3-
  Zeugen sowie zwei vollständig verglichene Katalogkategorien auf zwei Schemas.
- Source, Deploy, Adapter, Workflow und Parameter-/Queue20Upgrade-Fälle bleiben
  unverändert. Der Branch ergänzt nur die Fixtures und vier Begleitdokumente.
- Native class3-Prüfung einschließlich eigener Bereinigung: **NOT_EXECUTED**.

Voraussetzung, Stand 2026-10-08: PR293 ist nach `main`
`2ad2c018da18768c05f05e0fd7cf4c333fd6b090` gemergt.
[Main-Worker-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37715148163)
und [Main-Dokumentations-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37715148155)
bestanden am exakten Mainstand; Parameterrepeat, beide bestehenden Exportfälle,
drei eigene Exportbereinigungen und Containercleanup sind separat bezeugt.
Die Parameter-Mainvoraussetzung ist erfüllt. Native class3-Prüfung und
eigener Cleanup sind **NOT_EXECUTED**; die eigene exakte Head-/Main-CI
einschließlich Bereinigung bleibt **PENDING**.


## 2026-10-08 – Parametermetadaten beim exportierten Repeat prüfen

- Der vorbereitete Testfall `ParameterMetadata` bindet die bestehenden
  `USP_PrepareResultTable` und `USP_EnqueueWork` mit elf Parametern an die
  echte Dreimodulfolge result-table/work-type/work-queue, lokal und zentral
  mit Erstinstallation und einem Repeat derselben hashgebundenen Exportdatei.
- Vier kollisionsgeprüfte class-2-Zeugen auf zwei Parametern umfassen
  typisierte Annotationen und `MS_Description`. Private binäre Snapshots
  vergleichen Parameter-, ausgewählte Objekt-/Modul-, Definitions- und
  Propertymetadaten sowie nur beobachtete Permissions mit Nullmengenzeugen.
  T-SQL-`has_default_value = 0` beweist keine Defaults; Definitionbytes
  werden getrennt erhalten.
- Produktquellen, Deployment-DDL, öffentliche API, Berechtigungen und Ziele
  bleiben unverändert. Die bestehenden Repeat-/Queue20Upgrade-Fälle bleiben
  erhalten. Offlineprüfungen und unabhängige Reviews bestanden: beide
  Dreimodul-Exporte mit je 90 Batches, insgesamt 180 SQL150-Parses ohne Fehler,
  Adapter-AST ohne Fehler. Native Parameterprüfung und eigener Cleanup sind
  `NOT_EXECUTED`; Integration und exakte Head-CI stehen aus.

Voraussetzung für die Parameterintegration, Stand 2026-10-08: PR292 wurde
nach `main` `c73f67959185c7a7846455b89c067854dc7d87f6` gemergt.
Die [Main-Worker-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37713277392)
und [Main-Dokumentations-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37713277427)
bestanden am exakten Mainstand. Alle drei Workerjobs sowie beide bestehenden
Exportfälle bestanden; die tatsächlichen Festmarker bezeugen beide Export-PASS,
zweimal eigenen Exportcleanup und einmal eigene Containerbereinigung.
Auch die bestehende Control-Repeat- und Ablehnungsabnahme bestand.
Der neue unerwartete SQL-Diagnosezweig wurde dabei **NOT_TRIGGERED**;
seine Offline-Negativprüfung bleibt ein getrennter Nachweis. Der frühere
Mainfehler auf `f8b9b407ad30fc560015b8b475005b4505617689` und seine
weiterhin **UNMEASURED** Ursache bleiben unveränderte Historie; der erfolgreiche
Lauf belegt keine Ursachenbehebung.
Die native Parameterprüfung einschließlich eigener Bereinigung bleibt
**NOT_EXECUTED**. Der Mainnachweis wurde unabhängig geprüft; der Parameter-
branch enthält Adapter, Fixtures und CI-Schritt für die eigene Headprüfung.
Sämtliche bisherigen
Migrations-/Fehler-/Parentnachweise bleiben vollständig erhalten.

## 2026-10-08 – Genuine Queue2.0 über die aktuelle Exportdatei migrieren

- Der getrennte Testfall `Queue20Upgrade` installiert sieben aktuelle
  Bootstrapmodule, die gepinnte Original-Queue2.0 und anschließend den echten
  vollständigen Neun-Modul-Export lokal/zentral in frischen Sitzungen.
- Acht alte Tabellen mit 109 Feldern einschließlich aller 43 WorkItem-Felder,
  einem aktiven Legacyclaim, Rowversions, Audit-/Text-/Tokenbytes, verbrauchten
  Identitywerten und ausgewähltem Katalog werden vor weiterer DML privat
  verglichen. Die leere Barrier-Tabelle wird ausdrücklich erfasst.
- Rein lesende Assertions prüfen die drei neutralen Managedfelder sowie die
  Spaltenformen und neutralen Zustände der sechs neuen Gate-/Controltabellen.
  Danach erfolgt nur eigene Bereinigung; keine Post-Migration-Completion,
  neue Admission oder zusätzliche 14-Tabellen-Repeatfolge.
- Keine Source-, Deploy-, API-, Callback-, Provider-, Rechte-, Konfigurations-
  oder Truständerung. Bestehende Repeatfixtures bleiben unverändert.
  Offlineprüfungen und unabhängiger Domainreview bestanden; native Migration
  ist `NOT_EXECUTED`. Parent PR290 bestand den begrenzten nativen Exportrepeat
  am Qualifikationshead `a836b87778fbe4c498b4b1ce05f06c58373ea03c`
  ([CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37701845352));
  frühere FAILED-Läufe bleiben historische Evidenz. Finale Parent-Head-CI am
  Stand `bdc2ba9f001190d9d63cc97e040f1e693fb4dafd` bestand; PR290 ist nach
  `origin/main` integriert, Mainstand `acba925419973d9dfb2b7b8e481d67f0a75789e3`.
  Main-Dokumentations- und Main-Worker-CI einschließlich eigener Bereinigung
  bestanden; eigene native Migrationsqualifikation ist noch offen.

- Statusfortschreibung: Der erste native Migrationslauf am Head
  `1d4f9cbdde094c2c59c22eb01b5c5ee261df73b0` ist FAILED
  ([CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37705019236));
  Dokumentations-CI desselben Heads bestand. Die öffentlichen ResultTable-
  Ziele `#tbx_ExportUpgradeStatus`/`#tbx_ExportUpgradeClaim` verletzen den
  bestehenden reservierten `#tbx_`-Präfixvertrag (`51020`/State `1`). Nur die
  eigenen Fixtureziele werden als `#ExportUpgradeStatus`/`#ExportUpgradeClaim`
  vorbereitet; die korrigierte native Migration ist NOT_EXECUTED. Wholejob-
  Cleanup bestand separat; auf dem Fehlerpfad fehlt ein Erfolgsmarker der
  eigenen Migration-DB-/Dateibereinigung. Kein eigener Cleanup-PASS daraus.
  Frühere Syntax- und Reviewnachweise sowie Parenttexte bleiben erhalten;
  keine Source-, Deployment-, Guard-, Orakel- oder Vertragsänderung.


Statusfortschreibung 2026-10-08: Der zweite Lauf am korrigierten Head
`2735ad3167174d8986857e2f16ec92c3c6942beb` ist bereits in den unveränderten
Managed-Worker-SQL-Contracts **FAILED**
([CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37706094651));
[Dokumentations-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37706094720)
bestand. Das feste Oracle `MANAGED.UNEXPECTED_UNKNOWN` meldet ein unbekanntes
Workerende im Fall `budget-two`, nach `LIVE_BUDGET_TWO_REDUCED_WITHOUT_CANCEL`.
Beide Export-Schritte wurden **SKIPPED**; die korrigierte native Migration
bleibt **NOT_EXECUTED**. Always-Containercleanup bestand. Die zugrunde liegende
Actor-/Guardianursache ist nicht gemessen; SQL0 der generischen Waitexception
belegt keinen Actor-SQL-Code. Eine begrenzte Diagnoseergänzung an der Testfixture
soll bereits vorhandene Actor-/Guardianfelder ausschließlich als feste
Sourcecodes, typisierte numerische SQL-Codes und Statusflags sichtbar machen.
Workerprodukt, SQL, Orakel, Timing, Ressourcen und Cleanup bleiben unverändert;
kein unveränderter Retry oder gelockerter UNKNOWN-Guard qualifiziert den Test.

Statusfortschreibung 2026-10-08: Der begrenzte native Export-Migrationsfall
in [PR291](https://github.com/gecompat/SQL_Server_Toolbelt/pull/291) besteht
am Qualifikationshead `155f74c9d11548cf600e7770f0d0d12e0720a7f4` (**PASS**;
[Worker-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37707910466),
[Dokumentations-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37707910490)).
Auf SQL Server 2019 Linux/CL150 bestand lokal und zentral die tatsächliche
Exportfolge: sieben aktuelle Bootstrapmodule (124 Batches), die gepinnte
Original-Queue2.0 (46 Batches) und der vollständige aktuelle Neun-Modul-Export
(261 Batches), jeweils in frischen ungepoolten Sitzungen. Acht Legacytabellen
mit allen 109 Feldern einschließlich der 43 WorkItem-Felder und des aktiven
Legacyclaims bleiben vor weiterer persistenter DML bytegenau erhalten;
Rowversions, Tokens, NULLs, Audit-/Textbytes, verbrauchte Identitywerte und
ausgewählte Katalogmetadaten sind eingeschlossen. Nur die dokumentierten
Queue-Versions-/Check-ID-Normalisierungen sind ausgenommen. Die drei neutralen
Managedfelder und die bekannten Spaltenformen/neutralen Zustände der sechs
neuen Gate-/Controltabellen bestehen die lesenden Assertions. Eigene
Migration-DB-/Dateibereinigung und separate Containerbereinigung bestanden.
Auch der vorhandene gemeinsame befüllte Exportrepeat bestand separat; die
Migration erhält keine Post-Migration-Completion, Admission, neue Callback-/
SQL-API oder zusätzliche Repeatfolge. Keine Rechte-, Provider-, Trust-,
Konfigurations- oder Zielausweitung; weitere Plattformen/CLs, Minimalrechte,
nichtleere Grants und allgemeiner 44-Modul-Lifecycle bleiben offen.

Frühere Vorbereitungs-/NOT_EXECUTED-Angaben und beide FAILED-Läufe einschließlich
der SKIPPED-Exportschritte bleiben historische Evidenz ihrer Quellenstände.
Der Erfolg schreibt keine früheren Fehler oder fehlenden Cleanupnachweise um.
Die Actor-/Guardianursache des früheren Managed-UNKNOWN bleibt **UNMEASURED**;
im erfolgreichen Lauf erschien kein UNKNOWN-Diagnosedescriptor. Die begrenzte
Beobachterabbildung ist offline validiert; ihre UNKNOWN-Ausgabestrecke wurde
hier nicht ausgelöst. Der UNKNOWN-Guard bleibt unverändert; daraus wird kein
Workerprodukt- oder Ursachenfix abgeleitet. Parentnachweise bleiben erhalten.
Finale Head-CI nach dieser Evidenzfortschreibung, PR291-Merge und anschließende
Main-CI einschließlich Maincleanup sind noch offen.

Statusfortschreibung 2026-10-08 nach PR291-Merge: Die vorstehende offene
Abschlussangabe beschreibt den damaligen Stand. Der erfolgreiche
Qualifikationshead `155f74c9d11548cf600e7770f0d0d12e0720a7f4` bleibt erhalten;
auch der finale Head `6a28ba484760d181ce2b37833b339780084a457d` bestand
[Worker-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37709411383)
und [Dokumentations-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37709411388).
PR291 wurde nach `main` `f8b9b407ad30fc560015b8b475005b4505617689` gemergt.
Die [Main-Dokumentations-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37709938821)
bestand; die [Main-Worker-CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37709938890)
ist **FAILED** im bestehenden Schritt „Execute genuine Queue 2.0 to 2.1
upgrade“. Die vorherigen realen Linux-Worker-, Managed- und Admissionprüfungen
bestanden. Beide neuen Export-Schritte sind **SKIPPED / NOT_EXECUTED**.
Die separate eigene Containerbereinigung bestand mit genau einem tatsächlichen
festen Cleanupmarker; daraus folgt kein eigener Export- oder Fixturecleanup-PASS.
Die beiden früheren FAILED-Läufe bleiben unverändert historische Evidenz.

Der geschlossene Fehlerbefund nennt die Sourcephase
`control-repeat-post-source-rollback`, SQL1222, die äußere Source-Skriptzeile141
und Orakel `UNSPECIFIED`; der bestehende Sourcefall erwartet SQL54969/State1.
Ein numerischer Enginefehlerdescriptor wurde nicht ausgegeben. Enginezeile,
tatsächlicher State, erster fehlgeschlagener Batch und Blockerursache bleiben
**UNMEASURED**. Weder ein
Timingproblem noch ein Produktfehler ist damit ursächlich belegt; die frühere
Managed-UNKNOWN-Ursache bleibt ebenfalls offen. Kein Main-PASS wird abgeleitet.

Die begrenzte Diagnosewartung liegt als privater, eingefrorener
Testfixturekandidat vor. Ausschließlich `Invoke-ControlRepeatExpectedFailure`
erfasst vor dem unveränderten Weiterwerfen der ersten unerwarteten SQL-Abweisung
den Batch und höchstens vier numerische Enginefehler im vorhandenen
`fixtureSqlFailure`-Pfad; Texte sind auf fünf vorhandene Source-Guardmeldungen
oder leer beschränkt. Die bestehende geschlossene Descriptorabbildung gibt
keine freien Fehlertexte aus. Offlineprüfungen und unabhängiger Client-/Privacy-
Review bestanden: erste begrenzte Erfassung ohne Überschreiben, erwartete
Abweisungen und State-Wildcard unverändert, unbekannte Meldungen ausgeschlossen
und ursprüngliche Exception auch bei fehlgeschlagener Erfassung erhalten.
Syntax sowie vollständige Byteerhaltung außerhalb dieser Diagnosefunktion
wurden offline geprüft. Die native Ausführung des Kandidaten ist
**NOT_EXECUTED**; Ursache und Mainqualifikation bleiben offen. Erwartete
Abweisungen, Orakel, Timing, Transaktions-/Ownership-Guards, Produktquellen,
Ziele und Cleanup bleiben unverändert; kein unveränderter Retry ersetzt diesen
Nachweis. Kanonische Main-Adoption von ParameterMetadata und class3-
Schemaannotation bleibt bis zur Mainqualifikation gesperrt; private Vorbereitung
kann innerhalb der bestehenden Grenzen fortgesetzt werden.


## 2026-10-08 – Befüllte exportierte Modulfolge gemeinsam prüfen

- Ein begrenzter Adapter verwendet den echten SQL-Export von neun CLR-freien
  Modulen für Erstinstallation und zwei befüllte Repeats lokal/zentral in
  frischen Sitzungen. Alle 14 Tabellen, Rowversions, Audits, Identitywerte und
  ausgewählte Katalog-/Annotationsmetadaten werden privat verglichen.
- Die zwei bestehenden kanonischen Normalisierungen im ersten Repeat werden
  separat geprüft; der zweite muss vollständig unverändert sein. Eigene
  Datenbanken werden nur nach frischer Besitz-/Verbraucherprüfung gelöscht.
- Der vorhandene externe Linux2019/CL150-CI-Job erhält den Test und passende
  Source-/Exportpfade. Keine Source-, Deploy-, API-, Infrastruktur-, Provider-,
  Rechte- oder Truständerung. Offlineprüfungen bestanden; neue native Evidenz,
  Windows, weitere Matrix und SQLCMD-/44-Modul-Qualifikation bleiben getrennt.
- Erster gemeinsamer nativer Head-Lauf FAILED; vorhandene Worker-/Upgradefälle
  und eigene Containerbereinigung bestanden. Der Diagnoselauf begrenzt den
  Fehler auf den Verbindungs-Preflight: Zwei ungültige PowerShell-Builder-
  Dotzuweisungen sind ohne SQL reproduziert und werden durch explizite gültige
  Indexer ersetzt. Der separate Cleanup-Pfadseparatorfehler ist korrigiert;
  beide FAILED-Läufe bleiben erhalten, kein unveränderter Retry.
- Nach Builderkorrektur besteht der Preflight; das eigene Datenbank-/
  Sitzungsgate weist den Lauf weiterhin ab. Feste Einzelstates zeigen:
  Alle Einzelbedingungen bestehen, das kombinierte Gate wirft State 13.
  Neutrale Sitzungsprüfungen werden vor und nach den gemeinsam gebundenen
  Besitzprädikaten getrennt ausgewertet; Autocommit im Katalogstatement bleibt
  eine nicht direkt gemessene Hypothese.
  Vorherige Runtimefälle und Containerbereinigung bestanden.
- Nach Trennung des Adaptergates bestehen eigene Besitzprüfung und
  Erstinstallation. Der folgende Fehler liegt im initialen Fixture-
  Sitzungsgate (SQL54980/State1); dessen kombinierte Sitzungsbedingungen
  werden ohne Prädikatverlust in einzelne IFs getrennt. Zu diesem Stand war
  native Qualifikation noch offen; historische FAILED-Läufe bleiben erhalten.
- Der korrigierte Head `a836b87778fbe4c498b4b1ce05f06c58373ea03c` besteht die
  gemeinsame Neun-Modul-Folge auf Linux2019/CL150 lokal/zentral: zwei befüllte
  Repeats aller 14 Tabellen, eigene DB-/Datei- und Containerbereinigung sowie
  vorhandene Worker-/Upgradefälle
  ([CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37701845352)).
  Dokumentations-CI ebenfalls bestanden; übrige Plattform-/Client-/44-Modul-
  und Releasegrenzen bleiben offen.

## 2026-10-07 – Deaktivierten SecondSessionProvider über Deploys erhalten

- Zwei echte 1.1.0-Repeats vergleichen alle acht Spalten eines deaktivierten
  synthetischen Einzelproviders einschließlich Audit-/Text-/Rowversionbytes,
  ausgewählten Katalog und eigene Tabellen-/Spaltenbeschreibungen.
- Der vorhandene Linuxadapter ruft die neue Fixture lokal/zentral vor seiner
  bestehenden Providerkonfiguration auf. Source, Deployment und API bleiben
  gleich; der neue Test benötigt keinen RPC. Native neue Evidenz und offene
  Windows-/Minimalrechte-/Benutzergrant-/historische Fälle bleiben getrennt.
- Der neue Repeat bestand am 2026-10-08 am Commit
  `32ee260e413b8de7f9b2046ffdc11618b0afd69b` auf Linux2019/150,2022/160,
  2025/170 jeweils lokal/zentral; bestehende Provider-/API-/Lifecyclefälle und
  eigene CI-Bereinigung ebenfalls. Abhängige EventLog-Suite am selben Head
  bestanden ([CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37693379887)).

## 2026-10-07 – EventLog-Datenerhalt und WorkType-Reaktivierung prüfen

- Zwei echte versionsgleiche Deploys vergleichen alle 24 Eventspalten,
  verbrauchte Identitywerte und ausgewählte Katalog-/Annotationsmetadaten.
  Die bestehende WorkType-Reaktivierung wird im ersten Deploy separat geprüft;
  der zweite muss die aktive Registrierung einschließlich Rowversion erhalten.
- Der vorhandene Linuxadapter ersetzt den lokalen COUNT-only-Redeploy und
  ergänzt denselben Test zentral. Neue Repeat-Auditresultsets bleiben privat.
  Source, öffentliche API und Deployment bleiben gleich; native neue Evidenz
  sowie offene Windows-/Minimalrechte-/Benutzergrantfälle bleiben getrennt.
- Der neue Repeat bestand am Commit `6f51078cfa1f13ace32212f07d46de8d55d39ef0`
  auf Linux2019/150,2022/160,2025/170 jeweils lokal/zentral; bestehende
  API-/Rollback-/Parallelitäts-/Consumer-/Uninstallfälle und eigene
  CI-Bereinigung ebenfalls
  ([CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37692309192)).

## 2026-10-07 – Befüllte Cancellation-Repeats prüfen

- Zusätzliche Testfixtures qualifizieren zwei echte versionsgleiche Deploys
  mit synthetischen Cancellation-Zeilen einschließlich Rowversionbytes,
  Auditzeiten, NULLs und exakten Textbytes sowie ausgewähltem Katalog.
  Source, Deploy und öffentliche Cancellation-Semantik bleiben gleich.
- Der vorhandene W6d-Linuxadapter führt die Fixtures lokal/zentral vor
  den bisherigen API-, Parallelitäts- und Consumerfällen aus. Neue Windows-,
  Minimalrechte-, Benutzergrant- und historische Migrationsqualifikation
  wird daraus nicht abgeleitet; native Ergebnisse werden gesondert erfasst.
- Der neue Repeatnachweis bestand am Commit
  `fac18e590f854a26364e5f498c6a2b5d330a95c2` auf Linux2019/150,2022/160,
  2025/170 jeweils lokal/zentral mit unveränderten Rowversions und eigenen
  nichtleeren Tabellen-/Spaltenbeschreibungen; bisherige API-/Lifecyclefälle
  und eigene CI-Bereinigung ebenfalls
  ([CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37690604199)).

## 2026-10-07 – Befüllte File-Content-Repeats prüfen

- Ein zusätzlicher Lifecycle-Contract führt zwei echte versionsgleiche
  Deploys mit aktiven/inaktiven synthetischen Allowlist-Zeilen aus. Exakte
  Daten, Auditzeiten, verbrauchte Identitywerte, Katalog und vorhandene
  Berechtigungsmetadaten werden verglichen; die kanonische Tabellenbeschreibung
  wird separat geprüft. Source, öffentliche API und Deploy bleiben gleich.
- Der vorhandene Linuxadapter führt den Tabellenrepeat lokal und zentral
  vor seiner bestehenden Datei-I/O-Konfiguration aus. Windows, weitere CLs,
  nichtleere Benutzergrants, Minimalrechte und historische Migrationen bleiben
  offen; `partially validated` und `unreleased` bleiben bestehen.
- Der gezielte Repeatnachweis am Commit `8effcee91106cb4b8924c7a839928d550c0653b6`
  bestand am 2026-10-07 auf SQL Server 2019/150, 2022/160 und 2025/170 Linux
  jeweils lokal/zentral; die bestehende Datei-Suite und Uninstall bestanden
  ebenfalls ([CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37687448814)).

## 2026-10-07 – Veröffentlichungsnachweise und freiwillige Fehlermeldungen

- Das kanonische Modulmodell verbindet veröffentlichte Versionen mit exaktem
  Quellcommit, qualifiziertem Supportumfang, Freigabefundstelle, öffentlichem
  Release und Asset-Hashes. Build-/CI-Artefakte bleiben eigene Schritte.
- Der Dokumentationsvalidator trennt lokale Strukturprüfung von ausdrücklich
  gewählter GitHub-GET-Abnahme; fehlende oder widersprüchliche externe Evidenz
  wird nicht als Bestätigung dargestellt. Synthetische Regressionen sind an
  die vorhandene Change-Impact-Prüfung gekoppelt.
- CONTRIBUTING und das vorhandene Fehlerformular erklären Herkunftsangaben,
  Grenzen installierter Versionsmarkierungen und freiwillige synthetische
  Reproduktionen. Keine neue SQL-API, Veröffentlichung, Tag-Erzeugung,
  Statusaufwertung, Telemetrie oder Lizenzänderung.

## 2026-10-07 – Ruhender Queue-/Control-Repeat erhält persistente Steuerung

- Bekannte vollständig installierte Queue2.1-/Control1.0-Stände können bei
  deaktiviertem Managedgate ohne Claims, Holds oder offene Reservations
  gemeinsam erneut deployed werden. Andere Consumerstände und Queue-Uninstall
  behalten ihre Abweisung; kein automatischer Controlabbau oder Zustandsreset.
- Beide Lifecyclepfade verwenden denselben Compatibilitypreflight und
  begrenzte Schreibsperren bis Commit. Der vorhandene externe Upgradeadapter
  ergänzt zwei befüllte Verbundrepeats und prüft Daten-/Token-/Identity- und
  Katalogerhalt. Der temporäre Releasemanifest-Schlüssel ist anonym und
  kollidiert deshalb nicht zwischen getrennten Deploymentsessions.
- Der gezielte Verbundnachweis bestand am 2026-10-07 auf SQL Server 2019 Linux
  einschließlich Caller-/Zustands-/Sperr-/Source-Rollbackfällen und eigenem
  Cleanup ([CI](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37672934548)).
  Die Queue-Runtime-Matrix bestand separat auf 2019/2022/2025 Linux.
  Nach Merge dieser Runde pausiert die Entwicklung auf Benutzerauftrag;
  offene Schritte und Grenzen stehen in `.ai/BACKLOG.md`.

## 2026-10-07 – Queue-Repeat erhält gültige Retry-/Barrierzustände

- Die vorhandene WorkItem-Migration legt beim Repeat keine vorübergehende
  veraltete Vier-Status-Constraint mehr an. Die endgültige W6c-Constraint wird
  weiterhin innerhalb des Moduldeployments validiert; Daten und Statuswerte
  werden für diese Korrektur nicht umgeschrieben.
- Der genuine Queue2.0→2.1-Adapter erhält einen befüllten Zweifach-Repeatnachweis
  für alle sieben Zustände. Gemeinsamer Worker-Control-Repeat bleibt separat.

## 2026-10-07 – Eigenständiger SQL-Export aus aktuellen Modulskripten

- `Deploy-All.ps1 -OutputSqlFile` erzeugt ohne SQL-Verbindung eine einzelne
  UTF-8-SQLCMD-Datei mit eingebetteten Includes, geprüften Eingaben und
  deterministischer Dependency-Reihenfolge. Bestehende Dateien werden nicht
  überschrieben; Verbindungsoptionen sind im Exportmodus unzulässig.
- Frische Sitzung und Fehlerabbruch sind erforderlich. Transaktionsguards
  an Modulgrenzen erhalten die bestehenden Lifecycle-/Migrationssperren.
  Kein generischer Tabellen-Refresh, keine Trustfreigabe oder Gesamt-Rollback;
  jederzeitiges datenbewahrendes Gesamtdeployment bleibt separat offen.

## 2026-10-07 – Discovery prüft Origins vor Vorschlag und Transport

- Der bestehende Konfigurationsclient weist ungültige Discovery-Origins vor
  Requesterzeugung ab. Nur credential-freies HTTP(S) ohne URL-Anhänge ist
  zulässig; Steuerzeichen, Whitespace, fehlerhafte Ports/IPv6 und kodierte
  Authorities werden ebenfalls abgewiesen.
- INVALID_ENDPOINT gibt keinen Kandidateninhalt wieder und blockiert den
  sicheren Default nicht. Loopbackallowlist, Nicht-Loopback-Autoritätsgrenze,
  Vorschlagsflags und Probe-only-Verhalten bleiben erhalten. Keine
  Runtimeaktivierung, Konfigurationsmutation oder SQL-/Provideränderung.

## 2026-10-07 – Foundation-Discovery bleibt im begrenzten Probe

- Der getrennte Versionsprobe verwendet den bestehenden16MiB-/64KiB-Reader
  vor JSON und verweigert Redirects vor Folgekontakt. HTTPError-Antworten werden
  ohne Bodyread geschlossen; neue Größen-, EOF- und Encodingablehnungen bleiben
  im bisherigen UNAVAILABLE-Vorschlag isoliert.
- Kandidatenauswahl, Probeflags, Timeouts und Bestätigungsgrenzen bleiben erhalten.
  Original1.19-Provenienz und vorherige Overrides bleiben gebunden. Keine Runtime-,
  Konfigurations-, Netzwerk- oder SQL-Erweiterung; Initialvalidierung, DNS-/Proxy-,
  Pfadrennen-, Heap-/Gesamtzeit- und Endpointqualifikation bleiben eigenständig.

## 2026-10-07 – Foundation-HttpAdapter liest begrenzte Antwortbodies

- Probe/Catalog/Invoke im gemeinsamen HTTP-Adapterpfad lesen vor JSON und
  Outputmutation höchstens16MiB plus ein Overflowbyte. Größere Antworten werden
  strukturiert abgewiesen; kurze Reads und positive Restlänge am EOF bleiben
  kontrolliert. Ein Schließfehler verdeckt die festgestellte Abwehr nicht.
- Neue feste Transportgrenze ohne Configknopf, auch für legitime größere
  Antworten. Originale Foundation1.19-Provenienz bleibt erhalten; keine SQL-,
  Runtime-, Netzwerk-, Provider- oder Rechteerweiterung. Discovery-Readpfad,
  Pfadrennen, Heap-/Gesamtzeit- und reale Endpointqualifikation bleiben offen.

## 2026-10-07 – Foundation-Redirects vor dem Folgekontakt prüfen

- Der bereits ausgewählte optionale Host-Preparation-Client bindet Download-
  und Cost-Evidence-Redirects vor Dispatch an HTTPS, ursprünglichen Host und
  Port443. Same-origin-Ketten bleiben erlaubt; Fremdorigins und Userinfo werden
  vor Kontakt abgewiesen. Verweigerte Antworten werden ohne Bodyread geschlossen.
- Source1.19.0 bleibt als Ausgangsprovenienz erhalten; die zwei betroffenen
  installierten Dateien sind explizite Target-Overrides. Keine Runtimeaktivierung,
  Provisionierung, Rechte-/Providererweiterung oder SQL-Produktänderung.

## 2026-10-07 – Windows-Directory-Delete hält die geprüften Grenzen ein

- Die bestehende rekursive Löschung erstellt vor der ersten Mutation einen
  vollständigen Prüfplan. Childdirectories jenseits von `@MaxDepth` und zu
  viele Einträge werden vorab abgewiesen; anschließend werden ausschließlich
  geprüfte Einträge und Directories nichtrekursiv gelöscht.
- Frische Reparse-/Typprüfungen ergänzen den Plan. Dateisystemraces und
  Teilzustände nach I/O-Fehlern bleiben offen; SQL-Verträge, Identitäten,
  Rechte, Trust-Opt-in, Provider und Modulversion bleiben erhalten.

## 2026-10-07 – File-Content-Roots mit literaler Verzeichnisgrenze

- Die beiden bestehenden Datei-Lader verwenden ein gemeinsames SQLCMD-
  Prädikat. Ein Root ohne abschließenden Slash erlaubt nur den exakten Pfad
  oder Nachfahren; Geschwisterpräfixe und LIKE-Metazeichen erweitern ihn nicht.
- Leere Roots autorisieren keinen Pfad. BIN2-Vergleich mit expliziter UTF-16-
  Länge bewahrt Leerzeichen und Unicode-Grenzen. Der bestehende Fehlercode
  `51321`, öffentliche Signaturen, Objekte, Provider und Rechte bleiben erhalten.

## 2026-10-07 – ScriptDom-Pin und selektives Deployment

- Der freigegebene ScriptDom-Pin ist jetzt FileVersion `18.0.117.0`; Parser-
  und Table-Clone-Trigger-Hashes sind gekoppelt. Die neue Windows-SQL-
  Lifecycle- und Triggerqualifikation bleibt offen; das Modul bleibt unveröffentlicht.
- Der neue Deployment-Runner wählt Module mit ihren transitiven Manifest-
  Abhängigkeiten, einschließlich Flow-Mappings. PlanOnly verbindet sich nicht;
  Variablennamen, DeploymentMode und Hex-Präfixe werden konsistent verarbeitet.
- Der Parser-Testadapter prüft bei ausgewähltem historischen Release beide
  Binary-Paare vor der Datenbankanlage. Administrative Trustregistrierung
  bleibt an das bestehende ausdrückliche Opt-in und private Journal gebunden.

## 2026-10-07 – Date-Spine-Negativorakel verlangen konkrete Ablehnung

- Die vorhandenen Uninstall-, Dependency- und Kollisionsorakel verlangen
  Fehlerstatus und vollständige Kategorien `51806`, `51809` und `51804`.
  Andere Fehler, längere Nummern oder Kategorie bei erfolgreichem Exit ergeben
  keinen Nachweis. Beide Rohkanäle bleiben ausschließlich im Speicher.
- Der synthetische Harness prüft tatsächliche Helper und Orakel in Runner-
  und Labmodus. SQL, Dependencies, Fixtures, Runnerbesitz und Cleanup, Images,
  Readinessfrist, Matrix und Runtimeworkflow bleiben erhalten.

## 2026-10-07 – Date-Spine-CI mit verifizierter eigener Bereinigung

- Der bestehende Adapter bindet seinen Runner vor dem Start an SQL-Version,
  Run, Attempt und Owner. Cleanup entfernt nur die gemeinsam mit dem Label
  gelesene volle ID und verlangt frische exakte Namensabwesenheit.
- Unbestätigter Cleanup endet mit Exit1; bestätigter erhält den ursprünglichen
  Teststatus. Der Labzweig bleibt Container-No-op ohne Owner oder private Ablage.
- Der synthetische Harness, Documentationgate und vorhandenes Impact-Paket
  erfassen den Adapter. Date-Spine-SQL, Dependencies, Fixtures, Negativorakel,
  Images, Readinessfrist, Matrix und Runtimeworkflow bleiben erhalten.

## 2026-10-07 – Generate-Series-Kollisionsorakel verlangt konkrete Ablehnung

- Der vorhandene Adapter verlangt Fehlerstatus und die vollständige Kategorie
  `51054`. Andere Deploymentfehler, längere Nummern und Kategorie bei erfolgreichem
  Exit ergeben keinen Nachweis. Beide Rohkanäle bleiben ausschließlich im Speicher.
- Der bestehende synthetische Harness prüft das Kollisionsorakel in Runner- und
  Labmodus. SQL-Verträge, Fixtures, Runnerbesitz, Cleanup, Images, Matrix und
  Runtimeworkflow bleiben erhalten.

## 2026-10-07 – Generate-Series-CI mit verifizierter eigener Bereinigung

- Der bestehende Adapter bindet seinen Runner vor dem Start an SQL-Version,
  Run, Attempt und Owner. Cleanup entfernt nur die gemeinsam mit dem Label
  gelesene volle ID und verlangt frische exakte Namensabwesenheit.
- Unbestätigter Cleanup endet mit Exit1; bestätigter erhält den ursprünglichen
  Teststatus. Der Labzweig bleibt Container-No-op ohne Owner oder private Ablage.
- Der synthetische Harness, Documentationgate und vorhandenes Impact-Paket
  erfassen den Adapter. SQL-Verträge und Fixtures, bestehendes Kollisionsorakel,
  optionaler Performancepfad, Images, Readinessfrist und Matrix bleiben erhalten.

## 2026-10-07 – Base64-Kollisionsorakel verlangt konkrete Ablehnung

- Der vorhandene Adapter verlangt Fehlerstatus und die vollständige Kategorie
  `51044`. Andere Deploymentfehler, längere Nummern und Kategorie bei erfolgreichem
  Exit ergeben keinen Nachweis. Beide Rohkanäle bleiben ausschließlich im Speicher.
- Der bestehende synthetische Harness prüft das Kollisionsorakel in Runner- und
  Labmodus. SQL-Verträge, Fixtures, Runnerbesitz, Cleanup, Images, Matrix und
  Runtimeworkflow bleiben erhalten.

## 2026-10-07 – Base64-CI mit verifizierter eigener Bereinigung

- Der bestehende Adapter bindet seinen Runner vor dem Start an SQL-Version,
  Run, Attempt und Owner. Cleanup entfernt nur die gemeinsam mit dem Label
  gelesene volle ID und verlangt frische exakte Namensabwesenheit.
- Unbestätigter Cleanup endet mit Exit1; bestätigter erhält den ursprünglichen
  Teststatus. Der Labzweig bleibt Container-No-op ohne Owner oder private Ablage.
- Der synthetische Harness, Documentationgate und vorhandenes Impact-Paket
  erfassen den Adapter. SQL-Verträge und Fixtures, bestehendes Kollisionsorakel,
  optionaler Performancepfad, Images, Readinessfrist und Matrix bleiben erhalten.

## 2026-10-07 – Semantic-Version-Kollisionsorakel verlangt konkrete Ablehnung

- Der vorhandene Adapter verlangt Fehlerstatus und die vollständige Kategorie
  `51084`. Andere Deploymentfehler, längere Nummern und Kategorie bei erfolgreichem
  Exit ergeben keinen Nachweis. Beide Rohkanäle bleiben ausschließlich im Speicher.
- Der bestehende synthetische Harness prüft das Kollisionsorakel in Runner- und
  Labmodus. SQL-Verträge, Fixtures, Runnerbesitz, Cleanup, Images, Matrix und
  Runtimeworkflow bleiben erhalten.

## 2026-10-07 – Semantic-Version-CI mit verifizierter eigener Bereinigung

- Der bestehende Adapter bindet seinen Runner vor dem Start an SQL-Version,
  Run, Attempt und Owner. Cleanup entfernt nur die gemeinsam mit dem Label
  gelesene volle ID und verlangt frische exakte Namensabwesenheit.
- Unbestätigter Cleanup endet mit Exit1; bestätigter erhält den ursprünglichen
  Teststatus. Der Labzweig bleibt Container-No-op ohne Owner oder private Ablage.
- Der synthetische Harness, Documentationgate und vorhandenes Impact-Paket
  erfassen den Adapter. SemVer-Verträge und SQL-Fixtures, Kollisionsorakel,
  Images, Bereitschaftsfrist, Matrix und Runtimeworkflow bleiben erhalten.

## 2026-10-07 – Split-Characters-Preflightorakel verlangen konkrete Ablehnung

- Die bestehenden Dependency- und Kollisionsprüfungen verlangen Fehlerstatus
  und die vollständigen Kategorien `51079` beziehungsweise `51074`. Andere
  Deploymentfehler, längere Nummern und Kategorie bei erfolgreichem Exit
  ergeben keinen Nachweis. Beide Rohkanäle bleiben im Speicher.
- Der vorhandene synthetische Harness prüft beide Orakel in Runner- und Labmodus.
  SQL-Verträge, Fixtures, Runnerbesitz, Cleanup, Images, Bereitschaftsfrist,
  Matrix und Runtimeworkflow bleiben erhalten.

## 2026-10-07 – Split-Characters-CI mit verifizierter eigener Bereinigung

- Der vorhandene Adapter bindet seinen Runner vor dem Start an SQL-Version,
  Run, Attempt und Owner. Cleanup entfernt nur die gemeinsam mit dem Label
  gelesene volle ID und bestätigt frische exakte Namensabwesenheit.
- Unbestätigter Cleanup endet Exit1; bestätigter erhält den ursprünglichen
  Teststatus. Der Labzweig bleibt Container-No-op ohne Owner oder private Ablage.
- Synthetischer Harness, Documentationgate und vorhandenes Impact-Paket
  erfassen den Adapter. Split-/Generate-Series-Verträge, SQL-Fixtures,
  Kollisions-/Dependencyorakel, Images, Readinessfrist, Matrix und Runtimeworkflow
  bleiben erhalten.

## 2026-10-07 – Identifier-Kollisionsorakel verlangt konkrete Ablehnung

- Der vorhandene Adapter verlangt Fehlerstatus und die vollständige Kategorie
  `51064`. Andere Deploymentfehler, längere Nummern und Kategorie bei erfolgreichem
  Exit ergeben keinen Nachweis. Beide Rohkanäle bleiben ausschließlich im Speicher.
- Der bestehende synthetische Harness prüft die beiden Kollisionsorakel von
  Identifier und Integer-Base gemeinsam in Runner- und Labmodus. SQL-Verträge,
  Fixtures, Runnerbesitz, Cleanup, Images, Matrix und Runtimeworkflow bleiben erhalten.

## 2026-10-07 – Identifier-CI mit verifizierter eigener Bereinigung

- Der vorhandene Identifier-Adapter prüft seine Runneridentität und setzt
  vor dem Start ein Ownerlabel. Cleanup entfernt nur die gemeinsam mit dem
  Owner gelesene volle ID und bestätigt frische exakte Namensabwesenheit.
- Fremder Bestand, unbekannte Sicht oder Removefehler werden als unbestätigt
  mit Exit1 gemeldet; bestätigter Cleanup erhält den ursprünglichen Teststatus.
  Der Labzweig bleibt Container-No-op ohne Runnerowner oder private Ablage.
- Der bestehende synthetische Harness und sein selektiver Documentation-Gate
  erfassen den Adapter. Fachliche SQL-Verträge und Fixtures, Images, Matrix,
  Readinessfrist und Runtimeworkflow bleiben unverändert.

## 2026-10-07 – Integer-Base-Kollisionsorakel verlangt konkrete Ablehnung

- Das vorhandene CI-Orakel akzeptiert nur Fehlerstatus zusammen mit der
  vollständigen Kategorie `51094`; beliebige Deploymentfehler und Text bei
  erfolgreichem Exit ergeben keinen Kollisionsnachweis. Rohkanäle bleiben im Speicher.
- Der vorhandene synthetische Harness prüft Fehlerstatus, Kategorie und
  Zahlengrenzen in Runner- und Labmodus. Fachliche SQL-Verträge und Fixtures,
  Runnerbesitz, Cleanup, Images, Matrix und Runtimeworkflow bleiben unverändert.

## 2026-10-07 – Integer-Base-CI mit verifizierter eigener Bereinigung

- Der bestehende Integer-Base-Adapter bindet seinen Runner vor dem Start an
  Version, Run, Attempt und Owner. Cleanup entfernt nur die gemeinsam mit
  dem Label gelesene volle ID und bestätigt frische Namensabwesenheit.
  Unbestätigter Cleanup endet Exit1; bestätigter erhält den ursprünglichen Status.
- Synthetischer Harness, Documentationgate und vorhandenes Impact-Paket
  erfassen den Adapter. Lab-No-op, Encode-/Decode-Vertrag, SQL-Fixtures,
  Images, Bereitschaftsfrist, Matrix und Runtimeworkflow bleiben unverändert.

## 2026-10-07 – W1-CI mit verifizierter eigener Bereinigung

- W1 bindet seinen Runner vor dem Start an Version, Run, Attempt und Owner.
  Cleanup entfernt nur die gemeinsam mit dem Label gelesene volle ID und
  prüft frische Namensabwesenheit. Unbestätigter Cleanup endet Exit1;
  bestätigte Bereinigung erhält den ursprünglichen Teststatus.
- Gemeinsamer synthetischer Harness, Documentationgate und vorhandenes
  Impact-Paket erfassen den Adapter. Lab-No-op, SQL-Verträge, Fixtures,
  Kollisionsorakel, Collationfälle, Images, Bereitschaftsfrist, Matrix und
  Runtimeworkflow bleiben erhalten.

## 2026-10-07 – W2a-CI mit verifizierter eigener Bereinigung

- W2a bindet seinen Runner vor dem Start an Version, Run, Attempt und Owner.
  Cleanup entfernt nur die gemeinsam mit dem Label gelesene volle ID und
  prüft frische Namensabwesenheit. Unbestätigter Cleanup endet Exit1;
  bestätigte Bereinigung erhält den ursprünglichen Teststatus.
- Gemeinsamer synthetischer Harness, Documentationgate und vorhandenes
  Impact-Paket erfassen den Adapter. Lab-No-op, SQL-Verträge, Fixtures,
  Kollisionsorakel, Bucket-Workload, Images, Bereitschaftsfrist, Matrix und
  Runtimeworkflow bleiben erhalten.

## 2026-10-07 – JSON-Path-CI mit verifizierter eigener Bereinigung

- W2b bindet seinen Runner vor dem Start an Version, Run, Attempt und Owner.
  Cleanup entfernt nur die gemeinsam mit dem Label gelesene volle ID und
  prüft frische Namensabwesenheit. Unbestätigter Cleanup endet Exit1;
  bestätigte Bereinigung erhält den ursprünglichen Teststatus.
- Gemeinsamer synthetischer Harness, Documentationgate und vorhandenes
  Impact-Paket erfassen den Adapter. Lab-No-op, SQL-Vertrag, Fixtures,
  Kollisionsorakel, Images, Bereitschaftsfrist, Matrix und Runtimeworkflow
  bleiben erhalten.

## 2026-10-07 – W2c-CI mit eigener Containeridentität

- Der bestehende Runner bindet Name und Owner vor dem Start, entfernt nur
  die gemeinsam mit dem Label gelesene volle ID und prüft frische
  Namensabwesenheit. Fremder Bestand und unbekannter Cleanup werden sichtbar;
  bestätigte Bereinigung erhält den ursprünglichen Teststatus.
- Gemeinsamer synthetischer Cleanupharness, Documentationgate und bestehendes
  Impact-Paket erfassen den Adapter. Lab-No-op, öffentliche SQL-Verträge,
  Console-Ausgabemarker, fachliche Fixtures, Images, Matrix und Runtimeworkflow
  bleiben erhalten.

## 2026-10-07 – Cancellation-CI mit eigener Identität und privater Ausgabe

- W6d bindet seinen Runner vor dem Start an Version, Run, Attempt und Owner.
  Cleanup entfernt nur die gemeinsam mit dem Label gelesene volle ID und
  prüft frische Namensabwesenheit. Unbestätigter Cleanup endet Exit1;
  erfolgreicher Cleanup erhält den ursprünglichen Teststatus.
- Dependency- und Uninstall-Ausgaben sind auch im Lab laufisoliert. Die
  vorhandenen Fehlerexit-/Kategorieguards bleiben erhalten; private
  Dateibereinigungsfehler sind sichtbar. Lab-Container-rm bleibt No-op.
- Gemeinsamer Offlineharness, selektives Documentationgate und bestehendes
  Impact-Paket erfassen den Adapter. Öffentliche SQL-Verträge, fachliche
  Fixtures, Images, Matrix, parallele Worker und Runtimeworkflow bleiben erhalten.

## 2026-10-07 – Event-Log-CI mit eigener Containeridentität und Fehlerexit

- W5b bindet seinen Runner vor dem Start an Version, Run, Attempt und Owner.
  Cleanup entfernt ausschließlich die gemeinsam mit dem Owner gelesene volle
  ID und prüft frische Namensabwesenheit; unbestätigter Cleanup endet Exit1.
- Die Uninstalldatei ist auch im Lab laufisoliert. Das vorhandene Negativorakel
  verlangt Fehlerexit und Kategorie 51749. Exit0 mit Fehlertext wird abgewiesen;
  das bestehende Diagnose-cat bleibt erhalten.
- Gemeinsamer Offlineharness und Documentationgate erfassen den Adapter über
  das bereits gekoppelte Impact-Paket. Öffentliche SQL-Verträge, Loopback,
  fachliche Fixtures, Images, Matrix, Sessions und Runtimeworkflow bleiben erhalten.

## 2026-10-07 – Second-Session-CI mit verifiziertem Cleanup und Fehlerexit

- W5a bindet seinen Runner vor dem Start an Version, Run, Attempt und Owner.
  Nur die gemeinsam mit dem Owner gelesene vollständige ID wird entfernt;
  frische Namensabwesenheit und private Dateibereinigung sind Pflicht.
- Die Uninstall-Ausgabe ist auch im Lab laufisoliert. Der bestehende Guard
  verlangt Fehlerexit und Kategorie51649; Exit0 mit Fehlertext ist kein
  erfolgreicher Abweisungsnachweis. Das bestehende Diagnose-cat bleibt erhalten.
- Gemeinsame synthetische Cleanup-/Guardprüfungen und vorhandene Impact-Gates
  erfassen den Adapter. Öffentliche SQL-Verträge, Loopback-Konfiguration,
  Images, Matrix, Sessions und Runtimeworkflow bleiben erhalten.

## 2026-10-07 – W4b-CI mit verifizierter Bereinigung und Fehlerorakel

- Der vorhandene Work-Type-Runner bindet Name und Owner vor dem Start,
  entfernt nur die vollständige eigene ID und prüft frische Namensabwesenheit.
  Fremder Bestand und unbekannte Bereinigung bleiben sichtbare Fehler.
- Seine Uninstall-Negativphase verwendet auch im Lab eine private Datei und
  verlangt zusätzlich zur Fehlerkategorie einen Fehlerexit. Ein Exit0 mit
  Fehlertext ist kein erfolgreicher Abweisungsnachweis.
- Gemeinsamer Offlineharness, Dokumentationsgate und bestehendes Impact-Paket
  erfassen diese Grenzen. Lab-Container-No-op, öffentliche SQL-Verträge,
  fachliche Fixtures, Images, Matrix und Runtimeworkflow bleiben erhalten.

## 2026-10-07 – Work-Queue-CI mit eigener Identität und Ausgabeablage

- Runner-Cleanup bindet den bestehenden Container an Version, Run, Attempt
  und Owner, entfernt ausschließlich seine vollständige ID und verlangt
  frische Namensabwesenheit. Fremder Bestand und unbekannter Cleanup bleiben
  sichtbare Fehler; Runner-SQL-Drops über den Namen entfallen.
- Vier Negativphasen verwenden auch im Lab eine eigene private Ausgabeablage.
  Die sieben bestehenden Lab-Drops und der Container-No-op bleiben erhalten;
  ein Fehler der privaten Dateibereinigung beendet den Labadapter mit Exit1.
- Gemeinsamer Offlineharness, Dokumentationsgate und bestehendes Impact-Paket
  erfassen den Adapter. Öffentliche SQL-Verträge, fachliche Fixtures, Images,
  Versions-/CL-Matrix und Runtimeworkflow bleiben unverändert.

## 2026-10-07 – Eigenen W4a-CI-Container verifiziert bereinigen

- Der vorhandene Execution-Foundations-Adapter bindet den Runner an
  SQL-Version, Run, Attempt und Owner. Cleanup entfernt nur die gemeinsam
  mit dem Owner gelesene vollständige ID und verlangt frische Namensabwesenheit.
  Fremder Bestand oder unbestätigter Cleanup werden zum sichtbaren Fehler.
- Gemeinsamer synthetischer Harness, selektives Dokumentationsgate und
  bestehende Impact-Pakete erfassen den Adapter. Lab-No-op, fachliche
  SQL-Verträge, Fixtures, Zielmatrix und Lifecycle-Suite bleiben unverändert.
- Der ResultTable-Validator erkennt seinen einzelnen Pfad im gemeinsamen
  Cleanupgate, ohne eine Nachbarschaft zu anderen Pfadargumenten zu verlangen.

## 2026-10-07 – Eigenen ResultTable-CI-Container verifiziert bereinigen

- Der vorhandene Adapter bindet sein flüchtiges Runnerziel an SQL-Version,
  Run, Attempt und Owner. Cleanup entfernt nur die zusammen mit dem Label
  gelesene vollständige ID und verlangt frische Namensabwesenheit. Fremder
  Bestand oder unbestätigter Cleanup erzeugen einen sichtbaren Fehler.
- Der bestehende gemeinsame Offlineharness und sein selektives Dokumentations-
  gate erfassen jetzt diesen Adapter. Lab-No-op, öffentliche SQL-Funktion,
  bestehende Runtime-Suite, Performanceflag und Zielmatrix bleiben unverändert.

## 2026-10-07 – Eigenes Worker-CI-Ziel verifiziert bereinigen

- Der vorhandene Linux-Workerworkflow bindet sein flüchtiges Ziel vor dem
  Start an Run, Attempt und Owner. Der getrennte Cleanupstep entfernt nur
  die zusammen mit dem eigenen Label gelesene vollständige Container-ID
  und bestätigt danach frische Namensabwesenheit; Fehler bleiben sichtbar.
- Ein begrenzter synthetischer Test extrahiert die tatsächlichen beiden
  Workflowsteps und prüft Übergabe, Fehler und Dockerargumente ohne Docker
  oder SQL. Bestehende Faultjobs führen ihn aus. Produkt-SQL, Workerlogik,
  Image, Port, Provider, Matrix und Labadapter bleiben unverändert.

## 2026-10-07 – Eigene Tabellenklon-CI-Container verifiziert bereinigen

- Der vorhandene Runner-Adapter bindet seinen Container an Run, Attempt,
  SQL-Version und ein eigenes Ownerlabel. Die zusammen mit dem Label gelesene
  vollständige Container-ID ist das Löschziel; fremder Namensbestand bleibt
  erhalten. Fehlende Sicht oder fehlgeschlagene Abwesenheitsprüfung verhindern
  einen erfolgreichen Cleanupstatus.
- Der gemeinsame synthetische Cleanup-Test und seine CI-/Impactkopplung
  erfassen den Tabellenklon-Adapter. Die selektiven Documentation-CI-Guards
  verwenden Git-Pathspecs und unterscheiden kein Match von einem Diff-Fehler;
  ein fehlendes optionales Suchwerkzeug überspringt die Tests nicht mehr.
  Keine neue SQL-Funktion, Zielmatrix,
  Rechte- oder Truständerung; Lab-Shimpfad bleibt unverändert. Normales
  EXIT-Cleanup ist kein Nachweis für harte Runner-/Hostunterbrechung.

## 2026-10-07 – Schema-CI folgt der vorhandenen CL-Matrix

- Der bestehende Schema-Upgrade-/API-/Safety-/CrossDB-Scope läuft local und
  central auf allen bereits gewählten CI-CLs, einschließlich SQL2025/CL150/160.
  Consumer und Provider werden vor jeder Stufe auf denselben CL gebunden.
- Der eigene Upgrade-Snapshot wird nach verifiziertem Schema-Uninstall
  entfernt, damit jede Folgestufe mit einem frischen genuine1.0.0-Stand
  beginnt. Core wird erst nach allen Stufen entfernt.
- Keine zusätzlichen Constructor-Lastfixtures im Schema-Loop, keine neuen
  Binaries, Trusthashes oder öffentlichen Verträge. Head-CI wird im PR
  belegt; teilweise validiert und unveröffentlicht, übrige Matrix offen.

## 2026-10-07 – Vollständige kanonische JSON-Pointer-Lifecycle-CI

- Der flüchtige Linuxadapter ersetzt überlappende zentrale Teilprüfungen durch
  dieselben20 local-/22 central-Fälle je CL wie der vorhandene Labadapter.
  Dependency-, Caller-, Lock-, Rollback-, Marker-, Fremdslot- und Confirm0-
  Prüfungen verwenden unverändert dessen gemeinsamen Helper.
- Ein begrenzter Driver bindet eigene Fixtures an DB-Identität und Sourcepins,
  führt private Restorejournale und bestätigt Uninstall/Repeat/Abwesenheit.
  Feste Fehlerskategorien werden erst nach Restore ausgegeben.
- Testcode allein ist kein Runtime-PASS; exakte Head-CI wird im PR belegt.
  Produkt-SQL und öffentliche Verträge unverändert, teilweise validiert und
  unveröffentlicht. Weitere physische Ziele, Minimalrechte, Ressourcen und
  Hard-Interrupt-Recovery bleiben offen.

## 2026-10-07 – Safe-Cast-CI verwendet vollständige kanonische Lifecyclefälle

- Der flüchtige CI-Adapter ersetzt zentrale Teilprüfungen durch dieselben
  18 local-/20 central-Fälle pro CL wie der vorhandene Labadapter, einschließlich
  Callerzustand/SET-Optionen, AppLock, Rollback, Marker, Fremdslot und Confirm0.
- Eigene DB-Identität und Sourcepins, ein privates Restorejournal sowie
  frische Abwesenheitsprüfungen binden den begrenzten Driver an seine Fixtures.
  Testcode allein ist kein Runtime-PASS; exakte Head-CI wird im PR nachgewiesen.
- Produkt-SQL und öffentliche Verträge unverändert; Minimalrechte, gemessene
  Ressourcen und Hard-Interrupt-Recovery bleiben offen. Teilweise validiert,
  unveröffentlicht.
- Erster [nativer CI-Lauf](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37541002552)
  scheiterte beim ersten lokalen Lifecycleaufruf auf allen drei SQL-Versionen;
  die Ursache war wegen unterdrückter fester Diagnosekategorien noch offen.
  Der Adapter gibt jetzt erst nach Restore eine strikt gefilterte feste
  Fehlerstufe/-kategorie aus. Rohtexte und private Journale bleiben verborgen;
  der fehlgeschlagene Lauf wird dadurch nicht zu erfolgreicher Evidenz.

## 2026-10-07 – Runtime-CI bei Helper- und Generatoränderungen

- Safe-Cast- und JSON-Pointer-Runtime-CI berücksichtigen ihre tatsächlich
  geladenen gemeinsamen Lifecycle-Hilfsdateien und die vom statischen Vertrag
  ausgeführten Deploymentgeneratoren jetzt sowohl bei Pull Requests als auch
  bei Pushes auf `main`. Reine Änderungen dieser Abhängigkeiten lassen dadurch
  die bestehenden nativen Prüfungen nicht mehr aus.
- Testumfang und öffentliche SQL-Verträge bleiben gleich; daraus folgt keine
  zusätzliche Lifecycle-, Rechte-, Ressourcen- oder Releasequalifikation.

## 2026-10-06 – Schema1.0.1: begrenzte native CI bestanden

- [Runtime37532174433](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37532174433)
  und Docs37532174428 am exakten Head83164b539e637deeb1ad21b74a15cad99e0184c1
  PASS, einschließlich Windows und Linux SQL2019/CL150,2022/CL160,2025/CL170.
  Schema jeweils local/central: genuine Upgrade, erwarteter55699-Rollback,
  Mode-Abweisung, Uninstall/Reinstall/Repeat,40 Contractfälle je Modus,
  Safety, CrossDB und Cleanup. Je SQL-Version acht Upgrade- und zwei
  Safety-Witnesses; kein UnexpectedSQL/CleanupUnverified-Witness.
- SQLCMD-Dateifaulttransport bestand im tatsächlichen Testpfad; daraus wird
  keine exakte Actual168-Rootcause abgeleitet. Frühere failed/PENDING-Records
  bleiben erhalten. Jeder spätere Head benötigt vor Integration eigene
  erfolgreiche Checks; übrige Ziel-/
  Minimalrechte-/Lifecycle-/Kapazitätsmatrix offen, unveröffentlicht.

## 2026-10-06 – JSON Schema1.0.1: SchemaPointer-Reihenfolge korrigiert

- Finale Offline-Läufe `qual4`/`package4` nach Common-Härtung bestanden:
  15 Phasen mit unveränderten Harnesszahlen und acht Packagingfälle.
  Genau ein strict-UTF8-Byteinput ist an den festen historischen
  Snapshot-SHA256 gebunden; gültig neu gerahmte Constructorframes werden
  im Generator und Driver vor Ausgabe mit `SCHEMA_PATCH_BASELINE_PIN`
  abgewiesen. Kandidat und aktive Registry/Binaryhashes sind semantisch
  exakt gleich. Die folgenden sechs Packagingfälle aus `qual3`/`package3`
  bleiben erfolgreiche Nachweise des früheren Scriptstands.
- Erster [nativer CI-Versuch](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37525258700)
  am Head `58993f7012a0b458db377d7d4374b7bf162f0432`: SQL2019/2022 scheiterten
  mit Msg515 in UpgradeCapture Permissions wegen NULL für den leeren
  FOR-XML-Katalog. Capture/Verify normalisieren diesen nun symmetrisch
  auf `0x`; unabhängiger Review und ScriptDom14/42 bestanden. SQL2025
  lief bei Erfassung noch; native Abnahme am korrigierten Head
  sowie die ergänzte Windows-CI-Qualifikation bleiben PENDING.
- Schemaformfehler und Referenzzyklen folgen vollständig codierten
  SchemaPointern; decodierte Instanzmember und numerische Instanzarrays
  behalten ihre Reihenfolge. Profil, Signatur und Ergebnisfelder unverändert.
- Expliziter1.0.0→1.0.1-Maintenancepfad und Uninstall beider bekannten
  Releases implementiert; historische Closure unverändert erhalten.
  Core-/Constructorbytes bleiben gleich. Die eigene neue Schemazeile
  trägt ausschließlich die tatsächlich ausgeführte begrenzte Patchqualifikation.
- Offline:169 Profilfälle/1275 Assertions,854 Zahlenfälle/6830 Assertions
  und120 Bridge-Assertions je drei Kulturen, eigene IL, bytegleicher
  Schema-Projektbuild, sechs Patch- und sieben Releasepaketierungsorakel
  sowie ScriptDom14 Batches/42 Assertions bestanden. Der historische
  Erzeuger reproduzierte die echten1.0.0-Bytes aus50 Originalblobs in53
  erfolgreichen Prozessphasen. Syntax und18 synthetische CI-Cleanupfälle
  sowie33 Selector-/Bindungsfälle ohne Labzugriff bestanden. Keine erneute
  lokale Maximallastqualifikation.
- Native1.0.1-API, echter SQL-Upgrade und exakte aktuelle Head-CI noch offen;
  bisherige1.0.0-Nachweise bleiben historische Evidenz. Teilweise validiert,
  unveröffentlicht, kein neuer öffentlicher Funktionsscope.

## 2026-10-06 – JSON-Pointer-Contract-, Safety- und Client-CI ergänzt

- Ein modulbezogener Runtime-Workflow prüft den bestehenden Pointer-Vertrag
  in flüchtigen Linux-SQL-Server-2019/2022/2025-Containern über die jeweils
  unterstützten Compatibility Levels, local/central/Consumer, Safety,
  Clientmetadaten, Repeat und Uninstall. Produkt-SQL und öffentlicher Vertrag
  bleiben gleich.
- Gezielte Lifecycle-Negativfälle, Hard-Interrupt-Recovery, weitere physische
  Ziele, Minimalrechte und Maximalworkload/Heap sind dadurch nicht qualifiziert.

## 2026-10-06 – Safe-Cast-API- und Client-CI ergänzt

- Ein modulbezogener Runtime-Workflow prüft den bestehenden Safe-Cast-Vertrag
  in flüchtigen Linux-SQL-Server-2019/2022/2025-Containern über die jeweils
  unterstützten Compatibility Levels, local/central/Consumer, Clientmetadaten,
  Repeat und Uninstall. Produkt-SQL und öffentlicher Vertrag bleiben gleich.
- Gezielte Lifecycle-Negativfälle, Hard-Interrupt-Recovery, weitere physische
  Ziele, Minimalrechte und Heap sind dadurch nicht qualifiziert.

## 2026-10-06 – Safe Cast auf Windows 2025 mit CL150/160 qualifiziert

- Derselbe bereits ausgewählte Windows2025/CU8-Testserver bestand die
  vollständigen Safe-Cast-Adapter zusätzlich mit CL150 und CL160, je local/
  central/Consumer, festen API-/Clientprüfungen und 38 Lifecyclefällen.
  Frische unabhängige Audits bestätigten eigene Bereinigung,
  Fixturewiederherstellung und unveränderte Eingaben. Produkt-SQL und
  öffentlicher Vertrag blieben unverändert.
- Weitere physische Ziele, Minimalrechte, Heap und vollständige Runtime-Head-CI
  bleiben offen; teilweise validiert und unveröffentlicht.

## 2026-10-06 – JSON Pointer auf Windows 2025 mit CL150/160 qualifiziert

- Derselbe bereits ausgewählte Windows2025/CU8-Testserver bestand die vollständigen
  Pointer-Adapter zusätzlich mit CL150 und CL160, je local/central/Consumer,
  Contract/Safety/Client und42 Lifecyclefällen. Frische unabhängige Audits
  bestätigten eigene Bereinigung, Fixturewiederherstellung und unveränderte
  Eingaben. Produkt-SQL und öffentlicher Vertrag blieben unverändert.
- Weitere physische Ziele, Minimalrechte, Maximalworkload/Heap und vollständige
  Runtime-Head-CI bleiben offen; teilweise validiert und unveröffentlicht.

## 2026-10-06 – Exakte Argumentbindung der Safe-Cast-/Pointer-Labtreiber

- Plattform, Version, Deploymentmodus und Pointer-Qualifikationsscope werden
  bereits bei der Parameterbindung exakt geprüft. Ein synthetischer CI-Test
  führt nur die isolierten Paramblöcke aus; kein Labzugriff oder Produkt-SQL.
  Die nachgelagerte exakte Zielauswahl war bereits geschlossen.

## 2026-10-06 – JSON-Pointer-Quellvertrag in der pfadbezogenen CI

- Der bestehende statische JSON-Pointer-Vertrag läuft bei Moduländerungen und
  manuellem Workflowaufruf im Dokumentationsworkflow. Produkt-SQL,
  Runtimeadapter und Modulstatus bleiben unverändert; ein erfolgreicher
  Quellvertrag ersetzt keine SQL-Runtime- oder vollständige Head-CI-Abnahme.

## 2026-10-06 – Safe-Cast-Quellvertrag in der pfadbezogenen CI

- Der bestehende statische Safe-Cast-Vertrag läuft bei Moduländerungen und
  manuellem Workflowaufruf im Dokumentationsworkflow. Produkt-SQL,
  Runtimeadapter und Modulstatus bleiben unverändert; ein erfolgreicher
  Quellvertrag ersetzt keine SQL-Runtime- oder vollständige Head-CI-Abnahme.

## 2026-10-05 – SAFE JSON: Windows-CL150/160-Qualifikation und Selectorbindung

- Derselbe begrenzte Core-/Schema-Scope bestand auf Windows2025/exaktCU8
  zusätzlich mit CL150 und CL160 jeweils local/central:30 Contractfälle,
  Safety/Client/Lifecycle und frische unabhängige Dispositionaudits.
- Labadapter erlaubt150/160/170; exakter Linux2019-Guard bleibt150.
  Öffentliche SQL-Verträge und bekannte DLLs unverändert. Constructor1.3
  und genuine1.2→1.3 separat auf beiden Levels local/central einschließlich
  post-DROP-Rollback und frischen Audits bestanden; vollständige Ziel-/
  Minimalrechtequalifikation bleibt offen.
- Inkonsistente Casebindung am ersten Zielguard gehärtet; nachfolgender
  Selector blieb bereits geschlossen.33 Assertions und Originalstand-Negativtest
  bestanden, erneuter kanonischer CL160-Lablauf frisch auditiert. Test in CI/
  Impact registriert; laufende JSON-Runtimeprüfung wird erhalten.


## 2026-10-05 – Historischer Queue-Capture: aktuelle Helperkopplung

- Exakten Prozesshelperpin nach qualifizierter Timeout-Erweiterung aktualisiert;
  historische Queue2.0-Blobs und Capturebudgets unverändert. Helperänderungen
  sind jetzt in Worker-CI und Work-Queue-Impact registriert.
- Offlinecapture aller15 Originalblobs/14 Includes bestanden; neue native
  Migrations-CI separat. Vorheriger Helperpin-Fehler bleibt fehlgeschlagen.


## 2026-10-05 – JSON Schema1.0, gemeinsamer Core1.0 und Constructors1.3

- Freigegebene `USP_ValidateJsonSchema` mit Profil `toolbelt-2020-12-v1`,
  zehn Ergebnisfeldern, vollständigem Preflight, exakten Zahlen/Unicode,
  lokalen nichtrekursiven Referenzen und globalem Arbeitsbudget umgesetzt.
- Ein physischer SAFE-JSON-Core für Schema und die sieben Constructoradapter;
  drei getrennte bekannte Assemblies und explizite SameDB-Dependencies.
  Öffentliche Constructorverträge und AGF-Wireversion3 bleiben erhalten.
- Source-/Framework-/IL, drei kanonische bytegleiche Projektbuilds und sieben
  Paketierungskontrollen bestanden. Interne Schema-CLR-Bindungen verwenden
  Unicode; öffentliche ASCII-Felder bleiben varchar. Consumer-DROP verwendet
  `WITH NO DEPENDENTS`, um den gemeinsamen Core zu erhalten.
- Native Core-/Schema-Läufe auf Linux2019/latest CL150 und Windows2025/CU8
  CL170 local/central bestanden Contract/Safety/Client/Repeat/Consumer-Reject/
  Uninstall und eigene Bereinigung. Constructor-Fixtures einschließlich16 MiB
  und100000 Einträgen bestanden Linux lokal und Windows lokal/zentral.
- Genuine1.2→1.3 auf Linux local/central bestanden: fünf Procedureidentitäten/
  Rechte und effektive Owner erhalten, drei eigene CLR-Slots/Assembly atomar
  ersetzt, post-DROP-Rollback und Zusatzmetadaten-Abweisung geprüft. Der
  verworfene ALTER-Versuch scheiterte an SQL6282; Fehlerhistorie bleibt sichtbar.
  Windowsmigration anschließend ebenso local/central bestanden; aktuelle Head-CI offen.
- Schema-Trustfreigabe gilt für weitere separat qualifizierte Schemahashes
  der laufenden freigegebenen Testwelle ohne erneute Frage. Kein Produktions-
  oder Infrastrukturauftrag. Weitere Matrix, Minimalrechte, CrossDB und volle
  Lifecycle-/Heapqualifikation offen. Neue Module teilweise validiert und
  unveröffentlicht;44 Module insgesamt,19 validiert/25 teilweise validiert.

## 2026-10-05 – AI Repository Foundation1.19.0

- Exakte öffentliche Quelle4aafd20442275d0fdedf291fc6e12e8fe1f683cc nach
  vollständiger Feature-/Hashprüfung integriert; bestehende Projektregeln,
  drei Adapter und neun ausgewählte Capabilities erhalten.
- Zwei neue Features bewertet: sichere CI-Ablösung und metadatenbasierte
  Sessionsteuerung.24 Runtime-Workflows erhalten laufende Prüfungen, solange
  keine belegte Bereinigung nach harter Unterbrechung besteht.
- Foundationintegrität,34 relevante Upstream-Regressionsfälle, vollständiger
  Projektdokumentationsaudit und YAML-Verträge bestanden. Konkrete
  Sessionthresholds und automatische Clientrotation bleiben optional.
- [Bewertung und Grenzen](Documentation/Architecture/FOUNDATION_1_19_INTEGRATION.md).


## 2026-10-05 – JSON Pointer1.0.0 und freigegebener nativer128er-Guard

- Einzeln freigegebene lesende native MSTVF TVF_ResolveJsonPointer mit vier
  Parametern, vier BIN2-Ergebnisspalten, vollständiger Unicode-/Tiefenpolicy,
  exakten Keys und getrennten Statuswerten geschrieben; eigener atomarer
  Lifecycle und Source-abgeleiteter Deploymentgenerator, kein CLR.
- Offlineverträge, Syntax/Ast und vollständige Dokumentationskopplung bestanden.
  Zwei native Linux2019-Adapter bestanden Deploy/Repeat und432 Contract-Oracles,
  scheiterten an ISJSON-Tiefe129. Eigene Bereinigung und Inputpins jeweils
  unabhängig bestätigt; frühere Fehler bleiben fehlgeschlagen.
- [Konkrete notwendige Prioritätsänderung](Documentation/Architecture/JSON_POINTER_NATIVE_DEPTH_BOUNDARY.md)
  anschließend ausdrücklich freigegeben: nonnegative128er-Strukturguard vor
  Nativevalidation, geschützter Scalarwrapper; bis128 bleibt Syntax vor
  caller-seitig abgesenktem MaxDepth. Oberfläche sonst unverändert.
- Historischer separater Lifecycle-Scope vor der Prioritätsänderung auf Linux2019/CL150 und Windows2025/
  CU8/CL170 erfolgreich: je local/central/Consumer,15 Clientreader,42 Lifecycle-
  Fälle und frischer Bereinigungs-/Fixture-/Pinaudit. Contract/Safety dabei
  ausdrücklich nicht ausgeführt; löste damals die noch offene Tiefenpriorität nicht.
- Finale vollständige Adapter des korrigierten freigegebenen Standes auf
  Linux2019/CL150 und Windows2025/exaktCU8/CL170 bestanden je local/central/
  Consumer,3072 feste APPLY-Oracles,15 Clientreader und42 Lifecyclefälle samt
  frischem Bereinigungs-/Fixture-/Pinaudit. Keine Konfigurations-/Rechte-/
  Truständerungen. Frühere Fehlläufe und Lifecycle-only-Scopes bleiben getrennt;
  weitere Ziele, Minimalrechte, Maximalworkload/Heap und exakteHead-CI separat
  offen. `partially validated`, `unreleased`.

## 2026-10-05 – Strict Safe Cast / 1.0.0

- Sechs einzeln freigegebene schemagebundene Inline-TVFs für bigint,
  decimal(38,18), date, datetime2(7), bit und uniqueidentifier. Genau eine
  Value/Status/ErrorCode-Zeile, strikte ASCII-/ISO-Lexik, höchstens8192
  Inputbytes, exakter Wertebereich vor Skalenverlust und keine stille Rundung.
- Finale lokale Adapter auf Linux2019/latest CL150 und Windows2025/exaktCU8
  CL170 bestanden jeweils local/central/Consumer: je13104 feste API-Oracles,
  54 Clientreader,38 Lifecyclefälle, Clean/Repeat und Uninstall/Repeat.
  Frische unabhängige Audits bestätigen Inputpins, exakte Marker-/Fremdslot-
  Wiederherstellung und eigene Bereinigung. Frühere drei Gesamtfehlläufe bleiben
  getrennt. Keine Konfigurations-, Rechte- oder Truständerungen.
- Teilweise validiert, unveröffentlicht. Weitere physische Ziel-/CL-Matrix,
  Minimalrechte, Heap und exakte Head-CI bleiben separate Nachweise.

## 2026-10-05 – CSV Memory / zusätzliche Qualifikation

- Zwei separate Linux2019/latest-CL150-Markerfälle: Deploy und Uninstall
  weisen synthetisches int statt bit mit SQL55324/state5 unverändert ab;
  exakte Restaurierung und frischer unabhängiger OwnDB-/Trustaudit bestanden.
  Keine Aufwertung der vollständigen Driftmatrix oder des 29-Fall-Zählers.
- Historische exakte PR169-Head-CI mit fünf erfolgreichen Checks dokumentiert;
  CSV-Produkt und CLR-Bytes unverändert, Status teilweise validiert/unveröffentlicht.

## 2026-10-05 – CSV Memory / 1.0.0

- Einzeln freigegebene `USP_ParseCsv` und `USP_WriteCsv` mit eigenem SAFE-CLR-Kern,
  rechteckigen HEADER-/DATA-Zellen, exaktem NULL-Token und atomarem ResultTable-Routing.
  100000 DATA-Records, 1024 Spalten, eine Million Zellen und 16 MiB UTF16-Textbytes;
  alle Budgets nur absenkbar. Kein Datei- oder Netzwerkzugriff.
- Binarygebundene .NET48-Frameworkprüfungen mit drei Kulturen, unabhängigen
  Quotingorakeln, harten Grenzen und IL-Prüfung bestanden. Finale öffentliche Labadapter
  auf Linux2019/latest CL150 und Windows2025/exakt CU8 CL170 bestanden jeweils lokal,
  zentral und mit separatem Consumer: SQL-Verträge, Budgets, Clientmetadaten,
  29 Caller-/Lock-/Rollbackfälle, Repeat und Uninstall/Repeat. Frühere fehlgeschlagene
  Syntax-, LF-Padding- und Help-Metadatenläufe bleiben getrennt; exakte Head-CI ist
  ein separater Mergegate.
- Teilweise validiert, unveröffentlicht. Weitere physische Ziele, tatsächliche
  Minimalrechte und Heap-/Produktionskapazität bleiben offen.

## 2026-10-04/05 – Managed Queue Worker / unveröffentlichte Welle

- Queue 2.1 und Worker-Control 1.0 ergänzen den bestehenden externen Provider
  um zentrale dynamische Parallelitätsbudgets, Generationen, Intervalle und
  kontrolliertes Drain. Stop/Hold verhindert automatische Wiederholung;
  bestätigte SQL-Endzustände und unbekannte Ausgänge bleiben getrennt.
- Dokumentations-/Kopplungsaudit und begrenzte Offlineprüfungen bestanden.
  Der SQL-Vertrag mit Admission, Generationen, Holdbypass, Help/ResultTable
  und sechs echten Lifecycle-Abweisungen bestand auf 2019 Linux und
  2025 Windows/exakt CU8. Der echte Queue-Upgrade 2.0→2.1 bestand auf 2019 Linux.
  Fehlgeschlagene Providerläufe bleiben getrennt dokumentiert; kein Gesamt-PASS.
- Unabhängiger Produktreview ohne neue Blockingfindings abgeschlossen.
  Fokussierte Managedläufe auf beiden ausgewählten SQL-Zielen einschließlich
  eigenem Cleanup bestanden; tatsächlicher Linux-Workerhost und exakte Head-CI
  bleiben getrennte Mergegates. Keine neuen
  Agent-, Broker- oder SSIS-Provider und kein Releaseauftrag.

## 2026-10-04 – Table Clone Datenkopie / 4.1.0

- Einzeln freigegebene SameDB-Kopie in leere formgleiche Targets mit neun
  Parametern und fünf NOT-NULL-Summaryfeldern. KEEP/REGENERATE und vorhandenes
  SNAPSHOT/SERIALIZABLE ausdrücklich wählen;100000 Zeilen/16MiB nur absenkbar.
- Bestehende passende FKs unverändert; fehlende gemappte Beziehungen nach Copy
  durch den gemeinsamen internen Renderer anlegen. Keine Constraint-Deaktivierung,
  Rechteerteilung oder automatische Konfiguration; Identity-Zählerfortschritt
  trotz Rollback, kein RESEED.
- Vier Lifecycle-Slots13/14/14/9. Fünf Copygruppen, Client und genuine4.0→4.1-
  Lifecycle auf Linux2019/Windows2025 exaktCU8 bestanden; eigene Bereinigung
  unabhängig geprüft. Vier dynamische Identity-Zustände und zwei SNAPSHOT-
  Konkurrenzfälle auf Linux2019 gezielt nachgewiesen; abgeschlossene
  Teilnachweise aus Fehlerläufen ausdrücklich getrennt wiederverwendet.
  Head-CI separat im PR; teilweise validiert und unveröffentlicht.

## 2026-10-04 – Table Clone Trigger-Vorschau / 4.0.0

- Einzeln freigegebenes Windows-Opt-in `IncludeTriggers=1` im bestehenden Planner;
  13 Parameter, Standardtail10..13. Executor behält14 Parameter und bleibt triggerfrei.
- AST-/Katalogbindung über den vorhandenen exakt gepinnten Parser2.0;
  UTF16-Identifierumschreibung mit erhaltenen Kommentaren/Literalen,
  quellengetreuen Events, SET-Metadaten, FIRST/LAST und Disabledzustand.
- Generierte Triggernamen teilen das Kollisionsgate mit bestehenden Objekten
  und geplanten Map-Zieltabellen. Lifecycle kennt4.0 und historische Releases;
  Hash-v1 bindet das neue Releasefeld4.0.
- Unabhängige Coreprüfung, statische Kopplung und offline Syntaxprüfung bestanden.
  Zwei gezielte Trigger-Fixtures auf Windows2025/exakt CU8 CL170 lokal bestanden;
  Clean4/genuine3.1→4, Repeat, Clienthash, Consumer, Uninstall und Cleanup bestanden.
  Linux2019/latest CL150 Option0-/Lifecycle-PASS wiederverwendet; nachfolgende
  Coreänderungen ausschließlich Option1, unabhängig geprüft. Temporären exakten
  Parsertrust wiederhergestellt; keine Konfigurations-, Rechte- oder Owneränderung.
  Head-CI separat im PR; weitere native Ziele, zentrale4.0-Nutzung und Minimalrechte offen.
  Teilweise validiert und unveröffentlicht; historische Evidenz bleibt getrennt.

## 2026-10-04 – Phonetik 1.0.0 (unreleased, begrenzte Teilnachweise)

- Zwei einzeln freigegebene IF-Fassaden und zwei interne FT auf eigener SAFE-Assembly.
- Geschlossene Alphabete, feste inhärente Transformation, UTF16-/Quotenpriorität
  und vollständige Double-Metaphone-Codes einschließlich terminalem J-Leerzeichen.
- Markierte Apache-1.18.0-Portierung mit Headern und modullokaler LICENSE/NOTICE.
- Explizite installierte SHA2-512-Erwartung, kohärente Owner/Slotmarker,
  zweipassiger AppLock-Lifecycle; Trust bleibt getrennt.
- Build, Framework (223 Assertions je drei Kulturen), eigene IL und begrenzte
  native Teilnachweise auf Linux2019/latest CL150 und Windows2025/exakt CU8
  CL170 bestanden. Vier lokale Fixtures und 18 Clientreader je Ziel sowie
  local/central Lifecycle mit frischer Bereinigung; keine Konfigurations-,
  Rechte- oder Owneränderungen. Java-Differential, vollständige Qualifikation
  und aktuelle Head-CI bleiben offen; teilweise validiert, unveröffentlicht.


## 2026-10-04 – ZIP-Dateifassaden 1.0.0, begrenzte Teilnachweise

- Zwei einzeln freigegebene lokale Windows-USPs verwenden statisch bestehende
  ZIP-Writer-/Reader- und Filesystemverträge; keine neue Assembly/Providerlogik.
- Vollständige Payloadvorbereitung vor Dateipublikation, TX-Abweisung und
  eigene späte SQL-ResultTable-Transaktion; keine SQL-/Dateisystematomarität.
- Drei konkrete Brücken-Temps als eng genehmigte Namingausnahme; kein Corefix.
- Lifecycle, Help, Manifest und fünf synthetische Runtime-Fixtures vorhanden;
  elf frühere und zwei gezielte AppLock-Fallnachweise auf Windows2025/CU8 CL170
  local bei identischen Produktbytes; kein gemeinsamer 13-Fälle-Erfolgslauf.
  Eigene Bereinigung frisch geprüft. Vollständige Qualifikation und aktuelle
  Head-CI separat offen; teilweise validiert, unveröffentlicht.

## 2026-10-04 – Gemeinsamer SAFE-JSON-Kern und Aggregate 1.2.0

- Zwei einzeln freigegebene Aggregate und eine interne CLR-Bridge verwenden
  denselben Kern wie die vier bestehenden Konstruktor-USPs; deren Signaturen,
  globale Budgets und ResultTable-Verträge bleiben erhalten.
- Bekannte Binarybytes, sechs exakt typisierte Assemblymarker und kohärente
  vorhandene Eigentümer binden den achtteiligen Lifecycle ohne Rechtevergabe.
- Offlinequalifikation, kanonischer Projektbuild, lokale Acht-Fixture-Läufe
  auf Linux2019/CL150 und Windows2025/CU8/CL170 sowie genuine1.1 lokal und
  genuine1.0 lokal/zentral mit Repeat/Uninstall und eigener Bereinigung bestanden.
- Sechs erste-GO-Negativfälle bestanden; weitere Lifecycle-, Minimalrechte-,
  Engine-Merge-/Heap-/Spill- und Zielmatrixnachweise bleiben offen. Aktuelle CI
  wird separat am PR-Head geprüft. `partially validated`, `unreleased`.

## 2026-10-03 – Begrenzter Paarvergleich 1.0.0, unveröffentlicht

- Eine individuell freigegebene USP über die drei vorhandenen statischen TVFs;
  keine neue CLR-/Assembly-/Unicodeimplementierung.
- Typgenaue caller-lokale Paare, globale Row-/Text-/Workadmission und vollständige
  Ergebnisprüfung vor gemeinsamer ResultTable-Helper-/Insert-Atomik.
- Eigener Lifecycle mit bekannten same-database Dependencies, administrativer
  exakter SHA2-512-Bindung und vorhandener Metadatensicht.
- Fünf synthetische SQL-Fixtures und Lifecycle-Wiederholungen auf Linux 2019
  local und Windows 2025/CU8 local erfolgreich; gezielter zentraler Windows-
  Client-/ResultTable-/Uninstall-Bestätigungsnachweis unabhängig geprüft.
  Minimalrechte, weitere Lifecycle-Negativfälle, Ziele und Head-CI bleiben offen.

## 2026-10-03 – XLSX-Anzeigeformatierung 1.2.0 (unreleased)

- Additive Anzeige-TVF mit acht Inputs, zwei Outputs, zehn Literalformaten und drei expliziten Kulturen im bestehenden SAFE-Provider. Exakte SqlDecimal-Rundung und begrenzter Temporalübertrag; Raw-/Typquellen bytegleich.
- Lifecycle erkennt echte 1.0/1.1-Upgrades und 1.2-Reinstall mit neun Slots; bestehendes Sichtbarkeitsgate unverändert. Separate genuine1.1-, Display-, Client-, Kompositions- und CI-Testquellen.
- Nachweisergänzung 2026-10-04:19 Offlinephasen am aktuellen Artefaktpaar und separate13 genuine1.1-Offlinephasen bestanden; unveränderte Genuine1.0-/ZIP1.3-Verpackung separat bestanden.
- Am 2026-10-04 bestand ein privater Qualifikationsadapter auf SQL Server 2019 Linux/latest CL150 und SQL Server 2025 Windows/exakt CU8 CL170 jeweils ausschließlich lokal: Clean1.2 und genuine installierte1.1→1.2 mit frischer Session, drei→vier CLR-Bindings und sieben→neun Slots am identischen aktuellen Binary. Je Ziel bestanden zwölf SQL-Fixtures, sechs Display-Clientprüfungen und zwei Raw→Type-/Raw→Type→Display-Kompositionen, Repeat sowie Uninstall/Repeat. Zwei eigene Datenbanken wurden entfernt und drei exakte Trust-Vorzustände wiederhergestellt; frische unabhängige Bereinigungsprüfungen bestanden. Keine Konfigurations-, Rechte- oder Owneränderungen.
- Dies ist ein begrenzter privater Adapternachweis, kein vollständiger öffentlicher Labadapter- oder Produkt-PASS. Zentrale1.2-Nutzung, genuine1.0→1.2, weitere CL/Ziele, vollständige Lifecycle-/Kollisionsmatrix, Minimalrechte, Heap und aktuelle exakte Head-CI bleiben offen. Status bleibt `partially validated`, `unreleased`.


## 2026-10-03 – Jaro-Winkler im bestehenden SAFE-Provider 1.1.0, teilweise validiert

- Individuelle Funktionsfreigabe und konkrete Erweiterung der bestehenden Assembly
  auf 1.1.0 kanonisch festgehalten; genau eine öffentliche IF und eine interne FT.
- UnicodeScalar als einziger physischer Helfer; bestehende Distanzverträge bleiben.
- Bekannte 1.0-/1.1-Lifecycle-Releases mit vier/sechs Slots, genuine historische
  Blobpaketierung und neue harte Golden-/Metadaten-/Clientfixtures vorbereitet.
- Neue 1.1-/genuine 1.0-Releasebuilds, vollständige Distanz-/Jaro-Frameworkregression,
  Pythonreferenz und beide IL-Metadatengates separat bestanden.
- Private, source-/binarygebundene native Gesamtadapter auf Linux 2019/latest
  CL150 und Windows 2025/CU8 CL150/160/170 lokal/zentral und SC-UTF8 bestanden:
  genuine Upgrade, sechs Slots, API/Client/Lifecycle/Caller/AppLock/Faults und
  unabhängige eigene DB-/Trustbereinigung. Keine Config-/Rechte-/Owneränderung.
- Doomed-Guardnachweis im eigenen DB-Prozedurkontext des ganzen originalen
  Firstbatch; kein vollständiger SQLCMD-doomed-Nachweis. Minimalrechte, weitere
  physische Ziele und Heap offen; aktuelle CI separat am PR-Head.
  `partially validated`, `unreleased`; frühere 1.0-Evidenz bleibt historisch.

## 2026-10-03 – Windows Filesystem NoOverwrite-Korrektur / 1.0.0 unreleased

- Binary-/Textschreiben und Transcoding geben das bestehende Overwrite-Flag an den kanonischen Helper weiter. NoOverwrite veröffentlicht ausschließlich per nicht überschreibendem Move und erhält auch ein während des Staging-Schreibens erzeugtes Ziel; der Overwrite=true-Pfad bleibt unverändert. Keine neue API, Lifecycle- oder Versionsänderung.
- Aktueller .NET-Framework-4.8-Projektbuild und Releaseartefakt-Erzeugung erfolgreich. Historischer privater Helpernachweis: neun synthetische Fälle/254 Assertions. Der aktuelle sourcegebundene Fixed-only-Harness bestand tatsächlich neun Fälle/254 Assertions einschließlich eigener Bereinigung und abschließender Pins; vier private tatsächliche Prozesskontrollen bestanden Nonzero, Timeout, Capturegrenze und Postpin-Drift. Windows-CI ist gekoppelt und bleibt ein separater Mergegate am exakten PR-Head. Die korrigierte Binary im SQL-Caller-/NTFS-Kontext ist nicht qualifiziert; `partially validated`, `unreleased`.

## 2026-10-03 – Script-only Tabellenklon Welle1 / 2.0.0

- Bestehende zwei USP-Slots erweitern die rein textuelle Vorschau um Computed/PERSISTED, gefilterte Rowstore-Indizes und optionale typisierte Extended Properties. Zehn Parameter einschließlich `IncludeExtendedProperties` an Position6 vor dem Standardtail verschieben die bisherigen Positionen6..9 auf7..10; sieben einzelne SET-Zeilen vor TABLE begründen die dokumentierte Signaturversion2.0.0. Keine Scriptausführung oder Datenkopie durch die API; Welle2 bleibt getrennt.
- Finale öffentliche Adapter auf SQL Server 2019 Linux/latest CL150 und 2025 Windows/CU8 CL150/160/170 jeweils lokal und zentral bestanden: vier Runtime-Fixtures, Clientmetadaten, 27 Propertytypen/Owner und separate18-datetimeoffset-Produktpfadregression, 2MiB-Atomik, genuine1.0-Upgrade, Caller-TX/SET, AppLock, Rollback, Kollisions-/Dependency-Erhalt, Sichtbarkeitsprädikate, Uninstall und eigene Bereinigung.
- Hashgebundene Source-/Helper-/Genuine-Inputs, tatsächlicher Exit mit vollständigen Kanälen, exakt gebundenes Journal und frischer Cleanup-Audit wurden zusammen geprüft. Keine Konfigurations-, Rechte-, Trust- oder Infrastrukturänderungen;32 ist ausschließlich der Visibility-Teilzähler. Die korrigierte Prefixfixture bestand in erneuten öffentlichen Native-Läufen auf beiden ausgewählten Zielen. Alle sieben CI-Checks am geprüften Head76888216 bestanden, einschließlich CloneLinux2019/2022/2025. Tatsächliche Minimalrechte mit eigenem Principal und weitere physische Ziele bleiben offen. `partially validated`, `unreleased`; historische V1- und fehlgeschlagene Zwischenstände bleiben getrennt.

## 2026-10-02 – XLSX-Zelltypinterpretation 1.1.0

XLSX 1.1.0 ergänzt die einzeln freigegebene `TVF_InterpretXlsxCell` im bestehenden SAFE-Provider. Der finale öffentliche Typadapter bestand am 2026-10-02 auf SQL Server 2019 Linux/latest CL150 und 2025 Windows/CU8 CL150/160/170 jeweils lokal und zentral: drei Types-Runtime-Fixtures, exakte Zahlen-/100-ns-/NULL-/Clientmetadaten, clean/genuine 1.0/Repeat, Caller-TX OFF/ON intakt und doomed, AppLock, postDROP/preCOMMIT-Rollback, historische Zukunftsslots, Sichtbarkeitsprädikate, Uninstall und eigene Bereinigung. Raw→Type-Komposition wurde nach den API-CL-Schleifen auf der jeweils letzten CL (2019:150, 2025:170) sowie separat im zentralen Caller geprüft. Keine Konfigurations- oder Rechteänderungen. Die öffentliche Pfadfassung bestand nach ihrem unabhängig geprüften Port auf beiden ausgewählten Targets einschließlich frischer eigener Bereinigungsprüfungen. Aktuelle CI wird separat am exakten PR-Head als Mergegate geprüft. Tatsächliche Minimalrechte, weitere physische Ziele und Heap-/Produktionskapazität bleiben offen. `partially validated`, `unreleased`; historische Raw-1.0-Evidenz bleibt getrennt.

## 2026-10-02 – Levenshtein-/OSA-Provider 1.0.0, gezielt nativ teilweise qualifiziert

- Dedizierter portabler SAFE-CLR-Provider für genau die beiden einzeln
  freigegebenen Distanzfunktionen; zusätzliche Assembly-/Lifecyclefreigabe
  und Vor-Source-Vertrag dokumentiert. Jaro und Phonetik bleiben getrennt.
- Gemeinsame Unicode-Scalarvalidierung und zwei-/drei-Zeilen-DP, Standard/Large,
  strikter MaxDistance-/Fehlerprioritätsvertrag ohne Kürzung oder Näherung.
- Offline Vollmatrixreferenz 21185 und Framework 81380 Assertions erfolgreich,
  einschließlich tatsächlicher 1M-/16M-DP und Large-Bandberechnung; Releasebuild
  erfolgreich. Finale Gesamtadapter am 2026-10-02 auf Linux 2019/latest CL150 und Windows 2025/CU8 CL150/160/170 jeweils lokal/zentral sowie separatem SC-UTF8-Consumer bestanden. API-/Budget-/1000-Paar-/Client- und InstalledMetadata-, NULL-Modemarker-, AppLock-, Caller-TX/SET-, post-DROP-Rollback-, Kollisions-/Dependency-, Reinstall-/Uninstall- und eigene Bereinigungsorakel erfolgreich; Konfigurations- und Rechteänderungen jeweils 0. Tatsächliche Minimalrechte, übrige physische Ziele und Heap-/Produktionskapazität sind nicht nachgewiesen; aktuelle CI wird als separater PR-Mergegate nachgewiesen.
- Historischer erster Linux-Lauf SQL468/State9 im Metadaten-Fixture wurde
  vollständig bereinigt; korrigierter neuer Gesamtadapter separat erfolgreich;
  teilweise validiert und unveröffentlicht.

## 2026-10-02 – Gruppierte JSON-Konstruktoren 1.1.0

- Zwei individuell freigegebene USPs liefern GroupOrdinal und JsonValue je vorhandener Gruppe; gemeinsame globale Budgets und atomare Ausgabe.
- Ein bestehender T-SQL-Prüf-/Escapingkern mit GroupMode; alte öffentliche Signaturen und ungruppierte Emptyverträge bleiben erhalten.
- Strikter fünfteiliger Lifecycle für 1.0/1.1, Caller-TX-Guard vor SET und echter unveränderter 1.0-Vorgänger als Testartefakt.
- Offline-Syntax, statische Kopplung und Dokumentationsaudit erfolgreich. API-/100000-/16-MiB-/Clientprüfungen auf Linux 2019/latest und Windows 2025/CU8 lokal/zentral erfolgreich als Teil früherer insgesamt fehlgeschlagener Läufe; finale fokussierte Metadaten-/Lifecycle-/Central-/Upgrade-/Bereinigungsadapter erfolgreich.
- Historische Oraclefehler 53609/4, Kollisionsfehler 206, Caller-Batchfehler 3998 und Central-Orakelfehler 54600/45 bleiben als fehlgeschlagene Läufe erhalten. Neue Minimalrechte einschließlich offener VIEW DEFINITION/SELECT-Entscheidung und separater aktueller CI-/PR-Mergegate offen. Teilweise validiert und unveröffentlicht.

## 2026-10-02 – Deterministic GeoJitter 1.2.0 implementiert, teilweise validiert

- Die einzeln freigegebene Inline-TVF erhält vor Source einen unabhängig
  geprüften begrenzten Vertrag für synthetische 2D-Points/SRID 4326,
  Entitätsparameter und Radius 1–10000 m (Default 100 m).
- Modellreferenz und sichere native Operanden auf ausgewählten Lab-Zielen
  qualifiziert; echte 128-Byte-/größere UDTs getrennt vom unbeobachteten
  129-Byte-Fall. Keine zusätzliche Spatial-API oder Anonymisierungszusage.
- Der finale synthetische Geo-Adapter besteht auf SQL Server 2019 Linux/latest CL150 und 2025 Windows/CU8 CL150/160/170 jeweils lokal und zentral. Ausgeführt wurden ausdrücklich `GeoJitter.Contract.sql`, `GeoJitter.Safety.sql` und `InstalledMetadata.Contract.sql`, dazu SQL-/Clientmetadaten, echte 1.0.0-/1.1.0-Upgrades, Erstinstallation/Wiederholung, Caller-TX-/SET-Erhalt, Snapshot-Faults, Zukunftsslot-Erhalt, Uninstall und eigene Bereinigung. Der ursprüngliche Geo-Vertrag besteht unverändert in fünf unpartitionierten Batches mit 504 Orakeln. Die sieben bisherigen Source-Dateien bleiben bytegleich; dies ist kein erneuter finaler Runtime-Nachweis aller bisherigen APIs. Keine Konfigurations- oder Rechteänderungen. Neue Minimalrechte, weitere physische Ziele und ein exakt 129-Byte-UDT bleiben offen. Aktuelle CI wird als separater PR-Mergegate am exakten Head nachgewiesen. `partially validated`, `unreleased`.
- Historische Zwischenstände vom 2026-10-02: Die ursprüngliche Ausdrucksform und kleinere Zwischenkandidaten scheiterten mit SQL-Fehler 701; ein späterer Lauf endete mit Timeout -2. Diese Läufe bleiben fehlgeschlagen, eine allgemeine Compilerursache ist nicht nachgewiesen. Der historische Vector-Facts-Kandidat bestand auf Linux mit einer vorübergehenden Partitionierung: 72 Gruppen mit je sieben Radiuswerten, zusammen dieselben 504 Orakel, eingebettet in 78 Batches einschließlich Metadaten/Goldens/Defaults, Setup, globalem Coverage-Orakel und Wiederholung. Dieser Zwischenbeleg ersetzt den finalen Nachweis der ursprünglichen fünf Batches nicht.

## 2026-10-02 – Regex-Captures und gruppenbezogenes Replace 1.3.0

- Zwei einzeln freigegebene APIs über den gemeinsamen SAFE-CLR-Kern:
  alle Capture-Wiederholungen mit stabilen Gruppenordinals und getrenntes
  Replace mit strikten `$1`-/`${Name}`-/`$$`-Referenzen.
- Zusätzlich ausdrücklich freigegebene erwartete SHA2_512-Binaryhashbindung
  für Deploy/Uninstall; keine historische CLR-Versionsableitung oder Hashfallback.
- Finale Gesamtadapter auf Linux 2019/latest CL150 und Windows 2025/CU8
  CL150/160/170 lokal/zentral erfolgreich: API-/Clientverträge, echter
  1.2-Upgrade, Reinstall, Caller-TX/SET-Erhalt, AppLock, Rollback,
  Kollisions-/Dependency-Erhalt, Uninstall und eigenes DB-/Trustcleanup.
- Frühere API-only-Nachweise bleiben getrennt; fehlgeschlagene Gesamtversuche
  führten zu korrigierter Vorgänger-SQLCMD-Normalisierung, optionsneutralem
  Snapshot und sicherer Credential-Quelle der zweiten Testverbindung.
- Neue Capture-Minimalrechte, weitere Ziele, ältere Capture-Upgrades und
  tatsächliche große SQL-Capture-Ausgabe offen. Aktuelle CI wird separat als PR-Mergegate nachgewiesen; teilweise
  validiert und unveröffentlicht, keine Heap-/Backtracking-/Durchsatzgarantie.

## 2026-10-02 – Parser-Härtung 2.0.0 in Arbeit

- Konkreter begrenzter Vertrag für die vier bestehenden TVFs vor Source
  dokumentiert und unabhängig geprüft. Der eingefrorene Wächterkandidat
  bestand 82 isolierte Framework-Kindprozesse mit exakter Dependency,
  einschließlich unabhängiger Wiederholung.
- Strikte Versionen und endliche Eingabegrenzen, vorgeschaltete
  Komplexitätsprüfung, keine partiellen ASTs und atomare begrenzte Ausgaben
  bilden die geplante Major-Inkompatibilität gegenüber 1.0.0.
- 245 integrierte Framework-Kindprozesse sowie Windows 2025/CU8 CL150/160/170
  bestanden: lokaler/zentraler Modus, echter 1.0-Upgrade, Wiederholung,
  Grenzen/Syntax, Caller-TX/SET-Erhalt, Kollisionsschutz und eigenes Cleanup.
- Zusätzlicher finaler Live-Lauf bestand saubere Erstinstallation,
  Fremdschema-/Shared-Dependency-Erhalt, Lock-Contention und eigene
  Transaktionswiederherstellung nach injiziertem post-DROP-Fehler.
- Windows 2019 bleibt wegen fachfremder Pending-Konfiguration blockiert;
  Windows 2022, minimale Rechte und tatsächliche Ausgabeceilings sind offen.
  Accounting-Helper ersetzen keine SQL-Ceilingqualifikation.
  Historische 1.0.0-Evidenz bleibt erhalten; 2.0 ist teilweise validiert.
  Kein Dependency-Upgrade, Trigger-Rewriting oder Release.

## 2026-10-02 – Erster externer Queue-Worker

- Manuell gestarteter PowerShell-Provider mit einem Supervisor, 1–8 Slots,
  separaten Handler-/Controlverbindungen und bestehenden SQL-Kern-APIs.
- Readonly-Claim-/Executionzuordnung, atomarer Handler-/Completecommit,
  kooperative Checkpoints, Watchdog und Drain ohne forcierten Abbruch.
- Retry ausschließlich explizit für geeignete Handler und transiente
  Fehler nach bestätigtem Rollback; Dead Letter separat gezählt.
  Ungeklärter Commit oder Ownershipverlust wird nicht blind wiederholt.
- Windows-Host-Labtests gegen SQL Server 2019 Linux/latest und 2025
  Windows/CU8 einschließlich tatsächlichem 60-Sekunden-Heartbeat erfolgreich.
  [Worker-Testmatrix](Workers/ExternalQueue/Tests/README.md) trennt finale
  Nachweise, erfolgreiche Linux-Host-CI auf SQL 2019 und offene Transport-/Rechte-/Recovery-/Central-
  Qualifikationen. Teilweise validiert, unveröffentlicht; kein Dienstbetrieb.

## 2026-10-02 – Deterministic Translate 1.1.0

- Additive echte Inline-TVF für formaterhaltende synthetische ASCII-Kennungen:
  casegekoppelte bijektive Buchstaben-/Ziffernabbildung, explizite Separatoren,
  Standard 2 MiB/Large 16 MiB, bytegenaue Fehlerpriorität und sichere native
  Operanden. Bestehende sechs Slots unverändert, keine weitere Dependency.
- Integrierte Referenzsuite und unabhängige Reviews erfolgreich. Vollständige
  Adapter auf Linux 2019/latest local/central und Windows 2025/CU8 central
  CL150/160/170 bestanden, einschließlich aller sieben Slots, Metadaten,
  echtem 1.0-Upgrade, Fehler-/Lifecyclefällen, Uninstall und eigenem Cleanup.
- Windows local: API-/Safetyfälle im früheren Gesamtfehllauf bestanden;
  separate korrigierte Metadaten-/Lifecycleprüfung erfolgreich. Dieser
  Teilnachweis ist kein nachträgliches PASS des ursprünglichen Gesamtlaufs.
- Keine Serverkonfiguration oder Rechteausweitung. Neue Minimalrechte,
  weitere physische Targets, Kapazität und aktuelle CI offen; teilweise
  validiert und unveröffentlicht, kein Merge- oder Releaseabschluss behauptet.

## 2026-10-02 – Deterministic Range, DateShift und Lookup 1.0.0

- Drei einzeln freigegebene synthetische Mapping-APIs mit einem gemeinsamen
  versionierten SHA256-/128-Rejection-Kern; keine CLR-, I/O-, persistierte
  Mapping- oder Anonymisierungsfunktion.
- Atomare Standard-USP-Ausgabe, Help-first vor privater Temp-Compilergrenze,
  versions-/ownershipgebundener Lifecycle und nichtdoomende frühe
  Callertransaction-Abweisung ohne SET-Änderung.
- Identische finale Adapter auf 2019 Linux/latest CL150 und 2025 Windows/CU8
  CL150/160/170 am 2026-10-02 erfolgreich. Weitere Targets, CrossDB-
  Minimalrechte und Produktionskapazität offen; teilweise validiert/unreleased.

## 2026-10-02 – Begrenzter XLSX-Raw-Reader 1.0.0 und ZIP-Fassade 1.4.0

- Individuell freigegebene Worksheetliste und sparse Raw/Text/Formula/Cache-Zellliste, SAFE und memory-only; kein SDK, File-I/O, Formula-Execution oder Typ-/Anzeige-Folgescope.
- Kanonischer ZIP-Parser wird über eine technische .NET-Fassade wiederverwendet. Ressourcenlimits, kooperatives Budget und konservativer 128-MiB-Outputcharge vor Ausgabe; keine Peak-RAM- oder harte Wallclock-Zusage.
- Finale synthetische Adapter auf Linux 2019/latest und Windows 2025/CU8 erfolgreich, einschließlich lokaler/zentraler Verwendung, Clientmetadaten, atomarer ResultTable, Caller-Scope, nichtdoomendem XLSX-/ZIP-Lifecycle und tatsächlichem ZIP-1.3-Upgrade. Begrenzte Framework-NoIO-/IL- sowie unabhängige Writer-Orakel erfolgreich.
- Bekannte Restmatrix offen; teilweise validiert und unveröffentlicht. Tatsächliche Releaseveröffentlichung, weitere Plattformen und Kapazitätsqualifizierung werden nicht behauptet.

## 2026-10-01 – Script-only Tabellenklon 1.0.0

- `USP_ScriptTableClone` liefert deterministische begrenzte SameDB-DDL-
  Vorschau für Spalten, Defaults, Checks, PK/UQ, Rowstore-Indizes und optionale
  Identity; keine DDL-Ausführung oder Datenkopie durch die öffentliche API.
- Unsupported atomar sichtbar, vollständiger Plan vor ResultTable-Mutation,
  datenbankweite Metadatensicht, Lifecycle-Callertransaktionen nichtdoomend
  abgewiesen und registrierte Typdrift kontrolliert repariert.
- Finale synthetische Adapter auf 2019 Linux/latest und 2025 Windows/CU8
  erfolgreich. Weitere Zielkombinationen, GitHub-Runtime und Lowpriv-CrossDB
  offen; `partially validated`, `unreleased`. Keine Folgeausbauten enthalten.

## 2026-10-01 – JSON-Konstruktoren 1.0.0

- Getrennte `USP_JsonArray` und `USP_JsonObject` mit einem gemeinsamen
  begrenzten Prüf-/Escapingkern, expliziten ValueKinds und caller-lokalen
  Eingabetabellen. Keine Typinferenz, JSON-Aggregate oder SQL-Ausführung.
- Atomare ResultTable-Ausgabe, Help-first, binär längensensitive Keys,
  strikte Zahlen-/Boolean-/Fragment-/Unicode-Verträge und begrenzte LOBs.
- Vollständige finale Adapter auf SQL Server 2019 Linux/latest und 2025
  Windows/CU8 erfolgreich; Lifecycle-Typreparatur und Namespace-Compilegrenzen
  nach unabhängigem Review nachgetestet. Weitere Ziele, gemappte CrossDB-
  Minimalrechte und Produktionskapazität offen; teilweise validiert/unreleased.

## 2026-10-01 – Regex Matches und Split 1.2.0

- `TVF_RegexMatches` und `TVF_RegexSplit` verwenden den bestehenden SAFE-CLR-
  Dialektkern. Originaltexte, UTF-16-Positionen und leere Tokens bleiben
  erhalten; keine Captures, Backreferences oder automatische Entquotierung.
- Vollständige begrenzte Materialisierung vor Ausgabe, MaxRows und vorhandene
  Standard-/Large-Budgets; Vertragsfehler und Timeout ohne Teilmenge.
- Vollständige Adapter auf SQL Server 2019 Linux/latest CL150 und 2025
  Windows/CU8 CL150/160/170 erfolgreich; echte 1.0-/1.1-Upgrades und lokale/
  direkt zentrale Minimalrechte geprüft. Weitere Ziele, Lowpriv-CrossDB und
  SQL-100k-Durchsatz offen; `partially validated`, `unreleased`.

## 2026-10-01 – ZIP-Writer 1.3.0

- `USP_CreateZipFromEntries` erzeugt begrenzte In-memory-ZIPs aus einer caller-lokalen Temp-Tabelle: Stored als Default, Deflate ausdrücklich wählbar, strikte UTF-8-Namen und atomare ResultTable-Ausgabe.
- Reiner SAFE-CLR-Kern, Help-first, Lifecycle-/Upgrade-/Kollisionsschutz und unabhängige Frameworktests; keine Datei-I/O- oder ZIP64-Erweiterung.
- Internes Empty-Payload-Marshalling des bestehenden Readers korrigiert; öffentliche SQL-Signaturen, Limits und encrypted NULL bleiben unverändert. Zusätzliche Readerkopien sind dokumentiert.
- Ausgewählte Live-Tests auf SQL Server 2019 Linux und 2025 Windows/CU8 erfolgreich; höhere SQL-Live-Grenzen und reale Produktionsarchive bleiben offen. Status `partially validated`, `unreleased`.

## 2026-10-01 – Unquoting und Split-USP

- `toolbelt.string.split-advanced` 1.1.0 ergänzt die einzeln freigegebenen
  `TVF_UnquoteToken` und `USP_SplitAdvanced`; der vorhandene Split-Kern bleibt
  unverändert und unquotet niemals automatisch.
- Unquoting behandelt explizite oder automatisch erkannte äußere Quote-Paare,
  doubled closing Qualifier und nur ausdrücklich aktivierte Backslash-Escapes.
  Fehler bleiben atomar; NULL, UTF-16-/BIN2-Grenzen und Fehlerpriorität sind
  Bestandteil des öffentlichen Vertrags.
- Die USP ergänzt Help, Debug-Messages und caller-lokale ResultTables mit
  ResultTable-Dependency und callerfreundlichen Transaktionen/Savepoints.
  Das Modul bleibt `partially validated` und `unreleased`; die konkrete
  Ausführungsevidenz und offene Grenzen stehen in seiner Testmatrix.

## 2026-10-01 – Regex R2a

- `toolbelt.string.regex` 1.1.0 ergänzt ausdrücklich freigegebene
  `SVF_RegexReplace` und `SVF_RegexSubstring`: literal Replacement, UTF-16,
  max-Signaturen, Standard-/Large-Profil und begrenzter Ergebnisbau.
- T-SQL-Fassaden erhalten max-Defaults vor internen SAFE-CLR-Kernen;
  kooperatives Gesamtbudget und Restbudget ergänzen Engine-Timeouts.
- Tests koppeln R1b-Regression, Profil-/Patterngrenzen, echte 1.0.0-Upgrades,
  Central-/Codepage-Aufrufe, Dependency-Schutz und konkurrierende LOBs.
- Alle Module bleiben `unreleased`; kein allgemeiner Benchmark oder
  Native-RE2-/Streaming-/Parallelitätsvertrag wird eingeführt.

## 2026-10-01 – S2 Quote/Escape Split

- Neues dependencyfreies Modul `toolbelt.string.split-advanced` mit verpflichtender `TVF_SplitAdvanced`, Originaltokens, längstem Separator und atomarer Geschäftsfehlerzeile.
- Grenzen, UTF-16-/BIN2-Semantik, priorisierte Fehler, local/central Lifecycle, CI-/Lab-Adapter und synthetische Contracttests umgesetzt; optionaler USP und Unquoting nicht enthalten.
- Risikobasierte physische Tests auf SQL Server 2019 Linux und 2025 Linux/Windows erfolgreich; weitere physische Zielkombinationen nicht ausgeführt. Die zusätzliche [GitHub-hosted Linux-Matrix 2019/2022/2025](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/36857332229) ist ebenfalls erfolgreich. Status `partially validated`, `unreleased`.

## 2026-09-01 – GitHub-hosted Linux-Versionsmatrix

- Alle fünfzehn bislang auf SQL Server 2025 beschränkten Modul-Runtime-Workflows
  laufen jetzt über die Matrix 2019, 2022 und 2025. Die Adapter unter `Tests/CI/`
  unterstützten diese Versionen bereits; nur die Workflows setzten `TBX_SQL_VERSION`
  nicht und verwendeten ein fest verdrahtetes 2025-Image.
- Zwei dadurch aufgedeckte Testadapterfehler sind behoben: der Loopback-Linked-Server
  der W5-Adapter verwendete `encrypt=optional`, das erst ab MSOLEDBSQL 19 existiert,
  und `run-file-content-linux.sh` setzte feste Compatibility Levels 150, 160 und 170.
- Kein öffentliches SQL-Objekt, kein Vertrag und kein Modulmanifest wurde geändert.
  Alle Module bleiben `partially validated`, weil die Windows-Matrix weiterhin offen ist.

## 2026-08-24 – ZIP-Metadaten-Listing und Statuswahrheit

- `toolbelt.archive.zip-memory` Version `1.2.0` stellt die neue
  Listing-API samt internem CLR-TVF, Lifecycle, Help, ResultTable,
  Local-/Central- und Struktur-/Encoding-/Pfadverträgen.
- Windows-.NET-Framework-4.8-Build und SQL-Server-2019-/2022-/2025-Linux-
  Runtime für Extraktion und Listing sind im
  [GitHub-Actions-Lauf 32701896453](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/32701896453)
  erfolgreich; Windows-Runtime und echte Extremgrößen bleiben offen.
- Aggregierte Manifeststatus, Kandidatenplan und Roadmap sind konsolidiert;
  doppelte AP-/Phasenabschnitte entfernt und zukünftige Wellen mit expliziten
  Freigabegates verankert.
- Der Dokumentationsvalidator prüft abgeleitete AP-Status lokal im jeweiligen
  Abschnitt, Manifestaggregate und eindeutige Planungs-IDs.

## 2026-08-05 – W5b Event Log

- `toolbelt.core.second-session` auf Version `1.1.0` mit `@SuppressResult` erweitert.
- `toolbelt.core.event-log` Version `1.0.0` implementiert: rollback-unabhängiger Writer, Event-View, begrenzte Retention und sauberer Work-Type-Lifecycle.
- SQL Server 2025 Linux CL150/160/170 einschließlich Rollback, uncommittable Caller, Concurrency, Central und Uninstall erfolgreich.

## 2026-08-05 – Work-Type-Katalog 1.1.0

- `toolbelt.core.work-type` um `toolbelt_core.USP_RemoveWorkType` erweitert.
- Entfernung ist nur nach Disable, mit `@AllowDelete = 1` und optionaler `rowversion`-Prüfung zulässig.
- Savepoint-, uncommittable-Caller-, ResultTable- und Lifecycle-Verträge werden capabilitybezogen getestet.

## 2026-08-04 – W5a Second Session

- `toolbelt.core.second-session` Version `1.0.0` implementiert.
- Registrierte Work-Types laufen synchron über einen administrativ vorbereiteten
  Loopback-Linked-Server in einer getrennten SQL-Server-Session; Raw SQL und
  im Modul gespeicherte Credentials bleiben ausgeschlossen.
- SQL-Server-2025-Linux-Loopback-Spike ist erfolgreich; physische SQL-Server-
  2019-/2022- und Windows-Läufe bleiben `not executed`.

## 2026-08-01 – W4b Work-Type-Katalog

- `toolbelt.core.work-type` Version `1.0.0` implementiert.
- Persistente Tabelle `toolbelt_core.WorkType` mit expliziten Constraint-/Indexnamen und `rowversion`.
- Register, Disable, Resolve, View, ResultTable, Concurrency, Redeploy, Central und Data-Loss-Uninstall-Schutz.
- `DEC-2026-025` schließt die Tabellen-/Constraint-/Index-Namenskonvention.
- SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 erfolgreich: https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30703339193.

Alle wesentlichen Änderungen an SQL Server Toolbelt werden hier dokumentiert.

Das Format orientiert sich an [Keep a Changelog](https://keepachangelog.com/de/1.0.0/).

## [Unreleased]

- 2026-10-09: CSV-Framework-Testwartung ersetzt die vollständige DLL-Bytearray-
  Kopie durch einen festen 64-KiB-Puffer mit `Int64`-Längenbindung und exakter
  EOF-Prüfung. Bestehende Kopie-/Endpins, Harnessorakel und Prozessbudgets
  bleiben erhalten. Sechs synthetische Kopierfälle **PASS**; neue Head-CI
  **NOT_EXECUTED**; keine Produkt-,
  API-, Workflow-, Modulstatus-, Heap- oder Releasequalifikation.

- 2026-10-07: Regex-CI-Cleanup prüft volle Container-ID und Owner gemeinsam,
  entfernt per ID und verlangt frische Namensabwesenheit. Run-Attempt-/SQL-/
  CL-Name und Owner vor Setup geprüft; Cleanupfehler bleiben sichtbar und
  bestätigter Cleanup erhält den vorherigen Fehlerstatus. Lab-No-op und
  vorhandene zusätzliche R2a-Trustbereinigung separat erhalten. Offlinegate
  und Dokumentation gekoppelt; Produkt-SQL, Binaries und Matrix unverändert.

- 2026-10-07: XLSX-Qualifikations-CI lädt nur15 benannte aktuelle und genuine
  historische Releaseinputs hoch. Private Argument-/Prozessdateien, Logs,
  Qualifikations- und Buildbäume bleiben außerhalb des Uploads. Die bestehende
  statische Prüfung kontrolliert die tatsächliche Auswahl mit synthetischen
  Sentinels;19 Frameworkphasen, Produktbinaries, SQL, Trust und Rechte unverändert.

- 2026-10-07: Constructors-CI-Cleanup bindet volle Container-ID und Owner aus
  derselben Aufnahme, entfernt per ID und verlangt frische Namensabwesenheit.
  Run-/Attempt-/SQL-Name und Owner vor Setup geprüft; privates Verzeichnis
  erst nach fallibler Vorbereitung, feste Cleanupzeugen und Fehlerstatuserhalt.
  Bestehende Offlineprobe/Testdokumentation gekoppelt; Produkt-SQL/Binaries,
  Matrix, Rechte, Trust und Lab unverändert. Kein Hard-Interrupt- oder
  Releasequalifikationsnachweis.

- 2026-10-07: Safe-Cast-CI-Cleanup bindet volle Container-ID und Owner aus
  derselben Aufnahme, entfernt per ID und verlangt frische Namensabwesenheit.
  Run-/Attempt-/SQL-Name vor Setup geprüft; privates Verzeichnis erst nach
  fallibler Vorbereitung, feste Cleanupzeugen und bisheriger Fehlerstatus.
  Bestehende Offlineprobe/Testdokumentation gekoppelt; Produkt-SQL, Matrix,
  Rechte, Trust und Lab unverändert. Kein Hard-Interrupt- oder
  Releasequalifikationsnachweis.

- 2026-10-07: Pointer-CI-Cleanup bindet volle Container-ID und Owner aus
  derselben Aufnahme, entfernt per ID und verlangt frische Namensabwesenheit.
  Run-/Attempt-/SQL-Name vor Setup geprüft; privates Verzeichnis erst nach
  fallibler Vorbereitung, feste Cleanupzeugen und bisheriger Fehlerstatus.
  Bestehende Offlineprobe/Testdokumentation gekoppelt; Produkt-SQL, Matrix,
  Rechte, Trust, Lab und manuelle Lastfälle unverändert. Kein Hard-Interrupt-
  oder Releasequalifikationsnachweis.

- 2026-10-07: Deterministic-CI-Container-Cleanup an gemeinsamen Owner-/ID-
  Nachweis und frische Abwesenheit gebunden; Run-/Attempt-/SQL-/CL-Identitaet,
  Fehlerstatus und feste Cleanupzeugen statt unterdruecktem name-only rm.
  Bestehende Offlineprobe und Dokumentations-Impact gekoppelt; Produkt-SQL,
  sechs CI-Paare, Rechte, Trust und Lab unveraendert. Head-/Main-Nachweis im PR;
  keine Hard-Interrupt-/Releasequalifikation.

- Die sechs bestehenden Deterministic-CI-Jobs binden ihren exakten
  Compatibility-Level-Opt-in vor Deploy/Upgrade an alle 13 eigenen Datenbanken
  und pruefen ihn vor jedem SQL-Skript erneut. Der erwartete Fehlerpfad
  startet nach fehlgeschlagenem Gate kein Skript. Ohne Opt-in bleibt der
  historische Multi-Level-Scope unveraendert; keine neue Produktfunktion,
  Zielmatrix, Rechte- oder Trustaenderung.

### Geändert

- AI Repository Foundation von `1.4.0` auf den manifestierten Core `1.8.0`
  aktualisiert. Semantische Upgrade-Bewertung, zentrales Registry-Profil,
  Repository-Continuity und Rule-Context-Cache-Governance sind integriert;
  optionale Foundation-Capabilities bleiben unselektiert.
- Die vollständige lokale Adaptermatrix ist auf physischen SQL-Server-2019-,
  2022- und 2025-Zielen unter Windows base und Linux latest erfolgreich.
  20 Module sind damit `validated`; sieben bleiben wegen ausdrücklich
  abgegrenzter Performance-, Client-/Treiber-, Fixture-, Interoperabilitäts-
  oder manueller Sicherheitsgates `partially validated`.
- Die W1-Pflichtfälle decken zusätzlich CI-/CS-/UTF-8-Collations, leere
  Trim-Mengen, den vollständigen druckbaren ASCII-Raum, ungültige kurze
  Prozentsequenzen, Large-Input-Roundtrip und Fremdobjektkollisionen ab.
- W2a/W2b ergänzen Fremdobjektkollisionen sowie einen synthetischen
  100.000-Zeilen-Bucket-Workload; der Capability Catalog prüft eingeschränkte
  Metadatensichtbarkeit ohne Rechteausweitung.
- Second Session und Event Log verwenden im Loopback-Providervertrag
  `encrypt=no`, das von den eingesetzten OLE-DB-18-/19-Pfaden akzeptiert wird.

### Hinzugefügt

- `toolbelt.core.execution-cancel` Version 1.0.0 implementiert den
  freigegebenen W6d-Slice: persistierte, irreversible kooperative
  Cancellation je ExecutionId mit sicherer Status-TVF und Skalurfunktion.
  Der Kern führt kein `KILL` aus, verändert keine Work-Queue-Zeilen und
  akzeptiert keine aktive Caller-Transaktion.

- ADP-008 ergänzt für `toolbelt.core.console-message` einen Project Adapter
  0.1 mit deterministisch aus den kanonischen Modulquellen erzeugten Install-,
  Update- und Cleanup-Entrypoints. Der vorhandene Modulvertrag wurde auf SQL
  Server 2025 Linux getrennt unter Docker und Podman end-to-end erfolgreich
  ausgeführt; der Toolbelt-Runner bindet ausschließlich bestehende Lab-Runs
  und verwaltet keine Provider-Infrastruktur.

- `toolbelt.string.regex` Version `1.0.0` implementiert den ausdrücklich
  freigegebenen R1b-Slice mit `SVF_RegexIsMatch`, `SVF_RegexInstr` und
  `SVF_RegexCount`. Ein eigener Parser begrenzt den Toolbelt-Dialekt; Input,
  Pattern, Quantifier und Laufzeit besitzen feste Grenzen. Die identische
  .NET-Framework-4.8-Assembly läuft als `SAFE` SQL CLR ohne Drittanbieter-
  oder Native-Abhängigkeit und wird ausschließlich per exaktem SHA2-512-Hash
  autorisiert. Die vollständige physische Matrix SQL Server 2019/2022/2025
  unter Windows base und Linux latest ist erfolgreich; das Modul ist
  `validated` und `unreleased`. RE2-Parität, lineare Laufzeit, Replace,
  Substring, Captures, Split und Matches werden nicht zugesagt.

- `toolbelt.core.work-queue` Version `1.1.0` ergänzt den E1a-Kern um den
  ausdrücklich freigegebenen E1b-Slice: begrenzte Claim-Lease, monotone
  Generation, tokengebundener Heartbeat, explizite Batch-Recovery und
  aktive-Lease-Prüfung für Complete/Fail. Das echte Upgrade `1.0.0 → 1.1.0`
  erhält QUEUED-/terminale Daten und blockiert bei aktiven Alt-Claims vor der
  ersten Mutation. Der erste vollständige E1b-Lauf auf SQL Server 2025 Linux
  war erfolgreich; anschließend bestand die vollständige physische Matrix
  SQL Server 2019/2022/2025 unter Windows base und Linux latest. Das Modul ist
  `validated`. Retry/Dead Letter/Idempotenz, Cancellation und Worker
  bleiben getrennte Slices; das Modul bleibt `unreleased`.

- `toolbelt.datetime.date-spine` Version `1.0.0` mit drei portablen Inline
  TVFs für Tages-, ISO-Wochen- und Monatsperioden eines halboffenen
  `date`-Bereichs. Die vollständige Linux-Matrix auf SQL Server 2019, 2022 und
  2025 ist erfolgreich; Windows blieb wegen nicht erreichbarer SQL-
  Anmeldungs-Preflights `not executed`. Das Modul bleibt `unreleased`.

- Q1 Migration-Idempotency-Verifier für isolierte dependency-freie,
  zustandslose T-SQL-Module. V1 vergleicht den effektiven Katalog vor und nach
  einem Wiederholungsdeployment und prüft zwei unabhängige Uninstalls samt
  leerem Restzustand. Die physische SQL-Server-2019-/2022-/2025-Matrix ist auf
  Linux und Windows erfolgreich; alle synthetischen Testdatenbanken wurden
  anschließend entfernt.

- Windows-only Modul `toolbelt.filesystem.windows` mit EXTERNAL_ACCESS-SQL-CLR-Fassade für begrenztes Text-/Binary-I/O, explizite Codepages und Transcoding, Directory-Operationen und begrenztes rekursives Löschen. `Caller` ist der Default, `ServiceAccount` explizit; Build, Trust, Deployment, Help, SQL-Authentication-Ablehnung und kontrolliertes ServiceAccount-Schreiben sind validiert, die breitere Caller-/NTFS-/I/O-Matrix bleibt offen.

- `toolbelt.archive.zip-memory` ergänzt den ZIP-Metadaten-Pfad (TC-2026-033) im CLR-Provider inklusive Testhärtung für nicht-ASCII-Entry-Namen (`Grüße.txt` als Unicode-Konkatenausdruck). Version `1.2.0` stellt ihn über `USP_ListZipEntriesFromBinary` bereit; die vollständige Linux-SQL-Runtime-Matrix ist erfolgreich.

- W2c mit `toolbelt.core.console-message` für Unicode-sichere lange
  `PRINT`-/`RAISERROR ... WITH NOWAIT`-Messages und
  `toolbelt.metadata.capability-catalog` für eine read-only Projektion
  gültiger, unvollständiger oder ungültiger Database-level Modulmarker.
  Source, Lifecycle, Central-, Contract-, Dokumentations- und
  Runtime-Artefakte sind vorhanden. SQL Server 2025 Linux ist mit
  Compatibility Levels 150, 160 und 170 einschließlich Langtext-/Unicode-,
  Marker-/Drift-, Wiederholungs-, Lifecycle-, Central- und
  Uninstall-Contracts erfolgreich; beide Module sind `partially validated`.
- W2b-A mit `toolbelt.json.path-exists`: fehlerfreie SQL/JSON-Pfadprüfung
  für SQL Server 2019+ mit Root-, Property-, Array-Index-, Quote- und
  Wildcard-Semantik, gekoppelte Lifecycle-, Central-, Contract-,
  Dokumentations- und Runtime-Artefakte. SQL Server 2025 Linux ist mit
  Compatibility Levels 150, 160 und 170 einschließlich nativer Parität,
  Wiederholungsdeployment, Lifecycle, Central und Uninstall erfolgreich;
  Konstruktoren und JSON-Aggregate bleiben getrennt zurückgestellt.
- W2a mit typgetrennten Date/Time-Truncation- und Bucket-Inline-TVFs sowie
  Bigint-Shift-, Bit-Count-, Get-Bit- und Set-Bit-Funktionen. Die drei Module
  besitzen gekoppelte Lifecycle-, Central-, Contract-, Dokumentations- und
  Runtime-Artefakte. SQL Server 2025 Linux ist mit Compatibility Levels 150,
  160 und 170 einschließlich Wiederholungsdeployment, Lifecycle, Central und
  Uninstall erfolgreich; der Status ist `partially validated`.
- Sechs semantisch äquivalente inline-TVF-APIs für Base64, Integer-Base und
  Semantic Versioning als kanonische relationale Kerne für `CROSS APPLY` und
  `OUTER APPLY`; die vorhandenen SVFs bleiben Convenience-Wrapper.
- Kandidatenübergreifender Implementierungsplan für alle 46 Toolbelt-Kandidaten mit vorhandenen beziehungsweise vorgeschlagenen Modulen, öffentlichen Objektfamilien, Provider-Slices, Abhängigkeiten, Pflicht-Gates, Testschwerpunkten und Entwicklungswellen; ohne neue Implementierungsfreigabe.
- Formale Kandidaten `TC-2026-033` bis `TC-2026-046` für ZIP-/Kompressionsprovider, kontrollierte Datei-/Verzeichniszugriffe, getrennte Pseudonymisierungsbausteine, Objektklonen, XLSX-Lesen und eine providerneutrale Second-Session-Abstraktion; alle ohne Implementierungsfreigabe im Status `researched`.
- Deduplizierte Toolbelt-Research-Inbox mit 168 breit gefächerten Ideen und 92 öffentlichen Quellen; Mehrfachnennungen behalten ihre gemeinsamen Fundstellen; Funktionsideen aus dem Projektchat „SQL Server Toolbelt Planung“ zu Session Context, Sequence-Ranges, Schema-Introspektion, sicheren Dynamic-SQL-Primitiven, Resultset-Rendering und Temporal Queries sind nachgetragen.
- Repository-Grundaufbau mit autoritativen Steuerungsdateien, Architektur, Standards, Templates und Backlogs.
- Verbindlicher USP-Vertrag und SQL-Objekt-Namenskonventionen.
- GitHub-Copilot-Custom-Agent für die Backlog-Pflege.
- Erste evidence-basierte Backlog-Research-Welle mit den Kandidaten `TC-2026-001` bis `TC-2026-013`.
- Versionsbezogene Compatibility-Kandidaten für SQL Server 2019, 2022 und 2025 in den Bereichen Core, String, Datetime, JSON, Binary und Conversion.
- Implementierungsreife Spezifikation des ersten Kernmoduls `toolbelt.core.result-table`.
- Verbindliche ResultTable-Contract-Testmatrix für Help, Schema, `@KeepData`, DDL, Transaktionen, Collation, Deployment und Plattformen.
- Architekturentscheidungen `DEC-2026-013` bis `DEC-2026-017` für Modulscope, Schemaquelle, in-place-Umbau, Transaktionsvertrag und interne Temp-Namen.
- Folgearbeitspaket `AP-2026-003` für Implementierung und Validierung des ResultTable-Kernmoduls.
- Zweite Research-Welle mit den Execution-Infrastructure-Kandidaten `TC-2026-014` bis `TC-2026-022`.
- Kandidaten für transaktionsunabhängiges Logging, begrenzte Parallelisierung, Console-Ausgabe, Error Envelope, Cancellation, Correlation, Retry/Dead-letter, Worker-Leases und einen sicheren Work-Type-Katalog.
- Erstimplementierung von `toolbelt_core.USP_PrepareResultTable` mit Help-, Referenztabellen-, Typ-, Collation-, `@KeepData`-, Preflight-, in-place-DDL-, Debug-, Fehler- und Savepoint-Vertrag.
- Modulmanifest, parametergesteuertes Deploy- und Uninstall-Skript, Objekt- und Moduldokumentation, synthetisches Beispiel sowie statische und synthetische Contract-Testartefakte für `toolbelt.core.result-table`.
- Architekturentscheidung `DEC-2026-019` für gemeinsame Deployments, Release-Manifeste und kurze Mutationstransaktionen.
- GitHub-hosted Linux-Validierung für SQL Server 2019, 2022 und 2025.
- Manifestzentrierte Modulregistry mit gekoppelten Dokumentationspfaden und Contract-Versionen.
- Inkrementeller Dokumentations- und Change-Impact-Validator ohne externe Python-Abhängigkeiten.
- Eigener GitHub-Actions-Workflow für diff-basierte Dokumentationskonsistenz.
- Architekturentscheidung `DEC-2026-020` zur Status- und Change-Impact-Steuerung.
- Projektübergreifende Toolbelt-Landschaftsrecherche mit 16 direkten Libraries, Frameworks, Skriptkatalogen, Diagnose-, Maintenance- und Automationsprojekten.
- Prior-Art-Vergleich für zweite Sessions und Parallelisierungsprovider sowie Architekturfolgen für Packaging, Discovery, Versionierung, Tests, Lizenzierung, Security und Repository-Grenzen.
- Kandidaten `TC-2026-023` für einen abfragbaren Capability-/Versionskatalog und `TC-2026-024` für URI-Percent-Encoding/-Decoding.
- Quellenbasierte Vorprüfung der persönlichen Brainstorm-Themen Zahlensysteme, Kompression/Archive, Datei-/Verzeichniszugriff, Anonymisierung und Objektklonen.
- Kandidaten `TC-2026-025` bis `TC-2026-028` für kontrollierte PowerShell-Host-Automation, Python-Provider, versionsbezogene REST-/Web-Requests und getrennte KI-/Chat-Capabilities.
- ResultTable-Contract-Tests für explizite Collations, das 1024-Spalten-Limit, Caller-/uncommittable-Transaktionen und einen reproduzierbaren synthetischen Performance-Workload.
- Entscheidungsvorlage für das zweite Modul mit einem vertieften Vergleich von `TC-2026-004` und `TC-2026-012`, offenen Vertragsfragen, Provideroptionen, Testdimensionen und expliziten Implementierungs-Gates.
- ResultTable-Multi-Session-Contract für vier parallele Sitzungen mit identischen logischen Temp-Tabellennamen.
- Modul `toolbelt.conversion.base64` mit portablen Scalar UDFs für Base64- und Base64URL-Encoding/-Decoding.
- Parametergesteuertes lokales und zentrales Base64-Deployment, Uninstall, Objekt- und Moduldokumentation, synthetische Beispiele sowie statische, Contract-, Lifecycle- und Größenprüfungen.
- Serieller SQL-Server-2025-Linux-Workflow für Compatibility Levels 150, 160 und 170.
- Architekturentscheidung `DEC-2026-021` für scopebezogene Qualitäts-Gates unabhängiger Module.
- Erfolgreiche Base64-Runtime-Matrix auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 einschließlich RFC-4648-, Fehler-, Größen-, Deployment- und Lifecycle-Contracts.
- Modul `toolbelt.core.generate-series` mit portablen Inline TVFs für `int`- und `bigint`-Zahlenreihen.
- Gemeinsamer `bigint`-Kern mit konstanten binär gestapelten Rowsets, zeilenzahlgesteuertem Row Goal und überlaufsicherer interner `decimal(38,0)`-Arithmetik.
- Parametergesteuertes lokales und zentrales Generate-Series-Deployment, Uninstall, Objekt- und Moduldokumentation, synthetische Beispiele sowie statische, Contract-, Lifecycle-, Grenz- und Größenprüfungen.
- Serieller SQL-Server-2025-Linux-Workflow für Generate-Series unter Compatibility Levels 150, 160 und 170.
- Erfolgreiche Generate-Series-Runtime-Matrix auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 einschließlich Semantik, nativer Parität, Fehlern, Grenzen, einer Million Werte, Row Goal, Join, `CROSS APPLY`, Deployment- und Lifecycle-Contracts.
- Formale Kandidaten `TC-2026-029` bis `TC-2026-031` für sicheres Identifier-Handling, Semantic Versioning und frei definierbare Zahlensysteme.
- Getrennte Split-Ausbaustufe `TC-2026-032` für mehrzeichige Separatoren, Escape und Quote.
- Modul `toolbelt.metadata.identifier` mit zustandsbasiertem Multipart-Parser und kanonischem Quote-Wrapper.
- Unterstützung für ein- bis vierteilige Namen, `[...]`, `]]`-Escapes, ausgelassene mittlere Teile und stabile abstrakte Validation Codes.
- Parametergesteuertes lokales und zentrales Identifier-Deployment, Uninstall, Objekt-/Moduldokumentation sowie statische, Contract-, Collation- und Lifecycle-Prüfungen.
- Modul `toolbelt.string.split-characters` mit literalem Multi-Separator-Vertrag, stabilen Ordinals und definierter Leer-Token-Semantik.
- Binärer Separatorvergleich, `nvarchar(max)`-Verarbeitung, Generate-Series-Dependency sowie lokales/zentrales Deployment und vollständige Lifecycle-Artefakte.

### Behoben

- Öffentliche Filesystem-Fassaden ordnen CLR-Providerfehler jetzt der jeweils
  angeforderten Operation zu. Die `file.content`-Reader liefern bei
  `OPENROWSET`-Enginefehlern Fehler `51326` mit vorangestelltem Kontext.
- Das Wiederholungsdeployment von `toolbelt.file.content` erhält die bestehende
  Root-Allowlist einschließlich ihrer Daten und aktualisiert ihre Beschreibung
  idempotent.
- `toolbelt.filesystem.windows` erkennt den `Caller`-Modus direkt über
  `SqlContext.WindowsIdentity` und hängt nicht mehr von der Sichtbarkeit
  serverweiter Login-Metadaten ab. Directory-Resultsets werden erst nach
  Beendigung der Windows-Impersonation an SQL Server zurückgegeben.
- Die internen CLR-Procedure-Bindings verwenden `CREATE OR ALTER`, sodass
  Assembly-Upgrades ohne Objektkollision wiederholbar ausgeführt werden.

### Geändert

- R1a dokumentiert und reproduziert die native SQL-Server-2025-RE2-Semantik
  für einen möglichen `LIKE`-/`INSTR`-/`COUNT`-Slice. Der Spike nimmt keine
  Dependency und keine Runtime-API auf: .NET Framework 4.8 ist semantisch
  nicht RE2-paritätisch, native RE2-Wrapper verletzen das portable
  `SAFE`-/Linux-Gate. Die Implementierung bleibt bis zur Richtungs- und
  Vertragsfreigabe gesperrt.

- W4a implementiert: `toolbelt.core.error-envelope` standardisiert explizite CATCH-Daten ohne Rethrow- oder Logging-Seiteneffekt.
- W4a implementiert: `toolbelt.core.execution-context` stellt Begin/Set/End, inline TVF und SVF-Wrapper über `SESSION_CONTEXT` bereit.
- Beide Module auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 einschließlich Lifecycle, Central und Sessionisolation validiert (https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30699604948).

- ResultTable-Contract um einen natürlichen Enginefehler 2705 nach begonnener Mutation erweitert; Savepoint-Rollback von Schema, Daten und Caller-Transaktion auf SQL Server 2019/2022/2025 Linux validiert ([Run 30692956855](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30692956855)).
- Manuelle Windows-Runtime-Testpläne für ResultTable und ZIP Memory mit synthetischem Scope und abstrahierter Rückmeldung ergänzt.

- Modulregistry um das bereits vorhandene `toolbelt.file.content` ergänzt; Statusübersichten zeigen nun 19 implementierte, 18 teilweise validierte und ein nicht ausgeführtes Modul.
- Dokumentationsvalidator erkennt künftig jedes vorhandene, aber nicht registrierte `Modules/*/module.yaml` sowie veraltete Registry-Einträge.
- `toolbelt.file.content` im Wartungslauf https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30692267356 auf SQL Server 2025 Linux mit Compatibility Levels 150/160/170 validiert und mit kanonischer Evidenz gekoppelt.
- ZIP-Backlog, Kandidaten, Implementierungsplan und Roadmap an die produktive CLR-Implementierung und die Linux-Matrix angepasst.
- Branchspezifischen Self-Mutation-Job aus dem ZIP-Workflow entfernt und Workflow-Berechtigung auf `contents: read` reduziert.
- Windows-Dateisystem-Arbeitspaket auf den tatsächlich verbleibenden manuellen Windows-SQL-Server-/NTFS-Runtime-Test reduziert.
- Welle `W1` implementiert: `TC-2026-002` als Calendar Difference,
  `TC-2026-008` als Directional TRIM Compatibility und `TC-2026-024` als
  RFC-3986-URI-Component-Percent-Encoding. Die drei Module besitzen
  eigenständige Lifecycle-Artefakte, Objektseiten und synthetische
  Contract-Tests. SQL Server 2025 Linux ist mit Compatibility Levels 150,
  160 und 170 einschließlich Wiederholungsdeployment, zentraler Nutzung und
  Uninstall erfolgreich; der Status ist `partially validated`.

- Base64, Integer-Base und Semantic Versioning auf Modulversion `1.1.0`
  angehoben; Deployment, Upgrade, Uninstall, Objektverträge, Beispiele,
  Manifeste und Testmatrizen um die inline-TVF-Alternativen erweitert.
- Inline-TVF-Remediation `AP-2026-014` nach erfolgreichen SQL-Server-2025-
  Linux-Läufen mit Compatibility Levels 150, 160 und 170 abgeschlossen.
- Datenschutz- und Vertraulichkeitsregeln präzisiert: fachlich relevante öffentliche Organisations-/Projektnamen und Links sowie `gecompat` und `Gerhard Pisch` sind zulässig; personenbezogene/sensible Daten, interne/vertrauliche Informationen, Original-Tabelleninhalte, reale Runtime-Ausgaben und konkrete Remote-Runner-Hardwarewerte bleiben ausgeschlossen.
- Bestehende Kandidaten zu Multi-Separator-Split und kalendarischer Differenz mit präziseren Versions-, Provider-, Performance- und Aussagegrenzen versehen.
- Roadmap um die abgeschlossene Research-Welle, die abgeschlossene ResultTable-Designphase und die geplante Implementierungswelle ergänzt.
- USP-Vertrag mit der kanonischen ResultTable-Runtime-Spezifikation und Testmatrix verknüpft.
- Repository-Map und Modulübersicht um das implementierungsreif geplante Kernmodul ergänzt.
- `@CreateStmt` für Version `1.0.0` zugunsten einer Referenztabelle zurückgestellt; die parsergestützte Capability bleibt als spätere Vertragsoption erhalten.
- Interne lokale Temp-Objekte verwenden den reservierten Präfix `#tbx_`; persistente Tabellenkonventionen bleiben offen.
- Implementierungs-Gate präzisiert: Ideen dürfen fortlaufend dokumentiert werden; jede konkrete Funktion benötigt vor der Implementierung eine Besprechung und anschließende ausdrückliche Benutzerfreigabe.
- `AP-2026-003` bis zur funktionsbezogenen Besprechung und Freigabe auf `blocked` gesetzt.
- `Backlog/personal_Backlog_Bainstorm.md` als verpflichtend zu berücksichtigenden, nicht autoritativen und historisch zu erhaltenden Research-Input in AI-Regeln, Repo-Map, Backlog-Prozess und Curator-Agent eingebunden.
- `AP-2026-003` nach ausdrücklicher funktionsbezogener Benutzerfreigabe auf `implemented` gesetzt; weitere Funktionen bleiben ohne eigene Freigabe blockiert.
- Anchor-Umbau am SQL-Server-Limit von 1024 Spalten in kontrollierte Teilschritte zerlegt.
- Getrennte Install-/Upgrade-Pfade durch ein gemeinsames `Deploy.sql` mit `DeploymentMode`, Release-Manifest, Application Lock und objektgenauer Herkunftsprüfung ersetzt.
- Source-Hashes von einem blockierenden Drift-Gate zu rein diagnostischer Information geändert.
- Modulstatus in getrennte Implementierungs-, Validierungs- und Release-Dimensionen aufgeteilt.
- README- und Modulübersichtsstatus als aus Manifesten erzeugte Abschnitte gekennzeichnet.
- ResultTable-Runtime-Workflow auf Source-, Deployment-, Manifest-, Runtime-Test- und CI-Adapteränderungen begrenzt.
- Execution-Infrastructure-Kandidaten um konkrete Prior Art aus tSQLt, SQL Server Multi Thread und der SQL Server Maintenance Solution ergänzt.
- Vorhandenen Base64-Kandidaten `TC-2026-012` anhand der nativen SQL-Server-2025-Semantik präzisiert.
- Toolbelt-Landschaftsrecherche auf den implementierten ResultTable-/Dokumentationsstand und die aktuellen SQL-Server-2025-REST-/AI-Funktionen konsolidiert.
- SQL Server 2022 und 2025 in der GitHub-hosted Linux-Matrix von der reduzierten Kompatibilitätsprüfung auf die vollständige ResultTable-Suite umgestellt.
- `TC-2026-012` als bevorzugten nächsten Besprechungskandidaten eingeordnet und `TC-2026-004` bis zur Grundsatzentscheidung über Typ-/Scale-Parität und Objektfamilie zurückgestellt; keine Implementierungsfreigabe erteilt.
- Vier parallele ResultTable-Sitzungen mit identischen logischen lokalen Temp-Tabellennamen auf SQL Server 2019, 2022 und 2025 unter Linux erfolgreich validiert; invasiven DDL-Trigger-Harness als ungeeignete Recovery-Evidenz verworfen.
- Das pauschale Phase-2-Gate eines vollständig validierten, fachlich unabhängigen Referenzmoduls durch ein scopebezogenes Gate ersetzt; konkrete Modulverträge, Eigenvalidierung und tatsächlich verwendete gemeinsame Infrastruktur bleiben verpflichtend.
- `TC-2026-012` nach Benutzerfreigabe vom Research-Kandidaten zum implementierten und auf SQL Server 2025 Linux teilweise validierten Modul überführt.
- `TC-2026-006` nach Benutzerfreigabe vom Research-Kandidaten zum implementierten und auf SQL Server 2025 Linux teilweise validierten Modul überführt.
- Veralteten Backlogstatus des bereits gemergten Base64-Arbeitspakets von `active` auf `completed` korrigiert.
- `TC-2026-001`, `TC-2026-030` und `TC-2026-031` nach gemeinsamer Vertragsbesprechung und ausdrücklicher Freigabe vom 2026-07-30 auf `ready for development` gesetzt; Arbeitspakete `AP-2026-011` bis `AP-2026-013` angelegt.
- `TC-2026-029` aus `RI-2026-011` als `AP-2026-010` implementiert und auf SQL Server 2025 Linux teilweise validiert.
- Identifier-Runtime-Matrix auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 einschließlich Parser-, Quote-, Escape-, Omission-, Längen-, Fehler-, Deployment- und Lifecycle-Contracts erfolgreich.
- `TC-2026-001` als `AP-2026-011` implementiert; die breitere Split-Version mit Separatorstrings beliebiger Länge, frei definierbaren Quote-Zeichen und Escape bleibt getrennt als `TC-2026-032` im Research-Status.
- Split-Characters-Runtime-Matrix auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 einschließlich Literal-, Leer-Token-, NULL-/NUL-, Collation-, LOB-, Dependency-, zentraler und Lifecycle-Contracts erfolgreich; Status auf `partially validated` angehoben.
- Modul `toolbelt.validation.semantic-version` mit striktem SemVer-2.0.0-Parser, Comparator und binärem Sort Key ohne numerischen Overflow.
- Semantic-Version-Runtime-Matrix auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 einschließlich Parser-, Präzedenz-, Sort-Key-, Größen-, Deployment- und Lifecycle-Contracts erfolgreich; Status auf `partially validated` angehoben.
- Modul `toolbelt.conversion.integer-base` mit kanonischer Codierung und strikter Decodierung des vollständigen `bigint`-Bereichs für frei definierbare ASCII-Alphabete der Basen 2 bis 93.
- Integer-Base-Runtime-Matrix auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 einschließlich Alphabet-, Kanonizitäts-, Grenzwert-, Overflow-, Deployment- und Lifecycle-Contracts erfolgreich; Status auf `partially validated` angehoben.

### Korrigiert

- Bucket-SQL-Alias und Optimizer-Expansion korrigiert. Die drei öffentlichen
  Verträge bleiben Inline TVFs; ein interner einzeiliger Core verhindert den
  in der Runtime nachgewiesenen SQL-Server-Fehler `8632`.
- Modulzahl, Modulübersichten, Testinventar, Roadmap, Backlog, Research-Fokus
  und den kandidatenübergreifenden Implementierungsplan auf die tatsächlich
  vorhandenen 10 Module synchronisiert.
- W1-Evidenz in Manifesten und gekoppelter Dokumentation auf den finalen
  erfolgreichen Runtime-Lauf `30553118399` sowie den finalen
  Dokumentationslauf `30553118014` vereinheitlicht.
- Abgeschlossene Arbeitspakete aus dem aktiven Backlogabschnitt entfernt und
  den noch aktiven ResultTable-Validierungsscope getrennt ausgewiesen.
- W2a mit `TC-2026-004`, `TC-2026-005` und `TC-2026-007` nach
  funktionsbezogener Freigabe implementiert; offene JSON-Oberflächen bleiben
  getrennt in `W2b`.
- Dokumentationsvalidator um manifestbasierte Prüfungen für Modulzahl,
  README-/Testinventar, implementierte Kandidaten und Research-Inbox-Status
  erweitert; W1-Runtime-Trigger auf Runtime- und Manifestpfade begrenzt.
- Kandidatenstatus und nächste Schritte von `TC-2026-003`, `TC-2026-006`, `TC-2026-012` und `TC-2026-029` an den nachweisbaren Implementierungs- und Validierungsstand angeglichen.
- Custom-Agent-Profil auf gültige `.agent.md`-Struktur mit YAML-Frontmatter umgestellt.
- Generische Objektvorlagen durch objekttypspezifische USP-, TVF-, SVF- und View-Vorlagen ersetzt.
- USP-Vertrag und Teststandard um vollständige `@ResultTable`- und `@KeepData`-Contract-Tests ergänzt.
- SQL Server 2025 in Support-, Manifest- und Testmatrizen aufgenommen.
- CLR-Linux-Grenzen und `TRUSTWORTHY`-Ausnahmeregel präzisiert.
- Statusangaben nach dem initialen Merge aktualisiert.
- Entscheidungsprotokoll, Contribution-Regel und technische Identifier-Sprache konsolidiert.
- Bereits in `SQL_Server_Analyze` vorhandenen Unused-Index-Kandidaten aus dem offenen Analyze-Backlog entfernt.
- Identische Ziel- und Referenz-Temp-Tabelle wird vor jeder Mutation mit `51022` abgelehnt.
- Engine-Fehler beim Metadatenzugriff und bei `TRUNCATE` bleiben unverändert; der unzulässige `DELETE`-Fallback wurde entfernt.
- Debug-Stufen `4` bis `254` liefern für `USP_PrepareResultTable` denselben Detailumfang wie Stufe `3`.
- Deployment-Sessionoption und Objektartvergleich für XML- und Collation-stabile Ausführung korrigiert.
- Runtime-Testmetadaten für `datetime2(3)` und CI-Kollisionsvorbereitung korrigiert.
- Veraltete Runtime-Statusangaben in README, SECURITY und USP-Vertrag korrigiert.
- ResultTable-Evidenz auf den finalen erfolgreichen Linux-Workflow aktualisiert.

### Status

45 Module sind implementiert. 21 sind `validated`, 24 sind `partially validated`; 0 sind `not executed`. Die verbindliche, je Modul und Plattform getrennte Evidenz
steht in den Manifesten. Offene Windows- und modulspezifische Releasefälle
werden nicht aus Linux- oder Compatibility-Level-Läufen abgeleitet.

## 2026-10-04 – Table Clone Executor / 3.1.0

- Neuer expliziter `USP_ExecuteTableClone`: frischer kanonischer Plan,
  erwarteter Bytehash, ausschließlich neue SameDB-Ziele und eigene Transaktion.
  CREATE/DEFER bindet den vollständigen Plan; keine Daten- oder Triggerkopie.
- Vorhandene DB-/Servervollsicht und DDL-Seiteneffektgate, gekoppelte
  Deployment-/Uninstall-, Help-, ResultTable- und Client-Hashverträge.
- Gezielte lokale Nachweise auf SQL Server 2019 Linux/latest CL150 und
  2025 Windows/exakt CU8 CL170 bestanden, einschließlich genuine3→3.1,
  Caller-TX/SET, Fehlerrollback, Clientmetadata und eigener Bereinigung.
  Head-CI ist separat im Pull Request nachzuweisen; Modul weiterhin teilweise validiert und unveröffentlicht.

## 2026-10-04 – Table Clone W2 / V3 Source

- Vorhandene öffentliche/interne Prozedur mit TableMap an7 und ExternalReferenceRule an8; Standardtail9..12. Gemeinsamer W1-Renderer, Map-Snapshot, globale Reihenfolge, FK-Umleitung/KEEP, begrenzte Flags und FK-EP-Failclosed. Kein Execute-Wrapper, Provider oder Rechteänderung.
- Separate64Maps/1024Columns/128Indexes, exakt2048Childobjekte-plus-FK-Spaltentupel und globale2MiB. Begrenzte lokale W2-Native-/Upgrade-/Lifecycle-Nachweise auf Linux2019/latest CL150 und Windows2025/exakt CU8 CL170 bestanden mit frischer eigener Bereinigung. Linux-Fixtures sind wiederverwendeter Teilnachweis eines historischen Fehllaufs; Windows-Fixtures bestanden im aktuellen Clean3. Unresolved nicht etabliert, vollständige Qualifikation und aktuelle Head-CI offen; historische W1-Evidenz bleibt getrennt.
