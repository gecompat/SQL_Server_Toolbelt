# Architekturentscheidungen

Dauerhafte Entscheidungen werden mit stabiler ID dokumentiert. Historische Entscheidungen werden nicht rückwirkend umgeschrieben; eine Ablösung verwendet `superseded` und verweist auf die neue ID.

## Vorlage

```markdown
## DEC-YYYY-NNN: <Titel>

| Feld | Wert |
|---|---|
| Datum | YYYY-MM-DD |
| Status | proposed / accepted / superseded / rejected |
| Entscheidung | <Verbindliche Festlegung> |
| Begründung | <Fachliche Begründung> |
| Scope | <Betroffene Artefakte oder Module> |
| Auswirkungen | <Wesentliche Folgen> |
| Alternativen | <Verworfen oder nachrangig> |
| Betroffene Verträge | <Links> |
```

## DEC-2026-001: T-SQL-first

| Feld | Wert |
|---|---|
| Datum | 2026-07-28 |
| Status | accepted |
| Entscheidung | T-SQL ist die bevorzugte Implementierungssprache. |
| Begründung | Native Ausführung, geringe Deployment-Komplexität und breite Plattformverfügbarkeit. |
| Scope | alle Module |
| Auswirkungen | CLR, C#, Python, Java oder R benötigen eine dokumentierte technische Begründung. |
| Alternativen | CLR-first oder externe Runtime als Default wurden verworfen. |
| Betroffene Verträge | `TSQL_ENGINEERING.md`, `CLR_SECURITY_AND_PORTABILITY.md` |

## DEC-2026-002: Fachliche Schemas `toolbelt_<category>`

| Feld | Wert |
|---|---|
| Datum | 2026-07-28 |
| Status | accepted |
| Entscheidung | Öffentliche Objekte werden in kollisionsarmen fachlichen Schemas `toolbelt_<category>` angelegt. |
| Begründung | Eindeutige Herkunft und geringeres Kollisionsrisiko bei lokaler Installation. |
| Scope | öffentliche Schemas und Synonyme |
| Auswirkungen | Generische Schemas wie `string`, `time`, `io`, `json` oder `xml` sind unzulässig. |
| Alternativen | Ein einzelnes Schema `toolbelt` und unpräfixierte Kategorien wurden verworfen. |
| Betroffene Verträge | `SQL_OBJECT_NAMING.md` |

## DEC-2026-003: Weitere Objekttypen bleiben offen

| Feld | Wert |
|---|---|
| Datum | 2026-07-28 |
| Status | superseded |
| Entscheidung | Für persistente Tabellen, Synonyme, Assemblies, Trigger, Sequences und Types wird vor dem ersten Bedarf keine Namenskonvention erfunden. |
| Begründung | Die Konvention soll anhand eines konkreten fachlichen Objekts entschieden werden. |
| Scope | genannte persistente SQL-Objekttypen |
| Auswirkungen | Beim ersten Bedarf ist der Benutzer zu fragen und diese Entscheidung zu ersetzen oder anzunehmen. Interne lokale Temp-Objekte sind gesondert in `DEC-2026-017` geregelt. |
| Alternativen | Spekulative Präfixe für persistente Objekte wurden verworfen. |
| Betroffene Verträge | `SQL_OBJECT_NAMING.md` |

## DEC-2026-004: Modul- und Dependency-Modell

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Ein Modul ist Lifecycle-, Deployment- und Dokumentationseinheit; Abhängigkeiten sind versioniert und azyklisch. |
| Begründung | Teilinstallationen und kopierte Parallelimplementierungen müssen vermieden werden. |
| Scope | alle Module und Installer |
| Auswirkungen | Dependency-Preflight vor erster Mutation; keine automatische Nachinstallation. |
| Alternativen | Objektweise unabhängige Installation wurde verworfen. |
| Betroffene Verträge | `MODULE_AND_DEPENDENCY_MODEL.md`, Modulmanifest |

## DEC-2026-005: Lokale und zentrale Installation

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Capabilities sollen lokal in einer Zieldatenbank und zentral in einer Toolbelt-Datenbank einsetzbar sein, soweit technisch möglich. |
| Begründung | Unterschiedliche Betriebsmodelle sollen denselben fachlichen Vertrag nutzen. |
| Scope | Deployment, Wrapper, Synonyme |
| Auswirkungen | Cross-database-Verwendung ist Designziel; lokale Installation bleibt bei technischen Grenzen zulässig oder erforderlich. |
| Alternativen | Nur zentrale oder nur lokale Installation wurden verworfen. |
| Betroffene Verträge | `DEPLOYMENT_MODEL.md` |

## DEC-2026-006: Einheitlicher USP-Hilfevertrag

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Jede Toolbelt-USP besitzt `@Hilfe bit = 0`; bei `@Hilfe = 1` wird ausschließlich ein stabiles maschinenlesbares Help-Resultset ausgegeben. |
| Begründung | Menschen und KI-Systeme sollen Vertrag, Parameter, Resultspalten und Beispiele ohne Quellcodeanalyse ermitteln können. |
| Scope | öffentliche und interne USPs |
| Auswirkungen | Fachliche Pflichtparameter erhalten technische Defaults; Help-Modus verursacht keine Seiteneffekte. |
| Alternativen | Freitext-`PRINT` und pro USP unterschiedliche Help-Formate wurden verworfen. |
| Betroffene Verträge | `USP_CONTRACT.md` |

## DEC-2026-007: `@ResultTable` und `@KeepData`

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | USPs mit tabellarischem Resultset unterstützen eine bestehende lokale Temp-Tabelle über `@ResultTable`; `@KeepData` steuert Replace oder Append. |
| Begründung | Resultsets müssen ohne verschachteltes `INSERT ... EXEC` programmatisch weiterverarbeitet werden können. |
| Scope | USPs mit fachlichem tabellarischem Resultset |
| Auswirkungen | Höchstens ein fachliches Resultset; vollständige Contract-Testmatrix; beliebige Dummyspalte zulässig. |
| Alternativen | Nur Console-Resultset und generisches `INSERT ... EXEC` wurden verworfen. |
| Betroffene Verträge | `USP_CONTRACT.md`, `TEST_AND_VALIDATION_POLICY.md` |

## DEC-2026-008: Metadaten, Collation und String-Typen

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Reguläre Metadaten werden bevorzugt über Catalog Views gelesen; lokale Temp-Tabellen einmalig über `OBJECT_ID` aufgelöst. String-Typ und Collation werden nach fachlicher Semantik gewählt. |
| Begründung | Unnötige Metadatenfunktionsaufrufe, Collation-Konflikte und pauschaler Unicode-Overhead sollen vermieden werden. |
| Scope | T-SQL-Implementierungen und interne Temp-Objekte |
| Auswirkungen | Geeignete read-only Catalog-Abfragen dürfen `NOLOCK` verwenden; `nvarchar` ist kein pauschaler Default. |
| Alternativen | Wiederholte Metadatenfunktionen und pauschales `nvarchar` wurden verworfen. |
| Betroffene Verträge | `TSQL_ENGINEERING.md` |

## DEC-2026-009: CLR-Trust und `TRUSTWORTHY`

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Exaktes SHA2-512-Hash-Pinning ist bevorzugter Release-Trust; Strong Name ist Alternative. `TRUSTWORTHY ON` bleibt eine ausdrücklich freizugebende Last-Resort-Ausnahme. |
| Begründung | Reproduzierbare Autorisierung ohne Veröffentlichung privater Schlüssel und ohne pauschales Datenbankvertrauen. |
| Scope | CLR und privilegierte Datenbankkontexte |
| Auswirkungen | Linux unterstützt nur geeignete `SAFE`-CLR-Szenarien; private Signing Keys bleiben außerhalb des Repositorys. |
| Alternativen | `TRUSTWORTHY ON` oder deaktiviertes `clr strict security` als Default wurden verworfen. |
| Betroffene Verträge | `CLR_SECURITY_AND_PORTABILITY.md` |

## DEC-2026-010: Debugdaten und Secrets

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Diagnostisch notwendige vertrauliche Runtime-Werte dürfen im lokalen Debug erscheinen; echte Secrets werden nicht aktiv ausgegeben. |
| Begründung | Diagnosefähigkeit bleibt erhalten, ohne Credentials offenzulegen. |
| Scope | Debug-Messages und Runtime-Ausgaben |
| Auswirkungen | Reale Debugausgaben dürfen nicht als Repository-, Help-, Beispiel- oder Testartefakt übernommen werden. |
| Alternativen | Vollständige Runtime-Anonymisierung und uneingeschränkte Secret-Ausgabe wurden verworfen. |
| Betroffene Verträge | `DATA_PRIVACY_AND_CONFIDENTIALITY.md`, `USP_CONTRACT.md` |

## DEC-2026-011: Repository-Grenze zu SQL Server Analyze

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Analyse-, Diagnose-, Performance-, Konfigurations- und Security-Assessment-Funktionalität wird nicht im Toolbelt implementiert. |
| Begründung | `gecompat/SQL_Server_Analyze` besitzt die fachliche Verantwortung. |
| Scope | Backlog und Modulklassifikation |
| Auswirkungen | Ideen werden nur als geprüfter Backlog-Input erfasst; vor Eintrag erfolgt nach Möglichkeit ein Duplikatabgleich. |
| Alternativen | Parallele Analyseimplementierungen wurden verworfen. |
| Betroffene Verträge | `REPOSITORY_BOUNDARIES.md`, Analyze-Kandidatenliste |

## DEC-2026-012: Supportmatrix und portable Provider

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Die Grundmatrix umfasst SQL Server 2019, 2022 und 2025; Windows- und Linux-Support wird pro Modul und Provider getrennt ausgewiesen. |
| Begründung | „SQL Server 2019+“ muss aktuelle Hauptversionen konkret und prüfbar abbilden. |
| Scope | Manifest, Tests, Dokumentation und Provider |
| Auswirkungen | Windows-only-Capabilities benötigen eine Prüfung auf portable Alternativen; `not applicable` erfordert Begründung. |
| Alternativen | Nur 2019/2022 und pauschale Plattformzusagen wurden verworfen. |
| Betroffene Verträge | `DEPLOYMENT_MODEL.md`, `TEST_AND_VALIDATION_POLICY.md` |

## DEC-2026-013: Erstes Kernmodul `toolbelt.core.result-table`

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Das erste geplante Kernmodul trägt die ID `toolbelt.core.result-table` und stellt in Version `1.0.0` ausschließlich `toolbelt_core.USP_PrepareResultTable` bereit. |
| Begründung | ResultTable-Routing ist Voraussetzung für programmatisch verschachtelbare Toolbelt-USPs und eignet sich als erste Referenz für Lifecycle, Help, Deployment und Contract Tests. |
| Scope | `AP-2026-002`, erstes `toolbelt_core`-Modul |
| Auswirkungen | Die erste Version benötigt keine persistente Tabelle, kein Synonym, keine Assembly und keinen Type; `DEC-2026-003` bleibt daher für persistente Objekttypen offen. |
| Alternativen | Ein breiteres allgemeines Core-Modul mit spekulativer Modulregistrierung wurde für die erste Welle verworfen. |
| Betroffene Verträge | `RESULT_TABLE_MODULE_DESIGN.md`, `USP_CONTRACT.md` |

## DEC-2026-014: Referenztabelle vor frei geliefertem `CREATE TABLE`-DDL

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Version `1.0.0` ermittelt das gewünschte Schema aus einer vorhandenen lokalen oder regulären Referenztabelle über `@LikeTable`. Ein öffentlicher `@CreateStmt`-Parameter wird für diese Version zurückgestellt. |
| Begründung | Eine routinenspezifische Helper-Temp-Tabelle lässt SQL Server selbst Datentyp, Länge, Precision, Scale, Nullability und Collation auflösen und vermeidet in der ersten Version einen unvollständigen DDL-Sicherheitsparser. |
| Scope | `toolbelt_core.USP_PrepareResultTable` und aufrufende Toolbelt-USPs |
| Auswirkungen | Jede resultseterzeugende USP legt bei Bedarf eine eindeutig benannte Schema-Helper-Temp-Tabelle an und übergibt sie als `@LikeTable`. Die zuvor erwogene `@CreateStmt`-Capability bleibt ein möglicher späterer Ausbau, benötigt für fremdes DDL jedoch ScriptDOM oder einen gleichwertigen vollständigen Parser und einen eigenen Sicherheitsvertrag. |
| Alternativen | Für Version `1.0.0` wurden Regex-/String-basierte Sicherheitsbewertung beliebigen DDLs und ungeprüfte Ausführung von `@CreateStmt` verworfen; die Capability als solche wird nicht dauerhaft ausgeschlossen. |
| Betroffene Verträge | `RESULT_TABLE_MODULE_DESIGN.md`, `TSQL_ENGINEERING.md` |

## DEC-2026-015: In-place-Schemaumbau mit vollständigem Preflight

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Eine abweichende lokale ResultTable wird nach vollständigem read-only Preflight mit einer temporären Anchor-Spalte in-place umgebaut; das Zielobjekt wird nicht gedroppt und neu erstellt. |
| Begründung | Das vom Aufrufer erzeugte lokale Temp-Objekt muss in seinem ursprünglichen Scope erhalten bleiben. |
| Scope | `@KeepData`-Replace-Pfad von `USP_PrepareResultTable` |
| Auswirkungen | Blockierende Indizes, Constraints, computed columns, Trigger, user-created statistics oder andere Dependencies führen vor der ersten Mutation zum Abbruch; kein Blocker wird automatisch entfernt. |
| Alternativen | Drop/Recreate des Zielobjekts und automatisches Entfernen fremder Dependencies wurden verworfen. |
| Betroffene Verträge | `RESULT_TABLE_MODULE_DESIGN.md`, `RESULT_TABLE_CONTRACT_TEST_MATRIX.md` |

## DEC-2026-016: Savepoint-fähiger Transaktionsvertrag und zentrale Verwendbarkeit

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Die ResultTable-Mutation verwendet eine eigene Transaktion oder bei vorhandener Caller-Transaktion einen Savepoint. Das Modul unterstützt lokale und zentrale Installation ohne Synonympflicht. |
| Begründung | Fehler dürfen keinen halb umgebauten Zustand hinterlassen; zugleich darf eine Toolbelt-USP keine vollständige Caller-Transaktion committen oder zurückrollen. Lokale Temp-Tabellen derselben Session sind auch bei dreiteiligem Procedure-Aufruf nutzbar. |
| Scope | Transaktions-, Fehler- und Deployment-Vertrag des ResultTable-Moduls |
| Auswirkungen | Bei `XACT_STATE() = -1` bleibt der uncommittable Zustand sichtbar; die Procedure rethrowt den Originalfehler. Zentrale Deinstallation benötigt eine Betreiberbestätigung, weil beliebige externe Direktaufrufer nicht vollständig ermittelbar sind. |
| Alternativen | Unbedingter Full Rollback, `TRUSTWORTHY ON`, Synonympflicht und separate lokale/ zentrale Fachimplementierungen wurden verworfen. |
| Betroffene Verträge | `RESULT_TABLE_MODULE_DESIGN.md`, `DEPLOYMENT_MODEL.md` |

## DEC-2026-017: Interne lokale Temp-Objekte verwenden `#tbx_`

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Interne lokale Temp-Tabellen verwenden den reservierten Präfix `#tbx_` sowie englische Modul-, Routine- und Rollenbestandteile; dynamische Arbeitsobjekte erhalten zusätzlich einen Invocation-spezifischen Suffix. |
| Begründung | Eindeutige Namen vermeiden Kollisionen in verschachtelten, rekursiven und parallelen Aufrufkontexten und unterscheiden interne Objekte von Benutzer-ResultTables. |
| Scope | interne lokale Temp-Objekte aller Module |
| Auswirkungen | Benutzer-ResultTables dürfen nicht mit `#tbx_` beginnen. Routinenspezifische unveränderliche Schema-Helper dürfen bei Rekursion wiederverwendet und nur vom tatsächlichen Erzeuger entfernt werden. Die Namenskonvention persistenter Tabellen bleibt offen. |
| Alternativen | Generische Namen wie `#Temp`, `#Result` und zufällige Namen ohne fachliche Zuordnung wurden verworfen. |
| Betroffene Verträge | `SQL_OBJECT_NAMING.md`, `TSQL_ENGINEERING.md`, `RESULT_TABLE_MODULE_DESIGN.md` |

### Ergänzung vom 2026-10-04: ZIP-ResultTable-Brücken

| Feld | Wert |
|---|---|
| Status | accepted; technische Codex-Entscheidung innerhalb des bereits einzeln freigegebenen Zwei-Fassaden-Scopes |
| Entscheidung | Ausschließlich `USP_CreateZipFileFromEntries` und `USP_ExtractZipEntryToFile` dürfen `#ZipFiles_CreateStage`, `#ZipFiles_ExtractStage` und `#ZipFiles_WriteStage` als eigene feste ResultTable-Brücken verwenden. Andere interne lokale Temps behalten `#tbx_`. |
| Begründung | Der vorhandene ResultTable-1.0-Vertrag lehnt Zielnamen mit `#tbx_` ab. Die begrenzte Ausnahme ermöglicht statische Aufrufe der bestehenden Provider ohne Coreänderung oder dynamisch verdeckte SQL-Dependencies. |
| Scope | Genau die drei Brücken der beiden Windows-local-Fassaden in `toolbelt.archive.zip-files` 1.0.0. Die ursprüngliche Entscheidung bleibt für alle übrigen internen Temps bestehen. |
| Auswirkungen | Vor CREATE werden alle drei Namen auf Kollision geprüft; Callerinput und Calleroutput dürfen sie nicht referenzieren. Keine Adoption oder Löschung fremder Temps; eigene Temps enden mit dem Procedure-Scope. Diese Entscheidung liefert keinen Runtime- oder Qualifikationsnachweis. |
| Alternativen | Eine allgemeine Namensfreigabe, Änderung des Corevertrags und dynamische Provideraufrufe werden nicht eingeführt. |
| Betroffene Verträge | [ZIP_FILES_CONTRACT.md](ZIP_FILES_CONTRACT.md), `SQL_OBJECT_NAMING.md`, `USP_CONTRACT.md`, `toolbelt.archive.zip-files` |

### Ergänzung vom 2026-10-04: Tabellenklon-Executor-Brücken

| Feld | Wert |
|---|---|
| Status | accepted; technische Codex-Entscheidung innerhalb des einzeln freigegebenen Executor-Scopes |
| Entscheidung | Nur `USP_ExecuteTableClone` verwendet `#TableCloneExecute_MapStage` und `#TableCloneExecute_PlanStage` als feste eigene Planner-/ResultTable-Brücken. |
| Begründung | Bestehende Caller-Verträge lehnen `#tbx_` als Map beziehungsweise ResultTable ab; statische kanonische Aufrufe benötigen eine begrenzte Ausnahme. |
| Scope | Zwei Brücken im Executor; übrige interne Temps behalten `#tbx_`. |
| Auswirkungen | Kollisionsprüfung vor CREATE, keine Callerinputs/-outputs unter diesen Namen, keine Adoption oder Entfernung fremder Objekte. Keine Änderung der Core-/Planner-API und kein Runtime-Nachweis aus dieser Entscheidung. |
| Alternativen | Keine allgemeine Präfixfreigabe, kein kopierter Planrenderer und kein verschachteltes INSERT EXEC. |
| Betroffene Verträge | [TABLE_CLONE_EXECUTE_CONTRACT.md](TABLE_CLONE_EXECUTE_CONTRACT.md), `SQL_OBJECT_NAMING.md`, `USP_CONTRACT.md` |

## DEC-2026-018: Persönlicher Brainstorm als erhaltener Research-Input

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | `Backlog/personal_Backlog_Bainstorm.md` wird vor jeder Funktionsrecherche und Backlog-Pflege als vom Benutzer gepflegte Hinweisquelle berücksichtigt. Bestehende Inhalte werden nicht gelöscht; Überholtes wird durchgestrichen und unmittelbar mit einem datierten Änderungskommentar versehen. |
| Begründung | Freie Gedanken sollen als dauerhafte Rechercheimpulse erhalten bleiben, ohne die Struktur und Verbindlichkeit der kanonischen Kandidatenlisten zu erzwingen oder historische Hinweise zu verlieren. |
| Scope | Funktionsrecherche, Backlog Curator, Backlog-Pflege und AI-Steuerung |
| Auswirkungen | KI-Systeme dürfen ergänzen, kommentieren und Querverweise setzen. Die Datei ist keine Source of Truth für Regeln, Prioritäten, öffentliche Verträge oder Implementierungsfreigaben. Formale Ergebnisse verbleiben in den kanonischen Kandidatenlisten und in `.ai/BACKLOG.md`. |
| Alternativen | Löschen nach Übernahme, stillschweigende redaktionelle Neufassung und Behandlung als kanonischer Fachbacklog wurden verworfen. |
| Betroffene Verträge | `AGENTS.md`, `.ai/PROJECT_RULES.md`, `.ai/WORKING_RULES.md`, `.ai/repo_map.yaml`, `Backlog/README.md`, `backlog-curator.agent.md` |

## DEC-2026-019: Parametergesteuertes Deployment mit Release-Manifesten

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Erstinstallation, Upgrade und Wiederholungsinstallation eines Moduls verwenden ein gemeinsames parametergesteuertes `Deploy.sql`. Lokaler und zentraler Modus wählen nur Installationsort und Metadatum. Versionierte Release-Manifeste bestimmen Framework-Herkunft, Kollisionen und entfernte Objekte. |
| Begründung | Getrennte Install- und Upgrade-Implementierungen erzeugen unnötige Drift. Die Herkunft aus einem bekannten Vorgängerrelease ist eine belastbarere Lösch- und Überschreibgrenze als ein Source-Hash. |
| Scope | alle Toolbelt-Module und ihre Lifecycle-Artefakte |
| Auswirkungen | Framework-Objekte aus dem bekannten Vorgängerrelease werden auch nach lokalen Änderungen aktualisiert oder bei Wegfall entfernt. Neue Zielobjekte dürfen keine frameworkfremden Namenskollisionen überschreiben. Wiederholungsinstallation derselben Version deployed alle Release-Objekte erneut. Source-Hashes bleiben rein diagnostisch. Mutationstransaktionen beginnen erst nach dem Preflight und dauern nur bis zur atomaren Aktualisierung von Objekten und Installationsstand. |
| Alternativen | getrennte Install-/Upgrade-Skripte sowie Drift-Blockade anhand von Source-Hashes wurden verworfen. |
| Betroffene Verträge | `DEPLOYMENT_MODEL.md`, `MODULE_AND_DEPENDENCY_MODEL.md`, `MODULE_DEFINITION_OF_DONE.md`, Modulmanifest und Lifecycle-Tests |

## DEC-2026-020: Manifestzentrierte Status- und Change-Impact-Steuerung

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Jedes Modulmanifest ist die autoritative Quelle für Implementierungs-, Validierungs- und Release-Status sowie gekoppelte Dokumentationspfade und Contract-Versionen. Wiederholte Statusdarstellungen werden aus den registrierten Manifesten erzeugt. Konsistenzprüfungen beginnen mit dem Git-Diff und laden nur die in `.ai/repo_map.yaml` registrierten Impact-Pakete. |
| Begründung | Unabhängig gepflegte Statusangaben und pauschale Repository-Scans erzeugen zugleich Drift und unnötigen Aufwand. Explizite Kopplungen machen den Prüfbereich deterministisch, sparsam und überprüfbar. |
| Scope | Modulmanifeste, README-Status, Modulübersicht, Dokumentationsprüfung, Pull Requests und CI-Auslösung |
| Auswirkungen | Ein Modul verwendet getrennte Felder `implementation_status`, `validation_status` und `release_status`. Vollständige Audits bleiben auf Baseline, Release, Governance- oder Kopplungsänderungen sowie ausdrückliche Aufträge begrenzt. Reine Dokumentationsänderungen starten keine Runtime-Vollmatrix. |
| Alternativen | Ein Sammelstatus, unabhängige manuelle Statuspflege, Vollscan bei jedem Commit und ungeprüfte Pfadheuristiken wurden verworfen. |
| Betroffene Verträge | `.ai/repo_map.yaml`, `.ai/PROJECT_RULES.md`, `.ai/WORKING_RULES.md`, `ARTIFACT_ROLES.md`, `MODULE_AND_DEPENDENCY_MODEL.md`, `TEST_AND_VALIDATION_POLICY.md`, Modulmanifeste und GitHub-Actions-Workflows |

## DEC-2026-021: Scopebezogenes Qualitäts-Gate für weitere Module

| Feld | Wert |
|---|---|
| Datum | 2026-07-29 |
| Status | accepted |
| Entscheidung | Ein weiteres Modul benötigt nicht pauschal ein vollständig validiertes, fachlich unabhängiges Referenzmodul. Verbindlich sind die funktionsbezogene Besprechung und Freigabe, vollständige eigene Source-, Lifecycle-, Dokumentations- und Testartefakte sowie eine für den konkret verwendeten Vertrag ausreichende Validierung jeder gemeinsamen Infrastruktur. |
| Begründung | Ein pauschales Gate koppelt unabhängige Capabilities ohne technische Ursache und blockiert sie durch offene Prüfungen fremder Verträge. Scopebezogene Gates erhalten die Qualitätsanforderung und machen den tatsächlichen Abhängigkeits- und Testumfang explizit. |
| Scope | Phase 2, Modulplanung, Dependency-Preflight, Test- und Statuswahrheit |
| Auswirkungen | `toolbelt.conversion.base64` kann ohne ResultTable-Abhängigkeit implementiert und eigenständig validiert werden. Ein Modul darf offene Pflichtfälle verwendeter gemeinsamer Infrastruktur nicht umgehen; nicht ausgeführte Tests bleiben sichtbar. |
| Alternativen | Vollständige Validierung irgendeines Referenzmoduls als pauschale Voraussetzung; vollständig unabhängige Module ohne eigenes Qualitäts-Gate. |
| Betroffene Verträge | `.ai/ROADMAP.md`, `.ai/BACKLOG.md`, `BASE64_MODULE_DESIGN.md`, `MODULE_DEFINITION_OF_DONE.md`, `TEST_AND_VALIDATION_POLICY.md` |

## DEC-2026-022: Inline-TVF-Alternative für Scalar Functions

| Feld | Wert |
|---|---|
| Datum | 2026-07-30 |
| Status | accepted |
| Entscheidung | Für jede öffentliche SVF wird nach Möglichkeit eine semantisch äquivalente inline TVF angeboten. Die inline TVF bildet den kanonischen relationalen Kern; die SVF bleibt als zusätzliche Convenience-API verfügbar. Ein TVF-Wrapper, der lediglich die SVF aufruft, erfüllt den Vertrag nicht. |
| Begründung | Nicht ge-inline-te Scalar UDFs verhindern Intra-query-Parallelität und verbergen Fachlogik vor dem Optimizer. Eine inline TVF lässt sich über `CROSS APPLY` oder `OUTER APPLY` mengenorientiert einbinden. Scalar UDF Inlining ab SQL Server 2019 kann den Nachteil nur unter Voraussetzungen aufheben und ist kein stabiler API-Vertrag. |
| Scope | Alle bestehenden und zukünftigen öffentlichen SVFs in T-SQL-Modulen |
| Auswirkungen | Neue SVFs benötigen im Design eine inline-TVF-Prüfung. Bestehende Lücken werden im Audit und in `AP-2026-014` nachverfolgt. Dokumentation und Beispiele empfehlen die relationale API für mengenorientierte Abfragen. |
| Alternativen | Nur SVFs anzubieten oder eine inline TVF als bloßen Aufruf-Wrapper um die SVF zu legen wurde verworfen. Der vollständige Verzicht auf SVFs wurde verworfen, weil die skalare API für Einzelaufrufe und bestehende Aufrufstellen nützlich bleibt. |
| Betroffene Verträge | `TSQL_ENGINEERING.md`, `MODULE_DEFINITION_OF_DONE.md`, `SVF_INLINE_TVF_AUDIT.md` |

## DEC-2026-023: CLR-ZIP-Provider und Assemblyname

**Status:** Accepted  
**Datum:** 2026-07-31

### Kontext

Der erfolgreich validierte SQL-CLR-Spike hat gezeigt, dass Raw-Deflate
über `DeflateStream` aus der unterstützten `System.dll` mit
`PERMISSION_SET = SAFE`, aktiviertem `clr strict security` und einer
expliziten SHA2-512-Vertrauensfreigabe auf SQL Server Linux ausführbar
ist. Für die produktive Erweiterung von
`toolbelt.archive.zip-memory` werden erstmals ein persistenter
Assemblyname und ein interner CLR-SQL-Objektname benötigt.

### Entscheidung

- Die vorhandene öffentliche
  `toolbelt_archive.USP_ExtractZipEntryFromBinary` bleibt der einzige
  öffentliche Entry-Extraktionsvertrag und wird intern CLR-backed.
- Die modulspezifische SQL-Assembly heißt
  `Toolbelt_Archive_ZipMemory`; das Binary heißt
  `Toolbelt.Archive.ZipMemory.dll`.
- Der interne SQL-Provider heißt
  `toolbelt_archive.TVF_InternalExtractZipEntryClr` und ist keine
  öffentliche Convenience-API.
- Diese Namen entscheiden ausschließlich den konkreten Bedarf dieses
  Moduls. Sie begründen keine globale Assembly- oder CLR-Objektnamensregel
  für andere Module; `DEC-2026-003` bleibt im Übrigen unverändert.
- Die Assembly referenziert direkt nur `System` und `System.Data`.
  Deflate verwendet `DeflateStream` aus `System.dll`; eine direkte
  Referenz auf `System.IO.Compression.dll` und `ZipArchive` ist
  ausgeschlossen.
- Reguläres Deployment bleibt `SAFE`, prüft den exakten SHA2-512-Hash
  gegen `sys.trusted_assemblies` und ändert weder `clr enabled`,
  `clr strict security`, `TRUSTWORTHY` noch die Trust-Liste.
- Trust-Opt-in und Trust-Entfernung sind getrennte administrative
  Vorgänge. Der Modul-Uninstall entfernt keinen serverweiten
  Trust-Eintrag.

### Folgen

Das Modul erhält einen expliziten Build-/Release-Schritt für DLL,
Trust-Manifest und ein aus dem Binary abgeleitetes Deployment-SQL.
Die Runtime-Matrix muss den echten CLR-Aufruf, Stored, Deflate,
Payload-CRC32, Limits, lokale und zentrale Installation sowie den
vollständigen Datenbank-Uninstall prüfen. Windows-SQL-Server-Runtime
bleibt ein separater Release-Nachweis.


## DEC-2026-024: Windows-only Filesystem Provider

| Feld | Wert |
|---|---|
| Datum | 2026-07-31 |
| Status | accepted |
| Entscheidung | Dateisystemzugriff ist ein lokales EXTERNAL_ACCESS-SQL-CLR-Modul für Windows. Default ist Caller über SqlContext.WindowsIdentity; ServiceAccount wird nur explizit verwendet. |
| Begründung | Ein interaktiv angemeldeter Benutzer ist aus SQL Server nicht zuverlässig bestimmbar. Relative Pfade unter Root-Aliassen, Reparse-Point-Sperren und Staging begrenzen das Risiko. |
| Scope | toolbelt.filesystem.windows; Text/Binary, Codepages, Transcoding, Directory-Operationen und rekursives Delete. |
| Auswirkungen | Ursprünglicher Vertrag: Linux not applicable; TRUSTWORTHY ON, UNSAFE, xp_cmdshell und absolute/UNC-Pfade ausgeschlossen; manueller Windows-Runtime-Nachweis verpflichtend. Die spätere ausdrückliche SC-023-Freigabe vom 2026-10-15 ersetzt ausschließlich den EXTERNAL_ACCESS-/UNSAFE-Teil; siehe Security-Härtung unten. |
| Alternativen | OPENROWSET(BULK) bleibt für portable read-only Nutzung ein separates Modul; es ersetzt keine kontrollierten Writes, Impersonation oder Directory-Verwaltung. |
| Betroffene Verträge | CLR_SECURITY_AND_PORTABILITY.md, USP_CONTRACT.md, WINDOWS_FILESYSTEM_MODULE_DESIGN.md |


## DEC-2026-025: Persistente Tabellen, Constraints und Indizes

| Feld | Wert |
|---|---|
| Datum | 2026-08-01 |
| Status | accepted |
| Entscheidung | Persistente Toolbelt-Tabellen verwenden im fachlichen `toolbelt_<category>`-Schema einen verständlichen singulären `CamelCase`-Namen ohne `TBL_`-Präfix. Constraints und Indizes werden explizit mit `PK_`, `UQ_`, `FK_`, `CK_`, `DF_` beziehungsweise `IX_` benannt. |
| Begründung | Das Schema und der SQL-Objekttyp identifizieren eine Tabelle bereits eindeutig. Fachliche Namen bleiben lesbar; explizite Constraint-/Indexnamen ermöglichen stabile Deployments, Fehlerdiagnose und Upgrade-Skripte. |
| Scope | Persistente Tabellen, ihre Constraints und Indizes; erster konkreter Einsatz ist `toolbelt_core.WorkType`. |
| Auswirkungen | Tabellen sind standardmäßig intern, sofern das Manifest sie nicht ausdrücklich public erklärt. Spalten sind englisch und `CamelCase`; systemgenerierte Constraintnamen sind unzulässig. Direkter Tabellenzugriff ist kein impliziter API-Vertrag. |
| Alternativen | `TBL_`-/`TB_`-Präfixe und unbenannte Constraints wurden verworfen. Pluralformen bleiben nur bei fachlich etablierten Sammelbegriffen zulässig. |
| Betroffene Verträge | `SQL_OBJECT_NAMING.md`, `WORK_TYPE_MODULE_DESIGN.md`, `toolbelt.core.work-type` |

## DEC-2026-026: AI Repository Foundation 1.2 als additive Governance-Baseline

| Feld | Wert |
|---|---|
| Datum | 2026-08-23 |
| Status | accepted |
| Entscheidung | AI Repository Foundation 1.2 wird über den manifestierten Rules-only-Umfang unter `.ai/foundation/` integriert. `AGENTS.md` bleibt der kanonische Einstieg; die vorhandenen Toolbelt-Regeln bleiben für Projektfakten, Fachverträge und bewusst strengere Vorgaben autoritativ. Ausgewählt ist der vorhandene GitHub-Copilot-Adapter; Claude- und Gemini-Adapter bleiben unselektiert. |
| Begründung | Die Foundation ergänzt portable Regeln für Autorisierung, Sicherheit, Provenienz, Quellen, Dependencies und getrennte Validierungsebenen, ohne reife projektspezifische Governance zu ersetzen. Der semantische Integrationsvertrag verhindert Textüberschreibung und Regelverlust. |
| Scope | KI-Governance, Regel-Discovery, Modellrouting, Validierung, Datenschutz, Drittanbieter- und Quellenbehandlung |
| Auswirkungen | Das funktionsbezogene Implementierungs-Gate und der strengere Datenschutz sind `PROJECT_STRONGER`. Die Toolbelt-Modellrichtlinie und ihre Foundation-Tier-Zuordnung sowie die erweiterten Validierungsstatus sind `COMPLEMENTARY`. KI-Commit-Regel, Sprache, Git-/Merge-Workflow und konkrete Prüfkommandos bleiben `PROJECT_SELECTABLE_OVERRIDE`. Der Copilot-Adapter ist eine reine Discovery-Brücke; das projektspezifische Backlog-Curator-Profil bleibt als ausgewählte Capability erhalten. Foundation-Integrität, Toolbelt-Semantik und Runtime-Evidenz werden getrennt berichtet. |
| Alternativen | Vollständiges Ersetzen bestehender Regeln, Kopieren des Foundation-Repositories als Template, Änderung der Toolbelt-Root-Lizenz und parallele Governance in Tool-Adaptern wurden verworfen. |
| Betroffene Verträge | `AGENTS.md`, `.ai/foundation/`, `.ai/repo_map.yaml`, `.github/copilot-instructions.md`, `AI_COST_AND_QUALITY_PROCESSING_POLICY.md`, `TEST_AND_VALIDATION_POLICY.md` |

## DEC-2026-027: Statuswahrheit aus Manifesten und lokal begrenzte Ableitungen

| Feld | Wert |
|---|---|
| Datum | 2026-08-24 |
| Status | accepted |
| Entscheidung | Modulstatus und aggregierte Statussummen werden ausschließlich aus den registrierten `module.yaml`-Manifesten abgeleitet. Eine als abgeleitet gekennzeichnete Backlog-Zeile muss innerhalb desselben AP-Abschnitts zum im `Scope` genannten Modul passen. AP- und Roadmap-Phasen-IDs sind dokumentweit eindeutig. |
| Begründung | Eine dokumentweite Textsuche konnte einen falschen Status in einem Arbeitspaket durch einen richtigen Status an anderer Stelle verdecken. Manuell gepflegte Aggregatsummen und doppelte IDs erzeugten zusätzlich widersprüchliche Projektwahrheit. |
| Scope | Modulmanifeste, aktuelle Statusdokumente, `.ai/BACKLOG.md`, `.ai/ROADMAP.md` und Dokumentationsvalidator |
| Auswirkungen | Der vollständige Audit prüft Implementierungs-, Validierungs- und Releasewerte im lokalen AP-Abschnitt, Manifestaggregate sowie doppelte Planungs-IDs. Historische Changelog-Aussagen bleiben historische Evidenz und werden nicht umgeschrieben. |
| Alternativen | Globale Textsuche, vollständig manuelle Summenpflege und nicht eindeutige wiederverwendete Planungs-IDs wurden verworfen. |
| Betroffene Verträge | `Tests/Documentation/validate_documentation.py`, `.ai/BACKLOG.md`, `.ai/ROADMAP.md`, `Modules/README.md`, `PROJECT_CONTEXT.md` |

## DEC-2026-028: Foundation 1.4 und Bestandsschutz für Projektidentitäten

| Feld | Wert |
|---|---|
| Datum | 2026-08-24 |
| Status | accepted |
| Entscheidung | AI Repository Foundation 1.4 wird als additive Weiterentwicklung der mit `DEC-2026-026` eingeführten Baseline übernommen. Alle bestehenden stabilen Toolbelt-Referenzen und ihre bisherigen Bedeutungen bleiben im Modus `PRESERVE` unverändert. Die optionalen Foundation-Referenz-Clients werden nicht ausgewählt. |
| Begründung | Das Repository verwendet mehrere etablierte, fachlich getrennte Referenzfamilien, unter anderem `DEC`, `AP`, `TC`, `AC`, `UE`, `RI` und `SRC`. Eine rückwirkende Umbenennung erzeugte keinen gleichwertigen Nutzen und wäre ohne Alias- und Migrationsplan riskant. Die Bestandsaufnahme fand keine bereits dokumentierte, gemeinsame Registration Authority, die für Menschen und KI kollisionssicher neue finale Sequenzreferenzen vergibt. |
| Scope | Foundation-Identitäts- und Registrierungsregeln, bestehende Planungs-, Entscheidungs-, Research- und Quellenreferenzen |
| Auswirkungen | Historische Referenzen werden nicht umgedeutet, wiederverwendet oder aus dieser Integration heraus migriert. Vor der Einführung einer neuen finalen Referenzfamilie oder eines neuen automatisierten Allocators muss eine gesonderte Architekturentscheidung eine Registration Authority je überlappendem Scope sowie `DIRECT` oder `DEFERRED`, Kollisionsschutz, Recovery und dauerhafte Historie festlegen. Die hier übernommene Policy ist bis dahin ergänzende Governance und keine Ermächtigung, Sequenznummern aus Markdown, Git-Historie oder Modellgedächtnis zu erraten. |
| Alternativen | Retroaktive UUID-/Präfixmigration, stillschweigende Fortsetzung einer vermuteten Vergaberegel, Auswahl der optionalen Python-/PowerShell-Clients ohne Projektentscheidung |
| Betroffene Verträge | `.ai/foundation/PERSISTENT_IDENTITY_POLICY.md`, `.ai/foundation/ARTIFACT_REGISTRATION_POLICY.md`, `.ai/foundation/schemas/`, `.ai/repo_map.yaml`, `DEC-2026-026`, `Backlog/CANDIDATE_TEMPLATE.md`, `.github/agents/backlog-curator.agent.md` |

## DEC-2026-029: T-SQL Script Parser Modularchitektur und Providerentscheidung

| Feld | Wert |
|---|---|
| Datum | 2026-09-03 |
| Status | accepted |
| Entscheidung | Ein neues Modul `toolbelt.tsql.script-parser` wird im Schema `toolbelt_tsql` eingerichtet. Öffentliche Schnittstellen werden als CLR-Table-Valued-Functions (TVFs) für Knoten, Knoteneigenschaften, Tokenstrom und Parse-Fehler bereitgestellt. Als Parserkern wird `Microsoft.SqlServer.TransactSql.ScriptDom` (.NET Framework 4.8) evaluiert und eingesetzt. Das Modul liefert ausschließlich neutrale syntaktische Zerlegung (AST/Tokens/Fehler) ohne semantische Namens-/Aliasauflösung und ohne Code-Analyse (`DEC-2026-011`). |
| Begründung | Für das geplante semantische Umschreiben von SQL-Statements auf Framework-GUIDs sowie die sichere DDL-Inspektion (`DEC-2026-014`) wird ein vollständiger T-SQL-AST benötigt. T-SQL allein kann keine vollständige SQL-Grammatik parsen. `ScriptDom` ist die offizielle Microsoft-Referenz für T-SQL-ASTs. TVFs streamen Zeilen speicherschonend und sind per `CROSS APPLY` direkt in T-SQL-Pipelines komponierbar. |
| Scope | Modul `toolbelt.tsql.script-parser`, Schema `toolbelt_tsql`, Assembly `Toolbelt_Tsql_ScriptParser` und Drittanbieter-Assembly `Microsoft.SqlServer.TransactSql.ScriptDom` |
| Auswirkungen | Die Schemakategorie `toolbelt_tsql` und der Assemblyname `Toolbelt_Tsql_ScriptParser` werden autorisiert. Das Deployment verwaltet ggf. zwei Assemblies mit SHA2-512-Trust. Vor Modul-Release wird die Ladbarkeit unter `SAFE` bzw. `EXTERNAL_ACCESS`/`UNSAFE` sowie auf Linux/Windows in einem Spike nachgewiesen. |
| Alternativen | Reiner T-SQL-Parser (nicht grammatikvollständig), reiner Tokenizer ohne AST (für AST-Analyse unzureichend), Stored Procedures mit Temp-Tabellen (nicht per TVF/CROSS APPLY komponierbar), externes Parsen außerhalb der Datenbank. |
| Betroffene Verträge | `SQL_OBJECT_NAMING.md`, `CLR_SECURITY_AND_PORTABILITY.md`, `THIRD_PARTY_AND_SOURCE_POLICY.md`, `TC-2026-047`, `.ai/BACKLOG.md`, `.ai/repo_map.yaml` |

### 2026-10-04 – Tabellenklon als Parser-Verbraucher (`TC-2026-044`)

| Feld | Wert |
|---|---|
| Datum | 2026-10-04 |
| Status | accepted; einzeln freigegebene Funktion und konkrete4.0-Vertragsdetails |
| Entscheidung | Der bestehende Tabellenklon-Planner verwendet ausschließlich beim Windows-Opt-in `IncludeTriggers=1` die vier TVFs des exakt gepinnten Parser2.0. Semantische Map-/Alias-/CTE-Bindung gehört in den Tabellenklon-Verbraucher; der Parser bleibt unverändert syntaktisch. |
| Begründung | Belegte AST-/UTF16-Spannen ermöglichen Identifierumschreibung bei erhaltenen Kommentaren und Literalen. Katalogbindung und lokale Scopes verhindern ungeprüfte Namensersetzung. |
| Scope | Trigger-Vorschau im bestehenden `toolbelt.metadata.table-clone`; keine neue Assembly oder öffentliche Prozedur. |
| Auswirkungen | Planner13 mit Standardtail10..13, bestehender Executor14 weiterhin triggerfrei, Release4.0-Hashbindung und begrenzte feste Triggerbatches. Generierte `TR_`-Namen prüfen bestehende und geplante schemaweite Namen. Keine globale Triggernamenskonvention oder automatische Parserinstallation. |
| Alternativen | Blindes Text-REPLACE verworfen; vollständiger Prettyprint verliert den Lexemerhalt. Die bisherige Triggerablehnung bleibt als Default0 verfügbar. |
| Betroffene Verträge | [Triggervertrag](TABLE_CLONE_TRIGGER_CONTRACT.md), [Executorvertrag](TABLE_CLONE_EXECUTE_CONTRACT.md), [individuelle Freigaben](../../.ai/BACKLOG.md). |

## DEC-2026-030: Vollständige AI Repository Foundation 1.17.2

| Feld | Wert |
|---|---|
| Datum | 2026-09-09 |
| Status | accepted |
| Entscheidung | Die AI Repository Foundation 1.17.2 wird vollständig als manifestierter Core, alle Discovery-Adapter und alle ohne zusätzliche Projektentscheidung anwendbaren optionalen Referenz-Capabilities integriert. Bestehende Toolbelt-Governance, historische Identifier und die bisherigen Stop-Gates bleiben erhalten. |
| Begründung | Der ausdrückliche Auftrag verlangt die vollständige Aktualisierung. Die Foundation ergänzt die vorhandene kosten- und qualitätsoptimierte KI-Arbeit um portable Verträge für Modellrouting, AI-Arbeitsorchestrierung, Runtime-Adapter, Ausführung, Provisionierung, Client-Integration und installierte Provenienz. |
| Scope | `.ai/foundation/`, `AGENTS.md`, Discovery-Adapter, Foundation-Provenienz und zugehörige Governance-Dokumentation |
| Auswirkungen | Die Referenz-Capabilities sind verfügbar, aber nicht konfiguriert: Sie erzeugen keine Runtime-Abhängigkeit, keinen Netzwerkzugriff, keinen Modell- oder Prompt-Transfer, keine Credentials, keine externen Effekte und keine GitHub-Administration. `artifact-registry-github` bleibt unselektiert, da das Repository keine zentral entschiedene Artifact Registry besitzt und dessen Workflow sonst Pull Requests blockieren würde. Solche Wirkungen bleiben an die jeweiligen projekt- und auftragsbezogenen Freigaben gebunden. Die bestehende Registration-Authority-Entscheidung aus `DEC-2026-028` bleibt unverändert. |
| Alternativen | Core-only-Upgrade, Beibehaltung nur des Copilot-Adapters oder Konfiguration einer konkreten KI-Runtime wurden verworfen, weil sie den vollständigen Auftrag nicht erfüllen beziehungsweise zusätzliche nicht beauftragte externe Wirkungen auslösen würden. |
| Betroffene Verträge | `AGENTS.md`, `.ai/foundation/FOUNDATION_RULESET.md`, `.ai/foundation/AI_WORK_ORCHESTRATION_POLICY.md`, `.ai/foundation/MODEL_ROUTING_POLICY.md`, `.ai/foundation/installation-provenance.json`, `THIRD_PARTY_AND_SOURCE_POLICY.md`, `.ai/repo_map.yaml`, `DEC-2026-028` |

## DEC-2026-031: Work Queue v2 mit explizitem Retry und Gruppen-Barriers

| Feld | Wert |
|---|---|
| Datum | 2026-09-10 |
| Status | accepted |
| Entscheidung | `toolbelt.core.work-queue` wird in W6c als Version 2.0.0 um expliziten Retry, Dead Letter, Idempotenz, Priorität und gruppenbezogene `DRAIN_BARRIER` erweitert. Der Worker klassifiziert Retry; `USP_FailWork` bleibt terminal. |
| Begründung | Wiederholung, Dead Letter und Idempotenz benötigen denselben persistierten Queuezustand wie Lease und Claim. Systemveränderungen erfordern zusätzlich, dass ein höher priorisierter Wartungsauftrag laufende Arbeit einer definierten Gruppe geordnet abwartet, ohne sie zu beenden. |
| Scope | `TC-2026-020`, `TC-2026-048`, WorkItem-Persistenz, Claim-Reihenfolge, Statusoberflächen, Deployment, Upgrade und Work-Queue-Contract-Tests. |
| Auswirkungen | Retry-Policy ist pro Item unveränderlich: drei Versuche default, exponentieller Backoff ohne Jitter, Basis 60 und Maximum 3.600 Sekunden. Barriers speichern einen exakten Snapshot aus WorkItem und ClaimGeneration; Lease-Ablauf löst ihn nicht. Gleichpriorisierte Barriers dürfen parallel laufen, andere Gruppen bleiben frei. |
| Alternativen | Automatische Fehlerklassifikation, dynamische statt persistierter Wartemenge, präemptives Beenden laufender Arbeit, globale Queue-Sperren über die gesamte Arbeitsdauer und ein separater Retry-Provider wurden verworfen. |
| Betroffene Verträge | `WORK_QUEUE_MODULE_DESIGN.md`, `TC-2026-020`, `TC-2026-048`, `.ai/BACKLOG.md`, `toolbelt.core.work-queue` |

## DEC-2026-032: Persistierte kooperative Execution-Cancellation

| Feld | Wert |
|---|---|
| Datum | 2026-09-11 |
| Status | accepted |
| Entscheidung | W6d führt `toolbelt.core.execution-cancel` 1.0.0 als persistenten, irreversiblen Cancellation-Indikator je `ExecutionId` ein. Worker prüfen den Indikator kooperativ und entscheiden selbst über ihren kontrollierten Ausgang. |
| Begründung | Ein portabler T-SQL-Kern kann laufende Fremdarbeit nicht sicher beenden. Ein persistiertes Signal erlaubt geordnetes Reagieren ohne Session-Reuse-, Rollback- oder Berechtigungsrisiko eines globalen Abbruchs. |
| Scope | `TC-2026-018`, ExecutionCancellation-Persistenz, Status-TVF, Skalurfunktion, Anforderungs-USP, Lifecycle und Contract-Tests. |
| Auswirkungen | Die Anforderung akzeptiert keine aktive Caller-Transaktion, damit ihr Commit nicht später zurückgerollt wird. Sie verändert keine Work-Queue-Zeile, führt kein `KILL` aus und enthält keine automatische Recovery. Öffentlicher Status zeigt nur ID, Flag und UTC-Zeit. |
| Alternativen | Queue-only-Sperre, sofortiges `KILL`, provider-spezifische Abbrüche und eine automatische Terminalisierung oder Retry-Mutation wurden verworfen. |
| Betroffene Verträge | `EXECUTION_CANCELLATION_MODULE_DESIGN.md`, `TC-2026-018`, `.ai/BACKLOG.md`, `toolbelt.core.execution-cancel` |

## DEC-2026-033: Gemeinsamer SAFE-JSON-Kern und gebundener achtteiliger Lifecycle

| Feld | Wert |
|---|---|
| Datum | 2026-10-03 |
| Status | accepted |
| Entscheidung | Die einzeln freigegebenen JSON-Aggregate und die vier bestehenden Konstruktor-USPs verwenden in Version 1.2.0 einen gemeinsamen SAFE-CLR-Kern mit einer internen Bridge. Der Lifecycle umfasst fünf Procedure-Slots, eine CLR-TVF, zwei Aggregate und deren gemeinsame Assembly. |
| Begründung | Gemeinsame Literal-, Unicode- und Budgetregeln vermeiden konkurrierende Parser. Die zusätzlich einzeln bestätigten Lifecyclegrenzen verlangen exakt typisierte Assemblymarker, unabhängig qualifizierte bekannte Binarybytes und kohärente vorhandene Eigentümer. |
| Scope | Ausschließlich `toolbelt.json.constructors` 1.2.0 und die im [JSON-CLR-Migrationsvertrag](JSON_CLR_MIGRATION_CONTRACT.md) festgelegten Bindings, Profile, Tiefengrenzen und Migrationsrouten. |
| Auswirkungen | Bestehende öffentliche USP-Signaturen und globale Budgets bleiben erhalten. Assemblytrust erfordert ein separates exaktes Hash-Opt-in; unbekannte oder inkohärente Zustände blockieren. Keine automatische Rechtevergabe oder Ownerreparatur. Teilnachweise ergeben keine vollständige Produkt- oder Releasequalifikation. |
| Alternativen | Getrennte SQL-/CLR-Parser, ungeprüfte Binaryadoption und automatische Owner-/Rechtereparatur sind ausgeschlossen. |
| Betroffene Verträge | `JSON_CLR_MIGRATION_CONTRACT.md`, `JSON_GROUP_CONSTRUCTORS_CONTRACT.md`, `KNOWN_CLR_ARTIFACTS.json`, `.ai/BACKLOG.md`, `toolbelt.json.constructors` |

## DEC-2026-034: Risikobasierte Performance-Evidenz

| Feld | Wert |
|---|---|
| Datum | 2026-10-10 |
| Status | superseded durch [DEC-2026-036](#dec-2026-036-verpflichtende-lasttests-und-optionale-laufzeitmessungen); ursprünglicher Vertrag bleibt historisch erhalten |
| Entscheidung | Performanceprüfungen wiederholen SQL-Versionen oder Plattformen nur bei einem relevanten abweichenden Programmzweig, Provider oder erwarteten Engineunterschied. Andernfalls genügt ein dokumentiertes repräsentatives Ziel; für ResultTable, Base64 und Generate Series ist dies SQL Server 2025 mit Compatibility Level 170 auf einem reservierten oder ausreichend skalierten, lastkontrollierten Ziel. |
| Begründung | Betriebssystem und Produktversion allein ergeben keinen aussagekräftigen Performancevergleich. Eine Vollmatrix ohne technischen Unterschied erhöht Kosten und Umgebungsrauschen, ohne die Regressionserkenntnis zu verbessern. |
| Scope | Ausschließlich Performance-Evidenz; funktionale Support- und Providerprüfungen behalten ihre eigene risikobasierte Matrix. |
| Auswirkungen | Die drei Workloads verwenden drei Batches mit Warm-up und fünf Samples. Eine flüchtige Kalibrierung und ein unabhängiger Bestätigungslauf prüfen Wiederholbarkeit auf demselben Ziel. Ein geteilter Entwicklungs- oder Testhost ist keine zulässige Performancebasis; Docker ist nur auf einem reservierten oder ausreichend skalierten, lastkontrollierten Host zulässig. Messwerte, Baselines und Runnerdaten werden nicht als Repository-Evidenz gespeichert. Das ist keine allgemeine oder plattformübergreifende Leistungszusage. |
| Alternativen | Vollständige Windows-/Linux- und 2019-/2022-/2025-Performance-Matrix sowie ein reiner Stabilitätslauf ohne Bestätigung wurden nicht gewählt. |
| Betroffene Verträge | `TEST_AND_VALIDATION_POLICY.md`, `.ai/BACKLOG.md`, `toolbelt.core.result-table`, `toolbelt.conversion.base64`, `toolbelt.core.generate-series` |

## Datierter Entscheidungsstand 2026-10-05: sechs strikte Safe-Cast-TVFs

RelatedReference: `RI-2026-076`. Funktionsbezogene Benutzerentscheidung nach
Besprechung in PR170; keine neue finale Sequenz-ID.

Status: accepted; implementiert, teilweise validiert und unveröffentlicht.
Finale begrenzte Linux2019/latest-CL150- und Windows2025/CU8-CL170-Adapter
bestanden local/central/Consumer; Details und frühere Fehlläufe stehen im
[Evidenzprotokoll](../../Modules/toolbelt.conversion.safe-cast/Tests/README.md).
Entscheidung: genau sechs schemagebundene Inline-T-SQL-TVFs für bigint,
decimal(38,18), date, datetime2(7), bit und uniqueidentifier. Je Text/MaxInputBytes
und genau eine Value/Status/ErrorCode-Zeile. Der Benutzer antwortete auf die
konkrete Frage ausdrücklich „Diese sechs Funktionen freigegeben“, einschließlich
8192-Byte-Deckel, strikter ASCII-/ISO-Lexik, exaktem Bereich vor LOSSY und
INVALID_ARGUMENT/PARAMETER. Der [Safe-Cast-Vertrag](SAFE_CAST_CONTRACT.md)
ist kanonisch; keine erneute Freigabefrage für diese Umsetzung.

Begründung: Native TRY_CONVERT bleibt sichere Primitive, beweist aber weder
strikte Lexik noch Verlustfreiheit oder mathematischen Bereich vor Rundung.
Die relationale Implementierung vermeidet zusätzliche Provider-/Trustgrenzen
und funktioniert im APPLY. Auswirkungen: feste Zieltypen und stabile Codes,
keine Localeformate, stillen Rundungen, GUID-Suffixe oder Zeitzoneninterpretation.
Alternativen: alleiniger nativer Cast, Scalar-UDF-/MSTVF-Wrapper, dynamische
Precision/Scale und CLR sind für diese sechs APIs nicht erforderlich.
Betroffene Verträge: SAFE_CAST_CONTRACT.md, DEPLOYMENT_MODEL.md,
TSQL_ENGINEERING.md, toolbelt.conversion.safe-cast, .ai/BACKLOG.md.
Keine Pointer-, Schema-, zusätzliche öffentliche API oder Veröffentlichung.

## Datierter Entscheidungsstand 2026-10-04: V3 Map-/FK-Vorschau

RelatedReference: `TC-2026-044`. Datierte Revision der bestehenden funktionsbezogenen Entscheidung; keine neue Referenzfamilie oder finale Sequenz-ID.

Einzeln freigegebene Map-/FK-Erweiterung der vorhandenen Script-only-Prozedur; Benutzerentscheidung2026-10-03 zu Positionsbruch sowie FK-Property-/Zustandsgrenzen. [Vertrag](TABLE_CLONE_WAVE2_CONTRACT.md). Exakte2048Countdefinition und getrennte1024/128/64/2MiB-Grenzen dort; keine Provider-/Rights-/Execute-API. Neue Native-/CI-Qualifikation offen.

Status: accepted; Sourceimplementierung, neue Runtime-/CI-Qualifikation offen. Alternative eigenständiger MultiTable-Wrapper oder SMO/CLR verworfen: duplizierter W1-Kern beziehungsweise zusätzlicher Provider. Auswirkungen: dokumentierter Positionsbruch; W1 benannte Aufrufe fachlich unverändert, keine Ownership-/DDL-Ausführung.

## Datierter Entscheidungsstand 2026-10-04: begrenzte Tabellenklon-Datenkopie

RelatedReference: `TC-2026-044`. Revision der bereits funktionsbezogen freigegebenen Clone-Folgefunktion; keine neue finale Sequenzreferenz.

Status: accepted; neue Copy-Runtime und Head-CI noch nicht ausgeführt.
Entscheidung: SameDB-Datenkopie mit expliziter Map, leeren formgleichen Zielen, KEEP/REGENERATE und vorhandenem SNAPSHOT/SERIALIZABLE. Gemeinsame interne FK-Herleitung, neun öffentliche Parameter/fünf Summaryfelder, vier Lifecycle-Slots. Die einzeln bestätigten100000-Zeilen-/16MiB- und Identity-Rollback-/nachgelagertenFK-/DDL-Vollsichtgrenzen sind kanonisch im [Datenkopievertrag](TABLE_CLONE_DATA_COPY_CONTRACT.md) und Backlog dokumentiert.
Begründung: Bestehende Tabellenform und FK-Renderer vermeiden doppelte Fachlogik; eigene Transaktion koppelt Daten, fehlende FKs und ResultTable-Ausgabe. Vorhandene passende Constraints bleiben erhalten. Keine freie SQL-Ausführung, automatische Konfiguration oder Rechtevergabe.
Alternativen: Merge/Upsert, CrossDB-Transport, heimliches Constraintdisable, RESEED und zusätzliche öffentliche FK-Helper sind ausgeschlossen. Identity-Zähler und externe Commit-/Netzwerkeffekte bleiben ausdrücklich außerhalb umfassender Rollbackzusagen.
Betroffene Verträge: TABLE_CLONE_DATA_COPY_CONTRACT.md, TABLE_CLONE_WAVE2_CONTRACT.md, TABLE_CLONE_EXECUTE_CONTRACT.md, USP_CONTRACT.md, toolbelt.metadata.table-clone, .ai/BACKLOG.md.

## Datierter Entscheidungsstand 2026-10-04: zentral gesteuerte Queue-Worker

RelatedReference: `DEC-2026-031`, `TC-2026-020`, `TC-2026-048`. Funktionsbezogene Weiterentwicklung; keine neue finale Sequenzreferenz.

Status: accepted; Implementierung aktiv, neue Runtimequalifikation und Head-CI offen. Die ausdrücklichen Einzelentscheidungen des Benutzers sind in [.ai/BACKLOG.md](../../.ai/BACKLOG.md) dokumentiert.

Entscheidung: Die vorhandene externe Windows-/Linux-Ausführung erhält ein explizites Managed-Opt-in mit zentraler SQL-Steuerung, zur Laufzeit veränderbaren globalen und lokalen Parallelitätsbudgets sowie konfigurierbaren Heartbeatintervallen mit Defaults 15/60 Sekunden. `toolbelt.core.worker-control` hängt von Work Queue 2.1 ab; die Queue enthält nur das neutrale Integrationsgate. Spätere SQL Server Agent-, Service Broker- und SSIS-Provider bleiben außerhalb dieser Welle.

Begründung: Ein gemeinsamer persistierter Admission- und Dispositionskern verhindert unterschiedliche Budget-, Stopp- und Retryregeln je Provider. Ein dauerhafter Stop/Hold sperrt automatische Neuverarbeitung, bevor der konkrete Provider die tatsächliche Ausführung abbricht. Erst nach belegtem Ende und Rollback wird der Slot freigegeben; bestätigte Commits bleiben abgeschlossen, unbekannte Ausgänge belegt.

Auswirkungen: Managed-Aktivierung ist claimfrei, direkte Legacy-Claims sind danach gesperrt. Ein Einzelstopp betrifft genau eine Verarbeitung; ein Gruppenstopp pausiert ausgewählte stabile Workeridentitäten. Wiederholung verlangt eine explizite Hold-Freigabe. Eine separate Kontrollausführung kann die exakt gebundene Command-Instanz abbrechen. Sessionbindung, Transaktionswitness und Dispositionsgate liefern den SQL-Endnachweis; daraus folgt keine harte Abbruchfrist oder allgemeine Rollbackzusage für externe Systeme.

Alternativen: Feste Parallelität acht, lokale unabhängige Budgets, automatische Retryfreigabe nach Stopp, Wiederaufnahme unbekannter Ausgänge und `KILL` über eine gespeicherte Sessionnummer werden verworfen. Das kontrollierte Deaktivieren drainiert bestehende Arbeit und erfordert einen konsistenten Endzustand.

Betroffene Verträge: [Worker-Control-Vertrag](WORKER_CONTROL_CONTRACT.md), [bestehender Providervertrag](EXTERNAL_QUEUE_WORKER_CONTRACT.md), `USP_CONTRACT.md`, `toolbelt.core.work-queue`, `toolbelt.core.worker-control`, `Workers/ExternalQueue`.

## Datierter Entscheidungsstand 2026-10-05: Schema und physisch gemeinsamer JSON-Core

RelatedReference: `RI-2026-048`, `DEC-2026-033`. Funktionsbezogene Fortentwicklung;
keine neue finale Sequenzreferenz und keine rückwirkende Umschreibung von 1.2.

Status: accepted; implementiert, teilweise validiert und unveröffentlicht.
Offline-Framework/IL/bytegleiche Projekte und begrenzte native Core-/Schema-
und genuine Constructor1.2→1.3-Läufe auf Linux2019 CL150 und Windows2025 CU8
CL170 local/central bestanden; aktuelle Head-CI und übrige Matrix offen.

Entscheidung: Die ausdrückliche Antwort „Diese Schema-/Kern-Welle freigegeben“
auf die konkrete [PR175-Vorlage](https://github.com/gecompat/SQL_Server_Toolbelt/pull/175)
autorisiert `USP_ValidateJsonSchema` im begrenzten Profil `toolbelt-2020-12-v1`,
zehn Ergebnisfelder, lokale nichtrekursive Referenzen, exakte Zahlen und Unicode,
globales Arbeitsbudget und vollständige Evaluation trotz Diagnosekürzung.
Der gemeinsame Parser wird physisch nach `Toolbelt_JsonCore` ausgelagert.
Constructor1.3 referenziert diesen Core bei unveränderten acht SQL-Slots;
Schema verwendet eine eigene SAFE-Assembly mit einem internen CLR-TVF-Slot.

Begründung: Ein physischer Parser verhindert divergierende Syntax- und
Unicodeimplementierungen. Ein vollständiger Schemaort- und Graphpreflight
verhindert ein scheinbar gültiges Urteil bei unbenutzten unbekannten Keywords
oder Referenzzyklen. LIMIT ersetzt jedes unvollständige Boolurteil durch NULL.

Scope und Auswirkungen: Core als technische SameDB-Dependency ohne öffentliche
SQL-Funktion; getrennte Core-, Constructor- und Schemalifecycles. Coreabbau und
Ersetzung blockieren bei verbliebenen Assemblykonsumenten. Bekanntes Constructor1.2
wird explizit migriert; Schema installiert oder repariert keine Dependency.
Neue Binaries und ihre Buildclosure werden separat qualifiziert. Neue exakte
Trusthashes wurden anschließend für die notwendigen begrenzten Tests dieser
Welle ausdrücklich vorab freigegeben; keine erneuten Schemahashfragen.
Keine Infrastruktur-, Owner-,
Rechte-, TRUSTWORTHY- oder Releasefreigabe.

Alternativen: Eine zweite Parserkopie, ein Schemaadapter gegen die unmodifizierte
1.2-Assembly und ein kompletter Constructor-Slotneubau wurden anhand der
Assembly-/Foreignbindinggrenze in PR175 verworfen. Volles Draftprofil,
externe Referenzen und eine neue öffentliche Core-API bleiben ausgeschlossen.

Betroffene Verträge: [Schema-/Core-Vertrag](JSON_SCHEMA_CONTRACT.md),
`JSON_CLR_MIGRATION_CONTRACT.md`, `USP_CONTRACT.md`,
`toolbelt.json.core`, `toolbelt.json.constructors`, `toolbelt.json.schema`.

Native Präzisierung2026-10-05: SQL6282 schließt den zuerst versuchten
ALTER-Pfad mit neuer Core-Referenz aus. Der atomare Austausch betrifft nur
drei eigene CLR-Slots/Assembly; fünf Procedureidentitäten und Rechte bleiben
erhalten. Direkte CLR-/Assemblyrechte, explizite CLR-Owner und Zusatzmetadaten
blockieren vor Mutation, kein GRANT oder Ownerrepair. Post-DROP-Rollback,
Annotationserhalt, genuine Migration und vier aktuelle Constructor-Fixtures
bestanden auf beiden genannten Zielen local/central. Der verworfene komplette
achtteilige Slotneubau bleibt ausgeschlossen. Frühere Fehler und historische
1.2-Verträge bleiben unverändert; [native Evidenz](../../Modules/toolbelt.json.schema/Tests/NATIVE_EVIDENCE.md).

## Datierter Entscheidungsstand2026-10-05: Foundation1.19 und sichere CI-Ablösung

Stabile Feature-Referenzen: `ci-supersession-and-integration-queue` und
`session-lifecycle-management`; keine neue finale Sequenz-ID.
Status: accepted im Rahmen des ausdrücklichen Integrationsprüfungsauftrags.

Entscheidung: Exakte Foundation1.19-Quelle und bestehende Auswahl integrieren;
24 mutierende Runtime-/Qualification-Workflows erhalten laufende Prüfungen.
Die bestehende CI-Gruppierung, exakte Headabnahme und rein lesende
Dokumentationsablösung bleiben bestehen. Sessionsteuerung verwendet nur
belegte Metadaten und unreconciled Delta plus dauerhafte Referenzen.

Begründung: Bestehende EXIT-Traps belegen keine Bereinigung nach harter
Unterbrechung. Unbekannte Sessionmetriken rechtfertigen keine erfundenen
Thresholds oder automatische Clientrotation. Scope sind Foundationintegration,
Projekt-Arbeitsregeln und CI-Abbruchkonfiguration; kein SQL-Produktvertrag.
Auswirkungen: Laufende Runtimeprüfungen können länger bestehen bleiben;
abgebrochene Läufe bleiben unvalidiert. Keine neue Ausführungsautorität.
Alternativen: Hard-Interrupt-Cancellation erst nach belegtem Recoveryvertrag;
Merge Queue, konkrete Sessionthresholds und automatische Nachfolgesitzungen
bleiben optionale spätere Entscheidungen.
Betroffene Verträge: `.ai/WORKING_RULES.md`, Foundation-Continuity und
AI-Work, Workflow-Concurrency. [Bewertung und Nachweise](FOUNDATION_1_19_INTEGRATION.md).

## Datierter Entscheidungsstand 2026-10-07: Modulveröffentlichungen nachvollziehbar abnehmen

Status: accepted im Rahmen des ausdrücklichen Benutzerauftrags zur
Veröffentlichungs-, Herkunfts- und Rückmeldetransparenz; keine neue finale
Sequenzreferenz oder Änderung bestehender Identitäten.

Entscheidung: Das [Modulmodell](MODULE_AND_DEPENDENCY_MODEL.md#öffentlicher-veröffentlichungsnachweis)
ist die kanonische Quelle für den Veröffentlichungsvertrag. Ein modulreferenzierter
JSON-Datensatz verbindet Version, Quellcommit, Scopequalifikation, konkrete
Benutzerfreigabe und GitHub-Release. Lokale Strukturprüfung und ausdrücklich
gewählte externe GET-Abnahme bleiben getrennte Ergebnisse. Vorhandene
Build-/Trust-Manifeste und SHA2-512-Verträge bleiben eigenständig.

Begründung: Ein zulässiger Statuswert oder ein erzeugtes CI-Artefakt belegt
keine öffentliche Veröffentlichung. Versionen allein identifizieren veränderte
unveröffentlichte Quellen nicht eindeutig. Freiwillige synthetische
Fehlermeldungen ergänzen die vorhandene Testevidenz.

Scope/Auswirkungen: Governance, Dokumentationsvalidator und vorhandenes
Fehlerformular; alle vorhandenen Modulstände bleiben unveröffentlicht.
Fachlicher Review prüft Vollständigkeit und Bedeutung von Qualifikationen und
Freigabe. Die API-Abnahme bestätigt Referenzen und GitHub-Digests, führt keine
SQL-Tests aus und erteilt keine Veröffentlichungs- oder Trustautorität.

Alternativen: Reine Status-/Linkprüfung wäre unzureichend; verpflichtender
Netzwerkzugriff bei jedem Dokumentationslauf wäre unnötig. Ein neuer
Release-Orchestrator, Paketquelle, Telemetrie und neue SQL-API sind außerhalb
des Auftrags. Betroffene Verträge: Modulmodell, Definition of Done,
`publication_record`, Dokumentationsvalidator, CONTRIBUTING und Fehlerformular.

## Datierter Entscheidungsstand 2026-10-09: Foundation1.20 und endliche Verarbeitung

Stabile Feature-Referenz: `bounded-processing-efficiency`; keine neue finale
Sequenz-ID. Status:accepted. Autor:Codex. Grundlage ist der ausdrückliche
Benutzerauftrag zum Foundation-Upgrade und zur Bereinigung unwirtschaftlicher
projektinterner Regeln; die sonstige Entwicklungspause bleibt erhalten.

Entscheidung: Foundation1.20 aus dem exakten Commit
`39ae5c534bb0cf78046485754ed1be7867bf9534` integrieren, bestehende optionale
Auswahl erhalten und den Preflight auf Erstlektüre je Scope plus geprüfte
Wiederverwendung verfügbarer Sessionanalysen umstellen. Mechanische Prüfungen
bleiben lokal; zusätzliche Reviews benötigen eine offene semantische Frage.
Ein gemeinsamer endlicher Scope-/Agentenrahmen umfasst Koordination und Retries.

Begründung: Wiederholte Volllektüre und Reader-/Receipt-/PR-Reviewketten sparen
keine zusätzliche Unsicherheit ein. Unbekannte Tokenwerte und fehlende
Discovery-/Analyseinformationen dürfen nicht durch Behauptungen ersetzt werden.
Auswirkungen: weniger unveränderte Modelllektüre, gezielte transitive Invalidierung,
ereignisbasierte Handoffs; erforderliche unabhängige Reviews, Datenschutz,
SQL-/Lab-Ownership, Lizenzschutz, Pflichtchecks und Pausen bleiben wirksam.
Alternativen: Versionswechsel allein oder bloßes `PROJECT_STRONGER` ohne
Effizienzprüfung verworfen; persistenter Cache bleibt optional, keine neue
Plannerpflicht oder zusätzliche automatische Entwicklungswelle.
Scope/betroffene Verträge: AGENTS-Bridge, `.ai/WORKING_RULES.md`, Kostenrichtlinie,
Foundationmanifest/Provenienz, Dokumentationsvalidator und Repo-Map.
[Vollständige Bewertung und Verfahren](FOUNDATION_1_20_INTEGRATION.md).

## Datierter Entscheidungsstand 2026-10-09: Foundation1.21 und begründete Testzyklen

Stabile Feature-Referenzen: `processing-overhead-assessment` und
`layered-validation`; keine neue finale Sequenz-ID. Status: accepted.
Autor: Codex. Grundlage ist der ausdrückliche Benutzerauftrag zum neuen
Foundationstand und zur Bereinigung sinnloser Testzyklen.

Entscheidung: Foundation1.21 aus dem exakten Commit
`d720db4f2f0d043756a958d5195d0e62090b1c8f` bei erhaltener Auswahl und sieben
Overrides integrieren. Begrenzte Prozessänderungen wählen ihre Verbraucher;
globale Verträge, Selektor-/Registryänderungen und unbekannter Impact behalten
Vollaudit. Zwei gleiche Dokumentationsjob-Validatoraufrufe entfallen;
Werkzeug-Selbsttests werden von der laufenden Inputprüfung getrennt.
14 breite Modulworkflowfilter schließen bekannte reine Dokumentation aus.
Der allgemeine Entscheidungskatalog löst keine Work-Type-SQL-Matrix aus.
Phonetik-Pushprüfungen werden auf `main` begrenzt, damit Branch-Push und PR
nicht dieselbe Qualifikation doppelt starten.

Begründung: Fachfremde Tests, gleiche Checks im gleichen Job und zusätzliche
Modellanalysen grüner Logs liefern keinen neuen Nachweis. Diagnose und
begrenzte Integration benötigen andere Abschlusskriterien als volle
Support-/Releasequalifikation. Auswirkungen: weniger unnötige Testtrigger,
begründete Wiederholung und lokale begrenzte Logauswertung; aktuelle Head-CI,
negative Orakel, Qualification-/Cleanup-/Securitygates bleiben erhalten.

Alternativen: bloßes Kopieren, globale Gateentfernung, neue Reader-/Receiptketten
und Kürzung der deklarierten Supportmatrix verworfen. Scope: Foundation,
Projektregeln, tatsächliche Testselektoren/Workflows und Offline-Regressionen.
Keine Produktimplementierung, SQL-Testausführung oder automatische Fortsetzung.
[Vollständige Bewertung, Ausnahmen und Nachweise](FOUNDATION_1_21_INTEGRATION.md).


## DEC-2026-035: Explizit freigegebene Security-Härtung

| Feld | Wert |
|---|---|
| Datum | 2026-10-15 |
| Status | accepted; ausdrücklich vom Benutzer zur Implementierung freigegeben |
| Entscheidung | Die 25 einzeln besprochenen Securityverträge werden in vier geordneten Wellen umgesetzt. Windows Filesystem verwendet wegen handlegebundener P/Invoke-Operationen UNSAFE; dies ersetzt den betreffenden Teil von DEC-2026-024. Work-Type-Policy und ServiceAccount-Rolle/Root sind explizit zu konfigurieren. Ressourcenlimits erhalten die freigegebenen Status-/NULL-/Leermengenabbildungen. |
| Begründung | Autorität muss am tatsächlichen Caller und Datei-I/O an gehaltenen Objekten hängen. Arbeit und Ausgabe brauchen vorgezogene feste Grenzen. Mehrfaches Nachschlagen von Pfaden und bloße Metadatensicht reichen nicht. |
| Alternativen | Privilegierter Pfadfallback, automatischer Grant, Abschalten von strict security, TRUSTWORTHY ON und Lab-Zertifikatsausnahme verworfen. Kein genereller Wechsel anderer CLR-Module auf UNSAFE. |
| Auswirkungen | Bestehende Installationen müssen Policies, Rollen/Rootflag und den neuen Releasehash ausdrücklich konfigurieren. Legacy-Series nur für trusted Principals. Der aktuelle Labvertrag wird bis zur externen CA-/Hostnamebereitstellung gesperrt. Keine Infrastruktur-/Truststoreverwaltung durch Toolbelt. |
| Vertrag und Nachweise | [SECURITY_HARDENING_2026_10.md](SECURITY_HARDENING_2026_10.md); Status bleibt nach tatsächlich ausgeführten Teilprüfungen begrenzt, Integration/Head-CI und Cloudabschluss getrennt. |

**Änderung vom 2026-10-16 – Codex, ausdrückliche Benutzerklarstellung:**
Die pauschale TLS-Sperre für unabhängige fachliche Labtests ist ersetzt.
`TestPurpose=Functional` übernimmt den schema-validierten Labtransport mit
Encrypt=True und dessen booleschem Trustwert. `AuthenticatedTls` verlangt
weiterhin TrustServerCertificate=False. Ein fachliches PASS ersetzt keinen
TLS-Nachweis. Der Benutzer begründet dies damit, dass eine vom Transport
unabhängige Funktion mit dem vorhandenen Labzugang testbar bleiben muss.
Dies ändert ausschließlich die Testvoraussetzung für SC-045; Zertifikats-/
Truststoreverwaltung, automatische Fallbacks und andere Securityverträge
werden dadurch nicht freigegeben. Maßgeblich sind [AGENTS.md](../../AGENTS.md#fachliche-tests-und-transportqualifikation)
und die [Testregel](../Standards/TEST_AND_VALIDATION_POLICY.md#fachtests-und-verbindungstransport).


## DEC-2026-036: Verpflichtende Lasttests und optionale Laufzeitmessungen

| Feld | Wert |
|---|---|
| Datum | 2026-10-19 |
| Status | accepted; ausdrücklicher unmittelbarer Benutzerauftrag |
| Entscheidung | Für ResultTable, Base64 und Generate Series bleiben große synthetische Lastfälle mit Ergebnisprüfung Pflicht. Laufzeitmessungen einschließlich Kalibrierung, Stabilitäts- und Bestätigungsvergleich sind optionale ergänzende Evidenz und keine Voraussetzung für `validated` oder eine Releaseentscheidung. Diese Entscheidung ersetzt DEC-2026-034. |
| Begründung | Die bisherigen Zeitvergleiche derselben Implementierung belegen Wiederholbarkeit auf einem Ziel, aber keine vereinbarte absolute Laufzeit oder Verbesserung gegenüber einer Vorgängerversion. Korrekte Ergebnisse bei der vereinbarten Last sind das verpflichtende Funktionskriterium. |
| Scope | Ausschließlich die drei abgegrenzten Lastfälle und ihre Abnahme; öffentliche SQL-Verträge, funktionale Supportmatrix, Security, Cleanup und Veröffentlichung bleiben unverändert. |
| Auswirkungen | Drei getrennte `Load.Contract.sql` werden auf dem repräsentativen SQL-2025-/CL170-Ziel automatisch ohne Opt-in ausgeführt. Ein vorhandenes schema-valides Labziel genügt; für diese Ergebnisprüfungen ist keine Lastkontrolle nötig. Optionale Zeitmessungen behalten ihre bisherigen Stabilitäts-, Kalibrierungs- und Regressionsgrenzen und die Anforderung eines kontrollierten Messhosts. Nicht ausgeführte Zeitmessungen werden weiterhin ehrlich ausgewiesen. |
| Alternativen | Reservierten Host für jede Validierung verlangen, Pflicht-Lastfälle ersatzlos streichen oder Instabilität als Performance-PASS werten wurden verworfen. |
| Autorisierung | Der Benutzer beauftragte ausdrücklich die Vertragsänderung, die offenen Lasttests im vorhandenen Lab und einen PR. Keine neue fachliche Funktion und keine Veröffentlichungsfreigabe. |
| Betroffene Verträge | [Testregel](../Standards/TEST_AND_VALIDATION_POLICY.md), [Gatebericht](../../Tests/V0C_RELEASE_GATE_STATUS.md), Modulmanifeste, Contract-Matrizen und die drei bestehenden CI-Adapter. |

Prüfaufwand: ein Arbeitspaket, ein PR, ein Implementierungsverantwortlicher,
keine zusätzlichen Agenten oder Workflows. Drei geänderte Moduladapter werden
auf einem explizit ausgewählten bereiten Labziel qualifiziert; die bereits
grüne 66-Läufe-Fachmatrix wird nicht erneut ausgeführt. Bestehende Runtime-CI
und aktuelle Head-Prüfungen bleiben erhalten. Die Pflichtfälle laufen einmal
auf SQL 2025/CL170; die optionalen 3-Batch-/5-Sample-Zeitreihen werden dafür
nicht ausgeführt. Ein vollständiger Dokumentationsaudit ist wegen des globalen
Abnahmevertrags und der gekoppelten Statuspflege erforderlich. Runtime-Logs
bleiben lokal, Repository/PR enthalten nur abstrahierte Ergebnisse. Keine
neue Reviewkette, Telemetrie oder behauptete Token-/Kostenmessung.
