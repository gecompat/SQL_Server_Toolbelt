# Test- und Validierungsrichtlinie

## Grundsatz

Plan, Dokumentation, Manifest und vorhandener Testcode sind kein Runtime-Nachweis. Nur tatsächlich ausgeführte und erfolgreiche Prüfungen dürfen als `validated` oder bestanden bezeichnet werden.

## Validierungsstatus

Der `validation_status` ist von Implementierungs- und Release-Status getrennt.

| Wert | Bedeutung |
|---|---|
| `validated` | tatsächlich ausgeführt und erfolgreich |
| `partially validated` | dokumentierter Teil des Pflichtscopes erfolgreich; weitere Pflichtkombinationen offen |
| `not executed` | vorgesehen, aber nicht ausgeführt |
| `not applicable` | im konkreten Scope fachlich nicht anwendbar und begründet |
| `failed` | ausgeführt und fehlgeschlagen; Blocker dokumentiert |

## Foundation-Validierungsebenen

Die Toolbelt-Statuswerte bleiben autoritativ und werden in drei voneinander getrennten Evidenzbereichen verwendet:

- `FOUNDATION_INTEGRITY`: installierte Foundation-Struktur, Provenienz, Discovery und deterministische Foundation-Verträge;
- `PROJECT_SEMANTIC`: Toolbelt-Regeln, Architektur, Dokumentationsverträge, Repo-Map, statische Konsistenz und projektspezifische Overrides;
- `RUNTIME_EMPIRICAL`: Builds, SQL-Runtime-, Integrations-, Plattform- und manuelle Prüfungen.

`validated` und `not executed` behalten die reservierten Foundation-Bedeutungen. `partially validated`, `not applicable` und `failed` sind dokumentierte projektspezifische Erweiterungen. `pending manual validation` darf verwendet werden, wenn ein ausführbarer manueller Plan gemäß `.ai/foundation/VALIDATION_POLICY.md` vorliegt. Eine erfolgreiche `FOUNDATION_INTEGRITY`-Prüfung ist kein Nachweis für `PROJECT_SEMANTIC` oder `RUNTIME_EMPIRICAL`.

## Evidenz für ausgeführte Prüfungen

Mindestens dokumentieren:

- Befehl, Tool oder Workflow;
- geprüften Scope;
- SQL-Server-Version, Plattform und Provider;
- Ergebnis;
- Ausführungsdatum;
- bekannte Einschränkungen.

Ein agenteninterner Review ohne reproduzierbare Ausgabe ist kein CI- oder Runtime-Nachweis.

## Fachtests und Verbindungstransport

Benutzerklarstellung vom 2026-10-16: Ein für die Funktion unabhängiger
Transportaspekt darf ihre fachliche Prüfung nicht blockieren. Labtests
verwenden standardmäßig `TestPurpose=Functional` und übernehmen den
schema-validierten booleschen TrustServerCertificate-Wert. Encrypt bleibt
True. Ein Verbindungsfehler löst weder Trustumschaltung noch Providerfallback aus.

`TestPurpose=AuthenticatedTls` verlangt zusätzlich TrustServerCertificate=False.
Es verlangt außerdem den [gebundenen V2-Snapshot](../Architecture/LAB_QUALIFIED_TLS_CONSUMER.md)
mit explizitem Labmodul-/Run-/Instanz-/StateRoot-Kontext. Ein Schemaoverride
allein qualifiziert keinen Export. Die gemeinsame native Abnahme bleibt
von synthetischen Consumer- und Transportflagsprüfungen getrennt.
Dieser Modus ist für Serveridentitäts-/Zertifikatsprüfungen und konkrete davon
abhängige Funktionsverträge erforderlich. Ein erfolgreicher Fachtest mit
Trust-Override qualifiziert keine authentifizierte TLS-Verbindung; deren
Nachweis wird separat geführt. Die fachliche Freigabe gilt ausschließlich
für den geprüften Funktions-, Parameter- und Sessionkontext. Ändert ein anderer
Verbindungsmodus diesen Vertrag, erhält er eigene Tests.

## API- und Contract-Tests

Für alle öffentlichen Objekte:

- Name, Schema, Typ und Sichtbarkeit;
- Parameter, Datentypen, Reihenfolge und Defaults;
- Resultset-Spalten, Datentypen, Nullability und Collation;
- Fehler- und Berechtigungsvertrag;
- Beispiele gegen den tatsächlichen Vertrag.

Für USPs zusätzlich:

- `@Hilfe = 1` einschließlich Help-Resultset;
- `@Debug` ausschließlich als Messages;
- `@ResultTable IS NULL` mit genau einem fachlichen Resultset;
- `@ResultTable` ohne fachliches `SELECT`;
- beliebiger Dummyspaltenname und -typ;
- alle vier `@KeepData`-Konstellationen;
- passendes Schema mit zusätzlichen Indizes;
- blockierende Dependencies vor der ersten Mutation;
- verschachtelte Aufrufe ohne generisches `INSERT ... EXEC`;
- kein Seiteneffekt im Help-Modus.

## Lifecycle-Tests

- Erstinstallation auf sauberem Zustand;
- kontrollierte Wiederholung beziehungsweise Idempotenz;
- Upgrade von jeder unterstützten Vorgängerversion;
- Uninstall und Dependency-Schutz;
- fehlerhafter Preflight ohne Teilmutation;
- Recovery und Cleanup nach begonnenem Setup.

## Versions- und Plattformmatrix

Jede tatsächlich unterstützte Kombination wird separat bewertet, sofern sie
einen abweichenden Programmzweig aktiviert, einen anderen Provider verwendet
oder ein relevantes abweichendes Engineverhalten zu erwarten ist. Ohne einen
solchen Unterschied darf ein repräsentatives Ziel die gemeinsame Ausführung
abdecken; Version oder Betriebssystem allein erzwingen keine Wiederholung.

- SQL Server 2019, 2022 und 2025;
- Windows und Linux;
- lokale und zentrale Installation;
- jeder alternative Provider;
- Cross-database-Aufruf, wenn unterstützt.

Ein erfolgreicher Test auf einer Version, Plattform oder einem Provider beweist keine andere Kombination, außer die dokumentierte Risikobewertung weist die gemeinsame Ausführung ohne abweichenden Zweig, Provider oder erwarteten Engineunterschied nach. `not applicable` setzt eine dokumentierte Capability-Entscheidung voraus.

SQL Server 2025 mit CL150 ersetzt insbesondere nicht automatisch eine native
SQL-Server-2019-Prüfung. Engine und Compatibility Level sind getrennte Bindungen.

## Collation- und Datentests

- abweichende Server-, Toolbelt-, Zieldatenbank- und TempDB-Collations;
- mindestens case-insensitive, case-sensitive und BIN2; UTF-8, soweit fachlich relevant;
- deterministische synthetische Daten;
- Randwerte, Fehlerwerte und leere Eingaben;
- keine Produktionsdaten.

## Große Lastfälle mit Ergebnisprüfung

Benutzerentscheidung vom 2026-10-19, [DEC-2026-036](../Architecture/DECISIONS.md#dec-2026-036-verpflichtende-lasttests-und-optionale-laufzeitmessungen):
Für ResultTable, Base64 und Generate Series sind die synthetischen großen
Lastfälle mit fachlichen Ergebnisorakeln Pflicht für `validated`.
Die einmalige repräsentative Ausführung erfolgt auf SQL Server 2025 mit
Compatibility Level 170 im vorhandenen schema-validierten Lab oder in der
bestehenden Runtime-CI. Eine Plattformwiederholung ist nur bei einem relevanten
abweichenden Zweig, Provider oder erwarteten Engineunterschied erforderlich.
Die vorhandene funktionale Supportmatrix bleibt erhalten.

- ResultTable: 100000 Zeilen unverändert über 50 KeepData-Aufrufe, 20 vollständige
  Leerungen mit Indexerhalt und zehn Schemawechsel in beide Richtungen.
- Base64: vollständiger 4-MiB-Roundtrip mit NULL-, Längen- und Inhaltsprüfung.
- Generate Series: exakt zehn Millionen unterschiedliche Werte von 1 bis
  10000000, vollständig serverseitig ausgewertet.

Diese Fälle enthalten keine Zeitmessung, Baseline oder Streuungsgrenze und
benötigen keinen reservierten Messhost. Fehler, Timeouts und fehlgeschlagener
Cleanup bleiben erfolglose beziehungsweise unvollständige Nachweise.
Für diese drei Module sind Laufzeitmessungen optionale zusätzliche Evidenz und blockieren weder
`validated` noch die Releaseentscheidung. Konkrete künftig vereinbarte
Leistungszusagen benötigen einen eigenen Abnahmevertrag.

## Performance-Messungen

Die vorstehende Optionalität gilt ausschließlich für ResultTable, Base64 und
Generate Series gemäß DEC-2026-036. Andere ausdrücklich vereinbarte
modulspezifische Pflicht-Lastfälle und Leistungsnachweise bleiben unverändert.

- vergleichbare Abfrage, Parameter, Daten- und Cache-Zustände;
- Messumgebung und Datenmenge dokumentieren;
- Warm-up-, Parallelitäts- und Hardwareeffekte nennen;
- Einzellauf nicht als allgemeingültigen Benchmark darstellen;
- Ergebnisse als empirisch kennzeichnen.

Ein optional beauftragter Performance-Regressionsvergleich darf nur auf einer nachweislich stabilen
Messumgebung beruhen. Wenn ein moduldefiniertes Stabilitäts-Gate die zulässige
Streuung überschreitet, ist der Vergleich als `NOT_EXECUTED` beziehungsweise
`INFRASTRUCTURE_UNAVAILABLE` auszuweisen. Das ist weder ein erfolgreicher
Nachweis noch eine Statusaufwertung und ersetzt keinen tatsächlichen
Regressionsvergleich. Baselines, Messwerte und Runnerdaten bleiben außerhalb
der Repository-Evidenz.

Ein Performance-Nachweis wiederholt Plattformen oder SQL-Versionen nur bei
einem für den Workload relevanten Programmzweig, Provider oder erwarteten
Engineunterschied. Andernfalls genügt ein dokumentiertes repräsentatives Ziel;
Docker ist dafür nur auf einem reservierten oder ausreichend skalierten,
lastkontrollierten Host zulässig, wenn der Workload keine hostgebundene
Fähigkeit benötigt. Eine Kalibrierung und ein unabhängiger Bestätigungslauf dürfen eine
flüchtige Basis ausschließlich innerhalb desselben Laufs verwenden. Sie
belegen Wiederholbarkeit auf diesem Ziel, nicht eine allgemeine oder
plattformvergleichende Leistungszusage.

## Phasen, Testbindung und Wiederholung

Diagnose/Entwicklung, begrenzte Integration, Qualifikation des deklarierten
Supportscopes und Release haben unterschiedliche Akzeptanzkriterien. Eine
Fehlerkorrektur prüft betroffene Verträge und Verbraucher. Offene Plattform-,
Minimalrechte-, Performance- oder Releasefälle bleiben sichtbar offen, ohne
dadurch bei jeder Korrektur erneut die gesamte Matrix auszulösen. Die
Definition of Done und vorgeschriebene Lifecycle-/Statistik-/Frischeprüfungen
bleiben für eine entsprechende Qualifikations- oder Releaseaussage verbindlich.

Wiederholungen brauchen geänderte relevante Inputs oder Umgebung, einen neuen
Befund, eine vorgeschriebene Wiederholung/Frische oder einen noch unerfüllten
Gate. Zur Bindung gehören Produktquellen, Tests/Fixtures/Generatoren,
Toolversionen, Konfiguration, gemeinsame Abhängigkeiten, Umgebung und Scope.
Identische Produktbytes allein reichen nicht. Bei unbekannter Wirkung wird
konservativ breiter geprüft. Frühere Fehler bleiben Fehler; wiederverwendete
Teilnachweise werden mit Originaldatum und aktuellem Anwendungsgrund benannt,
nicht als frisch ausgeführt. Exakte aktuelle Head-/Integrations-CI bleibt
ein eigener Pflichtnachweis; ein lokaler Erfolg ersetzt sie nicht.

Ein identischer Validator läuft am gleichen Inputstand einmal über den
zuständigen Suite-/Impactpfad. Seine negativen Kontrollen und eigenen
Regressionen bleiben eigenständige Assertions. Validator-Selbsttests werden
bei Änderungen am Werkzeug, seinen Abhängigkeiten, der Testkonfiguration,
einem Befund oder ausdrücklich angeforderter Qualifikation ausgeführt;
die Prüfung aktueller Projektinputs bleibt davon getrennt.

Reine Modul-README-, CHANGELOG-, Objekt-/Testdokumentationsänderungen starten
keine SQL-Runtimeprüfung. Fachliche Architekturverträge, Manifeste, Code,
Fixtures, Generatoren, Adapter und unbekannte Moduldateien bleiben von den
vorhandenen positiven Workflowfiltern erfasst. Manuelle Qualifikation bleibt
unverändert. Selektoränderungen prüfen positive, negative, gemeinsame
Abhängigkeits- und unbekannte Fälle; Pflichtstatus werden nicht als PASS
erfunden. Laufende mutierende Tests behalten ihre Cleanup-/Cancellationgrenzen.

## Logauswertung und Modellreviews

Exitcode, fehlgeschlagene Schritte, Fehlerorte, Skips, Capturevollständigkeit
und Cleanup zuerst mit vorhandenen lokalen Werkzeugen prüfen. Originale
bleiben nach den Datenschutzregeln lokal; weitergegeben werden begrenzte,
deduplizierte Befunde mit Quellenbindung und Einschränkungen. Ein leerer
Fehlersuchtreffer beweist keinen Erfolg. Bei Unklarheit den erforderlichen
Originalausschnitt mit ausreichendem Kontext lesen. Grüne Vollogs, kumulierte
Receipts und komplette Chathistorien werden nicht routinemäßig neu analysiert.

Zusätzliche Modellaufrufe/Reviews brauchen eine offene semantische Frage,
geänderte Inputs, neue Befunde oder vorgeschriebene Unabhängigkeit. Hashes,
Zähler, Status und Commitbindungen werden deterministisch geprüft. Ein Review
erzwingt keinen Review seines Berichts; erforderliche unabhängige Fachreviews
bleiben erhalten. Für Routinearbeit entsteht keine neue Reader-/Receiptkette.

## CI

### Lokale Auswertung und Remote-Wiederverwendung

Vorhandene deterministische Runner entscheiden über Oracles, Exitstatus,
Vollständigkeit und Cleanup; ein erfolgreicher Routine-Test benötigt keine
zusätzliche modellbasierte Bestätigung. Unveränderte Blocker werden ohne
automatischen Wiederholungslauf benannt. Diagnose und Logauswertung folgen
dem vorstehenden Abschnitt.

Eine automatische Local-to-Remote-Attestierung ist derzeit `NOT_IMPLEMENTED`.
Lokale JSON-Dateien, Modellurteile, Sourcehashes oder Build-Provenance allein
ersetzen keinen aktuellen CI-Gate. Die bestehende Remote-CI wird ausgeführt
(`EXECUTE_REQUIRED`), bis ein unabhängig vertrauenswürdiger Verifikator
Aussteller/Autorität, Herkunft/Integrität, Frische, aktuelle Head-/Integration,
sämtliche relevanten Code-/Test-/Oracle-/Fixture-/Dependency-Inputs und die
tatsächliche Engine-/CL-/Plattform-/Provider-/Rechte-/Transportbindung sowie
Abschluss und Cleanup nachweisen kann. Externe Zustandsänderungen müssen
ebenfalls invalidieren. Fehlende oder manipulierte Nachweise führen nie zu
`REUSED_VERIFIED`; ohne ausführbaren Pflicht-Gate bleibt die Abnahme offen.
Eine spätere Implementierung erhält eigene positive und negative
Verifikations-/Eventtests einschließlich aktueller Required Checks.

Die [Impact-Prüfung](../../Tests/CI/CHANGE_IMPACT_REVIEW_2026-10-19.md)
hält die aktuelle Umsetzung, erhaltene Gates und ausdrücklich offene Grenzen fest.

### Bestehende Ausführung

CI bleibt schlank und pfadbezogen. Der Dokumentationsvalidator bestimmt seinen
Scope aus dem Git-Diff, der Modulregistry und den expliziten Impact-Paketen.
Dokumentationsänderungen lösen keine unnötige Runtime-Vollmatrix aus. Ein
vollständiger Audit läuft bei globalen Fach-/Schutzverträgen, Änderungen an
Kopplungsregistry oder Validator, unbekanntem Impact, vor einem Release,
beim manuellen Aufruf oder auf ausdrücklichen Auftrag. Begrenzte Prozess-,
Foundation- und Entscheidungsänderungen prüfen ihre registrierten Verbraucher;
unveränderliche Basisschutzprüfungen bleiben aktiv. Teure
oder spezielle Plattformtests dürfen manuell oder capability-spezifisch
ausgeführt werden; fehlende Runner ergeben keinen grünen Nachweis.

## Aktueller Qualifikationsstand vom 2026-10-19

45 Module sind implementiert: 21 `validated` und 24 `partially validated`;
alle bleiben `unreleased`. Die 16 Module der ersten Releasekohorte haben
keine offenen Pflichtgates mehr. Die drei großen Ergebnis-Lasttests sind
bestanden, Laufzeitmessungen gemäß DEC-2026-036 optional. Veröffentlichung
und authentifizierte TLS-Abnahme bleiben getrennt. Maßgeblich sind die
Modulmanifeste und der [V0c-Gatebericht](../../Tests/V0C_RELEASE_GATE_STATUS.md).

### Historischer Stand vom 2026-09-01

Die folgenden Zahlen und Restfälle beschreiben ausschließlich den damaligen
27-Modul-Bestand. Sie sind kein aktueller Arbeitsvorrat und werden nicht
auf spätere Modulversionen übertragen.

Am 2026-09-01 waren die vollständigen automatisierten Adapter auf physischen
SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und Linux latest
erfolgreich. Von 27 implementierten Modulen sind 20 `validated`, 7
`partially validated` und 0 `not executed`; alle bleiben `unreleased`.

`validated` sind `toolbelt.binary.bit-operations`,
`toolbelt.conversion.integer-base`, `toolbelt.conversion.uri-component`,
`toolbelt.core.error-envelope`, `toolbelt.core.event-log`,
`toolbelt.core.execution-context`, `toolbelt.core.second-session`,
`toolbelt.core.work-queue`, `toolbelt.core.work-type`,
`toolbelt.datetime.bucket`, `toolbelt.datetime.calendar-difference`,
`toolbelt.datetime.date-spine`, `toolbelt.datetime.truncate`,
`toolbelt.json.path-exists`, `toolbelt.metadata.capability-catalog`,
`toolbelt.metadata.identifier`, `toolbelt.string.directional-trim`,
`toolbelt.string.regex`, `toolbelt.string.split-characters` und
`toolbelt.validation.semantic-version`.

Die sieben `partially validated`-Module bleiben bewusst begrenzt:

- `toolbelt.core.result-table`: repräsentative stabile Performance-Evidenz;
- `toolbelt.conversion.base64`: breitere Large-LOB-Performance-Evidenz;
- `toolbelt.core.generate-series`: breitere Very-large-series-
  Performance-Evidenz;
- `toolbelt.core.console-message`: zusätzliche Client-/Treiber-, Buffering-
  und Framing-Evidenz;
- `toolbelt.file.content`: separat bereitgestellte serverseitige Fixtures und
  nicht-ASCII-spezifische Providergrenzen;
- `toolbelt.archive.zip-memory`: reale Archive, echte Extremgrößen,
  historische Upgrades und Interoperabilität;
- `toolbelt.filesystem.windows`: Caller-Impersonation, NTFS-ACLs und die
  breitere manuelle I/O-Matrix.

### Historischer Stand vom 2026-08-29

Die folgenden Aussagen dokumentieren den damaligen Zwischenstand und sind
durch den Stand vom 2026-09-01 ersetzt.

Am 2026-08-29 waren die vollständigen Adapter aller 16 V0c-Module auf
physischen SQL-Server-2019-, 2022- und 2025-Linux-Zielen erfolgreich. Die
folgenden Modulstatus bleiben dennoch `partially validated`, weil Windows-
und modulspezifische Restfälle nicht vollständig ausgeführt sind.

`toolbelt.core.result-table` hat `implementation_status: implemented`,
`validation_status: partially validated` und `release_status: unreleased`. Die
GitHub-hosted Linux-Läufe vom 2026-07-29 sind für SQL Server 2019, 2022 und
2025 erfolgreich; Windows und die noch nicht automatisierten Matrixfälle
bleiben `not executed`.

`toolbelt.string.split-characters` hat `implementation_status: implemented`,
`validation_status: partially validated` und `release_status: unreleased`.
SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 ist
einschließlich Literal-, Leer-Token-, NULL-/NUL-, Collation-, LOB-,
Dependency-, Deployment- und Lifecycle-Contracts erfolgreich. Windows-Läufe
bleiben `not executed`.

`toolbelt.validation.semantic-version` hat `implementation_status:
implemented`, `validation_status: partially validated` und `release_status:
unreleased`. Parser-, Comparator-, Sort-Key-, Deployment- und
Lifecycle-Contracts sind auf den physischen Linux-Zielen 2019/2022/2025
erfolgreich; Windows-Läufe bleiben `not executed`.

`toolbelt.conversion.integer-base` hat `implementation_status: implemented`,
`validation_status: partially validated` und `release_status: unreleased`.
Alphabet-, Kanonizitäts-, Grenzwert-, Overflow-, Deployment- und
Lifecycle-Contracts sind auf den physischen Linux-Zielen 2019/2022/2025
erfolgreich; Windows-Läufe bleiben `not executed`.

`toolbelt.conversion.base64` hat `implementation_status: implemented`,
`validation_status: partially validated` und `release_status: unreleased`. SQL
Server 2025 unter Linux ist mit Compatibility Levels 150, 160 und 170
einschließlich RFC-4648-, Fehler-, Größen-, Deployment- und
Lifecycle-Contracts erfolgreich. Windows-Läufe bleiben `not executed`.

`toolbelt.core.generate-series` hat `implementation_status: implemented`,
`validation_status: partially validated` und `release_status: unreleased`.
SQL Server 2025 unter Linux ist mit Compatibility Levels 150, 160 und 170
einschließlich Semantik, Grenzen, Größe, Join, `CROSS APPLY`, Deployment und
Lifecycle erfolgreich. Windows-Läufe bleiben `not executed`.

`toolbelt.metadata.identifier` hat `implementation_status: implemented`,
`validation_status: partially validated` und `release_status: unreleased`.
SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 ist
einschließlich Parser-, Quote-, Escape-, Omission-, Fehler-, Deployment- und
Lifecycle-Contracts erfolgreich. Windows-Läufe bleiben `not executed`.

`toolbelt.datetime.calendar-difference` hat `implementation_status:
implemented`, `validation_status: partially validated` und `release_status:
unreleased`. SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170
ist einschließlich Anniversary-, Grenzwert-, NULL-, `APPLY`-, Deployment- und
Lifecycle-Contracts erfolgreich. Windows-Läufe bleiben `not executed`.

`toolbelt.string.directional-trim` hat `implementation_status: implemented`,
`validation_status: partially validated` und `release_status: unreleased`.
SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 ist
einschließlich Richtungs-, Typ-, Literal-, NULL-/NUL-, nativer Paritäts-,
Deployment- und Lifecycle-Contracts erfolgreich. Weitere Collations und
Windows-Läufe bleiben `not executed`.

`toolbelt.conversion.uri-component` hat `implementation_status: implemented`,
`validation_status: partially validated` und `release_status: unreleased`.
SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 ist
einschließlich RFC-3986-, Unicode-, UTF-8-, Fehler-, Einmal-Decoding-,
SVF-/TVF-Paritäts-, Deployment- und Lifecycle-Contracts erfolgreich.
LOB-/Performancegrenzen und Windows-Läufe bleiben `not executed`.

`toolbelt.json.path-exists` hat `implementation_status: implemented`,
`validation_status: partially validated` und `release_status: unreleased`.
SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 ist
einschließlich nativer Parität, Root-, Property-, Quote-, Array-, Wildcard-,
NULL-, Fehler-, BIN2-, Deployment-, Central-, Uninstall- und
Lifecycle-Contracts erfolgreich. Windows-Läufe bleiben `not executed`.

`toolbelt.core.console-message` hat `implementation_status: implemented`,
`validation_status: partially validated` und `release_status: unreleased`.
SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170 ist
einschließlich API-, Help-, Langtext-, PRINT-, RAISERROR/NOWAIT-, Unicode-,
Zeilen-, Wiederholungs-, Lifecycle-, Central- und Uninstall-Contracts
erfolgreich. Windows- und weitere Client-/Treiber-Läufe bleiben `not
executed`.

`toolbelt.metadata.capability-catalog` hat `implementation_status:
implemented`, `validation_status: partially validated` und `release_status:
unreleased`. SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170
ist einschließlich API-, Marker-, Drift-, Typ-, Object-level-, Collation-,
Read-only-, Wiederholungs-, Lifecycle-, Central- und Uninstall-Contracts
erfolgreich. Windows- und eingeschränkte Metadata-Visibility-Läufe bleiben
`not executed`.
