# ROADMAP.md – SQL Server Toolbelt

## Status

Aktualisierung 2026-10-19: Zwölf aktuelle vollständige Pointer-Labadapter
bestanden auf Windows und Linux: SQL2019 CL150, SQL2022 CL150/160 und
SQL2025 CL150/160/170, jeweils local/central/Consumer. Je 3072 feste
Contract-/Safety-Oracles, 15 Clientreader und 42 Lifecyclefälle; frische
read-only Audits bestätigten Input-/Fixturepins und 36 eigene DBs abwesend.
Der seit den alten Läufen ergänzte SC-006-Source ist gebunden; die separate
Securityfixture und neue Lastfälle waren nicht Teil dieser Labwelle.
Die physischen Ziel-/CL-Lücken des full-Adapters sind damit geschlossen.
Minimalrechte, Heap/Parallelität, harte Runner-/Host-Recovery, authentifizierte
TLS-Abnahme und Release bleiben separat; teilweise validiert, unveröffentlicht.
[Qualifikationsbericht](../Modules/toolbelt.json.pointer/Tests/QUALIFICATION_2026-10-19.md).

JSON Pointer1.0.0 und die anschließende128er-Prioritätsänderung sind einzeln
freigegeben und umgesetzt. Finale Adapter auf Linux2019/latest CL150 und
Windows2025/exaktCU8 CL170 bestanden je local/central/Consumer,3072 feste
APPLY-Oracles,15 Clientreader und42 Lifecyclefälle samt frischem Cleanup-/
Fixture-/Pinaudit. Frühere Fehlläufe und Lifecycle-only-Scopes bleiben getrennt.
Zum Zeitpunkt dieser ersten Zielnachweise waren weitere physische Ziele,
Minimalrechte,16MiB-Maximalworkload/Heap und exakte Head-CI separate offene
Nachweise; teilweise validiert, unveröffentlicht.
Zusätzlich bestanden am 2026-10-06 auf demselben Windows2025/exaktCU8-Ziel
vollständige Pointer-Adapter mit CL150 und CL160 samt unabhängigen Audits;
weitere physische Ziele und Lastgrenzen bleiben offen.
Seit 2026-10-06 ist zusätzlich die begrenzte Modul-Runtime-CI am exakten
[PR187-Head](https://github.com/gecompat/SQL_Server_Toolbelt/pull/187)
([Linux-2019/2022/2025-Lauf](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37403031731))
und nach Merge auf [main](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37403199703)
erfolgreich. Sie enthält Contract/Safety, Clientmetadaten und installierte
Baseline, nicht die 42 gezielten Lab-Lifecyclefälle. Die damaligen offenen
Minimalrechte-, Hard-Interrupt-, Maximalworkload-/Heap-, Zielmatrix- und
Releasegrenzen werden durch diesen CI-Nachweis allein nicht geschlossen.
Nach [PR201](https://github.com/gecompat/SQL_Server_Toolbelt/pull/201) und
[PR203](https://github.com/gecompat/SQL_Server_Toolbelt/pull/203) bestanden
am 2026-10-06 manuell ausgelöste, einzeln begrenzte Linux-SQL2019-CL150-
Lastläufe: Root und `/k` bei64KiB,1MiB,4MiB und exakt16MiB sowie ein
geschachtelter `/k`-Pfad bei64KiB bis Tiefe128 und anschließend Tiefe128
bei1MiB,4MiB und exakt16MiB. [PR202](https://github.com/gecompat/SQL_Server_Toolbelt/pull/202)
und [PR204](https://github.com/gecompat/SQL_Server_Toolbelt/pull/204) verlinken
die tatsächlichen Einzelruns in der [Testmatrix](../Modules/toolbelt.json.pointer/Tests/JSON_POINTER_TEST_MATRIX.md).
Reguläre Pointer-Head- und Main-CI bestanden auch für die Adapteränderungen;
der schwere Lastmodus blieb dort SKIPPED und wurde separat manuell geprüft.
Weitere physische Ziele, Minimalrechte, Hard-Interrupt-Recovery,
SQL2022/2025-Maximallast, andere JSON-Formen, tatsächlicher Heap,
Parallelität und Releasequalifikation bleiben offen.
Weitere lokale Einzelproben am 2026-10-06 bestanden mit dem unveränderten
Adapter auf flüchtigem Linux-SQL2022-CL160 und SQL2025-CL170: je Root und
einfaches `/k` bei64KiB,1MiB,4MiB und exakt16MiB mit serverseitigem Oracle,
eigenem Cleanup und frischem Abwesenheitsaudit. Die vorherige Aussage zu
SQL2022/2025-Maximallast bezeichnet den Stand vor diesen Proben. Tiefe128
auf diesen Versionen, weitere Formen/Plattformen, reale Heap-/Parallel-
kapazität, Minimalrechte, Runner-/Host-Recovery und Release bleiben offen.

Anschließend bestanden am 2026-10-06 je zehn weitere lokale Einzelproben
auf denselben flüchtigen Linux-SQL2022-CL160-/SQL2025-CL170-Images:
64KiB mit Tiefe2,4,8,16,32,64,128 sowie Tiefe128 bei1MiB,4MiB und
exakt16MiB. Serverseitige Einzeilen-/Längen-/Hashoracles, eigene Bereinigung
und frische unabhängige Owner-Label-Abwesenheitsaudits bestanden. Die
[Testmatrix](../Modules/toolbelt.json.pointer/Tests/JSON_POINTER_TEST_MATRIX.md)
grenzt die lokalen Fälle ab. Der frühere offene Tiefe128-/Maximalgrößenstand
ist damit für diese synthetischen Linux-Kombinationen überholt. Andere
Formen/Plattformen, tatsächlicher Heap, Parallelität, Minimalrechte,
Runner-/Host-Recovery und Releasequalifikation bleiben offen.

Die sechs einzeln freigegebenen Safe-Cast-TVFs in `toolbelt.conversion.safe-cast`
1.0.0 sind implementiert und teilweise validiert. Finale begrenzte Adapter auf
Linux2019/latest CL150 und Windows2025/exaktCU8 CL170 bestanden local/central/
Consumer einschließlich fester API-Oracles, Clientmetadaten,38 Lifecyclefällen
je Ziel und unabhängigem Bereinigungsaudit. Drei frühere Gesamtfehlläufe bleiben
getrennt. Weitere physische Ziele, Minimalrechte, Heap und exakte Head-CI sind
separate Nachweise; unveröffentlicht.
Zusätzlich bestanden am 2026-10-06 auf demselben Windows2025/exaktCU8-Ziel
die vollständigen Safe-Cast-Adapter mit CL150 und CL160 samt unabhängigen
Audits. Weitere physische Ziele, Minimalrechte, Heap und Runtime-Head-CI
bleiben offen.

Seit 2026-10-06 ist zusätzlich die begrenzte Modul-Runtime-CI am exakten
[PR186-Head](https://github.com/gecompat/SQL_Server_Toolbelt/pull/186)
([Linux-2019/2022/2025-Lauf](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37402203046))
und nach Merge auf [main](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/37402837558)
erfolgreich. Sie enthält API-Fixtures, Clientmetadaten und installierte
Baseline, nicht die 38 gezielten Lab-Lifecyclefälle. Minimalrechte,
Hard-Interrupt-Recovery, Heap, weitere physische Ziele und Releasequalifikation
bleiben offen.

Aktualisierung 2026-10-19: Zwölf aktuelle Safe-Cast-Labadapter auf Windows
und Linux SQL2019 CL150, SQL2022 CL150/160 und SQL2025 CL150/160/170 bestanden
je local/central/Consumer mit 38 Lifecyclefällen. Alle Input-/Fixturepins
und 36 eigene DBs abwesend wurden vor dem Evidenznachtrag frisch lesend
bestätigt. Zwei echte ADO.NET-Setupfehlerproben bestanden ohne SQL. Die
historischen physischen Ziel-/CL-Lücken sind für diesen Scope geschlossen.
Minimalrechte, harte Runner-/Host-Recovery, Kapazität, Head-CI und Release
bleiben separat; teilweise validiert und unveröffentlicht.
[Qualifikationsbericht](../Modules/toolbelt.conversion.safe-cast/Tests/QUALIFICATION_2026-10-19.md).

`toolbelt.pseudonymization.deterministic` 1.1.0 ergänzt die einzeln freigegebene
ASCII-Translation. Vollständige Adapter auf Linux 2019/latest local/central
und Windows 2025/CU8 central CL150/160/170 erfolgreich; Windows local durch
bestandene API-/Safetyfälle und eine separate korrigierte Metadaten-/
Lifecycleprüfung belegt, ohne den früheren Gesamtfehllauf umzuwerten.
Aktuelle CI, neue Minimalrechte, weitere physische Targets und Kapazität
bleiben offen; `partially validated`, `unreleased`. GeoJitter ist eine
getrennt freigegebene Folgefunktion; der folgende additive Stand ist davon getrennt.

Version 1.2.0 implementiert GeoJitter. Finale ausgewählte Adapter bestehen auf
Linux 2019/latest CL150 und Windows 2025/CU8 CL150/160/170 lokal/zentral:
drei Geo-/Safety-/Metadaten-Runtime-Fixtures, ursprüngliche fünf Batches mit
504 Orakeln sowie Clientmetadaten, echte 1.0-/1.1-Upgrades und Lifecycle.
Neue Minimalrechte, weitere Ziele und exakt 129-Byte-UDT bleiben offen.
Aktuelle CI wird als separater PR-Mergegate am exakten Head nachgewiesen;
`partially validated`, `unreleased`.

XLSX-Raw-Reader `toolbelt.file.xlsx-memory` 1.0.0 und kanonische ZIP-Fassade 1.4.0 sind implementiert; finale ausgewählte Linux-2019-/Windows-2025-Adapter erfolgreich. Die Raw-Welle ist abgeschlossen und teilweise validiert; separat freigegebene Typ-/Anzeige-Folgewellen verbleiben beim nächsten Orchestrator.

Repository-Grundaufbau, Foundation-Korrektur, Research-Wellen,
Toolbelt-Landschaftsrecherche und die bisherigen Entwicklungswellen sind
abgeschlossen. 45 Module sind implementiert. 21 sind `validated`, 24 sind `partially validated`; 0 sind `not executed`. Die verbindlichen Einzelstatus werden aus den
jeweiligen `module.yaml`-Manifesten abgeleitet.

Die vollständige lokale Adaptermatrix war am 2026-09-01 auf physischen
SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und Linux latest
erfolgreich. Seit 2026-09-01 decken zusätzlich alle fünfzehn GitHub-hosted
Modul-Runtime-Workflows die SQL-Server-Versionen 2019, 2022 und 2025 unter
Linux ab; damit besteht ein von der Lab-Verfügbarkeit unabhängiger
Evidenzkanal. Second Session und Event Log verwenden die versionsabhängig
ermittelte OLE-DB-Provideroption. Sieben Bestandsmodule blieben damals wegen
ausdrücklich abgegrenzter Performance-, Client-/Treiber-, Fixture-,
Interoperabilitäts- oder manueller Sicherheitsfälle `partially validated`.
Der aktuelle Bestand umfasst 45 Module, davon 21 `validated` und 24
`partially validated`; alle 16 V0c-Module sind seit der Nachqualifikation
vom 2026-10-19 `validated`. Der
[V0c-Gatebericht](../Tests/V0C_RELEASE_GATE_STATUS.md) ersetzt die historischen
Kohorten-Restfälle; alle Module bleiben `unreleased`.
Script Parser 1.0.0 war auf Windows SQL Server 2019, 2022 und 2025 validiert;
die einzeln freigegebene Härtung 2.0.0 ist aktiv und `partially validated`:
245 integrierte Framework-Kindprozesse und Windows 2025/CU8 CL150/160/170
bestanden. Die damaligen 2019-/2022-Lücken betreffen diesen historischen
2.0.0-Vollscope. Der freigegebene 2.0.1-Build besteht seit 2026-10-18
Parser-Upgrades und SSIS-/Table-Clone-Consumerprüfungen auf Windows
2019/2022/2025 lokal und zentral. Das ist keine Vollqualifikation aller
nativen Parser-APIs oder Ausgabeceilings; siehe die
[aktuelle Parser-Evidenz](../Modules/toolbelt.tsql.script-parser/Tests/README.md).
Der vor Source qualifizierte Wächterkandidat ersetzt keine integrierte
Framework- oder Live-SQL-Abnahme. File Content benötigt weiterhin
separat bereitgestellte serverseitige Fixtures. S2 zu `TC-2026-032` wurde am
2026-10-01 freigegeben und als `toolbelt.string.split-advanced` implementiert;
risikobasiert sind 2019 Linux und 2025 Linux/Windows geprüft. Weitere
Zielkombinationen sind nicht ausgeführt; USP und Unquoting bleiben getrennt.

## Phase 0 – Repository-Grundaufbau

**Status:** `completed`
**Abschluss:** 2026-07-28

Enthält Root-Dateien, AI-Steuerung, Architektur- und Standardsdokumentation, Modul-Templates, Backlog-Struktur und den USP-Vertrag.

## Phase 0.1 – Foundation-Korrektur

**Status:** `completed`  
**Abschluss:** 2026-07-29

Enthält:

- korrigiertes GitHub-Copilot-Custom-Agent-Profil;
- objekttypspezifische SQL- und Dokumentations-Templates;
- vollständige USP-Contract-Testanforderungen;
- SQL Server 2025 in Support- und Testmatrizen;
- präzisierte CLR-, Linux- und `TRUSTWORTHY`-Regeln;
- vervollständigtes Entscheidungsprotokoll;
- konsolidierte Status-, Sprach- und Contribution-Regeln.

## Phase 0.2 – Backlog Research Wave 1

**Status:** `completed`  
**Abschluss:** 2026-07-29

Enthält:

- Präzisierung der bestehenden Kandidaten `TC-2026-001` und `TC-2026-002`;
- neue Kandidaten `TC-2026-003` bis `TC-2026-013`;
- versionsbezogene Abgrenzung zwischen SQL Server 2019, 2022 und 2025;
- Primärquellen, Plattformgrenzen, Performance-/Security-Fragen und konkrete nächste Schritte;
- Priorisierung der ResultTable-Infrastruktur als erstes Kernarbeitspaket.

## Phase 0.3 – Backlog Research Wave 2: Execution Infrastructure

**Status:** `completed`
**Abschluss:** 2026-07-29

Enthält:

- Kandidaten `TC-2026-014` bis `TC-2026-022`;
- transaktionsunabhängige Ereignisprotokollierung mit klarer Abgrenzung zu transactional Service-Broker-Messaging;
- asynchrone Work Queue und begrenzte Parallelisierung;
- lange beziehungsweise ungepufferte Console-Ausgabe;
- Error Envelope, Cancellation, Correlation, Retry/Dead-letter und Worker-Leases;
- sicheren Work-Type-Katalog anstelle einer ungeprüften Raw-SQL-Ausführung;
- verbindliche Trennung zwischen fortlaufender Ideenpflege und funktionsbezogener Implementierungsfreigabe.

## Phase 0.4 – Toolbelt-Landschaft und Prior Art

**Status:** `completed`
**Abschluss:** 2026-07-29

Enthält:

- systematische Einordnung von 16 direkten Libraries, Testframeworks, Skriptkatalogen, Diagnose-, Maintenance- und Automationsprojekten;
- vertiefte Architekturbetrachtung von SDU Tools, SQL#, T-SQL Toolbox und SQLServerSpatialTools;
- `tSQLt.NewConnection` als konkrete Prior Art für eine synchron geöffnete zweite Session;
- Vergleich von Service Broker, SQL Server Agent, tabellenbasierter Queue und externem Orchestrator als Parallelisierungsprovider;
- Packaging-, Discovery-, Versionierungs-, Test-, Lizenz-, Security- und Scope-Lehren;
- Präzisierung des vorhandenen Base64-Kandidaten `TC-2026-012` anhand der nativen SQL-Server-2025-Semantik;
- neue Kandidaten `TC-2026-023` für Runtime-Capability-Discovery und `TC-2026-024` für URI-Percent-Encoding/-Decoding;
- quellenbasierte Scope-Vorprüfung der persönlichen Brainstorm-Themen Zahlensysteme, Kompression/Archive, Datei-/Verzeichniszugriff, Anonymisierung und Objektklonen;
- Kandidaten `TC-2026-025` bis `TC-2026-028` für kontrollierte PowerShell- und Python-Provider, versionsbezogene REST-Aufrufe sowie getrennte Embedding-/KI-/Chat-Verträge;
- dokumentierte Ausschlussgrenze gegen Raw Script, beliebige Endpunkte und ungeprüfte KI-Ausgabe als ausführbaren Code;
- Screening-Liste für weitere Funktionsrecherche ohne Implementierungs- oder Kandidatenstatus.

## Phase 1 – Erstes Kernmodul

### Phase 1.1 – Implementierungsreife Spezifikation

**Status:** `completed`  
**Abschluss:** 2026-07-29  
**Arbeitspaket:** `AP-2026-002`

Ergebnis:

- Modul-ID `toolbelt.core.result-table`;
- einziges persistentes Objekt `toolbelt_core.USP_PrepareResultTable`;
- öffentliche Signatur und Modulfehlerbereich;
- Referenztabellenvertrag für Version `1.0.0`; ein sicherer `@CreateStmt`-Pfad bleibt als spätere parsergestützte Erweiterung möglich;
- normalisierte Spaltenmetadaten, Typ-Whitelist und invariant-binäre Namenssemantik;
- vollständiger `@KeepData`-, Preflight-, in-place-DDL-, Savepoint-, Transaktions- und Deployment-Vertrag;
- interne Temp-Namenskonvention `#tbx_` ohne Festlegung persistenter Tabellennamen;
- Lifecycle-, Ownership- und Berechtigungsmodell;
- vollständige statische und Runtime-Testmatrix;
- Architekturentscheidungen `DEC-2026-013` bis `DEC-2026-017`.

### Phase 1.2 – Implementierung und Validierung

**Arbeitsstatus:** `in progress`

**Implementierungsstatus:** `implemented`

**Validierungsstatus:** `partially validated`

**Release-Status:** `unreleased`
**Arbeitspaket:** `AP-2026-003`

Der Benutzer hat `toolbelt_core.USP_PrepareResultTable` am 2026-07-29 nach der ausführlichen Vertragsbesprechung ausdrücklich zum Beginn freigegeben. Diese Freigabe gilt nur für diese Funktion; weitere Kandidaten bleiben am funktionsbezogenen Gate.

Reihenfolge:

1. Funktionsvertrag, Alternativen, Risiken und Scope mit dem Benutzer besprechen;
2. ausdrückliche Implementierungsfreigabe dokumentieren;
3. Modulgerüst, Manifest, Procedure, Help und Lifecycle-Artefakte implementieren;
4. Objekt- und Moduldokumentation sowie synthetische Beispiele fertigstellen;
5. statische und Contract Tests ausführen;
6. lokale und zentrale Runtime-Tests auf SQL Server 2019, 2022 und 2025 durchführen;
7. Windows und Linux getrennt validieren, soweit geeignete Runner vorhanden sind;
8. Collation-, Fehler-, Recovery- und Performance-Tests dokumentieren;
9. `implemented` nach vollständigem Code und statischem Vertrag, `validated` ausschließlich nach tatsächlicher Runtime-Evidenz vergeben.

Stand:

- Schritte 1 bis 5 abgeschlossen;
- Source, Manifest, Lifecycle, Dokumentation, Beispiele sowie statische und synthetische Contract-Testartefakte vorhanden;
- reproduzierbare statische Vertragsprüfung erfolgreich;
- GitHub-hosted Linux: vollständige vorhandene Suite auf SQL Server 2019, 2022 und 2025 erfolgreich;
- lokale und zentrale Nutzung, Wiederholungsdeployment, Fremdobjekt-Kollision, Uninstall, explizite Collations, 1024-Spalten-Grenze, Transaktionspfade, vier parallele Sitzungen und synthetischer Performance-Workload auf allen drei Linux-Versionen erfolgreich;
- natürlicher Savepoint-Rollback nach Enginefehler 2705 im [Lauf 30692956855](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30692956855) auf SQL Server 2019, 2022 und 2025 Linux erfolgreich;
- automatisierte Windows-/Linux-Matrix 2019/2022/2025 erfolgreich; eine
  plattformübergreifend vergleichbare Performance-Baseline offen;
- Validierungsstatus deshalb `partially validated`, nicht vollständig `validated`.

Die erste Version benötigt keine persistente Tabelle, kein Synonym, keine Assembly und keinen Type. Eine Entscheidung zu diesen offenen persistenten Namenskonventionen ist deshalb noch nicht erforderlich.

## Phase 2 – Weitere Module

**Status:** `in progress`
**Abhängigkeit:** funktionsbezogene Freigabe und scopebezogen ausreichende
Validierung aller tatsächlich verwendeten gemeinsamen Verträge.

Schrittweise Umsetzung priorisierter Toolbelt-Kandidaten nach fachlicher Kategorie und Dependency-Reihenfolge.

### Phase 2.1 – Kandidatenübergreifende Objekt- und Wellenplanung

**Status:** `completed`  
**Abschluss:** 2026-07-30

Der [Implementierungsplan für Toolbelt-Kandidaten](../Backlog/TOOLBELT_CANDIDATE_IMPLEMENTATION_PLAN.md)
ordnet alle 46 formalen Kandidaten vorhandenen oder vorgeschlagenen Modulen,
öffentlichen Objektfamilien, Provider-Slices, Abhängigkeiten, Pflicht-Gates und
Entwicklungswellen zu. Breite Kandidaten werden vor der Entwicklung in
kleinste fachlich vollständige Arbeitspakete zerlegt. Der Plan erteilt keine
Implementierungsfreigabe und legt noch keinen öffentlichen Runtime-Vertrag fest.

Die Entscheidungsvorbereitung `AP-2026-007` ist abgeschlossen.
`TC-2026-012` (Base64/Base64URL) wurde gegenüber `TC-2026-004`
(`DATETRUNC`-Kompatibilität) ausgewählt, besprochen und zur Implementierung
freigegeben. Die Auswahlbegründung steht in
`Documentation/Research/SECOND_MODULE_SELECTION.md`; der verbindliche Vertrag
steht in `Documentation/Architecture/BASE64_MODULE_DESIGN.md`.

Der Base64-Vertrag wurde am 2026-07-29 besprochen und ausdrücklich zur
Implementierung freigegeben. `AP-2026-008` setzt ihn als unabhängiges Modul
`toolbelt.conversion.base64` um. Das Modul verwendet weder ResultTable noch
einen anderen noch unzureichend validierten gemeinsamen Runtime-Vertrag.

Das frühere pauschale Gate „mindestens ein vollständig validiertes
Referenzmodul“ wird durch `DEC-2026-021` scopebezogen präzisiert. Jedes Modul
benötigt weiterhin seine eigenen vollständigen Source-, Lifecycle-,
Dokumentations-, Contract- und Testartefakte. Verwendete gemeinsame
Infrastruktur muss für den konkret benötigten Vertrag ausreichend validiert
sein. Statuswerte dürfen nur tatsächlich ausgeführte Evidenz abbilden.

Stand `toolbelt.conversion.base64`:

- Implementierung, Manifest, Lifecycle, Dokumentation, Beispiele sowie
  statische und Runtime-Contract-Tests vorhanden;
- SQL Server 2025 mit Compatibility Levels 150, 160 und 170 als erste
  serielle Runtime-Matrix ausgeführt;
- vollständiger Adapter am 2026-09-01 auf physischen
  SQL-Server-2019-/2022-/2025-Zielen unter Windows base und Linux latest
  erfolgreich;
- SQL Server 2025 unter Linux mit Compatibility Levels 150, 160 und 170
  einschließlich RFC-4648-, Fehler-, Größen-, Deployment- und
  Lifecycle-Contracts erfolgreich;
- Pflicht-Lastfall mit exaktem 4-MiB-Roundtrip auf SQL 2025 Linux CL170 am 2026-10-19 erfolgreich; `validation_status: validated`, Zeitmessung optional.

Stand `toolbelt.core.generate-series`:

- Vertrag am 2026-07-30 besprochen und ausdrücklich freigegeben;
- zwei portable Inline TVFs für `int` und `bigint`, wobei der `int`-Wrapper
  den gemeinsamen `bigint`-Kern verwendet;
- Modulmanifest, Lifecycle, Dokumentation, Beispiele sowie statische und
  Runtime-Contract-Artefakte vorhanden;
- SQL Server 2025 unter Linux mit Compatibility Levels 150, 160 und 170
  einschließlich Semantik, nativer Parität, Fehlern, Grenzen, einer Million
  Werten, Row Goal, Join, `CROSS APPLY`, Deployment- und Lifecycle-Contracts
  erfolgreich;
- vollständiger Adapter am 2026-09-01 auf physischen
  SQL-Server-2019-/2022-/2025-Zielen unter Windows base und Linux latest
  erfolgreich;
- Pflicht-Lastfall mit zehn Millionen vollständig geprüften Werten auf SQL 2025 Linux CL170 am 2026-10-19 erfolgreich; `validation_status: validated`, Zeitmessung optional.

Stand `toolbelt.metadata.identifier`:

- vollständiger Funktionsvertrag am 2026-07-30 gemeinsam mit den drei
  nachfolgenden Modulen besprochen und ausdrücklich freigegeben;
- formaler Kandidat `TC-2026-029`, abgeschlossenes Arbeitspaket `AP-2026-010`;
- zustandsbasierter Parser und Scalar-Wrapper für ein- bis vierteilige Namen;
- Modulmanifest, Lifecycle, Dokumentation, Beispiele sowie statische und
  Runtime-Contract-Artefakte vorhanden;
- vollständiger Adapter auf physischen SQL-Server-2019-/2022-/2025-Zielen
  unter Windows base und Linux latest erfolgreich;
- `validation_status: validated`.

Stand `toolbelt.string.split-characters`:

- freigegebener Vertrag `TC-2026-001`, abgeschlossenes Arbeitspaket `AP-2026-011`;
- Inline-TVF für mehrere einzelne literal interpretierte UTF-16-Codeeinheiten;
- Dependency auf `toolbelt.core.generate-series` Version `1.0.0`;
- Modulmanifest, Lifecycle, Dokumentation, Beispiele sowie statische und
  Runtime-Contract-Artefakte vorhanden;
- vollständiger Adapter auf physischen SQL-Server-2019-/2022-/2025-Zielen
  unter Windows base und Linux latest erfolgreich;
- `validation_status: validated`;
- mehrzeichige Separatorstrings, Quote und Escape bleiben `TC-2026-032`.

Die freigegebene Entwicklungsfolge `AP-2026-010` bis `AP-2026-013` ist
abgeschlossen. Die breitere
Split-Version mit mehrzeichigen Separatoren, Escape und Quote ist separat als
`TC-2026-032` erfasst; dieser historische Phasenstand wurde durch die
S2-Einzelfreigabe und Implementierung vom 2026-10-01 ergänzt.

`toolbelt.validation.semantic-version` und
`toolbelt.conversion.integer-base` sind einschließlich kanonischer inline
TVFs, SVF-Convenience-Wrappern und Lifecycle implementiert sowie auf
physischen SQL-Server-2019-/2022-/2025-Zielen unter Windows base und Linux
latest `validated`.

### Phase 2.2 – Portable W1

**Status:** `completed`

**Abschluss:** 2026-07-30

**Arbeitspaket:** `AP-2026-015`

Die gemeinsam besprochenen und freigegebenen Kandidaten `TC-2026-002`,
`TC-2026-008` und `TC-2026-024` sind als
`toolbelt.datetime.calendar-difference`,
`toolbelt.string.directional-trim` und
`toolbelt.conversion.uri-component` implementiert. Alle drei Module besitzen
eigene Manifeste, Lifecycle-Artefakte, Objektseiten, statische Prüfungen sowie
Runtime-, zentrale und Uninstall-Contracts.

Der finale [W1-Portable-Runtime-Lauf
30553118399](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30553118399)
ist auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170
erfolgreich. Die [Dokumentationskonsistenz
30553118014](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30553118014)
ist auf demselben Pull-Request-Stand erfolgreich. Der vollständige Adapter
aller drei Module war am 2026-09-01 auf physischen SQL-Server-2019-/2022-/
2025-Zielen unter Windows base und Linux latest einschließlich zusätzlicher
Collation-, ASCII-/Unicode-/Large-Input- und Kollisionsfälle erfolgreich. Die
drei Module sind `validated`.

### Phase 2.3 – W2a Compatibility-Welle

**Status:** `completed`; Runtime `validated`

W2a mit `TC-2026-004`, `TC-2026-005` und `TC-2026-007` wurde am 2026-07-30
ausdrücklich freigegeben und ist als drei Module implementiert. Die
SQL-Server-2025-Linux-Runtime war mit Compatibility Levels 150, 160 und 170
einschließlich Wiederholungsdeployment, Lifecycle, Central und Uninstall
erfolgreich. Die vollständigen Adapter waren am 2026-09-01 zusätzlich auf
physischen SQL-Server-2019-/2022-/2025-Zielen unter Windows base und Linux
latest einschließlich Kollisionsschutz und 100.000-Zeilen-Bucket-Workload
erfolgreich.

### Phase 2.4 – W2b-A JSON Path Exists

**Status:** `completed`; Runtime `validated`

**Arbeitspaket:** `AP-2026-017`

Der Benutzer hat den empfohlenen V1-Scope am 2026-07-30 freigegeben.
`TC-2026-009` wird zunächst ausschließlich als
`toolbelt.json.path-exists` umgesetzt. Die öffentliche
`TVF_JsonPathExists` bildet die fehlerfreie `1`/`0`/SQL-`NULL`-Semantik für
Root-, Property-, Array-Index- und Wildcard-Pfade ab.

Historischer Stand dieser W2b-Planung: JSON-Konstruktoren waren ein eigener, noch nicht freigegebener Slice. Die spätere Einzelfreigabe und Umsetzung der USPs sowie der aktuellen gruppierten 1.1-Welle steht im BACKLOG und Modulmanifest; Aggregate bleiben ein getrennter Scope.

Gruppierte JSON-USPs 1.1.0 am 2026-10-02: ausgewählte API-/100000-/16-MiB-/Clientprüfungen lokal/zentral erfolgreich innerhalb insgesamt fehlgeschlagener früherer Adapter. Finale fokussierte Metadaten-/Upgrade-/Lifecycle-/Central-/Bereinigungsadapter auf Linux 2019/latest und Windows 2025/CU8 erfolgreich; deren Runtime-Auswahl enthielt ausschließlich InstalledMetadata.Contract.sql. Neue Minimalrechte bleiben offen; die Uninstall-Voraussetzung VIEW DEFINITION/SELECT wurde am 2026-10-02 einzeln freigegeben, die neue Gateumsetzung bestand fokussierte native Lifecycle-Läufe, negative CI-Injektionen bleiben offen; aktuelle CI wird als separater PR-Mergegate nachgewiesen. Details und Fehlerhistorie in der [Testmatrix](../Modules/toolbelt.json.constructors/Tests/JSON_CONSTRUCTOR_CONTRACT_TEST_MATRIX.md); teilweise validiert und unveröffentlicht.

`TC-2026-013` bleibt zurückgestellt, solange die nativen Aggregate Preview
sind und kein freigegebener SQL-CLR-/Providervertrag besteht.

Der [W2b-JSON-Path-Runtime-Lauf
30568128943](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30568128943)
ist auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170
einschließlich nativer Parität, Wiederholungsdeployment, Lifecycle, Central
und Uninstall erfolgreich. Der vollständige Adapter war am 2026-09-01
zusätzlich auf physischen SQL-Server-2019-/2022-/2025-Zielen unter Windows
base und Linux latest einschließlich Kollisionsschutz erfolgreich.

### Phase 2.5 – W2c Console Message und Capability Catalog

**Status:** `completed`; Runtime gemischt (`console-message` `partially validated`, `capability-catalog` `validated`)

**Arbeitspaket:** `AP-2026-018`

Der Benutzer hat `TC-2026-016` und `TC-2026-023` am 2026-07-30 gemäß
Hauptempfehlung freigegeben. `toolbelt.core.console-message` implementiert
`toolbelt_core.USP_WriteConsoleMessage` mit 4.000-Codeunit-`PRINT`- und
2.000-Codeunit-NOWAIT-Chunks. `toolbelt.metadata.capability-catalog`
implementiert `toolbelt_metadata.VW_ModuleCapabilities` als read-only
Projektion der Database-level Modulmarker.

Source, Lifecycle, Dokumentation, Beispiele, statische und synthetische
Runtime-Contracts sind vorhanden. Die
[W2c-Runtime 30573135975](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30573135975)
ist auf SQL Server 2025 Linux mit Compatibility Levels 150/160/170
einschließlich Langtext-/Unicode-, Marker-/Drift-, Wiederholungs-, Lifecycle-,
Central- und Uninstall-Contracts erfolgreich. Die vollständigen Adapter waren
am 2026-09-01 zusätzlich auf physischen SQL-Server-2019-/2022-/2025-Zielen
unter Windows base und Linux latest erfolgreich. Die eingeschränkte
Metadatensichtbarkeit wurde ohne Rechteausweitung geprüft; der Capability
Catalog ist `validated`. Console Message bleibt wegen zusätzlicher
Client-/Treiber- und Buffering-Grenzen `partially validated`.

### Phase 2.6 – Portable File Content

**Status:** `completed`; Runtime `partially validated`

**Arbeitspaket:** `AP-2026-024`

`toolbelt.file.content` stellt einen portablen Read-only-Vertrag für Text- und
Binärdateien über `OPENROWSET(BULK...)` und eine Root-Allowlist bereit. Der
Wartungslauf [https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30692267356](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30692267356) hat SQL Server 2025 Linux mit
Compatibility Levels 150, 160 und 170 einschließlich synthetischer Fixtures,
Allowlist, Lifecycle und Uninstall erfolgreich geprüft. Windows und
nicht-ASCII-spezifische Providergrenzen bleiben Releasevalidierung.

### Phase 2.7 – ZIP Memory SQL CLR

**Status:** `completed`; Runtime `partially validated`

**Arbeitspaket:** `AP-2026-020`

`toolbelt.archive.zip-memory` Version `1.2.0` extrahiert genau einen benannten
ZIP-Entry und listet Central-Directory-Metadaten aus `varbinary(max)` über eine
`SAFE` SQL-CLR-Assembly. Extraktions- und Listingvertrag mit Methods 0 und 8,
Data Descriptor, UTF-8/CP437, eigener CRC32, Metadatenstatus, Limits,
ResultTable, Central und Uninstall wurden im Workflow
[32701896453](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/32701896453)
auf SQL Server 2019, 2022 und 2025 unter Linux erfolgreich geprüft. Die
automatisierte Windows-/Linux-Matrix 2019/2022/2025 war am 2026-09-01
ebenfalls erfolgreich. Reale Archive, echte Extremgrößen, Interoperabilität
und ein vollständiger Upgradepfad aus einem realen 1.1.0-Stand bleiben offen.

### Phase 2.8 – Windows Filesystem

**Status:** `completed`; Runtime `partially validated`

**Arbeitspaket:** `AP-2026-023`

Die Windows-only Capability `toolbelt.filesystem.windows` stellt über eine `EXTERNAL_ACCESS`-SQL-CLR-Assembly Lesen/Schreiben von Text und Binary, explizite Codepages und Transcoding, Directory-Listing/Erzeugung sowie begrenztes Löschen bereit. `Caller` ist der Default; `ServiceAccount` ist eine explizite Alternative. Linux ist technisch `not applicable`.

Windows-Build, Trust, Deployment, Help, SQL-Authentication-Ablehnung,
kontrollierte Caller-/ServiceAccount-Schreibpfade sowie Junction-List/-Delete
und ein begrenzter TOCTOU-Lauf sind nachgewiesen. Die breitere
NTFS-/I/O-/Codepage-/Limit-Matrix bleibt als getrennte Releasequalifikation
offen.

### Phase 2.9 – Error Envelope

**Status:** `completed`; Runtime `validated`

`toolbelt.core.error-envelope` standardisiert explizit aus einem CATCH
übergebene Fehlerdaten, ohne `THROW;` oder persistentes Logging zu ersetzen.
Evidence: https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30699604948.

### Phase 2.10 – Execution Context

**Status:** `completed`; Runtime `validated`

`toolbelt.core.execution-context` verwaltet Execution-ID, Correlation-ID,
Actor, Tenant und verschachtelten ScopeDepth über `SESSION_CONTEXT`.
Evidence: https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30699604948.

### Phase 2.11 – Work-Type-Katalog

**Status:** `completed`; Runtime `validated`

`toolbelt.core.work-type` registriert ausschließlich vorhandene Stored
Procedures, schließt Raw SQL aus und schützt Änderungen mit expliziten Flags
und `rowversion`. Die erste persistente Tabellenkonvention ist in
`DEC-2026-025` festgehalten.
Evidence: https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30703339193.

### Phase 2.12 – Synchrone zweite Session

**Status:** `completed`; Runtime `validated`

`toolbelt.core.second-session` führt registrierte Work Types synchron über
einen administrativ vorbereiteten Loopback-Linked-Server in einer getrennten
Session aus. Raw SQL und im Modul gespeicherte Credentials bleiben
ausgeschlossen. Die vollständige Plattformmatrix ist auf physischen
SQL-Server-2019-/2022-/2025-Zielen unter Windows base und Linux latest
einschließlich Provider-, Transaktions- und Konkurrenzverträgen erfolgreich.

### Phase 2.13 – Rollback-independent Event Log

**Status:** `completed`; Runtime `validated`

`toolbelt.core.event-log` persistiert strukturierte Events über die synchrone
zweite Session. Caller-Rollback, uncommittable Caller, Context, Retention und
Konkurrenz sind auf physischen SQL-Server-2019-/2022-/2025-Zielen unter
Windows base und Linux latest nachgewiesen.
Evidence: https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/31018284410.

## Phase 3 – Schlanke Test-Infrastruktur und CI

**Status:** `in progress`

**Abhängigkeit:** mindestens ein implementiertes Modul mit konkreten Testpfaden.

Der inkrementelle Dokumentations- und Change-Impact-Validator sowie die
capability-spezifische ResultTable-Runtime-Matrix bilden den ersten vertikalen
Slice. Weitere Module registrieren ihre gekoppelten Artefakte im Manifest und
ihre Impact-Pfade in `.ai/repo_map.yaml`. Reine Dokumentationsänderungen lösen
keine pauschale Runtime-Vollmatrix aus.

### Phase 4.1 – V0 Releasevalidierung in drei Slices

**Status:** `in progress`; am 2026-08-28 ausdrücklich freigegeben

**Aktuelles Runtime-Gate:** Der über die vorgesehenen Umgebungsvariablen
ermittelte SQL_Server_Lab-Vertrag ist schema-valide. Die vollständige
automatisierte Matrix auf SQL Server 2019/2022/2025 unter Windows base und
Linux latest war am 2026-09-01 erfolgreich. Seit der ausdrücklichen
Benutzerfreigabe vom 2026-08-29 dürfen bei Bedarf aus `groupStatus =
INCOMPLETE` explizit ausgewählte Einzelziele mit `runtimeStatus = READY` und
geeignetem Eintragsstatus verwendet werden. Das Toolbelt-Projekt startet,
repariert oder löscht keine Lab-Ressourcen selbst.

- `V0a`: alle 24 portablen beziehungsweise Linux-fähigen Module auf physischen
  SQL-Server-2019-, 2022- und 2025-Engines prüfen. Der lokale Lab-Adapter
  verwendet die vorhandenen Runtime-Suites; `toolbelt.file.content` benötigt
  separat bereitgestellte synthetische serverseitige Fixtures.
- `V0b`: die portable V0c-Kohorte vollständig auf Windows 2019, 2022 und 2025
  prüfen und die Hochrisikofälle für CLR, Filesystem, ResultTable, File
  Content, Second Session und Event Log mit synthetischen Daten und
  abstrahierter Evidenz ergänzen.
- `V0c`: eine veröffentlichungsfertige Kohorte aus den 16 Modulen
  `toolbelt.core.result-table`, `toolbelt.conversion.base64`,
  `toolbelt.core.generate-series`, `toolbelt.metadata.identifier`,
  `toolbelt.string.split-characters`, `toolbelt.validation.semantic-version`,
  `toolbelt.conversion.integer-base`, `toolbelt.datetime.calendar-difference`,
  `toolbelt.string.directional-trim`, `toolbelt.conversion.uri-component`,
  `toolbelt.datetime.truncate`, `toolbelt.datetime.bucket`,
  `toolbelt.binary.bit-operations`, `toolbelt.json.path-exists`,
  `toolbelt.core.console-message` und
  `toolbelt.metadata.capability-catalog` vorbereiten. Versionierte
  Artefakte, unterstützte Upgrades, Wiederholungsdeployment, Central und
  Uninstall gehören zum Pflichtscope. Bis zur tatsächlichen autorisierten
  Veröffentlichung bleibt `release_status: unreleased`.

V0 verändert keine öffentlichen SQL-Signaturen oder fachlichen Verträge.
Neue Q1-/D1-Runtime-Objekte bleiben außerhalb dieser Freigabe.

Nachqualifikation 2026-10-19: Die 16 V0c-Module bestanden die aktuelle vollständige Fachmatrix auf allen sechs Windows-/Linux-Zielkombinationen. Nach zusätzlichen Client-, Minimalrechte- und zentralen Statusprüfungen sind nach den zusätzlichen Pflicht-Lastfällen alle 16 Module `validated`; Zeitmessungen sind gemäß ausdrücklicher Benutzerentscheidung optional. Alle Module bleiben `unreleased`. Voraussetzungen und Wiederaufnahme stehen im [V0c-Gatebericht](../Tests/V0C_RELEASE_GATE_STATUS.md).

### Phase 4.2 – Q1 Lifecycle- und Upgrade-Automation

**Status:** `completed` für den eng begrenzten V1-Scope

Zuerst `RI-2026-142` als Migration-Idempotency-Verifier begrenzen. Golden
Snapshots und Contract-Test-Generierung folgen erst, wenn mehrere Module einen
nachweisbar gemeinsamen stabilen Vertrag besitzen.

`Q1` ist damit ein Qualitätsbaustein, aber keine neue nutzerorientierte
SQL-Capability. Parallel zu einer Nutzerfunktion darf höchstens ein solcher
Qualitäts-Enabler aktiv sein.

V1 ist als repository-interner SQLCMD-Verifier für ein isoliertes,
dependency-freies und zustandsloses T-SQL-Modul implementiert. Der effektive
Katalog wird vor und nach dem Wiederholungsdeployment verglichen; zwei
unabhängige Uninstall-Sitzungen und eine Restzustandsprüfung schließen den
Lauf ab. Die physische SQL_Server_Lab-Matrix war am 2026-08-29 auf SQL Server
2019, 2022 und 2025 jeweils unter Linux und Windows erfolgreich. Alle
synthetischen Testdatenbanken wurden entfernt; die Lab-Systeme wurden weder
gestartet noch beendet. Tabellen-/Zustands-, historische Upgrade-, Central-
und Parallelitätsslices bleiben außerhalb von V1.

### Phase 4.3 – D1 Date Spine V1

**Status:** `implemented`; Runtime `validated`, Release `unreleased`

`RI-2026-079` nutzt die vorhandenen Generate-Series- und Truncate-Primitiven;
Datetime Bucket ist keine künstliche Dependency. Version 1 bleibt auf drei
relationale Inline TVFs für Tag, ISO-Woche und Monat mit halboffenen Grenzen
und ohne Feiertags-, Zeitzonen- oder persistente Kalenderdimension begrenzt.

`D1` wurde als nächste eigentliche nutzerorientierte Funktionswelle gewählt. Gegenüber
JSON-Konstruktion, Regex und Work Queue besitzt sie die kleinste bereits
vorhandene Dependency-Closure, eine portable T-SQL-Basis und die begrenzteste
Provider-, Security- und Recovery-Fläche. Der Vertrag wurde am 2026-08-30
besprochen und anschließend ausdrücklich freigegeben. Der vollständige
Adapter ist auf physischen SQL-Server-2019-/2022-/2025-Zielen unter Windows
base und Linux latest erfolgreich. Feiertage, Arbeitstage, Zeitzonen, DST,
Locale-Texte, Geschäfts- und Fiskalkalender sowie persistente
Kalenderdimensionen bleiben außerhalb von V1.

### Phase 4.4 – R1 Regex V1

**Status:** `R1a research completed`; R1b `implemented`, Runtime `validated`, Release `unreleased`

R1a hat die native SQL-Server-2025-RE2-Semantik und die Provideroptionen ohne
Runtime-API geprüft. `REGEXP_INSTR` und `REGEXP_COUNT` sind auf der physischen
2025-Linux-Engine unter Compatibility 150/160/170 erfolgreich;
`REGEXP_LIKE` benötigt 170. Der .NET-Framework-4.8-Regexkern ist wegen
Semantikabweichungen und Backtracking kein Paritätsprovider. Native
RE2-Wrapper benötigen plattformspezifischen nativen Code und scheitern am
portablen `SAFE`-/Linux-Gate. Deshalb ist kein Runtime-Provider ausgewählt.

R1b verwendet nach der Benutzerentscheidung einen ausdrücklich engeren
Toolbelt-Dialekt über `SAFE` SQL CLR und stellt IsMatch, Instr und Count bereit.
Der Provider verspricht keine RE2-Parität oder lineare Laufzeit und erzwingt
Parser-, Größen- und Timeoutgrenzen. Die vollständige physische Matrix SQL
Server 2019/2022/2025 unter Windows base und Linux latest ist erfolgreich.
Replace, Substring, Split, Captures und Matches bleiben getrennte
Erweiterungen; Fuzzy Matching bleibt zurückgestellt.

Einzelfreigabe 2026-10-01, Nachweis 2026-10-02: Regex 1.3.0 implementiert
sämtliche Capture-Wiederholungen und getrenntes Gruppen-Replace. Die später
ausdrücklich freigegebene erwartete Binaryhashbindung ersetzt die unzuverlässige
CLR-Versionsableitung. Finale Gesamtadapter auf Linux 2019/latest CL150 und
Windows 2025/CU8 CL150/160/170 lokal/zentral einschließlich echtem 1.2-Upgrade,
Lifecycle und eigenem Cleanup erfolgreich. Capture-Minimalrechte, übrige Ziele,
ältere Capture-Upgrades und große SQL-Ausgabe bleiben offen. Die aktuelle CI
wird separat als PR-Mergegate nachgewiesen;
teilweise validiert und unveröffentlicht.

### Phase 4.5 – E1 Work Queue in vertikalen Slices

Nachfolgerwelle 2026-10-02: Der am 2026-10-01 einzeln freigegebene erste
[externe Worker](../Documentation/Architecture/EXTERNAL_QUEUE_WORKER_CONTRACT.md)
ist `implemented`, Runtime `partially validated`, Release `unreleased`.
Bestehende SQL-APIs, ein Supervisor mit 1–8 Slots und kooperative
Cancellation/Drain sind umgesetzt. Die Windows-Host-Labtests gegen 2019
Linux/latest und 2025 Windows/CU8 bestehen; Linux-Host-CI gegen eine eigene
synthetische SQL-2019-Instanz ist ebenfalls erfolgreich.
Einzeln abgegrenzte offene Nachweise stehen in der Worker-Testmatrix.
Dauerbetrieb, persistente Registrierung sowie Agent/Broker bleiben getrennt.

**Status:** Work Queue 2.0.0 `implemented`, Runtime `validated`,
Release `unreleased`; E1d ist als W6d separat implementiert und validiert

Die bereits implementierten Grundlagen Work Type, Error Envelope, Execution
Context und Second Session tragen vier getrennte Slices: `E1a`
Claim/Complete/Fail, `E1b` Lease/Orphan Recovery, `E1c` Retry/Dead Letter/
Idempotenz, `TC-2026-048` priorisierte Gruppen-Barriers und `E1d` kooperative
Cancellation. Kein Slice autorisiert Raw SQL, automatisches `KILL` oder einen
externen Worker.

E1a umfasst als nutzbaren vertikalen Slice zusätzlich Enqueue und
Statusoberflächen. Der atomare tokengebundene Claim, Caller-Transaktionen,
Parallelität, Lifecycle und Central sind auf physischen Linux-Engines
2019/2022/2025 erfolgreich. Windows blieb im SQL-Anmeldungs-Preflight
`not executed`. E1b ergänzt eine begrenzte Lease, Heartbeat, explizite
Recovery, monotone Ownership-Generationen und ein vor aktiven E1a-Claims
geschütztes Upgrade auf 1.1.0. Die vollständige physische Matrix auf SQL Server
2019/2022/2025 unter Windows base und Linux latest ist erfolgreich. Recovery
bleibt manuell und begründet keine Exactly-once- oder Idempotenzzusage. W6c
ist als Work Queue 2.0.0 implementiert und enthält Retry und Dead Letter mit
expliziter Workerentscheidung sowie priorisierte gruppenbezogene
Drain-Barriers. Die Matrix 2019/2022/2025 unter Windows und Linux ist
erfolgreich. E1d bleibt getrennt: W6d implementiert ausschließlich persistierte
kooperative Cancellation ohne `KILL`, automatische Queue-Mutation oder
Provider-Abbruch. Der Benutzer hat diesen Scope am 2026-09-11 ausdrücklich
freigegeben; die betroffene Windows-/Linux-Runtime-Matrix ist erfolgreich.

### Phase 4.6 – R2025 GA-Delta-Research

**Status:** `completed research`; keine Implementierungsfreigabe

UNISTR, PRODUCT, DATEADD mit `bigint` und Vector-Scalar-Funktionen werden gegen
vorhandene Kandidaten dedupliziert und nur bei belegter Lücke formalisiert.
Vector Index/Search, Fuzzy Matching und JSON-Aggregate bleiben bis zu einer
erneuten Primärquellenprüfung ihres Previewstatus außerhalb einer
Implementierungswelle.

Die [Delta-Recherche vom 2026-09-11](../Documentation/Research/SQL_SERVER_2025_DELTA_2026-09-11.md)
formalisiert keinen neuen Implementierungskandidaten: `UNISTR` bleibt ein
potenzieller eigener Interoperabilitätsslice; `PRODUCT`, `DATEADD bigint` und
Vector-Scalar-Funktionen haben keine belegte portable Lücke. Vector Search
bleibt Preview.

## Repository-Grenze

Analyse-, Diagnose-, Performance-, Konfigurations- und Security-Assessment-Ideen für `gecompat/SQL_Server_Analyze` werden nur in `Backlog/SQL_SERVER_ANALYZE_CANDIDATES.md` gesammelt und nicht hier implementiert.

`toolbelt.string.edit-distance` 1.0.0 ergänzt die genau zwei freigegebenen Distanz-TVFs mit eigenem portablem SAFE-CLR-Provider. Der Vor-Source-Vertrag und die zusätzliche Providerfreigabe sind dokumentiert. Offline Framework-/Matrixprüfungen und Releasebuild bestanden. Finale Gesamtadapter am 2026-10-02 auf Linux 2019/latest CL150 und Windows 2025/CU8 CL150/160/170 jeweils lokal/zentral sowie separatem SC-UTF8-Consumer bestanden. API-/Budget-/1000-Paar-/Client- und InstalledMetadata-, NULL-Modemarker-, AppLock-, Caller-TX/SET-, post-DROP-Rollback-, Kollisions-/Dependency-, Reinstall-/Uninstall- und eigene Bereinigungsorakel erfolgreich; Konfigurations- und Rechteänderungen jeweils 0. Tatsächliche Minimalrechte, übrige physische Ziele und Heap-/Produktionskapazität sind nicht nachgewiesen; aktuelle CI wird als separater PR-Mergegate nachgewiesen. Teilweise validiert und unveröffentlicht.


## XLSX-Typinterpretation – gezielte Qualifikation 2026-10-02

XLSX 1.1.0 ergänzt die einzeln freigegebene `TVF_InterpretXlsxCell` im bestehenden SAFE-Provider. Der finale öffentliche Typadapter bestand am 2026-10-02 auf SQL Server 2019 Linux/latest CL150 und 2025 Windows/CU8 CL150/160/170 jeweils lokal und zentral: drei Types-Runtime-Fixtures, exakte Zahlen-/100-ns-/NULL-/Clientmetadaten, clean/genuine 1.0/Repeat, Caller-TX OFF/ON intakt und doomed, AppLock, postDROP/preCOMMIT-Rollback, historische Zukunftsslots, Sichtbarkeitsprädikate, Uninstall und eigene Bereinigung. Raw→Type-Komposition wurde nach den API-CL-Schleifen auf der jeweils letzten CL (2019:150, 2025:170) sowie separat im zentralen Caller geprüft. Keine Konfigurations- oder Rechteänderungen. Die öffentliche Pfadfassung bestand nach ihrem unabhängig geprüften Port auf beiden ausgewählten Targets einschließlich frischer eigener Bereinigungsprüfungen. Aktuelle CI wird separat am exakten PR-Head als Mergegate geprüft. Tatsächliche Minimalrechte, weitere physische Ziele und Heap-/Produktionskapazität bleiben offen. `partially validated`, `unreleased`; historische Raw-1.0-Evidenz bleibt getrennt.
