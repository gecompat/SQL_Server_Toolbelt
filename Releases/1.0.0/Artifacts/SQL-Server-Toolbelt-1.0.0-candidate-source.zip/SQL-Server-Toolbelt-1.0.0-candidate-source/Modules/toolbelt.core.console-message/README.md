# Console Message

Nachqualifikation 2026-10-19: Der vollständige aktuelle Moduladapter bestand auf SQL Server 2019/2022/2025 unter Windows und Linux. Zusätzliche ADO.NET- und ODBC/sqlcmd-Prüfungen decken den Client-/Treiber-Gate im bestehenden Enginevertrag ab. Runtime: `validated`; Release: `unreleased`. Die folgenden datierten älteren Abschnitte beschreiben ihren damaligen Stand. Details: [V0c-Gatebericht](../../Tests/V0C_RELEASE_GATE_STATUS.md).

Plattform-Evidenz 2026-09-01: `local: Tests/CI/run-lab-local.ps1` war auf physischen SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und Linux latest erfolgreich; zusätzliche Client-/Treiber-, Buffering- und Framing-Evidenz war damals offen. Der damalige Modulstatus war `partially validated`. Dieser Nachweis ersetzt frühere offene Windows-Aussagen; datierte ältere Einträge bleiben historische Evidenz.

V0a-Evidenz 2026-08-29: `local: Tests/CI/run-lab-local.ps1` belegt
ausschließlich den im Modulmanifest genannten physischen Linux-Scope; offene
Windows- und modulspezifische Fälle bleiben unberührt.

**Modul-ID:** `toolbelt.core.console-message`
**Version:** `1.0.0`
**Implementierungsstatus:** `implemented`
**Validierungsstatus:** `validated`
**Release-Status:** `unreleased`

## Zweck

Das Modul gibt lange Unicode-Texte vollständig und geordnet im
SQL-Server-Messages-Kanal aus. Der Aufrufer wählt gepuffertes `PRINT` oder
unmittelbares `RAISERROR ... WITH NOWAIT`.

## Öffentliches Objekt

| Objekt | Typ | Zweck |
|---|---|---|
| `toolbelt_core.USP_WriteConsoleMessage` | USP | Unicode-sichere, gechunkte Console-Ausgabe ohne fachliches Resultset. |

## Abhängigkeiten

Keine Runtime-Modulabhängigkeit.

## Deployment

`Deployment/Deploy.sql` benötigt die SQLCMD-Variable
`DeploymentMode=local|central`. Lokales und zentrales Deployment verwenden
dieselbe Implementierung. Zentral installierte Procedures werden mit
dreiteiligem Namen ausgeführt.

## Vertrag

- `nvarchar(max)`-Payload;
- `PRINT` mit höchstens 4.000 UTF-16-Codeunits je Chunk;
- `RAISERROR(N'%s', 0, 1, ...) WITH NOWAIT` mit höchstens 2.000
  UTF-16-Codeunits;
- Supplementary Characters werden nicht zwischen Chunks getrennt;
- `NULL` und Leertext erzeugen keine Ausgabe;
- keine Präfixe, Zeitstempel, Severity-Optionen oder Resultsets.

Der Client kann Message-Frame-Grenzen optisch als zusätzliche Zeilen
darstellen. Die Procedure ist nicht für zeilenweise Hot-Path-Ausgabe gedacht.

## Dokumentation

- [Objektseite](Documentation/USP_WriteConsoleMessage.md)
- [Architekturvertrag](../../Documentation/Architecture/CONSOLE_MESSAGE_MODULE_DESIGN.md)
- [Beispiele](Examples/ConsoleMessage.sql)
- [Testmatrix](Tests/CONSOLE_MESSAGE_CONTRACT_TEST_MATRIX.md)

Die GitHub-hosted
[W2c-Runtime 30573135975](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30573135975)
war auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170
einschließlich Langtext-, Unicode-, Provider-, Wiederholungs-, Lifecycle-,
Central- und Uninstall-Contracts erfolgreich.

Der vollständige Adapter ist seit 2026-08-29 zusätzlich auf physischen
SQL-Server-2019-, 2022- und 2025-Linux-Zielen erfolgreich. Die Windows-Matrix und die zusätzlichen ADO.NET-/ODBC-Clientfälle sind
seit der Nachqualifikation vom 2026-10-19 erfolgreich belegt.

## SQL Server Lab Project Adapter

Der [Project Adapter](TestLab/ProjectAdapter/README.md) implementiert den
ADP-008-Piloten für den Vertragsstand 0.1. Seine ausführbaren SQL-Dateien
werden deterministisch aus dem kanonischen Moduldeployment erzeugt. Der
identische Lifecycle aus Installation, versionsgleichem Update, Validierung
und markergebundenem Cleanup war am 2026-08-30 auf SQL Server 2025 Linux
getrennt unter Docker und Podman erfolgreich
(`local: SQL_Server_Lab Project Adapter 0.1`). Das Toolbelt-Repository verwaltet dabei keine
Lab-Infrastruktur; sein Runner bindet ausschließlich einen bereits
bereitgestellten Lab-Run.

## Aktuelle Validierungsevidenz

<!-- BEGIN GENERATED:MODULE_EVIDENCE -->
- Datum: `2026-10-19`
- Nachweis: `local: Tests/CI/run-lab-local.ps1`
- Scope: Physische SQL Server 2019/2022/2025 unter Windows mit freigegebenen CU-Äquivalenten zu base und Linux latest; vollständiger lokaler/zentraler Moduladapter, versionsabhängige CL150/160/170, Lifecycle und Uninstall; Security-Grenzen und ODBC/sqlcmd-Ausgabe; zusätzlich run-console-clients-lab.ps1 mit ADO.NET-Frames, Unicode, atomarer Ablehnung und NOWAIT-Beobachtung auf allen sechs Zielen
- Ergebnis: `success`
<!-- END GENERATED:MODULE_EVIDENCE -->

## Freigegebene Security-Härtung 2026-10-15

SC-038: Nachricht höchstens1 MiB UTF-16 und512 Frames; Prüfung vor erster PRINT-/NOWAIT-Ausgabe. Keine Kürzung. NULL/Leer bleiben ohne Ausgabe und Hilfe bleibt vor Grenzprüfung. Fehler52801/52802.

Details und abgegrenzte Nachweise: [Security-Härtung](../../Documentation/Architecture/SECURITY_HARDENING_2026_10.md).
