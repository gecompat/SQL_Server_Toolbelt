# Generate-Series-Contract-Testmatrix

Abnahmeänderung 2026-10-19: Große Lastfälle mit Ergebnisprüfung sind Pflicht; Laufzeitmessungen sind optional und kein Validierungs- oder Release-Gate. Maßgeblich ist [DEC-2026-036](../../../Documentation/Architecture/DECISIONS.md#dec-2026-036-verpflichtende-lasttests-und-optionale-laufzeitmessungen). Ältere datierte Aussagen zur verpflichtenden Performance-Abnahme beschreiben den damaligen Vertrag.

Plattform-Evidenz 2026-09-01: `local: Tests/CI/run-lab-local.ps1` war auf physischen SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und Linux latest erfolgreich; breitere Very-large-series-Performance-Evidenz bleibt offen. Der Modulstatus bleibt `partially validated`. Dieser Nachweis ersetzt frühere offene Windows-Aussagen; datierte ältere Einträge bleiben historische Evidenz.

V0a-Evidenz 2026-08-29: `local: Tests/CI/run-lab-local.ps1` belegt
ausschließlich den im Modulmanifest genannten physischen Linux-Scope; offene
Windows- und modulspezifische Fälle bleiben unberührt.

## Status

Die Matrix ist der Pflichtscope für `toolbelt.core.generate-series` Version
`1.0.0`. Der
[Generate-Series-Runtime-Lauf 30496759324](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30496759324)
war für die SQL-Server-2025-Linux-Matrix erfolgreich. Der Modulstatus ist
`partially validated`.

## Funktionsvertrag

| Dimension | Pflichtfälle |
|---|---|
| Signatur | Schema, Name, Inline-TVF-Typ, Parameterreihenfolge, Typen, Default und `Value`-Typ |
| Richtung | aufsteigend, absteigend und widersprüchliche Schrittweite |
| Grenze | Start enthalten; erreichbarer und nicht erreichbarer Stopwert |
| NULL | `NULL` bei Start/Stop; `NULL` und `DEFAULT` bei Schritt |
| Fehler | Schritt `0`; Vorrang dieses Fehlers; Zeilenzahl außerhalb `bigint` |
| Datentypen | `int`, `bigint` und Grenzwerte beider Typen |
| Größen | eine Million synthetische Werte |
| Performance (optional) | zehn Millionen synthetische Werte; drei unabhängige Serien mit je einem Warm-up und fünf Messwiederholungen; jede Serie liefert einen Median. Nur bei höchstens 20 % Streuung zwischen den Serien wird gegen eine lokal gehaltene Basis mit höchstens 20 % Median-Regression verglichen; beide Grenzen sind je Lauf überschreibbar. Ein optional beauftragter Nachweis läuft risikobasiert genau einmal auf einem reservierten oder ausreichend skalierten, lastkontrollierten SQL-Server-2025-/Compatibility-Level-170-Ziel. |
| Row Goal | äußerer `TOP (10)` gegen eine sehr große gültige Reihe |
| relationale Nutzung | typstabiler Join und korreliertes `CROSS APPLY` |
| native Parität | SQL Server 2025 bei Compatibility Levels 160 und 170 |
| Reihenfolge | keine implizite Ordnungszusage; Beispiele verwenden `ORDER BY` |

## Lifecycle

| Dimension | Pflichtfälle |
|---|---|
| Erstinstallation | leere Datenbank und vorbestehendes `toolbelt_core`-Schema |
| Wiederholung | dieselbe Version überschreibt lokale Framework-Änderungen |
| Kollision | frameworkfremdes Zielobjekt blockiert vor Mutation |
| interne Dependency | `TVF_GenerateSeriesInt` referenziert den `bigint`-Kern |
| Uninstall | Wrapper vor Kern; fremde Schemaobjekte bleiben |
| zentral | dreiteiliger Aufruf und ausdrückliche Uninstall-Bestätigung |

## Zielmatrix

| Engine/Plattform | Compatibility | Status |
|---|---:|---|
| SQL Server 2025 Linux | 150 | `validated` im genannten Run |
| SQL Server 2025 Linux | 160 | `validated` im genannten Run |
| SQL Server 2025 Linux | 170 | `validated` im genannten Run |
| SQL Server 2019 Linux | 150 | Vollständiger physischer Moduladapter unter Linux latest am 2026-09-01 erfolgreich |
| SQL Server 2022 Linux | 160 | Vollständiger physischer Moduladapter unter Linux latest am 2026-09-01 erfolgreich |
| Windows 2019/2022/2025 | passend | Vollständiger physischer Moduladapter unter Windows base am 2026-09-01 erfolgreich |

Die Compatibility-Matrix dient als schneller Syntax-, Planungs- und
Semantiktest. Sie ersetzt die gezielten physischen Versionsläufe vor einem
Release nicht.

Die physische Plattformmatrix ist mit dem im Modulmanifest dokumentierten
Nachweis vom 2026-09-01 erfolgreich. Die breitere
Very-large-series-Performance-Evidenz einschließlich eines belastbaren
Regressionsvergleichs bleibt offen; der Plattformnachweis begründet weder
eine vollständige Modulvalidierung noch eine Releasefreigabe.

## Datenschutz

Alle Grenzwerte, Bereiche und relationalen Testdaten sind synthetisch.
Runtime-Ausgaben und Runner-Eigenschaften werden nicht als Repository-Evidenz
gespeichert.

## Optionaler Performance-Vergleich

`Tests/Runtime/Performance.Workload.sql` verwendet die SQLCMD-Variablen
`PerformanceBaselineMedianMilliseconds` und
`PerformanceMaxMedianRegressionPercent` sowie
`PerformanceMaxBatchMedianVariancePercent`. Die Default-Grenzen betragen
jeweils `20`. Ein Basiswert `0` deaktiviert nur die Regressionsentscheidung,
nicht den synthetischen Workload oder das Stabilitäts-Gate. Überschreitet die
Batch-Streuung ihre Grenze, klassifiziert der Lab-Adapter den Vergleich als
`NOT_EXECUTED` mit `PERFORMANCE_STABILITY_UNAVAILABLE`; dies ist weder ein
bestandener Performance-Nachweis noch eine Statusaufwertung. Basis und
Messwerte bleiben beim Aufrufer und werden nicht gespeichert oder
veröffentlicht.

Der Benutzer hat dieses Stabilitäts-Gate am 2026-09-19 für den bestehenden
Generate-Series-Performancevertrag freigegeben. Es ändert weder den
öffentlichen SQL-Vertrag noch die bestehende Regressionsgrenze.

Der Benutzer entschied am 2026-10-10, dass Versions- oder Plattformwiederholungen
für Performance nur bei einem relevanten Programmzweig, Provider oder erwarteten
Engineunterschied erforderlich sind. Der T-SQL-Workload hat keinen solchen
eigenen Zweig; deshalb erfolgt eine optionale Messung auf SQL Server 2025 mit
Compatibility Level 170 auf einem reservierten oder ausreichend skalierten,
lastkontrollierten Ziel. Der Adapter kann dafür einmal kalibrieren und
unmittelbar danach unabhängig bestätigen; die Werte verbleiben flüchtig und
belegen nur Wiederholbarkeit auf diesem Ziel. Der Versuch auf dem gemeinsam
belasteten Entwicklungs-Docker-Host war `NOT_EXECUTED / PERFORMANCE_STABILITY_UNAVAILABLE` und wird nicht wiederholt.

## Aktuelle Validierungsevidenz

<!-- BEGIN GENERATED:MODULE_EVIDENCE -->
- Datum: `2026-10-19`
- Nachweis: `local: Tests/CI/run-lab-local.ps1`
- Scope: SQL Server 2025 Linux/latest CL170; vollständiger aktueller Moduladapter einschließlich Pflicht-Lastfall: zehn Millionen Werte mit Anzahl, Eindeutigkeit und Grenzen 1..10000000; lokales/zentral Deploy, Lifecycle, Uninstall und frischer eigener Cleanupaudit erfolgreich; ergänzt die unveränderte Sechs-Ziel-Fachmatrix. Laufzeitmessung optional und nicht ausgeführt gemäß DEC-2026-036
- Ergebnis: `success`
<!-- END GENERATED:MODULE_EVIDENCE -->

## Pflicht-Lastfall ab 2026-10-19

Generate Series: exakt zehn Millionen unterschiedliche Werte im Bereich 1..10000000.
[Load.Contract.sql](Runtime/Load.Contract.sql) läuft automatisch auf dem repräsentativen SQL-2025-/CL170-Ziel.
Keine Zeitmessung, Baseline oder Streuung entscheidet über dieses Ergebnisgate.
Die optionale Performanceprüfung behält ihre eigenen bisherigen Grenzen.
