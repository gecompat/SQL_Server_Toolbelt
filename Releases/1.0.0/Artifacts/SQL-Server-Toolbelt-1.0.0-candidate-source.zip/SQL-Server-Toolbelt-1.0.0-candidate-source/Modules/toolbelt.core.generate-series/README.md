# Portable Integer Series

Lastqualifikation 2026-10-19: Der vollständige Moduladapter einschließlich Pflicht-Lastfall (zehn Millionen Werte mit Anzahl, Eindeutigkeit und Grenzen 1..10000000) bestand auf SQL Server 2025 Linux/latest CL170. Zusammen mit der unveränderten Windows-/Linux-Fachmatrix gilt `validated`; Release bleibt `unreleased`. Optionale Laufzeitmessungen: `not executed`. [Aktuelle Abnahme](../../Tests/V0C_RELEASE_GATE_STATUS.md).

Abnahmeänderung 2026-10-19: Große Lastfälle mit Ergebnisprüfung sind Pflicht; Laufzeitmessungen sind optional und kein Validierungs- oder Release-Gate. Maßgeblich ist [DEC-2026-036](../../Documentation/Architecture/DECISIONS.md#dec-2026-036-verpflichtende-lasttests-und-optionale-laufzeitmessungen). Ältere datierte Aussagen zur verpflichtenden Performance-Abnahme beschreiben den damaligen Vertrag.

Historischer Zwischenstand vor der Abnahmeänderung am 2026-10-19: Der vollständige aktuelle Moduladapter bestand auf SQL Server 2019/2022/2025 unter Windows und Linux. Die abgegrenzte Performance-Abnahme bleibt offen; Runtime: `partially validated`, Release: `unreleased`. Die folgenden datierten älteren Abschnitte beschreiben ihren damaligen Stand. Details: [V0c-Gatebericht](../../Tests/V0C_RELEASE_GATE_STATUS.md).

Plattform-Evidenz 2026-09-01: `local: Tests/CI/run-lab-local.ps1` war auf physischen SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und Linux latest erfolgreich; breitere Very-large-series-Performance-Evidenz bleibt offen. Der Modulstatus bleibt `partially validated`. Dieser Nachweis ersetzt frühere offene Windows-Aussagen; datierte ältere Einträge bleiben historische Evidenz.

V0a-Evidenz 2026-08-29: `local: Tests/CI/run-lab-local.ps1` belegt
ausschließlich den im Modulmanifest genannten physischen Linux-Scope; offene
Windows- und modulspezifische Fälle bleiben unberührt.

**Modul-ID:** `toolbelt.core.generate-series`

**Version:** `1.0.0`

**Implementierung:** `implemented`

**Validierung:** `partially validated`

**Release:** `unreleased`

## Zweck

Das Modul schließt auf SQL Server 2019 und in Datenbanken unter Compatibility
Level 150 die Lücke zur nativen Funktion `GENERATE_SERIES`. Es stellt
portable, typstabile Inline TVFs für `int` und `bigint` bereit.

## Öffentliche Objekte

| Objekt | Typ | Schema | Zweck |
|---|---|---|---|
| `TVF_GenerateSeriesBigInt` | Inline TVF | `toolbelt_core` | gemeinsamer Kern für `bigint`-Reihen |
| `TVF_GenerateSeriesInt` | Inline TVF | `toolbelt_core` | typstabiler `int`-Wrapper über dem Kern |

## Vertrag

- `DEFAULT` oder `NULL` für `@Step`: `+1` aufsteigend, `-1` absteigend.
- Der Startwert wird eingeschlossen.
- Der Stopwert erscheint nur, wenn ihn die Schrittfolge erreicht.
- Eine widersprüchliche Schrittrichtung liefert keine Zeile.
- `NULL` bei Start oder Stop liefert keine Zeile.
- Schritt `0` erzeugt einen unveränderten Enginefehler.
- Es gibt keine garantierte Ergebnisreihenfolge und keine stille Kürzung.
- Version `1.0.0` unterstützt ausschließlich `int` und `bigint`.

Bei User-defined Functions muss für den Defaultparameter ausdrücklich
`DEFAULT` übergeben werden:

```sql
SELECT Value
FROM toolbelt_core.TVF_GenerateSeriesInt(1, 10, DEFAULT)
ORDER BY Value;
```

## Implementierung

Der gemeinsame `bigint`-Kern verwendet binär gestapelte konstante Rowsets und
einen durch die berechnete Zeilenzahl begrenzten Row Goal. Er benötigt weder
rekursive CTEs noch Systemkataloge, persistente Tabellen oder SQL CLR.
`decimal(38,0)` wird nur intern eingesetzt, um Arithmetik an
`bigint`-Grenzen sicher zu berechnen.

Die `int`-Funktion enthält keine zweite Reihenlogik. Sie ruft den Kern auf und
konvertiert dessen bereits typgültige Werte zu `int`.

## Deployment

Aus `Deployment/` im SQLCMD-Modus:

```sql
:setvar DeploymentMode local
:r .\Deploy.sql
```

`DeploymentMode` unterstützt `local` und `central`. Bei zentraler Installation
werden die Funktionen mit dreiteiligem Namen aufgerufen.

## Performance und Größen

Inline TVFs bleiben für den Optimizer sichtbar. Der Vertrag garantiert jedoch
weder einen bestimmten Execution Plan noch feste Cardinality Estimates,
Parallelität oder Laufzeit. Sehr große Reihen können erhebliche CPU-, Speicher-
und Clientkosten erzeugen und bleiben Verantwortung des Aufrufers.

Eine mathematische Zeilenzahl außerhalb des positiven `bigint`-Bereichs wird
nicht gekürzt, sondern führt zu einem unveränderten Engine-Overflow.

## Plattform- und Teststatus

Der
[Generate-Series-Runtime-Lauf 30496759324](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30496759324)
war auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170
erfolgreich. Er deckt Semantik, native Parität bei 160/170, Fehler und
Typgrenzen, eine Million Werte, einen äußeren Row Goal, Joins, `CROSS APPLY`
sowie lokale, zentrale und Lifecycle-Verträge ab. Der vollständige Adapter
ist am 2026-08-29 zusätzlich auf physischen SQL-Server-2019-, 2022- und 2025-Linux-Zielen
erfolgreich. Am 2026-09-01 war der vollständige automatisierte Moduladapter
auf physischen SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und
Linux latest erfolgreich. Wegen der weiterhin offenen breiteren
Very-large-series-Performance-Evidenz bleibt der Modulstatus
`partially validated`.

## Dokumentation

- [Moduldesign](../../Documentation/Architecture/GENERATE_SERIES_MODULE_DESIGN.md)
- [TVF_GenerateSeriesBigInt](./Documentation/TVF_GenerateSeriesBigInt.md)
- [TVF_GenerateSeriesInt](./Documentation/TVF_GenerateSeriesInt.md)
- [Contract-Testmatrix](./Tests/GENERATE_SERIES_CONTRACT_TEST_MATRIX.md)
- [Test-Evidenz](./Tests/README.md)

## Aktuelle Validierungsevidenz

<!-- BEGIN GENERATED:MODULE_EVIDENCE -->
- Datum: `2026-10-19`
- Nachweis: `local: Tests/CI/run-lab-local.ps1`
- Scope: SQL Server 2025 Linux/latest CL170; vollständiger aktueller Moduladapter einschließlich Pflicht-Lastfall: zehn Millionen Werte mit Anzahl, Eindeutigkeit und Grenzen 1..10000000; lokales/zentral Deploy, Lifecycle, Uninstall und frischer eigener Cleanupaudit erfolgreich; ergänzt die unveränderte Sechs-Ziel-Fachmatrix. Laufzeitmessung optional und nicht ausgeführt gemäß DEC-2026-036
- Ergebnis: `success`
<!-- END GENERATED:MODULE_EVIDENCE -->

## Freigegebene Security-Härtung 2026-10-15

SC-018: TVF_GenerateSeriesBigIntStatus berechnet die angeforderte Zeilenzahl exakt vor Expansion und begrenzt auf1000000 Zeilen. Alt-APIs bleiben mathematisch unverändert und nur für vertrauenswürdige Direktgrants vorgesehen. Bestehende untrusted Legacygrants werden nicht automatisch widerrufen; in solchen Installationen bleibt der Befund offen.

Details und abgegrenzte Nachweise: [Security-Härtung](../../Documentation/Architecture/SECURITY_HARDENING_2026_10.md).
