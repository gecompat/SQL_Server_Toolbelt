:On Error exit
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @VersionProperty sysname=N'Toolbelt.Module.toolbelt.conversion.uri-component.Version',@ModeProperty sysname=N'Toolbelt.Module.toolbelt.conversion.uri-component.DeploymentMode',@DeploymentMode nvarchar(16)=LOWER(N'$(DeploymentMode)'),@InstalledVersion nvarchar(64),@DependencyVersion nvarchar(64),@ProductMajorVersion int=TRY_CONVERT(int,SERVERPROPERTY(N'ProductMajorVersion'));
IF @ProductMajorVersion NOT IN(15,16,17) THROW 51220,N'Dieses Modul unterstützt ausschließlich SQL Server 2019, 2022 und 2025.',1;
IF @DeploymentMode NOT IN(N'local',N'central') THROW 51221,N'Die SQLCMD-Variable DeploymentMode muss local oder central sein.',1;
SELECT @DependencyVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=N'Toolbelt.Module.toolbelt.core.generate-series.Version';
IF @DependencyVersion<>N'1.0.0' OR OBJECT_ID(N'toolbelt_core.TVF_GenerateSeriesBigInt',N'IF') IS NULL THROW 51229,N'toolbelt.core.generate-series Version 1.0.0 muss vor diesem Modul in derselben Datenbank installiert sein.',1;
SELECT @InstalledVersion=TRY_CONVERT(nvarchar(64),value) FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty;
IF @InstalledVersion IS NOT NULL AND @InstalledVersion<>N'1.0.0' THROW 51223,N'Die installierte Modulversion ist diesem Deployment nicht bekannt.',1;
IF @InstalledVersion IS NULL AND EXISTS(SELECT 1 FROM sys.objects WHERE object_id IN(OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentEncode'),OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentDecode'),OBJECT_ID(N'toolbelt_conversion.SVF_UriComponentEncode'),OBJECT_ID(N'toolbelt_conversion.SVF_UriComponentDecode'))) THROW 51224,N'Ein Zielobjekt stammt nicht aus einem bekannten Toolbelt-Release.',1;
IF SCHEMA_ID(N'toolbelt_conversion') IS NOT NULL AND HAS_PERMS_BY_NAME(N'toolbelt_conversion',N'SCHEMA',N'ALTER')<>1 THROW 51222,N'Für toolbelt_conversion fehlt ALTER.',1;
IF HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE FUNCTION')<>1 THROW 51222,N'In der Installationsdatenbank fehlt CREATE FUNCTION.',1;
IF OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentEncodeStatus') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentEncodeStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(256),value)=N'toolbelt.conversion.uri-component') THROW 51224,N'Neuer Security-Zielname ist frameworkfremd belegt.',1;
IF OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentDecodeStatus') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentDecodeStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId' AND CONVERT(nvarchar(256),value)=N'toolbelt.conversion.uri-component') THROW 51224,N'Neuer Security-Zielname ist frameworkfremd belegt.',1;
BEGIN TRANSACTION;
DECLARE @LockResult int;
EXEC @LockResult=sys.sp_getapplock @Resource=N'toolbelt.deploy.toolbelt.conversion.uri-component',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=0,@DbPrincipal=N'public';
IF @LockResult<0 THROW 51227,N'Ein paralleles Deployment dieses Moduls ist bereits aktiv.',1;
IF SCHEMA_ID(N'toolbelt_conversion') IS NULL
BEGIN
 EXEC sys.sp_executesql N'CREATE SCHEMA [toolbelt_conversion];';
 EXEC sys.sp_addextendedproperty @name=N'Toolbelt.Managed',@value=1,@level0type=N'SCHEMA',@level0name=N'toolbelt_conversion';
 EXEC sys.sp_addextendedproperty @name=N'Toolbelt.SchemaCategory',@value=N'conversion',@level0type=N'SCHEMA',@level0name=N'toolbelt_conversion';
END;
GO
:r ../Source/TVF_UriComponentEncode.sql
:r ../Source/TVF_UriComponentDecode.sql
:r ../Source/SVF_UriComponentEncode.sql
:r ../Source/SVF_UriComponentDecode.sql
SET NOCOUNT ON;
BEGIN TRY
 DECLARE @VersionProperty sysname=N'Toolbelt.Module.toolbelt.conversion.uri-component.Version',@ModeProperty sysname=N'Toolbelt.Module.toolbelt.conversion.uri-component.DeploymentMode';
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@VersionProperty) EXEC sys.sp_updateextendedproperty @name=@VersionProperty,@value=N'1.0.0'; ELSE EXEC sys.sp_addextendedproperty @name=@VersionProperty,@value=N'1.0.0';
 IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND major_id=0 AND minor_id=0 AND name=@ModeProperty) EXEC sys.sp_updateextendedproperty @name=@ModeProperty,@value=N'$(DeploymentMode)'; ELSE EXEC sys.sp_addextendedproperty @name=@ModeProperty,@value=N'$(DeploymentMode)';
IF NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentEncodeStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId') EXEC sys.sp_addextendedproperty @name=N'Toolbelt.ModuleId',@value=N'toolbelt.conversion.uri-component',@level0type=N'SCHEMA',@level0name=N'toolbelt_conversion',@level1type=N'FUNCTION',@level1name=N'TVF_UriComponentEncodeStatus';
IF NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=1 AND major_id=OBJECT_ID(N'toolbelt_conversion.TVF_UriComponentDecodeStatus') AND minor_id=0 AND name=N'Toolbelt.ModuleId') EXEC sys.sp_addextendedproperty @name=N'Toolbelt.ModuleId',@value=N'toolbelt.conversion.uri-component',@level0type=N'SCHEMA',@level0name=N'toolbelt_conversion',@level1type=N'FUNCTION',@level1name=N'TVF_UriComponentDecodeStatus';
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
