# ZIP Memory Inspection

Aktueller Release-1.4-Nachweis: `local: Modules/toolbelt.file.xlsx-memory/Tests/Runtime/Invoke-LabContract.ps1`, 2026-10-02, Linux 2019/latest und Windows 2025/CU8 erfolgreich; echte Upgradefixture, Writerregression und nichtdoomende Lifecycle-Callerablehnung. Historische Reader-/Writer-Matrix ersetzt keine weitere 1.4-Kapazitätsqualifikation.

Plattform-Evidenz 2026-09-01: `local: Tests/CI/run-lab-local.ps1` war auf physischen SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und Linux latest erfolgreich; reale Archive, echte Extremgrößen, historische Upgrades und Interoperabilität bleiben offen. Der Modulstatus bleibt `partially validated`. Dieser Nachweis ersetzt frühere offene Windows-Aussagen; datierte ältere Einträge bleiben historische Evidenz.

V0a-Evidenz 2026-08-29: `local: Tests/CI/run-lab-local.ps1` belegt
ausschließlich den im Modulmanifest genannten physischen Linux-Scope; offene
Windows- und modulspezifische Fälle bleiben unberührt.

**Modul-ID:** `toolbelt.archive.zip-memory`  
**Version:** `1.4.0`

Release 1.4.0 ergänzt ausschließlich die technische .NET-Fassade
`ZipEntryProvider.ArchiveSession` für den separat freigegebenen XLSX-Reader.
Sie verwendet den kanonischen ZIP-Parser, Payloadprüfungen und CRC32 ohne
Parserkopie. Es entsteht keine neue öffentliche ZIP-SQL-API; bestehende
Reader-/Writerverträge und Ressourcenparameter bleiben unverändert. Ein
referenzierender XLSX-Consumer blockiert den ZIP-Uninstall. Die echte
1.3→1.4-Assemblyhash-Upgradefixture und Writer-Vertragsregression auf Windows
2025/CU8 und Linux 2019/latest sind erfolgreich; dieser Scope ersetzt keine vollständige
Plattform-/Kapazitätsqualifizierung.

Deploy und Uninstall benötigen einen eigenen Transaktionsscope. Der frühe Guard lehnt vorhandene Caller-Transaktionen vor SET und DDL mit RAISERROR 50000 und `TBX_ZIP_LIFECYCLE_CALLER_TRANSACTION:` ab. Er verändert weder Caller-Arbeit noch XACT_ABORT und beschädigt den Scope auch bei XACT_ABORT ON nicht. SQLCMD beendet die Ablehnung über `:On Error exit` mit einem Fehlerstatus.

Release 1.3.0 ergänzt den ausdrücklich freigegebenen [ZIP-Writer](Documentation/USP_CreateZipFromEntries.md): lokale Entrytabelle des Aufrufers, Stored oder Deflate, konservative unabhängige Ressourcenlimits, Binary-Envelope und datenzugriffsfreier SAFE-CLR-Kern. Die Readervertragsgrenzen bleiben unverändert. Die neue Writerqualifikation ist getrennt von den nachfolgenden historischen Readernachweisen zu betrachten.

**Status:** `implemented`; `partially validated`

## Zweck

Das Modul listet deklarierte Metadaten aller Entries und extrahiert optional
genau einen benannten ZIP-Entry aus einem In-memory-ZIP-Container
(`varbinary(max)`) ohne Dateisystemzugriff. Der interne C#-SQL-CLR-Provider
unterstützt bei der Extraktion Compression Methods `0` (`Stored`) und `8`
(`Deflate`) sowie CRC32-Prüfung über den tatsächlichen Payload.

## Objekte

| Objekt | Rolle |
|---|---|
| `toolbelt_archive.USP_ExtractZipEntryFromBinary` | Einzige öffentliche Entry-Extraktions-API; Signatur gegenüber `1.0.0` unverändert. |
| `toolbelt_archive.USP_ListZipEntriesFromBinary` | Öffentliche Metadatenliste in Central-Directory-Reihenfolge; liest keine Payloads. |
| `toolbelt_archive.TVF_InternalExtractZipEntryClr` | Interner CLR-Provider. |
| `toolbelt_archive.TVF_InternalListZipEntriesClr` | Interner CLR-Metadatenprovider. |
| `Toolbelt_Archive_ZipMemory` | Modulspezifische `SAFE`-Assembly. |

## Abhängigkeit

`toolbelt.core.result-table` ab Version `1.0.0` wird für den optionalen
`@ResultTable`-Pfad benötigt.

Die geprüften Callerrechte der drei öffentlichen ZIP-Memory-USPs stehen im
[ZIP-Callerbericht](../../Releases/1.0.0/ZIP-CALLER-PROFILE.md). Der Bericht
begrenzt sich auf feste synthetische Werte und die dort genannten Objektprofile;
er ersetzt keine übrige Modul- oder Releasequalifikation.

## Build-, Trust- und Deploymentmodell

`Scripts/New-ClrReleaseArtifacts.ps1` erzeugt aus dem C#-Quellcode:

- `Toolbelt.Archive.ZipMemory.dll`;
- ein SHA2-512-Trust-Manifest;
- `Deploy.WithAssembly.sql` mit dem exakten Binary als SQL-Binäritliteral.

Trust ist ein separater administrativer Opt-in über
`Deployment/Add-TrustedAssembly.sql`. Der reguläre Installer prüft
`clr enabled`, `clr strict security` und den exakten Hash in
`sys.trusted_assemblies`, verändert diese Instanzzustände aber nicht.

Der Uninstall entfernt beide Procedures, beide internen CLR-TVFs und die
Assembly aus der Datenbank. Ein serverweiter Trust-Eintrag bleibt bewusst
bestehen.

## Providervertrag

- direkte Framework-Referenzen ausschließlich `System` und `System.Data`;
- `DeflateStream` aus `System.dll`;
- kein `ZipArchive` und keine direkte Referenz auf
  `System.IO.Compression.dll`;
- UTF-8-Entry-Namen bei Flag 11, sonst CP437;
- ordinaler case-sensitiver Namensvergleich;
- Local Header mit und ohne Data Descriptor;
- Duplicate-Name-, Header-, Größen-, Ratio- und CRC32-Prüfung.

Das Listing behält die Central-Directory-Reihenfolge bei, zählt exakte
Namensduplikate, markiert Directory-Einträge, unbekannte Methoden,
Verschlüsselung und unsichere Pfade und dekodiert DOS-Zeitstempel. Diese
Metadaten werden nicht durch Lesen des Payloads verifiziert.

Default-Limits:

- `@MaxEntryBytes = 104857600`;
- `@MaxCompressionRatio = 200.00`.

Harte Providerlimits:

- Archiv `268435456` Bytes;
- komprimierter Entry `134217728` Bytes;
- maximal `10000` untersuchte Entries.

## Nicht unterstützt

ZIP64, Multi-Disk, Verschlüsselungsentschlüsselung, Deflate64, andere Methods,
Archiv-Erzeugung, Multi-Entry-, Verzeichnis- und rekursive Extraktion sowie
Dateisystem-, Netzwerk- oder Prozesszugriff.

## Dokumentation

- Objekt: `Documentation/USP_ExtractZipEntryFromBinary.md`
- Objekt: `Documentation/USP_ListZipEntriesFromBinary.md`
- Architektur: `../../Documentation/Architecture/ZIP_ARCHIVE_MODULE_DESIGN.md`
- CLR-Provider: `../../Documentation/Architecture/ZIP_CLR_PROVIDER_DESIGN.md`
- Tests: `Tests/`

## Teststatus

GitHub-Actions-Lauf `32701896453` war erfolgreich für Version `1.2.0`:

- Windows-.NET-Framework-4.8-Build;
- SQL Server 2019 Linux / Compatibility 150;
- SQL Server 2022 Linux / Compatibility 160;
- SQL Server 2025 Linux / Compatibility 150, 160 und 170;
- Stored, Deflate, Data Descriptor, UTF-8, CP437, CRC32, Fehlerverträge,
  Metadatenstatus für Duplikate, Verschlüsselung, Methoden, Directories, Pfade
  und DOS-Zeit, ResultTable, Upgrade-Marker, Wiederholungsdeployment, Central
  und Uninstall.

Der Extraktions- und Listingvertrag ist in der Linux-Zielversionsmatrix
erfolgreich. Windows-SQL-Server-Runtime, echte Extremgrößenläufe und eine
breitere Interoperabilitätsmatrix realer Archive bleiben vor Release offen.

Evidenz: https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/32701896453
und der lokale Lauf vom 2026-08-29 mit reproduzierbar neu gebautem, per
exaktem SHA2-512 autorisiertem Releaseartefakt.

## Aktuelle Validierungsevidenz

<!-- BEGIN GENERATED:MODULE_EVIDENCE -->
- Datum: `2026-10-02`
- Nachweis: `local: Modules/toolbelt.file.xlsx-memory/Tests/Runtime/Invoke-LabContract.ps1`
- Scope: Release 1.4.0: finaler identischer Linux-2019-/Windows-2025-CU8-Adapter nach EOF-Pflege; echte ZIP-1.3-Assemblyhash-Upgradefixture, bestehender Writer-SQL-Vertrag, SAFE local/central und nichtdoomende ZIP-Deploy/Uninstall-Callerablehnung OFF/ON. Unabhängige Framework-Writerregression erneut erfolgreich; übrige Kapazitäts-/Plattformmatrix offen.
- Ergebnis: `success`
<!-- END GENERATED:MODULE_EVIDENCE -->

## Freigegebene Security-Härtung 2026-10-15

SC-004: Entryextraktion verwendet standardmäßig 16777216 Bytes (16 MiB), höchstens 67108864 Bytes (64 MiB). Deklarierte und tatsächlich gelesene Größe werden geprüft. Ein exakt dimensionierter finaler Entrybuffer ersetzt wachsenden MemoryStream und ToArray-Abschlusskopie. Archiv-/Compressed-/Ratio-/CRC-Grenzen bleiben bestehen. Die technische ArchiveSession teilt die feste Entryobergrenze.

Details und abgegrenzte Nachweise: [Security-Härtung](../../Documentation/Architecture/SECURITY_HARDENING_2026_10.md).
