# Integer-Base Contract-Testmatrix

Vollständige Plattform-Evidenz 2026-09-01: `local: Tests/CI/run-lab-local.ps1` belegt den erfolgreichen Moduladapter auf physischen SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und Linux latest. Dieser Nachweis ersetzt frühere offene oder `not executed`-Aussagen; datierte ältere Einträge bleiben als historische Evidenz erhalten.

Wartung 2026-10-09: Plus als Alphabetziffer an unterschiedlichen Positionen,
Null/negative Werte, bigint-Grenzen und NULL-sichere positive Roundtrip- sowie
SVF-/TVF-Orakel sind neuer Impact-Scope. Quellenstand SOURCE_ONLY, neue
Runtimequalifikation NOT_EXECUTED. Die datierten Erfolgsnachweise und die
bisherigen Plattformzeilen unten behalten ihren historischen Umfang.

| Bereich | Fälle | Stand |
|---|---|---|
| Signatur | `bigint`, `varchar(93)`, `varchar(65)` | vorhanden |
| Alphabet | Länge 2/93, druckbares ASCII, binär eindeutig, kein `-` | vorhanden |
| Darstellung | Null, kein zusätzliches positives Vorzeichen, keine führenden Nullen, kein `-0`; `+` als Alphabetziffer | vorhanden |
| Basen | 2, 8, 10, 16, 36, 62 und 93 | vorhanden |
| Grenzen | vollständiger `bigint`-Bereich und Decode-Overflow | vorhanden |
| Roundtrip | positive, negative und Grenzwerte | vorhanden |
| API-Parität | SVF und inline TVF, exakt eine Zeile, `OUTER APPLY` | vorhanden |
| Upgrade | `1.0.0` auf `1.1.0`, Wiederholung, Kollision | vorhanden |
| Lifecycle | lokal, zentral, Drift, Kollision, Uninstall | vorhanden |
| SQL Server 2025 Linux 150/160/170 | Version `1.1.0` | `success` |
| SQL Server 2019/2022/2025 unter Windows base und Linux latest | Release-Matrix | erfolgreich |

Aktuelle Evidenz:
https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30535377860

## Aktuelle Validierungsevidenz

<!-- BEGIN GENERATED:MODULE_EVIDENCE -->
- Datum: `2026-10-19`
- Nachweis: `local: Tests/CI/run-lab-local.ps1`
- Scope: Physische SQL Server 2019/2022/2025 unter Windows mit freigegebenen CU-Äquivalenten zu base und Linux latest; vollständiger lokaler/zentraler Moduladapter, versionsabhängige CL150/160/170, Lifecycle und Uninstall; Plus als Alphabetziffer, bigint-Grenzen und NULL-/kardinalitätssichere Orakel einschließlich Upgrade von 1.0.0
- Ergebnis: `success`
<!-- END GENERATED:MODULE_EVIDENCE -->
