# toolbelt.conversion.integer-base

Nachqualifikation 2026-10-19: Der vollständige aktuelle Moduladapter bestand auf SQL Server 2019/2022/2025 unter Windows und Linux. Runtime: `validated`; Release: `unreleased`. Die folgenden datierten älteren Abschnitte beschreiben ihren damaligen Stand. Details: [V0c-Gatebericht](../../Tests/V0C_RELEASE_GATE_STATUS.md).

Vollständige Plattform-Evidenz 2026-09-01: `local: Tests/CI/run-lab-local.ps1` belegt den erfolgreichen Moduladapter auf physischen SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und Linux latest. Dieser Nachweis ersetzt frühere offene oder `not executed`-Aussagen; datierte ältere Einträge bleiben als historische Evidenz erhalten.

Kanonische Konvertierung des vollständigen `bigint`-Bereichs mit einem frei
definierbaren druckbaren ASCII-Alphabet.

Status: `implemented`, `validated`, `unreleased`.

Wartungsstand 2026-10-09: Die Korrektur der Plusziffer und die NULL-sicheren
positiven Contract-Orakel sind SOURCE_ONLY; ihre neue Runtimequalifikation ist
NOT_EXECUTED. Die folgenden datierten Nachweise gelten für ihre historischen
Quellstände und belegen keine neue Windows-/Linux- oder Vollmatrixqualifikation
der geänderten Quelle. Version `1.1.0` bleibt unveröffentlicht.

Öffentliche Objekte:

- `TVF_IntegerToBase` – kanonischer relationaler Encode-Kern;
- `TVF_TryBaseToInteger` – kanonischer relationaler Decode-Kern;
- `SVF_IntegerToBase` – codiert einen `bigint` als `varchar(65)`;
- `SVF_TryBaseToInteger` – decodiert eine kanonische Darstellung oder liefert
  `NULL`.

Die Basis ergibt sich aus der Alphabetlänge von 2 bis 93. Das erste Zeichen
steht für Null; `-` ist ausschließlich als Vorzeichen reserviert. Alphabet und
Ziffern werden binär geprüft, daher bleiben Groß- und Kleinschreibung
verschieden. `+` ist eine reguläre Ziffer, wenn es im gewählten Alphabet
enthalten ist; ein zusätzliches positives Vorzeichen wird nicht interpretiert.
Führende Nullzeichen, `-0`, Whitespace, unbekannte Zeichen und Overflow werden
abgelehnt. Mit dem Dezimalalphabet bleibt `+1` ungültig.

Das Modul hat keine Abhängigkeit zu Base64 oder anderen Toolbelt-Modulen.
Zwischenarithmetik mit `decimal(38,0)` deckt auch
`-9223372036854775808` sicher ab.

Modulversion `1.1.0` ergänzt die inline-TVF-APIs. Die vorhandenen SVFs
delegieren an diese Kerne. Für mengenorientierte Aufrufe sind die TVFs mit
`CROSS APPLY` oder `OUTER APPLY` zu bevorzugen. Die SVF-Wrapper sind bewusst
nicht schemagebunden, damit Wiederholungs- und Upgrade-Deployments die
kanonischen TVF-Kerne ersetzen können.

Aktuelle Evidenz:
[Integer-Base Runtime Run 30535377860](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30535377860)
war auf SQL Server 2025 Linux mit Compatibility Levels 150, 160 und 170
erfolgreich. Der vollständige Adapter ist am 2026-08-29 zusätzlich auf physischen
SQL-Server-2019-, 2022- und 2025-Linux-Zielen erfolgreich; Windows-Läufe
bleiben offen.

Siehe [Design](../../Documentation/Architecture/INTEGER_BASE_MODULE_DESIGN.md)
und [Testmatrix](./Tests/INTEGER_BASE_CONTRACT_TEST_MATRIX.md).

## Aktuelle Validierungsevidenz

<!-- BEGIN GENERATED:MODULE_EVIDENCE -->
- Datum: `2026-10-19`
- Nachweis: `local: Tests/CI/run-lab-local.ps1`
- Scope: Physische SQL Server 2019/2022/2025 unter Windows mit freigegebenen CU-Äquivalenten zu base und Linux latest; vollständiger lokaler/zentraler Moduladapter, versionsabhängige CL150/160/170, Lifecycle und Uninstall; Plus als Alphabetziffer, bigint-Grenzen und NULL-/kardinalitätssichere Orakel einschließlich Upgrade von 1.0.0
- Ergebnis: `success`
<!-- END GENERATED:MODULE_EVIDENCE -->
