# Base64-Contract-Testmatrix

Abnahmeänderung 2026-10-19: Große Lastfälle mit Ergebnisprüfung sind Pflicht; Laufzeitmessungen sind optional und kein Validierungs- oder Release-Gate. Maßgeblich ist [DEC-2026-036](../../../Documentation/Architecture/DECISIONS.md#dec-2026-036-verpflichtende-lasttests-und-optionale-laufzeitmessungen). Ältere datierte Aussagen zur verpflichtenden Performance-Abnahme beschreiben den damaligen Vertrag.

Wartung 2026-10-19: Der Roundtrip-Vergleich im Performance-Workload weist
unerwartetes `NULL` nun ausdrücklich ab. Das aus dem Workload extrahierte
Orakel bestand eine funktionale Prüfung mit NULL, abweichendem und korrektem
Binärwert auf SQL Server 2025 Linux, CL170. Der kontrollierte
Performance-Vergleich bleibt getrennt `not executed`.

Plattform-Evidenz 2026-09-01: `local: Tests/CI/run-lab-local.ps1` war auf physischen SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und Linux latest erfolgreich; breitere Large-LOB-Performance-Evidenz bleibt offen. Der Modulstatus bleibt `partially validated`. Dieser Nachweis ersetzt frühere offene Windows-Aussagen; datierte ältere Einträge bleiben historische Evidenz.

V0a-Evidenz 2026-08-29: `local: Tests/CI/run-lab-local.ps1` belegt
ausschließlich den im Modulmanifest genannten physischen Linux-Scope; offene
Windows- und modulspezifische Fälle bleiben unberührt.

## Status

Die Matrix ist der Pflichtscope für `toolbelt.conversion.base64` Version
`1.1.0`. Der
[SQL-Server-2025-Linux-Lauf 30535377837](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30535377837)
war für die Compatibility Levels 150, 160 und 170 erfolgreich.

## Funktionsvertrag

| Dimension | Pflichtfälle |
|---|---|
| Signatur | Schema, Name, Typ, Parameterreihenfolge, Typen und Encode-Default |
| Null/leer | `NULL`, leere Binärfolge und leerer Text |
| RFC-4648-Vektoren | `f`, `fo`, `foo`, `foob`, `fooba`, `foobar` |
| Alphabet | Standard und Base64URL; kanonische Encode-Ausgabe |
| Padding | vollständig, ausgelassen, zu viel, Daten nach Padding |
| Whitespace | Space, Tab, CR und LF; nicht freigegebener Whitespace als Fehler |
| Fehler | ungültiges Zeichen, Länge Rest eins und ungültiges Padding |
| Roundtrip | Encode → Decode für Standard und URL-safe |
| Größen | inline-TVF-Roundtrip mit 6.000, 6.001, 65.536 und 1.048.576 synthetischen Bytes; SVF-Parität bis 6.001 Bytes |
| Performance (optional) | 4 MiB synthetischer Large-LOB-Roundtrip; drei unabhängige Batches mit je Warm-up und fünf Messungen; Batch-Median-Spanne höchstens 20 %; Regression gegen optionale lokale Basis, je Lauf überschreibbar. Ein optional beauftragter Nachweis läuft risikobasiert genau einmal auf einem reservierten oder ausreichend skalierten, lastkontrollierten SQL-Server-2025-/Compatibility-Level-170-Ziel. |
| Native Parität | SQL Server 2025 als semantische Referenz |
| API-Parität | SVF und inline TVF für Normal-, Grenz-, `NULL`- und Fehlerfälle |
| Mengenverwendung | `OUTER APPLY`, exakt eine Ergebniszeile, Resultspalten |
| Sitzungsoption | direkter inline-TVF-Aufruf mit `QUOTED_IDENTIFIER ON` |

## Lifecycle

| Dimension | Pflichtfälle |
|---|---|
| Erstinstallation | leere Datenbank |
| Wiederholung | dieselbe Version überschreibt lokale Framework-Änderungen |
| Kollision | frameworkfremdes Zielobjekt blockiert vor Mutation |
| Upgrade | bekanntes Release `1.0.0` auf `1.1.0` |
| Uninstall | exakt vier Release-Funktionen; fremde Schemaobjekte bleiben |
| zentral | dreiteiliger Aufruf und ausdrückliche Uninstall-Bestätigung |

## Zielmatrix

| Engine/Plattform | Compatibility | Status |
|---|---:|---|
| SQL Server 2025 Linux | 150 | Version `1.1.0` erfolgreich |
| SQL Server 2025 Linux | 160 | Version `1.1.0` erfolgreich |
| SQL Server 2025 Linux | 170 | Version `1.1.0` erfolgreich |
| SQL Server 2019 Linux | 150 | Vollständiger physischer Moduladapter unter Linux latest am 2026-09-01 erfolgreich |
| SQL Server 2022 Linux | 160 | Vollständiger physischer Moduladapter unter Linux latest am 2026-09-01 erfolgreich |
| Windows 2019/2022/2025 | passend | Vollständiger physischer Moduladapter unter Windows base am 2026-09-01 erfolgreich |

Die Compatibility-Matrix dient als schneller Syntax-, Planungs- und
Semantiktest. Sie ersetzt die gezielten physischen Versionsläufe vor einem
Release nicht.

Die physische Plattformmatrix ist mit dem im Modulmanifest dokumentierten
Nachweis vom 2026-09-01 erfolgreich. Die breitere Large-LOB-Performance-Evidenz
einschließlich eines belastbaren Regressionsvergleichs bleibt offen; der
Plattformnachweis begründet weder eine vollständige Modulvalidierung noch
eine Releasefreigabe.

## Datenschutz

Alle Werte sind synthetisch. Decodierte Inhalte, Fehlerinputs und Runtime-
Ausgaben werden nicht als Repository-Evidenz gespeichert.

## Optionaler Performance-Vergleich

`Tests/Runtime/Performance.Workload.sql` verwendet die SQLCMD-Variablen
`PerformanceBaselineMedianMilliseconds` und
`PerformanceMaxMedianRegressionPercent` sowie
`PerformanceMaxBatchMedianVariancePercent`. Beide Grenzwerte haben standardmäßig
den Wert `20`. Der Workload bildet aus je fünf Messungen pro drei unabhängigen
Batches einen Batch-Median und prüft vor einer optionalen Regression, ob deren
Spanne stabil ist. Bei einer instabilen Spanne signalisiert der Adapter
`NOT_EXECUTED` mit `PERFORMANCE_STABILITY_UNAVAILABLE`; das Stabilitäts-Gate
kann keine Statusaufwertung begründen. Ein Basiswert `0` deaktiviert nur die
Regressionsentscheidung, nicht den synthetischen Workload oder das
Stabilitäts-Gate. Basis und Messwerte bleiben beim Aufrufer und werden nicht
gespeichert oder veröffentlicht.

Der Benutzer entschied am 2026-10-10, dass Versions- oder Plattformwiederholungen
für Performance nur bei einem relevanten Programmzweig, Provider oder erwarteten
Engineunterschied erforderlich sind. Der Workload verwendet den bestehenden
T-SQL/XML-Provider ohne eigenen Plattformzweig; deshalb erfolgt die offene
Evidenz auf SQL Server 2025 mit Compatibility Level 170 auf einem reservierten
oder ausreichend skalierten, lastkontrollierten Ziel. Der Adapter kann dafür
einmal kalibrieren und unmittelbar danach unabhängig bestätigen; die Werte
verbleiben flüchtig und belegen nur Wiederholbarkeit auf diesem Ziel.

## Aktuelle Validierungsevidenz

<!-- BEGIN GENERATED:MODULE_EVIDENCE -->
- Datum: `2026-10-19`
- Nachweis: `local: Tests/CI/run-lab-local.ps1`
- Scope: SQL Server 2025 Linux/latest CL170; vollständiger aktueller Moduladapter einschließlich Pflicht-Lastfall: exakter 4-MiB-Roundtrip mit NULL-, Längen- und Inhaltsorakeln; lokales/zentral Deploy, Lifecycle, Uninstall und frischer eigener Cleanupaudit erfolgreich; ergänzt die unveränderte Sechs-Ziel-Fachmatrix. Laufzeitmessung optional und nicht ausgeführt gemäß DEC-2026-036
- Ergebnis: `success`
<!-- END GENERATED:MODULE_EVIDENCE -->

## Pflicht-Lastfall ab 2026-10-19

Base64: exakter 4-MiB-Roundtrip mit NULL-, Längen- und Inhaltsprüfung.
[Load.Contract.sql](Runtime/Load.Contract.sql) läuft automatisch auf dem repräsentativen SQL-2025-/CL170-Ziel.
Keine Zeitmessung, Baseline oder Streuung entscheidet über dieses Ergebnisgate.
Die optionale Performanceprüfung behält ihre eigenen bisherigen Grenzen.
