# Base64 and Base64URL Conversion

Aktuelle [Callerrechte-Qualifikation](../../Releases/1.0.0/CONVERSION-CALLER-QUALIFICATION.md): einzelne SELECT-Grants für TVFs und EXECUTE-Grants für Scalarwrapper, lokal/direkt zentral auf zwölf Ziel-/CL-Kombinationen. Die ältere pauschale SELECT-/REFERENCES-Formulierung im Manifest ist für Scalarwrapper veraltet; ihr gebundener Metadaten-/Paketrefresh bleibt separat offen. Andere Fach-/Lifecycle-/CrossDB-Gates und Modulstatus werden dadurch nicht erweitert.

Lastqualifikation 2026-10-19: Der vollständige Moduladapter einschließlich Pflicht-Lastfall (exakter 4-MiB-Roundtrip mit NULL-, Längen- und Inhaltsorakeln) bestand auf SQL Server 2025 Linux/latest CL170. Zusammen mit der unveränderten Windows-/Linux-Fachmatrix gilt `validated`; Release bleibt `unreleased`. Optionale Laufzeitmessungen: `not executed`. [Aktuelle Abnahme](../../Tests/V0C_RELEASE_GATE_STATUS.md).

Abnahmeänderung 2026-10-19: Große Lastfälle mit Ergebnisprüfung sind Pflicht; Laufzeitmessungen sind optional und kein Validierungs- oder Release-Gate. Maßgeblich ist [DEC-2026-036](../../Documentation/Architecture/DECISIONS.md#dec-2026-036-verpflichtende-lasttests-und-optionale-laufzeitmessungen). Ältere datierte Aussagen zur verpflichtenden Performance-Abnahme beschreiben den damaligen Vertrag.

Historischer Zwischenstand vor der Abnahmeänderung am 2026-10-19: Der vollständige aktuelle Moduladapter bestand auf SQL Server 2019/2022/2025 unter Windows und Linux. Die abgegrenzte Performance-Abnahme bleibt offen; Runtime: `partially validated`, Release: `unreleased`. Die folgenden datierten älteren Abschnitte beschreiben ihren damaligen Stand. Details: [V0c-Gatebericht](../../Tests/V0C_RELEASE_GATE_STATUS.md).

Plattform-Evidenz 2026-09-01: `local: Tests/CI/run-lab-local.ps1` war auf physischen SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und Linux latest erfolgreich; breitere Large-LOB-Performance-Evidenz bleibt offen. Der Modulstatus bleibt `partially validated`. Dieser Nachweis ersetzt frühere offene Windows-Aussagen; datierte ältere Einträge bleiben historische Evidenz.

V0a-Evidenz 2026-08-29: `local: Tests/CI/run-lab-local.ps1` belegt
ausschließlich den im Modulmanifest genannten physischen Linux-Scope; offene
Windows- und modulspezifische Fälle bleiben unberührt.

**Modul-ID:** `toolbelt.conversion.base64`

**Version:** `1.1.0`

**Implementierung:** `implemented`

**Validierung:** `partially validated`

**Release:** `unreleased`

## Zweck

Das Modul schließt auf SQL Server 2019 und 2022 die erst mit SQL Server 2025
nativ verfügbare Base64-Lücke. Es bietet eine portable T-SQL/XML-
Implementierung mit derselben öffentlichen Oberfläche auf allen drei
unterstützten Hauptversionen.

## Öffentliche Objekte

| Objekt | Typ | Schema | Zweck |
|---|---|---|---|
| `TVF_Base64Encode` | inline TVF | `toolbelt_conversion` | kanonischer relationaler Encode-Kern |
| `TVF_Base64Decode` | inline TVF | `toolbelt_conversion` | kanonischer relationaler Decode-Kern |
| `SVF_Base64Encode` | `SVF` | `toolbelt_conversion` | `varbinary(max)` als Base64 oder Base64URL codieren |
| `SVF_Base64Decode` | `SVF` | `toolbelt_conversion` | Base64 oder Base64URL als `varbinary(max)` decodieren |

## Vertrag

- `NULL` ergibt `NULL`.
- Standard-Base64 enthält kanonisches Padding.
- Base64URL verwendet `-` und `_` und enthält kein Padding.
- Decode akzeptiert beide RFC-4648-Alphabete sowie fehlendes Padding.
- Decode ignoriert ausschließlich Space, Tab, CR und LF.
- Zeichenketten werden nicht implizit in Binärdaten umgewandelt.
- Ungültige Eingaben liefern unverändert den Fehler des T-SQL/XML-Providers.
- Base64 ist eine Codierung, keine Verschlüsselung und kein Integritätsschutz.
- Direkte Aufrufe der inline TVFs setzen wegen der expandierten XML-Methode
  `SET QUOTED_IDENTIFIER ON` in der aufrufenden Sitzung voraus.

Der optionale UDF-Parameter `@UrlSafe` besitzt den Default `0`. T-SQL verlangt
bei Scalar UDFs dennoch ein Argument; für den Defaultpfad kann `DEFAULT`
übergeben werden.

## Abhängigkeiten

Das Modul hat keine Abhängigkeit zu anderen Toolbelt-Modulen. Die
scopebezogene Qualitätsregel erlaubt deshalb die Implementierung unabhängig
vom noch teilweise validierten ResultTable-Modul. Eigene Source-, Lifecycle-,
Contract- und Dokumentationsprüfungen bleiben vollständig verpflichtend.

## Deployment

Aus `Deployment/` im SQLCMD-Modus:

```sql
:setvar DeploymentMode local
:r .\Deploy.sql
```

`DeploymentMode` unterstützt `local` und `central`. Bei zentraler Installation
werden die Funktionen mit dreiteiligem Namen aufgerufen; Synonyme sind nicht
erforderlich.

## Performance und Größen

Der XML-Provider verarbeitet Werte synchron. Für mengenorientierte Aufrufe
sind die inline TVFs über `CROSS APPLY` oder `OUTER APPLY` zu bevorzugen; die
SVFs bleiben Convenience-APIs und versprechen kein Scalar-UDF-Inlining. Die
SVF-Wrapper sind bewusst nicht schemagebunden, damit der kanonische
inline-TVF-Kern bei einem Wiederholungs- oder Upgrade-Deployment ersetzt
werden kann. Die
`max`-Typen definieren die SQL-Schnittstelle, nicht eine
unbegrenzte praktische Größen- oder Performancegarantie. Set-basierte
Massenaufrufe und große LOBs sind vor produktivem Einsatz mit repräsentativen,
nicht vertraulichen Daten zu messen.

Der optionale synthetische 4-MiB-Large-LOB-Workload führt drei unabhängige
Batches mit je einem Warm-up und fünf Messungen aus. Er verwendet deren
Medianwerte nur innerhalb des Laufs und persistiert weder Messwerte noch eine
Baseline. Die Batch-Median-Spanne darf standardmäßig 20 % nicht überschreiten;
bei Instabilität wird der Lauf als `NOT_EXECUTED` mit
`PERFORMANCE_STABILITY_UNAVAILABLE` eingeordnet. Ein Basiswert `0` deaktiviert
nur den Regressionsvergleich, nicht dieses Stabilitäts-Gate.

## Plattform- und Teststatus

Der portable Provider enthält keine bekannte Betriebssystemabhängigkeit.
Der
[Base64-Runtime-Lauf 30535377837](https://github.com/gecompat/SQL_Server_Toolbelt/actions/runs/30535377837)
war auf SQL Server 2025 unter Linux mit Compatibility Levels 150, 160 und 170
erfolgreich. Geprüft wurden RFC-4648-/Base64URL-Vektoren, Fehlerfälle,
synthetische Größen bis 1 MiB, Wiederholungsdeployment, Fremdobjekt-Kollision,
lokale und zentrale Nutzung sowie Uninstall. Der vollständige Adapter ist am
2026-08-29 zusätzlich auf physischen SQL-Server-2019-, 2022- und 2025-Linux-Zielen
erfolgreich. Am 2026-09-01 war der vollständige automatisierte Moduladapter
auf physischen SQL-Server-2019-, 2022- und 2025-Zielen unter Windows base und
Linux latest erfolgreich. Wegen der weiterhin offenen breiteren
Large-LOB-Performance-Evidenz bleibt der Modulstatus `partially validated`.

## Dokumentation

- [Moduldesign](../../Documentation/Architecture/BASE64_MODULE_DESIGN.md)
- [TVF_Base64Encode](./Documentation/TVF_Base64Encode.md)
- [TVF_Base64Decode](./Documentation/TVF_Base64Decode.md)
- [SVF_Base64Encode](./Documentation/SVF_Base64Encode.md)
- [SVF_Base64Decode](./Documentation/SVF_Base64Decode.md)
- [Contract-Testmatrix](./Tests/BASE64_CONTRACT_TEST_MATRIX.md)
- [Test-Evidenz](./Tests/README.md)

## Aktuelle Validierungsevidenz

<!-- BEGIN GENERATED:MODULE_EVIDENCE -->
- Datum: `2026-10-19`
- Nachweis: `local: Tests/CI/run-lab-local.ps1`
- Scope: SQL Server 2025 Linux/latest CL170; vollständiger aktueller Moduladapter einschließlich Pflicht-Lastfall: exakter 4-MiB-Roundtrip mit NULL-, Längen- und Inhaltsorakeln; lokales/zentral Deploy, Lifecycle, Uninstall und frischer eigener Cleanupaudit erfolgreich; ergänzt die unveränderte Sechs-Ziel-Fachmatrix. Laufzeitmessung optional und nicht ausgeführt gemäß DEC-2026-036
- Ergebnis: `success`
<!-- END GENERATED:MODULE_EVIDENCE -->

## Freigegebene Security-Härtung 2026-10-15

SC-019: Der kanonische begrenzte MSTVF-Statuskern prüft vor Normalisierung/XML. Encode16 MiB Binary, Decode24 MiB Rohtext einschließlich Whitespace und16 MiB Ergebnis. Neue Statusoberflächen unterscheiden OK, SQL_NULL, INVALID, LIMIT; bestehende TVF-/SVF-Werte bei LIMIT NULL. Syntaxfehler unterhalb der Grenzen bleiben in bisherigen Fassaden. Inlinewrapper über MSTVF; keine bisherige Plan-/Inliningzusage übernehmen.

Details und abgegrenzte Nachweise: [Security-Härtung](../../Documentation/Architecture/SECURITY_HARDENING_2026_10.md).
