# Implementierungsplan für Toolbelt-Kandidaten

Stand: 2026-09-11

Fortschritt 2026-10-05: RI-2026-041 und die notwendige128er-Prioritätsänderung
sind einzeln freigegeben und umgesetzt. Finale Linux2019-/Windows2025-Adapter
bestehen local/central/Consumer mit je3072 APPLY-Oracles,15 Clientreadern,
42 Lifecyclefällen und frischem Bereinigungs-/Fixture-/Pinaudit. Frühere
Fehlläufe bleiben getrennt; weitere Ziele, Minimalrechte, Maximalworkload/Heap
und exakteHead-CI separat offen. Teilweise validiert und unveröffentlicht.

Dieser Plan zerlegt die Kandidaten aus
[`TOOLBELT_CANDIDATES.md`](./TOOLBELT_CANDIDATES.md) in mögliche Module,
öffentliche SQL-Objekte, interne beziehungsweise externe Provider-Artefakte,
Abhängigkeiten und ausführbare Entwicklungswellen.

## Verbindlichkeit und Aussagegrenzen

- **Dokumentiert:** Die Kandidatenliste enthält 48 Kandidaten. 45 Module sind implementiert; 21 sind `validated`, 24 sind `partially validated`, 0 sind `not executed`.
- **Planungsvorschlag:** Noch nicht implementierte Modul-IDs, Objektnamen und
  Objektzuschnitte in diesem Dokument sind Arbeitsnamen für die
  Vertragsbesprechung. Sie sind noch kein öffentlicher Runtime-Vertrag.
- **Keine Implementierungsfreigabe:** Ein Eintrag in diesem Plan ändert einen
  Kandidaten nicht von `researched` auf `ready for development`. Vor jeder
  Implementierung bleiben die funktionsbezogene Vertragsbesprechung und die
  anschließende ausdrückliche Benutzerfreigabe erforderlich.
- **Persistente Namen nur nach Architekturentscheidung:** Tabellen, Constraints und Indizes sind mit `DEC-2026-025` geregelt. Für Synonyme, Trigger, Sequences, Types und bisher ungeregelte Objekttypen bleibt eine konkrete Architekturentscheidung vor dem ersten Einsatz erforderlich.
- **Provider sind keine stillen Alternativimplementierungen:** Ein alternativer
  Provider erhält eine eigene Support-, Security-, Deployment- und
  Testmatrix. Kanonische Fachlogik wird nicht kopiert.

## Vorbereitete Entscheidungsvorlagen

Folgescope-Entscheidungen vom 2026-10-01: `TC-2026-032` führt Unquoting nur
für einen äußerlich gequoteten Token mit Entfernung des äußeren Paars und
Dekodierung verdoppelter innerer Quotes nach Nutzerpräzisierung. Andere
Escape-/Fehlerregeln bleiben offen. Eine
optionale `USP_SplitAdvanced` verwendet Originaltokens und kein automatisches
Unquoting. `TC-2026-045` beginnt mit Binary-/Raw-/Stringtext-/Cache-Scope;
Anzeigeformat, Styles, Culture und Datumsbehandlung bleiben verpflichtende
spätere Erweiterung. Diese Entscheidungen sind keine Implementierungsfreigaben
der Folgeslices. Konkrete Vorschläge stehen in den verlinkten Proposals und
im Abschnitt „Besprochene Folgescopes“ von `.ai/BACKLOG.md`.

ZIP-Erzeugung hat drei logische Entryfelder; der Benutzer hat caller-lokale
`#Temp`-Eingabe für lokale/zentrale Nutzung und Deflate ohne implizites
Writer-Ratiolimit entsprechend dem Readerdefault gewählt. Das erforderliche
explizite Readerlimit wird dokumentiert. Der CLR-Transport bleibt offen.
Ein User-defined Table Type geht nicht direkt an eine
managed SQL-CLR-Routine; das ZIP-Proposal vergleicht deshalb Binary-Envelope,
Context-Connection-/Temp-Snapshot und einen vorgeschalteten T-SQL-TVP-Wrapper.

Die folgenden Dokumente begrenzen offene Kandidaten und sind die Grundlage
für eine spätere funktionsbezogene Besprechung. Sie sind keine
Implementierungsfreigaben.

| Kandidaten | Vorbereitung | Empfohlener nächster Schritt |
|---|---|---|
| `009` Slice B, `013` | [JSON-Konstruktoren](../Documentation/Architecture/JSON_CONSTRUCTOR_PROPOSAL.md), [JSON-Aggregate](../Documentation/Architecture/JSON_AGGREGATE_PROPOSAL.md) | Typed Constructor-Schnitt beziehungsweise CLR- oder Nicht-Backport-Entscheidung bestätigen. |
| `010`, `011`, `032` | [Regex-Erweiterungen](../Documentation/Architecture/REGEX_EXTENSION_PROPOSAL.md), [Fuzzy Matching](../Documentation/Architecture/FUZZY_MATCH_PROPOSAL.md), [Advanced Split](../Documentation/Architecture/ADVANCED_STRING_SPLIT_PROPOSAL.md) | Jeweiligen V1-Vertrag einzeln bestätigen. |
| `025`–`027`, `028` | [Externes Capability-Gate](../Documentation/Architecture/EXTERNAL_CAPABILITY_GATE_PROPOSAL.md) | Eine einzelne allowlisted Capability mit Daten-, Provider- und Ergebnisvertrag auswählen. |
| `034`, `045` | [ZIP-Erzeugung](../Documentation/Architecture/ZIP_CREATION_PROPOSAL.md), [XLSX-Reader](../Documentation/Architecture/XLSX_READER_PROPOSAL.md) | In-memory-Entryliste beziehungsweise Binary-only-Zellresultat bestätigen. |
| `035`, `036`, `041`, `043` | [Gzip-Entscheidung](../Documentation/Architecture/GZIP_PROVIDER_DECISION.md), [Kompressionsprovider-Gate](../Documentation/Architecture/OPTIONAL_COMPRESSION_PROVIDER_GATE.md), [Zeichentranslation](../Documentation/Architecture/CHARACTER_PSEUDONYMIZATION_DECISION.md), [Geo-Jittering](../Documentation/Architecture/GEO_JITTERING_DECISION.md) | Nur bei konkretem nicht abgedecktem Use Case wieder aufnehmen. |
| `039`, `040`, `042` | [Pseudonymisierungsgrundlage](../Documentation/Architecture/PSEUDONYMIZATION_FOUNDATION_PROPOSAL.md), [Date Shifting](../Documentation/Architecture/DATE_SHIFTING_PROPOSAL.md) | Range-/Lookup-V1 und danach den Date-Shifting-Schnitt einzeln bestätigen. |
| `044` | [Tabellenklon](../Documentation/Architecture/TABLE_CLONE_PROPOSAL.md) | Script-only-V1 für eng begrenzte Tabellenmerkmale bestätigen. |

## Ergebnis der Bestandsprüfung

| Gruppe | Kandidaten | Konsequenz |
|---|---|---|
| Implementiert | `TC-2026-001`, `TC-2026-002`, `TC-2026-003`, `TC-2026-004`, `TC-2026-005`, `TC-2026-006`, `TC-2026-007`, `TC-2026-008`, `TC-2026-009` Slice A, `TC-2026-012`, `TC-2026-014`, `TC-2026-015`, `TC-2026-016`, `TC-2026-017`, `TC-2026-018`, `TC-2026-019`, `TC-2026-020`, `TC-2026-021`, `TC-2026-022`, `TC-2026-023`, `TC-2026-024`, `TC-2026-029`, `TC-2026-030`, `TC-2026-031`, `TC-2026-032` S2, `TC-2026-033`, `TC-2026-034` Extraction-Slice, `TC-2026-037` Read-/Windows-Slices, `TC-2026-038` Windows-Slice, `TC-2026-046` synchroner Slice, `TC-2026-047` Parser-Slice, `TC-2026-048` Barrier-Slice | S2 ist zusätzlich risikobasiert teilweise validiert; 22 Bestandsmodule sind vollständig validiert; die sieben getrennt dokumentierten Performance-, Client-/Treiber-, Fixture-, Interoperabilitäts- und manuellen Sicherheitsgates benötigen externe Voraussetzungen oder Entscheidungen. |
| Parser-, CLR- oder breite Semantikmodule | `TC-2026-010`, `TC-2026-011`, `TC-2026-013` | Funktionsfamilien und Provider vor dem ersten Code begrenzen und benchmarken. |
| Execution-Infrastruktur | Zusätzliche Session-/Worker-Provider aus `TC-2026-046` sowie separate `KILL`-, Queue-Mutations- und Provider-Abbruch-Slices aus `TC-2026-018` | Work Queue 2.0.0 mit Claim, Lease, Retry, Dead Letter, Idempotenz und Barriers sowie W6d-Cancellation sind implementiert und validiert. Der synchrone Second-Session- und Event-Log-Pfad ist ebenfalls implementiert; zusätzliche Provider und Abbruch-Slices benötigen eigene Verträge und Freigaben. |
| Externe Provider und Integrationen | `TC-2026-025` bis `TC-2026-028`; optionale portable Worker-Slices aus `TC-2026-037`/`TC-2026-038` | Allowlist-, Identity-, Secret-, Timeout-, Abbruch- und Plattformvertrag sind Pflicht-Gates; vorhandene Windows-/Read-only-Provider nicht duplizieren. |
| Archive, Kompression und Office | Verbleibende Slices aus `TC-2026-034`, `TC-2026-035`, `TC-2026-036`, `TC-2026-045` | ZIP-Entry-Extraktion und Listing sind implementiert; Erzeugung, vollständige Dateisystemextraktion und weitere Formate bleiben getrennte Verträge. |
| Pseudonymisierung und synthetische Daten | `TC-2026-039` bis `TC-2026-043` | Gemeinsame deterministische Primitive zuerst; Datenschutzwirkung nicht als Anonymisierung behaupten. |
| DDL-/Clone-Framework | `TC-2026-044` | Script-only vor automatischer Mutation; Dependency- und Recovery-Vertrag getrennt. |

## Einheitlicher Ablauf je neuem Modul

1. Kandidat auf einen kleinsten fachlich vollständigen Version-1-Slice
   reduzieren.
2. Zweck, öffentliche Signatur, Resultsets, Fehler, Collation, Datentypen,
   Limits, Berechtigungen, Deployment-Modi und Alternativen besprechen.
3. Breite Kandidaten in getrennte Arbeitspakete und gegebenenfalls Module
   teilen. Mehrere öffentliche Objekte bleiben in einem Modul, wenn sie
   denselben Lifecycle und denselben kanonischen Kern besitzen.
4. Bei erstmaligem Bedarf an persistenten Tabellen, Assemblies, Types,
   Triggern, Sequences oder Synonymen die Namenskonvention mit dem Benutzer
   entscheiden und als Architekturentscheidung festhalten.
5. Implementierungsfreigabe dokumentieren und erst dann ein Arbeitspaket auf
   `ready for development` beziehungsweise beim Start auf `active` setzen.
6. Moduldesign, Contract-Testmatrix und `module.yaml` vor oder gemeinsam mit
   dem ersten Runtime-Objekt erstellen.
7. Source, `Deploy.sql`, `Uninstall.sql`, Release-Manifest,
   Objektdokumentation, Beispiele sowie statische, Contract-, Lifecycle- und
   Runtime-Tests gekoppelt umsetzen.
8. Zuerst den geänderten Capability-Scope testen. Für portables T-SQL ist SQL
   Server 2025 unter den Compatibility Levels 150, 160 und 170 der schnelle
   Entwicklungsfilter. Physische SQL-Server-2019-/2022-Läufe bleiben für
   Engine-, Provider- oder Versionsunterschiede und die Releasevalidierung
   erforderlich. Windows wird bei plattformrelevanten Modulen und vor Release
   getrennt geprüft.
9. Status ausschließlich aus tatsächlich vorhandenen Artefakten und
   ausgeführter Evidenz ableiten.

## Entwicklungswellen und Abhängigkeiten

| Welle | Status | Inhalt | Kandidaten | Eintrittsbedingung | Ergebnis |
|---|---|---|---|---|---|
| `V0a` | automatisierte Linux-Matrix 2019/2022/2025 erfolgreich | Physische Linux-Zielversionen | alle portablen beziehungsweise Linux-fähigen Module | schema-valider SQL_Server_Lab-Vertrag; explizit ausgewählte Ziele mit eigenem `runtimeStatus = READY`; echte Engines 2019/2022/2025 und synthetische Fixtures | File Content weiterhin mit separat bereitgestellten serverseitigen Fixtures prüfen; keine Statusanhebung ohne vollständige Pflichtfälle. |
| `V0b` | automatisierte Windows-Matrix 2019/2022/2025 erfolgreich; manuelle Spezialfälle offen | Windows-Release- und Providerfälle | portable V0c-Kohorte sowie ResultTable, CLR-, Datei-, Second-Session- und Event-Module | schema-valider SQL_Server_Lab-Vertrag, einzeln bereite Windows-Ziele, kontrollierte Windows-SQL-Server-Roots und abstrahierte Evidenz | Verbleibende Identity-, NTFS-, Trust-, Interoperabilitäts- und Performanceverträge getrennt nachweisen. |
| `V0c` | `active`; abhängig von `V0a`/`V0b` | Erste Releasekohorte | 16 portable Module aus Kernfolge, W1, W2a, W2b-A und W2c | vollständige Pflichtmatrix, versionierte Artefakte, Upgrade-/Uninstallnachweis und Releasekriterien | Veröffentlichungsfertige Kohorte; `release_status` bleibt bis zur tatsächlichen autorisierten Veröffentlichung `unreleased`. |
| `W1` | `completed`; Runtime `validated` | Kleine unabhängige T-SQL-Kerne | `002`, `008`, `024` | Einzelvertrag und Freigabe | Drei implementierte und auf Windows/Linux 2019/2022/2025 validierte Module. |
| `W2a` | `completed`; Runtime `validated` | Date/Time- und Bigint-Bit-Kompatibilität | `004`, `005`, `007` | Typfamilien, Paritätsumfang und Fehlervertrag am 2026-07-30 freigegeben | Drei auf Windows/Linux 2019/2022/2025 validierte Module einschließlich nativer Parität, Kollisionsschutz und Bucket-Workload. |
| `W2b-A` | `completed`; Runtime `validated` | JSON-Pfadprüfung | `009` Slice A | Pfad-, NULL-, Fehler- und Providervertrag am 2026-07-30 freigegeben | `toolbelt.json.path-exists` auf Windows/Linux 2019/2022/2025 validiert. |
| `W2b-B` | `deferred` | JSON-Konstruktoren und Aggregate | `009` Slice B, `013` | Variable Konstruktoroberfläche beziehungsweise stabiler Aggregat-/CLR-Provider entschieden | Keine Implementierung; Aggregate bleiben während Preview zurückgestellt. |
| `W2c` | `completed`; Runtime gemischt | Console-Ausgabe und Runtime-Capability-Discovery | `016`, `023` | Provider-, Chunk-, Null-, Metadatenquellen- und Driftvertrag am 2026-07-30 freigegeben | Capability Catalog auf Windows/Linux 2019/2022/2025 validiert; Console Message wegen zusätzlicher Client-/Treibergrenzen teilweise validiert. |
| `W3` | `R1b implemented`; Rest `researched` | String-Parser und Matching | `010`, `011`, `032` | R1b-Vertrag am 2026-08-30 freigegeben; weitere Einzelverträge offen | Regex IsMatch/Instr/Count implementiert und validiert; Fuzzy sowie Quote-/Escape-Module bleiben Research. |
| `W4` | `completed`; Runtime `validated` | Weitere Execution-Grundlagen | `017`, `019`, `022` | Persistente Tabellenkonvention mit `DEC-2026-025`; Einzelverträge freigegeben | Error Envelope, Execution Context und Work-Type-Katalog sind auf Windows/Linux 2019/2022/2025 validiert. |
| `W5a` | `completed`; Runtime `validated` | Synchrone zweite Session und Event Log | `046` synchroner Slice, `014` | Work-Type, Execution Context und Error Envelope | `toolbelt.core.second-session` und rollback-unabhängiges `toolbelt.core.event-log` sind auf Windows/Linux 2019/2022/2025 validiert. |
| `W5b` | `researched` | Zusätzliche Session- und Ausführungsprovider | verbleibender `046`-Scope | Konkreter Providerbedarf, eigener Security-/Lifecyclevertrag und Freigabe | Kein automatischer Ausbau; Agent, Broker und externe Worker bleiben getrennte Optionen. |
| `W6` | `completed`; Runtime `validated` | Queue, Retry, Lease, priorisierte Barriers und Cancellation | `015`, `021`, `020`, `048`, `018` | W6c am 2026-09-10 und W6d am 2026-09-11 ausdrücklich freigegeben | Work Queue 2.0.0 und die kooperative Cancellation sind auf Windows/Linux 2019/2022/2025 validiert. Worker-Provider sowie `KILL`-, Queue-Mutations- und Provider-Abbruch-Slices bleiben getrennt. |
| `W7` | `active` | Datei- und Host-Provider | `037`, `038`, `025`, `026`, `027` | Root-Allowlist, Pfad-/Encoding-Vertrag und Provider | `toolbelt.file.content` ist als portabler Read-only-Slice implementiert und auf SQL Server 2025 Linux teilweise validiert. `toolbelt.filesystem.windows` implementiert Read/Write/Transcoding/Directory-Operationen; der manuelle Windows-Runtime-Nachweis bleibt offen. Externe Worker bleiben optional zurückgestellt. |
| `W8` | `completed` für ZIP Memory; Rest `researched` | Archive und XLSX | `033`, `034`, `035`, `036`, `045` | Untrusted-input-Limits; Dateiprovider nur bei pfadbasiertem Scope | `toolbelt.archive.zip-memory` Version `1.2.0` enthält Extraktion und Listing; die automatisierte Windows-/Linux-Matrix 2019/2022/2025 ist erfolgreich. Reale Archive, Extremgrößen, historische Upgrades und Interoperabilität bleiben Validierungsgates; ZIP-Erzeugung, vollständige Dateisystemextraktion und XLSX bleiben ohne Implementierungsfreigabe offen. |
| `Q1` | `completed` für V1 | Lifecycle- und Upgrade-Automation | `RI-2026-142`; weitere Manifest-/Snapshot-Slices zurückgestellt | V1 auf isolierte dependency-freie zustandslose T-SQL-Module begrenzt | Kataloggenauer Wiederholungsdeploy, zwei unabhängige Uninstalls und Restzustandsprüfung sind auf SQL Server 2019/2022/2025 unter Linux und Windows erfolgreich. |
| `D1` | `implemented`; Runtime `validated` | Date Spine V1 | `RI-2026-079` auf Basis von `006` und `004` | Vertrag am 2026-08-30 besprochen und ausdrücklich freigegeben | Drei portable Inline TVFs für Tag, ISO-Woche und Monat; Windows/Linux 2019/2022/2025 erfolgreich. |
| `R1` | `R1a completed`; `R1b implemented and validated` | Regex V1 | `010` | Freigegebener Vertrag und vollständige physische Matrix erfüllt | Begrenzter Toolbelt-Dialekt über portables SAFE SQL CLR für IsMatch, Instr und Count; keine RE2-Paritätszusage, Replace/Split/Captures bleiben außerhalb. |
| `R2025` | `proposed research` | SQL-Server-2025-GA-Delta | UNISTR, PRODUCT, DATEADD bigint, Vector-Scalar-Funktionen | Aktuellen GA-/Preview-Status aus Primärquellen bestätigen | Nur Deduplizierung und Kandidatenbewertung; keine Implementierung. |
| `W9` | `researched` | Deterministische Pseudonymisierungsprimitive | `040`, `039`, `041`, `042`, `043` | Key-/Seed-, Kanonisierungs- und Datenschutzvertrag | Range-Primitive zuerst; darauf Lookup, Translation, Date Shift und Geo Jitter. |
| `W10` | `researched` | Kontrolliertes DDL-Klonen | `044` | Identifier-Modul vorhanden; unterstützte Objektmenge festgelegt | Zuerst nur geprüftes Script, später optional getrennte Ausführung. |
| `W11` | `researched` | KI-Capabilities | `028` | REST/Worker, Capability-Katalog, Credentials, Kosten- und Datengovernance | Embeddings und generative Aufrufe als getrennte Module. |

Die Wellen sind eine Dependency-Reihenfolge, keine pauschale
Implementierungsfreigabe. Innerhalb einer Welle wird nur ein ausdrücklich
freigegebenes Arbeitspaket aktiv.

## Bestimmung der nächsten neuen Funktionswelle

Die Releasevalidierung `V0a`/`V0b`/`V0c` bleibt vorrangig. `Q1`, `D1`, R1a,
E1a, E1b und R1b sind in ihrem deklarierten Scope abgeschlossen. E1b und R1b
wurden am 2026-08-30 ausdrücklich zur sequenziellen Implementierung
freigegeben und jeweils separat umgesetzt; weitere Funktionsimplementierungen
sind nicht pauschal autorisiert.

Die Auswahl von `D1` beruhte auf der bereits implementierten Dependency-Closure
aus Generate Series und Datetime Truncate, dem hohen
relationalen Nutzwert und einer gegenüber Regex, JSON-Konstruktion und Work
Queue kleineren Semantik-, Provider-, Security- und Recovery-Fläche. V1 bleibt
auf Tag, Woche und Monat mit expliziten Grenzen beschränkt. Feiertage,
Arbeitstage, Zeitzonen, DST, Locale-Texte, Geschäfts- und Fiskalkalender sowie
eine persistente Kalenderdimension sind ausdrücklich nicht Bestandteil dieser
Welle.

Der D1-Vertrag wurde am 2026-08-30 mit halboffenen Grenzen, leerer Menge für
`NULL` sowie leere oder umgekehrte Bereiche, Montag-basierter ISO-Woche,
nullbasiertem Ordinal und ohne künstliches Schutzlimit festgelegt und danach
ausdrücklich freigegeben. `R1a` hat den Semantik-/Provider-Spike ohne
Runtime-API abgeschlossen; der danach freigegebene R1b-Vertrag wählte bewusst
einen kleineren Toolbelt-Dialekt ohne RE2-Paritätszusage.
`E1a` ist nach eigener Vertragsbesprechung und Freigabe als
Enqueue/Claim/Complete/Fail/Status-Slice implementiert. `E1b` ergänzt nach
getrennter Besprechung und Freigabe Lease, Heartbeat und explizite Recovery.
Retry, Dead Letter, Idempotenz und priorisierte Gruppen-Barriers sind nach
ausdrücklicher Freigabe vom 2026-09-10 als W6c in Work Queue 2.0.0 implementiert
und validiert. Die kooperative Cancellation ist nach ausdrücklicher Freigabe
vom 2026-09-11 als W6d implementiert und validiert. Zusätzliche Session-/Worker-
Provider sowie `KILL`, Queue-Mutation und Provider-Abbrüche bleiben getrennte
Slices mit eigenen Vertrags- und Freigabegrenzen. R1b ist nach dem E1b-Merge mit
portablem SAFE-CLR-Provider implementiert und auf der vollständigen
physischen Windows-/Linux-Matrix validiert.

## Objekt- und Modulplan

### Bereits implementierte Module

XLSX-Raw-Slice ergänzt am 2026-10-02: Die ältere Archive-/Office-Planung weiter unten bleibt historische Architekturvorbereitung; aktuelle Raw-Verträge und separat freigegebene Typ-/Anzeige-Folgefunktionen stehen in `.ai/BACKLOG.md`.

| Kandidat | Modul | Vorhandene öffentliche Objekte | Restarbeit |
|---|---|---|---|
| `TC-2026-032` S2 | `toolbelt.string.split-advanced` | `toolbelt_string.TVF_SplitAdvanced` | Freigegeben und implementiert; risikobasiert 2019 Linux und 2025 Linux/Windows geprüft, weitere Zielkombinationen nicht ausgeführt. USP/Unquoting bleiben spätere Einzelslices. |
| `TC-2026-001` | `toolbelt.string.split-characters` | `toolbelt_string.TVF_SplitByCharacters` | Keine autonome Validierung offen; `TC-2026-032` bleibt getrennt. |
| `TC-2026-002` | `toolbelt.datetime.calendar-difference` | `toolbelt_datetime.TVF_CalendarDifference` | Keine autonome Validierung offen. |
| `TC-2026-003` | `toolbelt.core.result-table` | `toolbelt_core.USP_PrepareResultTable` | Pflicht-Lastfall mit Daten-/Schema-/Indexergebnisprüfung erfolgreich; Laufzeitmessung gemäß DEC-2026-036 optional. |
| `TC-2026-006` | `toolbelt.core.generate-series` | `toolbelt_core.TVF_GenerateSeriesBigInt`, `toolbelt_core.TVF_GenerateSeriesInt` | Zehn-Millionen-Pflicht-Lastfall mit vollständiger Wertemengenprüfung erfolgreich; Laufzeitmessung optional. |
| `TC-2026-008` | `toolbelt.string.directional-trim` | `toolbelt_string.TVF_TrimDirectionalNvarchar`, `toolbelt_string.TVF_TrimDirectionalVarchar` | Keine autonome Validierung offen. |
| `TC-2026-012` | `toolbelt.conversion.base64` | `toolbelt_conversion.TVF_Base64Encode`, `toolbelt_conversion.TVF_Base64Decode`, `toolbelt_conversion.SVF_Base64Encode`, `toolbelt_conversion.SVF_Base64Decode` | 4-MiB-Pflicht-Lastfall mit exaktem Roundtrip erfolgreich; Laufzeitmessung optional. |
| `TC-2026-024` | `toolbelt.conversion.uri-component` | `toolbelt_conversion.TVF_UriComponentEncode`, `toolbelt_conversion.TVF_UriComponentDecode`, `toolbelt_conversion.SVF_UriComponentEncode`, `toolbelt_conversion.SVF_UriComponentDecode` | Keine autonome Validierung offen. |
| `TC-2026-029` | `toolbelt.metadata.identifier` | `toolbelt_metadata.TVF_ParseMultipartName`, `toolbelt_metadata.SVF_QuoteMultipartName` | Keine autonome Validierung offen. |
| `TC-2026-030` | `toolbelt.validation.semantic-version` | `toolbelt_validation.TVF_ParseSemanticVersion`, `toolbelt_validation.TVF_CompareSemanticVersion`, `toolbelt_validation.TVF_SemanticVersionSortKey`, `toolbelt_validation.SVF_CompareSemanticVersion`, `toolbelt_validation.SVF_SemanticVersionSortKey` | Keine autonome Validierung offen. |
| `TC-2026-031` | `toolbelt.conversion.integer-base` | `toolbelt_conversion.TVF_IntegerToBase`, `toolbelt_conversion.TVF_TryBaseToInteger`, `toolbelt_conversion.SVF_IntegerToBase`, `toolbelt_conversion.SVF_TryBaseToInteger` | Keine autonome Validierung offen. |
| `TC-2026-004` | `toolbelt.datetime.truncate` | `TVF_TruncateDate`, `TVF_TruncateDateTime2`, `TVF_TruncateDateTimeOffset` | Keine autonome Validierung offen. |
| `TC-2026-005` | `toolbelt.datetime.bucket` | `TVF_DateBucketDate`, `TVF_DateBucketDateTime2`, `TVF_DateBucketDateTimeOffset` | Keine autonome Validierung offen. |
| `TC-2026-007` | `toolbelt.binary.bit-operations` | `TVF_LeftShiftBigInt`, `TVF_RightShiftBigInt`, `TVF_BitCountBigInt`, `TVF_GetBitBigInt`, `TVF_SetBitBigInt` | Keine autonome Validierung offen; Binary-Slice bleibt getrennt. |
| `TC-2026-009` | `toolbelt.json.path-exists`, `toolbelt.json.constructors` | `toolbelt_json.TVF_JsonPathExists`, `USP_JsonArray`, `USP_JsonObject` | Path Exists validiert; Konstruktoren im ausgewählten Linux-2019-/Windows-2025-Scope geprüft, weitere Ziele und gemappte CrossDB-Minimalrechte offen. |
| `TC-2026-014` | `toolbelt.core.event-log` | `toolbelt_core.USP_WriteEvent`, `VW_Events`, `USP_DeleteEventsBefore` | Keine autonome Validierung offen; betriebliche Loopback-Blockierungsprofile wären ein getrennter Scope. |
| `TC-2026-016` | `toolbelt.core.console-message` | `toolbelt_core.USP_WriteConsoleMessage` | Zusätzliche reale Client-/Treiber-, Buffering- und Framing-Evidenz. |
| `TC-2026-017` | `toolbelt.core.error-envelope` | `toolbelt_core.USP_CaptureErrorEnvelope` | Keine autonome Validierung offen; Retry-Entscheidungen bleiben ausdrücklich außerhalb dieses Moduls. |
| `TC-2026-018` | `toolbelt.core.execution-cancel` | `toolbelt_core.USP_RequestExecutionCancellation`, `toolbelt_core.TVF_ExecutionCancellationStatus`, `toolbelt_core.SVF_IsCancellationRequested` | W6d ist auf Windows/Linux 2019/2022/2025 validiert. `KILL`, Queue-Mutation und Provider-Abbrüche sind getrennte Slices. |
| `TC-2026-019` | `toolbelt.core.execution-context` | `toolbelt_core.TVF_CurrentExecutionContext`, `toolbelt_core.SVF_CurrentExecutionId`, `toolbelt_core.USP_BeginExecution`, `toolbelt_core.USP_SetExecutionContext`, `toolbelt_core.USP_EndExecution` | Keine autonome Validierung offen; weitergehende Connection-Pooling-Zusagen wären ein getrennter Scope. |
| `TC-2026-022` | `toolbelt.core.work-type` | `toolbelt_core.USP_RegisterWorkType`, `USP_DisableWorkType`, `USP_RemoveWorkType`, `USP_ResolveWorkType`, `VW_WorkTypes` | Keine autonome Validierung offen; zusätzliche Second-Session-Provider bleiben getrennt. |
| `TC-2026-023` | `toolbelt.metadata.capability-catalog` | `toolbelt_metadata.VW_ModuleCapabilities` | Keine autonome Validierung offen. |
| `TC-2026-034` | `toolbelt.archive.zip-memory` | `toolbelt_archive.USP_ExtractZipEntryFromBinary` | Reale Archive, echte Extremgrößen und Interoperabilität; ZIP-Erzeugung bleibt ein separater Slice. |
| `TC-2026-033` | `toolbelt.archive.zip-memory` | `toolbelt_archive.USP_ListZipEntriesFromBinary` | Reale Archive, echte Extremgrößen, Interoperabilität und vollständiger Upgradepfad aus einem realen 1.1.0-Stand. |
| `TC-2026-045` | `toolbelt.file.xlsx-memory` | `toolbelt_file.USP_ListXlsxWorksheets`, `USP_ReadXlsxWorksheetCells` | Finale Linux-2019-/Windows-2025-Raw-Verträge und begrenzte SAFE-/NoIO-/IL-Gates erfolgreich; reale große Ceilings, minimale Rechte und übrige Zielmatrix offen. Typ-/Anzeige-Folgefunktionen separat freigegeben. |
| `TC-2026-037` | `toolbelt.file.content`; `toolbelt.filesystem.windows` | `toolbelt_file.USP_LoadBinaryFile`, `toolbelt_file.USP_LoadTextFile`; Windows Read/Write/Transcoding-Procedures | File-Content-Windows-Releasevalidierung und manueller Windows-CLR-Runtime-Test; externer Worker nur bei Bedarf. |
| `TC-2026-038` | `toolbelt.filesystem.windows` | `toolbelt_filesystem.USP_ListDirectory` | Manueller Windows-Runtime-Test; portabler Listing-Provider bleibt optional offen. |
| `TC-2026-046` | `toolbelt.core.second-session` | `toolbelt_core.USP_ExecuteWorkTypeInNewSession` | Keine autonome Validierung offen; zusätzliche Provider bleiben getrennte Forschungs- und Freigabeslices. |
| `D1` / `RI-2026-079` | `toolbelt.datetime.date-spine` | `toolbelt_datetime.TVF_DateSpineDay`, `TVF_DateSpineIsoWeek`, `TVF_DateSpineMonth` | Keine autonome Validierung offen; Release bleibt unautorisiert. |
| `TC-2026-015` | `toolbelt.core.work-queue` (E1a) | `toolbelt_core.USP_EnqueueWork`, `USP_ClaimWork`, `USP_CompleteWork`, `USP_FailWork`, `USP_GetWorkStatus`, `VW_WorkQueue` | Worker-Provider und E1c Retry/Idempotenz bleiben separat; tatsächliche Veröffentlichung ist nicht autorisiert. |
| `TC-2026-021` | `toolbelt.core.work-queue` (E1b) | `toolbelt_core.USP_RenewWorkLease`, `USP_RecoverExpiredWork`; Lease- und Generationserweiterungen der E1a-Objekte | E1c Retry/Idempotenz bleibt separat; tatsächliche Veröffentlichung ist nicht autorisiert. |
| `TC-2026-048` | `toolbelt.core.work-queue` (W6c) | `toolbelt_core.USP_EnqueueBarrierWork`, `VW_WorkQueueBarrierBlockers`; Erweiterungen der Queue-Status- und Claim-Verträge | Work Queue 2.0.0 ist auf Windows/Linux 2019/2022/2025 validiert; kooperative Cancellation bleibt ein getrennter, unautorisierter Slice. |
| `TC-2026-047` | `toolbelt.tsql.script-parser` | `toolbelt_tsql.TVF_ParseScriptNodes`, `TVF_ParseScriptNodeProperties`, `TVF_TokenizeScript`, `TVF_ParseScriptErrors` | Der Parser ist auf physischen Windows-SQL-Server-2019-/2022-/2025-Zielen validiert. |
| `TC-2026-010` | `toolbelt.string.regex` (R1b) | `toolbelt_string.SVF_RegexIsMatch`, `SVF_RegexInstr`, `SVF_RegexCount` | Replace, Substring, Captures, Split und Matches bleiben separat; tatsächliche Veröffentlichung ist nicht autorisiert. |

### Portable Fach- und Compatibility-Module

| Kandidat | Vorgeschlagener Modul-Slice | Vorgeschlagene öffentliche Objekte | Zentrale Vertragsentscheidung | Testschwerpunkt |
|---|---|---|---|---|
| `TC-2026-013` | `toolbelt.json.aggregate` mit zwei getrennten Aggregat-Slices | Array- und Object-Aggregat-Oberfläche; Objekttyp und Name bleiben bis zur Providerentscheidung offen | T-SQL-Resultset-Procedure versus CLR User-defined Aggregate; Order, Duplicate Keys, NULL und Return Type. | Native Parität auf 2025, Reihenfolge, Escaping, große Gruppen, Memory Grants und Providervergleich. |

### Parser, Regex und Matching

| Kandidat | Vorgeschlagener Modul-Slice | Vorgeschlagene öffentliche Objekte | Zentrale Vertragsentscheidung | Testschwerpunkt |
|---|---|---|---|---|
| `TC-2026-011` | `toolbelt.string.fuzzy-match` | `SVF_EditDistance`, `SVF_EditDistanceSimilarity`, `SVF_JaroWinklerDistance`, `SVF_JaroWinklerSimilarity` | Exakte SQL-Server-2025-Semantik, maximale Länge, Unicode/Collation und T-SQL- versus CLR-Kern. | Native Parität, Symmetrie, Grenzwerte, lange Strings, Mengenaufruf und Benchmark. |


### Execution- und Provider-Infrastruktur

| Kandidat | Vorgeschlagener Modul-Slice | Vorgeschlagene öffentliche Objekte | Interne/persistente Bestandteile und Blocker |
|---|---|---|---|
| `TC-2026-017` | `toolbelt.core.error-envelope` | `toolbelt_core.USP_CaptureErrorEnvelope` | Rückgabeform, Klassifikation und Rethrow-Grenze entscheiden; keine persistente Tabelle erforderlich. |
| `TC-2026-019` | `toolbelt.core.execution-context` | `USP_BeginExecution`, `USP_SetExecutionContext`, `SVF_CurrentExecutionId`, optional `USP_EndExecution` | Session-Context-Keys, Nested Ownership und Lebensdauer; persistenter Ausführungsstatus nur als getrennte Erweiterung. |
| `TC-2026-014` | `toolbelt.core.event-log` mit genau einem freigegebenen Provider in Version 1 | `USP_WriteEvent`; optional `VW_Events` und kontrollierte Retention-USP | Persistente Logtabelle und Providerartefakte benötigen Namens-/Retention-Entscheidung. Haltbarkeit, Blockierung und Fehlerverhalten müssen explizit sein. |
| `TC-2026-020` | `toolbelt.core.work-queue` (W6c) | `USP_EnqueueWorkWithPolicy`, `USP_ScheduleWorkRetry`, `USP_RequeueDeadLetter` | Zusammen mit `TC-2026-048` am 2026-09-10 freigegeben: Worker entscheidet Retry, Backoff ohne Jitter, drei Versuche default, Dead Letter und Idempotenz pro Work Type/Key. |
| `TC-2026-021` | `toolbelt.core.worker-lease` | `USP_AcquireWorkLease`, `USP_HeartbeatWorkLease`, `USP_ReleaseWorkLease`, `USP_RecoverOrphanedWork`, `VW_WorkLeases` | Lease-/Heartbeat-Zustand benötigt persistente Tabellenkonvention; atomare Ownership-Version und Recovery zuerst spezifizieren. |
| `TC-2026-018` | `toolbelt.core.execution-cancel` | `USP_RequestExecutionCancellation`, `TVF_ExecutionCancellationStatus`, `SVF_IsCancellationRequested`; privilegierter `USP_StopExecutionGroup` nur als separater optionaler Slice | W6d ist am 2026-09-11 freigegeben und implementiert: kooperative Prüfung ist Default; `KILL`, Queue-Mutation und Provider-Abbrüche bleiben getrennt. |

Pflichtprüfungen für diese Familie sind konkurrierende Worker, Doppelausführung,
Crash zwischen Zustandsübergängen, Deadlocks, Caller-Transaktionen,
uncommittable Transactions, Timeout, Abbruch, Wiederanlauf, Berechtigungen,
Providerausfall und idempotentes Deployment. Jeder Test verwendet ausschließlich
synthetische Work Types und Payloads.

### Externe Automation, Dateien, Netzwerk und KI

| Kandidat | Vorgeschlagener Modul-/Provider-Slice | Vorgeschlagene öffentliche Objekte | Pflicht-Gates |
|---|---|---|---|
| `TC-2026-025` | `toolbelt.automation.powershell` | `toolbelt_automation.USP_InvokePowerShellWorkType` | Exakte erlaubte Aufgaben, kein Raw Script, Workeridentität, Parameter-/Outputschema, Timeout, Cancellation, Audit und Windows-/Linux-Matrix. |
| `TC-2026-026` | A: `toolbelt.integration.python-ml`; B: `toolbelt.automation.python-worker` | A: `USP_ExecutePythonCapability`; B: `USP_InvokePythonWorkType` | Datenorientierte In-database-Ausführung strikt von Host-Automation trennen; Packages, Version, Ressourcen, Import-Allowlist und ResultTable-Vertrag festlegen. |
| `TC-2026-027` | `toolbelt.integration.rest` mit internem 2025- und Worker-Provider | `toolbelt_integration.USP_InvokeRestEndpoint` | Endpoint-/Method-Allowlist, Credentialreferenz statt Secret, Redirects, DNS/SSRF, Payloadlimit, Timeout, Retry/Idempotenz und 2019/2022-Provider. |
| `TC-2026-028` | A: `toolbelt.ai.embedding`; B: `toolbelt.ai.structured-inference`; C: generativer Chat erst danach | Arbeitsnamen `USP_CreateEmbedding`, `USP_RunStructuredInference`, `USP_CreateChatCompletion` | Separate Verträge, Datenfreigabe, Modell/Version, Region, Credentials, Kostenlimit, Outputschema, Prompt-Injection-Grenze und keine automatische Codeausführung. |
| `TC-2026-037` | `toolbelt.file.content` | `toolbelt_file.USP_LoadTextFile`, `USP_SaveTextFile`, `USP_LoadBinaryFile`, `USP_SaveBinaryFile` | Root-Allowlist, kanonische Pfadauflösung, Links, Identität, Encoding/BOM, Maximalgröße, Atomic Write, Overwrite und Provider. |
| `TC-2026-038` | `toolbelt.file.directory` | `toolbelt_file.USP_ListDirectoryEntries` | Flach/rekursiv, Paging, Sortierung, Metadatenschema, Links, Root-Allowlist und Ressourcenlimit. |

Für jede resultseterzeugende USP gelten der vollständige Help-,
`@ResultTable`-, `@KeepData`- und Debug-Vertrag. Provider-E2E-Tests werden
getrennt von den providerneutralen Contract-Tests ausgewiesen.

### Archive, Kompression und XLSX

| Kandidat | Vorgeschlagener Modul-/Capability-Slice | Vorgeschlagene öffentliche Objekte | Reihenfolge und Grenzen |
|---|---|---|---|
| `TC-2026-034` | A: `toolbelt.archive.zip-memory`; B: `toolbelt.archive.zip-filesystem`; C: optionaler CLR-Provider-Slice | A: `USP_ExtractZipEntry`, `USP_CreateZipArchive`; B: `USP_ExtractZipArchiveToDirectory`, `USP_CreateZipArchiveFromFiles`; C: Providerobjektname erst im Implementierungs-Slice | A vor B und C. Filesystem-Slice hängt von `TC-2026-037` ab. `AP-2026-021` legt C auf In-memory, Method 0/8 und Payload-CRC fest. Der C#-Build, die `System.IO.Compression`-Abhängigkeitsprüfung und der Assembly-Trust sind als Spike `AP-2026-022` statisch sowie im Windows-Build nachgewiesen. Reale Windows-/Linux-SQL-Server-Evidenz und die produktive Providerimplementierung bleiben getrennte, ausdrücklich freizugebende Slices; kein pauschales `TRUSTWORTHY ON`. |
| `TC-2026-035` | Bedingter Slice `toolbelt.compression.gzip-stream` | Nur bei belegter Lücke: `USP_GzipCompressStream`, `USP_GzipDecompressStream` | Zurückgestellt: Native `COMPRESS`/`DECOMPRESS` decken den belegten In-memory-Bedarf ab. Wiederaufnahme nur mit klarem Streaming-/Datei-Use-Case. |
| `TC-2026-036` | Pro tatsächlich benötigtem Format ein Modul `toolbelt.compression.<format>` | Formatbezogene Compress-/Decompress-Oberflächen; kein generisches „beliebiges Format“-Objekt | Zurückgestellt: Format und Use Case sind nicht ausgewählt. Erst danach Lizenz, Supply Chain, Plattform, Wartung, Bomb-Limits und Exit-Strategie je Provider prüfen. |
| `TC-2026-045` | `toolbelt.office.xlsx` | V1: `toolbelt_office.USP_ListXlsxWorksheets`, `USP_ReadXlsxCells`; später getrennt `USP_ImportXlsxTable` | V1 liefert stabiles zellorientiertes Schema. Tabellenförmige Typinferenz und Mutation folgen separat. Shared Strings, Styles, 1900/1904-Datumsmodus, Formeln, Fehlerzellen, Limits und Streaming testen. |

### Pseudonymisierung und synthetische Daten

| Kandidat | Vorgeschlagener Modul-Slice | Vorgeschlagene öffentliche Objekte | Pflicht-Gates |
|---|---|---|---|
| `TC-2026-040` | `toolbelt.pseudonymization.range` als gemeinsames Primitive | `toolbelt_pseudonymization.SVF_DeterministicRangeBigInt`; optional getrennte normalisierte Unit-Interval-Funktion | Kanonisierung, Hash/PRF, Seed versus geheimer Key, Verteilung, Bias, Bereich und Versionierung. |
| `TC-2026-039` | `toolbelt.pseudonymization.lookup` | `SVF_DeterministicLookupIndex` als Primitive; `USP_MapDeterministicLookupValue` für kontrollierte Lookupquellen | Stabile Sortierung, Lookup-Version, leere/geänderte Menge, Identifier-Sicherheit und Referenzkonsistenz. Gemeinsamen Kern aus `TC-2026-040` wiederverwenden. |
| `TC-2026-041` | `toolbelt.pseudonymization.translation` | `SVF_TranslateDeterministic` | Reversibilität, Alphabet, Unicode, Case-Regeln, Format Preservation, Key/Salt, Rotation und Mappingversion. |
| `TC-2026-042` | `toolbelt.pseudonymization.date-shift` | Typfamilie `SVF_ShiftDate`, `SVF_ShiftDateTime2`, optional `SVF_ShiftDateTimeOffset` | Granularität pro Entität/Gruppe/Zeile, Intervallerhalt, Offsetbereich, Zeitzone, Overflow und Schlüsselmodell. |
| `TC-2026-043` | `toolbelt.pseudonymization.spatial-jitter` | `SVF_JitterGeography`, `SVF_JitterGeometry` nur bei jeweils freigegebenem Modell | SRID, planar/geodätisch, Distanzverteilung, deterministische Parameter, Clipping, zulässige Gebiete und messbare Re-Identifikationsgrenze. |

Diese Module werden als Pseudonymisierung beziehungsweise synthetische
Datenerzeugung dokumentiert. Der Plan behauptet keine irreversible
Anonymisierung oder automatische Datenschutzkonformität.

### DDL- und Clone-Framework

| Kandidat | Vorgeschlagener Slice | Vorgeschlagene öffentliche Objekte | Pflicht-Gates |
|---|---|---|---|
| `TC-2026-044` | V1 `toolbelt.metadata.table-clone-script`; V2 getrennte Execute-Capability | V1 `toolbelt_metadata.USP_ScriptTableClone`; V2 optional `USP_ExecuteTableClone` | V1 nur Script-Erzeugung und Validierung. Unterstützte Tabellenarten, Spalten, Identity, Indizes, PK/UQ/FK, Check-/Default-Constraints, Trigger, Computed Columns, Partitionierung, Temporal/Graph/Ledger, Dateigruppen und Reihenfolge explizit whitelisten. Generierte persistente Objektnamen erfordern vorab die offene Namensentscheidung. |

V1 testet ausschließlich synthetische DDL-Modelle, deterministische
Namensbildung, Dependency-Reihenfolge, Kollisionsfreiheit und wiederholbare
Skripterzeugung. Automatische Ausführung, Datenkopie und Rollback gehören nicht
stillschweigend zu V1.

## Abnahmekriterien für den Plan

- Jeder der 46 Kandidaten ist genau einer Planzeile beziehungsweise einem
  vorhandenen Modul zugeordnet.
- Breite Kandidaten sind in getrennte Capabilities oder Provider-Slices
  zerlegt.
- Abhängigkeiten sind azyklisch und gemeinsame Primitive werden nicht
  dupliziert.
- Vorgeschlagene USP-, TVF-, SVF- und View-Namen entsprechen den bestehenden
  Konventionen.
- Für ungeregelte persistente Objekttypen wurde kein Name erfunden.
- Implementierungs-, Validierungs- und Release-Status bleiben getrennt.
- Der Plan verändert keine Implementierungsfreigabe und behauptet keine nicht
  ausgeführte Runtime-Evidenz.
- Datenschutz-, Secret-, Third-Party-, Provider-, Plattform- und
  untrusted-input-Gates sind bei den betroffenen Modulen sichtbar.

## Nächste konkrete Auswahl

W2c mit `TC-2026-016` und `TC-2026-023` ist als
`toolbelt.core.console-message` sowie
`toolbelt.metadata.capability-catalog` implementiert. Die automatisierte
Windows-/Linux-Matrix 2019/2022/2025 ist erfolgreich; der Capability Catalog
ist einschließlich eingeschränkter Metadatensichtbarkeit `validated`.
Console Message bleibt wegen zusätzlicher realer Client-/Treiber-, Buffering-
und Framing-Evidenz `partially validated`.

JSON-Konstruktoren und `TC-2026-013` bilden W2b-B und bleiben zurückgestellt.
Konstruktoren benötigen eine belastbare variable Eingabeoberfläche;
JSON-Aggregate bleiben während des nativen Preview-Status und ohne
freigegebenen SQL-CLR-/Providervertrag außerhalb der Entwicklung.

Die am 2026-08-28 ausdrücklich freigegebene Entwicklungsfolge `V0a` → `V0b`
→ `V0c` hat ihre autonom ausführbare Windows-/Linux-Matrix abgeschlossen.
Offen bleiben die sieben ausdrücklich abgegrenzten externen oder manuellen
Gates; eine tatsächliche Veröffentlichung ist nicht autorisiert.

`V0c` ist verbindlich auf folgende 16 vorhandene Module begrenzt:

- `toolbelt.core.result-table`;
- `toolbelt.conversion.base64`;
- `toolbelt.core.generate-series`;
- `toolbelt.metadata.identifier`;
- `toolbelt.string.split-characters`;
- `toolbelt.validation.semantic-version`;
- `toolbelt.conversion.integer-base`;
- `toolbelt.datetime.calendar-difference`;
- `toolbelt.string.directional-trim`;
- `toolbelt.conversion.uri-component`;
- `toolbelt.datetime.truncate`;
- `toolbelt.datetime.bucket`;
- `toolbelt.binary.bit-operations`;
- `toolbelt.json.path-exists`;
- `toolbelt.core.console-message`;
- `toolbelt.metadata.capability-catalog`.

22 Module sind `validated`, 8 bleiben `partially validated`; alle 30 sind `unreleased`. Der lokale
SQL_Server_Lab-Vertrag ist schema-valide. Die vollständige automatisierte
Matrix war am 2026-09-01 auf physischen SQL-Server-2019-/2022-/2025-Zielen
unter Windows base und Linux latest erfolgreich. File Content bleibt ohne
separat bereitgestellte serverseitige Fixtures in diesem Spezialscope offen.
Das Projekt startet, repariert oder löscht keine Lab-Ressourcen selbst.
