-- ============================================================================
-- Objekt:          toolbelt_file.USP_LoadBinaryFile
-- Typ:             Stored Procedure
-- Zweck:           Liest eine Datei als varbinary(max) über OPENROWSET(BULK...).
-- Vertrag:         Documentation/Architecture/FILE_CONTENT_MODULE_DESIGN.md
-- Parameter:       @FilePath nvarchar(4000) = NULL (nur Help-Aufruf)
--                  @MaxBytes bigint = NULL
--                  @Debug tinyint = 0
--                  @Hilfe bit = 0
--                  @ResultTable sysname = NULL
--                  @KeepData bit = 0
-- Resultset:       Genau eine Zeile mit Content, BytesRead, IsValid,
--                  ValidationCode, ValidationMessage.
-- Dependencies:    toolbelt_file.FileContentRootAllowlist
-- Rechte:          EXECUTE auf der Procedure;
--                  ADMINISTER BULK OPERATIONS oder ad hoc distributed queries;
--                  Lesezugriff auf den Dateipfad.
-- Versionen:       SQL Server 2019, 2022 und 2025.
-- Plattformen:     Windows und Linux.
-- Fehlerverhalten: Fachliche Fehler werden als Resultset-Zeile mit
--                  IsValid = 0 zurückgegeben. Unbehandelte Engine-Fehler
--                  propagieren als THROW.
-- Performance:     Einzelner OPENROWSET(BULK...)-Aufruf; Limitierung durch
--                  @MaxBytes erfolgt nicht auf Byte-Ebene, sondern als
--                  Validierung nach dem Lesen.
-- Einschränkungen:  Dateigröße ist durch varbinary(max) auf ca. 2 GB begrenzt.
-- ============================================================================

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_file].[USP_LoadBinaryFile]
(
      @FilePath  nvarchar(4000) = NULL
    , @MaxBytes  bigint       = NULL
    , @ResultTable sysname    = NULL
    , @KeepData bit           = 0
    , @Debug     tinyint      = 0
    , @Hilfe     bit          = 0
)
AS
BEGIN
    SET NOCOUNT ON;

    SET @Hilfe    = ISNULL(@Hilfe, 0);

    IF @Hilfe = 1
    BEGIN
        DECLARE @Help TABLE
        (
              HelpContractVersion varchar(16)    NOT NULL
            , SchemaName          sysname        NOT NULL
            , ObjectName          sysname        NOT NULL
            , Section             varchar(32)    NOT NULL
            , Ordinal             int            NOT NULL
            , ItemName            sysname        NULL
            , SqlDataType         varchar(256)   NULL
            , IsRequired          bit            NULL
            , IsNullable          bit            NULL
            , DefaultValue        nvarchar(4000) NULL
            , Description         nvarchar(max)  NOT NULL
            , ExampleSql          nvarchar(max)  NULL
        );

        INSERT INTO @Help
        (
              HelpContractVersion
            , SchemaName
            , ObjectName
            , Section
            , Ordinal
            , ItemName
            , SqlDataType
            , IsRequired
            , IsNullable
            , DefaultValue
            , Description
            , ExampleSql
        )
        VALUES
          ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'DESCRIPTION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Liest eine Datei als varbinary(max) über OPENROWSET(BULK...). Der Pfad muss unter einem Eintrag der Root-Allowlist liegen.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'PARAMETER', 1
          , N'@FilePath', 'nvarchar(4000)', 1, 0, N'NULL'
          , N'Absoluter Pfad zur Datei. UNC-Pfade sind erlaubt. Relative Pfade, ..-Segmente und Pfade außerhalb der Allowlist werden abgelehnt.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'PARAMETER', 2
          , N'@MaxBytes', 'bigint', 0, 1, N'NULL'
          , N'Optionales Limit. Wenn die gelesene Datei mehr Bytes enthält, wird ein Validierungsfehler zurückgegeben, der Inhalt bleibt jedoch NULL.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'PARAMETER', 5
          , N'@Debug', 'tinyint', 0, 1, N'0'
          , N'Beim ResultTable-Routing Diagnosemeldungen des kanonischen Helpers; keine zusätzlichen fachlichen Resultsets. Im SELECT-Pfad keine Debug-Messages.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'PARAMETER', 6
          , N'@Hilfe', 'bit', 0, 1, N'0'
          , N'1 gibt ausschließlich dieses Help-Resultset aus und ignoriert alle anderen Parameter.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'PARAMETER', 3
          , N'@ResultTable', 'sysname', 0, 1, N'NULL'
          , N'Optionaler lokaler Temp-Tabellenname. Bei erfolgreicher Validierung oder fachlichem Validierungsresultat wird genau die vorhandene Ergebniszeile in die vorbereitete ResultTable geschrieben.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'PARAMETER', 4
          , N'@KeepData', 'bit', 0, 1, N'0'
          , N'Bei ResultTable-Routing bleiben vorhandene Zeilen erhalten, wenn 1; sonst wird die Zieltabelle gemäß ResultTable-Vertrag geleert.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'RESULT_COLUMN', 1
          , N'Content', 'varbinary(max)', 0, 1, NULL
          , N'Der binäre Dateiinhalt. Bei Validierungsfehlern NULL.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'RESULT_COLUMN', 2
          , N'BytesRead', 'bigint', 0, 0, NULL
          , N'Anzahl gelesener Bytes. Bei Validierungsfehlern vor dem Lesen 0.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'RESULT_COLUMN', 3
          , N'IsValid', 'bit', 0, 0, NULL
          , N'1, wenn der Inhalt erfolgreich gelesen wurde; 0 bei fachlichem Fehler.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'RESULT_COLUMN', 4
          , N'ValidationCode', 'int', 0, 1, NULL
          , N'Fachlicher Fehlercode oder NULL bei Erfolg.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'RESULT_COLUMN', 5
          , N'ValidationMessage', 'nvarchar(4000)', 0, 1, NULL
          , N'Fachliche Fehlermeldung oder NULL bei Erfolg.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'ERROR', 1
          , N'51320', NULL, NULL, NULL, NULL
          , N'Ungültiger oder leerer Dateipfad.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'ERROR', 2
          , N'51321', NULL, NULL, NULL, NULL
          , N'Pfad liegt außerhalb der konfigurierten Root-Allowlist.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'ERROR', 3
          , N'51322', NULL, NULL, NULL, NULL
          , N'Pfad enthält verbotene relative Segmente oder Traversal.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'ERROR', 4
          , N'51323', NULL, NULL, NULL, NULL
          , N'Datei überschreitet @MaxBytes.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'PERMISSION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Erforderlich ist EXECUTE auf toolbelt_file.USP_LoadBinaryFile, Lesezugriff auf den Dateipfad sowie ADMINISTER BULK OPERATIONS oder ad hoc distributed queries für OPENROWSET(BULK...). Für @ResultTable zusätzlich EXECUTE auf toolbelt_core.USP_PrepareResultTable.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'LIMITATION', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Dateigröße ist durch varbinary(max) auf ca. 2 GB begrenzt. OPENROWSET(BULK...) liest die gesamte Datei; @MaxBytes prüft erst nach dem Lesen. ResultTable-Änderung und Datei-I/O liegen in derselben Transaktion.'
          , NULL )
        , ( '1.0', N'toolbelt_file', N'USP_LoadBinaryFile', 'EXAMPLE', 1
          , NULL, NULL, NULL, NULL, NULL
          , N'Liest eine Datei aus einem erlaubten Root.'
          , N'EXEC toolbelt_file.USP_LoadBinaryFile
      @FilePath = N''/var/opt/mssql/data/allowed/sample.bin'';' );

        SELECT
              HelpContractVersion
            , SchemaName
            , ObjectName
            , Section
            , Ordinal
            , ItemName
            , SqlDataType
            , IsRequired
            , IsNullable
            , DefaultValue
            , Description
            , ExampleSql
        FROM @Help
        ORDER BY
              CASE Section
                  WHEN 'DESCRIPTION'   THEN 1
                  WHEN 'PARAMETER'     THEN 2
                  WHEN 'RESULT_COLUMN' THEN 3
                  WHEN 'ERROR'         THEN 4
                  WHEN 'PERMISSION'    THEN 5
                  WHEN 'LIMITATION'    THEN 6
                  WHEN 'EXAMPLE'       THEN 7
              END
            , Ordinal;

        RETURN 0;
    END;

    DECLARE @InitialTransactionCount int = @@TRANCOUNT
          , @StartedTransaction bit = 0
          , @SavepointCreated bit = 0
          , @SavepointName varchar(32) = CONVERT(varchar(32), 'tbx_file_' + LEFT(REPLACE(CONVERT(varchar(36), NEWID()), '-', ''), 23))
          , @InsertResultSql nvarchar(max);

    IF @ResultTable IS NOT NULL SET XACT_ABORT OFF;
    SET @KeepData = ISNULL(@KeepData, 0);
    SET @Debug = ISNULL(@Debug, 0);
    IF @ResultTable IS NOT NULL AND @InitialTransactionCount > 0 AND XACT_STATE() <> 1
        THROW 51028, N'Der Callertransaktionszustand erlaubt keinen kontrollierten ResultTable-Savepoint.', 1;
    CREATE TABLE #tbx_LoadBinaryFileResult
    (
          Content varbinary(max) NULL
        , BytesRead bigint NOT NULL
        , IsValid bit NOT NULL
        , ValidationCode int NULL
        , ValidationMessage nvarchar(4000) NULL
    );
    BEGIN TRY
    IF @ResultTable IS NOT NULL
    BEGIN
        IF OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable', N'P') IS NULL
            THROW 51908, N'Für @ResultTable fehlt toolbelt.core.result-table.', 1;
        IF @InitialTransactionCount = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @StartedTransaction = 1;
        END
        ELSE
        BEGIN
            IF XACT_STATE() <> 1 THROW 51028, N'Der Callertransaktionszustand erlaubt keinen kontrollierten ResultTable-Savepoint.', 1;
            SAVE TRANSACTION @SavepointName;
            SET @SavepointCreated = 1;
        END;
        EXEC toolbelt_core.USP_PrepareResultTable
              @ResultTableToAlter = @ResultTable
            , @LikeTable = N'#tbx_LoadBinaryFileResult'
            , @KeepData = @KeepData
            , @Debug = @Debug;
    END;
    SET @FilePath = NULLIF(LTRIM(RTRIM(@FilePath)), N'');
    SET @MaxBytes = NULLIF(@MaxBytes, 0);
    SET @Debug    = ISNULL(@Debug, 0);
    SET @KeepData = ISNULL(@KeepData, 0);
    IF @FilePath IS NULL
    BEGIN
        INSERT #tbx_LoadBinaryFileResult VALUES(NULL, 0, 0, 51320, N'Ungültiger oder leerer Dateipfad.');
        GOTO EmitResult;
    END;

    DECLARE @NormalizedPath nvarchar(4000) = @FilePath;

    -- Plattformunabhängige Normalisierung: Backslash -> Slash für Vergleich.
    SET @NormalizedPath = REPLACE(@NormalizedPath, N'\\', N'/');
    SET @NormalizedPath = REPLACE(@NormalizedPath, N'\', N'/');

    -- Traversal-Prüfung.
    IF @NormalizedPath LIKE N'%/../%' OR @NormalizedPath LIKE N'%/..'
       OR @NormalizedPath LIKE N'../%'
    BEGIN
        INSERT #tbx_LoadBinaryFileResult VALUES(NULL, 0, 0, 51322, N'Pfad enthält verbotene relative Segmente oder Traversal.');
        GOTO EmitResult;
    END;

    -- Pfad muss absolut sein: lokaler Buchstabe oder UNC.
    IF @NormalizedPath NOT LIKE N'[A-Za-z]:/%'
       AND @NormalizedPath NOT LIKE N'//%'
       AND @NormalizedPath NOT LIKE N'/%'
    BEGIN
        INSERT #tbx_LoadBinaryFileResult VALUES(NULL, 0, 0, 51320, N'Ungültiger oder leerer Dateipfad.');
        GOTO EmitResult;
    END;

    -- Allowlist-Prüfung (Latin1_General_100_BIN2 für byteidentischen Vergleich).
    IF NOT EXISTS
       (
:r ../Source/FileContentRootPredicate.sql
       )
    BEGIN
        INSERT #tbx_LoadBinaryFileResult VALUES(NULL, 0, 0, 51321, N'Pfad liegt außerhalb der konfigurierten Root-Allowlist.');
        GOTO EmitResult;
    END;

    DECLARE @Sql nvarchar(max)
          , @Content varbinary(max)
          , @BytesRead bigint;

    SET @Sql = N'SET @Content = (SELECT BulkColumn FROM OPENROWSET(BULK '
               + QUOTENAME(@FilePath, N'''')
               + N', SINGLE_BLOB) AS x);';

    BEGIN TRY
        EXEC sys.sp_executesql
              @stmt = @Sql
            , @params = N'@Content varbinary(max) OUTPUT'
            , @Content = @Content OUTPUT;

        SET @BytesRead = DATALENGTH(@Content);

        IF @MaxBytes IS NOT NULL AND @BytesRead > @MaxBytes
        BEGIN
            INSERT #tbx_LoadBinaryFileResult VALUES(NULL, @BytesRead, 0, 51323, N'Datei überschreitet @MaxBytes.');
            GOTO EmitResult;
        END;

        INSERT #tbx_LoadBinaryFileResult VALUES(@Content, @BytesRead, 1, NULL, NULL);
        GOTO EmitResult;
    END TRY
    BEGIN CATCH
      DECLARE @ProviderError nvarchar(2048) = N'Datei konnte nicht ueber OPENROWSET gelesen werden. Engine-Meldung: '
        + REPLACE(LEFT(ERROR_MESSAGE(), 1700), N'%', N'%%');
      THROW 51326, @ProviderError, 1;
    END CATCH;
    END TRY
    BEGIN CATCH
        IF @StartedTransaction = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @SavepointCreated = 1 AND XACT_STATE() = 1 ROLLBACK TRANSACTION @SavepointName;
        THROW;
    END CATCH;

EmitResult:
    IF @ResultTable IS NULL
    BEGIN
        SELECT Content, BytesRead, IsValid, ValidationCode, ValidationMessage
        FROM #tbx_LoadBinaryFileResult;
        RETURN 0;
    END;

    BEGIN TRY
        SET @InsertResultSql = N'INSERT INTO ' + QUOTENAME(@ResultTable)
            + N' (Content,BytesRead,IsValid,ValidationCode,ValidationMessage)'
            + N' SELECT Content,BytesRead,IsValid,ValidationCode,ValidationMessage FROM #tbx_LoadBinaryFileResult;';
        EXEC sys.sp_executesql @InsertResultSql;
        IF @StartedTransaction = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @StartedTransaction = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @SavepointCreated = 1 AND XACT_STATE() = 1 ROLLBACK TRANSACTION @SavepointName;
        THROW;
    END CATCH;
    RETURN 0;
END;
GO
