SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [toolbelt_core].[USP_CompleteWork]
(
      @WorkItemId bigint           = NULL
    , @ClaimToken uniqueidentifier = NULL
    , @ResultTable sysname         = NULL
    , @KeepData    bit             = 0
    , @Debug       tinyint         = 0
    , @Hilfe       bit             = 0
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;
    SET @KeepData = ISNULL(@KeepData, 0);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Hilfe = ISNULL(@Hilfe, 0);

    IF @Hilfe = 1
    BEGIN
        SELECT CAST('1.0' AS varchar(16)) AS HelpContractVersion,
               CAST(N'toolbelt_core' AS sysname) AS SchemaName,
               CAST(N'USP_CompleteWork' AS sysname) AS ObjectName,
               v.Section, v.Ordinal, v.ItemName, v.SqlDataType, v.IsRequired,
               v.IsNullable, v.DefaultValue, v.Description, v.ExampleSql
        FROM (VALUES
          (CAST('DESCRIPTION' AS varchar(32)),1,CAST(NULL AS sysname),CAST(NULL AS varchar(256)),CAST(NULL AS bit),CAST(NULL AS bit),CAST(NULL AS nvarchar(4000)),CAST(N'Schließt genau ein CLAIMED Work Item mit dem passenden ClaimToken als COMPLETED ab. Ein fachliches Arbeitsergebnis wird in E1a nicht gespeichert.' AS nvarchar(max)),CAST(NULL AS nvarchar(max))),
          ('PARAMETER',1,N'@WorkItemId','bigint',1,0,NULL,N'Eindeutige Queue-ID.',NULL),
          ('PARAMETER',2,N'@ClaimToken','uniqueidentifier',1,0,NULL,N'Vom erfolgreichen Claim zurückgegebenes Ownership-Token.',NULL),
          ('PARAMETER',3,N'@ResultTable','sysname',0,1,NULL,N'Optionale lokale Temp-Tabelle für die Statuszeile.',NULL),
          ('PARAMETER',4,N'@KeepData','bit',0,0,N'0',N'Steuert die ResultTable-Vorbereitung.',NULL),
          ('PARAMETER',5,N'@Debug','tinyint',0,0,N'0',N'Erzeugt bei Werten größer 0 eine abstrakte Informationsmeldung.',NULL),
          ('PARAMETER',6,N'@Hilfe','bit',0,0,N'0',N'1 gibt ausschließlich dieses Help-Resultset aus.',NULL),
          ('RESULT_COLUMN',1,N'WorkItemId','bigint',0,0,NULL,N'Eindeutige Queue-ID.',NULL),
          ('RESULT_COLUMN',2,N'WorkTypeName','varchar(128)',0,0,NULL,N'Kanonischer Work-Type-Name.',NULL),
          ('RESULT_COLUMN',3,N'Status','varchar(16)',0,0,NULL,N'Nach Erfolg stets COMPLETED.',NULL),
          ('RESULT_COLUMN',4,N'EnqueuedAtUtc','datetime2(7)',0,0,NULL,N'UTC-Zeitpunkt der Einreihung.',NULL),
          ('RESULT_COLUMN',5,N'EnqueuedBy','sysname',0,0,NULL,N'Original-Login der Einreihung.',NULL),
          ('RESULT_COLUMN',6,N'ClaimedAtUtc','datetime2(7)',0,1,NULL,N'UTC-Zeitpunkt des Claims.',NULL),
          ('RESULT_COLUMN',7,N'ClaimedBy','sysname',0,1,NULL,N'Original-Login des Claimers.',NULL),
          ('RESULT_COLUMN',8,N'CompletedAtUtc','datetime2(7)',0,1,NULL,N'UTC-Zeitpunkt des Abschlusses.',NULL),
          ('RESULT_COLUMN',9,N'CompletedBy','sysname',0,1,NULL,N'Original-Login des Abschlusses.',NULL),
          ('RESULT_COLUMN',10,N'FailedAtUtc','datetime2(7)',0,1,NULL,N'Bei COMPLETED NULL.',NULL),
          ('RESULT_COLUMN',11,N'FailedBy','sysname',0,1,NULL,N'Bei COMPLETED NULL.',NULL),
          ('RESULT_COLUMN',12,N'FailureCode','varchar(64)',0,1,NULL,N'Bei COMPLETED NULL.',NULL),
          ('RESULT_COLUMN',13,N'FailureMessage','nvarchar(1000)',0,1,NULL,N'Bei COMPLETED NULL.',NULL),
          ('RESULT_COLUMN',14,N'RowVersion','binary(8)',0,0,NULL,N'Aktueller Concurrency-Marker.',NULL),
          ('RESULT_COLUMN',15,N'ClaimGeneration','bigint',0,0,NULL,N'Ownership-Generation des abgeschlossenen Claims.',NULL),
          ('RESULT_COLUMN',16,N'LeaseDurationSeconds','int',0,1,NULL,N'Lease-Dauer des abgeschlossenen Claims.',NULL),
          ('RESULT_COLUMN',17,N'LeaseUntilUtc','datetime2(7)',0,1,NULL,N'Lease-Grenze des abgeschlossenen Claims.',NULL),
          ('RESULT_COLUMN',18,N'LastHeartbeatAtUtc','datetime2(7)',0,1,NULL,N'Letzter Heartbeat des abgeschlossenen Claims.',NULL),
          ('RESULT_COLUMN',19,N'IsLeaseExpired','bit',0,0,NULL,N'Bei COMPLETED stets 0.',NULL),
          ('RESULT_COLUMN',20,N'RecoveryCount','bigint',0,0,NULL,N'Kumulierte Recoveries vor diesem Abschluss.',NULL),
          ('RESULT_COLUMN',21,N'LastRecoveredAtUtc','datetime2(7)',0,1,NULL,N'Zeitpunkt der letzten Recovery.',NULL),
          ('RESULT_COLUMN',22,N'LastRecoveredBy','sysname',0,1,NULL,N'Original-Login der letzten Recovery.',NULL),
          ('ERROR',1,N'51920-51924',NULL,NULL,NULL,NULL,N'Parameter-, Zustands-, Token- oder Transaktionsfehler.',NULL),
          ('EXAMPLE',1,NULL,NULL,NULL,NULL,NULL,N'Schließt einen zuvor beanspruchten synthetischen Auftrag ab.',N'EXEC toolbelt_core.USP_CompleteWork @WorkItemId=1, @ClaimToken=''00000000-0000-0000-0000-000000000001'';')
        ) v(Section,Ordinal,ItemName,SqlDataType,IsRequired,IsNullable,DefaultValue,Description,ExampleSql)
        ORDER BY CASE v.Section WHEN 'DESCRIPTION' THEN 1 WHEN 'PARAMETER' THEN 2 WHEN 'RESULT_COLUMN' THEN 3 WHEN 'ERROR' THEN 4 ELSE 5 END,v.Ordinal;
        RETURN 0;
    END;

    IF @WorkItemId IS NULL OR @WorkItemId <= 0 OR @ClaimToken IS NULL
        THROW 51920, N'@WorkItemId und @ClaimToken sind erforderlich.', 1;
    IF XACT_STATE() = -1
        THROW 51924, N'Ein Work Item kann in einer uncommittable Caller-Transaktion nicht abgeschlossen werden.', 1;

    CREATE TABLE #tbx_WorkQueue_StatusShape
    (WorkItemId bigint NOT NULL,WorkTypeName varchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,Status varchar(16) COLLATE Latin1_General_100_BIN2 NOT NULL,EnqueuedAtUtc datetime2(7) NOT NULL,EnqueuedBy sysname NOT NULL,ClaimedAtUtc datetime2(7) NULL,ClaimedBy sysname NULL,CompletedAtUtc datetime2(7) NULL,CompletedBy sysname NULL,FailedAtUtc datetime2(7) NULL,FailedBy sysname NULL,FailureCode varchar(64) COLLATE Latin1_General_100_BIN2 NULL,FailureMessage nvarchar(1000) NULL,RowVersion binary(8) NOT NULL,ClaimGeneration bigint NOT NULL,LeaseDurationSeconds int NULL,LeaseUntilUtc datetime2(7) NULL,LastHeartbeatAtUtc datetime2(7) NULL,IsLeaseExpired bit NOT NULL,RecoveryCount bigint NOT NULL,LastRecoveredAtUtc datetime2(7) NULL,LastRecoveredBy sysname NULL);
    CREATE TABLE #tbx_WorkQueue_StatusResult
    (WorkItemId bigint NOT NULL,WorkTypeName varchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,Status varchar(16) COLLATE Latin1_General_100_BIN2 NOT NULL,EnqueuedAtUtc datetime2(7) NOT NULL,EnqueuedBy sysname NOT NULL,ClaimedAtUtc datetime2(7) NULL,ClaimedBy sysname NULL,CompletedAtUtc datetime2(7) NULL,CompletedBy sysname NULL,FailedAtUtc datetime2(7) NULL,FailedBy sysname NULL,FailureCode varchar(64) COLLATE Latin1_General_100_BIN2 NULL,FailureMessage nvarchar(1000) NULL,RowVersion binary(8) NOT NULL,ClaimGeneration bigint NOT NULL,LeaseDurationSeconds int NULL,LeaseUntilUtc datetime2(7) NULL,LastHeartbeatAtUtc datetime2(7) NULL,IsLeaseExpired bit NOT NULL,RecoveryCount bigint NOT NULL,LastRecoveredAtUtc datetime2(7) NULL,LastRecoveredBy sysname NULL);

    DECLARE @InitialTranCount int = @@TRANCOUNT;
    DECLARE @CurrentStatus varchar(16);
    DECLARE @CurrentToken uniqueidentifier,@LeaseUntilUtc datetime2(7),@NowUtc datetime2(7);
    IF @InitialTranCount = 0 BEGIN TRANSACTION;
    ELSE SAVE TRANSACTION TBX_WorkQueue_Complete;
    BEGIN TRY
        SELECT @CurrentStatus=Status,@CurrentToken=ClaimToken,@LeaseUntilUtc=LeaseUntilUtc
        FROM toolbelt_core.WorkItem WITH (UPDLOCK,HOLDLOCK)
        WHERE WorkItemId=@WorkItemId;
        IF @CurrentStatus IS NULL THROW 51921,N'Das Work Item existiert nicht.',1;
        IF @CurrentStatus<>'CLAIMED' THROW 51922,N'Nur ein CLAIMED Work Item kann abgeschlossen werden.',1;
        IF @CurrentToken<>@ClaimToken THROW 51923,N'@ClaimToken besitzt das Work Item nicht.',1;
        -- Die geheime Completionnonce entsteht erst im verifizierten Handlerabschluss.
        -- Der reservationsbezogene Transaktionslock bleibt bis zum äußeren Commit.
        DECLARE @ManagedReservationId uniqueidentifier,@ManagedCompletionNonce uniqueidentifier,@ManagedHold bit;
        SELECT @ManagedReservationId=ManagedReservationId,@ManagedCompletionNonce=ManagedCompletionNonce,@ManagedHold=ManagedHold
        FROM toolbelt_core.WorkItem WHERE WorkItemId=@WorkItemId;
        IF @ManagedHold=1 THROW 54201,N'Der Claim steht unter persistentem Hold.',2;
        IF @ManagedReservationId IS NOT NULL AND
           (@InitialTranCount<>1 OR @ManagedCompletionNonce IS NULL
            OR TRY_CONVERT(uniqueidentifier,SESSION_CONTEXT(N'toolbelt.worker.completion_nonce')) IS NULL
            OR TRY_CONVERT(uniqueidentifier,SESSION_CONTEXT(N'toolbelt.worker.completion_nonce'))<>@ManagedCompletionNonce
            OR APPLOCK_MODE(N'public',N'Toolbelt.Worker.Disposition.'+CONVERT(nvarchar(36),@ManagedReservationId),N'Transaction')<>N'Exclusive')
            THROW 54201,N'Der verwaltete Claim besitzt keinen verifizierten Completionpfad.',3;
        SET @NowUtc=SYSUTCDATETIME();
        IF @LeaseUntilUtc<=@NowUtc THROW 51922,N'Die Lease ist abgelaufen; nur Recovery darf den Claim verändern.',2;

        IF @ResultTable IS NOT NULL
        BEGIN
            IF OBJECT_ID(N'toolbelt_core.USP_PrepareResultTable',N'P') IS NULL THROW 51924,N'Für @ResultTable fehlt toolbelt.core.result-table.',2;
            EXEC toolbelt_core.USP_PrepareResultTable @ResultTableToAlter=@ResultTable,@LikeTable=N'#tbx_WorkQueue_StatusShape',@KeepData=@KeepData;
        END;

        UPDATE toolbelt_core.WorkItem
        SET Status='COMPLETED',CompletedAtUtc=@NowUtc,CompletedBy=ORIGINAL_LOGIN()
        WHERE WorkItemId=@WorkItemId AND Status='CLAIMED' AND ClaimToken=@ClaimToken AND LeaseUntilUtc>@NowUtc;
        IF @@ROWCOUNT<>1 THROW 51923,N'Der Claim-Zustand hat sich konkurrierend verändert.',2;

        INSERT INTO #tbx_WorkQueue_StatusResult SELECT WorkItemId,WorkTypeName,Status,EnqueuedAtUtc,EnqueuedBy,ClaimedAtUtc,ClaimedBy,CompletedAtUtc,CompletedBy,FailedAtUtc,FailedBy,FailureCode,FailureMessage,RowVersion,ClaimGeneration,LeaseDurationSeconds,LeaseUntilUtc,LastHeartbeatAtUtc,IsLeaseExpired,RecoveryCount,LastRecoveredAtUtc,LastRecoveredBy FROM toolbelt_core.VW_WorkQueue WHERE WorkItemId=@WorkItemId;
        IF @ResultTable IS NOT NULL
        BEGIN
            DECLARE @InsertSql nvarchar(max)=N'INSERT INTO '+QUOTENAME(@ResultTable)+N' (WorkItemId,WorkTypeName,Status,EnqueuedAtUtc,EnqueuedBy,ClaimedAtUtc,ClaimedBy,CompletedAtUtc,CompletedBy,FailedAtUtc,FailedBy,FailureCode,FailureMessage,RowVersion,ClaimGeneration,LeaseDurationSeconds,LeaseUntilUtc,LastHeartbeatAtUtc,IsLeaseExpired,RecoveryCount,LastRecoveredAtUtc,LastRecoveredBy) SELECT WorkItemId,WorkTypeName,Status,EnqueuedAtUtc,EnqueuedBy,ClaimedAtUtc,ClaimedBy,CompletedAtUtc,CompletedBy,FailedAtUtc,FailedBy,FailureCode,FailureMessage,RowVersion,ClaimGeneration,LeaseDurationSeconds,LeaseUntilUtc,LastHeartbeatAtUtc,IsLeaseExpired,RecoveryCount,LastRecoveredAtUtc,LastRecoveredBy FROM #tbx_WorkQueue_StatusResult;';
            EXEC sys.sp_executesql @InsertSql;
        END;
        IF @InitialTranCount=0 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @InitialTranCount=0 AND XACT_STATE()<>0 ROLLBACK TRANSACTION;
        ELSE IF @InitialTranCount>0 AND XACT_STATE()=1 ROLLBACK TRANSACTION TBX_WorkQueue_Complete;
        THROW;
    END CATCH;
    IF @Debug>0 RAISERROR(N'USP_CompleteWork: Work Item abgeschlossen.',10,1) WITH NOWAIT;
    IF @ResultTable IS NULL SELECT * FROM #tbx_WorkQueue_StatusResult;
    RETURN 0;
END;
GO
