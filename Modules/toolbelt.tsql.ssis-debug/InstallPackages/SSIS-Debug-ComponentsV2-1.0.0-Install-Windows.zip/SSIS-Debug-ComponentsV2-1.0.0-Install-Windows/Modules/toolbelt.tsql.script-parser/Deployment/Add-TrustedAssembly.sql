:On Error exit
SET NOCOUNT ON;

/*
 * Separater administrativer Opt-in. Dieses Skript aktiviert CLR nicht und
 * verändert clr strict security nicht.
 */
IF IS_SRVROLEMEMBER(N'sysadmin') <> 1
    THROW 53110, N'Das Trust-Opt-in für die ScriptParser-Assembly erfordert sysadmin.', 1;

IF NOT EXISTS
   (
       SELECT 1
       FROM sys.configurations
       WHERE name = N'clr enabled'
         AND value_in_use = 1
   )
    THROW 53111, N'CLR ist nicht aktiviert. Das Modul ändert keine Instanzoption.', 1;

IF NOT EXISTS
   (
       SELECT 1
       FROM sys.configurations
       WHERE name = N'clr strict security'
         AND value_in_use = 1
   )
    THROW 53112, N'clr strict security muss aktiviert bleiben.', 1;

DECLARE
      @AssemblyHash varbinary(64) =
          CONVERT(varbinary(64), N'$(AssemblyHash)', 1)
    , @ScriptDomAssemblyHash varbinary(64) =
          CONVERT(varbinary(64), N'$(ScriptDomAssemblyHash)', 1)
    , @AssemblyDescription nvarchar(4000) =
          N'$(AssemblyDescription)';

IF @AssemblyHash IS NULL OR DATALENGTH(@AssemblyHash) <> 64
    THROW 53113, N'AssemblyHash muss ein SHA2-512-Hexliteral mit genau 64 Bytes sein.', 1;
IF NULLIF(@AssemblyDescription, N'') IS NULL
    THROW 53114, N'AssemblyDescription darf nicht leer sein.', 1;
IF @ScriptDomAssemblyHash IS NULL OR DATALENGTH(@ScriptDomAssemblyHash) <> 64
    THROW 53115, N'ScriptDomAssemblyHash muss ein SHA2-512-Hexliteral mit genau 64 Bytes sein.', 1;

IF NOT EXISTS
   (
       SELECT 1
       FROM sys.trusted_assemblies
       WHERE hash = @AssemblyHash
   )
    EXEC sys.sp_add_trusted_assembly
          @hash = @AssemblyHash
        , @description = @AssemblyDescription;
IF NOT EXISTS (SELECT 1 FROM sys.trusted_assemblies WHERE hash = @ScriptDomAssemblyHash)
    EXEC sys.sp_add_trusted_assembly
          @hash = @ScriptDomAssemblyHash
        , @description = N'SQL Server Toolbelt ScriptDom dependency 18.x';
GO
